package net.hxhadventure.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
   public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, "hxhadventure");
   public static final RegistryObject<Block> WATER_GLASS_BLOCK = BLOCKS.register(
      "nen_glass", () -> new NenWaterGlassBlock(Properties.of().noOcclusion().strength(0.5F))
   );

   public static final RegistryObject<Block> LAPTOP = BLOCKS.register(
      "laptop", () -> new LaptopBlock(Properties.of().noOcclusion().strength(0.8F).sound(net.minecraft.world.level.block.SoundType.METAL))
   );

   public ModBlocks() {
   }
}
