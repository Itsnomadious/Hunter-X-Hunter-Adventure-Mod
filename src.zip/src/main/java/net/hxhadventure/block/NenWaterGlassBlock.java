package net.hxhadventure.block;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.entity.client.gui.WaterDivinationScreen;

/**
 * The Water Divination glass. It is crafted and placed empty (stage 0); right-click it with a water bucket to fill it (stage 1),
 * then with any leaf block to float a leaf on it (stage 2). Only then does right-clicking it open Water Divination.
 * Glasses placed before stages existed load as stage 2, so they keep working.
 */
public class NenWaterGlassBlock extends Block {
   public static final IntegerProperty STAGE = IntegerProperty.create("stage", 0, 2);
   public static final int EMPTY = 0, WATER = 1, READY = 2;

   public NenWaterGlassBlock(Properties properties) {
      super(properties);
      this.registerDefaultState(this.stateDefinition.any().setValue(STAGE, READY));
   }

   @Override
   protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
      builder.add(STAGE);
   }

   @Override
   public BlockState getStateForPlacement(BlockPlaceContext context) {
      return this.defaultBlockState().setValue(STAGE, EMPTY);
   }

   public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
      int stage = state.getValue(STAGE);
      ItemStack held = player.getItemInHand(hand);

      if (stage == EMPTY) {
         if (held.is(Items.WATER_BUCKET)) {
            if (!level.isClientSide()) {
               level.setBlock(pos, state.setValue(STAGE, WATER), 3);
               if (!player.getAbilities().instabuild) player.setItemInHand(hand, new ItemStack(Items.BUCKET));
               level.playSound(null, pos, SoundEvents.BUCKET_EMPTY, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide());
         }
         if (!level.isClientSide()) player.displayClientMessage(Component.literal("§bThe glass is empty. Right-click it with a water bucket."), true);
         return InteractionResult.SUCCESS;
      }

      if (stage == WATER) {
         if (Block.byItem(held.getItem()).defaultBlockState().is(BlockTags.LEAVES)) {
            if (!level.isClientSide()) {
               level.setBlock(pos, state.setValue(STAGE, READY), 3);
               if (!player.getAbilities().instabuild) held.shrink(1);
               level.playSound(null, pos, SoundEvents.CROP_PLANTED, SoundSource.BLOCKS, 1.0F, 1.2F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide());
         }
         if (!level.isClientSide()) player.displayClientMessage(Component.literal("§bThe glass is full. Float a leaf on it: right-click with a leaf block."), true);
         return InteractionResult.SUCCESS;
      }

      Combat combat = Combat.get(player);
      if (combat != null && combat.getCurrentKit() >= 1) {
         if (player instanceof net.minecraft.server.level.ServerPlayer sp) net.hxhadventure.addon.NenProfile.sync(sp); // the client learns the current hxhnentypeselect value
         if (level.isClientSide()) {
            NenWaterGlassBlock.ClientScreenHandler.openWaterDivinationScreen();
         }

         return InteractionResult.SUCCESS;
      } else {
         if (!level.isClientSide()) {
            player.sendSystemMessage(Component.literal("§cYou aren't ready yet! Find a teacher."));
         }

         return InteractionResult.SUCCESS;
      }
   }

   private static class ClientScreenHandler {
      private ClientScreenHandler() {
      }

      @OnlyIn(Dist.CLIENT)
      public static void openWaterDivinationScreen() {
         Minecraft.getInstance().setScreen(new WaterDivinationScreen());
      }
   }
}
