package net.hxhadventure.block;

import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.quest.QuestData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The Hunter laptop: a placeable laptop that opens the Hunter Association's quest network. Right-click it (as a licensed Hunter) and the camera
 * zooms into its screen, where a browser lists the quests (see LaptopScreen). Its keyboard faces the player who placed it.
 */
public class LaptopBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    /** One shape per facing, indexed by {@link #steps}. Built from the model: a flat deck and the tilted lid's bounding box. */
    private static final VoxelShape[] SHAPES = new VoxelShape[4];

    static {
        for (int k = 0; k < 4; k++) {
            SHAPES[k] = Shapes.or(rotated(k, 1, 0, 1, 15, 1, 12), rotated(k, 1, 1, 11, 15, 10.5, 15));
        }
    }

    public LaptopBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    /** How many quarter turns (clockwise from above) the model, which is drawn facing north, is turned for a facing. */
    private static int steps(Direction d) {
        return switch (d) {
            case EAST -> 1;
            case SOUTH -> 2;
            case WEST -> 3;
            default -> 0;
        };
    }

    /** A box given in model space (1/16 block units, facing north), turned {@code k} quarter turns about the block's centre. */
    private static VoxelShape rotated(int k, double x1, double y1, double z1, double x2, double y2, double z2) {
        double ax = x1 - 8, az = z1 - 8, bx = x2 - 8, bz = z2 - 8;
        for (int i = 0; i < k; i++) {
            double nax = -az, naz = ax, nbx = -bz, nbz = bx;
            ax = nax;
            az = naz;
            bx = nbx;
            bz = nbz;
        }
        return Block.box(Math.min(ax, bx) + 8, y1, Math.min(az, bz) + 8, Math.max(ax, bx) + 8, y2, Math.max(az, bz) + 8);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPES[steps(state.getValue(FACING))];
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer sp) {
            if (!QuestData.isHunter(sp)) {
                sp.displayClientMessage(Component.literal("§cThe Hunter Association's quest network is for licensed Hunters only."), true);
                return InteractionResult.CONSUME;
            }
            QuestData.sync(sp, pos, true);
        }
        return InteractionResult.CONSUME;
    }
}
