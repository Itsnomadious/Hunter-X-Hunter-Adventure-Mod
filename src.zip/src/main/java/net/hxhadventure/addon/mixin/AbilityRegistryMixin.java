package net.hxhadventure.addon.mixin;

import java.util.HashMap;
import java.util.function.Consumer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.addon.ChainAbilities;
import net.hxhadventure.addon.ExtrasHooks;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Registers the chain and Skill Hunter abilities in HxHAdventure's ability map (what Z runs). */
@Mixin(value = AbilityRegistry.class, remap = false)
public abstract class AbilityRegistryMixin {

    @Shadow @Final private static HashMap<String, Consumer<ServerPlayer>> ABILITIES;

    /** End of AbilityRegistry's static block, after the base abilities are put in the map. */
    @Inject(method = "<clinit>", at = @At("TAIL"), remap = false)
    private static void hxh$registerExtraAbilities(CallbackInfo ci) {
        ChainAbilities.registerAll(ABILITIES);
    }

    // ---- Black Voice: Z brings you back from a borrowed body; Shift+Z with the phone takes one ----

    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private static void hxh$blackVoiceUse(String id, ServerPlayer sp, CallbackInfo ci) {
        if (net.hxhadventure.addon.BlackVoice.interceptUse(id, sp)) ci.cancel();
    }

    // ---- Chain Jail: Ten and Ren cannot be switched on (turning them off is always allowed) ----

    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private static void hxh$jailBlocksNenKeys(String id, ServerPlayer sp, CallbackInfo ci) {
        if (("ten_toggle".equals(id) || "ren_toggle".equals(id)) && ExtrasHooks.nenBlocked(sp)) ci.cancel();
    }

    // ---- Shu Vows: while Shu is on, the Ren key cannot break the aura form the Vow forces (Ren or Ko) ----

    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private static void hxh$shuForcesForm(String id, ServerPlayer sp, CallbackInfo ci) {
        if ("ren_toggle".equals(id) && net.hxhadventure.addon.Vows.refuseShuFormToggle(sp)) ci.cancel();
    }

    // ---- Pain Packer: while the armor is on, Ren is forced and cannot be switched off by hand ----

    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private static void hxh$painPackerForcesRen(String id, ServerPlayer sp, CallbackInfo ci) {
        if ("ren_toggle".equals(id) && net.hxhadventure.addon.PainPacker.isArmored(sp)) {
            sp.displayClientMessage(net.minecraft.network.chat.Component.literal("\u00a74Pain Packer: Ren is forced while the armor is on"), true);
            ci.cancel();
        }
    }

    // ---- Vows: a sworn Condition / Limitation / Vow can forbid a Hatsu ability, and some Vows punish it afterwards ----

    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private static void hxh$vowsGate(String id, ServerPlayer sp, CallbackInfo ci) {
        if (net.hxhadventure.addon.Vows.blocksAbility(sp, id)) {
            ci.cancel();
            return;
        }
        if (net.hxhadventure.addon.Guanyin.interceptBasic(id, sp)) {
            ci.cancel();
            return;
        }
        if (net.hxhadventure.addon.Blinky.interceptBasic(id, sp)) {
            ci.cancel();
            return;
        }
        if (net.hxhadventure.addon.NenStitches.interceptBasic(id, sp)) { // Nen Stitches: with Threads on, the basic attacks are slashes
            ci.cancel();
            return;
        }
        if (net.hxhadventure.addon.Iaido.interceptBasic(id, sp)) { // the sheathed Katana in hand: Attack / Strong attack are the iaido draw
            ci.cancel();
            return;
        }
        // Using any Hatsu ability (everything except the basic attacks and the Ten / Ren toggles) drops you out of Zetsu at once
        if (!net.hxhadventure.addon.NenAddonData.isBasicAbility(id)) {
            net.hxhadventure.addon.NenAddonData d = net.hxhadventure.addon.NenAddonData.peek(sp);
            if (d != null && d.zetsu) d.leaveZetsuForHatsu(sp);
        }
    }


    @Inject(method = "execute", at = @At("TAIL"), remap = false)
    private static void hxh$vowsAfter(String id, ServerPlayer sp, CallbackInfo ci) {
        net.hxhadventure.addon.Vows.afterAbility(sp, id);
    }

    @Inject(method = "toggleTen", at = @At("HEAD"), cancellable = true, remap = false)
    private static void hxh$jailBlocksTen(Player player, boolean on, CallbackInfo ci) {
        if (on && ExtrasHooks.nenBlocked(player)) ci.cancel();
    }

    @Inject(method = "toggleRen", at = @At("HEAD"), cancellable = true, remap = false)
    private static void hxh$jailBlocksRen(Player player, boolean on, CallbackInfo ci) {
        if (on && ExtrasHooks.renBlocked(player)) ci.cancel();
    }
}
