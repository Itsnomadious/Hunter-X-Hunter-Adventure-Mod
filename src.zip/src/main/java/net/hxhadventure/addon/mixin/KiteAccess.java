package net.hxhadventure.addon.mixin;

import net.hxhadventure.entity.custom.KiteEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Lets addon code read and drop Kite's aura (both members are private in the base mod). */
@Mixin(value = KiteEntity.class, remap = false)
public interface KiteAccess {
    @Accessor(value = "isNenActive", remap = false)
    boolean hxh$isNenActive();

    @Invoker(value = "deactivateNenAura", remap = false)
    void hxh$deactivateNenAura();
}
