package net.hxhadventure.addon.mixin;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.hxhadventure.addon.ExtrasHooks;
import net.hxhadventure.entity.custom.KiteEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * KiteEntity.tick() raises the NPC's aura whenever it has a living target and drops it when it has
 * none, so a chained NPC that keeps re-acquiring a target flickers its aura on and off. Refusing the
 * activation outright (Forced Zetsu / Chain Jail) means the aura is never attempted.
 */
@Mixin(value = KiteEntity.class, remap = false)
public abstract class KiteEntityMixin {

    @Inject(method = "activateNenAura", at = @At("HEAD"), cancellable = true, remap = false)
    private void hxh$noAuraWhileForced(ServerLevel level, CallbackInfo ci) {
        if (ExtrasHooks.hatsuForced((LivingEntity) (Object) this)) ci.cancel();
    }
}
