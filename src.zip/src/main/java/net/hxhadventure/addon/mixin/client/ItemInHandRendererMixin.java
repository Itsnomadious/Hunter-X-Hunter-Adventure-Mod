package net.hxhadventure.addon.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.hxhadventure.addon.client.ShuCoat;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Shu: right after the game draws a held item (first person, and third person through ItemInHandLayer, both go through this method),
 * the item is coated in the user's Ten. Named both ways (mapped / SRG) because this project's mixins use no refmap; require = 0 means
 * that if neither name matches the item is simply left uncoated instead of crashing the game.
 */
@Mixin(value = ItemInHandRenderer.class, remap = false)
public abstract class ItemInHandRendererMixin {

    /** Katana: turns the blade in the grip while a slash clip plays, so the cutting edge leads the swing. Runs before the display transform. */
    @Inject(method = {
        "renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
        "m_269530_(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"
    }, at = @At("HEAD"), remap = false, require = 0)
    private void hxh$katanaWrist(LivingEntity entity, ItemStack stack, ItemDisplayContext ctx, boolean left,
                                 PoseStack pose, MultiBufferSource buf, int light, CallbackInfo ci) {
        net.hxhadventure.addon.client.KatanaWrist.apply(entity, stack, ctx, pose);
    }

    @Inject(method = {
        "renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
        "m_269530_(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"
    }, at = @At("TAIL"), remap = false, require = 0)
    private void hxh$shuCoat(LivingEntity entity, ItemStack stack, ItemDisplayContext ctx, boolean left,
                             PoseStack pose, MultiBufferSource buf, int light, CallbackInfo ci) {
        ShuCoat.render(entity, stack, ctx, left, pose, buf);
    }
}
