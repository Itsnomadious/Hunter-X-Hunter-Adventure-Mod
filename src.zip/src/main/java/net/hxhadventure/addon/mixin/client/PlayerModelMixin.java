package net.hxhadventure.addon.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.hxhadventure.addon.client.ChainArm;
import net.hxhadventure.addon.client.anim.PoseDriver;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * After the game has posed the player, a playing chain ability takes over the right arm (and its sleeve) so the
 * arm moves with the animation. The method is named both ways (mapped / SRG) because this project's mixins do not
 * use a refmap; require = 0 means that if neither matches, the arm just stays still instead of crashing the game.
 */
@Mixin(value = PlayerModel.class, remap = false)
public abstract class PlayerModelMixin {

    /** Vanilla never resets the leg x pivots, and the pose framework moves them: put them back before this model is posed again. */
    @Inject(method = {
        "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V",
        "m_6973_(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V"
    }, at = @At("HEAD"), remap = false, require = 0)
    private void hxh$poseReset(LivingEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                               float netHeadYaw, float headPitch, CallbackInfo ci) {
        PoseDriver.beforeVanilla((PlayerModel<?>) (Object) this);
    }

    /**
     * Held items follow the wrist bend / roll of an authored pose (main_item / off_item in the pose json). If the method name
     * does not match, only the wrist bend is lost; the poses themselves still work.
     */
    @Inject(method = {
        "translateToHand(Lnet/minecraft/world/entity/HumanoidArm;Lcom/mojang/blaze3d/vertex/PoseStack;)V",
        "m_6002_(Lnet/minecraft/world/entity/HumanoidArm;Lcom/mojang/blaze3d/vertex/PoseStack;)V"
    }, at = @At("TAIL"), remap = false, require = 0)
    private void hxh$poseWrist(HumanoidArm side, PoseStack stack, CallbackInfo ci) {
        PoseDriver.applyWrist(stack, side);
    }

    @Inject(method = {
        "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V",
        "m_6973_(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V"
    }, at = @At("TAIL"), remap = false, require = 0)
    private void hxh$chainArm(LivingEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                              float netHeadYaw, float headPitch, CallbackInfo ci) {
        // authored poses / animations first, so the ability effects below can still take an arm over while they play
        PoseDriver.apply((PlayerModel<?>) (Object) this, entity, ageInTicks);
        ChainArm.apply((PlayerModel<?>) (Object) this, entity, ageInTicks);
        net.hxhadventure.addon.client.OrbFx.applyArms((PlayerModel<?>) (Object) this, entity);
        net.hxhadventure.addon.client.BlastFx.applyArm((PlayerModel<?>) (Object) this, entity);
        net.hxhadventure.addon.client.GumFx.applyArm((PlayerModel<?>) (Object) this, entity);
        net.hxhadventure.addon.client.TerpsichoraFx.applyArms((PlayerModel<?>) (Object) this, entity); // Terpsichora's marionette T-pose
        net.hxhadventure.addon.client.PrayFx.applyArms((PlayerModel<?>) (Object) this, entity); // praying: hands clasped together
        net.hxhadventure.addon.client.PaperFx.applyArm((PlayerModel<?>) (Object) this, entity); // Paper Manipulation: confetti drop / fan wave
        net.hxhadventure.addon.client.JajankenFx.applyArm((PlayerModel<?>) (Object) this, entity); // Jajanken Rock: fist drawn back / punch
        net.hxhadventure.addon.client.EstheticianClient.applyPose((PlayerModel<?>) (Object) this, entity); // Magical Esthetician: sitting / lying while Cookie works
        net.hxhadventure.addon.client.CyclotronFx.applyArm((PlayerModel<?>) (Object) this, entity); // Ripper Cyclotron: the spinning arm
        net.hxhadventure.addon.client.BlinkyFx.applyArm((PlayerModel<?>) (Object) this, entity); // Blinky: the head's swing, sucking and draining
        net.hxhadventure.addon.client.SmokeFx.applyArm((PlayerModel<?>) (Object) this, entity); // Smoke Manipulation: the pipe at the mouth / the big breath
        net.hxhadventure.addon.client.CrazySlotsFx.applyArm((PlayerModel<?>) (Object) this, entity); // Crazy Slots: Silent Waltz and the staff slam
        net.hxhadventure.addon.client.BarrierFx.applyPose((PlayerModel<?>) (Object) this, entity); // Bungee Barrier: wide stance, hands together then parting
        net.hxhadventure.addon.client.StitchFx.applyArm((PlayerModel<?>) (Object) this, entity); // Nen Stitches: Wound Sewing's flying hands
    }
}
