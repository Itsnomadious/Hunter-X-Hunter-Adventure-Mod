package net.hxhadventure.addon.mixin.client;

import net.minecraft.client.Minecraft;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.ChainAbilities;
import net.hxhadventure.addon.ExtrasHooks;
import net.hxhadventure.event.ClientAbilityHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Adds the chain / Skill Hunter abilities to the R (cycle) and Z (use) menu, and their HUD names. */
@Mixin(value = ClientAbilityHandler.class, remap = false)
public abstract class ClientAbilityHandlerMixin {

    /** The list of ability ids the R key cycles through. Runs at every return of the base method. */
    @Inject(method = "getCurrentSet", at = @At("RETURN"), cancellable = true, remap = false)
    private static void hxh$extendSet(CallbackInfoReturnable<String[]> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        cir.setReturnValue(ExtrasHooks.menuSet(cir.getReturnValue(), Combat.get(mc.player)));
    }

    /** The base method returns the raw id for names it does not know; swap in ours. */
    @Inject(method = "getSelectedAbilityName", at = @At("RETURN"), cancellable = true, remap = false)
    private static void hxh$abilityName(CallbackInfoReturnable<String> cir) {
        String name = ChainAbilities.displayName(cir.getReturnValue());
        if (name != null) cir.setReturnValue(name);
    }
}
