package net.hxhadventure.addon.mixin;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.ExtrasHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Kit checks for the addon Hatsu (the Nen type each one needs). Hatsu is chosen in the Water Divination menu or with /hxh set skill, never rolled. */
@Mixin(value = Combat.class, remap = false)
public abstract class CombatMixin {

    @Shadow private Player player;
    @Shadow private int nenType;
    @Shadow private int hatsuLevel;

    /** Same kind of check HxHAdventure does for kits 3-7: Chains needs conjurer/specialist, Skill Hunter and Doctor Blythe specialist. */
    @Inject(method = "setKit", at = @At("HEAD"), cancellable = true, remap = false)
    private void hxh$checkExtraKits(int kitId, CallbackInfoReturnable<Boolean> cir) {
        String message = null;
        if (kitId == ExtrasHooks.CHAINS_KIT && this.nenType != 4 && this.nenType != 6) {
            message = "\u00a7cYou must be a conjurer or specialist to use this!";
        } else if ((kitId == ExtrasHooks.HUNTER_KIT || kitId == ExtrasHooks.BLYTHE_KIT || kitId == net.hxhadventure.addon.LaplaceDevil.KIT) && this.nenType != 6) {
            message = "\u00a7cYou must be a specialist to use this!";
        }
        if ((kitId == ExtrasHooks.ORBS_KIT || kitId == ExtrasHooks.BLAST_KIT || kitId == net.hxhadventure.addon.HideAndSeek.KIT) && this.nenType != Combat.NEN_EMISSION) {
            message = "\u00a7cYou must be an emitter to use this!";
        }
        if (kitId == ExtrasHooks.GUM_KIT && this.nenType != Combat.NEN_TRANSMUTATION) {
            message = "\u00a7cYou must be a transmuter to use this!";
        }
        if (kitId == ExtrasHooks.JAJANKEN_KIT && this.nenType != Combat.NEN_ENHANCEMENT) {
            message = "\u00a7cYou must be an enhancer to use this!";
        }
        if (kitId == net.hxhadventure.addon.Guanyin.KIT && this.nenType != Combat.NEN_ENHANCEMENT) {
            message = "\u00a7cYou must be an enhancer to use this!";
        }
        if (kitId == net.hxhadventure.addon.RipperCyclotron.KIT && this.nenType != Combat.NEN_ENHANCEMENT) {
            message = "\u00a7cYou must be an enhancer to use this!";
        }
        if (kitId == net.hxhadventure.addon.BigBangImpact.KIT && this.nenType != Combat.NEN_ENHANCEMENT) {
            message = "\u00a7cYou must be an enhancer to use this!";
        }
        if (kitId == ExtrasHooks.NEEDLES_KIT && this.nenType != Combat.NEN_MANIPULATION) {
            message = "\u00a7cYou must be a manipulator to use this!";
        }
        if (kitId == ExtrasHooks.PAPER_KIT && this.nenType != Combat.NEN_MANIPULATION) {
            message = "\u00a7cYou must be a manipulator to use this!";
        }
        if (kitId == ExtrasHooks.BLACKVOICE_KIT && this.nenType != Combat.NEN_MANIPULATION) {
            message = "\u00a7cYou must be a manipulator to use this!";
        }
        if (kitId == ExtrasHooks.HAKOWARE_KIT && this.nenType != Combat.NEN_CONJURATION) {
            message = "\u00a7cYou must be a conjurer to use this!";
        }
        if (kitId == net.hxhadventure.addon.LightningAura.KIT && this.nenType != Combat.NEN_TRANSMUTATION) {
            message = "\u00a7cYou must be a transmuter to use this!";
        }
        if (kitId == net.hxhadventure.addon.PainPacker.KIT && this.nenType != Combat.NEN_TRANSMUTATION) {
            message = "\u00a7cYou must be a transmuter to use this!";
        }
        if (kitId == net.hxhadventure.addon.MagicalEsthetician.KIT && this.nenType != Combat.NEN_TRANSMUTATION) {
            message = "\u00a7cYou must be a transmuter to use this!";
        }
        if (kitId == net.hxhadventure.addon.SmokeManipulation.KIT && this.nenType != Combat.NEN_MANIPULATION) {
            message = "\u00a7cYou must be a manipulator to use this!";
        }
        if (kitId == net.hxhadventure.addon.LittleFlower.KIT && this.nenType != Combat.NEN_CONJURATION) {
            message = "\u00a7cYou must be a conjurer to use this!";
        }
        if (kitId == net.hxhadventure.addon.Blinky.KIT && this.nenType != Combat.NEN_CONJURATION) {
            message = "\u00a7cYou must be a conjurer to use this!";
        }
        if (kitId == net.hxhadventure.addon.CrazySlots.KIT && this.nenType != Combat.NEN_CONJURATION) {
            message = "\u00a7cYou must be a conjurer to use this!";
        }
        if (kitId == net.hxhadventure.addon.NenStitches.KIT && this.nenType != Combat.NEN_TRANSMUTATION) {
            message = "\u00a7cYou must be a transmuter to use this!";
        }
        if (message == null) return;
        if (!this.player.level().isClientSide) this.player.sendSystemMessage(Component.literal(message));
        cir.setReturnValue(false);
    }

    /**
     * A Chimera Ant (reborn through the staff of Crazy Slots) has 40 health as its base instead of 20; the Hatsu level bonus is added on top,
     * as for everyone. Replaces the normal calculation for them.
     */
    @Inject(method = "updatePlayerMaxHealth", at = @At("HEAD"), cancellable = true, remap = false)
    private void hxh$chimeraHealth(CallbackInfo ci) {
        if (this.player == null || this.player.level().isClientSide || !net.hxhadventure.addon.CrazySlots.isChimeraAnt(this.player)) return;
        net.minecraft.world.entity.ai.attributes.AttributeInstance a = this.player.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH);
        if (a != null) {
            double target = net.hxhadventure.addon.CrazySlotsTuning.CHIMERA_BASE_HEALTH;   // the level bonus is a Health Boost effect, as for everyone
            if (a.getBaseValue() != target) {
                a.setBaseValue(target);
                if (this.player.getHealth() > this.player.getMaxHealth()) this.player.setHealth(this.player.getMaxHealth());
            }
        }
        net.hxhadventure.abilities.Combat.applyHealthBoost(this.player, net.hxhadventure.abilities.Combat.bonusHealthForLevel(this.hatsuLevel));
        ci.cancel();
    }

    /** Backstop for Chain Jail: nothing may set Ten or Ren active on a chained player, whatever code path asks. */
    @Inject(method = "setTenActive", at = @At("HEAD"), cancellable = true, remap = false)
    private void hxh$jailBlocksTenFlag(boolean active, CallbackInfo ci) {
        if (active && ExtrasHooks.nenBlocked(this.player)) ci.cancel();
    }

    @Inject(method = "setAuraActive", at = @At("HEAD"), cancellable = true, remap = false)
    private void hxh$jailBlocksRenFlag(boolean active, CallbackInfo ci) {
        if (active && ExtrasHooks.renBlocked(this.player)) ci.cancel();
    }
}
