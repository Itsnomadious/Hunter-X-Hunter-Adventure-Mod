package net.hxhadventure.addon;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.function.Predicate;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.client.ChainFx;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketChainFx;
import net.hxhadventure.addon.network.PacketChainMark;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Kurapika's chains: Dowsing Chain (ranged swinging attack), Holy Chain (heal), Chain Jail (root + forced Zetsu).
 * Hatsu kit 8: rolled by Water Divination for Conjurers and Specialists. Particle-drawn, so no models or textures are needed.
 */
public final class ChainManager {
    private ChainManager() {}

    // ---- tuning ----
    /** The Hatsu kit id that grants the chains (rolled by Water Divination, or /hxh set skill chains). */
    public static final int CHAINS_KIT = 8;
    public static final int SWEEP_MIN_LEVEL = 10;
    public static final int HOLY_MIN_LEVEL = 15;
    public static final int JAIL_MIN_LEVEL = 20;
    private static final float SWEEP_COST = 100f, HOLY_COST = 150f, JAIL_COST = 300f, JAIL_UPKEEP = 15f;
    private static final int SWEEP_CD = 30, HOLY_CD = 100, JAIL_CD = 400;
    /** Chain Jail holds for one second at base: only Conditions, Limitations and Vows (or Emperor Time) make it last longer. */
    private static final int JAIL_BASE_TICKS = 20;
    /**
     * A user who has sworn that Chain Jail is only for the Phantom Troupe (the Condition, or the Vow that kills them otherwise) holds a
     * Phantom Troupe member for this long (5 minutes), if that is longer than the jail would be anyway. The energy upkeep still applies.
     */
    private static final int JAIL_TROUPE_TICKS = 5 * 60 * 20;
    /** Dowsing Chain: the swing (left to right; this is when it hurts) and then the curl and reel back into the hand (visual only). */
    private static final int SWEEP_TICKS = 6;
    private static final int SWEEP_RETRACT_TICKS = 8; // curl, then reel in; keep equal to ChainRope.RETRACT_TICKS
    private static final double SWEEP_HALF_ARC = Math.toRadians(70);
    /** Holy Chain's visual: wind on, hold with the cross glowing, then reel back in (heal itself is instant). */
    private static final int HOLY_FX_TICKS = 30;
    /** Chain Jail on someone a Dowsing Chain marked: no aiming needed within this many blocks. */
    public static final double MARK_JAIL_RANGE = 15.0;
    /** How many enemies one caster can have marked at once (the oldest mark goes first). */
    private static final int MARK_MAX = 5;

    private static final Map<Player, State> STATES = new WeakHashMap<>();
    /** victim UUID -> caster UUID, for quick "is jailed" lookups from any code. */
    private static final Map<UUID, UUID> JAILED = new java.util.concurrent.ConcurrentHashMap<>();
    /** marked victim UUID -> who marked them (see the Dowsing Chain marks section). */
    private static final Map<UUID, Mark> MARKED = new java.util.concurrent.ConcurrentHashMap<>();

    private static final class State {
        int sweepCd, holyCd, jailCd;
        int sweepTick = -1; // -1 = idle
        Vec3 sweepDir = Vec3.ZERO;   // where the caster looked, pitch included
        Vec3 sweepSide = Vec3.ZERO;  // horizontal, perpendicular to sweepDir: the way the swing travels
        double sweepSign = 1;        // -1 when the swing is mirrored (comes in from the right)
        final Set<Integer> sweepHit = new HashSet<>();
        UUID jailTarget;
        /** Holy Chain is being held (see the Holy Chain section). */
        boolean holyOn, zDown;
        UUID holyTarget;
        int holyTick;
        int jailTicks;
        /** The current jail came from a Dowsing Chain mark: nothing about it is shown or told to the victim. */
        boolean jailSecret;
        /** Enemies wrapped in an invisible chain by a Dowsing Chain hit made while In was on (oldest first). */
        final Set<UUID> marks = new LinkedHashSet<>();
    }

    private static State state(Player p) {
        return STATES.computeIfAbsent(p, k -> new State());
    }

    /** An NPC (Kurapika) puts a victim in / takes it out of Chain Jail: the same lookup players' code uses (isJailed) then sees it. */
    public static void npcJail(UUID victim, UUID caster) {
        JAILED.put(victim, caster);
    }

    public static void npcRelease(UUID victim) {
        JAILED.remove(victim);
    }

    public static boolean isJailed(Entity e) {
        return e != null && JAILED.containsKey(e.getUUID());
    }

    /** True while this player is holding someone in Chain Jail. */
    public static boolean isJailing(Player p) {
        State s = p == null ? null : STATES.get(p);
        return s != null && s.jailTarget != null;
    }

    /** While Chain Jail is held, no other chain ability may be used until it ends or is released. Returns true to refuse. */
    private static boolean jailLock(ServerPlayer sp) {
        if (!isJailing(sp)) return false;
        sp.displayClientMessage(Component.literal("\u00a7cChain Jail is active: release it first"), true);
        return true;
    }

    /** Swings the right arm so the first-person hand and other players' views move with the cast. */
    private static void castSwing(ServerPlayer sp) {
        sp.swing(InteractionHand.MAIN_HAND, true);
    }

    public static boolean canUseChains(Combat c) {
        return c.getCurrentKit() == CHAINS_KIT;
    }

    private static boolean gate(ServerPlayer sp, Combat c, int minLevel, String name) {
        if (!canUseChains(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not the Chains"), true);
            return false;
        }
        if (c.getHatsuLevel() < minLevel) {
            sp.displayClientMessage(Component.literal("\u00a7c" + name + " unlocks at Level " + minLevel), true);
            return false;
        }
        return true;
    }

    /** Same action-bar style as the base mod's "is recovering" messages. Returns true while on cooldown. */
    public static boolean onCooldown(ServerPlayer sp, String name, int ticksLeft) {
        if (ticksLeft <= 0 || sp.isCreative()) return false; // creative: no cooldowns
        sp.displayClientMessage(Component.literal("\u00a7c" + name + " is recovering (" + formatSeconds(ticksLeft) + ")"), true);
        return true;
    }

    /** Tell the player's HUD that a cooldown has started so it can be listed in the bottom right until it ends. */
    public static void startCooldown(ServerPlayer sp, String name, int ticks) {
        if (ticks <= 0 || sp.isCreative()) return; // creative: no cooldowns
        AddonNetwork.sendToPlayer(new net.hxhadventure.addon.network.PacketCooldown(name, ticks), sp);
    }

    /** Wipes every cooldown on the player's HUD (death, login). */
    public static void clearCooldowns(ServerPlayer sp) {
        AddonNetwork.sendToPlayer(net.hxhadventure.addon.network.PacketCooldown.clearAll(), sp);
    }

    public static String formatSeconds(int ticks) {
        return String.format(java.util.Locale.ROOT, "%.1fs", ticks / 20.0);
    }

    private static boolean pay(ServerPlayer sp, Combat c, float cost) {
        if (c.getCurrentEnergy() < cost) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return false;
        }
        c.consumeEnergy(cost);
        return true;
    }

    // ---------------- Dowsing Chain (ability id chain_sweep) ----------------
    public static void sweep(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !gate(sp, c, SWEEP_MIN_LEVEL, "Dowsing Chain")) return;
        if (jailLock(sp)) return;
        State s = state(sp);
        if (s.sweepTick >= 0) return;
        if (onCooldown(sp, "Dowsing Chain", s.sweepCd)) return;
        if (isJailed(sp)) return;
        if (!pay(sp, c, SWEEP_COST)) return;
        s.sweepCd = SWEEP_CD;
        startCooldown(sp, "Dowsing Chain", SWEEP_CD);
        castSwing(sp);
        s.sweepTick = 0;
        s.sweepHit.clear();
        s.sweepDir = sp.getLookAngle().normalize();                    // the swing is made at the height the caster is looking
        Vec3 flat = new Vec3(-s.sweepDir.z, 0, s.sweepDir.x);
        if (flat.lengthSqr() < 1e-6) flat = new Vec3(1, 0, 0);          // looking straight up or down
        s.sweepSide = flat.normalize();
        s.sweepSign = sp.getRandom().nextBoolean() ? 1 : -1;             // sometimes it comes in from the right instead
        fx(sp, ChainFx.Kind.SWEEP, 0, SWEEP_TICKS + SWEEP_RETRACT_TICKS, (float) s.sweepDir.x, (float) s.sweepDir.y, (float) s.sweepDir.z, (float) s.sweepSign, (float) sweepRange(c));
        playSound(sp, SoundEvents.CHAIN_PLACE, 1.0f, 1.3f);
    }

    private static double sweepRange(Combat c) {
        return Math.min(14.0, 8.0 + c.getHatsuLevel() * 0.1);
    }

    private static float sweepDamage(ServerPlayer sp, Combat c) {
        return (6.0f + c.getHatsuLevel() * 0.25f) * boost(sp) * Vows.power(sp, ChainAbilities.SWEEP);
    }

    /** Angle of the ball (from the cast direction, negative = left) at a point of the swing; same curve the client draws. */
    private static double sweepAngleAt(double tick) {
        double x = Math.max(0.0, Math.min(1.0, tick / SWEEP_TICKS));
        return -SWEEP_HALF_ARC + 2 * SWEEP_HALF_ARC * (0.5 - 0.5 * Math.cos(Math.PI * x));
    }

    private static void tickSweep(ServerPlayer sp, Combat c, State s) {
        if (s.sweepTick < 0 || !(sp.level() instanceof ServerLevel level)) return;
        // the ball sweeps from the left to the right: everything it passed over this tick is hit once
        double a0 = sweepAngleAt(s.sweepTick), a1 = sweepAngleAt(s.sweepTick + 1);
        double out = Math.min(1.0, 0.15 + (s.sweepTick + 1) / 2.5);
        double range = sweepRange(c) * (1 - (1 - out) * (1 - out)); // the chain is still unfurling in the first ticks
        // the swing follows where the caster is looking while it plays
        s.sweepDir = sp.getLookAngle().normalize();
        Vec3 flat = new Vec3(-s.sweepDir.z, 0, s.sweepDir.x);
        s.sweepSide = flat.lengthSqr() < 1e-6 ? s.sweepSide : flat.normalize();
        double am = (a0 + a1) * 0.5;
        Vec3 side = s.sweepSide.scale(s.sweepSign);
        Vec3 dir = s.sweepDir.scale(Math.cos(am)).add(side.scale(Math.sin(am)));
        Vec3 origin = sp.position().add(0, sp.getBbHeight() * 0.6, 0);
        Vec3 normal = s.sweepDir.cross(side);                       // the swing's plane is tilted to where the caster looked

        AABB box = sp.getBoundingBox().inflate(range, range, range);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (e == sp || !e.isAlive() || s.sweepHit.contains(e.getId()) || AllianceUtils.isAlly(e, sp)) continue;
            Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(origin);
            double along = to.dot(s.sweepDir), across = to.dot(side);
            double dist = Math.sqrt(along * along + across * across);
            if (dist > range) continue;
            if (Math.abs(to.dot(normal)) > 1.3 + e.getBbHeight() * 0.5) continue; // above or below the swing
            double a = Math.atan2(across, along);
            double margin = 0.06 + Math.atan2(e.getBbWidth() * 0.5, Math.max(dist, 0.5));
            if (a < a0 - margin || a > a1 + margin) continue;
            s.sweepHit.add(e.getId());
            Vows.hatsuHurt(e, level.damageSources().playerAttack(sp), sweepDamage(sp, c));
            if (e.isAlive() && inActive(sp)) mark(sp, s, e);
            Vec3 push = dir.scale(0.4).add(0, 0.15, 0);
            e.push(push.x, push.y, push.z);
            e.hurtMarked = true;
            level.sendParticles(ParticleTypes.CRIT, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 8, 0.3, 0.3, 0.3, 0.1);
        }
        if (++s.sweepTick >= SWEEP_TICKS) {
            s.sweepTick = -1;
            playSound(sp, SoundEvents.CHAIN_HIT, 0.9f, 1.5f); // the chain is reeled back in
            // Vow: "If Dowsing Chain hits no one, I die"
            if (s.sweepHit.isEmpty() && Vows.has(sp, Vows.SWEEP_MISS_VOW)) Vows.breakVow(sp, "Dowsing Chain hit no one");
        }
    }

    // ---------------- Holy Chain (a hold skill) ----------------
    /** While Holy Chain is held it heals this much every HOLY_PULSE ticks. */
    private static final float HOLY_HEAL = 1.0f;
    private static final int HOLY_PULSE = 20;
    /** Energy per pulse while held (0 = hold as long as you like for free). */
    private static final float HOLY_UPKEEP = 0f;
    /** How far the chained ally may get before the chain lets go. */
    private static final double HOLY_BREAK_RANGE = 20.0;
    /** Pause after letting go before it can be used again. */
    private static final int HOLY_RELEASE_CD = 20;
    /** The visual starts this long and is cut short on release. */
    private static final int HOLY_FX_MAX = 20 * 60 * 30;

    public static void holyChain(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !gate(sp, c, HOLY_MIN_LEVEL, "Holy Chain")) return;
        if (jailLock(sp)) return;
        State s = state(sp);
        if (isJailed(sp) || !(sp.level() instanceof ServerLevel level)) return;
        if (s.holyOn) return; // already held
        if (onCooldown(sp, "Holy Chain", s.holyCd)) return;

        LivingEntity target = sp;
        Entity looked = rayEntity(sp, 14.0, e -> e instanceof LivingEntity le && le != sp && AllianceUtils.isAlly(le, sp));
        if (looked instanceof LivingEntity le) target = le;
        if (target == sp) {
            if (Vows.has(sp, Vows.HOLY_NO_SELF)) {
                sp.displayClientMessage(Component.literal("\u00a7cHoly Chain can never be used on myself: look at an ally"), true);
                return;
            }
            if (Vows.has(sp, Vows.HOLY_SELF_VOW)) {
                Vows.breakVow(sp, "I used Holy Chain on myself");
                return;
            }
        }
        s.holyOn = true;
        s.holyTarget = target.getUUID();
        s.holyTick = 0;
        s.zDown = true; // it is started by pressing Z; letting go ends it
        castSwing(sp);
        fx(sp, ChainFx.Kind.HOLY, target.getId(), HOLY_FX_MAX, 0, 0, 0);
        playSound(sp, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0f, 1.0f);
        sp.displayClientMessage(Component.literal("\u00a76Holy Chain: " + (target == sp ? "self" : target.getName().getString()) + " (hold Z)"), true);
    }

    /** From PacketZHold: Z went down or up. Letting go ends Holy Chain. */
    public static void setZHeld(ServerPlayer sp, boolean held) {
        State s = state(sp);
        s.zDown = held;
    }

    private static void tickHoly(ServerPlayer sp, Combat c, State s) {
        if (!s.holyOn) return;
        if (!(sp.level() instanceof ServerLevel level)) { endHoly(sp, s, null); return; }
        Entity ent = level.getEntity(s.holyTarget);
        if (!s.zDown) { endHoly(sp, s, null); return; }
        if (!(ent instanceof LivingEntity target) || !target.isAlive() || target.level() != level
            || (target != sp && target.distanceToSqr(sp) > HOLY_BREAK_RANGE * HOLY_BREAK_RANGE) || isJailed(sp)) {
            endHoly(sp, s, "\u00a77Holy Chain released");
            return;
        }
        if (++s.holyTick % HOLY_PULSE == 0) {
            if (HOLY_UPKEEP > 0) {
                if (c.getCurrentEnergy() < HOLY_UPKEEP) { endHoly(sp, s, "\u00a7cEnergy depleted! Holy Chain released."); return; }
                c.consumeEnergy(HOLY_UPKEEP);
            }
            target.heal(HOLY_HEAL);
            level.sendParticles(ParticleTypes.HEART, target.getX(), target.getY() + target.getBbHeight() + 0.3, target.getZ(), 1, 0.3, 0.2, 0.3, 0.0);
        }
    }

    private static void endHoly(ServerPlayer sp, State s, String msg) {
        if (!s.holyOn) return;
        s.holyOn = false;
        s.holyTarget = null;
        s.holyCd = HOLY_RELEASE_CD;
        startCooldown(sp, "Holy Chain", HOLY_RELEASE_CD);
        fx(sp, ChainFx.Kind.HOLY_END, 0, 0, 0, 0, 0);
        if (msg != null) sp.displayClientMessage(Component.literal(msg), true);
    }

    // ---------------- Chain Jail ----------------
    public static void chainJail(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !gate(sp, c, JAIL_MIN_LEVEL, "Chain Jail")) return;
        State s = state(sp);
        if (!(sp.level() instanceof ServerLevel level) || isJailed(sp)) return;
        if (s.jailTarget != null) { // pressing again releases
            releaseJail(sp, s, "\u00a77Chain Jail released");
            return;
        }
        if (onCooldown(sp, "Chain Jail", s.jailCd)) return;
        Entity hit = rayEntity(sp, 18.0, e -> e instanceof LivingEntity le && le != sp && !AllianceUtils.isAlly(le, sp));
        // nobody in the crosshair: an enemy a Dowsing Chain marked (while In was on) within reach is chained without aiming
        if (!(hit instanceof LivingEntity)) hit = markedTarget(sp, level, s);
        if (!(hit instanceof LivingEntity victim)) {
            sp.displayClientMessage(Component.literal(s.marks.isEmpty() ? "\u00a7cNo target in range"
                : "\u00a7cNo target in range (marked enemies are beyond " + (int) MARK_JAIL_RANGE + " blocks)"), true);
            return;
        }
        if (!Vows.isTroupe(victim)) {
            if (Vows.has(sp, Vows.JAIL_TROUPE_VOW)) {
                Vows.breakVow(sp, "I used Chain Jail on someone who is not in the Phantom Troupe");
                return;
            }
            if (Vows.has(sp, Vows.JAIL_TROUPE)) {
                sp.displayClientMessage(Component.literal("\u00a7cChain Jail can only be used on members of the Phantom Troupe"), true);
                return;
            }
        }
        if (!pay(sp, c, JAIL_COST)) return;
        castSwing(sp);
        s.jailTarget = victim.getUUID();
        s.jailTicks = Math.max(1, (int) (JAIL_BASE_TICKS * boost(sp) * Vows.power(sp, ChainAbilities.JAIL)));
        if (Vows.isTroupe(victim) && (Vows.has(sp, Vows.JAIL_TROUPE) || Vows.has(sp, Vows.JAIL_TROUPE_VOW))) {
            s.jailTicks = Math.max(s.jailTicks, JAIL_TROUPE_TICKS); // the Phantom Troupe oath: 5 minutes
        }
        JAILED.put(victim.getUUID(), sp.getUUID());
        boolean secret = MARKED.containsKey(victim.getUUID());
        s.jailSecret = secret;
        unmark(victim.getUUID()); // the hidden chain becomes the jail (and stays secret)
        HatsuEffects.apply(victim, 40, !secret); // Forced Zetsu: no Ren/Ten/aura for the whole jail
        fx(sp, ChainFx.Kind.JAIL, victim.getId(), s.jailTicks, 0, 0, 0, secret ? 2f : 1f, 0);
        if (!secret) {
            playSound(sp, SoundEvents.CHAIN_PLACE, 1.2f, 0.7f);
            playSound(sp, SoundEvents.ANVIL_LAND, 0.5f, 1.6f);
        }
        sp.displayClientMessage(Component.literal("\u00a77Chain Jail: " + victim.getName().getString()), true);

        if (victim instanceof ServerPlayer vp) {
            Combat vc = Combat.get(vp);
            if (vc != null && vc.hasNenUnlocked()) {
                if (secret) {
                    NenAddonData.get(vp).setZetsuQuiet(vp);
                } else {
                    NenAddonData.get(vp).setZetsu(vp, true, null);
                    vp.displayClientMessage(Component.literal("\u00a77Chain Jail: your aura is sealed (Zetsu)"), true);
                }
            }
        }
    }

    private static void releaseJail(ServerPlayer sp, State s, String msg) {
        if (s.jailTarget != null) {
            fx(sp, ChainFx.Kind.JAIL_END, 0, 0, 0, 0, 0);
            if (sp.level() instanceof ServerLevel l && l.getEntity(s.jailTarget) instanceof LivingEntity v) HatsuEffects.remove(v);
            JAILED.remove(s.jailTarget);
            s.jailTarget = null;
            s.jailTicks = 0;
            s.jailCd = JAIL_CD;
            startCooldown(sp, "Chain Jail", JAIL_CD);
            if (msg != null) sp.displayClientMessage(Component.literal(msg), true);
        }
    }

    private static void tickJail(ServerPlayer sp, Combat c, State s) {
        if (s.jailTarget == null || !(sp.level() instanceof ServerLevel level)) return;
        Entity ent = level.getEntity(s.jailTarget);
        if (!(ent instanceof LivingEntity victim) || !victim.isAlive() || victim.level() != level
            || victim.distanceToSqr(sp) > 30 * 30 || --s.jailTicks <= 0) {
            releaseJail(sp, s, "\u00a77Chain Jail broken");
            return;
        }
        if (sp.tickCount % 20 == 0) {
            if (c.getCurrentEnergy() < JAIL_UPKEEP) {
                releaseJail(sp, s, "\u00a7cEnergy depleted! Chain Jail released.");
                return;
            }
            c.consumeEnergy(JAIL_UPKEEP);
        }
        if (sp.tickCount % 10 == 0) HatsuEffects.apply(victim, 40, !s.jailSecret); // keep Forced Zetsu up while chained
        // root: no walking, no jumping, no targeting. Velocity is left alone on purpose, so a chained victim still falls
        // and can be knocked back instead of hovering in place.
        victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 6, false, false, false));
        victim.addEffect(new MobEffectInstance(MobEffects.JUMP, 5, 128, false, false, false));
        if (victim instanceof Mob mob) {
            mob.setTarget(null);
            mob.getNavigation().stop();
        }
    }

    // ---------------- Dowsing Chain marks ----------------
    private static final class Mark {
        final ServerPlayer owner;
        final int victimId;

        Mark(ServerPlayer owner, int victimId) {
            this.owner = owner;
            this.victimId = victimId;
        }
    }

    private static boolean inActive(ServerPlayer sp) {
        NenAddonData d = NenAddonData.peek(sp);
        return d != null && d.in;
    }

    /** A Dowsing Chain hit while In is on wraps an invisible chain round the enemy (visible to the owner and to Gyo). */
    private static void mark(ServerPlayer sp, State s, LivingEntity victim) {
        UUID id = victim.getUUID();
        if (s.marks.contains(id)) return; // already wrapped
        Mark old = MARKED.put(id, new Mark(sp, victim.getId()));
        if (old != null && old.owner != sp) state(old.owner).marks.remove(id); // someone else's mark on them is replaced
        s.marks.add(id);
        while (s.marks.size() > MARK_MAX) unmark(s.marks.iterator().next());
        PacketChainMark msg = new PacketChainMark(victim.getId(), sp.getId(), true);
        AddonNetwork.sendToTracking(msg, victim);
        AddonNetwork.sendToPlayer(msg, sp);
        sp.displayClientMessage(Component.literal("\u00a77Chain wrapped round " + victim.getName().getString()
            + " (Chain Jail reaches them within " + (int) MARK_JAIL_RANGE + " blocks)"), true);
    }

    /** Takes a mark off (used, victim gone, or the owner is gone) and tells the clients. */
    private static void unmark(UUID victimId) {
        Mark m = MARKED.remove(victimId);
        if (m == null) return;
        state(m.owner).marks.remove(victimId);
        PacketChainMark msg = new PacketChainMark(m.victimId, m.owner.getId(), false);
        AddonNetwork.sendToPlayer(msg, m.owner);
        if (m.owner.level() instanceof ServerLevel lvl && lvl.getEntity(victimId) != null) AddonNetwork.sendToTracking(msg, lvl.getEntity(victimId));
    }

    /** Called when a player starts tracking an entity: if it is marked, they learn of it (the client decides who may see it). */
    public static void sendMarkTo(Entity target, ServerPlayer viewer) {
        Mark m = target == null ? null : MARKED.get(target.getUUID());
        if (m != null) AddonNetwork.sendToPlayer(new PacketChainMark(target.getId(), m.owner.getId(), true), viewer);
    }

    /** The marked enemy within reach that the caster is looking nearest to, or null. */
    private static LivingEntity markedTarget(ServerPlayer sp, ServerLevel level, State s) {
        Vec3 eye = sp.getEyePosition(), look = sp.getLookAngle();
        LivingEntity best = null;
        double bestDot = -2;
        for (UUID id : s.marks) {
            if (!(level.getEntity(id) instanceof LivingEntity v) || !v.isAlive() || v == sp || AllianceUtils.isAlly(v, sp)) continue;
            if (v.distanceTo(sp) > MARK_JAIL_RANGE) continue;
            Vec3 to = v.position().add(0, v.getBbHeight() * 0.5, 0).subtract(eye);
            double len = to.length();
            double dot = len < 1e-6 ? 1.0 : to.scale(1.0 / len).dot(look);
            if (dot > bestDot) { bestDot = dot; best = v; }
        }
        return best;
    }

    /** Drops marks whose victim has died, left the level or logged out. */
    private static void tickMarks(ServerPlayer sp, State s) {
        if (s.marks.isEmpty() || sp.tickCount % 20 != 0 || !(sp.level() instanceof ServerLevel level)) return;
        for (UUID id : new HashSet<>(s.marks)) {
            if (!(level.getEntity(id) instanceof LivingEntity v) || !v.isAlive()) unmark(id);
        }
    }

    // ---------------- Emperor Time ----------------
    public static void emperorTime(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !gate(sp, c, Tuning.EMPEROR_MIN_LEVEL, "Emperor Time")) return;
        NenAddonData.get(sp).toggleEmperor(sp, c);
    }

    private static float boost(ServerPlayer sp) {
        NenAddonData d = NenAddonData.peek(sp);
        return d != null && d.emperor ? Tuning.EMPEROR_CHAIN_BOOST : 1.0f;
    }

    // ---------------- per-tick / lifecycle ----------------
    public static void tick(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        State s = state(sp);
        if (s.sweepCd > 0) s.sweepCd--;
        if (s.holyCd > 0) s.holyCd--;
        if (s.jailCd > 0) s.jailCd--;
        tickSweep(sp, c, s);
        tickJail(sp, c, s);
        tickMarks(sp, s);
        tickHoly(sp, c, s);
    }

    /** Release any jail this player holds (death, logout). */
    public static void clear(Player p) {
        State s = STATES.get(p);
        if (s != null && s.holyOn && p instanceof ServerPlayer hsp) endHoly(hsp, s, null);
        if (s != null && s.jailTarget != null) {
            if (p instanceof ServerPlayer sp) fx(sp, ChainFx.Kind.JAIL_END, 0, 0, 0, 0, 0);
            if (p.level() instanceof ServerLevel l && l.getEntity(s.jailTarget) instanceof LivingEntity v) HatsuEffects.remove(v);
            JAILED.remove(s.jailTarget);
            s.jailTarget = null;
        }
        JAILED.remove(p.getUUID());
        if (s != null) for (UUID id : new HashSet<>(s.marks)) unmark(id); // death / logout: the chains round their enemies fall away
    }

    // ---------------- helpers ----------------
    private static Vec3 rotateY(Vec3 v, double ang) {
        double cos = Math.cos(ang), sin = Math.sin(ang);
        return new Vec3(v.x * cos - v.z * sin, v.y, v.x * sin + v.z * cos);
    }

    public static Entity rayEntity(ServerPlayer sp, double range, Predicate<Entity> filter) {
        Vec3 start = sp.getEyePosition();
        Vec3 end = start.add(sp.getLookAngle().scale(range));
        HitResult block = sp.level().clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        if (block.getType() != HitResult.Type.MISS) end = block.getLocation();
        AABB box = sp.getBoundingBox().expandTowards(end.subtract(start)).inflate(1.0);
        // the creature you are wearing (Black Voice) sits exactly where you stand: without this every ray started inside it and hit it first
        Predicate<Entity> notWorn = x -> !BlackVoice.isWornBy(x, sp) && filter.test(x);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(sp.level(), sp, start, end, box, notWorn);
        return hit != null ? hit.getEntity() : null;
    }

    private static void fx(ServerPlayer sp, ChainFx.Kind kind, int target, int duration, float dx, float dz, float range) {
        fx(sp, kind, target, duration, dx, 0, dz, 1, range);
    }

    private static void fx(ServerPlayer sp, ChainFx.Kind kind, int target, int duration, float dx, float dy, float dz, float side, float range) {
        AddonNetwork.sendToTrackingAndSelf(new PacketChainFx(kind, sp.getId(), target, duration, dx, dy, dz, side, range), sp);
    }

    private static void playSound(ServerPlayer sp, SoundEvent ev, float vol, float pitch) {
        sp.level().playSound(null, sp.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }
}
