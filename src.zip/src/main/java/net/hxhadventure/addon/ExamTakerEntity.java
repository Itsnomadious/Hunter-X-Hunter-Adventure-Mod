package net.hxhadventure.addon;

import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * A test taker of the Hunter Exam's second test (see {@link ExamBattle}). As strong as a Minecraft zombie (20 health, 3 damage, the same
 * speed, armour and follow range) and wearing one of the test taker skins or one of the five Bystander skins. It attacks the nearest other test
 * taker or player, and anything that hurts it. It drops nothing, is not saved, and fades if the test it belongs to is no longer running.
 */
public class ExamTakerEntity extends PathfinderMob implements ExamContestant {
    /** textures/entity/exam_taker/taker_00.png ... taker_40.png. */
    public static final int TAKER_SKINS = 41;
    /** Every skin it can wear: the test taker skins, then the Bystander skins (bystander_0 ... bystander_4). */
    public static final int SKINS = TAKER_SKINS + BystanderEntity.SKINS;

    /** Test taker skins that use slim (Alex) arms. */
    private static final Set<Integer> SLIM_TAKERS = Set.of(1, 6, 11, 12, 13, 14, 19, 26, 28, 29, 39);

    private static final EntityDataAccessor<Integer> SKIN = SynchedEntityData.defineId(ExamTakerEntity.class, EntityDataSerializers.INT);

    private UUID battle;
    private int orphanTicks;

    public ExamTakerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    /** A Minecraft zombie's numbers. */
    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 20.0)
            .add(Attributes.MOVEMENT_SPEED, 0.23)
            .add(Attributes.ATTACK_DAMAGE, 3.0)
            .add(Attributes.FOLLOW_RANGE, 35.0)
            .add(Attributes.ARMOR, 2.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(SKIN, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new ExamFightGoal(this));
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    // ------------------------------------------------------------------ skin

    public int skin() {
        return Math.floorMod(this.entityData.get(SKIN), SKINS);
    }

    @Override
    public void setSkin(int skin) {
        this.entityData.set(SKIN, Math.floorMod(skin, SKINS));
    }

    /** Texture name under textures/entity/ (without .png) for a skin index. */
    public static String textureName(int skin) {
        return skin < TAKER_SKINS ? String.format("exam_taker/taker_%02d", skin) : "bystander_" + (skin - TAKER_SKINS);
    }

    public static boolean isSlim(int skin) {
        return skin < TAKER_SKINS ? SLIM_TAKERS.contains(skin) : (skin - TAKER_SKINS) >= 2; // bystander_2 to bystander_4 are slim
    }

    // ------------------------------------------------------------------ battle

    @Override
    public void setBattle(UUID player) {
        this.battle = player;
    }

    @Override
    public UUID battleId() {
        return battle;
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && battle != null && isDeadOrDying()) ExamBattle.onTakerDown(battle, getUUID());
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) return;
        // the test is over (or never was: summoned by hand with no battle behind it only stays when there is no owner at all)
        if (battle != null && !ExamBattle.isActive(battle) && ++orphanTicks > 40) fade(sl);
    }

    @Override
    public void fade(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.9, getZ(), 12, 0.3, 0.5, 0.3, 0.02);
        discard();
    }

    // ------------------------------------------------------------------ misc

    @Override
    protected boolean shouldDropLoot() {
        return false;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }
}
