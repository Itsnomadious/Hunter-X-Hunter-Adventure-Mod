package net.hxhadventure.addon;

import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.TickEvent;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks for {@link BlackVoice}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class BlackVoiceEvents {
    private BlackVoiceEvents() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) BlackVoice.serverTick(ServerLifecycleHooks.getCurrentServer());
    }

    /** Right-click on a creature with the phone: plant an antenna. Runs before a villager's trade screen would open. */
    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (e.getLevel().isClientSide()) return;
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        boolean used = BlackVoice.isNenlessBody(sp) || (e.getHand() == InteractionHand.MAIN_HAND && BlackVoice.handleRightClick(sp, e.getTarget()));
        if (used) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    // ---- while you wear another body your hands do nothing (items, blocks), and while a needle drives you nothing you do counts ----
    @SubscribeEvent
    public static void onUseItem(PlayerInteractEvent.RightClickItem e) {
        if (!e.getLevel().isClientSide() && BlackVoice.isHandsLocked(e.getEntity())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onUseBlock(PlayerInteractEvent.RightClickBlock e) {
        if (!e.getLevel().isClientSide() && BlackVoice.isHandsLocked(e.getEntity())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onPunchBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (!e.getLevel().isClientSide() && BlackVoice.isHandsLocked(e.getEntity())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (BlackVoice.isHandsLocked(e.getPlayer())) e.setCanceled(true);
    }

    /** Inside a body, your punch is the creature's attack instead; with the needle in, your hands are not yours at all. */
    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent e) {
        if (e.getEntity().level().isClientSide() || !(e.getEntity() instanceof ServerPlayer sp)) return;
        if (BlackVoice.isAutoPilot(sp) || BlackVoice.onPossessedAttack(sp, e.getTarget())) e.setCanceled(true);
    }

    /** A hit that would kill somebody wearing a creature kills the creature instead, and they are back in their own body. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onWearerDamage(LivingDamageEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp && !sp.level().isClientSide && BlackVoice.onWearerLethal(sp, e.getSource(), e.getAmount())) {
            e.setCanceled(true);
        }
    }

    /** Wearing a creature, you have its hitbox and eye height: the camera sits where its eyes are and you fit where it fit. */
    // EntityEvent.Size is flagged for removal in newer Forge, but 1.20.1 has no replacement hook (EstheticianEvents / GonVowEvents do the same)
    @SuppressWarnings("removal")
    @SubscribeEvent
    public static void onSize(EntityEvent.Size e) {
        if (!(e.getEntity() instanceof Player p) || p.level() == null) return;
        LivingEntity body = BlackVoice.sizeBody(p);
        if (body == null) return;
        e.setNewSize(body.getDimensions(net.minecraft.world.entity.Pose.STANDING), false);
        e.setNewEyeHeight(body.getEyeHeight(net.minecraft.world.entity.Pose.STANDING));
    }

    // ---- the circle of allies ----
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        BlackVoice.onDeath(e.getEntity());
        if (e.getEntity() instanceof ServerPlayer sp) BlackVoice.onOwnerGone(sp);
    }

    /** Antenna'd mobs never pick their owner or a fellow ally as a target. */
    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent e) {
        LivingEntity t = e.getNewTarget();
        if (t == null) return;
        // the creature somebody is wearing is invisible and cannot be hurt: whatever wanted it goes for the one wearing it
        ServerPlayer wearer = BlackVoice.possessorOf(t.getUUID());
        if (wearer != null && wearer != e.getEntity()) {
            e.setNewTarget(wearer);
            return;
        }
        UUID owner = BlackVoice.controllerOf(e.getEntity().getUUID());
        if (owner == null) return;
        if (owner.equals(t.getUUID()) || owner.equals(BlackVoice.controllerOf(t.getUUID()))) e.setCanceled(true);
    }

    /** No friendly fire between an owner and what carries their antenna, or between two of them. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        Entity attacker = e.getSource().getEntity();
        if (attacker != null && BlackVoice.areAllies(e.getEntity(), attacker)) e.setCanceled(true);
    }

    /** Makes sure the phone's recipe is known (shows in the recipe book) for everybody. */
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            BlackVoice.recoverBackup(sp); // a crash while wearing a body must not leave its Level and kit on you
            sp.awardRecipesByKey(new net.minecraft.resources.ResourceLocation[] {
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("hxhadventure", "shalnark_phone") });
        }
    }

    /** After the base mod's own save handlers: the file always holds the player's real kit, Nen type, Level and energy, never a borrowed body's. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onSaveToFile(PlayerEvent.SaveToFile e) {
        if (e.getEntity() instanceof ServerPlayer sp) BlackVoice.patchSave(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) BlackVoice.onOwnerGone(sp);
    }

    /** Moving between dimensions drops you out of the borrowed body (it cannot follow). */
    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) BlackVoice.returnToBody(sp, "\u00a77The body cannot follow you between worlds");
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        BlackVoice.reset();
    }
}
