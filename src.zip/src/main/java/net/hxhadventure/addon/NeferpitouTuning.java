package net.hxhadventure.addon;

/**
 * Every number that defines the Neferpitou NPC, in one place. She is a level 500 Nen user: five times the level 100 of a Nen master like Hisoka or Chrollo (no player can get that high).
 * Her damage comes from the same pieces as a player's: the move's base damage x the spirit bonus of her level (Ken adds to it).
 */
public final class NeferpitouTuning {
    private NeferpitouTuning() {}

    // ---- levels (500 everywhere: 5x a level 100 Nen master) ----
    public static final int LEVEL = 500;
    public static final int HATSU_LEVEL = LEVEL, KO_LEVEL = LEVEL;
    /** Her aura (Ten / Ren) never goes above what a player can reach (NpcFeelTuning.PLAYER_CAP), so a matched player can always hurt her. */
    public static final int TEN_LEVEL = Math.min(NpcFeelTuning.PLAYER_CAP, LEVEL), REN_LEVEL = Math.min(NpcFeelTuning.PLAYER_CAP, LEVEL);

    // ---- body ----
    public static final double MAX_HEALTH = 2000.0;
    public static final double BASE_SPEED = 0.36;
    public static final double FOLLOW_RANGE = 80.0;
    public static final double KNOCKBACK_RESISTANCE = 0.9;
    public static final float HEAL_PER_SECOND = 5.0f;            // while Ten is up and she has not been hit for 2 s
    public static final int FOE_MEMORY_TICKS = 1200;
    public static final int AURA_COLOR_INDEX = 6;                // colour of her aura (6 = pink, the index Hisoka uses)

    // ---- aura pool ----
    public static final float AURA_POOL_MULT = 0.25f;
    public static final float EXHAUST_RESUME_FRACTION = 0.10f;
    public static final float EXHAUST_REGEN_PCT = 0.008f;
    public static final float REST_REGEN_PCT = 0.004f;
    public static final int REST_DELAY_TICKS = 100;
    public static final float BASE_REGEN = 0.5f;

    public static float tenRegenPerSecond() {
        float s = (float) Math.sqrt(HATSU_LEVEL);
        float scaled = Math.min(0.5f + HATSU_LEVEL * 0.1f * (1f + s * 0.1f), 2.0f);
        return scaled * 5.5f + Tuning.tenRegen(TEN_LEVEL);
    }

    public static float maxAura() {
        return Tuning.npcMaxNen(HATSU_LEVEL, TEN_LEVEL, REN_LEVEL) * AURA_POOL_MULT;
    }

    // ---- stances: Ten always, Ko as her fighting stance, Ken while attacking or being hit ----
    public static final int FORM_SWITCH_TICKS = 5;
    public static final int KEN_AFTER_HIT_TICKS = 40;
    public static final int KEN_AFTER_ATTACK_TICKS = 30;
    public static final float MIN_AURA_FOR_KEN = 500f;
    public static final int KO_CHARGE_TICKS = 20;                // Ko held this long makes the next hit stronger
    public static final float KO_DAMAGE_MULT = 1.5f;
    public static final float KO_DEFENCE_PENALTY = 0.10f;        // on top of Ko stripping her Ten armor, she takes this much more damage

    // ---- attacks (Combat.java's numbers x DAMAGE_MULT x spirit bonus) ----
    public static final float DAMAGE_MULT = 1.5f;
    public static final double REACH = 2.8;
    public static final int PUNCH_GAP_TICKS = 8;
    public static final float PUNCH_DAMAGE = 5.0f, PUNCH_RANGE = 1.7f;
    public static final float STRONG_DAMAGE = 15.0f, STRONG_RANGE = 2.3f;
    public static final double STRONG_KNOCKBACK = 1.6;
    public static final int STRONG_CHARGE_TICKS = 30;
    public static final int STRONG_MAX_HOLD_TICKS = 45;
    public static final int STRONG_COOLDOWN_TICKS = 80;
    public static final float BARRAGE_DAMAGE = 1.5f;
    public static final int BARRAGE_TICKS = 36;
    public static final int BARRAGE_HIT_GAP = 2;
    public static final int BARRAGE_COOLDOWN_TICKS = 50;
    public static final float ATTACK_SLOW = 0.10f, STRONG_SLOW = 0.40f, BARRAGE_SLOW = 0.30f;
    public static final int PUNCH_ANIM_TICKS = 9;
    public static final float PUNCH_WEIGHT_BARRAGE = 0.25f, PUNCH_WEIGHT_STRONG = 0.20f;

    // ---- Pounce ----
    public static final double POUNCE_MIN_RISE = 0.04;           // the leap always climbs at least this much (sine of the angle), so she lifts off the floor
    public static final double POUNCE_HOP = 0.6;                 // blocks she is lifted at the start of the leap
    public static final double POUNCE_MIN_DISTANCE = 20.0;       // only used when the target is further than this
    public static final double POUNCE_MAX_DISTANCE = 70.0;
    public static final int POUNCE_CROUCH_TICKS = 25;            // the full squat before she goes
    public static final double POUNCE_SPEED = 4.5;               // blocks per tick (90 blocks/s, was 2.2)
    /** She blasts this many blocks PAST the point where the target was, so the pounce goes through them and on, never stopping at them. */
    public static final double POUNCE_OVERSHOOT = 30.0;
    public static final int POUNCE_COOLDOWN_TICKS = 140;
    /** Base damage. x spirit bonus (about 6x with Ken) x Ko bonus. Massive: it kills almost anything that is not another level 300. */
    public static final float POUNCE_DAMAGE = 3000.0f;
    public static final double POUNCE_KNOCKBACK = 4.0;

    // ---- Doctor Blythe ----
    public static final float BLYTHE_SELF_HEALTH_FRACTION = 0.35f;
    public static final float BLYTHE_ALLY_HEALTH_FRACTION = 0.40f;
    public static final double BLYTHE_ALLY_RANGE = 24.0;
    public static final int BLYTHE_TICKS = 100;                  // heals over 5 seconds
    public static final float BLYTHE_HEAL_FRACTION = 0.60f;      // of the patient's max health
    public static final int BLYTHE_COOLDOWN_TICKS = 900;

    // ---- Terpsichora ----
    public static final float TERP_HEALTH_FRACTION = 0.70f;
    public static final int TERP_COOLDOWN_TICKS = 200;
    public static final int TERP_FLASH_TICKS = 20;               // the figure is only out for this long (1 second) when she is called...
    public static final int TERP_BUFF_TICKS = 1200;              // ...but the buffs (Tuning.TERPSI_BOOST: speed and damage) last this long (1 minute)
    public static final float REVIVE_HEALTH_FRACTION = 0.20f;    // she is raised at this much of her max health when she is killed, and the figure stays out until she dies again
    public static final float TERP_DAMAGE = 40.0f;               // x her spirit bonus
    public static final double TERP_REACH = 4.5;
    public static final int TERP_HIT_GAP_TICKS = 14;
}
