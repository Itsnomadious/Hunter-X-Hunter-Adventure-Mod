package net.hxhadventure.addon;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

/** The Hunter Exam receptionist in the lobby: welcomes you and, if you accept, sends you up to the third floor. */
public class ExamReceptionistEntity extends ExamNpcEntity {
    public ExamReceptionistEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    @Override
    public int examKind() {
        return HunterExam.KIND_RECEPTIONIST;
    }
}
