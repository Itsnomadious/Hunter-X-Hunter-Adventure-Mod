package net.hxhadventure.addon;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks for {@link IllumiNeedles}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class NeedleEvents {
    private NeedleEvents() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) IllumiNeedles.serverTick(ServerLifecycleHooks.getCurrentServer());
    }

    /** Right-click on an entity with a needle drawn: plant it. Sneak + right-click on a controlled body: pull it out. */
    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (e.getLevel().isClientSide() || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (IllumiNeedles.handleRightClick(sp, e.getTarget())) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        IllumiNeedles.onDeath(e.getEntity());
        if (e.getEntity() instanceof ServerPlayer sp) IllumiNeedles.onOwnerGone(sp);
    }

    /** Controlled bodies never pick their owner or each other as a target. */
    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent e) {
        java.util.UUID owner = IllumiNeedles.controllerOf(e.getEntity());
        if (owner == null || e.getNewTarget() == null) return;
        Entity t = e.getNewTarget();
        if (owner.equals(t.getUUID()) || owner.equals(IllumiNeedles.controllerOf(t))) e.setCanceled(true);
    }

    /** No friendly fire between an owner, their controlled bodies, and each other. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        Entity victim = e.getEntity();
        Entity attacker = e.getSource().getEntity();
        if (attacker == null) return;
        java.util.UUID vOwner = IllumiNeedles.controllerOf(victim);
        java.util.UUID aOwner = IllumiNeedles.controllerOf(attacker);
        if (vOwner != null && (vOwner.equals(attacker.getUUID()) || vOwner.equals(aOwner))) e.setCanceled(true); // owner or sibling hits one
        else if (aOwner != null && aOwner.equals(victim.getUUID())) e.setCanceled(true);                          // one hits its owner
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking e) {
        if (e.getEntity() instanceof ServerPlayer viewer) IllumiNeedles.sendTo(viewer, e.getTarget());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) IllumiNeedles.onOwnerGone(sp);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        IllumiNeedles.reset();
    }

    /** While transformed, chat and death messages use the copied name. */
    @SubscribeEvent
    public static void onNameFormat(PlayerEvent.NameFormat e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        Component copied = IllumiNeedles.displayNameOf(sp);
        if (copied != null) e.setDisplayname(copied);
    }
}
