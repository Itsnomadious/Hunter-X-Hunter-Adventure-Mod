package net.hxhadventure.addon;

import java.util.HashSet;
import java.util.Arrays;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketBlastFx;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Zeno's Aura Blast (Hatsu kit 12, Emitters): tap Z and a blast of aura leaves the open palm in a widening cone, stopping
 * at the first wall. Everything hostile in it takes solid damage and is thrown back, the ground under their feet breaks,
 * and a trail of ground along the beam is torn up. It pushes the user back a little too. Short cooldown.
 */
public final class AuraBlast {
    private AuraBlast() {}

    public static final int KIT = 12;
    public static final String ID = "aura_blast";

    private static final Map<UUID, Long> READY_AT = new ConcurrentHashMap<>();
    private static final Random RND = new Random();

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < Tuning.BLAST_MIN_LEVEL) return base;
        String[] out = Arrays.copyOf(base, base.length + 1);
        out[base.length] = ID;
        return out;
    }

    /** Radius of the cone at a distance along the beam. Shared by the server's hit test and the client's drawing. */
    public static double radiusAt(double d) {
        return 0.4 + 0.16 * d;
    }

    public static void fire(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Dragon's Head"), true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.BLAST_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cAura Blast unlocks at Level " + Tuning.BLAST_MIN_LEVEL), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        long ready = READY_AT.getOrDefault(sp.getUUID(), 0L);
        if (ChainManager.onCooldown(sp, "Aura Blast", (int) Math.max(0, ready - now))) return;
        if (c.getCurrentEnergy() < Tuning.BLAST_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.BLAST_COST);
        READY_AT.put(sp.getUUID(), now + Tuning.BLAST_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Aura Blast", Tuning.BLAST_COOLDOWN_TICKS);
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);

        // the beam leaves the right palm along the look direction and stops at the first wall
        Vec3 dir = sp.getLookAngle().normalize();
        double rad = Math.toRadians(sp.getYRot());
        Vec3 right = new Vec3(-Math.cos(rad), 0, -Math.sin(rad));
        Vec3 origin = sp.getEyePosition().add(right.scale(0.3)).add(0, -0.3, 0).add(dir.scale(0.4));
        float base = Tuning.BLAST_BASE_DAMAGE + c.getHatsuLevel() * Tuning.BLAST_DAMAGE_PER_LEVEL;
        NenAddonData d = NenAddonData.peek(sp);
        if (d != null) base *= Affinity.projectile(d.effType(c)); // emitters: +15% projectile damage
        base *= Vows.power(sp, ID);
        beam(sp, origin, dir, Tuning.BLAST_RANGE, 0.0, base, Tuning.BLAST_RECOIL, 0.4, false);
    }

    /**
     * The blast itself, shared with the 100-Type Guanyin's Aspect of Guanyin: a cone from {@code origin} along {@code dir}, stopping at the
     * first wall, hurting and throwing back everything hostile in it and tearing up the ground. {@code extraRadius} widens the cone by that
     * many blocks everywhere, {@code recoil} pushes the user back, {@code falloffAtEnd} is the share of damage lost at the far end (0.4 for
     * the normal blast), {@code golden} draws it gold instead of white.
     */
    public static void beam(ServerPlayer sp, Vec3 origin, Vec3 dir, double range, double extraRadius, float base, double recoil, double falloffAtEnd, boolean golden) {
        beam(sp, origin, dir, range, extraRadius, base, recoil, falloffAtEnd, golden, 1.0);
    }

    /** Same, with the throw multiplied by {@code knockbackMult} (1.0 = the normal blast; Aspect of Guanyin uses far more). */
    public static void beam(ServerPlayer sp, Vec3 origin, Vec3 dir, double range, double extraRadius, float base, double recoil, double falloffAtEnd, boolean golden, double knockbackMult) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        HitResult wall = level.clip(new ClipContext(origin, origin.add(dir.scale(range)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        double len = wall.getType() == HitResult.Type.MISS ? range : Math.max(1.0, wall.getLocation().distanceTo(origin));

        AddonNetwork.sendToTrackingAndSelf(new PacketBlastFx(sp.getId(), origin, dir, (float) len, (float) extraRadius, golden), sp);
        level.playSound(null, sp.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.6f, golden ? 0.6f : 0.8f);
        level.playSound(null, sp.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.0f, 1.5f);

        // hit everything hostile inside the cone
        Set<Long> broken = new HashSet<>();
        AABB box = new AABB(origin, origin.add(dir.scale(len))).inflate(radiusAt(len) + extraRadius + 1.0);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (e == sp || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, sp)) continue;
            Vec3 v = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(origin);
            double proj = v.dot(dir);
            if (proj < 0 || proj > len + 0.5) continue;
            double perp = v.subtract(dir.scale(proj)).length();
            if (perp > radiusAt(proj) + extraRadius + e.getBbWidth() * 0.5) continue;
            float falloff = (float) (1.0 - falloffAtEnd * proj / range);
            Vows.hatsuHurt(e, level.damageSources().playerAttack(sp), base * falloff);
            Vec3 push = dir.scale(Tuning.BLAST_KNOCKBACK * falloff * knockbackMult).add(0, 0.5 * Math.max(1.0, Math.sqrt(knockbackMult)), 0);
            e.push(push.x, push.y, push.z);
            e.hurtMarked = true;
            level.sendParticles(ParticleTypes.EXPLOSION, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 1, 0, 0, 0, 0);
            if (Tuning.BLAST_BREAK_GROUND) { // the ground gives way under their feet
                BlockPos feet = e.blockPosition().below();
                for (int x = -1; x <= 1; x++) {
                    for (int z = -1; z <= 1; z++) breakColumn(level, feet.getX() + x, feet.getY() + 1, feet.getZ() + z, 3, broken);
                }
            }
        }

        // a trail of torn-up ground along the beam
        if (Tuning.BLAST_BREAK_GROUND) {
            for (int t = 1; t <= (int) len && broken.size() < Tuning.BLAST_MAX_BLOCKS; t++) {
                Vec3 p = origin.add(dir.scale(t));
                int w = (int) Math.min(2, Math.ceil((radiusAt(t) + extraRadius) * 0.7));
                for (int x = -w; x <= w; x++) {
                    for (int z = -w; z <= w; z++) {
                        if (x * x + z * z > w * w + 1 || RND.nextFloat() > 0.8f) continue;
                        breakColumn(level, blockCoord(p.x) + x, blockCoord(p.y), blockCoord(p.z) + z, 4, broken);
                    }
                }
            }
        }

        // the user is pushed back by their own blast
        if (recoil > 0) {
            Vec3 dm = sp.getDeltaMovement();
            sp.setDeltaMovement(dm.x - dir.x * recoil, dm.y + 0.1, dm.z - dir.z * recoil);
            sp.connection.send(new ClientboundSetEntityMotionPacket(sp));
        }
    }

    private static int blockCoord(double v) {
        return net.minecraft.util.Mth.floor(v);
    }

    /**
     * Finds the first solid block at or below (x, topY, z) within `scan` blocks and breaks it and the block under it
     * (two layers deep), if the blast is strong enough for them.
     */
    private static void breakColumn(ServerLevel level, int x, int topY, int z, int scan, Set<Long> broken) {
        if (broken.size() >= Tuning.BLAST_MAX_BLOCKS) return;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int y = topY; y > topY - scan; y--) {
            pos.set(x, y, z);
            if (!level.isInWorldBounds(pos)) return;
            BlockState st = level.getBlockState(pos);
            if (st.isAir() || !st.getFluidState().isEmpty()) continue;
            for (int depth = 0; depth < 2; depth++) {
                pos.set(x, y - depth, z);
                BlockState s2 = level.getBlockState(pos);
                if (s2.isAir() || !s2.getFluidState().isEmpty() || s2.getDestroySpeed(level, pos) < 0
                    || s2.getBlock().getExplosionResistance() > Tuning.BLAST_BLOCK_POWER || !broken.add(pos.asLong())) continue;
                if (RND.nextFloat() < 0.05f) net.minecraft.world.level.block.Block.dropResources(s2, level, pos);
                if (RND.nextFloat() < 0.15f) {
                    level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, s2), x + 0.5, y + 1.0, z + 0.5, 4, 0.3, 0.2, 0.3, 0.05);
                }
                level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            }
            return; // only the first solid layer found
        }
    }

    public static void clear(Player p) {
        READY_AT.remove(p.getUUID());
    }
}
