package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;

import java.util.function.Supplier;
import net.hxhadventure.abilities.Combat;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * The H key: Jajanken's "I'll use everything." (and Godspeed for Lightning Aura, see below.)
 * Pressing H toggles Gon's adult form ({@link GonVow}); GonVow itself checks that
 * the player's Hatsu is Jajanken, the level, Forced Zetsu, lifespan and so on and tells them if they cannot.
 */
public final class UseEverything {
    private UseEverything() {}

    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        ResourceLocation.fromNamespaceAndPath(HxHAdventure.MOD_ID, "use_everything"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    /** The H key press (no data). */
    public static final class Press {
        public Press() {}
    }

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Setup {
        @SubscribeEvent
        public static void common(FMLCommonSetupEvent e) {
            e.enqueueWork(() -> CHANNEL.messageBuilder(Press.class, 0, NetworkDirection.PLAY_TO_SERVER)
                .encoder((Press m, FriendlyByteBuf buf) -> { })
                .decoder((FriendlyByteBuf buf) -> new Press())
                .consumerMainThread((Press m, Supplier<NetworkEvent.Context> ctx) -> {
                    ServerPlayer sender = ctx.get().getSender();
                    if (sender == null) return;
                    // H is the one Hatsu Mode key: Skill Hunter's book, Emperor Time, Godspeed or Gon's vow, whichever your Hatsu has
                    net.hxhadventure.addon.network.PacketAddonAction.hatsuMode(sender, Combat.get(sender));
                })
                .add());
        }
    }
}
