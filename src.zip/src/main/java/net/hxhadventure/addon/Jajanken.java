package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketRockFx;
import net.hxhadventure.entity.ModEntities;
import net.hxhadventure.entity.custom.AuraEntity;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Jajanken (Hatsu kit 14, Enhancers): Gon's rock-paper-scissors Hatsu. Techniques: <b>Rock</b> and <b>Scissors</b>.
 *
 * <ol>
 *   <li><b>Flare:</b> the moment the ability is pressed the user's current aura state is remembered (Ren, Ken, Ko,
 *       Zetsu or nothing), and a max-size Ren aura bursts out and shrinks to nothing in {@link #ROCK_FLARE_TICKS}
 *       ticks. When it is gone Ko is switched on for real: all the aura is in the fist.</li>
 *   <li><b>Charge:</b> HOLD Z. The user drops into a crouch and the aura around the fist starts
 *       wide and slowly converges on the fist into a ball (the longer it is held, the tighter and stronger it gets).</li>
 *   <li><b>Release:</b> let go of Z to throw the punch at normal melee range. It deals massive damage and breaks the
 *       blocks in a small area around where it lands.</li>
 * </ol>
 * "Hatsu is enforced" while charging: Ko is really on (NenAddonData.enforceKo), so the punch gets Ko's own melee multiplier
 * (built from the user's Hatsu level) and the body has Ko's defenceless {@link Tuning#KO_INCOMING_MULT}.
 * When the punch is thrown, or the charge is cancelled, the user is put back in the state they were in before Rock.
 * If the charge is lost to death, logout or a forced Zetsu nothing is restored (those clear the aura anyway).
 *
 * <b>Scissors</b> charges exactly like Rock (same flare, same Ko enforcement, same crouch). At a full charge the ball in the
 * hand turns into a blade; on release the user dashes {@link #SCISSORS_DASH} blocks forward in a horizontal slash that cuts
 * everything (entities and weak blocks) along the dash and {@link #SCISSORS_REACH} blocks ahead of where it ends (Rock's reach + 1).
 *
 * <b>Paper</b> charges the same way too, but the released ball of aura is thrown as a ranged shot (a ball with a tail, flying at
 * {@link #PAPER_SPEED} blocks per tick up to {@link #PAPER_RANGE} blocks) that bursts on the first thing it meets. It hurts
 * less than Rock. The damage (with Ko's multiplier) is fixed when it is thrown, because the user is back in their old state
 * by the time it lands.
 *
 * Every move is announced in chat to everyone: \"First comes rock...\" when it starts, \"Jan... ken...\" at {@link #CALL_FRACTION}
 * of the charge, and a different shout on release (\"G\u016b!\" for Rock, \"Chii!\" for Scissors, \"Pa!\" for Paper).
 *
 * <b>Gon's adult form</b> ({@link GonVow}, the \"I'll use everything.\" vow) changes Rock: only Rock is usable; the flare is a 10x Ren aura;
 * after it the aura is an orb that cycles in size to the sound clip (small red orb, rapid expansion to {@link GonVow#ORB_MAX_RADIUS} blocks around
 * the user, then back down to a dense, bright ball), the charge has no limit (the user is rooted), every finished cycle multiplies the damage by
 * {@link GonVow#CYCLE_DAMAGE_MULT}, and the blast reaches {@link GonVow#RADIUS_MULT}x as far (creatures and blocks).
 *
 * Server state is a charge per player; clients are only told what to draw (PacketRockFx / JajankenFx / JajankenRenderer).
 * Forge hooks live in {@link JajankenEvents}.
 */
public final class Jajanken {
    private Jajanken() {}

    public static final int KIT = 14;
    public static final String ROCK_ID = "jajanken_rock";
    public static final String SCISSORS_ID = "jajanken_scissors";
    public static final String PAPER_ID = "jajanken_paper";
    public static final int ROCK = 0, SCISSORS = 1, PAPER = 2;

    // ---- tuning (all in one place; nothing else needs to change to rebalance) ----
    public static final int ROCK_MIN_LEVEL = 5;
    public static final float ROCK_COST = 300f;                 // paid when the punch is thrown
    public static final int ROCK_FLARE_TICKS = 24;              // the max-size Ren aura that shrinks to nothing before Ko is enforced (was 12: half the speed now)
    public static final int ROCK_CHARGE_TICKS = 80;             // a full charge: 4 s
    /**
     * The aura's timing: it bursts out at full size the moment the move starts, then contracts into the fist in a straight line over
     * this many ticks, which is the same as a full charge, so the orb is at its smallest the moment the charge timer is full.
     * Visual only: damage still follows {@link #ROCK_CHARGE_TICKS}.
     */
    public static final int AURA_CONTRACT_TICKS = ROCK_CHARGE_TICKS; // the orb is fully contracted exactly when the charge is full
    public static final int ROCK_MIN_CHARGE_TICKS = 20;         // released earlier than this, the aura just scatters
    public static final int ROCK_COOLDOWN_TICKS = 100;          // after the punch
    public static final int ROCK_HOLD_LIMIT_TICKS = 100;        // past a full charge, the punch is thrown by itself after this long
    public static final float ROCK_BASE_DAMAGE = 22f;           // at a full charge, before level, Ko enforcement and affinity
    public static final float ROCK_DAMAGE_PER_LEVEL = 1.0f;
    public static final float ROCK_MIN_CHARGE_FACTOR = 0.4f;    // damage multiplier at the minimum charge (1.0 at full)
    public static final boolean ROCK_KO_ENFORCED = false;       // Ko is no longer forced while charging (and no Ko damage multiplier is added on top); set true to bring it back
    public static final double ROCK_REACH = 3.6;                // "normal melee range"
    public static final double ROCK_HIT_WIDTH = 0.7;            // how far off the look line a target may be
    public static final float ROCK_KNOCKBACK = 2.0f;
    public static final float ROCK_SHOCK_FRACTION = 0.4f;       // anything else within the shock radius takes this share
    public static final double ROCK_SHOCK_RADIUS = 2.2;
    public static final double ROCK_BREAK_RADIUS = 2.2;         // blocks broken: a small sphere around where the punch lands
    public static final int ROCK_MAX_BLOCKS = 45;
    public static final float ROCK_BLOCK_POWER = 30f;           // blocks with more blast resistance survive (obsidian is 1200)
    public static final boolean ROCK_BLOCK_DROPS = true;

    // ---- Scissors ----
    public static final int SCISSORS_MIN_LEVEL = 10;
    public static final float SCISSORS_COST = 350f;
    public static final int SCISSORS_COOLDOWN_TICKS = 120;
    public static final double SCISSORS_DASH = 3.0;             // blocks the user dashes forward
    public static final double SCISSORS_REACH = ROCK_REACH + 1; // one block more than Rock
    public static final double SCISSORS_WIDTH = 2.4;            // how far to each side of the dash line the blade cuts
    public static final float SCISSORS_BASE_DAMAGE = 20f;       // at a full charge, before level, Ko and affinity (it can hit many targets)
    public static final double SCISSORS_EXIT_SPEED = 1.2;       // momentum the user carries out of the slash (was 0.3)
    public static final float SCISSORS_KNOCKBACK = 1.2f;
    public static final float SCISSORS_DURABILITY_IGNORE = 0.10f; // Scissors ignores this share of the target's damage reduction (durability, armor)
    public static final double SCISSORS_BLOCK_HALF_WIDTH = 1.5; // blocks cut: a 2-high slab this wide around the dash line
    public static final int SCISSORS_MAX_BLOCKS = 90;
    // ---- Paper ----
    public static final int PAPER_MIN_LEVEL = 15;
    public static final float PAPER_COST = 300f;
    public static final int PAPER_COOLDOWN_TICKS = 120;
    public static final double PAPER_SPEED = 4.0;               // blocks per tick (was 1.6)
    public static final double PAPER_RANGE = 40.0;
    public static final float PAPER_BASE_DAMAGE = 14f;          // at a full charge, before level, Ko and affinity (Rock is 22)
    public static final double PAPER_RADIUS_MIN = 0.5, PAPER_RADIUS_MAX = 1.0; // the ball's size, by how long it was charged
    public static final double PAPER_BLAST_RADIUS = 2.5;
    public static final double PAPER_BREAK_RADIUS = 1.6;
    public static final int PAPER_MAX_BLOCKS = 20;
    public static final float PAPER_KNOCKBACK = 1.2f;
    public static final float PAPER_DAMAGE_MULT = 2.0f;         // Paper's damage is doubled
    /** The chat call "Jan... ken..." is said at this share of a full charge. */
    public static final double CALL_FRACTION = 0.70;

    private static final class Charge {
        int move;
        boolean calledJan;
        /** Game time the press happened, and the game time the Ko charge itself starts (press + flare). */
        long pressed, start;
        boolean release;
        NenAddonData.AuraSnapshot saved;
        AuraEntity flare;
        /** Gon's adult form: this Rock is the cycling orb (no limit, rooted). */
        boolean vow;
        /** Finished orb cycles when it was released (each one is x1.5 damage). */
        int cycles;
    }

    private static final Map<UUID, Charge> CHARGING = new ConcurrentHashMap<>();
    private static final Map<UUID, long[]> READY_AT = new ConcurrentHashMap<>(); // per move: ROCK, SCISSORS, PAPER

    /** A thrown Paper ball in flight (one per user: the cooldown is longer than its flight). */
    private static final class Shot {
        ServerLevel level;
        Vec3 pos, dir;
        double travelled, radius;
        float dmg;
    }

    private static final Map<UUID, Shot> SHOTS = new ConcurrentHashMap<>();

    private static long readyAt(UUID id, int move) {
        long[] r = READY_AT.get(id);
        return r == null ? 0L : r[move];
    }

    private static void setReady(UUID id, int move, long at) {
        READY_AT.computeIfAbsent(id, k -> new long[3])[move] = at;
    }

    // ---- Scissors: ignores a share of the target's durability ----
    /** The creature a Scissors hit is being dealt to right now (null otherwise), and the damage it had just before armor was applied. */
    private static LivingEntity pierceVictim;
    private static float pierceBefore = -1f;

    /** The share of the victim's damage reduction the hit being dealt right now ignores (0 for anything but a Scissors hit). */
    public static float pierce(LivingEntity victim) {
        return victim != null && victim == pierceVictim ? SCISSORS_DURABILITY_IGNORE : 0f;
    }

    /** Called when the hurt handlers are done: remembers the damage before armor and the like, so {@link #pierceAfter} can give back a share. */
    public static void pierceBefore(LivingEntity victim, float amount) {
        if (pierce(victim) > 0f) pierceBefore = amount;
    }

    /** Called once armor, resistance and absorption have reduced the hit: gives back the ignored share of what they took off. */
    public static float pierceAfter(LivingEntity victim, float amount) {
        float p = pierce(victim);
        if (p <= 0f || pierceBefore < 0f || amount >= pierceBefore) return amount;
        float out = amount + p * (pierceBefore - amount);
        pierceBefore = -1f;
        return out;
    }

    private static String moveName(int move) { return move == SCISSORS ? "Scissors" : move == PAPER ? "Paper" : "Rock"; }

    private static int minLevel(int move) { return move == SCISSORS ? SCISSORS_MIN_LEVEL : move == PAPER ? PAPER_MIN_LEVEL : ROCK_MIN_LEVEL; }

    private static float cost(int move) { return move == SCISSORS ? SCISSORS_COST : move == PAPER ? PAPER_COST : ROCK_COST; }

    /** Every Jajanken line goes to everyone's chat, as if the user said it. */
    static void say(ServerPlayer sp, String text) {
        if (sp.getServer() == null) return;
        sp.getServer().getPlayerList().broadcastSystemMessage(
            Component.literal("<").append(sp.getDisplayName()).append(Component.literal("> " + text)), false);
    }

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < ROCK_MIN_LEVEL) return base;
        boolean vow = GonVow.isActive(c.getPlayer()); // in Gon's adult form only Rock is on the menu
        List<String> out = new ArrayList<>(Arrays.asList(base));
        out.add(ROCK_ID);
        if (!vow && c.getHatsuLevel() >= SCISSORS_MIN_LEVEL) out.add(SCISSORS_ID);
        if (!vow && c.getHatsuLevel() >= PAPER_MIN_LEVEL) out.add(PAPER_ID);
        if (c.getHatsuLevel() >= GonVow.MIN_LEVEL && GonVow.isSworn(c.getPlayer())) out.add(GonVow.ID); // only once the vow is sworn
        return out.toArray(new String[0]);
    }

    public static boolean isCharging(Player p) {
        return p != null && CHARGING.containsKey(p.getUUID());
    }

    /**
     * Extra incoming-damage multiplier from Rock itself. Always 1 now: Ko is switched on for real while the aura is in the
     * fist, so AddonServerEvents already applies Ko's defenceless multiplier (counting it here too would double it), and
     * during the flare, before Ko is enforced, the user is not defenceless yet. Kept so JajankenEvents needs no change.
     */
    public static float incomingMult(Player p) {
        return 1.0f;
    }

    // ---------------- Rock: Z pressed ----------------
    public static void rock(ServerPlayer sp) { begin(sp, ROCK); }

    public static void scissors(ServerPlayer sp) { begin(sp, SCISSORS); }

    public static void paper(ServerPlayer sp) { begin(sp, PAPER); }

    private static void begin(ServerPlayer sp, int move) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Jajanken"), true);
            return;
        }
        int minLevel = minLevel(move);
        if (c.getHatsuLevel() < minLevel) {
            sp.displayClientMessage(Component.literal("\u00a7c" + moveName(move) + " unlocks at Level " + minLevel), true);
            return;
        }
        if (CHARGING.containsKey(sp.getUUID())) return;
        boolean vow = GonVow.isActive(sp);
        if (vow && move != ROCK) {
            sp.displayClientMessage(Component.literal("\u00a7cIn this form only Rock answers"), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        if (ChainManager.onCooldown(sp, "Jajanken: " + moveName(move), (int) Math.max(0, readyAt(sp.getUUID(), move) - now))) return;
        if (c.getCurrentEnergy() < cost(move)) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        NenAddonData d = NenAddonData.get(sp);
        Charge ch = new Charge();
        ch.move = move;
        ch.pressed = now;
        ch.start = now + ROCK_FLARE_TICKS;
        ch.vow = vow;
        ch.saved = d.snapshotAura(c);   // what to go back to
        d.clearForRockFlare(sp);        // Ren / Zetsu / forms off: the flare is the only aura out
        ch.flare = spawnFlare(sp, level, vow ? GonVow.REN_SIZE : Tuning.REN_MAX_SIZE);
        CHARGING.put(sp.getUUID(), ch);
        Prayer.chargeBegan(sp, move == SCISSORS ? SCISSORS_ID : move == PAPER ? PAPER_ID : ROCK_ID, ch.saved); // Ko / root limitations start now, on the press
        if (vow && GonVow.addDebt(sp)) return; // every vow Rock that is charged adds a level of Nen debt; at the limit the Nen is lost and this Rock never starts
        AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 1, move, 0, 0, 0, 0, 0), sp);
        say(sp, "First comes rock...");
        level.playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 0.6f);
        level.sendParticles(ParticleTypes.FLASH, sp.getX(), sp.getY() + 1.0, sp.getZ(), 1, 0, 0, 0, 0.0);
    }

    /** A Ren aura at the biggest size the slider allows, drawn by the normal aura renderer. */
    private static AuraEntity spawnFlare(ServerPlayer sp, ServerLevel level, float size) {
        AuraEntity aura = new AuraEntity((EntityType<?>) ModEntities.AURA_ENTITY.get(), level);
        aura.setPos(sp.getX(), sp.getY(), sp.getZ());
        aura.setOwner(sp);
        aura.setAuraColorIndex(AbilityRegistry.getOrCreatePlayerAuraColor(sp) - 1);
        aura.setAuraType(0);
        aura.setAuraScale(size);
        level.addFreshEntity(aura);
        return aura;
    }

    /** Max size -> nothing, fast at first (ease-out), then gone. */
    private static void shrinkFlare(Charge ch, long now) {
        if (ch.flare == null) return;
        double t = (now - ch.pressed) / (double) ROCK_FLARE_TICKS;
        if (t >= 1.0 || !ch.flare.isAlive()) {
            ch.flare.discard();
            ch.flare = null;
            return;
        }
        double left = 1.0 - t;
        ch.flare.setAuraScale(Math.max(0.02f, (float) ((ch.vow ? GonVow.REN_SIZE : Tuning.REN_MAX_SIZE) * left * left)));
    }

    private static void dropFlare(Charge ch) {
        if (ch.flare != null) {
            ch.flare.discard();
            ch.flare = null;
        }
    }

    /** Z released: throw the punch (from PacketZHold). */
    public static void setZHeld(ServerPlayer sp, boolean held) {
        if (held) return;
        Charge ch = CHARGING.get(sp.getUUID());
        if (ch != null) ch.release = true;
    }

    // ---------------- per tick ----------------
    public static void tick(ServerPlayer sp) {
        tickShots(sp);
        Charge ch = CHARGING.get(sp.getUUID());
        if (ch == null) return;
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || !sp.isAlive() || ExtrasHooks.hatsuForced(sp) || !(sp.level() instanceof ServerLevel level)) {
            end(sp);
            return;
        }
        long now = level.getGameTime();
        long elapsed = now - ch.start; // negative while the flare is still shrinking
        if (ch.vow) GonVow.freeze(sp); // the vow's Rock roots the user from the press until the punch
        if (!ch.vow && !ch.release && elapsed > ROCK_CHARGE_TICKS + ROCK_HOLD_LIMIT_TICKS) ch.release = true; // held far too long (or the key-up was missed): throw it
        if (ch.release) {
            CHARGING.remove(sp.getUUID());
            if (elapsed < ROCK_MIN_CHARGE_TICKS) {
                cancel(sp, ch, "\u00a77" + moveName(ch.move) + ": the aura scattered (hold Z a little longer)");
                return;
            }
            // the vow's first finished cycle is the full charge; every cycle after it is x1.5 on top
            double charge = Math.min(1.0, elapsed / (double) (ch.vow ? GonVow.CYCLE_TICKS : ROCK_CHARGE_TICKS));
            ch.cycles = ch.vow ? GonVow.cyclesDone(elapsed) : 0;
            if (ch.move == SCISSORS) slash(sp, c, level, charge, ch);
            else if (ch.move == PAPER) fire(sp, c, level, charge, ch);
            else punch(sp, c, level, charge, ch);
            return;
        }
        sp.setSprinting(false);
        if (elapsed < 0) { // the flare: max-size Ren shrinking to nothing
            shrinkFlare(ch, now);
            return;
        }
        if (ch.flare != null) { // the flare is gone: all the aura goes into the fist
            dropFlare(ch);
            level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8f, 0.8f);
        }
        if (ROCK_KO_ENFORCED) NenAddonData.get(sp).enforceKo(sp); // held on every tick, so toggling a form or Ren mid-charge cannot break it
        if (!ch.calledJan && elapsed >= CALL_FRACTION * ROCK_CHARGE_TICKS) {
            ch.calledJan = true;
            say(sp, "Jan... ken...");
        }
        if (ch.vow) {
            if (elapsed % 5 == 0) {
                int cyc = GonVow.cyclesDone(elapsed);
                sp.displayClientMessage(Component.literal(String.format(java.util.Locale.ROOT,
                    "\u00a74Rock: cycle %d, x%.3g damage \u00a77(debt %d/%d, %ds left) \u00a74release Z", cyc, (double) GonVow.cycleMult(cyc),
                    GonVow.debt(sp), GonVow.NEN_LOSS_DEBT, GonVow.ticksLeft(sp) / 20)), true);
            }
            return;
        }
        if (elapsed % 5 == 0) {
            String bar = elapsed >= ROCK_CHARGE_TICKS
                ? "\u00a76" + moveName(ch.move) + ": fully charged, release Z"
                : String.format(java.util.Locale.ROOT, "\u00a76%s: %d%%", moveName(ch.move), (int) (100.0 * elapsed / ROCK_CHARGE_TICKS));
            sp.displayClientMessage(Component.literal(bar), true);
        }
        if (elapsed == ROCK_CHARGE_TICKS) level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.2f, 0.7f);
    }

    /** The charge ends without a punch but the user is still fine (released too early, no energy): back to how they were. */
    private static void cancel(ServerPlayer sp, Charge ch, String message) {
        dropFlare(ch);
        AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 0, 0, 0, 0, 0, 0, 0), sp);
        NenAddonData.get(sp).restoreAura(sp, ch.saved);
        sp.displayClientMessage(Component.literal(message), true);
    }

    /** The charge is lost without a punch (death, logout, lost the Hatsu, forced Zetsu). */
    public static void end(Player p) {
        Charge ch = CHARGING.remove(p.getUUID());
        if (ch == null) return;
        dropFlare(ch);
        NenAddonData d = NenAddonData.peek(p);
        if (d != null) d.dropEnforcedKo(); // nothing is restored here: those causes clear the aura themselves
        if (p instanceof ServerPlayer sp) AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 0, 0, 0, 0, 0, 0, 0), sp);
    }

    public static void clear(Player p) {
        end(p);
        SHOTS.remove(p.getUUID());
        READY_AT.remove(p.getUUID());
    }

    /** A player who comes into view of someone mid-charge sees the aura straight away. */
    public static void sendTo(ServerPlayer owner, ServerPlayer viewer) {
        Charge ch = CHARGING.get(owner.getUUID());
        if (ch == null) return;
        double age = owner.level().getGameTime() - ch.pressed; // x carries how long ago the press was, so the viewer's timing lines up
        AddonNetwork.sendToPlayer(new PacketRockFx(owner.getId(), 1, ch.move, age, 0, 0, 0, 0), viewer);
    }

    /** Damage of a fully charged Rock for this user, before Vows and affinity. */
    public static float fullChargeDamage(Combat c) {
        return ROCK_BASE_DAMAGE + c.getHatsuLevel() * ROCK_DAMAGE_PER_LEVEL;
    }

    // ---------------- the punch ----------------
    private static void punch(ServerPlayer sp, Combat c, ServerLevel level, double charge, Charge ch) {
        if (c.getCurrentEnergy() < ROCK_COST) {
            cancel(sp, ch, "\u00a7cNot enough energy");
            return;
        }
        c.consumeEnergy(ROCK_COST);
        long now = level.getGameTime();
        setReady(sp.getUUID(), ROCK, now + ROCK_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Jajanken: Rock", ROCK_COOLDOWN_TICKS);
        say(sp, "G\u016b!");
        sp.swing(InteractionHand.MAIN_HAND, true);

        // damage: scales with how long it was charged; Ko-style enforcement while the aura was all in the fist
        float dmg = (ROCK_BASE_DAMAGE + c.getHatsuLevel() * ROCK_DAMAGE_PER_LEVEL)
            * (float) (ROCK_MIN_CHARGE_FACTOR + (1.0 - ROCK_MIN_CHARGE_FACTOR) * charge);
        NenAddonData d = NenAddonData.peek(sp);
        if (ROCK_KO_ENFORCED && d != null && !d.ko) { // a real Ko is already applied to melee hits, so don't count it twice
            dmg *= d.koMeleeMult();
        }
        dmg *= Vows.power(sp, ROCK_ID);
        boolean vow = ch.vow;
        double radiusMult = vow ? GonVow.RADIUS_MULT : 1.0;
        if (vow) dmg = Math.min(GonVow.MAX_DAMAGE, dmg * GonVow.cycleMult(ch.cycles)); // x1.5 per finished orb cycle
        Prayer.attackOut(sp, ROCK_ID);
        strike(sp, level, dmg, vow, radiusMult, true);

        // the hit has landed (Ko was on for every hurt event above): back to the state the user was in before Rock
        NenAddonData.get(sp).restoreAura(sp, ch.saved);
        Vows.afterCharge(sp, ROCK_ID);
    }

    /**
     * The Rock punch itself, shared with Ripper Cyclotron: hits what the fist meets within melee range, shocks what is near the impact,
     * breaks blocks and plays the sounds. {@code dmg} is the full damage of the hit. Returns where it landed.
     */
    public static Vec3 strike(ServerPlayer sp, ServerLevel level, float dmg, boolean vow, double radiusMult, boolean rockFx) {
        return strike(sp, level, dmg, vow, radiusMult, rockFx, GonVow.CRATER_MAX_DEPTH);
    }

    /** Same, with the depth below the user's feet the big crater (the {@code vow} one) may dig to: Big Bang Impact passes its own. */
    public static Vec3 strike(ServerPlayer sp, ServerLevel level, float dmg, boolean vow, double radiusMult, boolean rockFx, int craterDepth) {
        // what the fist meets, within normal melee range
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle().normalize();
        Vec3 end = eye.add(look.scale(ROCK_REACH));
        HitResult wall = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        double wallDist = wall.getType() == HitResult.Type.MISS ? ROCK_REACH + 1 : wall.getLocation().distanceTo(eye);

        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(1.5))) {
            if (e == sp || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, sp)) continue;
            Vec3 v = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(eye);
            double proj = v.dot(look);
            if (proj < 0 || proj > ROCK_REACH + e.getBbWidth() * 0.5 || proj > wallDist + 0.5) continue;
            double perp = v.subtract(look.scale(proj)).length();
            if (perp > ROCK_HIT_WIDTH + e.getBbWidth() * 0.5 || proj >= best) continue;
            best = proj;
            target = e;
        }

        Vec3 impact;
        if (target != null) impact = target.position().add(0, target.getBbHeight() * 0.5, 0);
        else if (wall.getType() != HitResult.Type.MISS) impact = wall.getLocation();
        else impact = end;

        if (target != null) {
            target.invulnerableTime = 0;
            Vows.hatsuHurt(target, level.damageSources().playerAttack(sp), dmg);
            Vec3 push = look.scale(ROCK_KNOCKBACK).add(0, 0.45, 0);
            target.push(push.x, push.y, push.z);
            target.hurtMarked = true;
        }
        // the shock: anything else near the impact is hit for a share of it
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(impact, impact).inflate(ROCK_SHOCK_RADIUS * radiusMult))) {
            if (e == sp || e == target || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, sp)) continue;
            e.invulnerableTime = 0;
            Vows.hatsuHurt(e, level.damageSources().playerAttack(sp), dmg * ROCK_SHOCK_FRACTION);
            Vec3 away = e.position().subtract(impact).multiply(1, 0, 1);
            if (away.lengthSqr() > 1e-4) away = away.normalize().scale(0.8);
            e.push(away.x, 0.3, away.z);
            e.hurtMarked = true;
        }

        if (vow) GonVow.startCrater(level, impact.add(look.scale(0.4)), ROCK_BREAK_RADIUS * radiusMult, sp.blockPosition().getY(), craterDepth);
        else breakBlocks(level, sp, impact, look);

        if (rockFx) AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 2, ROCK, impact.x, impact.y, impact.z, vow ? radiusMult : 0, 0), sp);
        if (vow) {
            level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 8.0f, 0.5f);
            level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.WITHER_BREAK_BLOCK, SoundSource.PLAYERS, 6.0f, 0.6f);
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, impact.x, impact.y, impact.z, 12, ROCK_SHOCK_RADIUS * radiusMult * 0.4, 1.5, ROCK_SHOCK_RADIUS * radiusMult * 0.4, 0.0);
        }
        level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.6f, 0.7f);
        level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.IRON_GOLEM_ATTACK, SoundSource.PLAYERS, 1.8f, 0.5f);
        level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.8f, 0.6f);
        level.sendParticles(ParticleTypes.EXPLOSION, impact.x, impact.y, impact.z, 2, 0.3, 0.3, 0.3, 0.0);
        level.sendParticles(ParticleTypes.FLASH, impact.x, impact.y, impact.z, 1, 0, 0, 0, 0.0);
        return impact;
    }

    // ---------------- Paper: the thrown ball ----------------
    private static void fire(ServerPlayer sp, Combat c, ServerLevel level, double charge, Charge ch) {
        if (c.getCurrentEnergy() < PAPER_COST) {
            cancel(sp, ch, "\u00a7cNot enough energy");
            return;
        }
        c.consumeEnergy(PAPER_COST);
        long now = level.getGameTime();
        setReady(sp.getUUID(), PAPER, now + PAPER_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Jajanken: Paper", PAPER_COOLDOWN_TICKS);
        Prayer.attackOut(sp, PAPER_ID);
        say(sp, "Pa!");
        sp.swing(InteractionHand.MAIN_HAND, true);

        Vec3 look = sp.getLookAngle().normalize();
        Vec3 origin = sp.getEyePosition().add(look.scale(0.8)).subtract(0, 0.45, 0);
        // the damage is fixed now, with Ko's multiplier: the user is back in their old state by the time the ball lands
        float dmg = (PAPER_BASE_DAMAGE + c.getHatsuLevel() * ROCK_DAMAGE_PER_LEVEL)
            * (float) (ROCK_MIN_CHARGE_FACTOR + (1.0 - ROCK_MIN_CHARGE_FACTOR) * charge);
        NenAddonData d = NenAddonData.peek(sp);
        if (ROCK_KO_ENFORCED && d != null) dmg *= d.koMeleeMult();

        Shot s = new Shot();
        s.level = level;
        s.pos = origin;
        s.dir = look;
        s.dmg = dmg * Vows.power(sp, PAPER_ID) * PAPER_DAMAGE_MULT;
        s.radius = PAPER_RADIUS_MIN + (PAPER_RADIUS_MAX - PAPER_RADIUS_MIN) * charge;
        SHOTS.put(sp.getUUID(), s);

        AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 4, PAPER, origin.x, origin.y, origin.z, charge, sp.getYRot(), sp.getXRot()), sp);
        level.playSound(null, origin.x, origin.y, origin.z, SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.6f, 0.6f);
        level.playSound(null, origin.x, origin.y, origin.z, SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.2f, 1.6f);

        NenAddonData.get(sp).restoreAura(sp, ch.saved);
        Vows.afterCharge(sp, PAPER_ID);
    }

    /** Moves the user's ball along, one tick: it stops at the first wall or creature, or at the end of its range, and bursts. */
    private static void tickShots(ServerPlayer sp) {
        Shot s = SHOTS.get(sp.getUUID());
        if (s == null) return;
        if (!sp.isAlive() || sp.level() != s.level) {
            SHOTS.remove(sp.getUUID());
            return;
        }
        ServerLevel level = s.level;
        double step = Math.min(PAPER_SPEED, PAPER_RANGE - s.travelled);
        Vec3 p0 = s.pos, p1 = p0.add(s.dir.scale(step));
        HitResult wall = level.clip(new ClipContext(p0, p1, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        Vec3 limit = wall.getType() == HitResult.Type.MISS ? p1 : wall.getLocation();

        LivingEntity hit = null;
        Vec3 hitAt = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(p0, limit).inflate(s.radius + 1.0))) {
            if (e == sp || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, sp)) continue;
            AABB box = e.getBoundingBox().inflate(s.radius);
            Vec3 at;
            if (box.contains(p0)) {
                at = p0;
            } else {
                Optional<Vec3> o = box.clip(p0, limit);
                if (o.isEmpty()) continue;
                at = o.get();
            }
            double dist = at.distanceToSqr(p0);
            if (dist < best) {
                best = dist;
                hit = e;
                hitAt = at;
            }
        }
        if (hit != null) {
            blast(sp, s, hitAt, hit);
        } else if (wall.getType() != HitResult.Type.MISS) {
            blast(sp, s, limit, null);
        } else if (s.travelled + step >= PAPER_RANGE - 1e-6) {
            blast(sp, s, p1, null);
        } else {
            s.pos = p1;
            s.travelled += step;
        }
    }

    private static void blast(ServerPlayer sp, Shot s, Vec3 at, LivingEntity direct) {
        SHOTS.remove(sp.getUUID());
        ServerLevel level = s.level;
        // Ko's multiplier is already in s.dmg, so cancel whatever melee form multiplier the user has now (the hurt event re-applies it)
        Combat c = Combat.get(sp);
        NenAddonData d = NenAddonData.peek(sp);
        float cur = c != null && d != null ? d.outgoingFormMult(c, true) : 1f;
        float amount = s.dmg / Math.max(0.1f, cur);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(PAPER_BLAST_RADIUS))) {
            if (e == sp || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, sp)) continue;
            double dist = e.position().add(0, e.getBbHeight() * 0.5, 0).distanceTo(at);
            float fall = e == direct ? 1f : (float) Math.max(0.5, 1.0 - 0.5 * dist / PAPER_BLAST_RADIUS);
            e.invulnerableTime = 0;
            Vows.hatsuHurt(e, level.damageSources().playerAttack(sp), amount * fall);
            Vec3 away = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(at);
            away = away.lengthSqr() > 1e-4 ? away.normalize().scale(PAPER_KNOCKBACK) : s.dir.scale(PAPER_KNOCKBACK);
            e.push(away.x, 0.3 + Math.max(0, away.y) * 0.3, away.z);
            e.hurtMarked = true;
        }
        breakBlocks(level, sp, at, s.dir, PAPER_BREAK_RADIUS, PAPER_MAX_BLOCKS);
        AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 5, PAPER, at.x, at.y, at.z, 0, 0), sp);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.4f, 0.9f);
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0.2, 0.2, 0.2, 0.0);
        level.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0, 0, 0, 0.0);
    }

    // ---------------- Scissors: the dash slash ----------------
    private static void slash(ServerPlayer sp, Combat c, ServerLevel level, double charge, Charge ch) {
        if (c.getCurrentEnergy() < SCISSORS_COST) {
            cancel(sp, ch, "\u00a7cNot enough energy");
            return;
        }
        c.consumeEnergy(SCISSORS_COST);
        long now = level.getGameTime();
        setReady(sp.getUUID(), SCISSORS, now + SCISSORS_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Jajanken: Scissors", SCISSORS_COOLDOWN_TICKS);
        Prayer.attackOut(sp, SCISSORS_ID);
        say(sp, "Chii!");
        sp.swing(InteractionHand.MAIN_HAND, true);

        float yaw = sp.getYRot();
        double rad = Math.toRadians(yaw);
        Vec3 dir = new Vec3(-Math.sin(rad), 0, Math.cos(rad)); // the way the user faces, flat on the ground
        Vec3 start = sp.position();

        // 1. cut the weak blocks along the dash and ahead of it, so the dash is not stopped by them
        cutBlocks(level, sp, start, dir);

        // 2. the dash itself: up to 3 blocks, stopped early only by something that survived the cut
        double dist = 0;
        AABB box = sp.getBoundingBox();
        for (double d = 0.25; d <= SCISSORS_DASH + 1e-6; d += 0.25) {
            if (!level.noCollision(sp, box.move(dir.scale(d)))) break;
            dist = d;
        }
        Vec3 end = start.add(dir.scale(dist));

        // 3. everything in the blade's zone: the dash line plus Scissors' reach beyond where it ends
        float dmg = (SCISSORS_BASE_DAMAGE + c.getHatsuLevel() * ROCK_DAMAGE_PER_LEVEL)
            * (float) (ROCK_MIN_CHARGE_FACTOR + (1.0 - ROCK_MIN_CHARGE_FACTOR) * charge);
        NenAddonData d = NenAddonData.peek(sp);
        if (ROCK_KO_ENFORCED && d != null && !d.ko) dmg *= d.koMeleeMult();
        dmg *= Vows.power(sp, SCISSORS_ID);
        double length = dist + SCISSORS_REACH;
        AABB zone = new AABB(start, start.add(dir.scale(length))).inflate(SCISSORS_WIDTH + 1.0, 2.5, SCISSORS_WIDTH + 1.0);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, zone)) {
            if (e == sp || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, sp)) continue;
            Vec3 v = e.position().subtract(start);
            double along = v.x * dir.x + v.z * dir.z;
            double lateral = Math.abs(v.x * -dir.z + v.z * dir.x);
            double half = e.getBbWidth() * 0.5;
            if (along < -0.5 || along > length + half || lateral > SCISSORS_WIDTH + half) continue;
            if (e.getBoundingBox().maxY < start.y - 0.5 || e.getBoundingBox().minY > start.y + 2.2) continue;
            e.invulnerableTime = 0;
            pierceVictim = e;
            try {
                Vows.hatsuHurt(e, level.damageSources().playerAttack(sp), dmg);
            } finally {
                pierceVictim = null;
                pierceBefore = -1f;
            }
            e.push(dir.x * SCISSORS_KNOCKBACK, 0.3, dir.z * SCISSORS_KNOCKBACK);
            e.hurtMarked = true;
        }

        // 4. move the user (damage first: Ko is still on for every hurt event above)
        sp.connection.teleport(end.x, end.y, end.z, yaw, sp.getXRot());
        sp.setDeltaMovement(dir.scale(SCISSORS_EXIT_SPEED));
        sp.hurtMarked = true;
        sp.fallDistance = 0;

        AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 3, SCISSORS, start.x, start.y, start.z, dist, yaw), sp);
        level.playSound(null, end.x, end.y, end.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.8f, 0.6f);
        level.playSound(null, end.x, end.y, end.z, SoundEvents.TRIDENT_RIPTIDE_3, SoundSource.PLAYERS, 1.0f, 1.4f);
        for (double t = 0; t <= length; t += 0.8) {
            Vec3 pt = start.add(dir.scale(t));
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, pt.x, pt.y + 1.1, pt.z, 1, 0.3, 0.2, 0.3, 0.0);
        }

        NenAddonData.get(sp).restoreAura(sp, ch.saved);
        Vows.afterCharge(sp, SCISSORS_ID);
    }

    /** Cuts a 2-high slab of weak blocks along the dash and the reach beyond it, nearest first, up to a cap. */
    static void cutBlocks(ServerLevel level, net.minecraft.world.entity.Entity sp, Vec3 start, Vec3 dir) {
        double length = SCISSORS_DASH + SCISSORS_REACH;
        double w = SCISSORS_BLOCK_HALF_WIDTH;
        int minX = (int) Math.floor(Math.min(start.x, start.x + dir.x * length) - w);
        int maxX = (int) Math.floor(Math.max(start.x, start.x + dir.x * length) + w);
        int minZ = (int) Math.floor(Math.min(start.z, start.z + dir.z * length) - w);
        int maxZ = (int) Math.floor(Math.max(start.z, start.z + dir.z * length) + w);
        int y0 = (int) Math.floor(start.y + 0.1);
        java.util.List<double[]> cells = new java.util.ArrayList<>();
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                double vx = x + 0.5 - start.x, vz = z + 0.5 - start.z;
                double along = vx * dir.x + vz * dir.z;
                double lateral = Math.abs(vx * -dir.z + vz * dir.x);
                if (along < 0.3 || along > length || lateral > w) continue;
                cells.add(new double[] {along, x, z});
            }
        }
        cells.sort(java.util.Comparator.comparingDouble(a -> a[0]));
        int broken = 0;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (double[] cell : cells) {
            for (int dy = 0; dy <= 1 && broken < SCISSORS_MAX_BLOCKS; dy++) {
                pos.set((int) cell[1], y0 + dy, (int) cell[2]);
                if (!level.isInWorldBounds(pos)) continue;
                BlockState st = level.getBlockState(pos);
                if (st.isAir() || !st.getFluidState().isEmpty() || st.getDestroySpeed(level, pos) < 0
                    || st.getBlock().getExplosionResistance() > ROCK_BLOCK_POWER) continue;
                if (level.random.nextFloat() < 0.25f) {
                    level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 3, 0.3, 0.3, 0.3, 0.08);
                }
                level.destroyBlock(pos.immutable(), ROCK_BLOCK_DROPS, sp);
                broken++;
            }
            if (broken >= SCISSORS_MAX_BLOCKS) break;
        }
    }

    /** Breaks the blocks in a small sphere around the impact (nearest first, capped), skipping anything too tough. */
    static void breakBlocks(ServerLevel level, net.minecraft.world.entity.Entity sp, Vec3 impact, Vec3 look) {
        breakBlocks(level, sp, impact, look, ROCK_BREAK_RADIUS, ROCK_MAX_BLOCKS);
    }

    static void breakBlocks(ServerLevel level, net.minecraft.world.entity.Entity sp, Vec3 impact, Vec3 look, double radius, int maxBlocks) {
        // the centre sits a little inside the surface that was hit, so the crater is cut into it
        Vec3 centre = impact.add(look.scale(0.4));
        int r = (int) Math.ceil(radius);
        BlockPos origin = BlockPos.containing(centre);
        Set<Long> done = new HashSet<>();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int broken = 0;
        for (int ring = 0; ring <= r && broken < maxBlocks; ring++) { // inside out, so the cap never leaves a ring with a hole in the middle
            for (int x = -ring; x <= ring && broken < maxBlocks; x++) {
                for (int y = -ring; y <= ring && broken < maxBlocks; y++) {
                    for (int z = -ring; z <= ring && broken < maxBlocks; z++) {
                        if (Math.max(Math.abs(x), Math.max(Math.abs(y), Math.abs(z))) != ring) continue;
                        pos.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                        double dx = pos.getX() + 0.5 - centre.x, dy = pos.getY() + 0.5 - centre.y, dz = pos.getZ() + 0.5 - centre.z;
                        if (dx * dx + dy * dy + dz * dz > radius * radius) continue;
                        if (!level.isInWorldBounds(pos) || !done.add(pos.asLong())) continue;
                        BlockState st = level.getBlockState(pos);
                        if (st.isAir() || !st.getFluidState().isEmpty() || st.getDestroySpeed(level, pos) < 0
                            || st.getBlock().getExplosionResistance() > ROCK_BLOCK_POWER) continue;
                        if (level.random.nextFloat() < 0.2f) {
                            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 3, 0.3, 0.3, 0.3, 0.08);
                        }
                        level.destroyBlock(pos.immutable(), ROCK_BLOCK_DROPS, sp);
                        broken++;
                    }
                }
            }
        }
    }
}
