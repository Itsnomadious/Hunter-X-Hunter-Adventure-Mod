package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Lightning Aura's hooks into the game: Whirlwind dodging, the stun stopping jumps, and Thunderbolt's leap not hurting on landing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class LightningEvents {
    private LightningEvents() {}

    /** Whirlwind: an attack from another creature (melee, arrows, spells) can be dodged while Godspeed is on. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onAttack(LivingAttackEvent e) {
        if (e.isCanceled() || !(e.getEntity() instanceof ServerPlayer sp) || sp.level().isClientSide) return;
        if (!LightningAura.isGodspeed(sp)) return;
        DamageSource src = e.getSource();
        if (src.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || src.getEntity() == null || src.getEntity() == sp) return; // no dodging the void, fire or self-harm
        if (LightningAura.whirlwindDodges(sp)) e.setCanceled(true);
    }

    /** Paralysis: no jumping either (the walking speed is already zero). */
    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent e) {
        if (HatsuEffects.isStunned(e.getEntity())) {
            var m = e.getEntity().getDeltaMovement();
            e.getEntity().setDeltaMovement(m.x, Math.min(0, m.y), m.z);
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent e) {
        if (e.getEntity() instanceof Player p && LightningAura.noFall(p)) e.setCanceled(true);
    }
}
