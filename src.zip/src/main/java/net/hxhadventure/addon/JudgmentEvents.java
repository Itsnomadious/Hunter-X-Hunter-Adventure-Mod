package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge hooks of the Judgment Chain (see {@link JudgmentChain}). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class JudgmentEvents {
    private JudgmentEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase == TickEvent.Phase.END && e.player instanceof ServerPlayer sp) JudgmentChain.tickPlayer(sp);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        var server = ServerLifecycleHooks.getCurrentServer();
        if (server != null && server.getTickCount() % 10 == 0) JudgmentChain.tickNpcs(server);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!e.getEntity().level().isClientSide) JudgmentChain.onDeath(e.getEntity());
    }

    /** A sealed creature cannot hurt anyone; a bound player who hits their binder breaks "never raise a hand against me". */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        if (e.getEntity().level().isClientSide) return;
        Entity attacker = e.getSource().getEntity();
        if (attacker == null) return;
        if (JudgmentChain.isStakedNpc(attacker)) {
            e.setCanceled(true);
            return;
        }
        if (attacker instanceof ServerPlayer sp) JudgmentChain.onPlayerAttack(sp, e.getEntity());
    }

    /** A sealed creature never picks a target. */
    @SubscribeEvent
    public static void onTarget(LivingChangeTargetEvent e) {
        if (JudgmentChain.isStakedNpc(e.getEntity())) e.setNewTarget(null);
    }

    @SubscribeEvent
    public static void onStopped(ServerStoppedEvent e) {
        JudgmentChain.reset();
    }
}
