package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks for {@link CrazySlots}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CrazySlotsEvents {
    private CrazySlotsEvents() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) CrazySlots.serverTick(ServerLifecycleHooks.getCurrentServer());
    }

    /** Putting a weapon down is not possible: it is conjured, so it never lands on the ground. */
    @SubscribeEvent
    public static void onToss(ItemTossEvent e) {
        if (CrazySlots.isWeapon(e.getEntity().getItem())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent e) {
        CrazySlots.stripWeaponDrops(e.getDrops());
    }

    /** Not delivered for a death another handler refused (Terpsichora), so the staff's curse only follows a real death. */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) CrazySlots.onDeath(sp, e.getSource());
    }

    /** Last, so it runs after HxHAdventure has rebuilt the new body's Nen. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) CrazySlots.onRespawn(sp);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp && NenAddonData.get(sp).chimera) CrazySlots.applyChimeraTags(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) CrazySlots.onLogout(sp);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        CrazySlots.reset();
    }
}
