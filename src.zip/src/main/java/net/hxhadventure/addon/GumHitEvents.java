package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Every melee hit a Bungee Gum user lands sticks "Properties of Rubber and Gum" (and so a tether) onto the victim. It listens first of all
 * and even to hits other mods have already cancelled, so nothing earlier in the chain can swallow it. Gum's own damage (selfHurt) is skipped.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class GumHitEvents {
    private GumHitEvents() {}

    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public static void onHurt(LivingHurtEvent event) {
        if (event.getEntity().level().isClientSide) return;
        DamageSource src = event.getSource();
        Entity cause = src.getEntity();
        if (!(cause instanceof ServerPlayer user) || cause == event.getEntity()) return;
        if (src.getDirectEntity() instanceof Projectile) return; // melee: not an arrow or a thrown thing
        BungeeGum.onMeleeHit(user, event.getEntity());
    }
}
