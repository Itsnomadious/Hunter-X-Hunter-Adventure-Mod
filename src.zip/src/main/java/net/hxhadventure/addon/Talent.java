package net.hxhadventure.addon;

import java.util.Random;

/**
 * How gifted a player is, rolled once when their Nen awakens (first the aura colour, then this, then the Nen type; nothing else affects it) and never changed afterwards (only the /hxh talent command can).
 * Kite comments on it when you speak to him. The rarity is the chance of rolling at least that rare; everyone else is Common.
 */
public enum Talent {
    COMMON("common", "Common", 1.0, 1.0f, 0xFFB8B4A8,
        "Your talent is ordinary. Do not take that as an insult. Talent is only the starting line."),
    ONE_IN_THOUSAND("oneinthousand", "One in a thousand", 1e-3, 1.2f, 0xFF7FD6A0,
        "You have potential."),
    ONE_IN_TEN_THOUSAND("oneintenthousand", "One in ten thousand", 1e-4, 1.5f, 0xFF5FC8E8,
        "A rare talent. I have met only a handful of people with aura like yours."),
    ONE_IN_HUNDRED_THOUSAND("oneinhundredthousand", "One in a hundred thousand", 1e-5, 2.0f, 0xFFB48CF0,
        "Remarkable. A talent like yours turns up once in a hundred thousand people, if that."),
    ONE_IN_MILLION("oneinmillion", "One in a million", 1e-6, 3.0f, 0xFFF2C84B,
        "You have a god given gift."),
    ONE_IN_TEN_MILLION("oneintenmillion", "One in ten million", 1e-7, 4.5f, 0xFF5FF0D0,
        "Ten million to one. I have heard such talent described. I never thought I would be standing in front of it."),
    ONE_IN_BILLION("oneinbillion", "One in a billion", 1e-9, 6.0f, 0xFFF59A4B,
        "This should not be possible. Talent like yours comes once in a billion lives."),
    ONE_OF_A_KIND("oneofakind", "One of a kind", 1e-10, 11.0f, 0xFFFF6E8A,
        "Your like has never been seen before, and likely never will be again.");

    public final String id;
    public final String label;
    public final double chance;
    /** Multiplier on all Nen experience (level XP and skill XP): +0% / +20% / +50% / +100% / +200% / +350% / +500% / +1000%. */
    public final float xpMult;
    public final int color;
    public final String kiteLine;

    Talent(String id, String label, double chance, float xpMult, int color, String kiteLine) {
        this.id = id;
        this.label = label;
        this.chance = chance;
        this.xpMult = xpMult;
        this.color = color;
        this.kiteLine = kiteLine;
    }

    public static Talent byId(String id) {
        for (Talent t : values()) if (t.id.equals(id)) return t;
        return null;
    }

    public static Talent byOrdinal(int i) {
        Talent[] v = values();
        return i >= 0 && i < v.length ? v[i] : COMMON;
    }

    /**
     * One roll, nothing else affects it. Normally the rarest tier whose chance the roll falls under, else Common.
     * With the game rule hxhtalented on, Common is removed and the other seven talents are equally likely.
     */
    public static Talent roll(Random rnd, boolean talentedOnly) {
        Talent[] v = values();
        if (talentedOnly) return v[1 + rnd.nextInt(v.length - 1)];
        double r = rnd.nextDouble();
        for (int i = v.length - 1; i >= 1; i--) { // rarest first
            if (r < v[i].chance) return v[i];
        }
        return COMMON;
    }
}
