package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketNeedleFx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import org.jetbrains.annotations.Nullable;

/**
 * Illumi (NPC): Manipulation Hatsu "Illumi's Needles". He opens with a volley of needles at range, then plants needles in nearby mobs
 * (Corpse Control on the undead, Needle People on anything else, the player's costs and needle visuals) which then fight whatever he is
 * fighting and follow him; when the fight ends the needles come out. Up close he punches with Ten / Ren / Ken like everyone else.
 * (Body Alteration is a disguise for players and is not used by the NPC.)
 */
public class IllumiEntity extends NenFighter {
    public static final NpcStats STATS = new NpcStats("illumi", Combat.NEN_MANIPULATION)
        .levels(100, 98, 97, 95)
        .body(180.0, 0.30, 0.4, 1.0f)
        .melee(1.0f, 2.5)
        .look("purpleaura_ten", 0x1B1B2B, 0x7A5CC0);

    private static final int MAX_CORPSES = 4, MAX_PEOPLE = 2;
    private static final float VOLLEY_COST = 60f, VOLLEY_DAMAGE = 4.0f;
    private static final int VOLLEY_COOLDOWN = 50, VOLLEY_NEEDLES = 3;
    private static final double VOLLEY_RANGE = 24.0, VOLLEY_MIN_RANGE = 4.5;
    private static final double PLANT_RANGE = 14.0;

    private static final class Minion {
        final boolean corpse;
        Goal teeth;
        Minion(boolean corpse) { this.corpse = corpse; }
    }

    private final Map<UUID, Minion> minions = new LinkedHashMap<>();
    private int volleyReady, plantReady;

    public IllumiEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, STATS);
    }

    @Override
    protected boolean isAlly(Entity e) {
        return minions.containsKey(e.getUUID());
    }

    @Override
    protected void tickHatsu(@Nullable LivingEntity target, boolean fighting) {
        if (!(level() instanceof ServerLevel sl)) return;
        if (!canUseNen()) { // Forced Zetsu / Chain Jail / no aura: the needles fall out
            if (!minions.isEmpty()) releaseAll();
            return;
        }
        if (!minions.isEmpty() && tickCount % 10 == 0) controlMinions(sl, fighting ? target : null);
        if (!fighting || target == null) return;
        double d = distanceTo(target);
        if (tickCount % 10 == 0 && tickCount >= plantReady) tryPlant(sl, target);
        if (d >= VOLLEY_MIN_RANGE && d <= VOLLEY_RANGE && tickCount >= volleyReady && hasLineOfSight(target)) volley(sl, target);
    }

    // ---------------- the opener: a volley of needles ----------------
    private void volley(ServerLevel sl, LivingEntity target) {
        if (!payAura(VOLLEY_COST)) return;
        volleyReady = tickCount + VOLLEY_COOLDOWN;
        swingArm();
        Vec3 from = getEyePosition();
        Vec3 to = target.getEyePosition().subtract(0, target.getBbHeight() * 0.25, 0);
        Vec3 dir = to.subtract(from).normalize();
        double len = from.distanceTo(to);
        for (int n = 0; n < VOLLEY_NEEDLES; n++) {
            Vec3 d = dir.add((random.nextDouble() - 0.5) * 0.05, (random.nextDouble() - 0.5) * 0.05, (random.nextDouble() - 0.5) * 0.05).normalize();
            for (double s = 1.0; s < len; s += 0.6) {
                Vec3 p = from.add(d.scale(s));
                sl.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
            }
            target.invulnerableTime = 0; // each needle lands on its own
            hatsuHurt(target, VOLLEY_DAMAGE);
        }
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1)); // needles in the nerves
        sl.sendParticles(ParticleTypes.ENCHANTED_HIT, target.getX(), target.getEyeY(), target.getZ(), 10, 0.2, 0.2, 0.2, 0.2);
        sl.playSound(null, blockPosition(), SoundEvents.CHAIN_PLACE, SoundSource.HOSTILE, 1.0f, 1.9f);
    }

    // ---------------- Corpse Control / Needle People ----------------
    private int count(boolean corpse) {
        int n = 0;
        for (Minion m : minions.values()) if (m.corpse == corpse) n++;
        return n;
    }

    private void tryPlant(ServerLevel sl, LivingEntity target) {
        boolean wantCorpse = count(true) < MAX_CORPSES;
        boolean wantPeople = count(false) < MAX_PEOPLE && auraFraction() > 0.45f && stats.hatsu >= Tuning.NEEDLES_PEOPLE_MIN_LEVEL;
        if (!wantCorpse && !wantPeople) return;
        Mob best = null;
        double bd = Double.MAX_VALUE;
        for (Mob m : sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(PLANT_RANGE), this::plantable)) {
            boolean corpse = Puppeteer.isValidTarget(m);
            if (corpse ? !wantCorpse : !wantPeople) continue;
            if (!hasLineOfSight(m)) continue;
            double dist = m.distanceToSqr(this);
            if (dist < bd) { bd = dist; best = m; }
        }
        if (best == null) return;
        boolean corpse = Puppeteer.isValidTarget(best);
        if (!payAura(corpse ? Tuning.NEEDLES_CORPSE_COST : Tuning.NEEDLES_PEOPLE_COST)) return;
        plant(sl, best, corpse);
    }

    private boolean plantable(Mob m) {
        return m != this && m.isAlive() && m != getTarget() && !(m instanceof NenFighter) && !(m instanceof CookieEntity)
            && !(m instanceof BystanderEntity) && !m.getType().is(Tags.EntityTypes.BOSSES) && !minions.containsKey(m.getUUID())
            && !IllumiNeedles.isControlled(m) && !Puppeteer.isPuppet(m) && !BlackVoice.isAntenna(m) && SkillHunter.controllerOf(m.getUUID()) == null;
    }

    private void plant(ServerLevel sl, Mob m, boolean corpse) {
        plantReady = tickCount + Tuning.NEEDLES_COOLDOWN_TICKS;
        Minion minion = new Minion(corpse);
        minions.put(m.getUUID(), minion);
        m.setPersistenceRequired();
        m.setTarget(null);
        if (!corpse) minion.teeth = giveTeeth(m);
        AddonNetwork.sendToTracking(new PacketNeedleFx(m.getId(), corpse ? IllumiNeedles.FOREHEAD : IllumiNeedles.SKULL), m);
        swingArm();
        Vec3 from = getEyePosition(), to = m.getEyePosition();
        Vec3 dir = to.subtract(from).normalize();
        for (double s = 1.0; s < from.distanceTo(to); s += 0.6) {
            Vec3 p = from.add(dir.scale(s));
            sl.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
        sl.sendParticles(ParticleTypes.CRIT, m.getX(), m.getEyeY(), m.getZ(), 12, 0.2, 0.2, 0.2, 0.3);
        sl.playSound(null, blockPosition(), SoundEvents.CHAIN_PLACE, SoundSource.HOSTILE, 1.0f, 1.9f);
        sl.playSound(null, m.blockPosition(), SoundEvents.BONE_MEAL_USE, SoundSource.HOSTILE, 1.0f, 0.6f);
    }

    /** A mob that cannot hurt anything gets a plain melee goal (as the player's Needle People does). */
    @Nullable
    private static Goal giveTeeth(Mob m) {
        if (!(m instanceof PathfinderMob pm) || pm.getAttribute(Attributes.ATTACK_DAMAGE) == null) return null;
        boolean armed = pm.goalSelector.getAvailableGoals().stream().anyMatch(w -> w.getGoal() instanceof MeleeAttackGoal
            || w.getGoal() instanceof net.minecraft.world.entity.ai.goal.RangedAttackGoal
            || w.getGoal() instanceof net.minecraft.world.entity.ai.goal.RangedBowAttackGoal<?>
            || w.getGoal() instanceof net.minecraft.world.entity.ai.goal.RangedCrossbowAttackGoal<?>);
        if (armed) return null;
        Goal teeth = new MeleeAttackGoal(pm, 1.2, true);
        pm.goalSelector.addGoal(2, teeth);
        return teeth;
    }

    private void controlMinions(ServerLevel sl, @Nullable LivingEntity target) {
        for (UUID id : new ArrayList<>(minions.keySet())) {
            Entity e = sl.getEntity(id);
            if (e == null || !e.isAlive()) {
                release(sl, id, e);
                continue;
            }
            if (!(e instanceof Mob m)) continue;
            if (minions.get(id).corpse && m.isOnFire() && !m.isInLava()) m.clearFire(); // the needle keeps the body from burning up
            if (target != null && target.isAlive() && m.canAttack(target)) {
                m.setTarget(target);
                continue;
            }
            m.setTarget(null);
            double d = m.distanceTo(this);
            if (d > Tuning.NEEDLES_TELEPORT_DISTANCE) {
                m.teleportTo(getX() + (random.nextDouble() - 0.5) * 3, getY(), getZ() + (random.nextDouble() - 0.5) * 3);
                m.getNavigation().stop();
            } else if (d > Tuning.NEEDLES_FOLLOW_DISTANCE) {
                m.getNavigation().moveTo(this, 1.2);
            } else {
                m.getNavigation().stop();
            }
        }
    }

    private void release(ServerLevel sl, UUID id, @Nullable Entity e) {
        Minion minion = minions.remove(id);
        if (e instanceof Mob m) {
            m.setTarget(null);
            if (minion != null && minion.teeth != null) m.goalSelector.removeGoal(minion.teeth);
        }
        if (e != null) AddonNetwork.sendToTracking(new PacketNeedleFx(e.getId(), IllumiNeedles.OFF), e);
    }

    private void releaseAll() {
        if (minions.isEmpty() || !(level() instanceof ServerLevel sl)) {
            minions.clear();
            return;
        }
        for (UUID id : new ArrayList<>(minions.keySet())) release(sl, id, sl.getEntity(id));
        minions.clear();
    }

    @Override
    protected void onFightEnd() {
        releaseAll(); // the needles come out
    }

    @Override
    protected void onAuraGone() {
        releaseAll();
    }
}
