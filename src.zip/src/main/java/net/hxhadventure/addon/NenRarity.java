package net.hxhadventure.addon;

import java.util.Random;

/**
 * Aura colour roll. Colour is rolled first when Nen awakens and nothing else affects it (not talent, not type).
 * <p>
 * Colour ids are HxHAdventure's: 1 gold, 2 light blue, 3 red, 4 dark blue, 5 green, 6 purple, 7 pink, 8 white, 9 black,
 * then 10 yellow, 11 silver, 12 lime, 13 cyan, 14 coral, 15 teal, 16 grey, 17 forest, 18 maroon, 19 indigo, 20 midnight.
 * The darker a new colour is, the rarer it is (yellow is the most common new one, midnight the rarest; black stays the rarest of all).
 * With the game rule hxhrarenencolours on, white (8) is removed and every other colour is equally likely.
 */
public final class NenRarity {
    private NenRarity() {}

    public static final int WHITE = 8;

    /**
     * Relative weight of each colour id (index = id - 1). The first nine are the original odds (they added up to 100); the eleven new
     * colours add about 19.9 on top, so the chance of a colour is its weight divided by the total (about 119.9).
     */
    private static final double[] COLOUR_PERCENT = {19.0, 8.5, 6.6, 6.0, 15.2, 4.7, 11.4, 28.4, 0.2,
        4.0, 2.6, 3.5, 3.0, 2.0, 1.6, 1.2, 0.9, 0.5, 0.35, 0.25};

    /** Rolls an aura colour id (1-20). rareOnly = game rule hxhrarenencolours. */
    public static int rollColour(Random rnd, boolean rareOnly) {
        double[] w = new double[COLOUR_PERCENT.length];
        double total = 0;
        for (int i = 0; i < w.length; i++) {
            w[i] = rareOnly ? (i + 1 == WHITE ? 0.0 : 1.0) : COLOUR_PERCENT[i];
            total += w[i];
        }
        double r = rnd.nextDouble() * total;
        for (int i = 0; i < w.length; i++) {
            if (w[i] <= 0) continue;
            r -= w[i];
            if (r < 0) return i + 1;
        }
        return rareOnly ? 9 : WHITE; // only reached by rounding; any valid id will do
    }
}
