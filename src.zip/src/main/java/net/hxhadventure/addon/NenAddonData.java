package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketEnPulse;
import net.hxhadventure.addon.network.PacketSyncAddon;
import net.hxhadventure.entity.custom.KiteEntity;

/** Server-side per-player addon state: skills, Zetsu, En, aura buffs (Ten / Ren / Ken / Ko), auto-Ten. */
public final class NenAddonData {
    public static final String TAG = "HxHCraftAddon";
    private static final Map<Player, NenAddonData> CACHE = new WeakHashMap<>();

    /** Speed from Ten / Ren / Ken (one modifier: the current aura state decides the amount). */
    private static final UUID AURA_SPEED = UUID.fromString("a1000000-0000-4000-8000-000000000011");
    private static final UUID AFF_SPEED = UUID.fromString("a1000000-0000-4000-8000-000000000004");
    private static final UUID AGE_HP = UUID.fromString("a1000000-0000-4000-8000-000000000006");
    private static final UUID AFF_KB = UUID.fromString("a1000000-0000-4000-8000-000000000005");
    private static final UUID EMPEROR_SPEED = UUID.fromString("a1000000-0000-4000-8000-000000000010");

    private final Player player;
    public boolean zetsu;
    public boolean en;
    /** In (hides your Nen) and Gyo (sees hidden Nen, reads grades). Transient, like En. */
    public boolean in;
    public boolean gyo;
    /** Shu (aura coating on weapons). Transient, like En. */
    public boolean shu;
    /** Genius In only: the player chose to let their Nen show even while In is on. Persisted. */
    public boolean inVisible;
    private int inSent = -1;
    private String gyoSent = "";
    private int gyoSentTick;
    public boolean emperor;
    /** Skill Hunter book: 0 none, 1 closed (bookmark held), 2 open. */
    public int bookState;
    public int bookmark = -1;
    public int activePage = -1;
    /** Bit k set = the Hatsu of kit k has been stolen into the book. Persisted. */
    public int stolenMask;
    /** True while a Skill Hunter user is wearing a stolen kit (persisted so a relog restores kit 9). */
    public boolean hostKit;
    /** Kit currently borrowed from a stolen page (0 = none). Transient. */
    public int stolenKit;
    /** The book item is in the owner's inventory. Transient. */
    public boolean bookHeld;
    public float lifespan = Tuning.LIFESPAN_MAX;
    private int emperorCd;
    public float enRadius;
    /** Radius picked with the En slider on the Mastery screen (-1 = never set: 50 blocks, or less if En level does not allow it). */
    public float enChosen = -1f;
    /** Ren aura size picked with the slider (1 = normal; never more than Tuning.renMaxSize for the Ren skill level). */
    public float renSize = 1f;
    /** Aura forms. Ken and Ko toggle on their own, but they are alternatives to each other and to Ren: switching one on switches the others off. Transient. */
    public boolean ken;
    public boolean ko;
    private final int[] level = new int[NenSkill.values().length];
    /** Ids of the Conditions, Limitations and Vows this player has sworn (see Vows). Permanent. */
    public final java.util.LinkedHashSet<String> vows = new java.util.LinkedHashSet<>();
    /** Prayers followed by an attack (the "I must pray before every attack" Condition). Hidden: never shown to the player. Permanent. */
    public int prayers;
    /** Reborn as a Chimera Ant (died holding Crazy Slots' staff): 40 base health and double basic attacks, for good. Permanent. */
    public boolean chimera;
    /** Died holding the staff: the rebirth happens when the player respawns. Permanent until then. */
    public boolean chimeraPending;
    private final float[] xp = new float[NenSkill.values().length];
    private int formCooldown;
    /** A Ren / Ken / Ko switch waiting out its delay (see Tuning.switchDelayTicks). Transient. */
    private net.hxhadventure.addon.network.PacketAddonAction.Action pendingSwitch;
    private int switchTicks;
    public int hitXpCooldown;
    private int seconds;
    private float lastEnergy = -1f;
    private int lastPulseSize;
    /** Last Emperor Time state broadcast to nearby players (-1 = never sent). */
    private int emperorSent = -1;
    /** True while this player's Hatsu is the Chains (drives the chains on the right hand). */
    public boolean chainHand;
    private int chainHandSent = -1;
    /** Lifespan the max-health penalty is currently based on. Frozen while Emperor Time runs so the drain never hurts. */
    private float hpLifespan = Tuning.LIFESPAN_MAX;
    private boolean dirtySync = true;
    private boolean dirtySave;
    /** Last aura form broadcast to nearby players. */
    private AuraForm formSent = AuraForm.NONE;

    private NenAddonData(Player player) {
        this.player = player;
        java.util.Arrays.fill(level, 1);
        load();
    }

    public static NenAddonData get(Player p) {
        return CACHE.computeIfAbsent(p, NenAddonData::new);
    }

    public static NenAddonData peek(Player p) {
        return CACHE.get(p);
    }

    // ---------- persistence ----------
    private void load() {
        CompoundTag root = player.getPersistentData();
        if (!root.contains(TAG)) return;
        CompoundTag t = root.getCompound(TAG);
        for (NenSkill s : NenSkill.values()) {
            level[s.ordinal()] = Math.max(1, Math.min(NenSkill.MAX_LEVEL, t.getInt("lvl_" + s.name())));
            xp[s.ordinal()] = t.getFloat("xp_" + s.name());
        }
        lifespan = t.contains("lifespan") ? t.getFloat("lifespan") : Tuning.LIFESPAN_MAX;
        stolenMask = t.getInt("sh_stolen");
        hostKit = t.getBoolean("sh_host");
        enChosen = t.contains("en_chosen") ? t.getFloat("en_chosen") : -1f;
        renSize = t.contains("ren_size") ? t.getFloat("ren_size") : 1f;
        inVisible = t.getBoolean("in_visible");
        prayers = Math.max(0, t.getInt("prayers"));
        chimera = t.getBoolean("chimera");
        chimeraPending = t.getBoolean("chimera_pending");
        vows.clear();
        net.minecraft.nbt.ListTag vl = t.getList("vows", 8);
        for (int i = 0; i < vl.size(); i++) {
            if (Vows.RULES.containsKey(vl.getString(i))) vows.add(vl.getString(i)); // rules that no longer exist (the standing-still Conditions) are dropped
        }
    }

    public void save() {
        CompoundTag t = new CompoundTag();
        for (NenSkill s : NenSkill.values()) {
            t.putInt("lvl_" + s.name(), borrowedLv != null ? borrowedLv[s.ordinal()] : level[s.ordinal()]);   // a borrowed set is never saved
            t.putFloat("xp_" + s.name(), borrowedXp != null ? borrowedXp[s.ordinal()] : xp[s.ordinal()]);
        }
        t.putFloat("lifespan", lifespan);
        t.putInt("sh_stolen", stolenMask);
        t.putBoolean("sh_host", hostKit);
        t.putFloat("en_chosen", enChosen);
        t.putFloat("ren_size", renSize);
        t.putBoolean("in_visible", inVisible);
        net.minecraft.nbt.ListTag vl = new net.minecraft.nbt.ListTag();
        for (String v : vows) vl.add(net.minecraft.nbt.StringTag.valueOf(v));
        t.put("vows", vl);
        t.putInt("prayers", prayers);
        t.putBoolean("chimera", chimera);
        t.putBoolean("chimera_pending", chimeraPending);
        player.getPersistentData().put(TAG, t);
        dirtySave = false;
    }

    public void markSync() { dirtySync = true; }

    public void markSave() { dirtySave = true; }

    // ---------- skills ----------
    public int level(NenSkill s) { return level[s.ordinal()]; }

    /**
     * The level the skill actually performs at: the trained level raised by any Vows sworn on it (so it can pass 100).
     * In and Gyo only work by comparing levels, so their Conditions and Limitations raise it too.
     */
    public int effLevel(NenSkill s) {
        return Vows.effLevel(player, s, level[s.ordinal()]);
    }

    /** Vows: is this skill or form (a NenSkill name, KEN or KO) switched on right now. */
    public boolean vowActive(String key, Combat c) {
        return switch (key) {
            case "TEN" -> c.isTenActive();
            case "ZETSU" -> zetsu;
            case "REN" -> c.isAuraActive();
            case "EN" -> en;
            case "IN" -> in;
            case "GYO" -> gyo;
            case "SHU" -> shu;
            case "KEN" -> ken;
            case "KO" -> ko;
            default -> false;
        };
    }

    /** Vows: a sworn rule forces this skill or form off. */
    public void vowSwitchOff(ServerPlayer sp, String key, String msg) {
        switch (key) {
            case "TEN" -> net.hxhadventure.abilities.AbilityRegistry.toggleTen(sp, false); // it comes back by itself once the rule allows it
            case "ZETSU" -> setZetsu(sp, false, msg);
            case "REN" -> net.hxhadventure.abilities.AbilityRegistry.toggleRen(sp, false);
            case "EN" -> setEn(sp, false, msg);
            case "IN" -> setIn(sp, false, msg);
            case "GYO" -> setGyo(sp, false, msg);
            case "SHU" -> setShu(sp, false, msg);
            case "KEN" -> {
                if (ken) { ken = false; formOff(sp, msg); }
            }
            case "KO" -> {
                if (ko) { ko = false; formOff(sp, msg); }
            }
            default -> { }
        }
    }

    public float progress(NenSkill s) {
        int l = level[s.ordinal()];
        return l >= NenSkill.MAX_LEVEL ? 1f : xp[s.ordinal()] / NenSkill.xpToNext(l);
    }

    /** Black Voice: the real skill levels while another body's set is borrowed (null = nothing borrowed). */
    private int[] borrowedLv;
    private float[] borrowedXp;

    public boolean skillsBorrowed() { return borrowedLv != null; }

    /** Black Voice: wear an NPC's skill levels (Ten, Ren, En, Gyo, In...). Your own are kept aside, saved in place of the borrowed ones, and come back with {@link #returnSkills}. */
    public void borrowSkills(int[] lv) {
        if (borrowedLv != null) return;
        borrowedLv = level.clone();
        borrowedXp = xp.clone();
        for (int i = 0; i < level.length; i++) {
            level[i] = Math.max(1, Math.min(NenSkill.MAX_LEVEL, lv[i]));
            xp[i] = 0f;
        }
        afterSkillSwap();
    }

    public void returnSkills() {
        if (borrowedLv == null) return;
        System.arraycopy(borrowedLv, 0, level, 0, level.length);
        System.arraycopy(borrowedXp, 0, xp, 0, xp.length);
        borrowedLv = null;
        borrowedXp = null;
        afterSkillSwap();
        save();
    }

    private void afterSkillSwap() {
        if (en && player instanceof ServerPlayer) {
            Combat c = Combat.get(player);
            if (c != null) recomputeRadius(c);
        }
        dirtySync = true;
    }

    public void addXp(NenSkill s, float amount, Combat combat) {
        if (borrowedLv != null) return; // nothing is learned in somebody else's body
        int i = s.ordinal();
        dbgXpCalls++;
        if (level[i] >= NenSkill.MAX_LEVEL || amount <= 0) return;
        float talentMult = player instanceof ServerPlayer ? NenProfile.talent(player).xpMult : 1f; // talent: more XP
        float typeXp = (s == NenSkill.GYO || s == NenSkill.IN) ? Affinity.gyoInXpMult(effType(combat)) : 1f;
        xp[i] += amount * Affinity.skillXpMult(effType(combat)) * typeXp * talentMult;
        while (level[i] < NenSkill.MAX_LEVEL && xp[i] >= NenSkill.xpToNext(level[i])) {
            xp[i] -= NenSkill.xpToNext(level[i]);
            level[i]++;
            if (player instanceof ServerPlayer sp) {
                sp.displayClientMessage(Component.literal("\u00a7a" + s.label + " increased to " + level[i]), true);
                sp.level().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6f, 1.4f);
            }
        }
        if (level[i] >= NenSkill.MAX_LEVEL) xp[i] = 0;
        dirtySync = true;
        dirtySave = true;
    }

    /** Admin/command hook: set a skill to an exact level (progress to next level resets). */
    public void setLevel(NenSkill s, int newLevel) {
        int i = s.ordinal();
        level[i] = Math.max(1, Math.min(NenSkill.MAX_LEVEL, newLevel));
        xp[i] = 0;
        if (en && player instanceof ServerPlayer) {
            Combat c = Combat.get(player);
            if (c != null) recomputeRadius(c);
        }
        dirtySync = true;
        save();
    }

    public void addXp(NenSkill s, float amount) {
        Combat c = Combat.get(player);
        if (c != null) addXp(s, amount, c);
    }

    // ---------- aura buffs and forms: Ten / Ren / Ken / Ko ----------
    /** Ken or Ko is currently on (and Zetsu is not). */
    public boolean formActive(Combat c) {
        return !zetsu && (ken || ko);
    }

    /** Ten's current bonus as a fraction (0.2 = +20%), from the Ten skill level. See Tuning.tenBonus. */
    public float tenBonus() {
        return Tuning.tenBonus(effLevel(NenSkill.TEN)) * Vows.power(player, "TEN") * BlackVoice.autoPilotMult(player); // Auto Pilot: x2 (Ren builds on Ten, so it doubles too)
    }

    /**
     * Fraction ADDED to the damage this player deals (0.2 = +20%). Zetsu: none. Ko: melee only, Ten is gone.
     * Otherwise Ken, Ren or plain Ten, whichever is on (they are alternatives).
     */
    public float auraDamageBonus(Combat c, boolean melee) {
        if (zetsu) return 0f;
        float b = tenBonus();
        if (ko) return melee ? b * Tuning.KO_DAMAGE_SHARE : 0f;
        if (ken) return b * Tuning.KEN_DAMAGE_SHARE;
        if (c.isAuraActive()) return b * Tuning.REN_TEN_MULT * Vows.power(player, "REN");
        if (c.isTenActive()) return b;
        return 0f;
    }

    /** Fraction ADDED to durability (damage taken is divided by 1 + this). Ko and Zetsu: none. */
    public float auraDurabilityBonus(Combat c) {
        if (zetsu || ko) return 0f;
        float b = tenBonus();
        if (ken) return b * Tuning.KEN_DURABILITY_SHARE;
        if (c.isAuraActive()) return b * Tuning.REN_TEN_MULT * Vows.power(player, "REN");
        if (c.isTenActive()) return b;
        return 0f;
    }

    /** Ten's current movement-speed bonus as a fraction, from the Ten skill level (its own, slower curve: see Tuning.tenSpeedBonus). */
    public float tenSpeedBonus() {
        return Tuning.tenSpeedBonus(effLevel(NenSkill.TEN)) * Vows.power(player, "TEN") * BlackVoice.autoPilotMult(player);
    }

    /** Fraction ADDED to movement speed. Ko and Zetsu: none. */
    public float auraSpeedBonus(Combat c) {
        if (zetsu || ko) return 0f;
        float b = tenSpeedBonus();
        if (ken) return b * Tuning.KEN_SPEED_SHARE;
        if (c.isAuraActive()) return b * Tuning.REN_TEN_MULT * Vows.power(player, "REN");
        if (c.isTenActive()) return b;
        return 0f;
    }

    /** What Ren gives (as a fraction added), whether or not Ren is on right now: damage, durability and speed. Used by Gon's adult form. */
    public float renDamageBonus() { return tenBonus() * Tuning.REN_TEN_MULT * Vows.power(player, "REN"); }

    public float renDurabilityBonus() { return renDamageBonus(); }

    public float renSpeedBonus() { return tenSpeedBonus() * Tuning.REN_TEN_MULT * Vows.power(player, "REN"); }

    /** What Ko gives to melee damage (as a fraction added), whether or not Ko is on right now. */
    public float koDamageBonus() { return tenBonus() * Tuning.KO_DAMAGE_SHARE; }

    /** Ko's melee multiplier (1 + 2 x Ten's bonus): what Jajanken's Rock, Scissors and Paper use while the aura is all in the fist. */
    public float koMeleeMult() {
        return 1f + tenBonus() * Tuning.KO_DAMAGE_SHARE;
    }

    /** The basic Nen actions that are NOT Hatsu: attacks and the Ten / Ren toggles. Every other ability id is a Hatsu ability. */
    public static boolean isBasicAbility(String id) {
        return switch (id) {
            case "nen_attack", "nen_strong", "nen_strong_release", "nen_barrage", "ten_toggle", "ren_toggle" -> true;
            default -> false;
        };
    }

    /** Called when a Hatsu ability is used: using Hatsu in Zetsu drops you out of it at once (Ten comes straight back). */
    public void leaveZetsuForHatsu(ServerPlayer sp) {
        if (zetsu && !ChainManager.isJailed(sp) && !HatsuEffects.has(sp)) setZetsu(sp, false, "\u00a77Hatsu: you left Zetsu");
    }

    /**
     * Multiplier on a Hatsu ability's damage: Hatsu scales on the Hatsu level alone, so Ten, Ren and Ken add nothing here.
     * Ko still does, but only at {@link Tuning#KO_HATSU_SHARE} of its bonus (a +600% Ko adds +150% to Hatsu damage).
     */
    public float hatsuFormMult(Combat c) {
        return ko ? 1f + auraDamageBonus(c, true) * Tuning.KO_HATSU_SHARE : 1f;
    }

    /** Multiplier on damage this player deals. {@code melee} is true for direct hits (not projectiles or summons). */
    public float outgoingFormMult(Combat c, boolean melee) {
        return 1f + auraDamageBonus(c, melee);
    }

    /** Multiplier on damage this player takes: durability divides it, and Ko leaves the body wide open. */
    public float incomingFormMult(Combat c) {
        float m = 1f / (1f + auraDurabilityBonus(c));
        if (ko && !zetsu) m *= Tuning.KO_INCOMING_MULT;
        return m;
    }

    /**
     * Switching from one aura state (Ren / Ken / Ko) to a different one waits Tuning.switchDelayTicks(level) first:
     * 0.5s at level 0, shrinking to nothing at level 100. Returns true if the switch was queued (the caller must not apply it now).
     * Turning a state on from nothing, or off, is never delayed.
     */
    public boolean delaySwitch(ServerPlayer sp, Combat c, net.hxhadventure.addon.network.PacketAddonAction.Action target) {
        var A = net.hxhadventure.addon.network.PacketAddonAction.Action.class;
        boolean ren = c.isAuraActive();
        boolean inState = ren || ken || ko;
        boolean sameAsCurrent = (target == Enum.valueOf(A, "TOGGLE_REN") && ren)
            || (target == Enum.valueOf(A, "TOGGLE_KEN") && ken)
            || (target == Enum.valueOf(A, "TOGGLE_KO") && ko);
        if (!inState || sameAsCurrent) return false;
        if (formLocked(c, target)) return false; // let perform() show the "unlocks at level" message right away
        int delay = Tuning.switchDelayTicks(totalMastery() / (float) NenSkill.values().length);
        if (delay <= 0) return false;
        if (pendingSwitch == null) switchTicks = delay; // a second press only changes the target, the timer keeps running
        pendingSwitch = target;
        return true;
    }

    /** Combined level of every Nen skill (Ten, Zetsu, Ren, En, Hatsu, In, Gyo): total Nen mastery. */
    public int totalMastery() {
        int sum = 0;
        for (NenSkill s : NenSkill.values()) sum += effLevel(s);
        return sum;
    }

    private static boolean formLocked(Combat c, net.hxhadventure.addon.network.PacketAddonAction.Action target) {
        var A = net.hxhadventure.addon.network.PacketAddonAction.Action.class;
        return (target == Enum.valueOf(A, "TOGGLE_KEN") || target == Enum.valueOf(A, "TOGGLE_KO")) && c.getHatsuLevel() < Tuning.FORM_MIN_HATSU_LEVEL;
    }

    /** Counts down a queued switch and applies it when the delay is over. */
    private void tickSwitch(ServerPlayer sp) {
        if (pendingSwitch == null) return;
        if (!sp.isAlive()) { pendingSwitch = null; return; }
        if (--switchTicks > 0) return;
        var action = pendingSwitch;
        pendingSwitch = null;
        net.hxhadventure.addon.network.PacketAddonAction.perform(sp, action);
    }

    private boolean formGate(ServerPlayer sp) {
        if (formCooldown > 0) return false;
        formCooldown = Tuning.FORM_COOLDOWN_TICKS;
        return true;
    }

    /** Switch every form off (the caller decides what, if anything, to tell the player). */
    private void clearForms() {
        if (!ken && !ko) return;
        ken = false;
        ko = false;
        dirtySync = true;
    }

    private void formOn(ServerPlayer sp, String msg, float pitch) {
        if (zetsu) setZetsu(sp, false, null);
        // Ren is the full-power aura; a form is the same power focused. They are alternatives, so a form replaces Ren.
        Combat c = Combat.get(sp);
        if (c != null && c.isAuraActive()) net.hxhadventure.abilities.AbilityRegistry.toggleRen(sp, false);
        dirtySync = true;
        sp.displayClientMessage(Component.literal(msg), true);
    }

    private void formOff(ServerPlayer sp, String msg) {
        dirtySync = true;
        sp.displayClientMessage(Component.literal(msg), true);
    }

    private static boolean formUnlocked(ServerPlayer sp, String name) {
        Combat c = Combat.get(sp);
        if (c != null && c.getHatsuLevel() < Tuning.FORM_MIN_HATSU_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7c" + name + " unlocks at Level " + Tuning.FORM_MIN_HATSU_LEVEL), true);
            return false;
        }
        return true;
    }

    private static float maxAura(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        return c == null ? 0f : c.getMaxEnergy();
    }

    private boolean canPayForm(ServerPlayer sp, float upkeep, String name) {
        Combat c = Combat.get(sp);
        if (c != null && c.getCurrentEnergy() < upkeep) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy for " + name), true);
            return false;
        }
        return true;
    }

    /** Ken (key): Ren and Ten together. Much more durability, but you give up a fifth of Ten's damage. */
    public void toggleKen(ServerPlayer sp) {
        if (Vows.shuForcedForm(sp, this) != null) { // a Shu Vow holds the aura form in place
            sp.displayClientMessage(Component.literal("\u00a74Vow: \u00a77Shu is on, so your aura form is fixed"), true);
            return;
        }
        if (!ken && Vows.refuseLocked(sp, "KEN")) return;
        if (!ken && !formUnlocked(sp, "Ken")) return;
        if (!formGate(sp)) return;
        if (ken) {
            ken = false;
            formOff(sp, "\u00a73Ken is off");
            return;
        }
        if (!canPayForm(sp, Tuning.kenUpkeep(maxAura(sp)), "Ken")) return;
        clearForms();
        ken = true;
        formOn(sp, "\u00a7bKen is active", 1.2f);
    }

    /** Ko (key): out of Ten, all aura in the right arm. Double Ten's damage, no speed or durability. */
    public void toggleKo(ServerPlayer sp) {
        String forced = Vows.shuForcedForm(sp, this);
        if (forced != null && (ko || !"KO".equals(forced))) { // Ko cannot be dropped under a forced Ko, nor taken while Ren is forced
            sp.displayClientMessage(Component.literal("\u00a74Vow: \u00a77Shu is on, so your aura form is fixed"), true);
            return;
        }
        if (!ko && Vows.refuseLocked(sp, "KO")) return;
        if (!ko && !formUnlocked(sp, "Ko")) return;
        if (!formGate(sp)) return;
        if (ko) {
            ko = false;
            formOff(sp, "\u00a7cKo is off");
            return;
        }
        if (!canPayForm(sp, Tuning.koUpkeep(maxAura(sp)), "Ko")) return;
        clearForms();
        ko = true;
        formOn(sp, "\u00a7cKo is active", 0.8f);
    }

    private static String pct(float fraction) {
        return String.format(java.util.Locale.ROOT, "%.1f", fraction * 100f);
    }

    // ---------- Jajanken: Rock hooks (save the aura state, enforce Ko, put everything back) ----------
    /** The aura state a player was in before Rock, so it can be put back afterwards. */
    public static final class AuraSnapshot {
        public final boolean ren, ken, ko, zetsu;

        AuraSnapshot(boolean ren, boolean ken, boolean ko, boolean zetsu) {
            this.ren = ren;
            this.ken = ken;
            this.ko = ko;
            this.zetsu = zetsu;
        }
    }

    public AuraSnapshot snapshotAura(Combat c) {
        return new AuraSnapshot(c.isAuraActive(), ken, ko, zetsu);
    }

    /** Rock starts: Ren and Zetsu are dropped so the max-size flare is the only aura out (the snapshot remembers them). */
    public void clearForRockFlare(ServerPlayer sp) {
        if (zetsu) setZetsu(sp, false, null);
        Combat c = Combat.get(sp);
        if (c != null && c.isAuraActive()) net.hxhadventure.abilities.AbilityRegistry.toggleRen(sp, false);
        clearForms();
    }

    /** Rock's aura is all in the fist: Ko is switched on for real (no cooldown, no upkeep check), replacing any other form or Ren. */
    public void enforceKo(ServerPlayer sp) {
        if (zetsu) setZetsu(sp, false, null);
        Combat c = Combat.get(sp);
        if (c != null && c.isAuraActive()) net.hxhadventure.abilities.AbilityRegistry.toggleRen(sp, false);
        if (ko && !ken) return;
        ken = false;
        ko = true;
        dirtySync = true;
    }

    /** Takes Rock's Ko away without bringing anything back (death, logout, Hatsu lost). */
    public void dropEnforcedKo() {
        if (!ko) return;
        ko = false;
        dirtySync = true;
    }

    /** Rock is over: the player goes back to exactly what they were in (Ren, Ken, Ko, Zetsu or nothing). */
    public void restoreAura(ServerPlayer sp, AuraSnapshot s) {
        ko = false;
        ken = false;
        dirtySync = true;
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (s.zetsu) {
            setZetsu(sp, true, null);
        } else if (s.ren) {
            if (!c.isAuraActive()) net.hxhadventure.abilities.AbilityRegistry.toggleRen(sp, true);
        } else {
            ken = s.ken;
            ko = s.ko;
        }
    }

    // ---------- aura form visuals ----------
    /** The aura form to draw right now (NONE while Zetsu hides the aura). */
    public AuraForm auraForm(Combat c) {
        return formActive(c) ? AuraForm.of(ken, ko) : AuraForm.NONE;
    }

    /** Tells nearby players which Ten-style aura form this player is in, so the right zones light up (no separate body aura any more). */
    private void syncFormVisuals(ServerPlayer sp, AuraForm f) {
        if (!sp.isAlive()) f = AuraForm.NONE; // a dead player's body shows no aura
        if (f != formSent) {
            formSent = f;
            AddonNetwork.sendToTrackingAndSelf(new net.hxhadventure.addon.network.PacketAuraForm(sp.getId(), f), sp);
        }
    }

    /** What a player who has just started tracking this one needs to see their aura form. */
    public AuraForm formSent() { return formSent; }

    /** Clears the form's aura for everyone nearby (logout, death). */
    public void clearFormAura() {
        if (formSent != AuraForm.NONE) {
            formSent = AuraForm.NONE;
            if (player instanceof ServerPlayer sp) AddonNetwork.sendToTrackingAndSelf(new net.hxhadventure.addon.network.PacketAuraForm(sp.getId(), AuraForm.NONE), sp);
        }
    }

    // ---------- Zetsu / En ----------
    public float zetsuPenalty() { return Tuning.zetsuDamagePenalty(effLevel(NenSkill.ZETSU)); }
    public float zetsuStealthRange() { return Tuning.zetsuStealthRange(effLevel(NenSkill.ZETSU)); }

    /** Forced into Zetsu without the "Zetsu: On" message (a secret Chain Jail must not tell its victim). */
    public void setZetsuQuiet(ServerPlayer sp) {
        quietZetsu = true;
        try { setZetsu(sp, true, null); } finally { quietZetsu = false; }
    }

    private boolean quietZetsu;

    public void setZetsu(ServerPlayer sp, boolean on, String msg) {
        if (zetsu == on) return;
        zetsu = on;
        dirtySync = true;
        if (on) {
            // Zetsu ends every Hatsu mode (Godspeed, Skill Hunter's book) EXCEPT Emperor Time and "I'll use everything.", which carry on
            if (LightningAura.isGodspeed(sp)) LightningAura.endGodspeed(sp);
            if (PainPacker.isArmored(sp)) PainPacker.endForZetsu(sp);
            if (bookState != 0) SkillHunter.clear(sp);
            if (en) setEn(sp, false, null);
            if (in) setIn(sp, false, null);
            if (gyo) setGyo(sp, false, null);
            if (shu) setShu(sp, false, null);
            Combat c = Combat.get(sp);
            if (c.isTenActive()) net.hxhadventure.abilities.AbilityRegistry.applyTen(sp, false, true);
            if (c.isAuraActive()) net.hxhadventure.abilities.AbilityRegistry.toggleRen(sp, false);
            clearForms();
            refreshModifiers(sp, c);
            if (!quietZetsu) sp.displayClientMessage(Component.literal("\u00a77Zetsu: On"), true);
            LaplaceDevil.onZetsu(sp, true); // Tserriednich's Laplace Devil opens when its user enters Zetsu
        } else {
            LaplaceDevil.onZetsu(sp, false); // ...and closes when they leave it
            sp.displayClientMessage(Component.literal(msg != null ? msg : "\u00a77Zetsu: Off"), true);
            // Ten comes straight back: no waiting for the next automatic check
            Combat c = Combat.get(sp);
            if (c != null && c.hasNenUnlocked()) {
                autoTen(sp, c);
                refreshModifiers(sp, c);
            }
        }
    }

    public void setEn(ServerPlayer sp, boolean on, String msg) {
        if (en == on) return;
        Combat c = Combat.get(sp);
        if (on) {
            if (Vows.refuseLocked(sp, "EN")) return;
            if (c.getHatsuLevel() < Tuning.EN_MIN_HATSU_LEVEL) {
                sp.displayClientMessage(Component.literal("\u00a7cEn unlocks at Level " + Tuning.EN_MIN_HATSU_LEVEL), true);
                return;
            }
            recomputeRadius(c);
            if (c.getCurrentEnergy() < Tuning.enUpkeep(enRadius, effLevel(NenSkill.EN))) {
                sp.displayClientMessage(Component.literal("\u00a7cNot enough energy for En"), true);
                return;
            }
            if (zetsu) setZetsu(sp, false, null);
            en = true;
            sp.displayClientMessage(Component.literal("\u00a7dEn: On (radius " + Math.round(enRadius) + ")"), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.5f, 1.8f);
        } else {
            en = false;
            sp.displayClientMessage(Component.literal(msg != null ? msg : "\u00a7dEn: Off"), true);
            AddonNetwork.sendToPlayer(new PacketEnPulse(new int[0], new byte[0]), sp);
            lastPulseSize = 0;
        }
        dirtySync = true;
    }

    /** True while this player's Hatsu constructs (Chains, Bungee Gum) are invisible to anyone without Gyo. */
    public boolean hiddenNow() {
        return in && !(inVisible && effLevel(NenSkill.IN) >= Tuning.IN_VISIBILITY_LEVEL);
    }

    public void setIn(ServerPlayer sp, boolean on, String msg) {
        if (in == on) return;
        Combat c = Combat.get(sp);
        if (on) {
            if (Vows.refuseLocked(sp, "IN")) return;
            if (Vows.shuForbids(sp, this, "IN")) {
                sp.displayClientMessage(Component.literal("\u00a74Vow: \u00a77Shu is on, so your In is disabled"), true);
                return;
            }
            if (c.getHatsuLevel() < Tuning.IN_MIN_HATSU_LEVEL) {
                sp.displayClientMessage(Component.literal("\u00a7cIn unlocks at Level " + Tuning.IN_MIN_HATSU_LEVEL), true);
                return;
            }
            if (c.getCurrentEnergy() < Tuning.IN_UPKEEP) {
                sp.displayClientMessage(Component.literal("\u00a7cNot enough energy for In"), true);
                return;
            }
            if (zetsu) setZetsu(sp, false, null);
            in = true;
            sp.displayClientMessage(Component.literal("\u00a75In: On"), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.4f, 0.6f);
        } else {
            in = false;
            sp.displayClientMessage(Component.literal(msg != null ? msg : "\u00a75In: Off"), true);
        }
        dirtySync = true;
    }

    public void setGyo(ServerPlayer sp, boolean on, String msg) {
        if (gyo == on) return;
        Combat c = Combat.get(sp);
        if (on) {
            if (Vows.refuseLocked(sp, "GYO")) return;
            if (Vows.shuForbids(sp, this, "GYO")) {
                sp.displayClientMessage(Component.literal("\u00a74Vow: \u00a77Shu is on, so your Gyo is disabled"), true);
                return;
            }
            if (c.getHatsuLevel() < Tuning.IN_MIN_HATSU_LEVEL) {
                sp.displayClientMessage(Component.literal("\u00a7cGyo unlocks at Level " + Tuning.IN_MIN_HATSU_LEVEL), true);
                return;
            }
            if (c.getCurrentEnergy() < Tuning.GYO_UPKEEP) {
                sp.displayClientMessage(Component.literal("\u00a7cNot enough energy for Gyo"), true);
                return;
            }
            if (zetsu) setZetsu(sp, false, null);
            gyo = true;
            sp.displayClientMessage(Component.literal("\u00a7eGyo: On"), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.4f, 1.9f);
        } else {
            gyo = false;
            sp.displayClientMessage(Component.literal(msg != null ? msg : "\u00a7eGyo: Off"), true);
            gyoSent = "";
            AddonNetwork.sendToPlayer(new net.hxhadventure.addon.network.PacketGyoInfo(-1, ""), sp);
        }
        dirtySync = true;
    }

    public void setShu(ServerPlayer sp, boolean on, String msg) {
        if (shu == on) return;
        Combat c = Combat.get(sp);
        if (on) {
            if (Vows.refuseLocked(sp, "SHU")) return;
            if (c.getCurrentEnergy() < Tuning.SHU_UPKEEP) {
                sp.displayClientMessage(Component.literal("\u00a7cNot enough energy for Shu"), true);
                return;
            }
            if (zetsu) setZetsu(sp, false, null);
            shu = true;
            sp.displayClientMessage(Component.literal("\u00a76Shu: On"), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.4f, 1.4f);
        } else {
            shu = false;
            sp.displayClientMessage(Component.literal(msg != null ? msg : "\u00a76Shu: Off"), true);
        }
        dirtySync = true;
    }

    /** The "show my Nen" slider (Genius In and above). */
    public void setInVisible(boolean visible) {
        if (effLevel(NenSkill.IN) < Tuning.IN_VISIBILITY_LEVEL) visible = false;
        inVisible = visible;
        dirtySync = true;
        dirtySave = true;
    }

    /** Everyone who can see this player learns whether their Nen is currently hidden. */
    private void syncInFx(ServerPlayer sp) {
        int now = hiddenNow() ? 1 : 0;
        if (now == inSent) return;
        inSent = now;
        AddonNetwork.sendToTrackingAndSelf(new net.hxhadventure.addon.network.PacketInFx(sp.getId(), now == 1), sp);
    }

    /** Gyo: reads the grade of the player in the crosshair, only as far as this player's own Gyo grade reaches. */
    private void gyoScan(ServerPlayer sp) {
        net.minecraft.world.entity.Entity e = ChainManager.rayEntity(sp, Tuning.GYO_RANGE, x -> x instanceof Player p && p != sp && !p.isSpectator());
        int id = -1;
        String text = "";
        if (e instanceof Player p) {
            id = p.getId();
            Combat pc = Combat.get(p);
            NenAddonData od = peek(p);
            if (pc != null && pc.hasNenUnlocked() && !(od != null && od.zetsu)) {
                int target = Tuning.gradeRank(pc.getHatsuLevel());
                int mine = Tuning.gradeRank(effLevel(NenSkill.GYO));
                text = target <= mine
                    ? "\u00a76Grade: \u00a7e" + Tuning.GRADE_NAMES[target]
                    : "\u00a76Grade: \u00a78???  \u00a77(beyond your Gyo)";
            }
        }
        String key = id + ":" + text;
        if (key.equals(gyoSent) && sp.tickCount - gyoSentTick < 40) return; // unchanged: refresh now and then so it stays on screen
        gyoSent = key;
        gyoSentTick = sp.tickCount;
        AddonNetwork.sendToPlayer(new net.hxhadventure.addon.network.PacketGyoInfo(id, text), sp);
    }

    private void recomputeRadius(Combat c) {
        enRadius = Tuning.enSelectedRadius(enChosen, Tuning.enRadius(effLevel(NenSkill.EN), Affinity.enRadiusMult(effType(c)))) * Vows.power(player, "EN");
        enRadius = Math.min(enRadius, Vows.enRadiusLimit(player)); // sworn: En reaches 1 or 4 meters and no further
    }

    /** The aura size actually used for Ren: the slider's pick, between 1x and what the Ren skill level allows. */
    public float renScale() {
        if (GonVow.isActive(player)) return GonVow.REN_SIZE; // Gon's adult form: the Ren aura is 10x
        return Math.max(1f, Math.min(renSize, Tuning.renMaxSize(effLevel(NenSkill.REN))));
    }

    /**
     * Ren's involuntary flare: it appears at the biggest size this player could set it to, plus 30%, then shrinks to the size they
     * have chosen. In hides it: every In level pulls the flare back towards the chosen size, and at In 100 Ren appears at exactly the
     * size it is set to (no flare at all; the aura treats an intro that is not bigger than the set size as none).
     */
    public float renIntroScale() {
        float set = renScale();
        float flare = Math.max(Tuning.renMaxSize(effLevel(NenSkill.REN)), set) * 1.3f;
        float hidden = Math.max(0f, Math.min(1f, effLevel(NenSkill.IN) / (float) NenSkill.MAX_LEVEL));
        return flare + (set - flare) * hidden;
    }

    /** The Ren size slider moved: remember it and resize a Ren aura that is already out. */
    public void setRenSize(ServerPlayer sp, float size) {
        renSize = Math.max(1f, Math.min(Tuning.renMaxSize(effLevel(NenSkill.REN)), size)); // see Tuning.renMaxSize: 3x at level 100, 4x at 110, 5x at 120, no cap
        net.hxhadventure.abilities.AbilityRegistry.setActiveAuraScale(sp, renScale());
        dirtySync = true;
        dirtySave = true;
    }

    /**
     * Rules were lifted (Hina): anything that was sized by them is recalculated at once instead of waiting for the player to
     * toggle it. En's radius goes back to what the En level allows, and a Ren aura that is already out shrinks to the size the
     * Ren level allows (before this it stayed at the old, vow-boosted size until the slider was touched).
     */
    public void refreshAfterVowChange(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        recomputeRadius(c);
        if (c.isAuraActive()) net.hxhadventure.abilities.AbilityRegistry.setActiveAuraScale(sp, renScale());
        dirtySync = true;
        dirtySave = true;
    }

    /** The En slider moved: remember the radius (applied at once while En is on; the cost follows from the new radius). */
    public void setEnChosen(float radius) {
        enChosen = Math.max(1f, Math.min(1000f, radius));
        Combat c = Combat.get(player);
        if (en && c != null) recomputeRadius(c);
        dirtySync = true;
        dirtySave = true;
    }

    // ---------- lifespan ----------
    /**
     * Max health used to follow lifespan; now it does not (Tuning.AGE_MAX_HP_LOSS is 0), so this only clears the old "Lifespan lost" modifier.
     * Set AGE_MAX_HP_LOSS above 0 to bring the penalty back. While Emperor Time or Gon's vow is running that penalty is frozen, and the years they
     * burn only turn into lost max health once the form ends (otherwise health would be forced down every second and the client shows every drop as a hit).
     */
    private void applyLifespanHealth(ServerPlayer sp) {
        if (!emperor && !GonVow.isActive(player)) hpLifespan = lifespan; // Emperor Time and Gon's vow both freeze the max-health drop while they last
        double aged = Math.min(Tuning.AGE_MAX_HP_LOSS, (1.0 - Math.max(0f, hpLifespan) / Tuning.LIFESPAN_MAX) * Tuning.AGE_MAX_HP_LOSS);
        setMod(sp, Attributes.MAX_HEALTH, AGE_HP, "Lifespan lost", -aged, AttributeModifier.Operation.MULTIPLY_TOTAL);
        float max = sp.getMaxHealth();
        if (sp.isAlive() && sp.getHealth() > max) sp.setHealth(max);
    }

    /** Admin/command hook: set the remaining years of life (0 to the maximum). */
    public void setLifespan(float years) {
        lifespan = Math.max(0f, Math.min(Tuning.LIFESPAN_MAX, years));
        if (player instanceof ServerPlayer sp) {
            if (emperor && lifespan < Tuning.EMPEROR_YEARS_PER_SECOND) setEmperor(sp, false, "\u00a77Emperor Time ended: no life left to spend");
            hpLifespan = lifespan; // an explicit edit applies at once
            applyLifespanHealth(sp);
        }
        dirtySync = true;
        save();
    }

    /** The Chains kit shows as chains wrapped on the right hand for everyone who can see this player. */
    private void syncChainHand(ServerPlayer sp, Combat c) {
        chainHand = c.hasNenUnlocked() && c.getCurrentKit() == ChainManager.CHAINS_KIT;
        int now = chainHand ? 1 : 0;
        if (now == chainHandSent) return;
        chainHandSent = now;
        AddonNetwork.sendToTrackingAndSelf(new net.hxhadventure.addon.network.PacketChainHand(sp.getId(), chainHand), sp);
    }

    /** Tell everyone who can see this player that Emperor Time started or stopped, and re-apply the passives right away. */
    private void syncEmperorFx(ServerPlayer sp, Combat c) {
        int now = emperor ? 1 : 0;
        if (now == emperorSent) return;
        emperorSent = now;
        AddonNetwork.sendToTrackingAndSelf(new net.hxhadventure.addon.network.PacketEmperorFx(sp.getId(), emperor), sp);
        if (c.hasNenUnlocked()) refreshModifiers(sp, c);
    }

    // ---------- Emperor Time ----------
    /** The Nen type used for affinity passives: every type at once during Emperor Time. */
    public int effType(Combat c) {
        return emperor ? Affinity.ALL : c.getNenType();
    }

    public void toggleEmperor(ServerPlayer sp, Combat c) {
        if (emperor) {
            setEmperor(sp, false, "\u00a77Emperor Time ended");
            return;
        }
        if (c.getCurrentKit() != ChainManager.CHAINS_KIT) return;
        if (c.getHatsuLevel() < Tuning.EMPEROR_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cEmperor Time unlocks at Level " + Tuning.EMPEROR_MIN_LEVEL), true);
            return;
        }
        if (ChainManager.onCooldown(sp, "Emperor Time", emperorCd)) return;
        if (lifespan < Tuning.EMPEROR_YEARS_PER_SECOND) {
            sp.displayClientMessage(Component.literal("\u00a7cYou have no life left to spend"), true);
            return;
        }
        if (ChainManager.isJailed(sp)) return;
        if (zetsu) setZetsu(sp, false, null);
        emperor = true;
        dirtySync = true;
        sp.displayClientMessage(Component.literal("\u00a74\u00a7lEMPEROR TIME"), true);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.PLAYERS, 0.8f, 1.4f);
    }

    /**
     * The Nen is gone for good (Gon's vow debt reached its limit): every skill back to Level 1 with no progress, every state
     * (Zetsu, En, In, Gyo, Emperor Time, forms, Skill Hunter's book and stolen Hatsu) off, every slider back to its default.
     * Lifespan is left alone: it belongs to the body, not the Nen. Combat's own state (kit, Nen type, Hatsu level) is reset by {@link NenLoss}.
     */
    public void wipeForNenLoss(ServerPlayer sp) {
        java.util.Arrays.fill(level, 1);
        java.util.Arrays.fill(xp, 0f);
        closeNodes(sp);
    }

    /** Everything that is switched on or held by the Nen is reset, but skill levels and XP are kept (nodes closed, not forgotten). */
    public void closeNodes(ServerPlayer sp) {
        zetsu = false;
        en = false;
        in = false;
        gyo = false;
        shu = false;
        emperor = false;
        emperorCd = 0;
        ken = false;
        ko = false;
        bookState = 0;
        bookmark = -1;
        activePage = -1;
        stolenMask = 0;
        hostKit = false;
        stolenKit = 0;
        bookHeld = false;
        enChosen = -1f;
        enRadius = 0f;
        renSize = 1f;
        inVisible = false;
        hitXpCooldown = 0;
        lastPulseSize = 0;
        gyoSent = "";
        AddonNetwork.sendToPlayer(new PacketEnPulse(new int[0], new byte[0]), sp);
        AddonNetwork.sendToPlayer(new net.hxhadventure.addon.network.PacketGyoInfo(-1, ""), sp);
        clearFormAura();
        dirtySync = false;
        AddonNetwork.sendToPlayer(new PacketSyncAddon(this), sp); // tick() stops syncing for a player without Nen, so send the reset now
        save();
    }

    /** A new life: full lifespan, Emperor Time off and ready. */
    public void resetLifespan() {
        lifespan = Tuning.LIFESPAN_MAX;
        emperor = false;
        emperorCd = 0;
        dirtySync = true;
        save();
    }

    public void setEmperor(ServerPlayer sp, boolean on, String msg) {
        if (emperor == on) return;
        emperor = on;
        dirtySync = true;
        if (!on) {
            emperorCd = Tuning.EMPEROR_COOLDOWN_TICKS;
            ChainManager.startCooldown(sp, "Emperor Time", Tuning.EMPEROR_COOLDOWN_TICKS);
            dirtySave = true;
            if (msg != null) sp.displayClientMessage(Component.literal(msg), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.6f, 0.7f);
        }
    }

    /** One second of Emperor Time: pay the years, die if there are none left. */
    private void emperorSecond(ServerPlayer sp) {
        lifespan = Math.max(0f, lifespan - Tuning.EMPEROR_YEARS_PER_SECOND);
        dirtySync = true;
        save(); // years are never refunded by a crash or relog
        if (lifespan <= Tuning.LIFESPAN_EMPTY) {
            lifespan = 0f;
            setEmperor(sp, false, null);
            sp.displayClientMessage(Component.literal("\u00a74Your lifespan is exhausted..."), true);
            sp.hurt(sp.level().damageSources().genericKill(), Float.MAX_VALUE);
        }
    }

    // ---------- /hxh debug ----------
    private int dbgTicks, dbgNoCombat, dbgPastUnlock, dbgSeconds, dbgXpCalls;

    /** Lines for /hxh debug: where the per-tick code gets to, what holds Ten down, and the skill levels and XP. */
    public java.util.List<String> debugReport(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        java.util.List<String> out = new ArrayList<>();
        out.add("event handler: START calls=" + AddonServerEvents.Game.dbgStartCalls + " (server player: " + AddonServerEvents.Game.dbgStartServer
            + ")  END calls=" + AddonServerEvents.Game.dbgEndCalls + "  last error=" + AddonServerEvents.Game.dbgError);
        out.add("tick() calls: " + dbgTicks + "  (combat null: " + dbgNoCombat + ")  past the unlocked check: " + dbgPastUnlock
            + "  perSecond calls: " + dbgSeconds + "  addXp calls: " + dbgXpCalls);
        if (c == null) { out.add("Combat is null"); return out; }
        out.add("kit=" + c.getCurrentKit() + " nenUnlocked=" + c.hasNenUnlocked() + " nenType=" + c.getNenType()
            + " Level=" + c.getHatsuLevel() + " tenActive=" + c.isTenActive() + " renActive=" + c.isAuraActive());
        out.add("zetsu=" + zetsu + " en=" + en + " in=" + in + " gyo=" + gyo + " ken=" + ken + " ko=" + ko + " emperor=" + emperor);
        out.add("holds Ten down: jailed=" + ChainManager.isJailed(sp) + " forcedZetsu=" + HatsuEffects.has(sp)
            + " vowBlock=" + Vows.tenBlocked(sp, this) + " hatsuForced=" + ExtrasHooks.hatsuForced(sp)
            + " possessing=" + BlackVoice.isPossessing(sp) + " vows=" + vows.size());
        out.add("talent=" + NenProfile.talent(sp).label + " (xp x" + NenProfile.talent(sp).xpMult + ")  energy=" + Math.round(c.getCurrentEnergy()) + "/" + Math.round(c.getMaxEnergy()));
        StringBuilder sb = new StringBuilder("skills: ");
        for (NenSkill s : NenSkill.values()) {
            sb.append(s.label).append(' ').append(level[s.ordinal()]).append(" (").append(Math.round(xp[s.ordinal()] * 10f) / 10f).append(" xp)  ");
        }
        out.add(sb.toString());
        return out;
    }

    // ---------- tick ----------
    public void tick(ServerPlayer sp) {
        dbgTicks++;
        Combat c = Combat.get(sp);
        if (c == null) { dbgNoCombat++; return; }
        syncEmperorFx(sp, c);
        syncChainHand(sp, c);
        syncInFx(sp);
        applyLifespanHealth(sp);
        if (!c.hasNenUnlocked()) {
            if (formSent != AuraForm.NONE) syncFormVisuals(sp, AuraForm.NONE);
            if (zetsu || en || in || gyo || shu || emperor || bookState != 0 || ken || ko) { zetsu = false; en = false; in = false; gyo = false; shu = false; emperor = false; ken = false; ko = false; bookState = 0; bookmark = -1; activePage = -1; dirtySync = true; }
            setMod(sp, Attributes.MOVEMENT_SPEED, AURA_SPEED, "Aura speed", 0, AttributeModifier.Operation.MULTIPLY_TOTAL);
            setMod(sp, Attributes.MOVEMENT_SPEED, EMPEROR_SPEED, "Emperor Time speed", 0, AttributeModifier.Operation.MULTIPLY_TOTAL);
            applyJump(sp, 0);
            return;
        }
        dbgPastUnlock++;
        int t = sp.tickCount;
        if (formCooldown > 0) formCooldown--;
        tickSwitch(sp);
        if (hitXpCooldown > 0) hitXpCooldown--;
        if (emperorCd > 0) emperorCd--;
        SkillHunter.tick(sp, c, this);

        accountEnergy(c);
        if (emperor && (ChainManager.isJailed(sp) || c.getCurrentKit() != ChainManager.CHAINS_KIT)) setEmperor(sp, false, "\u00a77Emperor Time broken");
        if (!ChainManager.isJailed(sp) && HatsuEffects.has(sp)) { // Forced Zetsu from /effect etc.
            clearForms();
            if (c.isTenActive()) net.hxhadventure.abilities.AbilityRegistry.toggleTen(sp, false);
            if (c.isAuraActive()) net.hxhadventure.abilities.AbilityRegistry.toggleRen(sp, false);
        }
        if (ChainManager.isJailed(sp)) {
            // Chained: Ten and Ren are refused at the source (AbilityRegistryMixin / CombatMixin), so they never
            // flicker on. This is only a silent safety net for anything that was already active when the chain landed.
            clearForms();
            if (c.isTenActive()) net.hxhadventure.abilities.AbilityRegistry.toggleTen(sp, false);
            if (c.isAuraActive()) net.hxhadventure.abilities.AbilityRegistry.toggleRen(sp, false);
            if (en) setEn(sp, false, "\u00a77Chain Jail seals your En");
            if (!zetsu) setZetsu(sp, true, null);
        } else if (zetsu && (c.isTenActive() || c.isAuraActive())) setZetsu(sp, false, "\u00a77Zetsu broken");
        if (formActive(c) && c.isAuraActive()) { // Ren was switched on after the form: Ren replaces it, never both
            clearForms();
            sp.displayClientMessage(Component.literal("\u00a7bRen replaces your aura form"), true);
        }
        syncFormVisuals(sp, auraForm(c));
        if (t % 2 == 0) Vows.tick(sp, this, c);
        autoTen(sp, c);               // every tick: Ten is back the moment nothing holds it down
        refreshModifiers(sp, c);      // every tick: speed follows the aura state straight away
        if (t % 20 == 0) perSecond(sp, c);
        if (en && t % 10 == 0) pulse(sp, c);
        if (gyo && t % 5 == 0) gyoScan(sp);

        if (dirtySync && t % 5 == 0) {
            dirtySync = false;
            AddonNetwork.sendToPlayer(new PacketSyncAddon(this), sp);
        }
        if (dirtySave && t % 200 == 0) save();
        lastEnergy = c.getCurrentEnergy();
    }

    /**
     * Ten is always on for a Nen user. It only stays off while Zetsu, Chain Jail, Forced Zetsu or a sworn rule holds it down.
     * It switches back on silently (no message, sound or flash) the moment nothing holds it any more.
     * Skill Hunter's book and Emperor Time never affect it.
     */
    private void autoTen(ServerPlayer sp, Combat c) {
        if (c.isTenActive()) return;
        boolean blocked = zetsu || ChainManager.isJailed(sp) || HatsuEffects.has(sp) || Vows.tenBlocked(sp, this);
        if (!blocked) net.hxhadventure.abilities.AbilityRegistry.applyTen(sp, true, true);
    }

    private void accountEnergy(Combat c) {
        float cur = c.getCurrentEnergy();
        if (lastEnergy >= 0) {
            float drop = lastEnergy - cur - c.takeUpkeepSpent();
            if (drop >= Tuning.ABILITY_COST_THRESHOLD) {
                float pct = Math.min(0.5f, Tuning.hatsuRefund(effLevel(NenSkill.HATSU)) * Vows.power(player, "HATSU") + Affinity.abilityRefund(effType(c)));
                if (pct > 0) c.restoreEnergy(drop * pct);
                addXp(NenSkill.HATSU, Math.min(10f, drop / 50f), c);
            }
        }
    }

    private void perSecond(ServerPlayer sp, Combat c) {
        dbgSeconds++;
        seconds++;
        if (emperor) emperorSecond(sp);
        if (!sp.isAlive()) return;
        int type = effType(c);
        if (c.isTenActive()) {
            c.restoreEnergy(Tuning.tenRegen(effLevel(NenSkill.TEN)) * Vows.power(player, "TEN") * (1f + Affinity.regenBonus(type)) * MagicalEsthetician.regenMult(player));
            if (seconds % 4 == 0) addXp(NenSkill.TEN, 1f, c);
        }
        if (c.isAuraActive()) {
            float refund = Tuning.renUpkeep(c.getMaxEnergy()) * Math.min(0.6f, effLevel(NenSkill.REN) * 0.003f + Affinity.renRefund(type));
            if (refund > 0) c.restoreEnergy(refund);
            addXp(NenSkill.REN, 1f, c);
        }
        float bonus = Affinity.regenBonus(type);
        if (bonus > 0) c.restoreEnergy(c.getScaledRegeneration() * bonus);
        if (formActive(c)) {
            float base = ko ? Tuning.koUpkeep(c.getMaxEnergy()) : Tuning.kenUpkeep(c.getMaxEnergy());
            float cost = base * (1f - Math.min(0.5f, Affinity.efficiency(type)));
            if (c.getCurrentEnergy() < cost) {
                String name = ko ? "Ko" : "Ken";
                clearForms();
                sp.displayClientMessage(Component.literal("\u00a7cEnergy depleted! " + name + " deactivated."), true);
            } else {
                c.consumeEnergy(cost);
            }
        }
        if (zetsu) {
            float piano = MagicalEsthetician.regenMult(player); // Piano Massage
            c.restoreEnergy(Tuning.zetsuRegen(effLevel(NenSkill.ZETSU), effLevel(NenSkill.TEN)) * Vows.power(player, "ZETSU") * piano);
            c.restoreEnergy(c.getMaxEnergy() * Tuning.ZETSU_REGEN_PCT * piano);
            float gain = 0.5f;
            float range = zetsuStealthRange();
            AABB box = sp.getBoundingBox().inflate(16);
            for (Mob m : sp.level().getEntitiesOfClass(Mob.class, box)) {
                if (m instanceof Enemy) gain = 1.0f;
                if (m.getTarget() == sp && m.distanceToSqr(sp) > range * range) m.setTarget(null);
            }
            addXp(NenSkill.ZETSU, gain, c);
        }
        if (in) {
            float inCost = Tuning.IN_UPKEEP * (1f - Math.min(0.5f, Affinity.efficiency(type)));
            if (c.getCurrentEnergy() < inCost) {
                setIn(sp, false, "\u00a7cEnergy depleted! In deactivated.");
            } else {
                c.consumeEnergy(inCost);
                addXp(NenSkill.IN, 1f, c);
            }
        }
        if (gyo) {
            float gyoCost = Tuning.GYO_UPKEEP * (1f - Math.min(0.5f, Affinity.efficiency(type)));
            if (c.getCurrentEnergy() < gyoCost) {
                setGyo(sp, false, "\u00a7cEnergy depleted! Gyo deactivated.");
            } else {
                c.consumeEnergy(gyoCost);
                addXp(NenSkill.GYO, gyoSent.startsWith("-1:") || gyoSent.isEmpty() ? 1f : 1.5f, c);
            }
        }
        if (shu) {
            float shuCost = Tuning.SHU_UPKEEP * (1f - Math.min(0.5f, Affinity.efficiency(type)));
            if (c.getCurrentEnergy() < shuCost) {
                setShu(sp, false, "\u00a7cEnergy depleted! Shu deactivated.");
            } else {
                c.consumeEnergy(shuCost);
                addXp(NenSkill.SHU, 1f, c);
            }
        }
        if (en) {
            recomputeRadius(c);
            float cost = Tuning.enUpkeep(enRadius, effLevel(NenSkill.EN)) * (1f - Math.min(0.5f, Affinity.efficiency(type)));
            if (c.getCurrentEnergy() < cost) {
                setEn(sp, false, "\u00a7cEnergy depleted! En deactivated.");
            } else {
                c.consumeEnergy(cost);
                // Practice: 1 XP/s while En is held, +50% while it is actually sensing something.
                addXp(NenSkill.EN, lastPulseSize > 0 ? 1.5f : 1f, c);
            }
            dirtySync = true;
        }
    }

    private void pulse(ServerPlayer sp, Combat c) {
        double r = enRadius;
        AABB box = sp.getBoundingBox().inflate(r);
        List<LivingEntity> found = new ArrayList<>();
        for (LivingEntity e : sp.level().getEntitiesOfClass(LivingEntity.class, box)) {
            if (e == sp || !e.isAlive() || e instanceof ArmorStand) continue;
            double d2 = e.distanceToSqr(sp);
            if (d2 > r * r) continue;
            if (e instanceof Player p) {
                if (p.isSpectator()) continue;
                NenAddonData od = peek(p);
                if (od != null && od.zetsu && d2 > 9.0) continue; // Zetsu hides from En beyond 3 blocks
                Combat pc = Combat.get(p);
                if (pc != null && pc.hasNenUnlocked() && od != null && od.in) {
                    // Only In hides you from En (your Hatsu level no longer does): a detector whose En level is HIGHER
                    // than your In level can still sense you. Manipulators resist a little more (threshold 10% lower).
                    float threshold = Affinity.enImmune(od.effType(pc))
                        ? Affinity.MANIPULATOR_EN_THRESHOLD : Affinity.BASE_EN_THRESHOLD;
                    if (od.effLevel(NenSkill.IN) >= effLevel(NenSkill.EN) * threshold) continue;
                }
            }
            found.add(e);
        }
        found.sort((a, b) -> Double.compare(a.distanceToSqr(sp), b.distanceToSqr(sp)));
        if (found.size() > Tuning.EN_MAX_ENTITIES) found = found.subList(0, Tuning.EN_MAX_ENTITIES);
        int[] ids = new int[found.size()];
        byte[] cats = new byte[found.size()];
        for (int i = 0; i < ids.length; i++) {
            ids[i] = found.get(i).getId();
            cats[i] = (byte) categorize(found.get(i));
        }
        if (ids.length > 0 || lastPulseSize > 0) AddonNetwork.sendToPlayer(new PacketEnPulse(ids, cats), sp);
        lastPulseSize = ids.length;
    }

    /** 0 passive, 1 hostile, 2 regular player, 3 Nen user / Nen construct. */
    private static int categorize(LivingEntity e) {
        if (e instanceof Player p) {
            Combat pc = Combat.get(p);
            return pc != null && pc.hasNenUnlocked() ? 3 : 2;
        }
        if (e instanceof KiteEntity) return 3;
        if (e instanceof Enemy) return 1;
        return 0;
    }

    private void refreshModifiers(ServerPlayer sp, Combat c) {
        int type = effType(c);
        // Ten / Ren / Ken speed (Ko and Zetsu: none). Durability and damage are applied when damage is dealt or taken (AddonServerEvents.onHurt).
        double auraSpeed = auraSpeedBonus(c) * Tuning.BUFF_SPEED_SCALE;
        setMod(sp, Attributes.MOVEMENT_SPEED, AURA_SPEED, "Aura speed", auraSpeed, AttributeModifier.Operation.MULTIPLY_TOTAL);
        setMod(sp, Attributes.MOVEMENT_SPEED, AFF_SPEED, "Affinity speed", Affinity.speedBonus(type), AttributeModifier.Operation.MULTIPLY_TOTAL);
        // Emperor Time: x1.5 movement speed, multiplied on top of every other speed modifier.
        setMod(sp, Attributes.MOVEMENT_SPEED, EMPEROR_SPEED, "Emperor Time speed", emperor ? Tuning.EMPEROR_BOOST - 1.0 : 0, AttributeModifier.Operation.MULTIPLY_TOTAL);
        setMod(sp, Attributes.KNOCKBACK_RESISTANCE, AFF_KB, "Affinity knockback", Affinity.knockbackResist(type), AttributeModifier.Operation.ADDITION);
        // Jump Boost: II while Ten's speed is on, V during Godspeed (never below a stronger potion the player already has)
        applyJump(sp, LightningAura.isGodspeed(sp) ? Tuning.GODSPEED_JUMP_BOOST_LEVEL : auraSpeed > 0 ? Tuning.TEN_JUMP_BOOST_LEVEL : 0);
    }

    private boolean jumpGiven;

    /** Keeps a hidden, short Jump Boost running at this level (1 = Jump Boost I); 0 takes ours away. */
    private void applyJump(ServerPlayer sp, int level) {
        MobEffectInstance cur = sp.getEffect(MobEffects.JUMP);
        if (level <= 0) {
            if (jumpGiven && cur != null && cur.isAmbient() && !cur.isVisible()) sp.removeEffect(MobEffects.JUMP);
            jumpGiven = false;
            return;
        }
        int amp = level - 1;
        boolean ours = jumpGiven && cur != null && cur.isAmbient() && !cur.isVisible();
        if (cur != null && cur.getAmplifier() > amp) {
            if (!ours) return;                // a stronger Jump Boost from elsewhere wins
            sp.removeEffect(MobEffects.JUMP); // our own higher one (Godspeed just ended): step down at once
        }
        if (cur != null && cur.getAmplifier() == amp && cur.getDuration() > 10) { jumpGiven = true; return; }
        sp.addEffect(new MobEffectInstance(MobEffects.JUMP, 30, amp, true, false, false));
        jumpGiven = true;
    }

    private static void setMod(Player p, Attribute attr, UUID id, String name, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(attr);
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(id);
        if (Math.abs(amount) < 1e-6) {
            if (cur != null) inst.removeModifier(id);
            return;
        }
        if (cur != null && Math.abs(cur.getAmount() - amount) < 1e-6) return;
        if (cur != null) inst.removeModifier(id);
        inst.addTransientModifier(new AttributeModifier(id, name, amount, op));
    }
}
