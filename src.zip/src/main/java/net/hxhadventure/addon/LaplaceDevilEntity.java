package net.hxhadventure.addon;

import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraftforge.network.NetworkHooks;

/**
 * The Laplace Devil itself: planted {@link LaplaceDevilTuning#DEVIL_HEIGHT} blocks above the user, it never moves, cannot be hit, pushed
 * or targeted, and makes no sound. It is only drawn for people the domain does not affect (see LaplaceFx / LaplaceDevilRenderer).
 */
public class LaplaceDevilEntity extends Entity {
    private UUID owner;

    public LaplaceDevilEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.noCulling = true;
        this.setNoGravity(true);
        this.setInvulnerable(true);
        this.setSilent(true);
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
    }

    public UUID getOwnerId() {
        return owner;
    }

    @Override
    protected void defineSynchedData() {}

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public void tick() {
        // it does not move: no baseTick physics, only the guard that removes it when its domain is gone
        if (!level().isClientSide && (owner == null || !LaplaceDevil.owns(owner, getUUID()))) {
            if (++tickCount > 20) discard();
        }
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
