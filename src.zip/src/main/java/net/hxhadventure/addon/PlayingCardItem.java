package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** A playing card: right click throws one (see {@link GumCards}). Crafted from paper, 1 paper for 1 card. */
public final class PlayingCardItem extends Item {
    public PlayingCardItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.sidedSuccess(stack, true);
        if (!(player instanceof ServerPlayer sp)) return InteractionResultHolder.pass(stack);
        if (sp.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);
        if (!GumCards.throwCard(sp)) return InteractionResultHolder.fail(stack);
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        sp.getCooldowns().addCooldown(this, Tuning.PLAYING_CARD_COOLDOWN_TICKS);
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}
