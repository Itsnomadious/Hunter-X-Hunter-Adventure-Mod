package net.hxhadventure.addon;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import org.joml.Vector3f;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Hide and Seek, Knov's Hatsu (Hatsu kit 20, an Emitter's): aura sent out to open doors into a space of the user's own.
 * <ul>
 *   <li><b>Hide and Seek</b> (Z, aimed at a block): draws a ring of symbols on the block's face. Walk into it and you are in the
 *       artificial Nen dimension, in a room of your own: an endless white box with blue grid lines ({@link NenRooms}). Rooms are all
 *       separate, differ in size, and each has an exit circle. The <b>Master Key</b> ({@link MasterKeyItem}) chooses the room a circle leads to.</li>
 *   <li><b>Scream</b> (Z, aimed at a target): the user clasps their hands and a portal opens in each, joined by a loop of aura. The loop
 *       flies out and wraps round the target; the user says "Close." and whatever was inside it is in the selected room. The loop is small,
 *       so it can be closed on just a body part: a head, a torso, an arm (and what it holds), a leg. Small creatures and loose items are taken whole.</li>
 * </ul>
 * Circles and captives end with their user: when they die or lose the Hatsu, the circles close and everyone held is sent back.
 */
public final class HideAndSeek {
    private HideAndSeek() {}

    public static final int KIT = 20;
    public static final String ID = "hide_and_seek";
    public static final String SCREAM_ID = "scream";

    private static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.40f, 0.70f, 1.0f), 1.1f);
    private static final DustParticleOptions NAVY = new DustParticleOptions(new Vector3f(0.04f, 0.08f, 0.22f), 1.5f);

    private static final Map<UUID, Long> CIRCLE_READY = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> SCREAM_READY = new ConcurrentHashMap<>();
    private static final Map<UUID, Scream> SCREAM = new ConcurrentHashMap<>();

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    public static void registerAll(Map<String, Consumer<ServerPlayer>> abilities) {
        abilities.put(ID, HideAndSeek::circle);
        abilities.put(SCREAM_ID, HideAndSeek::scream);
    }

    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c)) return base;
        int lvl = c.getHatsuLevel();
        String[] out = base;
        if (lvl >= Tuning.HIDESEEK_MIN_LEVEL) {
            out = Arrays.copyOf(out, out.length + 1);
            out[out.length - 1] = ID;
        }
        if (lvl >= Tuning.SCREAM_MIN_LEVEL) {
            out = Arrays.copyOf(out, out.length + 1);
            out[out.length - 1] = SCREAM_ID;
        }
        return out;
    }

    public static String displayName(String id) {
        return switch (id) {
            case ID -> "§9 Hide and Seek";
            case SCREAM_ID -> "§9 Scream";
            default -> null;
        };
    }

    /** Wipes this player's in-progress state (logout, death, a new Hatsu). */
    public static void clear(Player p) {
        SCREAM.remove(p.getUUID());
        CIRCLE_READY.remove(p.getUUID());
        SCREAM_READY.remove(p.getUUID());
    }

    /** The user died or lost the Hatsu: every circle closes and everyone they hold is sent back where they were taken from. */
    public static void onLost(ServerPlayer sp) {
        cancelScream(sp);
        if (sp.getServer() == null) return;
        NenRooms rooms = NenRooms.get(sp.getServer());
        rooms.releaseAllOf(sp.getServer(), sp.getUUID());
        rooms.closePortals(sp.getServer(), sp.getUUID());
    }

    // ---------------------------------------------------------------- shared checks

    private static Combat gate(ServerPlayer sp, int minLevel, String name) {
        Combat c = Combat.get(sp);
        if (c == null) return null;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("§cYour Hatsu is not Hide and Seek"), true);
            return null;
        }
        if (c.getHatsuLevel() < minLevel) {
            sp.displayClientMessage(Component.literal("§c" + name + " unlocks at Level " + minLevel), true);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("§5Forced Zetsu: your aura will not answer"), true);
            return null;
        }
        if (HatsuEffects.isStunned(sp)) return null;
        return c;
    }

    private static boolean ready(ServerPlayer sp, Map<UUID, Long> map, String name, long now) {
        long at = map.getOrDefault(sp.getUUID(), 0L);
        return !ChainManager.onCooldown(sp, name, (int) Math.max(0, at - now));
    }

    private static boolean pay(ServerPlayer sp, Combat c, float cost) {
        if (c.getCurrentEnergy() < cost) {
            sp.displayClientMessage(Component.literal("§cNot enough energy"), true);
            return false;
        }
        c.consumeEnergy(cost);
        return true;
    }

    private static void anim(ServerPlayer sp, String name) {
        ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(sp.getUUID(), name, false), sp);
    }

    // ---------------------------------------------------------------- the Master Key

    /** Called every tick: a Hide and Seek user always has a key of their own (a new one if it is lost). */
    private static void giveKey(ServerPlayer sp) {
        if (sp.tickCount % 40 != 7) return;
        Combat c = Combat.get(sp);
        if (!canUse(c) || c.getHatsuLevel() < Tuning.HIDESEEK_MIN_LEVEL || HideSeekItems.KEY == null) return;
        if (MasterKeyItem.hasOwnKey(sp)) return;
        for (int i = 0; i < sp.getEnderChestInventory().getContainerSize(); i++) { // a key put away in the ender chest is still theirs
            if (sp.getUUID().equals(MasterKeyItem.ownerOf(sp.getEnderChestInventory().getItem(i)))) return;
        }
        if (sp.getInventory().add(MasterKeyItem.create(sp))) {
            sp.displayClientMessage(Component.literal("§bYour Master Key"), true);
        }
    }

    // ---------------------------------------------------------------- Hide and Seek: the circle

    /** Z: draw a circle of symbols on the block you are looking at. Shift+Z: close the circle you are looking at. */
    public static void circle(ServerPlayer sp) {
        Combat c = gate(sp, Tuning.HIDESEEK_MIN_LEVEL, "Hide and Seek");
        if (c == null || !(sp.level() instanceof ServerLevel level) || sp.getServer() == null) return;
        if (sp.isShiftKeyDown()) { // Shift+Z: close the circle you are looking at
            removeCircle(sp, level);
            return;
        }
        if (!ready(sp, CIRCLE_READY, "Hide and Seek", level.getGameTime())) return;
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle();
        BlockHitResult hit = level.clip(new ClipContext(eye, eye.add(look.scale(Tuning.HIDESEEK_RANGE)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, sp));
        if (hit.getType() != HitResult.Type.BLOCK) {
            sp.displayClientMessage(Component.literal("§7Aim at a block to draw the circle on"), true);
            return;
        }
        Direction face = hit.getDirection();
        Vec3 centre = circleCentre(level, hit.getBlockPos(), face);
        // another circle already on this spot: only your own can be drawn over
        for (HideSeekPortalEntity old : level.getEntitiesOfClass(HideSeekPortalEntity.class, new AABB(centre, centre).inflate(1.4))) {
            if (old.facing() != face) continue;
            if (old.isExit() || (old.owner() != null && !old.owner().equals(sp.getUUID()))) {
                sp.displayClientMessage(Component.literal("§7There is already a circle here"), true);
                return;
            }
        }
        NenRooms rooms = NenRooms.get(sp.getServer());
        NenRooms.Room room = rooms.selectedRoom(sp.getUUID(), c.getHatsuLevel());
        if (room == null) {
            sp.displayClientMessage(Component.literal("§cYou cannot make a room"), true);
            return;
        }
        if (!pay(sp, c, Tuning.HIDESEEK_COST)) return;
        CIRCLE_READY.put(sp.getUUID(), level.getGameTime() + Tuning.HIDESEEK_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Hide and Seek", Tuning.HIDESEEK_COOLDOWN_TICKS);
        for (HideSeekPortalEntity old : level.getEntitiesOfClass(HideSeekPortalEntity.class, new AABB(centre, centre).inflate(1.4))) {
            if (old.facing() == face && !old.isExit()) {
                if (old.owner() != null) rooms.unregisterPortal(old.owner(), old.getUUID());
                old.discard();
            }
        }

        HideSeekPortalEntity circle = new HideSeekPortalEntity(HxHEntities.HIDE_SEEK_PORTAL.get(), level);
        circle.configure(face, centre, false, room.id, sp.getUUID());
        level.addFreshEntity(circle);
        rooms.registerPortal(sp.getServer(), sp.getUUID(), circle);

        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        level.playSound(null, centre.x, centre.y, centre.z, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.9f, 1.7f);
        level.playSound(null, centre.x, centre.y, centre.z, SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.0f, 0.8f);
        sp.displayClientMessage(Component.literal("§bHide and Seek: circle connected to " + rooms.describe(room)), true);
    }

    /** Closes the circle of yours that the player is looking at (any non-exit circle for a creative player). */
    private static void removeCircle(ServerPlayer sp, ServerLevel level) {
        Vec3 eye = sp.getEyePosition();
        Vec3 end = eye.add(sp.getLookAngle().scale(Tuning.HIDESEEK_RANGE + 2));
        HideSeekPortalEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (HideSeekPortalEntity p : level.getEntitiesOfClass(HideSeekPortalEntity.class, new AABB(eye, end).inflate(2))) {
            if (p.isExit() || !(sp.isCreative() || sp.getUUID().equals(p.owner()))) continue;
            java.util.Optional<Vec3> hit = p.getBoundingBox().inflate(0.4).clip(eye, end);
            if (hit.isEmpty()) continue;
            double d = hit.get().distanceToSqr(eye);
            if (d < bestD) { bestD = d; best = p; }
        }
        if (best == null) {
            sp.displayClientMessage(Component.literal("§7Look at one of your circles to close it"), true);
            return;
        }
        if (best.owner() != null) NenRooms.get(sp.getServer()).unregisterPortal(best.owner(), best.getUUID());
        level.playSound(null, best.getX(), best.getY(), best.getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.8f, 1.4f);
        best.discard();
        sp.displayClientMessage(Component.literal("§bCircle closed"), true);
    }

    /** Where the circle's centre goes. On a wall it stands on the floor in front of the wall, so a walker can step straight in. */
    private static Vec3 circleCentre(ServerLevel level, BlockPos pos, Direction face) {
        double off = 0.5 + 0.06; // from the block's centre to just in front of its face
        double x = pos.getX() + 0.5 + face.getStepX() * off;
        double y = pos.getY() + 0.5 + face.getStepY() * off;
        double z = pos.getZ() + 0.5 + face.getStepZ() * off;
        if (face.getAxis().isHorizontal()) {
            BlockPos f = pos.relative(face);
            for (int i = 0; i < 6 && !level.getBlockState(f.below()).blocksMotion(); i++) f = f.below();
            y = f.getY() + 1.0;
        }
        return new Vec3(x, y, z);
    }

    private static void drawCircleFx(ServerLevel level, HideSeekPortalEntity circle) {
        Direction f = circle.facing();
        Vec3 u = f.getAxis() == Direction.Axis.X ? new Vec3(0, 0, 1) : new Vec3(1, 0, 0);
        Vec3 v = f.getAxis() == Direction.Axis.Y ? new Vec3(0, 0, 1) : new Vec3(0, 1, 0);
        for (int i = 0; i < 48; i++) {
            double a = i * Math.PI * 2 / 48;
            Vec3 p = circle.position().add(u.scale(Math.cos(a) * 0.95)).add(v.scale(Math.sin(a) * 0.95));
            level.sendParticles(BLUE, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
        level.sendParticles(ParticleTypes.ENCHANT, circle.getX(), circle.getY(), circle.getZ(), 30, 0.6, 0.6, 0.6, 0.4);
    }

    // ---------------------------------------------------------------- Scream

    private static final int WHOLE = 0, HEAD = 1, TORSO = 2, ARM = 3, LEG = 4;

    private static final class Scream {
        int t;
        final UUID target;
        final int part;
        final int side;        // +1: the target's right, -1: its left (arms and legs)
        final double fy;       // how far up the target the loop goes (0 = feet, 1 = top)
        final double radius;

        Scream(UUID target, int part, int side, double fy, double radius) {
            this.target = target;
            this.part = part;
            this.side = side;
            this.fy = fy;
            this.radius = radius;
        }
    }

    private record Pick(Entity entity, Vec3 hit) {}

    /** The loop's radius at a Hatsu level: the target has to fit inside it. */
    public static double loopRadius(int level) {
        return Math.min(Tuning.SCREAM_RADIUS_MAX, Tuning.SCREAM_RADIUS_BASE + level * Tuning.SCREAM_RADIUS_PER_LEVEL);
    }

    private static boolean screamable(ServerPlayer sp, Entity e) {
        if (e == sp || !e.isAlive() || e.isSpectator()) return false;
        if (e instanceof LivingEntity le) {
            return !(e instanceof ArmorStand) && !AllianceUtils.isAlly(e, sp) && !le.getType().is(Tags.EntityTypes.BOSSES);
        }
        return e instanceof ItemEntity || e instanceof Projectile || e instanceof ExperienceOrb;
    }

    /** The entity under the crosshair (nothing in the way) and the point of it that is being looked at. */
    private static Pick pick(ServerPlayer sp, ServerLevel level) {
        Vec3 eye = sp.getEyePosition();
        Vec3 dir = sp.getLookAngle();
        Vec3 end = eye.add(dir.scale(Tuning.SCREAM_RANGE));
        AABB box = sp.getBoundingBox().expandTowards(dir.scale(Tuning.SCREAM_RANGE)).inflate(1.0);
        Entity best = null;
        Vec3 bestHit = null;
        double bestD = Double.MAX_VALUE;
        for (Entity e : level.getEntities(sp, box, x -> screamable(sp, x))) {
            AABB bb = e.getBoundingBox().inflate(0.15);
            Optional<Vec3> h = bb.clip(eye, end);
            if (h.isEmpty()) {
                if (!bb.contains(eye)) continue;
                h = Optional.of(eye);
            }
            double d = eye.distanceToSqr(h.get());
            if (d < bestD) {
                bestD = d;
                best = e;
                bestHit = h.get();
            }
        }
        if (best == null) return null;
        BlockHitResult wall = level.clip(new ClipContext(eye, bestHit, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        if (wall.getType() == HitResult.Type.BLOCK && wall.getLocation().distanceToSqr(eye) + 0.01 < bestD) return null;
        return new Pick(best, bestHit);
    }

    /** Z: clasp the hands, send the loop out round whatever you are looking at, and close it. */
    public static void scream(ServerPlayer sp) {
        Combat c = gate(sp, Tuning.SCREAM_MIN_LEVEL, "Scream");
        if (c == null || !(sp.level() instanceof ServerLevel level) || sp.getServer() == null) return;
        if (SCREAM.containsKey(sp.getUUID())) return;
        if (!ready(sp, SCREAM_READY, "Scream", level.getGameTime())) return;
        Pick pick = pick(sp, level);
        if (pick == null) {
            sp.displayClientMessage(Component.literal("§7Nothing in sight to wrap the loop around"), true);
            return;
        }
        Entity target = pick.entity();
        double radius = loopRadius(c.getHatsuLevel());
        if (target.getBbWidth() * 0.5 + 0.05 > radius) {
            sp.displayClientMessage(Component.literal("§7The loop is too small to close round " + target.getName().getString()), true);
            return;
        }
        NenRooms rooms = NenRooms.get(sp.getServer());
        if (rooms.selectedRoom(sp.getUUID(), c.getHatsuLevel()) == null) {
            sp.displayClientMessage(Component.literal("§cYou have no room to send it to"), true);
            return;
        }
        if (!pay(sp, c, Tuning.SCREAM_COST)) return;
        SCREAM_READY.put(sp.getUUID(), level.getGameTime() + Tuning.SCREAM_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Scream", Tuning.SCREAM_COOLDOWN_TICKS);

        // which part is being taken: decided by where the crosshair is on the target
        int part = WHOLE, side = 1;
        double fy = 0.5;
        if (target instanceof LivingEntity le && target.getBbHeight() > Tuning.SCREAM_WHOLE_MAX_HEIGHT) {
            AABB bb = target.getBoundingBox();
            fy = Math.max(0.0, Math.min(1.0, (pick.hit().y - bb.minY) / Math.max(0.01, bb.getYsize())));
            double rad = Math.toRadians(le.yBodyRot);
            double lateral = (pick.hit().x - target.getX()) * -Math.cos(rad) + (pick.hit().z - target.getZ()) * -Math.sin(rad); // + is the target's right
            side = lateral >= 0 ? 1 : -1;
            double half = target.getBbWidth() * 0.5;
            if (fy >= 0.78) part = HEAD;
            else if (fy >= 0.40) part = Math.abs(lateral) >= 0.5 * half ? ARM : TORSO;
            else part = LEG;
        } else if (target instanceof LivingEntity) {
            fy = 0.5;
        }
        SCREAM.put(sp.getUUID(), new Scream(target.getUUID(), part, side, fy, radius));
        anim(sp, "scream_clasp");
        level.playSound(null, sp.blockPosition(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 1.2f, 1.9f);
    }

    private static void cancelScream(ServerPlayer sp) {
        if (SCREAM.remove(sp.getUUID()) != null) anim(sp, "stop_anim");
    }

    private static double ease(double v) {
        v = Math.max(0, Math.min(1, v));
        return v * v * (3 - 2 * v);
    }

    /** Hands, middle of the clasp, and the user's right-hand direction. */
    private static Vec3[] hands(ServerPlayer sp) {
        Vec3 look = sp.getLookAngle();
        double rad = Math.toRadians(sp.getYRot());
        Vec3 right = new Vec3(-Math.cos(rad), 0, -Math.sin(rad));
        Vec3 chest = sp.getEyePosition().add(look.scale(0.6)).add(0, -0.45, 0);
        return new Vec3[] {chest.subtract(right.scale(0.14)), chest.add(right.scale(0.14)), chest, right};
    }

    private static Vec3 goal(Entity target, Scream s) {
        AABB bb = target.getBoundingBox();
        return new Vec3(target.getX(), bb.minY + s.fy * bb.getYsize(), target.getZ());
    }

    private static void ring(ServerLevel level, Vec3 c, double r, int n, double phase) {
        for (int i = 0; i < n; i++) {
            double a = phase + i * Math.PI * 2 / n;
            level.sendParticles(BLUE, c.x + Math.cos(a) * r, c.y, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    /** The aura joining each hand to the loop. */
    private static void strand(ServerLevel level, Vec3 from, Vec3 to, double time) {
        int n = 9;
        for (int i = 0; i <= n; i++) {
            double k = i / (double) n;
            double wob = Math.sin(k * Math.PI) * 0.14 * Math.sin(time * 0.6 + k * 5);
            Vec3 p = from.lerp(to, k).add(0, wob, 0);
            level.sendParticles(BLUE, p.x, p.y, p.z, 1, 0.01, 0.01, 0.01, 0);
        }
    }

    /** Runs every tick for every player (see AddonServerEvents). */
    public static void tick(ServerPlayer sp) {
        giveKey(sp);
        Scream s = SCREAM.get(sp.getUUID());
        if (s == null) return;
        if (!(sp.level() instanceof ServerLevel level) || sp.getServer() == null) {
            cancelScream(sp);
            return;
        }
        Entity target = level.getEntity(s.target);
        if (!sp.isAlive() || HatsuEffects.isStunned(sp) || ExtrasHooks.hatsuForced(sp) || target == null || !target.isAlive()
            || target.distanceTo(sp) > Tuning.SCREAM_RANGE + 6) {
            cancelScream(sp);
            return;
        }
        s.t++;
        Vec3[] h = hands(sp);
        Vec3 goal = goal(target, s);
        int clasp = Tuning.SCREAM_CLASP_TICKS, travel = Tuning.SCREAM_TRAVEL_TICKS, hold = Tuning.SCREAM_HOLD_TICKS;

        if (s.t <= clasp) {
            // a portal opens in each hand and the loop forms between them
            double k = s.t / (double) clasp;
            level.sendParticles(NAVY, h[0].x, h[0].y, h[0].z, 3, 0.04, 0.04, 0.04, 0);
            level.sendParticles(NAVY, h[1].x, h[1].y, h[1].z, 3, 0.04, 0.04, 0.04, 0);
            for (int i = 0; i <= 10; i++) {
                double u = i / 10.0;
                Vec3 p = h[0].lerp(h[1], u).add(0, Math.sin(u * Math.PI) * 0.2 * k, 0);
                level.sendParticles(BLUE, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            }
            if (s.t == 1) level.playSound(null, sp.blockPosition(), SoundEvents.PORTAL_TRIGGER, SoundSource.PLAYERS, 0.35f, 1.8f);
            return;
        }

        Vec3 c;
        double rad;
        if (s.t <= clasp + travel) {
            double k = ease((s.t - clasp) / (double) travel);
            c = h[2].lerp(goal, k);
            rad = s.radius * (1.4 - 0.4 * k);
        } else {
            double k = Math.min(1.0, (s.t - clasp - travel) / (double) hold);
            c = goal;
            double snug = Math.max(0.12, target.getBbWidth() * 0.5 * 0.85);
            rad = s.radius + (snug - s.radius) * k;
            if (s.t % 2 == 0) level.playSound(null, c.x, c.y, c.z, SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 0.5f, 1.2f + (float) k);
        }
        ring(level, c, rad, 26, s.t * 0.45);
        strand(level, h[0], c.subtract(h[3].scale(rad)), s.t);
        strand(level, h[1], c.add(h[3].scale(rad)), s.t);
        level.sendParticles(NAVY, h[0].x, h[0].y, h[0].z, 2, 0.04, 0.04, 0.04, 0);
        level.sendParticles(NAVY, h[1].x, h[1].y, h[1].z, 2, 0.04, 0.04, 0.04, 0);

        if (s.t >= clasp + travel + hold) {
            SCREAM.remove(sp.getUUID());
            anim(sp, "stop_anim");
            close(sp, level, s, target, goal);
        }
    }

    /** "Close." Everything inside the loop is now in the room the Master Key has selected. */
    private static void close(ServerPlayer sp, ServerLevel level, Scream s, Entity target, Vec3 at) {
        Combat c = Combat.get(sp);
        if (c == null || sp.getServer() == null) return;
        Component said = Component.translatable("chat.type.text", sp.getDisplayName(), Component.literal("Close."));
        for (ServerPlayer p : level.players()) if (p.distanceToSqr(sp) < 40 * 40) p.sendSystemMessage(said);

        NenRooms rooms = NenRooms.get(sp.getServer());
        NenRooms.Room room = rooms.selectedRoom(sp.getUUID(), c.getHatsuLevel());
        if (room == null) return;
        rooms.ensureBuilt(NenRooms.nen(sp.getServer()), room);

        level.playSound(null, at.x, at.y, at.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 0.5f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.0f, 1.6f);
        level.sendParticles(ParticleTypes.PORTAL, at.x, at.y, at.z, 50, 0.3, 0.3, 0.3, 0.6);
        level.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0, 0, 0, 0);

        if (s.part == WHOLE || !(target instanceof LivingEntity le)) {
            boolean living = target instanceof LivingEntity;
            if (rooms.capture(sp.getServer(), target, room, sp.getUUID(), living)) {
                sp.displayClientMessage(Component.literal("§9" + target.getName().getString() + " is in " + rooms.describe(room)), true);
            } else {
                sp.displayClientMessage(Component.literal("§7It slipped out of the loop"), true);
            }
            return;
        }

        float mult = Vows.power(sp, SCREAM_ID);
        DamageSource src = level.damageSources().indirectMagic(sp, sp);
        float max = le.getMaxHealth();
        String what;
        switch (s.part) {
            case HEAD -> {
                what = "head";
                take(rooms, sp, room, le, EquipmentSlot.HEAD);
                dropHead(rooms, sp, room, le);
                hurt(le, src, max * Tuning.SCREAM_HEAD_FRACTION * mult);
            }
            case TORSO -> {
                what = "torso";
                take(rooms, sp, room, le, EquipmentSlot.CHEST);
                hurt(le, src, max * Tuning.SCREAM_TORSO_FRACTION * mult);
                le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, Tuning.SCREAM_LIMB_DEBUFF_TICKS, 1));
                le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, Tuning.SCREAM_LIMB_DEBUFF_TICKS, 1));
            }
            case ARM -> {
                what = s.side > 0 ? "right arm" : "left arm";
                boolean main = (s.side > 0) == (le.getMainArm() == HumanoidArm.RIGHT); // the hand that arm holds
                take(rooms, sp, room, le, main ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
                hurt(le, src, max * Tuning.SCREAM_ARM_FRACTION * mult);
                le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, Tuning.SCREAM_LIMB_DEBUFF_TICKS, 2));
                le.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, Tuning.SCREAM_LIMB_DEBUFF_TICKS, 1));
            }
            default -> {
                what = s.side > 0 ? "right leg" : "left leg";
                take(rooms, sp, room, le, EquipmentSlot.LEGS);
                take(rooms, sp, room, le, EquipmentSlot.FEET);
                hurt(le, src, max * Tuning.SCREAM_LEG_FRACTION * mult);
                le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, Tuning.SCREAM_LIMB_DEBUFF_TICKS, 3));
            }
        }
        sp.displayClientMessage(Component.literal("§9" + target.getName().getString() + "'s " + what + " is in " + rooms.describe(room)), true);
    }

    private static void hurt(LivingEntity le, DamageSource src, float amount) {
        le.invulnerableTime = 0; // the loop does not care about the hit that came a moment ago
        Vows.hatsuHurt(le, src, amount);
    }

    /** Whatever the part was wearing or holding goes into the room with it. */
    private static void take(NenRooms rooms, ServerPlayer sp, NenRooms.Room room, LivingEntity le, EquipmentSlot slot) {
        ItemStack stack = le.getItemBySlot(slot);
        if (stack.isEmpty()) return;
        le.setItemSlot(slot, ItemStack.EMPTY);
        rooms.dropIn(sp.getServer(), room, stack);
    }

    private static void dropHead(NenRooms rooms, ServerPlayer sp, NenRooms.Room room, LivingEntity le) {
        ItemStack head = null;
        if (le instanceof Player p) {
            head = new ItemStack(Items.PLAYER_HEAD);
            head.getOrCreateTag().putString("SkullOwner", p.getGameProfile().getName());
        } else if (le instanceof WitherSkeleton) head = new ItemStack(Items.WITHER_SKELETON_SKULL);
        else if (le instanceof Skeleton) head = new ItemStack(Items.SKELETON_SKULL);
        else if (le instanceof Zombie) head = new ItemStack(Items.ZOMBIE_HEAD);
        else if (le instanceof Creeper) head = new ItemStack(Items.CREEPER_HEAD);
        else if (le instanceof Piglin) head = new ItemStack(Items.PIGLIN_HEAD);
        if (head != null) rooms.dropIn(sp.getServer(), room, head);
    }
}
