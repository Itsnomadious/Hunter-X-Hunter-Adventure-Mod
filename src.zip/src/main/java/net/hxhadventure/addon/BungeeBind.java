package net.hxhadventure.addon;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketGumFx;
import net.hxhadventure.utils.AllianceUtils;
import org.joml.Vector3f;

/**
 * Bungee Bind (Bungee Gum, Z menu). Within {@link Tuning#BIND_RANGE} blocks of someone, Z ties them up in gum for
 * {@link Tuning#BIND_TICKS} ticks (6 s): they cannot move, jump or hit anyone, and Hatsu is out of their hands.
 * Like Nen Threads it does NOT force the captive into Zetsu (no Forced Zetsu): they can still use Ten and Ren.
 */
public final class BungeeBind {
    private BungeeBind() {}

    public static final String ID = "gum_bind";
    private static final String NAME = "Bungee Bind";

    private static final DustParticleOptions PINK = new DustParticleOptions(new Vector3f(0.92f, 0.42f, 0.84f), 1.2f);

    private static final class Bound {
        UUID caster;
        long until;
    }

    private static final Map<UUID, Bound> BOUND = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> READY_AT = new ConcurrentHashMap<>();

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(ID, BungeeBind::use);
    }

    public static boolean isBound(Entity e) {
        return e != null && BOUND.containsKey(e.getUUID());
    }

    public static void use(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!BungeeGum.canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Bungee Gum"), true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.BIND_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cBungee Bind unlocks at Level " + Tuning.BIND_MIN_LEVEL), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        if (ChainManager.onCooldown(sp, NAME, (int) Math.max(0, READY_AT.getOrDefault(sp.getUUID(), 0L) - now))) return;
        LivingEntity target = pick(sp, level);
        if (target == null) {
            sp.displayClientMessage(Component.literal("\u00a7cNo one within " + (int) Tuning.BIND_RANGE + " blocks to bind"), true);
            return;
        }
        if (c.getCurrentEnergy() < Tuning.BIND_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.BIND_COST);
        Bound b = new Bound();
        b.caster = sp.getUUID();
        b.until = now + Tuning.BIND_TICKS;
        BOUND.put(target.getUUID(), b);
        BungeeGum.addBuildup(sp, target, Tuning.GUM_BUILDUP_BIND); // the gum sticks to them for good measure
        AddonNetwork.sendToTrackingAndSelf(PacketGumFx.bind(target.getId(), Tuning.BIND_TICKS), target); // the gum strands on their limbs
        if (target instanceof Mob m) {
            m.getNavigation().stop();
            m.setTarget(null);
        }
        READY_AT.put(sp.getUUID(), now + Tuning.BIND_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, NAME, Tuning.BIND_COOLDOWN_TICKS);
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        level.playSound(null, target.blockPosition(), SoundEvents.SLIME_BLOCK_PLACE, SoundSource.PLAYERS, 1.5f, 0.6f);
        level.playSound(null, target.blockPosition(), SoundEvents.LEASH_KNOT_PLACE, SoundSource.PLAYERS, 1.2f, 0.8f);
        sp.displayClientMessage(Component.literal("\u00a7dBungee Bind: " + target.getName().getString() + " is tied up"), true);
        if (target instanceof ServerPlayer vp) vp.displayClientMessage(Component.literal("\u00a7dYou are tied up in gum..."), true);
    }

    /** The creature within range that the user is looking most nearly towards. */
    private static LivingEntity pick(ServerPlayer sp, ServerLevel level) {
        double r = Tuning.BIND_RANGE;
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle();
        LivingEntity best = null;
        double bestDot = -2.0;
        AABB box = sp.getBoundingBox().inflate(r + 1.0);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (e == sp || !e.isAlive() || e instanceof ArmorStand || e instanceof EnderDragon || e instanceof WitherBoss) continue;
            if (AllianceUtils.isAlly(e, sp)) continue;
            if (e instanceof Player p && (p.isCreative() || p.isSpectator())) continue;
            if (BOUND.containsKey(e.getUUID())) continue;
            if (gap(sp.getBoundingBox(), e.getBoundingBox()) > r) continue; // "within 2 blocks"
            Vec3 to = BungeeGum.centerOf(e).subtract(eye);
            double d = to.length();
            double dot = d < 1.0e-4 ? 1.0 : to.scale(1.0 / d).dot(look);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }

    /** Distance between two boxes (0 when they touch). */
    private static double gap(AABB a, AABB b) {
        double dx = Math.max(0, Math.max(a.minX - b.maxX, b.minX - a.maxX));
        double dy = Math.max(0, Math.max(a.minY - b.maxY, b.minY - a.maxY));
        double dz = Math.max(0, Math.max(a.minZ - b.maxZ, b.minZ - a.maxZ));
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // =====================================================================================================
    // the captives, every server tick
    // =====================================================================================================

    public static void tickGlobal(MinecraftServer server) {
        if (BOUND.isEmpty()) return;
        Iterator<Map.Entry<UUID, Bound>> it = BOUND.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Bound> en = it.next();
            Bound b = en.getValue();
            Entity e = find(server, en.getKey());
            if (!(e instanceof LivingEntity victim) || !victim.isAlive() || !(victim.level() instanceof ServerLevel level)
                || level.getGameTime() >= b.until) {
                if (e instanceof LivingEntity gone) free(gone);
                it.remove();
                continue;
            }
            hold(victim);
            if (level.getGameTime() % 40 == 0) { // for anyone who has only just come into view
                AddonNetwork.sendToTrackingAndSelf(PacketGumFx.bind(victim.getId(), (int) (b.until - level.getGameTime())), victim);
            }
            if (level.getGameTime() % 4 == 0) {
                // gum wrapped round the body
                double w = victim.getBbWidth() * 0.6 + 0.2;
                double ang = level.getGameTime() * 0.7;
                for (int i = 0; i < 3; i++) {
                    double a = ang + i * 2.0944;
                    double y = victim.getY() + victim.getBbHeight() * (0.2 + 0.3 * i);
                    level.sendParticles(PINK, victim.getX() + Math.cos(a) * w, y, victim.getZ() + Math.sin(a) * w, 1, 0.02, 0.02, 0.02, 0.0);
                }
            }
        }
    }

    /** Frozen, like Nen Threads: paralysis (no walking, no jumping, no Hatsu). It never touches Forced Zetsu, so Ten and Ren stay theirs. */
    private static void hold(LivingEntity t) {
        if (HatsuEffects.LIGHTNING_STUN != null) {
            MobEffectInstance cur = t.getEffect(HatsuEffects.LIGHTNING_STUN);
            if (cur == null || cur.getDuration() < 8) t.addEffect(new MobEffectInstance(HatsuEffects.LIGHTNING_STUN, 12, 0, false, false, true));
        }
        if (t instanceof Mob m) m.getNavigation().stop();
        t.setDeltaMovement(0, Math.min(0, t.getDeltaMovement().y), 0);
        t.hurtMarked = true;
    }

    private static void free(LivingEntity t) {
        HatsuEffects.removeStun(t);
        AddonNetwork.sendToTrackingAndSelf(PacketGumFx.bindOff(t.getId()), t);
    }

    private static Entity find(MinecraftServer server, UUID id) {
        for (ServerLevel l : server.getAllLevels()) {
            Entity e = l.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    /** Death / logout / Nen lost of the user: everyone they tied up is let go. */
    public static void clear(Player p) {
        UUID id = p.getUUID();
        READY_AT.remove(id);
        BOUND.remove(id); // as a captive
        MinecraftServer server = p.getServer();
        Iterator<Map.Entry<UUID, Bound>> it = BOUND.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Bound> en = it.next();
            if (!id.equals(en.getValue().caster)) continue;
            if (server != null && find(server, en.getKey()) instanceof LivingEntity victim) free(victim);
            it.remove();
        }
    }
}
