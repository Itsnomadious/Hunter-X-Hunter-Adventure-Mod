package net.hxhadventure.addon;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * Shalnark's phone, a crafted item (iron ingot, glass pane, iron ingot in a column). Holding it is what lets Black Voice work: right-click a creature to plant
 * an antenna, Shift+Z to take over an antenna'd body. All of that is handled by {@link BlackVoice} and
 * {@link BlackVoiceEvents}; the item itself does nothing on its own.
 */
public class BlackVoicePhoneItem extends Item {
    public BlackVoicePhoneItem(Properties props) {
        super(props);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("§8Right-click someone: plant a needle in the back of their neck"));
        tip.add(Component.literal("§8Shift+Z: take over a needled body, Shift+H: come back"));
    }
}
