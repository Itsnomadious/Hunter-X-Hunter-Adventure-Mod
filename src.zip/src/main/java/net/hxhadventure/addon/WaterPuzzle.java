package net.hxhadventure.addon;

/**
 * The 8 / 5 / 3 litre water puzzle (Satotz's question 10). Shared by the client (the pouring minigame) and the server, which replays the
 * moves the player made and only accepts the answer if the replay really ends with exactly {@link #TARGET} litres in a container.
 *
 * <p>A move is one byte: 0..2 fill container i from the tap, 3..5 empty container i, 6..14 pour container a into container b (see {@link #pour}).
 */
public final class WaterPuzzle {
    public static final int[] CAP = {8, 5, 3};
    public static final int TARGET = 4;
    /** Most moves the server will replay (a real solution takes about 8). */
    public static final int MAX_MOVES = 300;

    private WaterPuzzle() {}

    public static int fill(int i) {
        return i;
    }

    public static int empty(int i) {
        return 3 + i;
    }

    public static int pour(int from, int to) {
        return 6 + from * 3 + to;
    }

    /** Applies one move to the container levels. Returns false if the move is not a valid code. */
    public static boolean apply(int[] level, int move) {
        if (move < 0 || move > 14) return false;
        if (move < 3) {
            level[move] = CAP[move];
            return true;
        }
        if (move < 6) {
            level[move - 3] = 0;
            return true;
        }
        int m = move - 6;
        int from = m / 3;
        int to = m % 3;
        if (from == to) return false;
        int amount = Math.min(level[from], CAP[to] - level[to]);
        level[from] -= amount;
        level[to] += amount;
        return true;
    }

    /** Does any container hold exactly the target? */
    public static boolean solved(int[] level) {
        for (int v : level) {
            if (v == TARGET) return true;
        }
        return false;
    }

    /** Server check: replay the moves from three empty containers. */
    public static boolean verify(byte[] moves) {
        if (moves == null || moves.length > MAX_MOVES) return false;
        int[] level = new int[3];
        for (byte b : moves) {
            if (!apply(level, b)) return false;
        }
        return solved(level);
    }
}
