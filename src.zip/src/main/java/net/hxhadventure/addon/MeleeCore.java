package net.hxhadventure.addon;

import java.util.Random;

/**
 * The melee state machine of the NPCs (no Minecraft types, so it can be tested and simulated on its own: see {@link NpcBalance}).
 * Attack = a three-hit combo (swing, 3 ticks later the hit, step into the target, finisher launches), Strong = charge with a tell,
 * lock-in and lunge, Barrage = a flurry that holds the target and ends with a launcher. {@link NpcMelee} turns the Sink calls into
 * hits, particles and movement.
 */
public final class MeleeCore {

    public enum Kind { COMBO, FINISHER, STRONG, BARRAGE, BARRAGE_END }
    public enum Act { NONE, COMBO, STRONG, BARRAGE }

    /** One blow, as the NPC's melee scale will multiply it. */
    public static final class Hit {
        public Kind kind;
        public float damage, range;
        public double knockH, knockV;
        public boolean pin;
        public float progress;
    }

    public interface Sink {
        void swing();
        /** Lands a blow; returns how many enemies it hit. */
        int impact(Hit h);
        void charge(float progress);
        void snapFace();
        void lunge(double speed, int ticks);
        void strongStarted();
    }

    /** Per-NPC numbers: the basic attack constants every NPC already has in its tuning class. */
    public static final class Cfg {
        public float punchDamage = 5f, punchRange = 1.5f, strongDamage = 15f, strongRange = 2.0f, barrageDamage = 1.5f;
        public double strongKnock = 1.4;
        public int strongCharge = 40, strongMaxHold = 55, strongCooldown = 100;
        public int barrageTicks = 36, barrageGap = 3, barrageCooldown = 60;
        public float weightBarrage = 0.22f, weightStrong = 0.20f;

        public static Cfg of(float punchDamage, float punchRange, float strongDamage, float strongRange, double strongKnock,
                             int strongCharge, int strongMaxHold, int strongCooldown,
                             float barrageDamage, int barrageTicks, int barrageGap, int barrageCooldown,
                             float weightBarrage, float weightStrong) {
            Cfg c = new Cfg();
            c.punchDamage = punchDamage; c.punchRange = punchRange; c.strongDamage = strongDamage; c.strongRange = strongRange;
            c.strongKnock = strongKnock; c.strongCharge = strongCharge; c.strongMaxHold = strongMaxHold; c.strongCooldown = strongCooldown;
            c.barrageDamage = barrageDamage; c.barrageTicks = barrageTicks; c.barrageGap = barrageGap; c.barrageCooldown = barrageCooldown;
            c.weightBarrage = weightBarrage; c.weightStrong = weightStrong;
            return c;
        }
    }

    private final Cfg cfg;
    private final Sink sink;
    private final Random rng;

    private Act act = Act.NONE;
    private int actTicks, actCooldown, barrageCooldown, strongCooldown, barrageGapLeft;
    private boolean comboJustEnded;

    public MeleeCore(Cfg cfg, Sink sink, Random rng) {
        this.cfg = cfg;
        this.sink = sink;
        this.rng = rng;
    }

    public Act act() { return act; }

    public boolean isAttacking() { return act != Act.NONE; }

    public boolean isCharging() { return act == Act.STRONG; }

    /** True once, the tick after a combo's recovery began: the NPC may hit-and-run. */
    public boolean takeComboEnded() {
        boolean r = comboJustEnded;
        comboJustEnded = false;
        return r;
    }

    /** The attack slow that applies right now (Combat.updateAttackSlow's idea, much lighter for the moves that chase). */
    public float currentSlow() {
        return switch (act) {
            case STRONG -> NpcFeelTuning.STRONG_SLOW;
            case BARRAGE -> NpcFeelTuning.BARRAGE_SLOW;
            case COMBO -> NpcFeelTuning.COMBO_SLOW;
            default -> 0f;
        };
    }

    /** Another action (a Hatsu, a pounce) keeps the NPC from attacking for this many ticks. */
    public void setRecovery(int ticks) { actCooldown = Math.max(actCooldown, ticks); }

    /** Free to pick the next move: nothing running and the recovery is over. */
    public boolean ready() { return act == Act.NONE && actCooldown <= 0; }

    /** Picks the next move; the caller does this every tick the target is in reach. */
    public void choose() {
        if (!ready()) return;
        float roll = rng.nextFloat();
        if (barrageCooldown <= 0 && roll < cfg.weightBarrage) {
            act = Act.BARRAGE;
            actTicks = 0;
            barrageGapLeft = 0;
        } else if (strongCooldown <= 0 && roll < cfg.weightBarrage + cfg.weightStrong) {
            act = Act.STRONG;
            actTicks = 0;
            sink.strongStarted();
        } else {
            act = Act.COMBO;
            actTicks = 0;
        }
    }

    public void cancel() {
        if (act == Act.BARRAGE) barrageCooldown = cfg.barrageCooldown / 2;
        if (act == Act.STRONG) strongCooldown = cfg.strongCooldown / 2;
        act = Act.NONE;
        actTicks = 0;
    }

    /** Once per server tick. {@code inReach}: the target is close enough to hit; {@code busy}: a Hatsu holds the NPC. */
    public void tick(boolean inReach, boolean busy) {
        if (actCooldown > 0) actCooldown--;
        if (barrageCooldown > 0) barrageCooldown--;
        if (strongCooldown > 0) strongCooldown--;
        if (busy && act != Act.NONE) cancel();
        switch (act) {
            case COMBO -> tickCombo();
            case STRONG -> tickStrong(inReach);
            case BARRAGE -> tickBarrage();
            default -> { }
        }
    }

    private void tickCombo() {
        final int hits = NpcFeelTuning.COMBO_HITS, gap = NpcFeelTuning.COMBO_GAP_TICKS, windup = NpcFeelTuning.WINDUP_TICKS;
        int i = actTicks / gap, r = actTicks % gap;
        if (i < hits) {
            if (r == 0) {
                sink.snapFace();
                sink.swing();
                sink.lunge(NpcFeelTuning.COMBO_LUNGE_SPEED, NpcFeelTuning.COMBO_LUNGE_TICKS);
            }
            if (r == windup) {
                boolean fin = i == hits - 1;
                Hit h = new Hit();
                h.kind = fin ? Kind.FINISHER : Kind.COMBO;
                h.damage = cfg.punchDamage * (fin ? NpcFeelTuning.FINISHER_DAMAGE_MULT : 1f);
                h.range = cfg.punchRange;
                h.knockH = fin ? NpcFeelTuning.FINISHER_KNOCK_H : NpcFeelTuning.COMBO_KNOCK_H;
                h.knockV = fin ? NpcFeelTuning.FINISHER_KNOCK_V : 0.0;
                sink.impact(h);
                if (fin) {
                    act = Act.NONE;
                    actTicks = 0;
                    actCooldown = NpcFeelTuning.COMBO_RECOVERY_TICKS;
                    comboJustEnded = true;
                    return;
                }
            }
        }
        actTicks++;
    }

    private void tickStrong(boolean inReach) {
        actTicks++;
        if (actTicks % 3 == 0) sink.charge(Math.min(1f, actTicks / (float) cfg.strongCharge));
        if (actTicks == cfg.strongCharge - NpcFeelTuning.STRONG_LOCK_TICKS) {
            sink.snapFace();                                   // last chance to track: after this the blow is committed
            sink.lunge(NpcFeelTuning.STRONG_LUNGE_SPEED, NpcFeelTuning.STRONG_LOCK_TICKS);
        }
        if (actTicks >= cfg.strongCharge && (inReach || actTicks >= cfg.strongMaxHold)) {
            float progress = Math.min(1f, actTicks / (float) cfg.strongCharge);
            Hit h = new Hit();
            h.kind = Kind.STRONG;
            h.progress = progress;
            h.damage = cfg.punchDamage + (cfg.strongDamage - cfg.punchDamage) * progress;
            h.range = cfg.punchRange + (cfg.strongRange - cfg.punchRange) * progress;
            h.knockH = 0.5 + (cfg.strongKnock - 0.5) * progress;
            h.knockV = NpcFeelTuning.STRONG_LAUNCH_V + 0.20 * progress;
            sink.swing();
            int hit = sink.impact(h);
            act = Act.NONE;
            actTicks = 0;
            actCooldown = 12 + (hit == 0 ? NpcFeelTuning.STRONG_WHIFF_RECOVERY : 0);
            strongCooldown = cfg.strongCooldown;
        }
    }

    private void tickBarrage() {
        if (actTicks == 0) sink.snapFace();
        actTicks++;
        if (barrageGapLeft <= 0) {
            boolean last = actTicks + cfg.barrageGap > cfg.barrageTicks;
            Hit h = new Hit();
            h.kind = last ? Kind.BARRAGE_END : Kind.BARRAGE;
            h.damage = cfg.barrageDamage;
            h.range = cfg.punchRange;
            h.pin = !last;
            h.knockH = last ? NpcFeelTuning.BARRAGE_END_KNOCK_H : 0.0;
            h.knockV = last ? NpcFeelTuning.BARRAGE_END_KNOCK_V : 0.0;
            sink.swing();
            sink.lunge(NpcFeelTuning.BARRAGE_LUNGE_SPEED, 2);
            sink.impact(h);
            barrageGapLeft = cfg.barrageGap - 1;
        } else {
            barrageGapLeft--;
        }
        if (actTicks >= cfg.barrageTicks) {
            act = Act.NONE;
            actTicks = 0;
            actCooldown = 20;
            barrageCooldown = cfg.barrageCooldown;
        }
    }
}
