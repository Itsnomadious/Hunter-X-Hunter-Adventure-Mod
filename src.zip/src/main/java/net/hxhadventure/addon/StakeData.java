package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Every Stake of Retribution (see {@link JudgmentChain}) that stands in the world, saved with it: victim UUID -> stake.
 * A stake is driven into one creature's heart by a Judgment Chain and carries the commands its caster laid on it.
 * A stake whose victim is its own caster (Shift+Z) carries no commands: it only unlocks the death-Vows.
 */
public class StakeData extends SavedData {
    public static final String ID = "hxh_stakes";

    public static final class Stake {
        public UUID caster;
        public String casterName = "";
        /** Ids of {@link JudgmentChain#COMMANDS}. Empty on a self-stake. */
        public final List<String> commands = new ArrayList<>();
        /** The victim agreed to the commands (players are asked, NPCs never are). Commands only bind once this is true. */
        public boolean accepted;
        /** The victim is not a player: they are sealed and made passive instead of being given commands. */
        public boolean npc;

        public boolean isSelf(UUID victim) {
            return victim.equals(caster);
        }
    }

    public final Map<UUID, Stake> stakes = new LinkedHashMap<>();

    public static StakeData load(CompoundTag tag) {
        StakeData d = new StakeData();
        ListTag list = tag.getList("Stakes", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            if (!t.hasUUID("Victim") || !t.hasUUID("Caster")) continue;
            Stake s = new Stake();
            s.caster = t.getUUID("Caster");
            s.casterName = t.getString("CasterName");
            s.accepted = t.getBoolean("Accepted");
            s.npc = t.getBoolean("Npc");
            ListTag cmds = t.getList("Cmds", Tag.TAG_STRING);
            for (int c = 0; c < cmds.size(); c++) s.commands.add(cmds.getString(c));
            d.stakes.put(t.getUUID("Victim"), s);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Stake> e : stakes.entrySet()) {
            Stake s = e.getValue();
            CompoundTag t = new CompoundTag();
            t.putUUID("Victim", e.getKey());
            t.putUUID("Caster", s.caster);
            t.putString("CasterName", s.casterName);
            t.putBoolean("Accepted", s.accepted);
            t.putBoolean("Npc", s.npc);
            ListTag cmds = new ListTag();
            for (String c : s.commands) cmds.add(StringTag.valueOf(c));
            t.put("Cmds", cmds);
            list.add(t);
        }
        tag.put("Stakes", list);
        return tag;
    }
}
