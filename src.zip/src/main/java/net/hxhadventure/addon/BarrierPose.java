package net.hxhadventure.addon;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.entity.custom.AuraEntity;

/**
 * The Bungee Barrier's pose and the aura that goes with it, as one timeline shared by the server (where the auras are placed) and the client
 * (where the body is posed), both driven by the age in ticks of the barrier's aura entity:
 * <ol>
 *   <li>0 to {@link #STANCE_TICKS}: the user drops into a wide stance and lowers themselves a little;</li>
 *   <li>0 to {@link #MEET_TICKS}: both hands swing in front of the chest and come together; where they meet an aura forms;</li>
 *   <li>{@link #PART_START} onwards, over {@link #PART_TICKS}: the hands pull apart vertically, the right one up and the left one down, and
 *       the aura between them is stretched out like dough (longer and thinner);</li>
 *   <li>then everything holds until the barrier is released.</li>
 * </ol>
 * Three aura entities make the effect (see {@link AuraEntity#getHand}): one small flame at each hand and the stretching "dough" between them.
 * No client classes in here: the server uses it too.
 */
public final class BarrierPose {
    private BarrierPose() {}

    /** Client side: owner entity id -> the barrier's dough aura, so the pose code can find the age of the animation. */
    public static final Map<Integer, AuraEntity> CLIENT = new ConcurrentHashMap<>();

    public static final int HAND_RIGHT = 1;
    public static final int HAND_LEFT = 2;
    public static final int DOUGH = 3;

    public static final double STANCE_TICKS = 4;
    public static final double MEET_TICKS = 5;
    public static final double PART_START = 6;
    public static final double PART_TICKS = 11;

    public static final double STANCE_DROP = 0.176;   // blocks the body is lowered (matches the leg splay, see BarrierFx)
    public static final double MAX_GAP = 0.75;        // blocks between the hands once they are fully apart
    public static final double REACH = 0.66;          // how far in front of the body the hands meet
    public static final double HAND_HEIGHT = 0.69;    // of the body's height
    public static final double UNIT_HEIGHT = 1.4;     // blocks tall a flame of scale 1 stands (about; sets how far the dough is stretched)
    public static final double HAND_FLAME = 0.32;     // scale of the flame at each hand
    public static final double DOUGH_FLAME = 0.50;    // width scale of the dough when the hands first meet; it thins as it stretches

    public static double smooth(double x) {
        x = Mth.clamp(x, 0.0, 1.0);
        return x * x * (3.0 - 2.0 * x);
    }

    public static double stance(double age) { return smooth(age / STANCE_TICKS); }
    public static double gather(double age) { return smooth(age / MEET_TICKS); }
    public static double part(double age) { return smooth((age - PART_START) / PART_TICKS); }
    public static double appear(double age) { return smooth((age - (MEET_TICKS - 1.0)) / 3.0); }
    public static double drop(double age) { return STANCE_DROP * stance(age); }
    public static double gap(double age) { return MAX_GAP * part(age); }

    /** Where a hand is, relative to the owner's feet. */
    public static Vec3 handPos(LivingEntity o, double age, boolean right) {
        double yaw = Math.toRadians(o.yBodyRot);
        double reach = REACH * gather(age);
        double y = o.getBbHeight() * HAND_HEIGHT - drop(age) + (right ? 0.5 : -0.5) * gap(age);
        return new Vec3(-Math.sin(yaw) * reach, y, Math.cos(yaw) * reach);
    }

    public static float blobScale(int mode, double age) {
        double a = appear(age);
        double s = mode == DOUGH ? DOUGH_FLAME * (1.0 - 0.45 * part(age)) : HAND_FLAME;
        return (float) Math.max(0.001, s * a);
    }

    /** Extra vertical stretch: the dough is pulled out to span the gap between the hands, so it gets longer as it gets thinner. */
    public static float blobStretch(int mode, double age) {
        if (mode != DOUGH) return 1f;
        double span = gap(age) + 0.55;
        double ws = Math.max(0.05, blobScale(mode, age));
        return (float) Math.max(1.0, span / (UNIT_HEIGHT * ws));
    }

    /** The aura entity's position relative to the owner's feet (its base: the flame plumes up from there). */
    public static Vec3 blobOffset(LivingEntity o, double age, int mode) {
        Vec3 right = handPos(o, age, true);
        Vec3 left = handPos(o, age, false);
        if (mode == DOUGH) {
            double span = gap(age) + 0.55;
            return new Vec3(right.x, (right.y + left.y) * 0.5 - span * 0.5, right.z);
        }
        Vec3 h = mode == HAND_RIGHT ? right : left;
        return new Vec3(h.x, h.y - 0.5 * UNIT_HEIGHT * blobScale(mode, age), h.z);
    }
}
