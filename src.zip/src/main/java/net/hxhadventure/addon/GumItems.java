package net.hxhadventure.addon;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/** Registers the Playing Card without touching ModItem (same way as Kalluto's Fan, see PaperItems). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class GumItems {
    private GumItems() {}

    public static Item PLAYING_CARD;

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.ITEMS, helper -> {
            PLAYING_CARD = new PlayingCardItem(new Item.Properties().stacksTo(64));
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "playing_card"), PLAYING_CARD);
        });
    }

    @SubscribeEvent
    public static void creativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.COMBAT && PLAYING_CARD != null) e.accept(PLAYING_CARD);
    }
}
