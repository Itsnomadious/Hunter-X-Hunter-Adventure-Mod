package net.hxhadventure.addon;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Client-side mirror of the Vows, Limitations and Conditions the local player has sworn. No client-only imports, safe to load anywhere. */
public final class ClientVows {
    private ClientVows() {}

    public static final Set<String> chosen = new LinkedHashSet<>();
    /** The local player carries their own Stake of Retribution: the death-Vows can be sworn (see Vows.STAKE_VOWS). */
    public static boolean selfStake;

    public static void set(List<String> ids) {
        chosen.clear();
        chosen.addAll(ids);
        selfStake = chosen.remove(Vows.STAKE_FLAG);
    }

    public static int count(String target, Vows.Kind kind) {
        int n = 0;
        for (String id : chosen) {
            Vows.Rule r = Vows.RULES.get(id);
            if (r != null && r.target().equals(target) && r.kind() == kind) n++;
        }
        return n;
    }
}
