package net.hxhadventure.addon;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/** Registers Kalluto's Fan without touching ModItem (same way as the Skill Hunter book). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class PaperItems {
    private PaperItems() {}

    public static Item FAN;

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.ITEMS, helper -> {
            FAN = new PaperFanItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON));
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "kallutos_fan"), FAN);
        });
    }

    @SubscribeEvent
    public static void creativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES && FAN != null) e.accept(FAN);
    }
}
