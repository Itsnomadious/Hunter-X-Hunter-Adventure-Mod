package net.hxhadventure.addon;

import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Morel's pipe: a huge smoking pipe with a long stem, the mouthpiece at the user's end and a bowl the size of a pot at the far end, open at the top
 * (the held smoke wisp from that hole is client/PipeSmokeClient). It is a real item (crafted, not conjured), and Smoke Manipulation
 * only works while it is in a hand. Right-click just puffs a little smoke; the abilities live in {@link SmokeManipulation}.
 */
public class SmokePipeItem extends Item {
    public SmokePipeItem(Properties props) {
        super(props);
    }

    /** The hand that holds a pipe (main hand first), or null. */
    public static @Nullable InteractionHand heldIn(LivingEntity e) {
        if (e.getMainHandItem().getItem() instanceof SmokePipeItem) return InteractionHand.MAIN_HAND;
        if (e.getOffhandItem().getItem() instanceof SmokePipeItem) return InteractionHand.OFF_HAND;
        return null;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel sl) {
            Vec3 mouth = player.getEyePosition().add(player.getLookAngle().scale(0.5)).add(0.0, -0.15, 0.0);
            sl.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, mouth.x, mouth.y, mouth.z, 6, 0.1, 0.05, 0.1, 0.01);
            sl.playSound(null, player.blockPosition(), SoundEvents.CAMPFIRE_CRACKLE, SoundSource.PLAYERS, 0.5f, 1.4f);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || !oldStack.is(newStack.getItem());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("§7A pipe as big as a man's shoulder."));
        tip.add(Component.literal("§5Used by Smoke Manipulation (hold it to use Hatsu)"));
        tip.add(Component.literal("§8Z: Deep Purple - Shift+Z: clones"));
    }
}
