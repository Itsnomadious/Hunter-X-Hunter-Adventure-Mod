package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks for {@link SmokeManipulation}. Self-registering, so no existing event class needs editing. */
public final class SmokeEvents {
    private SmokeEvents() {}

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class SmokeModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent e) {
            putOnce(e, HxHEntities.SMOKE_MONSTER.get());
            putOnce(e, HxHEntities.SMOKE_CLONE.get());
        }

        /** Forge refuses a second entry for the same type; if this event is ever delivered twice the first entry is already right. */
        private static void putOnce(EntityAttributeCreationEvent e, net.minecraft.world.entity.EntityType<? extends net.minecraft.world.entity.LivingEntity> type) {
            try {
                e.put(type, SmokeMinion.createAttributes().build());
            } catch (IllegalStateException alreadyThere) {
                // already registered: nothing to do
            }
        }
    }

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class SmokeGame {
        @SubscribeEvent
        public static void onServerTick(TickEvent.ServerTickEvent e) {
            if (e.phase == TickEvent.Phase.END) SmokeManipulation.serverTick(ServerLifecycleHooks.getCurrentServer());
        }

        @SubscribeEvent
        public static void onDeath(LivingDeathEvent e) {
            if (e.getEntity() instanceof ServerPlayer sp) SmokeManipulation.clear(sp);
        }

        @SubscribeEvent
        public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
            if (e.getEntity() instanceof ServerPlayer sp) SmokeManipulation.clear(sp);
        }

        /** Smoke leaves nothing behind (and a clone's copied gear must not drop). */
        @SubscribeEvent
        public static void onDrops(LivingDropsEvent e) {
            if (e.getEntity() instanceof SmokeMinion) e.setCanceled(true);
        }

        /** The user cannot hurt their own smoke by accident. */
        @SubscribeEvent
        public static void onAttack(LivingAttackEvent e) {
            if (e.getEntity() instanceof SmokeMinion m && e.getSource().getEntity() != null
                && e.getSource().getEntity().getUUID().equals(m.ownerId())) {
                e.setCanceled(true);
            }
        }

        @SubscribeEvent
        public static void onLevelLoad(LevelEvent.Load e) {
            if (e.getLevel() instanceof ServerLevel sl) SmokeJail.onLevelLoad(sl);
        }

        @SubscribeEvent
        public static void onServerStopping(ServerStoppingEvent e) {
            SmokeJail.onServerStopping(e.getServer());
        }

        @SubscribeEvent
        public static void onServerStopped(ServerStoppedEvent e) {
            SmokeManipulation.reset();
        }
    }
}
