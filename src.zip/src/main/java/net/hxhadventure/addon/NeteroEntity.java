package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketBlastFx;
import net.hxhadventure.addon.network.PacketGuanyinFx;
import net.hxhadventure.addon.network.PacketPrayFx;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Isaac Netero, the Chairman (NPC): level 600, stronger than Neferpitou. His Hatsu is the 100-Type Guanyin Bodhisattva, run like a player's
 * ({@link Guanyin}): he prays, the statue stands behind him, and the Guanyin does his palm strikes, the First, Third and Ninety-ninth Hand,
 * the Aspect of Guanyin and finally the Zero Hand. The statue is drawn by the same client code as a player's (it is keyed on the entity id).
 *
 * <p>Gratitude: every prayer, every blow he lands and every blow he takes builds it. Below {@link #GRATITUDE_MAX} the Guanyin's hands are
 * {@link GuanyinTuning#SLOW_SPEED}x as fast; at the top he is enlightened: {@link GuanyinTuning#TRUE_SPEED}x hands, 30% shorter cooldowns, +10%
 * damage, and the statue costs as much as Ren.
 */
public class NeteroEntity extends NenFighter {
    public static final NpcStats STATS = new NpcStats("netero", Combat.NEN_ENHANCEMENT)
        .levels(600, 600, 600, 600)
        .body(2600.0, 0.38, 0.9, 6.0f)
        .melee(1.5f, 3.0)
        .look("gold_orangeaura_ten", 0xF2F2F2, 0x8B5A2B);

    /** Gratitude needed to be enlightened (a compact version of the player's 10000 prayers). */
    private static final int GRATITUDE_MAX = 100;
    private static final int GRATITUDE_PRAYER = 25, GRATITUDE_PER_HIT_DEALT = 1, GRATITUDE_PER_HIT_TAKEN = 1;
    private static final int PRAYER_TICKS = 40;
    private static final int PALM_ALIVE = 0;

    private enum Kind { ASPECT, FIRST, THIRD, NINETY, ZERO }

    private static final class Act {
        final Kind kind;
        int ticks, windup;
        Vec3 pos = Vec3.ZERO, dir = Vec3.ZERO, base = Vec3.ZERO, facing = Vec3.ZERO;
        UUID target;
        float used, acc;
        final List<UUID> held = new ArrayList<>();

        Act(Kind kind) { this.kind = kind; }
    }

    private int gratitude = 50;
    private boolean statueUp;
    private int prayTicks;
    private boolean prayedThisFight;
    private int statueResumeAt;
    private Act act;
    private boolean palmLeft;
    private int palmReadyAt, palmCount;
    private long aspectReady, firstReady, thirdReady, ninetyReady, zeroReady;

    public NeteroEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, STATS);
    }

    // ------------------------------------------------------------------ state

    public boolean enlightened() { return gratitude >= GRATITUDE_MAX; }

    private float speed() { return enlightened() ? GuanyinTuning.TRUE_SPEED : GuanyinTuning.SLOW_SPEED; }

    private float dmgMult() { return enlightened() ? GuanyinTuning.TRUE_DAMAGE_MULT : 1f; }

    private int ticks(int base) { return Math.max(1, Math.round(base / speed())); }

    private int cd(int base) { return Math.round(base * (enlightened() ? GuanyinTuning.TRUE_COOLDOWN_MULT : 1f)); }

    private void gratitude(int n) { gratitude = Math.min(GRATITUDE_MAX, gratitude + n); }

    @Override
    protected boolean hatsuBusy() {
        return prayTicks > 0 || (act != null && (act.kind == Kind.ZERO || act.kind == Kind.NINETY || act.kind == Kind.THIRD || act.kind == Kind.FIRST));
    }

    @Override
    public boolean armsOut() { return false; }

    @Override
    protected double preferredRange() { return statueUp ? 4.0 : 0.0; }

    @Override
    protected float extraOutgoingMult(@Nullable net.minecraft.world.damagesource.DamageSource src) { return statueUp ? dmgMult() : 1f; }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide) gratitude(GRATITUDE_PER_HIT_TAKEN);
        return hit;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Gratitude", gratitude);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Gratitude")) gratitude = tag.getInt("Gratitude");
    }

    @Override
    public void startSeenByPlayer(ServerPlayer p) {
        super.startSeenByPlayer(p);
        if (statueUp) AddonNetwork.sendToPlayer(new PacketGuanyinFx(getId(), PacketGuanyinFx.ON), p);
    }

    // ------------------------------------------------------------------ networking helpers

    private void fx(int type, Vec3 pos, Vec3 dir, int extra) {
        AddonNetwork.sendToTrackingAndSelf(new PacketGuanyinFx(getId(), type, pos, dir, extra), this);
    }

    private Vec3 forward() {
        double yaw = Math.toRadians(yBodyRot);
        return new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
    }

    private Vec3 flatLook() {
        double yaw = Math.toRadians(getYRot());
        return new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
    }

    private Vec3 statueBase() { return position().subtract(forward().scale(GuanyinTuning.STATUE_BACK)); }

    private long now() { return level().getGameTime(); }

    // ------------------------------------------------------------------ the Hatsu

    @Override
    protected void tickHatsu(@Nullable LivingEntity t, boolean fighting) {
        if (!(level() instanceof ServerLevel level)) return;
        if (prayTicks > 0 && --prayTicks == 0) finishPrayer();
        if (act != null) tickAct(level, t);

        if (statueUp) {
            if (!canUseNen() || !isAlive()) {
                dismiss();
            } else {
                if (tickCount % 20 == 0) { // the statue is paid for by the second: as much as Ren once enlightened
                    float upkeep = enlightened() ? Tuning.renUpkeep(maxAura()) : GuanyinTuning.SUMMON_UPKEEP;
                    if (aura() < upkeep || auraFraction() < 0.08f) {
                        dismiss();
                        statueResumeAt = tickCount + 200;
                    } else {
                        drainAura(upkeep);
                    }
                }
                if (tickCount % 4 == 0) {
                    Vec3 b = statueBase();
                    level.sendParticles(ParticleTypes.END_ROD, b.x + (level.random.nextDouble() - 0.5) * 5, b.y + level.random.nextDouble() * 9,
                        b.z + (level.random.nextDouble() - 0.5) * 3, 1, 0, 0.05, 0, 0.01);
                }
            }
        }
        if (!fighting || t == null) return;
        if (prayTicks > 0) return;
        if (!canUseNen()) return;

        double d = distanceTo(t);
        if (!statueUp) {
            if (!prayedThisFight && !enlightened() && tickCount - lastHitAge() > 0 && lastHitAge() > 30) { pray(); return; }
            if (tickCount >= statueResumeAt && auraFraction() > 0.30f && payAura(GuanyinTuning.SUMMON_COST)) summon(level);
            return;
        }
        if (act != null) return;

        // the Guanyin's moves, longest cooldowns and biggest first
        long now = now();
        if (zeroReady <= now && auraFraction() > 0.65f && d > 5.0 && d < 60.0 && hasLineOfSight(t) && t.getMaxHealth() > 60f && random.nextInt(30) == 0) { zeroHand(level, t); return; }
        if (d <= 12.0 && ninetyReady <= now && lastHitAge() < 60 && canAfford(GuanyinTuning.NINETY_COST)) { ninetyNinth(); return; }
        if (d <= GuanyinTuning.FIRST_THIRD_RANGE && thirdReady <= now && canAfford(GuanyinTuning.THIRD_COST)) { thirdHand(t); return; }
        if (d <= GuanyinTuning.FIRST_THIRD_RANGE && firstReady <= now && canAfford(GuanyinTuning.FIRST_COST)) { firstHand(t); return; }
        if (d > 7.0 && aspectReady <= now && hasLineOfSight(t) && canAfford(GuanyinTuning.ASPECT_COST)) { aspect(t); return; }
        // otherwise the statue does the punching: a palm over the 6 x 6 area in front of him
        if (d <= GuanyinTuning.ATTACK_REACH && tickCount >= palmReadyAt) {
            palmReadyAt = tickCount + (enlightened() ? 5 : Math.round(GuanyinTuning.ATTACK_COOLDOWN_TICKS / GuanyinTuning.SLOW_SPEED));
            palm(GuanyinTuning.ATTACK_DAMAGE, GuanyinTuning.ATTACK_KNOCKBACK, (++palmCount % 6 == 0) ? 1 : 0);
        }
    }

    @Override
    protected void onFightEnd() {
        prayedThisFight = false;
        endAct();
        dismiss();
        if (prayTicks > 0) {
            prayTicks = 0;
            AddonNetwork.sendToTrackingAndSelf(new PacketPrayFx(getId(), 0), this);
        }
    }

    @Override
    protected void onAuraGone() {
        endAct();
        dismiss();
    }

    @Override
    protected void onProvoked(LivingEntity attacker) {
        prayedThisFight = prayedThisFight || lastHitAge() < 30; // no time to pray under attack
    }

    // ------------------------------------------------------------------ prayer and the statue

    private void pray() {
        prayedThisFight = true;
        prayTicks = PRAYER_TICKS;
        getNavigation().stop();
        AddonNetwork.sendToTrackingAndSelf(new PacketPrayFx(getId(), PRAYER_TICKS, 0), this);
    }

    private void finishPrayer() {
        AddonNetwork.sendToTrackingAndSelf(new PacketPrayFx(getId(), 0), this);
        gratitude(GRATITUDE_PRAYER);
        if (level() instanceof ServerLevel level) level.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.2, getZ(), 10, 0.3, 0.3, 0.3, 0.02);
    }

    private void summon(ServerLevel level) {
        statueUp = true;
        fx(PacketGuanyinFx.ON, Vec3.ZERO, Vec3.ZERO, 0);
        Vec3 b = statueBase();
        level.playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 1.5f, 0.5f);
        level.playSound(null, blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 0.6f, 1.6f);
        level.sendParticles(ParticleTypes.END_ROD, b.x, b.y + 3, b.z, 80, 1.5, 3.0, 1.5, 0.15);
        level.sendParticles(ParticleTypes.FLASH, b.x, b.y + 4, b.z, 1, 0, 0, 0, 0);
    }

    private void dismiss() {
        if (!statueUp) return;
        statueUp = false;
        endAct();
        fx(PacketGuanyinFx.OFF, Vec3.ZERO, Vec3.ZERO, 0);
        level().playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 1.0f, 0.6f);
    }

    private void endAct() {
        if (act == null) return;
        release(act);
        act = null;
    }

    private void release(Act a) {
        if (!(level() instanceof ServerLevel level)) return;
        for (UUID id : a.held) if (level.getEntity(id) instanceof LivingEntity e) HatsuEffects.removeStun(e);
        a.held.clear();
    }

    // ------------------------------------------------------------------ moves

    private float hatsuDamage(float base, float perLevel) { return base + hatsuLevel() * perLevel; }

    private void hurtFoe(LivingEntity e, float base) {
        e.invulnerableTime = 0;
        hatsuHurt(e, base * dmgMult());
    }

    private Vec3 aimPoint(LivingEntity t) { return t.position(); }

    private void palm(float damage, double knockback, int strength) {
        if (!(level() instanceof ServerLevel level)) return;
        Vec3 f = flatLook();
        double half = GuanyinTuning.ATTACK_REACH * 0.5;
        Vec3 centre = position().add(f.scale(half));
        AABB box = new AABB(centre.x - half, getY() - 1.0, centre.z - half, centre.x + half, getY() + GuanyinTuning.ATTACK_REACH - 1.0, centre.z + half);
        boolean any = false;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, this::isFoe)) {
            hurtFoe(e, damage);
            e.knockback(knockback, getX() - e.getX(), getZ() - e.getZ());
            e.hurtMarked = true;
            gratitude(GRATITUDE_PER_HIT_DEALT);
            any = true;
        }
        palmLeft = !palmLeft;
        fx(PacketGuanyinFx.PALM, centre.add(0, 1.5, 0), f, strength | (palmLeft ? 2 : 0) | (Math.round(speed() * 100f) << 2));
        level.playSound(null, blockPosition(), strength > 0 ? SoundEvents.GENERIC_EXPLODE : SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, strength > 0 ? 1.0f : 0.8f, 0.7f);
        if (any) level.sendParticles(ParticleTypes.CRIT, centre.x, centre.y + 1.2, centre.z, 12, half * 0.5, 0.8, half * 0.5, 0.2);
    }

    private void aspect(LivingEntity t) {
        if (!payAura(GuanyinTuning.ASPECT_COST)) return;
        aspectReady = now() + cd(GuanyinTuning.ASPECT_COOLDOWN_TICKS);
        Vec3 dir = t.position().add(0, t.getBbHeight() * 0.5, 0).subtract(getEyePosition()).normalize();
        double rad = Math.toRadians(getYRot());
        Vec3 left = new Vec3(Math.cos(rad), 0, Math.sin(rad));
        Vec3 origin = getEyePosition().add(left.scale(GuanyinTuning.ASPECT_SIDE)).add(dir.scale(1.5)).add(0, -0.3, 0);
        Act a = new Act(Kind.ASPECT);
        a.pos = origin;
        a.dir = dir;
        a.windup = ticks(GuanyinTuning.ASPECT_FLASH_TICKS);
        act = a;
        fx(PacketGuanyinFx.FLASH, origin, dir, a.windup);
        level().playSound(null, blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 1.2f, 0.5f);
    }

    private void firstHand(LivingEntity t) {
        if (!payAura(GuanyinTuning.FIRST_COST)) return;
        firstReady = now() + cd(GuanyinTuning.FIRST_COOLDOWN_TICKS);
        Act a = new Act(Kind.FIRST);
        a.pos = aimPoint(t);
        a.dir = flatLook();
        a.windup = ticks(GuanyinTuning.FIRST_WINDUP_TICKS);
        act = a;
        fx(PacketGuanyinFx.FIRST, a.pos, a.dir, a.windup);
        level().playSound(null, blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 1.2f, 0.7f);
    }

    private void thirdHand(LivingEntity t) {
        if (!payAura(GuanyinTuning.THIRD_COST)) return;
        thirdReady = now() + cd(GuanyinTuning.THIRD_COOLDOWN_TICKS);
        Act a = new Act(Kind.THIRD);
        a.pos = aimPoint(t);
        a.dir = flatLook();
        a.windup = ticks(GuanyinTuning.THIRD_WINDUP_TICKS);
        act = a;
        fx(PacketGuanyinFx.THIRD, a.pos, new Vec3(a.dir.x, a.windup, a.dir.z), a.windup + GuanyinTuning.THIRD_HOLD_TICKS);
        level().playSound(null, blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 1.2f, 0.6f);
    }

    private void ninetyNinth() {
        if (!payAura(GuanyinTuning.NINETY_COST)) return;
        ninetyReady = now() + cd(GuanyinTuning.NINETY_COOLDOWN_TICKS);
        Act a = new Act(Kind.NINETY);
        a.pos = position();
        a.dir = flatLook();
        act = a;
        fx(PacketGuanyinFx.NINETY, a.pos, a.dir, GuanyinTuning.NINETY_DURATION_TICKS);
        level().playSound(null, blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 1.2f, 0.9f);
    }

    private void zeroHand(ServerLevel level, LivingEntity t) {
        float used = aura() * 0.5f; // the player spends ALL of it; Netero keeps half to go on fighting
        if (used < GuanyinTuning.ZERO_MIN_ENERGY || !payAura(used)) return;
        zeroReady = now() + cd(GuanyinTuning.ZERO_COOLDOWN_TICKS);
        Act a = new Act(Kind.ZERO);
        a.target = t.getUUID();
        a.pos = t.position();
        Vec3 d = position().subtract(t.position());
        double len = Math.hypot(d.x, d.z);
        a.facing = len < 1.0e-4 ? flatLook().scale(-1) : new Vec3(d.x / len, 0, d.z / len);
        Vec3 p = t.position().subtract(a.facing.scale(GuanyinTuning.ZERO_BEHIND));
        BlockHitResult down = level.clip(new ClipContext(p.add(0, 3, 0), p.add(0, -24, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, t));
        a.base = down.getType() == HitResult.Type.MISS ? p : new Vec3(p.x, down.getLocation().y, p.z);
        a.dir = a.facing;
        a.used = used;
        a.windup = ticks(GuanyinTuning.ZERO_CHARGE_TICKS);
        act = a;
        fx(PacketGuanyinFx.ZERO, a.pos, new Vec3(a.facing.x, a.base.y, a.facing.z), a.windup);
        level.playSound(null, blockPosition(), SoundEvents.WARDEN_SONIC_CHARGE, SoundSource.HOSTILE, 2.0f, 0.5f);
    }

    private void impact(ServerLevel level, Vec3 p, double radius) {
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.x, p.y + 0.5, p.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.END_ROD, p.x, p.y + 1.0, p.z, 60, radius * 0.4, 0.6, radius * 0.4, 0.35);
        level.sendParticles(ParticleTypes.CLOUD, p.x, p.y + 0.3, p.z, 40, radius * 0.5, 0.2, radius * 0.5, 0.2);
        level.playSound(null, BlockPos.containing(p), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 2.0f, 0.6f);
        level.playSound(null, BlockPos.containing(p), SoundEvents.IRON_GOLEM_DAMAGE, SoundSource.HOSTILE, 2.0f, 0.5f);
    }

    /** A beam from {@code origin} along {@code dir}: hits every enemy in a cone of this radius (the golden Aspect / Zero Hand beam). */
    private void beam(ServerLevel level, Vec3 origin, Vec3 dir, double range, double extraRadius, float base, double knock) {
        HitResult wall = level.clip(new ClipContext(origin, origin.add(dir.scale(range)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        double len = wall.getType() == HitResult.Type.MISS ? range : Math.max(1.0, wall.getLocation().distanceTo(origin));
        AddonNetwork.sendToTrackingAndSelf(new PacketBlastFx(getId(), origin, dir, (float) len, (float) extraRadius, true), this);
        level.playSound(null, blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 1.6f, 0.6f);
        level.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.0f, 1.5f);
        AABB box = new AABB(origin, origin.add(dir.scale(len))).inflate(AuraBlast.radiusAt(len) + extraRadius + 1.0);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, this::isFoe)) {
            Vec3 v = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(origin);
            double proj = v.dot(dir);
            if (proj < 0 || proj > len + 0.5) continue;
            double perp = v.subtract(dir.scale(proj)).length();
            if (perp > AuraBlast.radiusAt(proj) + extraRadius + e.getBbWidth() * 0.5) continue;
            float falloff = (float) (1.0 - 0.4 * proj / range);
            e.invulnerableTime = 0;
            hatsuHurt(e, base * falloff * dmgMult());
            Vec3 push = dir.scale(Tuning.BLAST_KNOCKBACK * falloff * knock).add(0, 0.5 * Math.max(1.0, Math.sqrt(knock)), 0);
            e.push(push.x, push.y, push.z);
            e.hurtMarked = true;
            level.sendParticles(ParticleTypes.EXPLOSION, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 1, 0, 0, 0, 0);
        }
    }

    private void tickAct(ServerLevel level, @Nullable LivingEntity t) {
        Act a = act;
        a.ticks++;
        switch (a.kind) {
            case ASPECT -> {
                if (a.ticks >= a.windup) {
                    float base = hatsuDamage(GuanyinTuning.ASPECT_BASE_DAMAGE, GuanyinTuning.ASPECT_DAMAGE_PER_LEVEL);
                    beam(level, a.pos, a.dir, Tuning.BLAST_RANGE + GuanyinTuning.ASPECT_EXTRA_RANGE, GuanyinTuning.ASPECT_EXTRA_RADIUS, base, GuanyinTuning.ASPECT_KNOCKBACK_MULT);
                    act = null;
                }
            }
            case FIRST -> {
                if (a.ticks >= a.windup) {
                    float dmg = hatsuDamage(GuanyinTuning.FIRST_BASE_DAMAGE, GuanyinTuning.FIRST_DAMAGE_PER_LEVEL);
                    AABB box = new AABB(a.pos, a.pos).inflate(GuanyinTuning.FIRST_RADIUS, 3.0, GuanyinTuning.FIRST_RADIUS);
                    for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, this::isFoe)) {
                        if (e.position().distanceTo(a.pos) > GuanyinTuning.FIRST_RADIUS + e.getBbWidth()) continue;
                        hurtFoe(e, dmg);
                        e.setDeltaMovement(e.getDeltaMovement().add((e.getX() - a.pos.x) * 0.15, 0.6, (e.getZ() - a.pos.z) * 0.15));
                        e.hurtMarked = true;
                        gratitude(GRATITUDE_PER_HIT_DEALT);
                    }
                    impact(level, a.pos, GuanyinTuning.FIRST_RADIUS);
                    act = null;
                }
            }
            case THIRD -> {
                if (a.ticks == a.windup) {
                    float dmg = hatsuDamage(GuanyinTuning.THIRD_BASE_DAMAGE, GuanyinTuning.THIRD_DAMAGE_PER_LEVEL);
                    AABB box = new AABB(a.pos, a.pos).inflate(GuanyinTuning.THIRD_RADIUS, 4.0, GuanyinTuning.THIRD_RADIUS);
                    for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, this::isFoe)) {
                        if (e.position().distanceTo(a.pos) > GuanyinTuning.THIRD_RADIUS + e.getBbWidth()) continue;
                        hurtFoe(e, dmg);
                        a.held.add(e.getUUID());
                        HatsuEffects.stun(e, GuanyinTuning.THIRD_HOLD_TICKS);
                        gratitude(GRATITUDE_PER_HIT_DEALT);
                    }
                    impact(level, a.pos, GuanyinTuning.THIRD_RADIUS);
                }
                if (a.ticks > a.windup) {
                    for (UUID id : a.held) {
                        if (level.getEntity(id) instanceof LivingEntity e && e.isAlive()) {
                            e.setDeltaMovement(0, Math.min(0, e.getDeltaMovement().y), 0);
                            e.hurtMarked = true;
                        }
                    }
                }
                if (a.ticks >= a.windup + GuanyinTuning.THIRD_HOLD_TICKS) {
                    release(a);
                    act = null;
                }
            }
            case NINETY -> {
                a.acc += speed() / GuanyinTuning.NINETY_HIT_EVERY_TICKS;
                for (int i = 0; i < 2 && a.acc >= 1f; i++, a.acc -= 1f) ninetyHit(level, a);
                if (a.ticks >= GuanyinTuning.NINETY_DURATION_TICKS) act = null;
            }
            case ZERO -> {
                if (a.ticks < a.windup) {
                    if (a.ticks == 1) {
                        level.sendParticles(ParticleTypes.END_ROD, a.base.x, a.base.y + 3, a.base.z, 60, 1.5, 3.0, 1.5, 0.12);
                        level.sendParticles(ParticleTypes.FLASH, a.base.x, a.base.y + 4, a.base.z, 1, 0, 0, 0, 0);
                        level.playSound(null, BlockPos.containing(a.base), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 1.5f, 0.5f);
                    }
                    if (level.getEntity(a.target) instanceof LivingEntity tg && tg.isAlive()) {
                        a.pos = tg.position();
                        tg.setDeltaMovement(0, Math.min(0, tg.getDeltaMovement().y), 0);
                        tg.hurtMarked = true;
                        if (a.ticks % 10 == 1) HatsuEffects.stun(tg, 20);
                    }
                    Vec3 m = a.base.add(0, GuanyinTuning.STATUE_MOUTH_HEIGHT, 0).add(a.facing.scale(GuanyinTuning.STATUE_MOUTH_FORWARD));
                    float p = a.ticks / (float) a.windup;
                    level.sendParticles(ParticleTypes.END_ROD, m.x, m.y, m.z, 2 + (int) (p * 8), 0.8 * (1 - p) + 0.1, 0.8 * (1 - p) + 0.1, 0.8 * (1 - p) + 0.1, 0.02);
                } else if (a.ticks == a.windup) {
                    Vec3 from = a.base.add(0, GuanyinTuning.STATUE_MOUTH_HEIGHT, 0).add(a.facing.scale(GuanyinTuning.STATUE_MOUTH_FORWARD));
                    Vec3 aim = a.pos.add(0, 1.0, 0);
                    if (level.getEntity(a.target) instanceof LivingEntity tg && tg.isAlive()) aim = tg.position().add(0, tg.getBbHeight() * 0.5, 0);
                    Vec3 dir = aim.subtract(from);
                    dir = dir.lengthSqr() < 1.0e-4 ? getLookAngle() : dir.normalize();
                    beam(level, from, dir, GuanyinTuning.ZERO_RANGE, GuanyinTuning.ZERO_EXTRA_RADIUS, Guanyin.zeroDamage(a.used), 1.0);
                } else if (a.ticks >= a.windup + 15) {
                    act = null;
                }
            }
        }
    }

    private void ninetyHit(ServerLevel level, Act a) {
        float dmg = hatsuDamage(GuanyinTuning.NINETY_HIT_DAMAGE, GuanyinTuning.NINETY_DAMAGE_PER_LEVEL);
        Vec3 f = a.dir;
        double half = GuanyinTuning.NINETY_HALF_WIDTH;
        Vec3 side = new Vec3(-f.z, 0, f.x);
        Vec3 centre = position().add(f.scale(GuanyinTuning.NINETY_REACH * 0.5));
        AABB box = new AABB(centre, centre).inflate(GuanyinTuning.NINETY_REACH * 0.5 + 1, 5.0, GuanyinTuning.NINETY_REACH * 0.5 + 1);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, this::isFoe)) {
            Vec3 v = e.position().subtract(position());
            double along = v.dot(f), across = Math.abs(v.dot(side));
            if (along < -0.5 || along > GuanyinTuning.NINETY_REACH || across > half + e.getBbWidth() * 0.5) continue;
            hurtFoe(e, dmg);
            e.setDeltaMovement(f.x * 0.12, Math.max(e.getDeltaMovement().y, 0.04), f.z * 0.12);
            e.hurtMarked = true;
        }
        Vec3 p = position().add(f.scale(2 + level.random.nextDouble() * (GuanyinTuning.NINETY_REACH - 2))).add(side.scale((level.random.nextDouble() - 0.5) * 2 * half)).add(0, 0.5 + level.random.nextDouble() * 2.5, 0);
        level.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 4, 0.3, 0.3, 0.3, 0.05);
        if (a.ticks % 6 == 0) level.playSound(null, blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.HOSTILE, 1.0f, 0.6f + level.random.nextFloat() * 0.4f);
        gratitude(PALM_ALIVE);
    }
}
