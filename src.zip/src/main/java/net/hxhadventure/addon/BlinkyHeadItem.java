package net.hxhadventure.addon;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * Blinky's head: the nozzle of Shizuku's vacuum cleaner, a pole ending in a flat mouth full of teeth. Conjured with the Hatsu key and
 * owned by the one who conjured it. Hold right-click and the mouth sucks up the blocks in front of it ({@link Blinky#suckTick});
 * swinging it (Attack, or a left-click) bites. The item itself holds no rules; they live in {@link Blinky} and {@link BlinkyEvents}.
 */
public class BlinkyHeadItem extends Item {
    public BlinkyHeadItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!Blinky.isOwnHead(stack, player)) return InteractionResultHolder.pass(stack); // someone else's: it does nothing for them
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000; // held for as long as the button is
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.NONE;
    }

    @Override
    public void onUseTick(Level level, LivingEntity user, ItemStack stack, int remaining) {
        if (!level.isClientSide && user instanceof ServerPlayer sp) Blinky.suckTick(sp);
    }

    /** Putting the head down or changing slot is not a new "equip": it must not bob while sucking. */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || !oldStack.is(newStack.getItem());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        if (stack.hasTag() && stack.getTag().contains("OwnerName")) {
            tip.add(Component.literal("§7Blinky of " + stack.getTag().getString("OwnerName")));
        }
        tip.add(Component.literal("§8Hold right-click: suck up blocks (no drops)"));
        tip.add(Component.literal("§8Attack: swing the head and bite"));
        tip.add(Component.literal("§8Z: Exsanguinate whoever it bit"));
    }
}
