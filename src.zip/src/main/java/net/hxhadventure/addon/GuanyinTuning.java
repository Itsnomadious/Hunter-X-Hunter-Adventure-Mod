package net.hxhadventure.addon;

/**
 * Every number of Netero's 100-Type Guanyin Bodhisattva (Enhancement Hatsu, kit 17) in one place. See {@link Guanyin}.
 * Damage numbers are "base + per Hatsu level" and are multiplied by Vows sworn on nothing in particular (Guanyin's moves are not bindable).
 */
public final class GuanyinTuning {
    private GuanyinTuning() {}

    // ---- unlock levels (Hatsu level) ----
    public static final int SUMMON_MIN_LEVEL = 5;
    public static final int ASPECT_MIN_LEVEL = 10;
    public static final int FIRST_MIN_LEVEL = 15;
    public static final int THIRD_MIN_LEVEL = 25;
    public static final int NINETY_NINTH_MIN_LEVEL = 35;
    public static final int ZERO_MIN_LEVEL = 50;

    // ---- prayer and enlightenment ----
    /** Prayers followed by an attack (H, then attack) needed to become enlightened. No Vow is needed: praying is optional. */
    public static final int GRATITUDE_NEEDED = 10000;

    // ---- speed, cooldown and damage ----
    /** Before enlightenment every move of the Guanyin runs at this share of its base speed (0.7 = 30% slower). */
    public static final float SLOW_SPEED = 0.7f;
    /** Enlightened: the statue's hands move at this multiple of the base speed (1.5 = 50% faster). */
    public static final float TRUE_SPEED = 1.5f;
    /** Enlightened: every cooldown that still exists is this share of what it was (0.7 = 30% shorter). */
    public static final float TRUE_COOLDOWN_MULT = 0.7f;
    /** Enlightened: damage multiplier (1.1 = +10%). */
    public static final float TRUE_DAMAGE_MULT = 1.1f;
    /** Enlightened, statue not fully manifested: ticks it stays in view after the move's own animation ends (1 = it leaves at once). */
    public static final int TEMP_SHOW_AFTER_TICKS = 1;

    // ---- Aspect of Guanyin (Z): a flash of the golden hand to the user's left, then an Aura Blast from that spot ----
    public static final float ASPECT_COST = 200f;
    public static final int ASPECT_COOLDOWN_TICKS = 80;
    public static final int ASPECT_FLASH_TICKS = 2;            // how long the hand shows before the beam leaves it
    public static final double ASPECT_EXTRA_RANGE = 50.0;      // blocks longer than Aura Blast's range
    public static final double ASPECT_EXTRA_RADIUS = 3.0;      // blocks wider than Aura Blast's cone, everywhere along it
    public static final double ASPECT_SIDE = 3.0;              // how far to the user's left the hand appears
    public static final double ASPECT_KNOCKBACK_MULT = 5.0;    // times the Aura Blast's throw: Aspect of Guanyin launches everything it hits
    public static final float ASPECT_BASE_DAMAGE = 18f;           // was 90
    public static final float ASPECT_DAMAGE_PER_LEVEL = 0.24f;   // was 1.2

    // ---- 100-Type Guanyin Bodhisattva (Z): the statue behind the user ----
    public static final float SUMMON_COST = 400f;
    public static final float SUMMON_UPKEEP = 25f;             // energy per second while it stands
    public static final int SUMMON_COOLDOWN_TICKS = 40;
    public static final double LOTUS_HEIGHT = 1.5;             // how far the user floats above the ground while in the lotus (the statue stays on the ground)
    public static final double STATUE_BACK = 3.5;              // blocks behind the user the statue's centre stands (client draws the same)
    public static final double STATUE_MOUTH_HEIGHT = 7.4;      // where the Zero Hand beam leaves (above the statue's base)
    public static final double STATUE_MOUTH_FORWARD = 1.3;

    // ---- the statue does the user's Attack / Strong attack / Barrage: a 6 x 6 area starting at the user ----
    public static final double ATTACK_REACH = 6.0;             // blocks in front of the user; the area is also 6 wide
    public static final float ATTACK_DAMAGE = 7f;               // times the user's spirit bonus (1 + 0.1 * sqrt(level))
    public static final float STRONG_DAMAGE = 22f;            // fully charged
    public static final float BARRAGE_HIT_DAMAGE = 1f;         // per hit, a hit every tick
    public static final int STRONG_CHARGE_TICKS = 25;
    public static final int BARRAGE_MAX_TICKS = 100;
    public static final int BARRAGE_COOLDOWN_TICKS = 10;           // 0.5 seconds
    public static final int ATTACK_COOLDOWN_TICKS = 10;            // 0.5 seconds, shared by Attack and Strong attack
    public static final double ATTACK_KNOCKBACK = 0.9, STRONG_KNOCKBACK = 2.0, BARRAGE_KNOCKBACK = 0.15;

    /** First Hand and Third Hand can only be aimed this far from the user. */
    public static final double FIRST_THIRD_RANGE = 15.0;

    // ---- First Hand: the statue slams a hand down in a chop ----
    public static final float FIRST_COST = 300f;
    public static final int FIRST_COOLDOWN_TICKS = 100;
    public static final int FIRST_WINDUP_TICKS = 10;           // the hand comes down, then lands
    public static final double FIRST_RADIUS = 5.5;
    public static final float FIRST_BASE_DAMAGE = 52f;
    public static final float FIRST_DAMAGE_PER_LEVEL = 0.6f;

    // ---- Third Hand: the statue claps, trapping the enemy in its grasp ----
    public static final float THIRD_COST = 500f;
    public static final int THIRD_COOLDOWN_TICKS = 200;
    public static final int THIRD_WINDUP_TICKS = 12;
    public static final int THIRD_HOLD_TICKS = 60;             // how long they stay trapped (stunned) in the grasp
    public static final double THIRD_RADIUS = 4.5;
    public static final float THIRD_BASE_DAMAGE = 84f;
    public static final float THIRD_DAMAGE_PER_LEVEL = 1f;

    // ---- Ninety-ninth Hand: a barrage of palm strikes from every arm ----
    public static final float NINETY_COST = 900f;
    public static final int NINETY_COOLDOWN_TICKS = 400;
    public static final int NINETY_DURATION_TICKS = 60;
    public static final int NINETY_HIT_EVERY_TICKS = 1;
    public static final double NINETY_REACH = 14.0;            // length of the area in front of the user
    public static final double NINETY_HALF_WIDTH = 5.0;
    public static final float NINETY_HIT_DAMAGE = 4.6f;
    public static final float NINETY_DAMAGE_PER_LEVEL = 0.08f;

    // ---- Zero Hand: grasp the target from behind, then ALL the user's Nen in one beam from the statue's mouth ----
    public static final int ZERO_COOLDOWN_TICKS = 2400;
    public static final int ZERO_CHARGE_TICKS = 40;            // the grasp and the charge, then the beam
    /** How far away the user can pick the target (30+ blocks works; the beam itself reaches ZERO_RANGE). */
    public static final double ZERO_TARGET_RANGE = 80.0;
    /** Extra aiming slack per block of distance (0.03 = 1.5 blocks more at 50 blocks), so a far target does not need pixel-perfect aim. */
    public static final double ZERO_AIM_TOLERANCE = 0.03;
    /** The statue appears this many blocks behind the target, on the far side from the user (centre of its lotus to the target's feet), facing the user. */
    public static final double ZERO_BEHIND = 8.0;
    /** Ticks the statue takes to appear behind the target (and to go away again afterwards). */
    public static final int ZERO_FADE_TICKS = 6;
    public static final float ZERO_MIN_ENERGY = 1000f;         // there must be something to spend
    public static final float ZERO_BASE_DAMAGE = 598f;           // Level 100, 80000 Nen: 598 x 1.8 x 1.29 (Hatsu) x 1.2 (Enhancer) = ~1666
    public static final float ZERO_DAMAGE_PER_NEN_BLOCK = 0.01f; // +1% of the base damage for every 1000 Nen spent
    public static final float ZERO_NEN_BLOCK = 1000f;
    public static final double ZERO_RANGE = 120.0;
    public static final double ZERO_EXTRA_RADIUS = 4.0;
}
