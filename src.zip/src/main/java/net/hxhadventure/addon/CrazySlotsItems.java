package net.hxhadventure.addon;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/** Registers the weapons Crazy Slots conjures without touching ModItem (same way as Blinky's head). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class CrazySlotsItems {
    private CrazySlotsItems() {}

    public static Item SCYTHE;
    /** The scythe while Silent Waltz is under way: the same item with the blade grown (only the model differs). */
    public static Item SCYTHE_BIG;
    public static Item STAFF;
    public static Item CARBINE;

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.ITEMS, helper -> {
            SCYTHE = new CrazyWeaponItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), CrazySlots.Weapon.SCYTHE, false);
            SCYTHE_BIG = new CrazyWeaponItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), CrazySlots.Weapon.SCYTHE, true);
            STAFF = new CrazyWeaponItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), CrazySlots.Weapon.STAFF, false);
            CARBINE = new CrazyGunItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), CrazySlots.Weapon.CARBINE); // drawn with HxH Craft's clown shotgun model
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "crazy_scythe"), SCYTHE);
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "crazy_scythe_big"), SCYTHE_BIG);
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "crazy_staff"), STAFF);
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "crazy_carbine"), CARBINE);
        });
    }
}
