package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;

public final class AddonServerEvents {
    private AddonServerEvents() {}

    /** Registers the addon channel; no edit to HxHAdventure.java needed. */
    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Setup {
        @SubscribeEvent
        public static void onCommonSetup(FMLCommonSetupEvent event) {
            event.enqueueWork(AddonNetwork::register);
        }
    }

    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class Game {
        /** /hxh debug: how often the player tick handlers are called, and the last error they hit (null = none). */
        public static volatile int dbgStartCalls, dbgStartServer, dbgEndCalls;
        public static volatile String dbgError;

        /**
         * The per-tick Nen work for the START phase. It is called from onPlayerTickEnd below: a separate @SubscribeEvent method for
         * the START phase was never invoked in game (the counters of /hxh debug showed 0 calls), while onPlayerTickEnd was.
         */
        private static void runStartTick(TickEvent.PlayerTickEvent event) {
            dbgStartCalls++;
            if (event.phase == TickEvent.Phase.START && event.player instanceof ServerPlayer sp) {
                dbgStartServer++;
                try {
                    NenAddonData.get(sp).tick(sp);
                } catch (Throwable t) {
                    dbgError = t.toString() + " at " + (t.getStackTrace().length > 0 ? t.getStackTrace()[0] : "?");
                    com.mojang.logging.LogUtils.getLogger().error("[hxh debug] NenAddonData.tick threw", t);
                    throw t;
                }
                ChainManager.tick(sp);
                DoctorBlythe.tick(sp);
                Terpsichora.tick(sp);
                ExplosiveOrbs.tick(sp);
                DragonHead.tick(sp);
                BungeeGum.tick(sp);
                LightningAura.tick(sp);
                HideAndSeek.tick(sp);
                Guanyin.tick(sp);
                PainPacker.tick(sp);
                GumCards.tick(sp);
                BungeeBarrier.tick(sp);
                Prayer.tick(sp);
            }
        }

        /** Hunger: once Nen is awakened, food drains at a quarter of the normal speed. */
        private static final float HUNGER_RATE = 0.25f;
        private static final java.util.Map<java.util.UUID, Float> LAST_EXHAUSTION = new java.util.HashMap<>();

        @SubscribeEvent
        public static void onPlayerTickEnd(TickEvent.PlayerTickEvent event) {
            dbgEndCalls++;
            if (event.phase == TickEvent.Phase.START) {
                runStartTick(event);
                return;
            }
            if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer sp)) return;
            Combat c = Combat.get(sp);
            if (c == null || !c.hasNenUnlocked()) {
                LAST_EXHAUSTION.remove(sp.getUUID());
                return;
            }
            net.minecraft.world.food.FoodData food = sp.getFoodData();
            float cur = food.getExhaustionLevel();
            Float last = LAST_EXHAUSTION.get(sp.getUUID());
            if (last != null && cur > last) {
                cur = last + (cur - last) * HUNGER_RATE; // only a quarter of what was just spent counts
                food.setExhaustion(cur);
            }
            LAST_EXHAUSTION.put(sp.getUUID(), cur);
        }

        @SubscribeEvent
        public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
            LAST_EXHAUSTION.remove(event.getEntity().getUUID());
            Prayer.forget(event.getEntity().getUUID());
        }

        @SubscribeEvent
        public static void onServerStopped(ServerStoppedEvent event) {
            DragonDive.clearAll();
        }

        /**
         * Sworn En restriction ("En reaches 1 meter"): while En is on, one attack in five from another creature is simply dodged.
         * Runs before any damage or knockback; things that cannot be dodged (void, starvation, kill commands, Vow penalties) are left alone.
         */
        @SubscribeEvent(priority = EventPriority.HIGH)
        public static void onAttackDodge(LivingAttackEvent event) {
            if (!(event.getEntity() instanceof ServerPlayer vp) || vp.level().isClientSide) return;
            DamageSource src = event.getSource();
            if (src.getEntity() == null && src.getDirectEntity() == null) return;
            if (src.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY)) return;
            if (!Vows.enRangeLimited(vp)) return;
            NenAddonData vd = NenAddonData.peek(vp);
            Combat vc = Combat.get(vp);
            if (vd == null || vc == null || !vc.hasNenUnlocked() || !vd.en) return;
            if (vp.getRandom().nextFloat() >= Vows.EN_DODGE_CHANCE) return;
            event.setCanceled(true);
            vp.displayClientMessage(net.minecraft.network.chat.Component.literal("\u00a7dEn: dodged"), true);
            vp.level().playSound(null, vp.blockPosition(), net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_SWEEP, net.minecraft.sounds.SoundSource.PLAYERS, 0.6f, 1.7f);
        }

        /** Whatever the Bungee Gum is dragging in cannot attack (nor can anyone tied up by Bungee Bind). Runs before damage or knockback. */
        @SubscribeEvent(priority = EventPriority.HIGH)
        public static void onGummedAttack(LivingAttackEvent event) {
            if (event.getEntity().level().isClientSide) return;
            Entity attacker = event.getSource().getEntity();
            if (attacker != null && BungeeGum.cannotAttack(attacker)) event.setCanceled(true);
        }

        @SubscribeEvent(priority = EventPriority.LOW)
        public static void onHurt(LivingHurtEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide) return;
            Entity rawCause = event.getSource().getEntity();
            if (rawCause != null && victim.getUUID().equals(SkillHunter.controllerOf(rawCause.getUUID()))) {
                event.setCanceled(true); // puppets cannot hurt the one pulling the strings
                return;
            }
            DamageSource src = event.getSource();
            float amount = event.getAmount();
            Entity cause = src.getEntity();
            Entity direct = src.getDirectEntity();
            // Bungee Gum: a user's melee hits build "Properties of Rubber and Gum" up on the victim (now done first of all, in GumHitEvents)
            // Bungee Gum state (H): whoever hits the user in melee gets Rubber and Gum too
            if (victim instanceof ServerPlayer gumVictim && cause instanceof LivingEntity gumHitter && gumHitter != victim && direct == cause) BungeeGum.onMeleeReceived(gumVictim, gumHitter);

            ServerPlayer attacker = null;
            boolean viaSummon = false;
            if (cause instanceof ServerPlayer sp) {
                attacker = sp;
            }
            if (attacker != null && attacker != victim) {
                Prayer.noteHit(attacker); // satisfies any "if it misses, I die" Vow
                Combat c = Combat.get(attacker);
                if (c != null && c.hasNenUnlocked()) {
                    NenAddonData d = NenAddonData.get(attacker);
                    int type = d.effType(c);
                    float mult = Affinity.dealt(type);
                    if (viaSummon) mult *= Affinity.summon(type);
                    else if (direct != cause && direct instanceof Projectile) mult *= Affinity.projectile(type);
                    boolean melee = direct == cause && !(direct instanceof Projectile);
                    mult *= Vows.isHatsuHit(src) ? d.hatsuFormMult(c) : d.outgoingFormMult(c, melee); // Hatsu hits ignore Ten / Ren / Ken (Ko still counts)
                    if (d.emperor) mult *= Tuning.EMPEROR_BOOST;
                    // Gon's adult form: Attack / Strong attack / Barrage get 2x Ren's bonus + Ko's; Hatsu hits (the Rock) and the rest stay x10
                    mult *= !Vows.isHatsuHit(src) && melee ? GonVow.meleeFactor(attacker, d, c) : GonVow.damageMult(attacker);
                    if (!Vows.isHatsuHit(src) && melee) mult *= Shu.damageMult(attacker, d); // Shu: aura on the weapon in hand
                    mult *= LightningAura.damageMult(attacker); // Godspeed: moderately more damage
                    if (direct == cause) mult *= Prayer.damageMult(attacker); // sworn rules on Attack / Strong attack / Barrage, and the prayer Condition
                    amount *= mult;
                    if (!viaSummon && d.hitXpCooldown <= 0) { // landing a hit trains Ten
                        d.addXp(NenSkill.TEN, 0.5f, c);
                        if (!Vows.isHatsuHit(src) && melee && d.shu && Shu.isWeapon(attacker.getMainHandItem())) d.addXp(NenSkill.SHU, 0.5f, c);
                        d.hitXpCooldown = 10;
                    }
                }
                amount *= Terpsichora.damageMult(attacker); // 1.8x while active, 2.5x post-mortem
                amount *= CrazySlots.chimeraDamageMult(attacker, src); // a Chimera Ant's Attack, Strong attack and Barrage: x2
            }

            // Manipulator: summons (puppets, controlled bodies) hit harder and take less damage
            {
                ServerPlayer summonOwner = summonOwner(victim.getServer(), victim);
                if (summonOwner != null) {
                    Combat oc = Combat.get(summonOwner);
                    if (oc != null && oc.hasNenUnlocked()) amount /= Affinity.summon(NenAddonData.get(summonOwner).effType(oc));
                }
            }
            if (rawCause != null && !(rawCause instanceof ServerPlayer)) {
                ServerPlayer summonOwner = summonOwner(victim.getServer(), rawCause);
                if (summonOwner != null) {
                    Combat oc = Combat.get(summonOwner);
                    if (oc != null && oc.hasNenUnlocked()) amount *= Affinity.summon(NenAddonData.get(summonOwner).effType(oc));
                }
            }

            if (victim instanceof ServerPlayer vp) {
                Combat vc = Combat.get(vp);
                if (vc != null && vc.hasNenUnlocked()) {
                    NenAddonData vd = NenAddonData.get(vp);
                    int type = vd.effType(vc);
                    float mult = Affinity.taken(type);
                    if (src.is(DamageTypes.LIGHTNING_BOLT)) mult *= 1f - Affinity.lightningReduction(type);
                    if (src.is(DamageTypes.FALL)) mult *= 1f - Affinity.fallReduction(type);
                    if (Affinity.isStatusDamage(src)) mult *= 1f - Affinity.statusReduction(type);
                    mult *= vd.incomingFormMult(vc);
                    mult *= BungeeGum.incomingMult(vp); // Bungee Gum state: -10% damage taken
                    if (vd.emperor) mult /= Tuning.EMPEROR_BOOST;
                    mult /= GonVow.durabilityFactor(vp, vd, vc); // Gon's adult form: Ren's durability + 100%
                    if (vd.zetsu) mult *= 1f + vd.zetsuPenalty();
                    mult *= Shu.takenMult(vd); // Shu: the coating costs you, you take more damage while it is on
                    float beforeDur = amount;
                    amount *= mult;
                    float ignore = Jajanken.pierce(victim); // Scissors ignores part of the durability
                    if (ignore > 0f && amount < beforeDur) amount += ignore * (beforeDur - amount);
                    if (vd.hitXpCooldown <= 0) { // taking a hit trains Ten
                        vd.addXp(NenSkill.TEN, 0.25f, vc);
                        vd.hitXpCooldown = 10;
                    }
                }
            }
            event.setAmount(amount);
        }

        /** The player who controls this entity as a summon (Puppeteer, Illumi's needles, Skill Hunter), or null. */
        private static ServerPlayer summonOwner(net.minecraft.server.MinecraftServer server, Entity e) {
            if (server == null || e == null || e instanceof ServerPlayer) return null;
            java.util.UUID id = Puppeteer.controllerOf(e);
            if (id == null) id = IllumiNeedles.controllerOf(e);
            if (id == null) id = SkillHunter.controllerOf(e.getUUID());
            if (id == null) id = BlackVoice.controllerOf(e.getUUID());
            return id == null ? null : server.getPlayerList().getPlayer(id);
        }

        /** Kite: a Forced Zetsu / chained NPC drops an aura it already had (activation itself is refused by KiteEntityMixin). */
        @SubscribeEvent
        public static void onNpcTick(net.minecraftforge.event.entity.living.LivingEvent.LivingTickEvent event) {
            if (!(event.getEntity() instanceof net.hxhadventure.entity.custom.KiteEntity npc)) return;
            if (npc.level().isClientSide || !ExtrasHooks.hatsuForced(npc)) return;
            net.hxhadventure.addon.mixin.KiteAccess acc = (net.hxhadventure.addon.mixin.KiteAccess) (Object) npc;
            if (acc.hxh$isNenActive()) acc.hxh$deactivateNenAura();
        }

        /** Zetsu stealth: mobs cannot newly acquire a Zetsu player beyond the stealth range. */
        @SubscribeEvent
        public static void onChangeTarget(LivingChangeTargetEvent event) {
            if (event.getNewTarget() != null && ChainManager.isJailed(event.getEntity())) {
                event.setCanceled(true); // a chained mob cannot pick a new target, so its AI stops fighting the jail
                return;
            }
            java.util.UUID boss = SkillHunter.controllerOf(event.getEntity().getUUID());
            LivingEntity nt = event.getNewTarget();
            if (boss != null && nt != null && (nt.getUUID().equals(boss) || boss.equals(SkillHunter.controllerOf(nt.getUUID())))) {
                event.setCanceled(true);
                return;
            }
            if (!(event.getNewTarget() instanceof ServerPlayer p)) return;
            LivingEntity mob = event.getEntity();
            if (mob.level().isClientSide) return;
            NenAddonData d = NenAddonData.peek(p);
            if (d == null || !d.zetsu) return;
            double r = d.zetsuStealthRange();
            if (mob.distanceToSqr(p) > r * r) event.setCanceled(true);
        }

        @SubscribeEvent
        public static void onServerTick(TickEvent.ServerTickEvent event) {
            if (event.phase == TickEvent.Phase.END) {
                SkillHunter.tickGlobal(event.getServer());
                ExplosiveOrbs.tickGlobal(event.getServer());
                DragonDive.tickAll(event.getServer());
                BungeeGum.tickGlobal(event.getServer());
                BungeeBind.tickGlobal(event.getServer());
            }
        }

        /** Gallery Fake copies are inanimate: no loot, no experience. */
        @SubscribeEvent
        public static void onFakeDrops(net.minecraftforge.event.entity.living.LivingDropsEvent event) {
            if (SkillHunter.isFake(event.getEntity())) event.setCanceled(true);
            else SkillHunter.stripBookDrops(event.getDrops());
        }

        /** Touching a dropped Skill Hunter book completes a theft if the toucher just answered the question. */
        /** A player who comes into view of someone in Emperor Time sees the red eyes straight away. */
        @SubscribeEvent
        public static void onStartTracking(PlayerEvent.StartTracking event) {
            // a Dowsing Chain mark on whatever just came into view (the client only draws it for the owner and for Gyo)
            if (event.getEntity() instanceof ServerPlayer markViewer) ChainManager.sendMarkTo(event.getTarget(), markViewer);
            if (event.getTarget() instanceof ServerPlayer target && event.getEntity() instanceof ServerPlayer viewer) {
                NenAddonData d = NenAddonData.peek(target);
                if (d != null && d.emperor) AddonNetwork.sendToPlayer(new net.hxhadventure.addon.network.PacketEmperorFx(target.getId(), true), viewer);
                if (d != null && d.chainHand) AddonNetwork.sendToPlayer(new net.hxhadventure.addon.network.PacketChainHand(target.getId(), true), viewer);
                if (d != null && d.formSent() != AuraForm.NONE) AddonNetwork.sendToPlayer(new net.hxhadventure.addon.network.PacketAuraForm(target.getId(), d.formSent()), viewer);
                if (d != null && d.hiddenNow()) AddonNetwork.sendToPlayer(new net.hxhadventure.addon.network.PacketInFx(target.getId(), true), viewer);
                DoctorBlythe.sendTo(target, viewer);
                Terpsichora.sendTo(target, viewer);
                Guanyin.sendTo(target, viewer);
                PainPacker.sendTo(target, viewer);
                ExplosiveOrbs.sendTo(target, viewer);
            }
        }

        @SubscribeEvent
        public static void onBookPickup(net.minecraftforge.event.entity.player.EntityItemPickupEvent event) {
            if (event.getEntity().level().isClientSide) return;
            if (SkillHunter.onBookTouched(event.getEntity(), event.getItem())) event.setCanceled(true);
        }

        @SubscribeEvent
        public static void onFakeXp(net.minecraftforge.event.entity.living.LivingExperienceDropEvent event) {
            if (SkillHunter.isFake(event.getEntity())) event.setCanceled(true);
        }

        @SubscribeEvent
        public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
            if (event.getEntity() instanceof ServerPlayer sp) {
                NenAddonData d = NenAddonData.get(sp);
                d.zetsu = false;
                d.en = false;
                d.in = false;
                d.gyo = false;
                d.emperor = false;
                d.bookState = 0;
                d.bookmark = -1;
                d.activePage = -1;
                d.markSync();
                ChainManager.clearCooldowns(sp);
            }
        }

        @SubscribeEvent
        public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
            ChainManager.clear(event.getEntity());
            DoctorBlythe.clear(event.getEntity());
            Terpsichora.onLogout(event.getEntity());
            ExplosiveOrbs.clear(event.getEntity());
            AuraBlast.clear(event.getEntity());
            DragonHead.clear(event.getEntity());
            BungeeGum.clear(event.getEntity());
            LightningAura.clear(event.getEntity());
            HideAndSeek.clear(event.getEntity());
            Guanyin.clear(event.getEntity());
            PainPacker.clear(event.getEntity());
            GumCards.clear(event.getEntity());
            SkillHunter.clear(event.getEntity());
            NenAddonData d = NenAddonData.peek(event.getEntity());
            if (d != null) {
                d.clearFormAura();
                d.save();
            }
        }

        @SubscribeEvent
        public static void onSave(PlayerEvent.SaveToFile event) {
            NenAddonData d = NenAddonData.peek(event.getEntity());
            if (d != null) d.save();
        }

        @SubscribeEvent
        public static void onClone(PlayerEvent.Clone event) {
            NenAddonData old = NenAddonData.peek(event.getOriginal());
            if (old != null) old.save();
            if (event.getOriginal().getPersistentData().contains(NenAddonData.TAG)) {
                net.minecraft.nbt.CompoundTag copy = event.getOriginal().getPersistentData().getCompound(NenAddonData.TAG).copy();
                if (event.isWasDeath()) copy.putFloat("lifespan", Tuning.LIFESPAN_MAX); // a new life has a full lifespan
                event.getEntity().getPersistentData().put(NenAddonData.TAG, copy);
            }
        }

        /**
         * Terpsichora: the first death of a user with it out is refused and the corpse keeps fighting. Runs before every
         * other death handler (including HxHAdventure's, which resets the player's Nen), so a refused death changes nothing.
         */
        @SubscribeEvent(priority = EventPriority.HIGHEST)
        public static void onLethalDeath(net.minecraftforge.event.entity.living.LivingDeathEvent event) {
            if (event.getEntity() instanceof ServerPlayer sp) Terpsichora.onLethal(sp, event);
        }

        @SubscribeEvent
        public static void onDeath(net.minecraftforge.event.entity.living.LivingDeathEvent event) {
            if (event.getEntity() instanceof net.minecraft.world.entity.player.Player p) {
                ChainManager.clear(p);
                DoctorBlythe.clear(p);
                Terpsichora.clear(p);
                ExplosiveOrbs.clear(p);
                DragonHead.clear(p);
                BungeeGum.clear(p);
                LightningAura.clear(p);
                if (p instanceof ServerPlayer hsDead && HideAndSeek.canUse(Combat.get(hsDead))) HideAndSeek.onLost(hsDead);
                HideAndSeek.clear(p);
                Guanyin.clear(p);
                PainPacker.clear(p);
                GumCards.clear(p);
                SkillHunter.clear(p);
                NenAddonData d = NenAddonData.peek(p);
                if (d != null) {
                    d.clearFormAura();
                    d.resetLifespan(); // dying starts a new life at full lifespan
                }
                if (p instanceof ServerPlayer dead) ChainManager.clearCooldowns(dead);
            }
        }

        @SubscribeEvent
        public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
            if (event.getEntity() instanceof ServerPlayer sp) {
                NenAddonData d = NenAddonData.get(sp);
                if (!event.isEndConquered()) d.resetLifespan(); // belt and braces: respawn always has the full 100 years
                d.markSync();
            }
        }
    }
}
