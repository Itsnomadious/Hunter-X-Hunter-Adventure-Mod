package net.hxhadventure.addon;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

/** Menchi, a single-star gourmet Hunter waiting on the third floor. Before the first test is beaten she sends you to Satotz. */
public class MenchiEntity extends ExamNpcEntity {
    public MenchiEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    @Override
    public int examKind() {
        return HunterExam.KIND_MENCHI;
    }
}
