package net.hxhadventure.addon;

import net.hxhadventure.abilities.Combat;

/**
 * Every number that defines the Chrollo NPC, in one place. Skill levels are the ones he was designed with
 * (a "genius level" NPC); the combat numbers are HxHAdventure's own player numbers (Combat.java), so he fights
 * exactly like a player of those levels would.
 */
public final class ChrolloTuning {
    private ChrolloTuning() {}

    // ---- levels: a level 100 Nen master. His skill levels: Ten 96, Zetsu 100, Ren 92, En 90, Hatsu 100, In 80, Gyo 96 ----
    public static final int LEVEL = 100;
    public static final int HATSU_LEVEL = 100;
    public static final int TEN_LEVEL = 96;
    public static final int ZETSU_LEVEL = 100;
    public static final int KEN_LEVEL = TEN_LEVEL;   // Ken has no skill of its own in the base mod: its numbers are read from Ten's level
    public static final int REN_LEVEL = 92;
    public static final int EN_LEVEL = 90;
    public static final int GYO_LEVEL = 96;
    public static final int IN_LEVEL = 80;
    public static final int NEN_TYPE = Combat.NEN_SPECIALIZATION;   // Chrollo is a Specialist: gets the Specialist affinity bonuses

    /** The level of a Nen skill for this NPC, for anything that wants to compare it with a player's (En vs In, Gyo, ...). */
    public static int skillLevel(NenSkill s) {
        return switch (s) {
            case TEN -> TEN_LEVEL;
            case REN -> REN_LEVEL;
            case EN -> EN_LEVEL;
            case GYO -> GYO_LEVEL;
            case IN -> IN_LEVEL;
            case ZETSU -> ZETSU_LEVEL;
            case HATSU -> HATSU_LEVEL;
            default -> 1;
        };
    }

    // ---- body ----
    public static final double MAX_HEALTH = 160.0;
    public static final double BASE_SPEED = 0.29;
    public static final double FOLLOW_RANGE = 64.0;
    public static final double KNOCKBACK_RESISTANCE = 0.4;
    public static final float HEAL_PER_SECOND = 1.0f;            // while Ten is up and he has not been hit for 2 s
    public static final int FOE_MEMORY_TICKS = 1200;             // how long something that hurt him counts as an enemy (gum / area hits)

    // ---- aura pool ----
    /** His pool is the old player formula (Tuning.npcMaxNen) for his levels, times this. Kept on the old formula when player aura was rescaled, so his pool did not change. */
    public static final float AURA_POOL_MULT = 0.25f;
    public static final float EXHAUST_RESUME_FRACTION = 0.10f;   // after running dry he needs this share of his pool back before any Nen returns
    public static final float EXHAUST_REGEN_PCT = 0.008f;        // share of max aura per second while recovering (the Zetsu rate)
    public static final float REST_REGEN_PCT = 0.004f;           // share of max aura per second while at peace
    public static final int REST_DELAY_TICKS = 100;              // peace has to last this long first
    public static final float BASE_REGEN = 0.5f;                 // per second with Ten off (Combat.getScaledRegeneration)

    /** Ten's regen per second, the same as a player's: Combat's scaled regeneration x5.5 plus the Ten skill's flat amount. */
    public static float tenRegenPerSecond() {
        float s = (float) Math.sqrt(HATSU_LEVEL);
        float scaled = Math.min(0.5f + HATSU_LEVEL * 0.1f * (1f + s * 0.1f), 2.0f);
        return scaled * 5.5f + Tuning.tenRegen(TEN_LEVEL);
    }

    public static float maxAura() {
        return Tuning.npcMaxNen(HATSU_LEVEL, TEN_LEVEL, REN_LEVEL) * AURA_POOL_MULT;
    }

    // ---- stance behaviour ----
    public static final int FORM_SWITCH_TICKS = 5;

    // ---- attacks (Combat.java's numbers) ----
    public static final double REACH = 2.5;                      // blocks from him to the edge of the target at which he starts punching
    public static final int PUNCH_GAP_TICKS = 10;
    public static final float PUNCH_DAMAGE = 5.0f, PUNCH_RANGE = 1.5f;
    public static final float STRONG_DAMAGE = 15.0f, STRONG_RANGE = 2.0f;
    public static final double STRONG_KNOCKBACK = 1.4;
    public static final int STRONG_CHARGE_TICKS = 40;
    public static final int STRONG_MAX_HOLD_TICKS = 55;          // if the target is out of reach he lets it go anyway at this point
    public static final int STRONG_COOLDOWN_TICKS = 100;
    public static final float BARRAGE_DAMAGE = 1.5f;
    public static final int BARRAGE_TICKS = 36;
    public static final int BARRAGE_HIT_GAP = 3;
    public static final int BARRAGE_COOLDOWN_TICKS = 60;
    public static final boolean BARRAGE_IGNORES_IFRAMES = true;  // false: a barrage is held back by invulnerability frames like a player's
    public static final float ATTACK_SLOW = 0.20f, STRONG_SLOW = 0.50f, BARRAGE_SLOW = 0.40f;
    public static final int PUNCH_ANIM_TICKS = 9;
    public static final float PUNCH_WEIGHT_BARRAGE = 0.22f, PUNCH_WEIGHT_STRONG = 0.20f;

    // ---- Skill Hunter pages ----
    public static final float STAMP_COST = 75f, MARK_COST = 100f;                 // the player's costs (SkillHunter)
    public static final int STAMP_COOLDOWN_TICKS = 600, STAMP_TICKS = 120;        // Order Stamp: seals the target's Nen (Forced Zetsu) for 6 s
    public static final int MARK_COOLDOWN_TICKS = 500, MARK_FUSE_TICKS = 60;      // The Sun and Moon: the mark goes off 3 s after it is placed
    public static final double MARK_RADIUS = 3.5;
    public static final boolean MARKS_BREAK_BLOCKS = true;                        // the blasts of his marks and detonating Bystanders break blocks
    public static final float MARK_BLOCK_POWER = 3.0f;                            // explosion power for the blocks (TNT is 4); a detonating pair is PAIR_BONUS times it
    public static final float MARK_DAMAGE = 6.0f;                                 // before his spirit bonus

    // ---- Skill Hunter pages: Gallery Fake (bystanders), Black Voice, Convert Hands ----
    public static final int MAX_BYSTANDERS = 40;                                  // most he can have out at once
    public static final float GALLERY_COST = 50f, BLACK_VOICE_COST = 100f, CONVERT_COST = 125f;
    public static final int GALLERY_COOLDOWN_TICKS = 40;                          // one bystander per use
    public static final int BLACK_VOICE_COOLDOWN_TICKS = 300, BLACK_VOICE_TICKS = 400, MAX_PUPPETS = 3;
    public static final int CONVERT_COOLDOWN_TICKS = 500;
    public static final int CONVERT_MIN_HOLD_TICKS = 160;                         // he holds the disguise at least this long before using another page
    public static final int PAGE_GCD_TICKS = 15;                                  // gap between two pages
    public static final int BOOK_AWAY_TICKS = 200;                                // no fight for this long: the book goes away and the bystanders fade
    public static final double SUN_MOON_SHARE_RADIUS = 4.0;                       // a bystander this close to him gets the opposite mark
    public static final double SUN_MOON_TOUCH = 2.0;                              // marked bystander this close to the marked target: the pair detonates
    public static final double BRAND_BOOM_GAP = 1.0;                              // a Sun and a Moon Bystander this close to each other AND to his target go off together (blocks between them)
    public static final float PAIR_BONUS = 1.5f;                                  // damage and radius of a detonating pair vs a lone mark
    // Convert Hands: where he ends up (safe block, close to the crowd)
    public static final double CONVERT_RANGE = 8.0;
    public static final double CONVERT_MAX_DX = 5.0;
}
