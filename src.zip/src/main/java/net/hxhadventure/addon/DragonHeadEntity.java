package net.hxhadventure.addon;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.UUID;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Zeno's Dragon Head: a 60 block golden dragon of aura. Only its head is a real hitbox; the body is a path of positions the
 * head has flown through (recorded every tick on server and client alike), which is what makes it slither: the renderer lays
 * the body along that path and ripples it. Up to five riders sit along the body at fixed distances behind the head.
 *
 * Steering is server side: the first rider's look direction is where it flies, W is forward, S brakes. With nobody steering
 * it hovers in place. It never expires by itself; its owner dismisses it (DragonHead ability), or it vanishes if the owner
 * dies or leaves. Riders who fall off or are dropped get Slow Falling so a dismissal mid-air is survivable.
 */
public class DragonHeadEntity extends Entity {
    /** Spacing of recorded trail points, blocks. */
    public static final double STEP = 0.25;
    private static final int TRAIL_MAX = (int) (Tuning.DRAGON_LENGTH / STEP) + 24;
    /** Distance behind the head (along the body) of each of the five seats. */
    private static final double[] SEATS = {3.0, 9.0, 15.0, 21.0, 27.0};
    /** The hitbox is 3.5 tall and the path runs through its centre. */
    public static final double CENTRE_HEIGHT = 1.75;
    /** Dragon Dive progress: -1 = not diving, otherwise ticks since the dive began (synced so the renderer can animate it). */
    private static final EntityDataAccessor<Integer> DIVE = SynchedEntityData.defineId(DragonHeadEntity.class, EntityDataSerializers.INT);

    private UUID owner;
    private Vec3 velocity = Vec3.ZERO;
    /** Blocks moved last tick, smoothed: drives the slither's amplitude on both sides. */
    private double speed;
    private Vec3 lastCentre;
    private final ArrayDeque<Vec3> trail = new ArrayDeque<>();
    private final Map<UUID, Integer> rammed = new HashMap<>();
    /** Where an NPC owner (Zeno) wants the dragon to fly; null = hover. Set every tick by the owner, since nobody rides it to steer. */
    private Vec3 npcGoal;

    public void setNpcGoal(Vec3 goal) {
        this.npcGoal = goal;
    }

    public DragonHeadEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noCulling = true;
        this.setNoGravity(true);
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
    }

    public UUID getOwnerId() {
        return owner;
    }

    public double speed() {
        return speed;
    }

    public Vec3 centre() {
        return position().add(0, CENTRE_HEIGHT, 0);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DIVE, -1);
    }

    public boolean isDiving() {
        return this.entityData.get(DIVE) >= 0;
    }

    /** Ticks since the dive began, or -1. */
    public int diveTicks() {
        return this.entityData.get(DIVE);
    }

    /** Dragon Dive: everyone climbs off, the dragon stops and coils into rings (see serverTick for the rest). */
    public void startDive() {
        if (level().isClientSide || isDiving()) return;
        ejectPassengers();
        this.entityData.set(DIVE, 0);
        level().playSound(null, getX(), getY(), getZ(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.PLAYERS, 5.0f, 0.6f);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    // ---------------- being a thing in the world ----------------
    @Override
    public boolean isPickable() {
        return !isRemoved();
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    /** Immune to everything except /kill and the void. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            if (!level().isClientSide) discard();
            return true;
        }
        return false;
    }

    /** Right-click the head to climb on (the owner and their allies), up to five riders. */
    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (!level().isClientSide && !isDiving() && !player.isSecondaryUseActive() && getPassengers().size() < Tuning.DRAGON_MAX_RIDERS) {
            Player o = owner == null ? null : level().getPlayerByUUID(owner);
            if (o == null || player == o || AllianceUtils.isAlly(player, o)) player.startRiding(this);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return !isDiving() && getPassengers().size() < Tuning.DRAGON_MAX_RIDERS;
    }

    /** Dropped riders get a few seconds of Slow Falling: dismounting, or being dismissed mid-air, should not kill. */
    @Override
    protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (!level().isClientSide && passenger instanceof LivingEntity le) {
            le.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0, false, false, false));
        }
    }

    /** Riders stay exactly where they were dropped (no snapping to the ground beside a dragon that is 100 blocks up). */
    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        return passenger.position();
    }

    /** Each rider sits on top of the body at their seat's distance behind the head. */
    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!hasPassenger(passenger)) return;
        int seat = Math.max(0, getPassengers().indexOf(passenger));
        double d = SEATS[Math.min(seat, SEATS.length - 1)];
        ensureTrail();
        Vec3[] pts = resample(centre(), STEP, (int) (d / STEP) + 2);
        Vec3 p = pts[Math.min(pts.length - 1, (int) Math.round(d / STEP))];
        double r = bodyRadius(d);
        callback.accept(passenger, p.x, p.y + r * 0.8 + passenger.getMyRidingOffset(), p.z);
    }

    /** Body thickness (radius) at a distance behind the head: thick at the neck, thin at the tail. Shared with the renderer. */
    public static double bodyRadius(double s) {
        double f = Math.max(0, 1 - s / Tuning.DRAGON_LENGTH);
        return (0.12 + 0.78 * Math.pow(f, 0.7)) * Tuning.DRAGON_THICKNESS;
    }

    // ---------------- the path the body follows ----------------
    private void ensureTrail() {
        if (!trail.isEmpty()) return;
        double yaw = Math.toRadians(getYRot());
        Vec3 back = new Vec3(Math.sin(yaw), 0, -Math.cos(yaw)); // straight behind where it faces
        Vec3 c = centre();
        for (int i = 1; i <= TRAIL_MAX; i++) trail.addLast(c.add(back.scale(STEP * i)));
        lastCentre = c;
    }

    private void recordTrail() {
        ensureTrail();
        Vec3 head = centre();
        Vec3 last = trail.peekFirst();
        Vec3 d = head.subtract(last);
        double len = d.length();
        if (len >= STEP) {
            Vec3 dir = d.scale(1.0 / len);
            while (len >= STEP) {
                last = last.add(dir.scale(STEP));
                trail.addFirst(last);
                len -= STEP;
            }
            while (trail.size() > TRAIL_MAX) trail.removeLast();
        }
        speed = Mth.lerp(0.3, speed, head.distanceTo(lastCentre));
        lastCentre = head;
    }

    /**
     * `count` points evenly `step` apart along the path, starting at `head` (which may be a partial-tick position)
     * and running back along the recorded trail. If the trail runs out the last point repeats.
     */
    public Vec3[] resample(Vec3 head, double step, int count) {
        ensureTrail();
        Vec3[] out = new Vec3[Math.max(1, count)];
        out[0] = head;
        int k = 1;
        double remaining = step;
        Vec3 a = head;
        Iterator<Vec3> it = trail.iterator();
        while (k < out.length && it.hasNext()) {
            Vec3 b = it.next();
            double seg = a.distanceTo(b);
            while (k < out.length && seg >= remaining && seg > 1e-9) {
                a = a.add(b.subtract(a).scale(remaining / seg));
                out[k++] = a;
                seg = a.distanceTo(b);
                remaining = step;
            }
            remaining -= seg;
            a = b;
        }
        while (k < out.length) out[k++] = a;
        return out;
    }

    // ---------------- tick ----------------
    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) serverTick();
        recordTrail();
    }

    private Player driver() {
        for (Entity e : getPassengers()) if (e instanceof Player p) return p;
        return null;
    }

    private void serverTick() {
        Entity oe = owner != null && level() instanceof net.minecraft.server.level.ServerLevel sl0 ? sl0.getEntity(owner) : null;
        LivingEntity o = oe instanceof LivingEntity le0 ? le0 : null;
        if (o == null || !o.isAlive() || o.level() != level()) { // its owner is gone: so is the dragon
            discard();
            return;
        }
        if (isDiving()) {
            diveTick(o);
            return;
        }
        Player driver = driver();
        Vec3 desired = Vec3.ZERO;
        if (driver != null) {
            Vec3 look = driver.getLookAngle();
            if (driver.zza > 0) desired = look.scale(Tuning.DRAGON_SPEED);
            else if (driver.zza < 0) desired = look.scale(-Tuning.DRAGON_SPEED * 0.25);
            setYRot(Mth.rotLerp(0.25f, getYRot(), driver.getYRot()));
            setXRot(Mth.lerp(0.25f, getXRot(), driver.getXRot()));
        } else if (npcGoal != null) { // an NPC owner flies it at its target
            Vec3 to = npcGoal.subtract(centre());
            if (to.lengthSqr() > 4.0) desired = to.normalize().scale(Tuning.DRAGON_SPEED * 0.6);
            if (velocity.lengthSqr() > 0.01) {
                setYRot((float) (Mth.atan2(-velocity.x, velocity.z) * (180.0 / Math.PI)));
                setXRot((float) -(Math.asin(Mth.clamp(velocity.normalize().y, -1, 1)) * (180.0 / Math.PI)));
            }
        } else if (velocity.lengthSqr() > 0.01) { // coasting: face the way it is going
            setYRot((float) (Mth.atan2(-velocity.x, velocity.z) * (180.0 / Math.PI)));
            setXRot((float) -(Math.asin(Mth.clamp(velocity.normalize().y, -1, 1)) * (180.0 / Math.PI)));
        }
        velocity = velocity.lerp(desired, driver != null ? 0.12 : 0.08);
        if (velocity.lengthSqr() > 1e-4) {
            move(MoverType.SELF, velocity);
            if (horizontalCollision || verticalCollision) velocity = velocity.scale(0.5);
        }
        ram(o);
    }

    /** Dragon Dive: brake to a stop, coil into rings, dissipate, then hand over to the arrow rain. */
    private void diveTick(LivingEntity o) {
        velocity = velocity.scale(0.8);
        if (velocity.lengthSqr() > 1e-4) move(MoverType.SELF, velocity);
        int t = this.entityData.get(DIVE) + 1;
        this.entityData.set(DIVE, t);
        if (t == Tuning.DIVE_RING_TICKS && level() instanceof net.minecraft.server.level.ServerLevel sl) {
            sl.sendParticles(net.minecraft.core.particles.ParticleTypes.END_ROD, getX(), centre().y, getZ(), 120, 3.0, 0.5, 3.0, 0.25);
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 4.0f, 0.5f);
        }
        if (t >= Tuning.DIVE_RING_TICKS + Tuning.DIVE_DISSIPATE_TICKS && level() instanceof net.minecraft.server.level.ServerLevel sl) {
            DragonDive.start(sl, centre(), owner);
            discard();
        }
    }

    /** At speed the head ploughs through enemies in front of it. */
    private void ram(LivingEntity o) {
        if (Tuning.DRAGON_RAM_DAMAGE <= 0 || velocity.length() < 0.8) return;
        int now = tickCount;
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(0.6))) {
            if (e == o || e.isPassengerOfSameVehicle(this) || hasPassenger(e) || AllianceUtils.isAlly(e, o)) continue;
            if (o instanceof NenFighter nf && !nf.isFoe(e)) continue; // an NPC's dragon only ploughs through its enemies
            Integer last = rammed.get(e.getUUID());
            if (last != null && now - last < 10) continue;
            rammed.put(e.getUUID(), now);
            if (o instanceof Player po) Vows.hatsuHurt(e, level().damageSources().playerAttack(po), Tuning.DRAGON_RAM_DAMAGE * Vows.power(po, DragonHead.ID));
            else Vows.hatsuHurt(e, level().damageSources().mobAttack(o), Tuning.DRAGON_RAM_DAMAGE * (o instanceof NenFighter nf2 ? nf2.hatsuScale() : 1f));
            Vec3 push = velocity.normalize().scale(1.8).add(0, 0.4, 0);
            e.push(push.x, push.y, push.z);
            e.hurtMarked = true;
        }
        if (rammed.size() > 64) rammed.clear();
    }

    /** Called by the DragonHead ability and clean-up. */
    public void dismiss() {
        if (!level().isClientSide) discard();
    }
}
