package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Forge event hooks for {@link RipperCyclotron}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class RipperCyclotronEvents {
    private RipperCyclotronEvents() {}

    @SubscribeEvent
    public static void onRipperTick(TickEvent.PlayerTickEvent e) {
        if (e.phase == TickEvent.Phase.START && e.player instanceof ServerPlayer sp) RipperCyclotron.tick(sp);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) RipperCyclotron.clear(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) RipperCyclotron.clear(sp);
    }

    /** Someone who starts tracking a player mid-spin sees the aura at once. */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking e) {
        if (e.getEntity() instanceof ServerPlayer viewer && e.getTarget() instanceof ServerPlayer owner) RipperCyclotron.sendTo(owner, viewer);
    }
}
