package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.List;
import net.hxhadventure.abilities.Combat;

/** Which Hatsu a Nen type can choose from (kit ids as in the rest of the mod). Water Divination shows a player only their own type's list. */
public final class HatsuCatalog {
    private HatsuCatalog() {}

    /** Hatsu level needed to choose a Hatsu. */
    public static final int MIN_LEVEL = 10;
    /** After choosing, the Hatsu can be changed again only once the level has risen by this much. */
    public static final int CHANGE_EVERY_LEVELS = 5;
    /** From this Hatsu level up the Hatsu can be changed whenever you like, with no waiting for the level to rise. */
    public static final int FREE_CHANGE_LEVEL = 80;

    public record Option(int kit, String name, String owner, String blurb, String text) {}

    private static final Option JAJANKEN = new Option(Jajanken.KIT, "Jajanken", "Gon Freecss",
        "Charge all your aura into a fist: Rock, Scissors, Paper.",
        "Enhancement Hatsu: Jajanken");
    private static final Option GUANYIN = new Option(Guanyin.KIT, "100-Type Guanyin Bodhisattva", "Isaac Netero",
        "Pray (H) and attack to grow in gratitude; manifest a giant golden statue.",
        "Enhancement Hatsu: 100-Type Guanyin Bodhisattva");
    private static final Option RIPER = new Option(RipperCyclotron.KIT, "Ripper Cyclotron", "Phinks Magcub",
        "Spin your arm to charge a Jajanken Rock punch.",
        "Enhancement Hatsu: Ripper Cyclotron");
    private static final Option BIGBANG = new Option(BigBangImpact.KIT, "Big Bang Impact", "Uvogin",
        "Focus all your aura into your fist: a blast that levels everything around, or (Shift+Z) a ripple that tears up the ground and stuns.",
        "Enhancement Hatsu: Big Bang Impact");
    private static final Option GUM = new Option(BungeeGum.KIT, "Bungee Gum", "Hisoka Morow",
        "Elastic, sticky aura: reel in enemies, bind, barrier, cards.",
        "Transmutation Hatsu: Bungee Gum");
    private static final Option LIGHTNING = new Option(LightningAura.KIT, "Lightning Aura", "Killua Zoldyck",
        "Lightning Palm, Thunderbolt and Godspeed.",
        "Transmutation Hatsu: Lightning Aura");
    private static final Option PAINPACKER = new Option(PainPacker.KIT, "Pain Packer", "Feitan Portor",
        "Turn pain into armor, then call Rising Sun.",
        "Transmutation Hatsu: Pain Packer");
    private static final Option ESTHETICIAN = new Option(MagicalEsthetician.KIT, "Magical Esthetician", "Biscuit Krueger",
        "Summon Cookie for buffs; grow with Body Transformation.",
        "Transmutation Hatsu: Magical Esthetician");
    private static final Option ORBS = new Option(ExplosiveOrbs.KIT, "Explosive Orbs", "Silva Zoldyck",
        "Levitate and hurl two exploding orbs of aura.",
        "Emission Hatsu: Explosive Orbs");
    private static final Option BLAST = new Option(AuraBlast.KIT, "Dragon's Head", "Zeno Zoldyck",
        "A cone of raw aura, Dragon Head and Dragon Dive.",
        "Emission Hatsu: Dragon's Head");
    private static final Option CHAINS = new Option(ChainManager.CHAINS_KIT, "Chains", "Kurapika",
        "Dowsing Chain, Holy Chain, Chain Jail, Judgment Chain.",
        "Chains");
    private static final Option NEEDLES = new Option(IllumiNeedles.KIT, "Illumi's Needles", "Illumi Zoldyck",
        "Body Alteration, Corpse Control, Needle People.",
        "Manipulation Hatsu: Illumi's Needles");
    private static final Option PAPER = new Option(PaperManipulation.KIT, "Paper Manipulation", "Kalluto Zoldyck",
        "A paper cloud and Kalluto's Fan: a serpent that marks enemies.",
        "Manipulation Hatsu: Paper Manipulation");
    private static final Option BLACKVOICE = new Option(BlackVoice.KIT, "Black Voice", "Shalnark",
        "Antenna phone: make allies, move your mind into their body.",
        "Manipulation Hatsu: Black Voice");
    private static final Option HAKOWARE = new Option(Hakoware.KIT, "Hakoware", "Knuckle Bine",
        "Lend aura with every blow: A.P.R. and I.R.S.",
        "Conjuration Hatsu: Hakoware");
    private static final Option HIDESEEK = new Option(HideAndSeek.KIT, "Hide and Seek", "Knov",
        "Symbol circles to your own Nen dimension, and Scream.",
        "Emission Hatsu: Hide and Seek");
    private static final Option HUNTER = new Option(SkillHunter.KIT, "Skill Hunter", "Chrollo Lucilfer",
        "A book that steals and uses other people's abilities.",
        "Specialization Hatsu: Skill Hunter");
    private static final Option BLYTHE = new Option(DoctorBlythe.KIT, "Doctor Blythe", "Neferpitou",
        "A giant healing doll, and Terpsichora buffs.",
        "Specialization Hatsu: Doctor Blythe");

    /** The Hatsu this Nen type may choose from. Empty for no type. */
    private static final Option BLINKY = new Option(Blinky.KIT, "Blinky", "Shizuku Murasaki",
        "A vacuum cleaner that sucks up blocks, then Exsanguinate.",
        "Conjuration Hatsu: Blinky");
    private static final Option STITCHES = new Option(NenStitches.KIT, "Nen Stitches", "Machi Komacine",
        "Aura threads: slashes, traps, binding, sewing wounds.",
        "Transmutation Hatsu: Nen Stitches");

    private static final Option CRAZYSLOTS = new Option(CrazySlots.KIT, "Crazy Slots", "Kite",
        "A clown roulette conjures a random weapon: Scythe, Staff or Carbine.",
        "Conjuration Hatsu: Crazy Slots");

    private static final Option LITTLEFLOWER = new Option(LittleFlower.KIT, "Little Flower", "Gentleman Genthru",
        "H: exploding palms. Z: Countdown, a bomb on someone's pulse.",
        "Conjuration Hatsu: Little Flower");

    private static final Option SMOKE = new Option(SmokeManipulation.KIT, "Smoke Manipulation", "Morel Mackernasey",
        "Pipe smoke: monsters or clones, and Smoky Jail.",
        "Manipulation Hatsu: Smoke Manipulation");

    private static final Option LAPLACE = new Option(LaplaceDevil.KIT, "Laplace Devil", "Tserriednich Hui Guo Rou",
        "Enter Zetsu: everyone sees only your double, never you.",
        "Specialization Hatsu: Laplace Devil");

    public static List<Option> forType(int type) {
        List<Option> out = new ArrayList<>();
        switch (type) {
            case Combat.NEN_ENHANCEMENT -> { out.add(JAJANKEN); out.add(GUANYIN); out.add(RIPER); out.add(BIGBANG); }
            case Combat.NEN_TRANSMUTATION -> { out.add(GUM); out.add(LIGHTNING); out.add(PAINPACKER); out.add(ESTHETICIAN); out.add(STITCHES); }
            case Combat.NEN_EMISSION -> { out.add(ORBS); out.add(BLAST); out.add(HIDESEEK); }
            case Combat.NEN_CONJURATION -> { out.add(CHAINS); out.add(HAKOWARE); out.add(BLINKY); out.add(CRAZYSLOTS); out.add(LITTLEFLOWER); }
            case Combat.NEN_MANIPULATION -> { out.add(NEEDLES); out.add(PAPER); out.add(BLACKVOICE); out.add(SMOKE); }
            case Combat.NEN_SPECIALIZATION -> { out.add(CHAINS); out.add(HUNTER); out.add(BLYTHE); out.add(LAPLACE); }
            default -> { }
        }
        return out;
    }

    /** The text shown on the licence screen for a Hatsu kit id, or null for kits without an entry (none, kit1, kit2). */
    public static String textFor(int kit) {
        for (int type = 1; type <= 6; type++) {
            Option o = find(type, kit);
            if (o != null) return o.text();
        }
        return null;
    }

    /** Everything the old Hatsu had out in the world goes (the same clean-up a death does). Used when the Hatsu is changed. */
    public static void clearAll(net.minecraft.server.level.ServerPlayer sp, Combat c) {
        Jajanken.clear(sp);
        Guanyin.clear(sp);
        ChainManager.clear(sp);
        ChainManager.clearCooldowns(sp);
        DoctorBlythe.clear(sp);
        Terpsichora.clear(sp);
        ExplosiveOrbs.clear(sp);
        DragonHead.clear(sp);
        BungeeGum.clear(sp);
        LightningAura.clear(sp);
        PainPacker.clear(sp);
        RipperCyclotron.clear(sp);
        BigBangImpact.clear(sp);
        BlackVoice.clear(sp);
        MagicalEsthetician.clear(sp); // Cookie goes, the form ends, the buffs are gone
        NenStitches.clear(sp);
        Blinky.clear(sp); // the vacuum cleaner and whatever it was draining
        SmokeManipulation.clear(sp); // the smoke monsters, the clones and the dome
        CrazySlots.clear(sp); // the clown and any weapon it conjured
        LittleFlower.release(sp); // the palms, and every bomb you planted
        LaplaceDevil.clear(sp);
        if (HideAndSeek.canUse(c)) HideAndSeek.onLost(sp); // its circles close, its captives go home
        HideAndSeek.clear(sp);
        GumCards.clear(sp);
        SkillHunter.clear(sp);
    }

    public static Option find(int type, int kit) {
        for (Option o : forType(type)) if (o.kit() == kit) return o;
        return null;
    }
}
