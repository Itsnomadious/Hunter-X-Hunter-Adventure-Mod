package net.hxhadventure.addon;

/** Numbers for {@link RareNpcSpawns}: how rarely the roaming NPCs turn up in the Overworld, and how likely each one is when one does. */
public final class RareNpcTuning {
    private RareNpcTuning() {}

    public static final boolean ENABLED = true;

    /** Each player is rolled once per this many ticks (1200 = every minute). */
    public static final int CHECK_INTERVAL_TICKS = 1200;
    /** Chance per roll that an NPC turns up near the player: 0.02 is about once an hour of play. */
    public static final double CHANCE_PER_CHECK = 0.02;
    /** After one turns up near a player, that player is not rolled again for this long (72000 = one real hour of play). */
    public static final int PLAYER_COOLDOWN_TICKS = 72000;
    /** No new NPC turns up while another roaming one is already within this many blocks of the player. */
    public static final int CROWD_RADIUS = 160;
    /** How far from the player (in blocks) the NPC appears. */
    public static final int MIN_DISTANCE = 28, MAX_DISTANCE = 56;

    // Relative weights: which NPC it is when one turns up. 0 = never. Neferpitou is deliberately not on this list.
    public static final int WEIGHT_KILLUA = 25;
    public static final int WEIGHT_GON = 25;
    public static final int WEIGHT_HISOKA = 20;
    public static final int WEIGHT_CHROLLO = 15;
    public static final int WEIGHT_NETERO = 6;
    public static final int WEIGHT_KURAPIKA = 12;
    public static final int WEIGHT_ILLUMI = 10;
    public static final int WEIGHT_BISKY = 10;
    public static final int WEIGHT_HINA = 10;
    public static final int WEIGHT_SILVA = 5;
    public static final int WEIGHT_ZENO = 5;
}
