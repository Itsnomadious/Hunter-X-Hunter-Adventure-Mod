package net.hxhadventure.addon;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Neferpitou, a level 500 Nen NPC. She attacks any player on sight. Ten is always up; Ko is her fighting stance; Ken comes
 * on the moment she attacks or is hit (she does not use Ren). She fights with Attack / Barrage / Strong attack and her own Pounce (a full squat,
 * then a leap across the map: used when the target is more than 20 blocks away). She brings out Doctor Blythe only when she
 * or an ally is low, and Terpsichora when she drops under 70 % health or fights someone using Jajanken's "I'll use everything".
 * Everything numeric is in {@link NeferpitouTuning}; the three outside abilities are wired in {@link PitouIntegration}.
 */
public class NeferpitouEntity extends PathfinderMob implements GeoEntity, NpcPose, NpcMelee.Host, NpcFightGoal.FightNpc {

    private static final EntityDataAccessor<Integer> NEN_FLAGS = SynchedEntityData.defineId(NeferpitouEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> POUNCE_STATE = SynchedEntityData.defineId(NeferpitouEntity.class, EntityDataSerializers.INT);
    public static final int F_TEN = 1, F_KO = 4, F_KEN = 8, F_TERP = 16;
    public static final int POUNCE_NONE = 0, POUNCE_CROUCH = 1, POUNCE_LEAP = 2;

    private static final UUID MOD_TEN_ARMOR = UUID.fromString("b3000000-0000-4000-8000-000000000001");
    private static final UUID MOD_TEN_TOUGH = UUID.fromString("b3000000-0000-4000-8000-000000000002");
    private static final UUID MOD_ATTACK_SLOW = UUID.fromString("b3000000-0000-4000-8000-000000000005");
    private static final java.util.UUID MOD_TEN_SPEED = UUID.fromString("b3000000-0000-4000-8000-000000000006");
    private static final UUID MOD_TERP_SPEED = UUID.fromString("b3000000-0000-4000-8000-000000000007");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    // ---- aura / Nen ----
    private enum Stance { NONE, KO, KEN }
    private final float maxAura = NeferpitouTuning.maxAura();
    private float aura = maxAura;
    private boolean exhausted;
    private boolean ten, ken, ko;
    private Stance stance = Stance.NONE;
    private int formCooldown, koTicks, koBonusLeft, kenUntil;
    private int lastHitTick = -1000;
    private int idleTicks;
    private boolean wasFighting;

    // ---- attacks ----
    private enum Act { NONE, POUNCE_CROUCH, POUNCE_LEAP }
    private Act act = Act.NONE;
    private int actTicks, pounceCooldown;
    private final NpcMelee melee = new NpcMelee(this, this, meleeCfg());
    private final float meleeGovern = NpcBalance.governedMelee(profile());

    static MeleeCore.Cfg meleeCfg() {
        return MeleeCore.Cfg.of(NeferpitouTuning.PUNCH_DAMAGE, NeferpitouTuning.PUNCH_RANGE, NeferpitouTuning.STRONG_DAMAGE, NeferpitouTuning.STRONG_RANGE, NeferpitouTuning.STRONG_KNOCKBACK,
            NeferpitouTuning.STRONG_CHARGE_TICKS, NeferpitouTuning.STRONG_MAX_HOLD_TICKS, NeferpitouTuning.STRONG_COOLDOWN_TICKS,
            NeferpitouTuning.BARRAGE_DAMAGE, NeferpitouTuning.BARRAGE_TICKS, NeferpitouTuning.BARRAGE_HIT_GAP, NeferpitouTuning.BARRAGE_COOLDOWN_TICKS,
            NeferpitouTuning.PUNCH_WEIGHT_BARRAGE, NeferpitouTuning.PUNCH_WEIGHT_STRONG);
    }

    /** What the balance model (NpcBalance) knows about her. */
    static NpcBalance.Profile profile() {
        return new NpcBalance.Profile("neferpitou", NeferpitouTuning.MAX_HEALTH, NeferpitouTuning.HATSU_LEVEL, Math.min(NpcFeelTuning.PLAYER_CAP, NeferpitouTuning.TEN_LEVEL))
            .mult(NeferpitouTuning.DAMAGE_MULT).ren(0).regen(NeferpitouTuning.HEAL_PER_SECOND).cfg(meleeCfg());
    }
    private boolean punchOne = true;
    private Vec3 leapDir = Vec3.ZERO;
    private int leapMax;
    private final java.util.Set<UUID> leapHit = new java.util.HashSet<>();

    // ---- Doctor Blythe / Terpsichora ----
    private UUID blythePatient;
    private int blytheLeft, blytheCooldown;
    private float blythePerTick;
    private UUID terpId;
    private int terpUntil, terpCooldown;
    /** tickCount until which her Terpsichora buffs last (the figure itself is only out for a second). */
    private int terpBuffUntil;
    /** She has been killed once and raised again: Terpsichora stays out until she dies again. */
    private boolean terpRevived;
    /** tickCount until which she stands still after calling Terpsichora. */
    private int terpFreezeUntil;

    private final Map<UUID, Long> foes = new HashMap<>();

    public NeferpitouEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.addTag(CrazySlotsTuning.CHIMERA_TAG); // a Chimera Ant: the tag a player reborn through the staff of Crazy Slots gets, too
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, NpcBalance.governedHealth(profile()))
            .add(Attributes.MOVEMENT_SPEED, NeferpitouTuning.BASE_SPEED)
            .add(Attributes.ATTACK_DAMAGE, 5.0)
            .add(Attributes.FOLLOW_RANGE, NeferpitouTuning.FOLLOW_RANGE)
            .add(Attributes.KNOCKBACK_RESISTANCE, NeferpitouTuning.KNOCKBACK_RESISTANCE);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(NEN_FLAGS, 0);
        this.entityData.define(POUNCE_STATE, POUNCE_NONE);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new NpcFightGoal(this, this, t -> isPouncing() || (distanceTo(t) > NeferpitouTuning.POUNCE_MIN_DISTANCE && tryPounce(t))));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        // attacks on sight: any player she can see
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, e -> validTarget(e)));
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        this.aura = maxAura;
        this.setPersistenceRequired();
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("PitouAura", aura);
        tag.putBoolean("PitouExhausted", exhausted);
        tag.putBoolean("PitouRevived", terpRevived);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("PitouAura")) aura = Math.max(0f, Math.min(maxAura, tag.getFloat("PitouAura")));
        exhausted = tag.getBoolean("PitouExhausted");
        terpRevived = tag.getBoolean("PitouRevived");
    }

    // =====================================================================================================
    // queries
    // =====================================================================================================

    public float aura() { return aura; }
    public float maxAura() { return maxAura; }
    public boolean isExhausted() { return exhausted; }
    public boolean isAttacking() { return act != Act.NONE || melee.isAttacking(); }

    @Override
    public NpcMelee melee() { return melee; }
    public boolean isPouncing() { return act == Act.POUNCE_CROUCH || act == Act.POUNCE_LEAP; }
    public int pounceState() { return this.entityData.get(POUNCE_STATE); }
    public int nenFlags() { return this.entityData.get(NEN_FLAGS); }
    /** Terpsichora is out: both arms are raised out to the sides, like a player's, to work the strings. */
    public boolean armsRaised() { return (nenFlags() & F_TERP) != 0; }

    @Override
    public boolean armsOut() { return false; }

    @Override
    public boolean tPose() { return armsRaised(); }

    public boolean canUseNen() {
        return !exhausted && !ExtrasHooks.hatsuForced(this);
    }

    /** HxHAdventure's spirit bonus for her Hatsu level: 1 + 0.1 sqrt(L), and Ken adds 0.2 sqrt(L) x Ken's damage share. */
    public float spiritBonus() {
        float s = (float) Math.sqrt(NeferpitouTuning.HATSU_LEVEL);
        float m = 1.0f + s * 0.1f;
        if (ken) m += s * 0.2f * Tuning.KEN_DAMAGE_SHARE;
        return m;
    }

    /** Multiplier on damage she takes: in Ko (as for players in this mod) Ten's armor is stripped, plus a small extra softness. */
    public float incomingMult(DamageSource src) {
        return NpcAura.incoming(NeferpitouTuning.TEN_LEVEL, ten && !ko, false, ken, ko); // Ten / Ken durability, or Ko's open body: the same as a player's
    }

    /** Her aura's multiplier on the damage she deals: Ten / Ken / Ko, the same formula players get. */
    private float auraOutMult() {
        return NpcAura.outgoing(NeferpitouTuning.TEN_LEVEL, ten && !ko, false, ken, ko);
    }

    public boolean isFoe(Entity e) {
        if (!(e instanceof LivingEntity le) || e == this || !le.isAlive() || e instanceof ArmorStand || isAlly(le)) return false;
        if (e instanceof TerpsichoraEntity) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        if (e == getTarget()) return true;
        Long t = foes.get(e.getUUID());
        return t != null && level().getGameTime() - t <= NeferpitouTuning.FOE_MEMORY_TICKS;
    }

    /** Allies: other Neferpitou and Hisoka NPCs. (Add more types here.) */
    public boolean isAlly(LivingEntity e) {
        return e != this && (e instanceof NeferpitouEntity || e instanceof HisokaEntity);
    }

    private void noteFoe(LivingEntity e) {
        foes.put(e.getUUID(), level().getGameTime());
        if (foes.size() > 32) {
            long now = level().getGameTime();
            foes.values().removeIf(t -> now - t > NeferpitouTuning.FOE_MEMORY_TICKS);
        }
    }

    private boolean validTarget(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof ArmorStand || isAlly(e) || e instanceof TerpsichoraEntity) return false;
        return !(e instanceof Player p && (p.isCreative() || p.isSpectator()));
    }

    // =====================================================================================================
    // being hurt
    // =====================================================================================================

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide) {
            lastHitTick = tickCount;
            if (source.getEntity() instanceof LivingEntity attacker && validTarget(attacker)) {
                noteFoe(attacker);
                LivingEntity cur = getTarget();
                if (cur == null || !cur.isAlive() || distanceToSqr(cur) > 16.0) setTarget(attacker);
            }
            // taking damage: Ken, right now
            if (canUseNen() && stance != Stance.KEN && aura >= NeferpitouTuning.MIN_AURA_FOR_KEN && !(act == Act.POUNCE_CROUCH)) setStance(Stance.KEN, false);
        }
        return hit;
    }

    // =====================================================================================================
    // per tick (server)
    // =====================================================================================================

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !isAlive() || !(level() instanceof ServerLevel)) return;
        LivingEntity t = getTarget();
        if (t != null && (!t.isAlive() || t.level() != level() || distanceToSqr(t) > 96.0 * 96.0
            || (t instanceof Player p && (p.isCreative() || p.isSpectator())))) {
            setTarget(null);
            t = null;
        }
        boolean fighting = t != null;
        if (fighting) idleTicks = 0; else idleTicks++;
        if (!fighting && wasFighting) cancelAttack();
        wasFighting = fighting;

        tickNen(fighting);
        if (tickCount < terpFreezeUntil) { // Terpsichora was just called: she cannot move for half a second
            getNavigation().stop();
            cancelAttack();
            setDeltaMovement(0, Math.min(0, getDeltaMovement().y), 0);
        } else {
            tickAttack(t);
            melee.tick(t, t != null && inReach(t), isPouncing());
        }
        tickBlythe();
        tickTerpsichora(fighting, t);
        refreshModifiers();
        syncFlags();
    }

    // =====================================================================================================
    // Nen: Ten always, Ko to fight, Ken to attack and when hit
    // =====================================================================================================

    private void tickNen(boolean fighting) {
        if (formCooldown > 0) formCooldown--;
        if (stance == Stance.KO) koTicks++;

        final float perTick = 1f / 20f;
        if (exhausted) {
            aura += (NeferpitouTuning.BASE_REGEN + maxAura * NeferpitouTuning.EXHAUST_REGEN_PCT) * perTick;
        } else {
            aura += (ten ? NeferpitouTuning.tenRegenPerSecond() : NeferpitouTuning.BASE_REGEN) * perTick;
            if (!fighting && idleTicks > NeferpitouTuning.REST_DELAY_TICKS) aura += maxAura * NeferpitouTuning.REST_REGEN_PCT * perTick;
            if (ken) aura -= Tuning.KEN_UPKEEP * perTick;
            if (ko) aura -= Tuning.KO_UPKEEP * perTick;
            if (ten && tickCount % 20 == 0 && getHealth() < getMaxHealth() && tickCount - lastHitTick > 40) heal(NeferpitouTuning.HEAL_PER_SECOND);
        }
        aura = Math.max(0f, Math.min(maxAura, aura));

        if (!exhausted && aura <= 0.01f) {
            runDry();
        } else if (exhausted && aura >= maxAura * NeferpitouTuning.EXHAUST_RESUME_FRACTION) {
            exhausted = false;
            level().playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 0.8f, 1.4f);
        }

        boolean blocked = exhausted || ExtrasHooks.hatsuForced(this);
        ten = !blocked;
        if (blocked) {
            if (stance != Stance.NONE) setStance(Stance.NONE, true);
            return;
        }

        Stance want = Stance.NONE;
        if (fighting) {
            boolean recentlyHit = tickCount - lastHitTick <= NeferpitouTuning.KEN_AFTER_HIT_TICKS;
            boolean attacking = melee.isAttacking() || act == Act.POUNCE_LEAP || tickCount < kenUntil;
            if ((recentlyHit || attacking) && act != Act.POUNCE_CROUCH && aura >= NeferpitouTuning.MIN_AURA_FOR_KEN) want = Stance.KEN;
            else want = Stance.KO;
        }
        if (want != stance && formCooldown <= 0) setStance(want, false);
    }

    private void runDry() {
        exhausted = true;
        aura = 0f;
        ten = false;
        setStance(Stance.NONE, true);
        if (level() instanceof ServerLevel sl) {
            sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 1.0f, 0.7f);
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0, getZ(), 20, 0.4, 0.6, 0.4, 0.02);
        }
    }

    private void setStance(Stance s, boolean force) {
        if (s == stance) return;
        Stance old = stance;
        stance = s;
        formCooldown = NeferpitouTuning.FORM_SWITCH_TICKS;
        // Ko held long enough: the first hit after it lands harder
        if (old == Stance.KO && s == Stance.KEN && koTicks >= NeferpitouTuning.KO_CHARGE_TICKS) koBonusLeft = 1;
        if (s == Stance.KO) koTicks = 0;
        ken = s == Stance.KEN;
        ko = s == Stance.KO;
        if (!(level() instanceof ServerLevel sl)) return;
        switch (s) {
            case KEN -> sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 0.8f, 1.2f);
            case KO -> sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 0.8f, 0.8f);
            case NONE -> {
                if (!force) sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 0.4f, 1.5f);
            }
        }
    }

    private float takeKoBonus() {
        return 1f; // Ko's damage now comes from NpcAura.outgoing (2 x Ten's bonus on every melee hit), not a one-off bonus
    }

    private void syncFlags() {
        int f = (ten ? F_TEN : 0) | (ko ? F_KO : 0) | (ken ? F_KEN : 0) | (terpsichoraActive() ? F_TERP : 0);
        if (this.entityData.get(NEN_FLAGS) != f) this.entityData.set(NEN_FLAGS, f);
        int p = act == Act.POUNCE_CROUCH ? POUNCE_CROUCH : act == Act.POUNCE_LEAP ? POUNCE_LEAP : POUNCE_NONE;
        if (this.entityData.get(POUNCE_STATE) != p) this.entityData.set(POUNCE_STATE, p);
    }

    private void refreshModifiers() {
        updateAttackSlow();
        if (tickCount % 5 != 0) return;
        // Ten's old armour / toughness and the old Ren speed are gone: one speed bonus, the player's (Ten, Ken x1, none in Ko)
        setMod(Attributes.MOVEMENT_SPEED, MOD_TEN_SPEED, NpcAura.speedBonus(NeferpitouTuning.TEN_LEVEL, ten && !ko, false, ken, ko), AttributeModifier.Operation.MULTIPLY_TOTAL);
        setMod(Attributes.MOVEMENT_SPEED, MOD_TERP_SPEED, terpMult() - 1.0, AttributeModifier.Operation.MULTIPLY_TOTAL); // Terpsichora's buff
    }

    private void setMod(Attribute attr, UUID id, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = getAttribute(attr);
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(id);
        if (Math.abs(amount) < 1e-6) {
            if (cur != null) inst.removeModifier(id);
            return;
        }
        if (cur != null && Math.abs(cur.getAmount() - amount) < 1e-6) return;
        if (cur != null) inst.removeModifier(id);
        inst.addTransientModifier(new AttributeModifier(id, "Neferpitou Nen", amount, op));
    }

    // =====================================================================================================
    // Attack / Barrage / Strong attack / Pounce
    // =====================================================================================================

    /** Called by the combat goal every tick the target is within reach. */
    @Override
    public void chooseAttack(LivingEntity t) {
        if (act != Act.NONE || !melee.core.ready()) return;
        startKen();
        melee.choose(t);
    }

    /** Attacking means Ken: she goes into it at once rather than waiting for the stance timer. */
    private void startKen() {
        kenUntil = tickCount + NeferpitouTuning.KEN_AFTER_ATTACK_TICKS;
        if (canUseNen() && stance != Stance.KEN && aura >= NeferpitouTuning.MIN_AURA_FOR_KEN) setStance(Stance.KEN, false);
    }

    /** The pounce states only: the punches are NpcMelee's. */
    private void tickAttack(@Nullable LivingEntity t) {
        if (pounceCooldown > 0) pounceCooldown--;
        if (melee.isAttacking()) kenUntil = tickCount + 10;
        switch (act) {
            case POUNCE_CROUCH -> tickCrouch(t);
            case POUNCE_LEAP -> tickLeap(t);
            default -> { }
        }
    }

    @Override
    public boolean inReach(LivingEntity t) {
        return distanceTo(t) - t.getBbWidth() * 0.5 <= NeferpitouTuning.REACH && Math.abs(t.getY() - getY()) < 2.5;
    }

    private void cancelAttack() {
        if (act == Act.POUNCE_LEAP) endLeap();
        act = Act.NONE;
        actTicks = 0;
        melee.cancel();
    }

    /** Spirit bonus x her damage multiplier x Ko / aura / Terpsichora boosts x the fairness governor. Asked only when a blow lands (taking the Ko bonus is a one-shot). */
    @Override
    public float meleeScale() {
        return spiritBonus() * NeferpitouTuning.DAMAGE_MULT * takeKoBonus() * auraOutMult() * terpMult() * meleeGovern;
    }

    @Override
    public void swingAnim() {
        triggerPunchAnim();
    }

    void triggerPunchAnim() {
        triggerAnim("attack_controller", punchOne ? "punch1" : "punch2");
        punchOne = !punchOne;
    }

    private void updateAttackSlow() {
        setMod(Attributes.MOVEMENT_SPEED, MOD_ATTACK_SLOW, -melee.slow(), AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    // ---------------------------------------------------------------------------------------------------
    // Pounce: full squat leaning forward, then a straight-line leap at the target. Only from beyond 20 blocks.
    // ---------------------------------------------------------------------------------------------------

    /** Starts a pounce if the target is far enough and she is free to. Returns true if it started. */
    boolean tryPounce(LivingEntity t) {
        if (act != Act.NONE || melee.isAttacking() || pounceCooldown > 0 || !onGround() || isInWaterOrBubble()) return false;
        double d = distanceTo(t);
        if (d <= NeferpitouTuning.POUNCE_MIN_DISTANCE || d > NeferpitouTuning.POUNCE_MAX_DISTANCE) return false;
        act = Act.POUNCE_CROUCH;
        actTicks = 0;
        getNavigation().stop();
        if (canUseNen() && aura >= NeferpitouTuning.MIN_AURA_FOR_KEN) setStance(Stance.KO, true); // gathering aura for the leap
        level().playSound(null, blockPosition(), SoundEvents.WARDEN_SONIC_CHARGE, SoundSource.HOSTILE, 1.0f, 1.4f);
        return true;
    }

    private void tickCrouch(@Nullable LivingEntity t) {
        actTicks++;
        getNavigation().stop();
        Vec3 dm = getDeltaMovement();
        setDeltaMovement(0, Math.min(0, dm.y), 0);
        if (t == null || !t.isAlive()) {
            act = Act.NONE;
            actTicks = 0;
            pounceCooldown = 40;
            return;
        }
        lookAtFlat(t.position().subtract(position()));
        if (level() instanceof ServerLevel sl && actTicks % 4 == 0)
            sl.sendParticles(ParticleTypes.CRIT, getX(), getY() + 0.3, getZ(), 3, 0.4, 0.1, 0.4, 0.02);
        if (actTicks >= NeferpitouTuning.POUNCE_CROUCH_TICKS) startLeap(t);
    }

    private void startLeap(LivingEntity t) {
        Vec3 from = position().add(0, getBbHeight() * 0.5, 0);
        double dist = from.distanceTo(t.position());
        double travelTicks = dist / NeferpitouTuning.POUNCE_SPEED;
        Vec3 aim = t.position().add(0, t.getBbHeight() * 0.5, 0).add(t.getDeltaMovement().scale(Math.min(8.0, travelTicks)));
        leapDir = aim.subtract(from).normalize();
        // she leaves the ground slightly upwards, so she never drags along the floor and gets stuck on it
        if (leapDir.y < NeferpitouTuning.POUNCE_MIN_RISE) {
            Vec3 flat = new Vec3(leapDir.x, 0, leapDir.z);
            double len = flat.length();
            if (len > 1.0e-4) {
                double rise = NeferpitouTuning.POUNCE_MIN_RISE;
                leapDir = new Vec3(flat.x / len * Math.sqrt(1 - rise * rise), rise, flat.z / len * Math.sqrt(1 - rise * rise));
            }
        }
        move(net.minecraft.world.entity.MoverType.SELF, new Vec3(0, NeferpitouTuning.POUNCE_HOP, 0)); // respects ceilings
        // she blasts to the target AND past it: the leap keeps going POUNCE_OVERSHOOT blocks beyond where they were
        leapMax = (int) Math.min(80, Math.ceil((dist + NeferpitouTuning.POUNCE_OVERSHOOT) / NeferpitouTuning.POUNCE_SPEED));
        leapHit.clear();
        act = Act.POUNCE_LEAP;
        actTicks = 0;
        kenUntil = tickCount + leapMax + NeferpitouTuning.KEN_AFTER_ATTACK_TICKS;
        if (canUseNen() && aura >= NeferpitouTuning.MIN_AURA_FOR_KEN) setStance(Stance.KEN, false);
        setNoGravity(true);
        level().playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.0f, 1.8f);
        if (level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.3, getZ(), 2, 0.3, 0.1, 0.3, 0.0);
    }

    private void tickLeap(@Nullable LivingEntity t) {
        actTicks++;
        faceDirection(leapDir);
        fallDistance = 0;
        // anything of hers in the way (the path of this tick's move, too)
        AABB box = getBoundingBox().inflate(1.3).expandTowards(leapDir.scale(NeferpitouTuning.POUNCE_SPEED));
        List<LivingEntity> hit = level().getEntitiesOfClass(LivingEntity.class, box, e -> isFoe(e) && !leapHit.contains(e.getUUID()));
        if (!hit.isEmpty()) {
            float dmg = NeferpitouTuning.POUNCE_DAMAGE * spiritBonus() * takeKoBonus() * auraOutMult() * terpMult();
            for (LivingEntity e : hit) {
                leapHit.add(e.getUUID());
                e.invulnerableTime = 0;
                e.hurt(damageSources().mobAttack(this), dmg);
                e.knockback(NeferpitouTuning.POUNCE_KNOCKBACK, -leapDir.x, -leapDir.z);
                e.hurtMarked = true;
            }
            if (level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX() + leapDir.x, getY() + 1.0, getZ() + leapDir.z, 1, 0, 0, 0, 0);
                sl.sendParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 1.0, getZ(), 1, 0, 0, 0, 0);
                sl.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.5f, 0.8f);
            }
            // no endLeap(): she does not stop on a hit, she keeps going through and past
        }
        if (actTicks >= leapMax || (actTicks > 2 && (horizontalCollision || verticalCollision))) {
            endLeap();
            return;
        }
        setDeltaMovement(leapDir.scale(NeferpitouTuning.POUNCE_SPEED)); // carried into next tick's move
        hasImpulse = true;
    }

    private void endLeap() {
        setNoGravity(false);
        leapHit.clear();
        setDeltaMovement(leapDir.scale(0.25));
        fallDistance = 0;
        setXRot(0);
        act = Act.NONE;
        actTicks = 0;
        melee.recover(20);
        pounceCooldown = NeferpitouTuning.POUNCE_COOLDOWN_TICKS;
    }

    private void lookAtFlat(Vec3 v) {
        float yaw = (float) (Mth.atan2(v.z, v.x) * (180.0 / Math.PI)) - 90.0f;
        setYRot(yaw); yBodyRot = yaw; yHeadRot = yaw;
    }

    private void faceDirection(Vec3 d) {
        lookAtFlat(d);
        double h = Math.sqrt(d.x * d.x + d.z * d.z);
        setXRot((float) -(Mth.atan2(d.y, h) * (180.0 / Math.PI)));
    }

    // =====================================================================================================
    // Doctor Blythe: only when she, or an ally nearby, is low
    // =====================================================================================================

    private void tickBlythe() {
        if (blytheCooldown > 0) blytheCooldown--;
        if (blythePatient != null) {
            Entity e = level() instanceof ServerLevel sl ? sl.getEntity(blythePatient) : null;
            if (!(e instanceof LivingEntity p) || !p.isAlive() || blytheLeft <= 0) {
                blythePatient = null;
                return;
            }
            blytheLeft--;
            p.heal(blythePerTick);
            if (level() instanceof ServerLevel sl && tickCount % 4 == 0)
                sl.sendParticles(ParticleTypes.HEART, p.getX(), p.getY() + p.getBbHeight() * 0.6, p.getZ(), 2, 0.4, 0.5, 0.4, 0.0);
            return;
        }
        if (blytheCooldown > 0 || tickCount % 10 != 0) return;
        LivingEntity patient = null;
        if (getHealth() < getMaxHealth() * NeferpitouTuning.BLYTHE_SELF_HEALTH_FRACTION) patient = this;
        else patient = findLowAlly();
        if (patient != null && !terpRevived) { // only one of her skills is out at a time: Blythe puts Terpsichora away
            if (terpBuffed()) {
                terpBuffUntil = 0;
                terpUntil = 0;
                terpCooldown = NeferpitouTuning.TERP_COOLDOWN_TICKS;
                PitouIntegration.dismissTerpsichora(this);
            }
            blytheCooldown = NeferpitouTuning.BLYTHE_COOLDOWN_TICKS;
            PitouIntegration.summonDoctorBlythe(this, patient);
        }
    }

    @Nullable
    private LivingEntity findLowAlly() {
        AABB box = getBoundingBox().inflate(NeferpitouTuning.BLYTHE_ALLY_RANGE);
        LivingEntity worst = null;
        float worstRatio = NeferpitouTuning.BLYTHE_ALLY_HEALTH_FRACTION;
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, box, this::isAlly)) {
            float r = e.getHealth() / e.getMaxHealth();
            if (r < worstRatio) { worstRatio = r; worst = e; }
        }
        return worst;
    }

    /** Doctor Blythe's healing: the patient recovers a share of their max health over a few seconds. */
    public void startBlytheHeal(LivingEntity patient) {
        blythePatient = patient.getUUID();
        blytheLeft = NeferpitouTuning.BLYTHE_TICKS;
        blythePerTick = patient.getMaxHealth() * NeferpitouTuning.BLYTHE_HEAL_FRACTION / NeferpitouTuning.BLYTHE_TICKS;
        level().playSound(null, patient.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.HOSTILE, 0.6f, 1.6f);
    }

    // =====================================================================================================
    // Terpsichora: under 70 % health, or when the target is using "I'll use everything"
    // =====================================================================================================

    /** Is the figure out right now (her arms are raised to work the strings)? Only for its first second, or after she has been raised. */
    public boolean terpsichoraActive() {
        if (terpId != null && level() instanceof ServerLevel sl) {
            Entity e = sl.getEntity(terpId);
            if (e != null && e.isAlive()) return true;
            terpId = null;
        }
        return tickCount < terpUntil;
    }

    /** Are Terpsichora's buffs on her (the one minute after she was called, or from being raised until she dies again)? */
    public boolean terpBuffed() {
        return terpRevived || tickCount < terpBuffUntil;
    }

    /** Speed and damage multiplier from Terpsichora: the same numbers a player gets (1.8x, 2.5x once raised from the dead). */
    private float terpMult() {
        return terpRevived ? Tuning.TERPSI_DEAD_BOOST : terpBuffed() ? Tuning.TERPSI_BOOST : 1.0f;
    }

    /** Called by {@link PitouIntegration} once the doll (or whatever stands in for it) is out. */
    public void registerTerpsichora(@Nullable Entity doll, int durationTicks) {
        terpId = doll == null ? null : doll.getUUID();
        terpUntil = tickCount + durationTicks;
    }

    private void tickTerpsichora(boolean fighting, @Nullable LivingEntity t) {
        if (terpCooldown > 0) terpCooldown--;
        if (terpRevived) {
            // raised from the dead: the figure is out until she dies again (also after a reload, when the old one is gone)
            if (tickCount % 10 == 0 && !terpsichoraActive() && !ExtrasHooks.hatsuForced(this)) PitouIntegration.summonTerpsichora(this, t, -1);
            return;
        }
        if (!fighting || terpBuffed() || terpCooldown > 0 || ExtrasHooks.hatsuForced(this)) return; // not while she is in Forced Zetsu
        boolean low = getHealth() < getMaxHealth() * NeferpitouTuning.TERP_HEALTH_FRACTION;
        boolean everything = t != null && PitouIntegration.isUsingUseEverything(t);
        if (low || everything) {
            // the figure appears for one second and vanishes; the buffs it applies last for a minute
            terpCooldown = NeferpitouTuning.TERP_BUFF_TICKS + NeferpitouTuning.TERP_COOLDOWN_TICKS;
            terpBuffUntil = tickCount + NeferpitouTuning.TERP_BUFF_TICKS;
            blythePatient = null; // only one of her skills is out at a time: Terpsichora puts Blythe away
            blytheLeft = 0;
            terpFreezeUntil = tickCount + Tuning.TERPSI_FREEZE_TICKS;
            PitouIntegration.summonTerpsichora(this, t, NeferpitouTuning.TERP_FLASH_TICKS);
        }
    }

    /** She was killed for the first time: she is raised at 20 % health with Terpsichora out until she dies again. */
    private void reviveWithTerpsichora() {
        terpRevived = true;
        PitouIntegration.dismissTerpsichora(this); // a flash from earlier, if it is still out: the new one stays
        terpId = null;
        setHealth(getMaxHealth() * NeferpitouTuning.REVIVE_HEALTH_FRACTION);
        clearFire();
        fallDistance = 0f;
        invulnerableTime = 20; // the blow that killed her cannot land a second time
        removeAllEffects();
        cancelAttack();
        if (level() instanceof ServerLevel sl) {
            sl.playSound(null, blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 0.9f, 0.6f);
            sl.playSound(null, blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 0.8f, 0.5f);
            sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 1.0, getZ(), 40, 0.5, 0.9, 0.5, 0.05);
        }
        PitouIntegration.summonTerpsichora(this, getTarget(), -1);
    }

    // =====================================================================================================
    // end of life
    // =====================================================================================================

    @Override
    public void die(DamageSource source) {
        // the first death is refused: she is raised at 20 % health with Terpsichora out. /kill and the void are not something it can undo.
        if (!level().isClientSide && !terpRevived && !source.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            reviveWithTerpsichora();
            return;
        }
        cleanUp();
        super.die(source);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        cleanUp();
        super.remove(reason);
    }

    private void cleanUp() {
        if (!level().isClientSide && terpsichoraActive()) PitouIntegration.dismissTerpsichora(this);
    }

    // =====================================================================================================
    // animation: the same walk / idle / punch clips as the Hisoka and Kite NPCs
    // =====================================================================================================

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement_controller", 1, event -> {
            if (this.isInWater() || pounceState() != POUNCE_NONE) {
                return PlayState.STOP; // the pounce pose is drawn by the renderer
            } else if (event.isMoving()) {
                event.getController().setAnimationSpeed(1.0);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.walk"));
            } else {
                event.getController().setAnimationSpeed(0.5);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.idle"));
            }
        }));
        controllers.add(new AnimationController<>(this, "terp_controller", 4, event ->
            armsRaised() ? event.setAndContinue(RawAnimation.begin().thenPlayAndHold("terp_arms")) : PlayState.STOP));
        controllers.add(new AnimationController<>(this, "attack_controller", 1, state -> PlayState.STOP)
            .triggerableAnim("punch1", RawAnimation.begin().thenPlay("punch1"))
            .triggerableAnim("punch2", RawAnimation.begin().thenPlay("punch2")));
    }

    /** The Geo punch clips are gone: the NPC is drawn with the player model, so a punch is the normal arm swing. */
    @Override
    public void triggerAnim(String controllerName, String animName) {
        if (!level().isClientSide && animName.startsWith("punch")) net.hxhadventure.addon.SwingUtil.forceSwing(this, net.minecraft.world.InteractionHand.MAIN_HAND);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
