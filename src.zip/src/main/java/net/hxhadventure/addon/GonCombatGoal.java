package net.hxhadventure.addon;

import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

/**
 * Gon's fighting: face the target, start a Jajanken move when one fits the distance, otherwise run the target down and punch once it is in
 * reach. While he charges a move he stands still (the entity roots him). In "I'll use everything." he only runs at the target until it is
 * near enough for the orb Rock to start.
 */
final class GonCombatGoal extends Goal {
    private final GonEntity npc;
    private int repath;

    GonCombatGoal(GonEntity npc) {
        this.npc = npc;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = npc.getTarget();
        return t != null && t.isAlive();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        npc.getNavigation().stop();
    }

    @Override
    public void tick() {
        LivingEntity t = npc.getTarget();
        if (t == null) return;
        npc.getLookControl().setLookAt(t, 60.0f, 60.0f);
        if (npc.janBusy() || npc.tryJajanken(t)) { // charging a Jajanken move: he stands where he is
            npc.getNavigation().stop();
            return;
        }
        boolean inReach = npc.inReach(t);
        if (inReach) {
            if (!npc.isAttacking()) npc.getNavigation().stop();
            npc.chooseAttack(t);
        }
        if (!inReach || (npc.isAttacking() && npc.distanceTo(t) > 1.6f)) {
            if (--repath <= 0) {
                repath = 4 + npc.getRandom().nextInt(4);
                npc.getNavigation().moveTo(t, 1.25);
            }
        }
    }
}
