package net.hxhadventure.addon.quest;

/** The Hunter types a quest can belong to. {@code about} is the short blurb the laptop's quest board shows on the type's page. */
public enum QuestCategory {
    GOURMET("Gourmet Hunter", "gourmet", "minecraft:golden_carrot", 0xFFD2691E,
        "Travels the world for rare cuisine and exotic foodstuffs, and for rare ingredients found only in remote, inhospitable places. "
            + "Great connoisseurs, often world-class chefs who turn their finds into new delicacies."),
    SEA("Sea Hunter", "sea", "minecraft:heart_of_the_sea", 0xFF1E88C8,
        "Operates on the seas, looking either for animals or for treasure."),
    RUINS("Ruins Hunter", "ruins", "minecraft:brush", 0xFF8D6E4A,
        "Dedicated to uncovering, restoring and preserving ruins in order to \"revive\" ancient societies."),
    TREASURE("Treasure Hunter", "treasure", "minecraft:gold_ingot", 0xFFC99A1B,
        "Scours the world in search of rare and valuable items."),
    STONE("Stone Hunter", "stone", "minecraft:diamond", 0xFF8E44AD,
        "A subtype of Treasure Hunter whose quest is for precious stones and gems, or for specific jewelry."),
    BLACKLIST("Blacklist Hunter", "blacklist", "minecraft:iron_sword", 0xFFC01D32,
        "Dedicates their skills to tracking down dangerous and wanted criminals.");

    public final String title;
    public final String slug;
    /** Registry id of the item drawn as this type's icon. */
    public final String icon;
    public final int color;
    public final String about;

    QuestCategory(String title, String slug, String icon, int color, String about) {
        this.title = title;
        this.slug = slug;
        this.icon = icon;
        this.color = color;
        this.about = about;
    }
}
