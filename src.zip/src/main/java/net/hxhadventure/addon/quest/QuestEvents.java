package net.hxhadventure.addon.quest;

import java.util.HashSet;
import java.util.Set;
import net.hxhadventure.HxHAdventure;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.ItemFishedEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Feeds the game's events (kills, mining, crafting, eating, fishing, exploring) into the players' active quests. Server side only. */
@Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class QuestEvents {
    /** How often (in ticks) a player with an Explore objective is checked for standing inside a structure. */
    private static final int VISIT_CHECK_TICKS = 40;

    private QuestEvents() {}

    /** The client starts every session with an empty cache: give it the saved quest log. */
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) QuestData.sendLog(sp);
    }

    @SubscribeEvent
    public static void onKill(LivingDeathEvent e) {
        LivingEntity dead = e.getEntity();
        if (dead.level().isClientSide) return;
        if (!(e.getSource().getEntity() instanceof ServerPlayer sp) || !QuestData.hasActive(sp)) return;
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(dead.getType());
        if (id != null) QuestData.add(sp, QuestType.KILL, id.toString(), 1);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onMine(BlockEvent.BreakEvent e) {
        if (e.isCanceled() || !(e.getPlayer() instanceof ServerPlayer sp) || !QuestData.hasActive(sp)) return;
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(e.getState().getBlock());
        if (id != null) QuestData.add(sp, QuestType.MINE, id.toString(), 1);
    }

    @SubscribeEvent
    public static void onCraft(PlayerEvent.ItemCraftedEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp) || !QuestData.hasActive(sp)) return;
        countItem(sp, QuestType.CRAFT, e.getCrafting());
    }

    /** Cooking counts as crafting too (a steak is a dish). */
    @SubscribeEvent
    public static void onSmelt(PlayerEvent.ItemSmeltedEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp) || !QuestData.hasActive(sp)) return;
        countItem(sp, QuestType.CRAFT, e.getSmelting());
    }

    @SubscribeEvent
    public static void onEat(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer sp) || !QuestData.hasActive(sp)) return;
        ItemStack st = e.getItem();
        if (st.isEmpty() || !st.getItem().isEdible()) return;
        countItem(sp, QuestType.EAT, st, 1);
    }

    @SubscribeEvent
    public static void onFish(ItemFishedEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp) || !QuestData.hasActive(sp)) return;
        for (ItemStack st : e.getDrops()) countItem(sp, QuestType.FISH, st, 1);
    }

    private static void countItem(ServerPlayer sp, QuestType type, ItemStack st) {
        countItem(sp, type, st, st.getCount());
    }

    private static void countItem(ServerPlayer sp, QuestType type, ItemStack st, int amount) {
        if (st.isEmpty()) return;
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(st.getItem());
        if (id != null) QuestData.add(sp, type, id.toString(), amount);
    }

    /** Explore objectives: standing inside one of the listed structures counts. Checked every couple of seconds, only for players who need it. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer sp)) return;
        if (sp.tickCount % VISIT_CHECK_TICKS != 0 || !QuestData.hasActive(sp)) return;
        if (!(sp.level() instanceof ServerLevel level)) return;

        QuestData.Snapshot snap = QuestData.read(sp);
        Set<String> wanted = new HashSet<>();
        for (QuestData.Active a : snap.active) {
            Quest q = Quests.get(a.id);
            if (q == null) continue;
            for (int i = 0; i < q.objectives.size(); i++) {
                Quest.Objective o = q.objectives.get(i);
                if (o.type == QuestType.VISIT && a.progress[i] < o.count) {
                    for (String t : o.targets) wanted.add(t);
                }
            }
        }
        if (wanted.isEmpty()) return;

        var registry = level.registryAccess().registryOrThrow(Registries.STRUCTURE);
        for (String id : wanted) {
            Structure structure = registry.get(new ResourceLocation(id));
            if (structure == null) continue;
            StructureStart start = level.structureManager().getStructureAt(sp.blockPosition(), structure);
            if (start != null && start.isValid()) QuestData.add(sp, QuestType.VISIT, id, 1);
        }
    }
}
