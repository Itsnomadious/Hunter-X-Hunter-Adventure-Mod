package net.hxhadventure.addon.quest;

/** What an objective asks for. COLLECT is handed in at the laptop; every other kind is tracked while you play. */
public enum QuestType {
    COLLECT("Collect"),
    KILL("Defeat"),
    VISIT("Explore"),
    EAT("Eat"),
    CRAFT("Craft"),
    FISH("Fish up"),
    MINE("Mine");

    public final String verb;

    QuestType(String verb) {
        this.verb = verb;
    }
}
