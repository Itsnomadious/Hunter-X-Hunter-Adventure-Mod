package net.hxhadventure.addon.quest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** One commission on the Hunter Association's quest board. Immutable; built with {@link Builder} (see {@link Quests}). */
public final class Quest {

    /** One thing to do. {@code targets} are registry ids (items, blocks, entity types or structures); "*" matches anything. */
    public static final class Objective {
        public final QuestType type;
        public final String label;
        public final int count;
        public final String[] targets;

        Objective(QuestType type, String label, int count, String[] targets) {
            this.type = type;
            this.label = label;
            this.count = count;
            this.targets = targets;
        }

        public boolean matches(String key) {
            for (String t : targets) {
                if (t.equals("*") || t.equals(key)) return true;
            }
            return false;
        }

        public String firstTarget() {
            return targets.length > 0 ? targets[0] : "";
        }
    }

    public static final class Reward {
        public final String item;
        public final int count;

        Reward(String item, int count) {
            this.item = item;
            this.count = count;
        }
    }

    public final String id;
    public final QuestCategory category;
    public final int tier;
    public final String title;
    public final String desc;
    public final int xpLevels;
    public final int points;
    public final boolean repeatable;
    public final List<Objective> objectives;
    public final List<Reward> rewards;

    private Quest(Builder b) {
        this.id = b.id;
        this.category = b.category;
        this.tier = b.tier;
        this.title = b.title;
        this.desc = b.desc;
        this.xpLevels = b.xpLevels >= 0 ? b.xpLevels : b.tier * 2;
        this.points = b.points >= 0 ? b.points : b.tier * 10;
        this.repeatable = b.repeatable;
        this.objectives = Collections.unmodifiableList(new ArrayList<>(b.objectives));
        this.rewards = Collections.unmodifiableList(new ArrayList<>(b.rewards));
    }

    /** True if at least one objective is handed in at the laptop (so the Submit button does something). */
    public boolean hasHandIn() {
        for (Objective o : objectives) {
            if (o.type == QuestType.COLLECT) return true;
        }
        return false;
    }

    public static Builder builder(String id, QuestCategory category, int tier, String title, String desc) {
        return new Builder(id, category, tier, title, desc);
    }

    public static final class Builder {
        private final String id;
        private final QuestCategory category;
        private final int tier;
        private final String title;
        private final String desc;
        private int xpLevels = -1;
        private int points = -1;
        private boolean repeatable;
        private final List<Objective> objectives = new ArrayList<>();
        private final List<Reward> rewards = new ArrayList<>();

        private Builder(String id, QuestCategory category, int tier, String title, String desc) {
            this.id = id;
            this.category = category;
            this.tier = tier;
            this.title = title;
            this.desc = desc;
        }

        private static String ns(String id) {
            return id.equals("*") || id.indexOf(':') >= 0 ? id : "minecraft:" + id;
        }

        private Builder obj(QuestType type, String label, int count, String... ids) {
            String[] t = new String[ids.length];
            for (int i = 0; i < ids.length; i++) t[i] = ns(ids[i]);
            objectives.add(new Objective(type, label, count, t));
            return this;
        }

        public Builder collect(String label, int count, String... ids) { return obj(QuestType.COLLECT, label, count, ids); }
        public Builder kill(String label, int count, String... ids) { return obj(QuestType.KILL, label, count, ids); }
        public Builder visit(String label, String... ids) { return obj(QuestType.VISIT, label, 1, ids); }
        public Builder eat(String label, int count, String... ids) { return obj(QuestType.EAT, label, count, ids); }
        public Builder craft(String label, int count, String... ids) { return obj(QuestType.CRAFT, label, count, ids); }
        public Builder fish(String label, int count, String... ids) { return obj(QuestType.FISH, label, count, ids); }
        public Builder mine(String label, int count, String... ids) { return obj(QuestType.MINE, label, count, ids); }

        public Builder item(String id, int count) {
            rewards.add(new Reward(ns(id), count));
            return this;
        }

        public Builder xp(int levels) { this.xpLevels = levels; return this; }
        public Builder points(int p) { this.points = p; return this; }
        public Builder repeatable() { this.repeatable = true; return this; }

        public Quest build() {
            return new Quest(this);
        }
    }
}
