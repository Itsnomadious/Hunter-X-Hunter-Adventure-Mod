package net.hxhadventure.addon.quest;

import com.mojang.logging.LogUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

import static net.hxhadventure.addon.quest.QuestCategory.*;

/**
 * The quest catalogue. Both sides load this class: the server tracks and rewards, the client lists. Adding a quest is one more
 * {@code add(Quest.builder(...)...)} line below; rewards default to {@code 2 x tier} XP levels and {@code 10 x tier} Hunter points.
 */
public final class Quests {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<String, Quest> BY_ID = new LinkedHashMap<>();

    private Quests() {}

    private static void add(Quest.Builder b) {
        Quest q = b.build();
        if (BY_ID.put(q.id, q) != null) throw new IllegalStateException("Duplicate quest id " + q.id);
    }

    public static Quest get(String id) { return BY_ID.get(id); }

    public static List<Quest> all() { return Collections.unmodifiableList(new ArrayList<>(BY_ID.values())); }

    public static List<Quest> in(QuestCategory c) {
        List<Quest> out = new ArrayList<>();
        for (Quest q : BY_ID.values()) if (q.category == c) out.add(q);
        return out;
    }

    /** Logs every registry id the catalogue uses that does not exist (a typo would otherwise make a quest impossible). Call once the registries are filled. */
    public static void validate() {
        for (Quest q : BY_ID.values()) {
            for (Quest.Reward r : q.rewards) {
                if (!ForgeRegistries.ITEMS.containsKey(new ResourceLocation(r.item))) LOGGER.error("Quest {}: unknown reward item {}", q.id, r.item);
            }
            for (Quest.Objective o : q.objectives) {
                for (String t : o.targets) {
                    if (t.equals("*")) continue;
                    ResourceLocation rl = new ResourceLocation(t);
                    boolean ok = switch (o.type) {
                        case COLLECT, CRAFT, EAT -> ForgeRegistries.ITEMS.containsKey(rl);
                        case MINE -> ForgeRegistries.BLOCKS.containsKey(rl);
                        case KILL -> ForgeRegistries.ENTITY_TYPES.containsKey(rl);
                        case FISH, VISIT -> true; // structures are data driven: checked when a world loads
                    };
                    if (!ok) LOGGER.error("Quest {}: unknown {} target {}", q.id, o.type, t);
                }
            }
        }
    }

    static {
        // ============================================================ GOURMET
        add(Quest.builder("gourmet_first_course", GOURMET, 3, "First Course",
                "Every great chef starts somewhere. Bake two cakes for the Association's canteen.")
            .craft("Cake", 2, "cake").item("cooked_beef", 8).repeatable());
        add(Quest.builder("gourmet_forager", GOURMET, 1, "Forager's Basket",
                "Gather wild berries from the taiga and the glowing caves below.")
            .collect("Sweet Berries", 16, "sweet_berries").collect("Glow Berries", 8, "glow_berries").item("golden_carrot", 4).repeatable());
        add(Quest.builder("gourmet_honey", GOURMET, 2, "Liquid Gold",
                "A client wants the freshest honey there is. Raid the hives, politely.")
            .collect("Honey Bottles", 4, "honey_bottle").collect("Honeycomb", 8, "honeycomb").item("golden_apple", 1));
        add(Quest.builder("gourmet_pies", GOURMET, 2, "Banquet Pies",
                "Forty guests, one dessert table. Bake pumpkin pies for all of them.")
            .craft("Pumpkin Pie", 8, "pumpkin_pie").item("cooked_porkchop", 16));
        add(Quest.builder("gourmet_catch", GOURMET, 2, "Catch of the Day",
                "A true gourmet tastes before he judges. Sample the sea's finest cooked fish.")
            .eat("Cooked Salmon", 3, "cooked_salmon").eat("Cooked Cod", 3, "cooked_cod").item("golden_carrot", 8));
        add(Quest.builder("gourmet_stew", GOURMET, 2, "Hearty Stew",
                "Rabbit stew, the hunter's comfort food. Cook it, then taste your own work.")
            .craft("Rabbit Stew", 3, "rabbit_stew").eat("Rabbit Stew", 2, "rabbit_stew").item("golden_apple", 2));
        add(Quest.builder("gourmet_golden_course", GOURMET, 3, "The Golden Course",
                "A wealthy patron demands gold on every plate. Craft the carrots, find the apple.")
            .craft("Golden Carrots", 8, "golden_carrot").collect("Golden Apple", 1, "golden_apple").item("emerald", 6));
        add(Quest.builder("gourmet_legend", GOURMET, 4, "Legendary Ingredient",
                "Somewhere, in a forgotten vault, lies the ingredient every chef dreams of. Bring it back.")
            .collect("Enchanted Golden Apple", 1, "enchanted_golden_apple").item("diamond", 6));

        // ============================================================ SEA
        add(Quest.builder("sea_first_cast", SEA, 1, "First Cast",
                "Every sea hunter learns patience first. Fish up ten catches, whatever they are.")
            .fish("Catches", 10, "*").item("cooked_salmon", 8).repeatable());
        add(Quest.builder("sea_kelp", SEA, 1, "Kelp Run",
                "The Association's cooks are out of kelp. Harvest a boatload.")
            .collect("Kelp", 32, "kelp").item("emerald", 2).repeatable());
        add(Quest.builder("sea_drowned", SEA, 1, "Drowned Menace",
                "The dead are walking the shallows. Put ten of them back to rest.")
            .kill("Drowned", 10, "drowned").item("gold_ingot", 4).repeatable());
        add(Quest.builder("sea_reef", SEA, 2, "Reef Collector",
                "An aquarium is paying well for live specimens from the warm reefs.")
            .collect("Tropical Fish", 3, "tropical_fish").collect("Pufferfish", 2, "pufferfish").item("emerald", 4));
        add(Quest.builder("sea_haul", SEA, 2, "Hunter's Haul",
                "A long day on the water. Land twenty-five catches.")
            .fish("Catches", 25, "*").item("name_tag", 2));
        add(Quest.builder("sea_wreck", SEA, 3, "Wreck Diver",
                "Somewhere on the seabed a ship went down with something aboard. Find a wreck.")
            .visit("A Shipwreck", "shipwreck", "shipwreck_beached").item("emerald", 6));
        add(Quest.builder("sea_guardian", SEA, 3, "Guardian Duty",
                "The monument's guardians are killing fishing crews. Thin their numbers.")
            .kill("Guardians", 6, "guardian").item("sponge", 2));
        add(Quest.builder("sea_monument", SEA, 4, "Monument Raid",
                "Find an ocean monument and silence its elder.")
            .visit("An Ocean Monument", "monument").kill("Elder Guardian", 1, "elder_guardian").item("diamond", 3));
        add(Quest.builder("sea_heart", SEA, 4, "Heart of the Sea",
                "Every sea hunter's dream: a heart of the sea, buried by some long-dead captain.")
            .collect("Heart of the Sea", 1, "heart_of_the_sea").item("diamond", 8).item("nautilus_shell", 2));

        // ============================================================ RUINS
        add(Quest.builder("ruins_portal", RUINS, 1, "Broken Gateways",
                "Survey a ruined portal. Whoever built these left in a hurry.")
            .visit("A Ruined Portal", "ruined_portal", "ruined_portal_desert", "ruined_portal_jungle", "ruined_portal_swamp",
                "ruined_portal_mountain", "ruined_portal_ocean").item("emerald", 2));
        add(Quest.builder("ruins_ocean", RUINS, 2, "Sunken Foundations",
                "Chart the ruins that the tide has taken back.")
            .visit("An Ocean Ruin", "ocean_ruin_cold", "ocean_ruin_warm").item("emerald", 3));
        add(Quest.builder("ruins_desert", RUINS, 2, "Sandbound Temple",
                "A temple half buried in the dunes. Document it. Mind the pressure plate.")
            .visit("A Desert Temple", "desert_pyramid").item("emerald", 4));
        add(Quest.builder("ruins_jungle", RUINS, 2, "Overgrown Relic",
                "The jungle swallowed this temple whole. Find it before the vines finish the job.")
            .visit("A Jungle Temple", "jungle_pyramid").item("emerald", 4));
        add(Quest.builder("ruins_preservation", RUINS, 2, "Preservation Work",
                "Restoration needs the right tools and the right vessels. Craft both.")
            .craft("Brush", 1, "brush").craft("Decorated Pots", 2, "decorated_pot").item("emerald", 4));
        add(Quest.builder("ruins_trail", RUINS, 3, "Trail Survey",
                "Buried ruins, stacked bricks and broken pots. Survey a site of the old trail.")
            .visit("Trail Ruins", "trail_ruins").item("emerald", 6));
        add(Quest.builder("ruins_mansion", RUINS, 4, "Hall of the Forgotten",
                "A mansion deep in the dark forest, its halls full of illagers. The records inside are the prize.")
            .visit("A Woodland Mansion", "mansion").item("diamond", 3));
        add(Quest.builder("ruins_stronghold", RUINS, 4, "The Lost Archive",
                "An ancient stronghold lies far beneath the surface. Find the way in.")
            .visit("A Stronghold", "stronghold").item("diamond", 3));
        add(Quest.builder("ruins_city", RUINS, 4, "City Beneath the Deep",
                "A whole city sleeps in the deep dark. Enter it. Do not make a sound.")
            .visit("An Ancient City", "ancient_city").item("diamond", 6).item("echo_shard", 2));

        // ============================================================ TREASURE
        add(Quest.builder("treasure_pocket", TREASURE, 1, "Pocket Change",
                "Every treasure hunter needs a bankroll. Bring in ten gold ingots.")
            .collect("Gold Ingots", 10, "gold_ingot").item("emerald", 2).repeatable());
        add(Quest.builder("treasure_x", TREASURE, 2, "X Marks the Spot",
                "A weathered map, a beach and a chest below the sand. Find some buried treasure.")
            .visit("Buried Treasure", "buried_treasure").item("emerald", 5));
        add(Quest.builder("treasure_gems", TREASURE, 2, "Gem Appraisal",
                "A dealer needs eight emeralds appraised. Hand them over.")
            .collect("Emeralds", 8, "emerald").item("diamond", 1));
        add(Quest.builder("treasure_delve", TREASURE, 3, "Dungeon Delver",
                "Old mineshafts hide old crates. Go and find one.")
            .visit("An Abandoned Mineshaft", "mineshaft", "mineshaft_mesa").item("emerald", 6));
        add(Quest.builder("treasure_fortress", TREASURE, 3, "Fortress Plunder",
                "The Nether's fortresses and bastions are stuffed with loot. Reach one.")
            .visit("A Fortress or Bastion", "fortress", "bastion_remnant").item("emerald", 8));
        add(Quest.builder("treasure_hoard", TREASURE, 4, "Dragon's Hoard",
                "A collector wants a dragon's hoard and he wants it in diamonds. Twelve of them.")
            .collect("Diamonds", 12, "diamond").item("experience_bottle", 8));
        add(Quest.builder("treasure_relic", TREASURE, 4, "Relic Broker",
                "A buyer wants a totem that has cheated death. Find one.")
            .collect("Totem of Undying", 1, "totem_of_undying").item("diamond", 4));
        add(Quest.builder("treasure_nether", TREASURE, 4, "Nether Bounty",
                "Netherite scrap: smelted from ancient debris, worth more than gold.")
            .collect("Netherite Scrap", 4, "netherite_scrap").item("diamond", 5));
        add(Quest.builder("treasure_collector", TREASURE, 4, "The Collector",
                "The rarest commission on the board. Two ingots of netherite, no questions asked.")
            .collect("Netherite Ingots", 2, "netherite_ingot").item("diamond", 10).item("enchanted_golden_apple", 1));

        // ============================================================ STONE
        add(Quest.builder("stone_lapis", STONE, 1, "Blue Stones",
                "A jeweler needs lapis, and plenty of it. Dig it out.")
            .mine("Lapis Ore", 12, "lapis_ore", "deepslate_lapis_ore").item("emerald", 2).repeatable());
        add(Quest.builder("stone_amethyst", STONE, 1, "Amethyst Rush",
                "The geodes are singing. Break them open and bring back the shards.")
            .collect("Amethyst Shards", 16, "amethyst_shard").item("emerald", 2).repeatable());
        add(Quest.builder("stone_quartz", STONE, 2, "Quartz Cutter",
                "Nether quartz makes the finest inlay. Mine sixteen veins.")
            .mine("Nether Quartz Ore", 16, "nether_quartz_ore").item("emerald", 3));
        add(Quest.builder("stone_jeweler", STONE, 2, "Jeweler's Commission",
                "A spyglass with an amethyst lens, and a block of solid gold to display it on.")
            .craft("Spyglass", 1, "spyglass").craft("Block of Gold", 1, "gold_block").item("emerald", 4));
        add(Quest.builder("stone_emerald", STONE, 3, "Emerald Eyes",
                "Emerald ore is only found in the mountains. Prospect three veins.")
            .mine("Emerald Ore", 3, "emerald_ore", "deepslate_emerald_ore").item("emerald", 6));
        add(Quest.builder("stone_diamond", STONE, 3, "Diamond Hunter",
                "Eight veins of diamond ore, and not a single one left behind.")
            .mine("Diamond Ore", 8, "diamond_ore", "deepslate_diamond_ore").item("emerald", 8));
        add(Quest.builder("stone_debris", STONE, 4, "Ancient Debris Prospector",
                "Below the lava, in the Nether, lies the toughest stone there is.")
            .mine("Ancient Debris", 6, "ancient_debris").item("diamond", 4));
        add(Quest.builder("stone_masterpiece", STONE, 4, "Gem Cutter's Masterpiece",
                "A patron wants a diamond centerpiece worth a king's ransom. Three solid blocks of it.")
            .collect("Blocks of Diamond", 3, "diamond_block").item("diamond", 8));

        // ============================================================ BLACKLIST
        add(Quest.builder("black_petty", BLACKLIST, 1, "Petty Crooks",
                "Pillagers are shaking down the outlying villages. Show them the law.")
            .kill("Pillagers", 6, "pillager").item("emerald", 3).repeatable());
        add(Quest.builder("black_muscle", BLACKLIST, 2, "Hired Muscle",
                "Vindicators for hire, axes and all. Bring four of them in.")
            .kill("Vindicators", 4, "vindicator").item("emerald", 4));
        add(Quest.builder("black_hexed", BLACKLIST, 2, "Hexed",
                "The witches' brews have poisoned a village well. Find the source.")
            .kill("Witches", 3, "witch").item("emerald", 4));
        add(Quest.builder("black_mage", BLACKLIST, 3, "Illager Mage",
                "Evokers summon fangs and vexes from nowhere. Two bounties on the board.")
            .kill("Evokers", 2, "evoker").item("emerald", 8));
        add(Quest.builder("black_beast", BLACKLIST, 3, "Beast Handler",
                "Raiders are siccing ravagers on the villages. Take down two.")
            .kill("Ravagers", 2, "ravager").item("emerald", 8));
        add(Quest.builder("black_streets", BLACKLIST, 3, "Clean the Streets",
                "A big sweep: twenty wanted illagers and witches, any mix.")
            .kill("Wanted Illagers or Witches", 20, "pillager", "vindicator", "evoker", "witch", "illusioner").item("emerald", 8).repeatable());
        add(Quest.builder("black_syndicate", BLACKLIST, 4, "Nether Syndicate",
                "Wither skeletons guard the fortresses like hired thugs. Remove eight enforcers.")
            .kill("Wither Skeletons", 8, "wither_skeleton").item("diamond", 3));
        add(Quest.builder("black_magician", BLACKLIST, 5, "Wanted: The Magician",
                "S-class bounty. He fights for pleasure and will smile all the way through. Bring Hisoka in.")
            .kill("Hisoka", 1, "hxhadventure:hisoka").item("diamond", 6));
        add(Quest.builder("black_spider", BLACKLIST, 5, "Wanted: The Spider",
                "S-class bounty. The leader of the Phantom Troupe steals more than treasure. Bring Chrollo in.")
            .kill("Chrollo", 1, "hxhadventure:chrollo").item("diamond", 6).repeatable());
    }
}
