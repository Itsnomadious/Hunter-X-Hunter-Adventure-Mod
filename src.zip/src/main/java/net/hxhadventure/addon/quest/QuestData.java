package net.hxhadventure.addon.quest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import net.hxhadventure.addon.HunterExam;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketQuestLog;
import net.hxhadventure.addon.network.PacketQuestSync;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * A player's quest log: which quests are active (with progress per objective), which are done, and their Hunter points. Stored in the player's
 * persistent data (so it survives death), changed only on the server, and sent to the client as a {@link Snapshot} whenever the laptop is open.
 */
public final class QuestData {
    public static final String KEY = "hxh_quests";
    public static final int MAX_ACTIVE = 20;

    public static final int ACTION_ACCEPT = 0, ACTION_ABANDON = 1, ACTION_SUBMIT = 2, ACTION_REFRESH = 3;

    private QuestData() {}

    // ------------------------------------------------------------------ the data

    public static final class Active {
        public final String id;
        public int[] progress;

        public Active(String id, int[] progress) {
            this.id = id;
            this.progress = progress;
        }
    }

    public static final class Snapshot {
        public int points;
        /** Total quests ever completed (repeatables count each time). Hunter stars are earned from this. */
        public int done;
        /** Quests completed at difficulty 4 or more, and at difficulty 5 (repeats count each time). Hunter stars need these. */
        public int done4, done5;
        public final LinkedHashSet<String> completed = new LinkedHashSet<>();
        public final List<Active> active = new ArrayList<>();

        public Active find(String id) {
            for (Active a : active) if (a.id.equals(id)) return a;
            return null;
        }

        public void write(FriendlyByteBuf b) {
            b.writeVarInt(points);
            b.writeVarInt(done);
            b.writeVarInt(done4);
            b.writeVarInt(done5);
            b.writeVarInt(completed.size());
            for (String s : completed) b.writeUtf(s);
            b.writeVarInt(active.size());
            for (Active a : active) {
                b.writeUtf(a.id);
                b.writeVarInt(a.progress.length);
                for (int v : a.progress) b.writeVarInt(v);
            }
        }

        public static Snapshot read(FriendlyByteBuf b) {
            Snapshot s = new Snapshot();
            s.points = b.readVarInt();
            s.done = b.readVarInt();
            s.done4 = b.readVarInt();
            s.done5 = b.readVarInt();
            int c = b.readVarInt();
            for (int i = 0; i < c; i++) s.completed.add(b.readUtf());
            int n = b.readVarInt();
            for (int i = 0; i < n; i++) {
                String id = b.readUtf();
                int len = b.readVarInt();
                int[] p = new int[len];
                for (int j = 0; j < len; j++) p[j] = b.readVarInt();
                s.active.add(new Active(id, p));
            }
            return s;
        }
    }

    // ------------------------------------------------------------------ storage

    private static CompoundTag persisted(Player p) {
        return p.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
    }

    public static Snapshot read(Player p) {
        CompoundTag root = persisted(p).getCompound(KEY);
        Snapshot s = new Snapshot();
        s.points = root.getInt("points");
        ListTag done = root.getList("completed", Tag.TAG_STRING);
        for (int i = 0; i < done.size(); i++) s.completed.add(done.getString(i));
        s.done = Math.max(root.getInt("done"), s.completed.size());
        s.done4 = root.getInt("done4");
        s.done5 = root.getInt("done5");
        ListTag act = root.getList("active", Tag.TAG_COMPOUND);
        for (int i = 0; i < act.size(); i++) {
            CompoundTag a = act.getCompound(i);
            Quest q = Quests.get(a.getString("id"));
            if (q == null) continue; // a quest that was removed from the catalogue
            s.active.add(new Active(q.id, fit(a.getIntArray("progress"), q.objectives.size())));
        }
        return s;
    }

    public static void write(ServerPlayer p, Snapshot s) {
        CompoundTag root = new CompoundTag();
        root.putInt("points", s.points);
        root.putInt("done", s.done);
        root.putInt("done4", s.done4);
        root.putInt("done5", s.done5);
        ListTag done = new ListTag();
        for (String id : s.completed) done.add(StringTag.valueOf(id));
        root.put("completed", done);
        ListTag act = new ListTag();
        for (Active a : s.active) {
            CompoundTag t = new CompoundTag();
            t.putString("id", a.id);
            t.putIntArray("progress", a.progress);
            act.add(t);
        }
        root.put("active", act);
        CompoundTag per = persisted(p);
        per.put(KEY, root);
        p.getPersistentData().put(Player.PERSISTED_NBT_TAG, per);
        sendLog(p, s.active); // keeps the O menu's quest page and the En quest markers up to date
    }

    /** Sends just the active quests (with progress) to the player's client, so the O menu and En markers need no laptop. */
    public static void sendLog(ServerPlayer p, List<Active> active) {
        AddonNetwork.sendToPlayer(new PacketQuestLog(active), p);
    }

    public static void sendLog(ServerPlayer p) {
        sendLog(p, read(p).active);
    }

    private static int[] fit(int[] progress, int n) {
        return progress.length == n ? progress : Arrays.copyOf(progress, n);
    }

    /** Cheap check used by the event handlers before they do any work. */
    public static boolean hasActive(Player p) {
        return !persisted(p).getCompound(KEY).getList("active", Tag.TAG_COMPOUND).isEmpty();
    }

    public static boolean isHunter(ServerPlayer p) {
        return p.isCreative() || HunterExam.hasLicense(p);
    }

    // ------------------------------------------------------------------ ranks

    private static final int[] RANK_AT = {0, 40, 100, 200, 350, 550};
    private static final String[] RANK = {"Rookie Hunter", "Apprentice Hunter", "Journeyman Hunter", "Expert Hunter", "Master Hunter", "Legendary Hunter"};

    public static String rank(int points) {
        int r = 0;
        for (int i = 0; i < RANK_AT.length; i++) if (points >= RANK_AT[i]) r = i;
        return RANK[r];
    }

    // ------------------------------------------------------------------ Hunter stars

    /** Quests completed in total needed for the 1st, 2nd and 3rd Hunter star (on top of the difficulty checks below). */
    public static final int[] STAR_AT = {15, 40, 75};
    public static final int MAX_STARS = 3;

    /** Points for clearing a repeatable quest again: a tenth of the first clear (at least 1). */
    public static int repeatPoints(Quest q) {
        return Math.max(1, q.points / 10);
    }

    /**
     * Stars, earned in order: the 1st needs {@link #STAR_AT}[0] completions including a difficulty 4 quest, the 2nd {@link #STAR_AT}[1] including a
     * difficulty 5 quest, the 3rd {@link #STAR_AT}[2] including five difficulty 5 clears. Only the two Wanted bounties are difficulty 5, so the
     * last star means bringing both in over and over.
     */
    public static int stars(Snapshot s) {
        if (s.done < STAR_AT[0] || s.done4 < 1) return 0;
        if (s.done < STAR_AT[1] || s.done5 < 1) return 1;
        if (s.done < STAR_AT[2] || s.done5 < 5) return 2;
        return 3;
    }

    /** One line saying what the next star still needs (empty at 3 stars). */
    public static String nextStarHint(Snapshot s) {
        int n = stars(s);
        if (n >= MAX_STARS) return "";
        String need = n == 0 ? "a difficulty 4 quest" : n == 1 ? "a difficulty 5 quest" : "5 difficulty 5 clears (" + Math.min(5, s.done5) + "/5)";
        return "Next star: " + STAR_AT[n] + " quests (" + Math.min(STAR_AT[n], s.done) + "/" + STAR_AT[n] + ") incl. " + need;
    }

    private static void announceStar(ServerPlayer sp, int stars) {
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1.0f, 1.0f);
        sp.sendSystemMessage(Component.literal("\u00a76\u2605 [Hunter] A Hunter star has been added to your licence! \u00a7e(" + stars + "/" + MAX_STARS + ")"));
    }

    // ------------------------------------------------------------------ progress (server)

    /** Adds {@code amount} to every active objective of this type that accepts {@code key}. */
    public static void add(ServerPlayer sp, QuestType type, String key, int amount) {
        if (amount <= 0 || !hasActive(sp)) return;
        Snapshot s = read(sp);
        boolean changed = false;
        for (Active a : s.active) {
            Quest q = Quests.get(a.id);
            if (q == null) continue;
            for (int i = 0; i < q.objectives.size(); i++) {
                Quest.Objective o = q.objectives.get(i);
                if (o.type != type || !o.matches(key) || a.progress[i] >= o.count) continue;
                a.progress[i] = Math.min(o.count, a.progress[i] + amount);
                changed = true;
                String done = a.progress[i] >= o.count ? "§a" : "§f";
                sp.displayClientMessage(Component.literal("§6[Quest] §f" + q.title + " §7- " + o.type.verb + " " + o.label + " " + done + a.progress[i] + "/" + o.count), true);
                if (isComplete(q, a)) {
                    sp.sendSystemMessage(Component.literal("§a[Quest] §f" + q.title + "§a is ready to hand in at a Hunter laptop."));
                }
            }
        }
        if (changed) write(sp, s);
    }

    public static boolean isComplete(Quest q, Active a) {
        for (int i = 0; i < q.objectives.size(); i++) {
            if (a.progress[i] < q.objectives.get(i).count) return false;
        }
        return true;
    }

    /** How many of an objective's items the player is carrying right now (used by the laptop to show hand-in progress). */
    public static int held(Player p, Quest.Objective o) {
        if (o.type != QuestType.COLLECT) return 0;
        int n = 0;
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && o.matches(idOf(st.getItem()))) n += st.getCount();
        }
        return n;
    }

    private static String idOf(Item item) {
        ResourceLocation rl = ForgeRegistries.ITEMS.getKey(item);
        return rl == null ? "" : rl.toString();
    }

    // ------------------------------------------------------------------ actions (server)

    public static void handle(ServerPlayer sp, int action, String questId) {
        if (!isHunter(sp)) {
            sp.sendSystemMessage(Component.literal("§cThe Hunter Association's quest network is for licensed Hunters only."));
            return;
        }
        Quest q = Quests.get(questId);
        switch (action) {
            case ACTION_ACCEPT -> {
                if (q != null) accept(sp, q);
            }
            case ACTION_ABANDON -> {
                if (q != null) abandon(sp, q);
            }
            case ACTION_SUBMIT -> {
                if (q != null) submit(sp, q);
            }
            default -> { }
        }
    }

    private static void accept(ServerPlayer sp, Quest q) {
        Snapshot s = read(sp);
        if (s.find(q.id) != null) return;
        if (s.completed.contains(q.id) && !q.repeatable) {
            sp.sendSystemMessage(Component.literal("§cYou have already completed that quest."));
            return;
        }
        if (s.active.size() >= MAX_ACTIVE) {
            sp.sendSystemMessage(Component.literal("§cYour quest log is full (" + MAX_ACTIVE + "). Hand in or abandon a quest first."));
            return;
        }
        s.active.add(new Active(q.id, new int[q.objectives.size()]));
        write(sp, s);
        sp.sendSystemMessage(Component.literal("§6[Quest] §fAccepted: §e" + q.title));
    }

    private static void abandon(ServerPlayer sp, Quest q) {
        Snapshot s = read(sp);
        Active a = s.find(q.id);
        if (a == null) return;
        s.active.remove(a);
        write(sp, s);
        sp.sendSystemMessage(Component.literal("§6[Quest] §7Abandoned: " + q.title));
    }

    /** Takes the items the quest asks for from the inventory (as many as are carried, up to what is still missing), then pays out if everything is done. */
    private static void submit(ServerPlayer sp, Quest q) {
        Snapshot s = read(sp);
        Active a = s.find(q.id);
        if (a == null) return;
        boolean handedIn = false;
        for (int i = 0; i < q.objectives.size(); i++) {
            Quest.Objective o = q.objectives.get(i);
            if (o.type != QuestType.COLLECT) continue;
            int need = o.count - a.progress[i];
            if (need <= 0) continue;
            Inventory inv = sp.getInventory();
            for (int slot = 0; slot < inv.getContainerSize() && need > 0; slot++) {
                ItemStack st = inv.getItem(slot);
                if (st.isEmpty() || !o.matches(idOf(st.getItem()))) continue;
                int take = Math.min(need, st.getCount());
                st.shrink(take);
                need -= take;
                a.progress[i] += take;
                handedIn = true;
            }
        }
        if (handedIn) {
            sp.getInventory().setChanged();
            sp.containerMenu.broadcastChanges();
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.6f, 1.0f);
        }
        if (isComplete(q, a)) {
            s.active.remove(a);
            boolean repeat = s.completed.contains(q.id);
            int gained = repeat ? repeatPoints(q) : q.points;
            s.completed.add(q.id);
            s.points += gained;
            int starsBefore = stars(s);
            s.done++;
            if (q.tier >= 4) s.done4++;
            if (q.tier >= 5) s.done5++;
            write(sp, s);
            reward(sp, q, gained, s.points);
            int starsNow = stars(s);
            if (starsNow > starsBefore) announceStar(sp, starsNow);
        } else {
            write(sp, s);
            sp.sendSystemMessage(Component.literal(handedIn
                ? "§6[Quest] §fItems handed in for §e" + q.title + "§f. There is still more to do."
                : "§6[Quest] §7Nothing to hand in yet for " + q.title + "."));
        }
    }

    private static void reward(ServerPlayer sp, Quest q, int gained, int totalPoints) {
        for (Quest.Reward r : q.rewards) {
            Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(r.item));
            if (item == null) continue;
            int left = r.count;
            while (left > 0) {
                int n = Math.min(left, item.getMaxStackSize());
                ItemStack st = new ItemStack(item, n);
                if (!sp.getInventory().add(st)) sp.drop(st, false);
                left -= n;
            }
        }
        if (q.xpLevels > 0) sp.giveExperienceLevels(q.xpLevels);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0f, 1.0f);
        sp.sendSystemMessage(Component.literal("§a[Quest] Completed: §e" + q.title + "§a  +" + gained + " Hunter points §7(" + rank(totalPoints) + ", " + totalPoints + " pts)"));
    }

    // ------------------------------------------------------------------ sync

    /** Sends the quest log to the player's client. {@code open} also opens the laptop screen at {@code pos}. */
    public static void sync(ServerPlayer sp, BlockPos pos, boolean open) {
        AddonNetwork.sendToPlayer(new PacketQuestSync(pos, open, read(sp)), sp);
    }
}
