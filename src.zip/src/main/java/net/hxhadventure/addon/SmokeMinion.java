package net.hxhadventure.addon;

import java.util.EnumSet;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.hxhadventure.utils.AllianceUtils;

/**
 * What Deep Purple summons: a short-lived servant of one user. Smoke monsters and clones both extend this, so they share every stat
 * (see {@link SmokeTuning}). A minion crouches beside the user for a moment after it appears, then follows the user, fights whatever
 * hurts the user or is hurt by the user, and goes after hostile mobs nearby. It never harms its owner or its siblings, drops nothing,
 * is never saved, and turns back into smoke when its time is up, when it dies, or when its owner dies, leaves or loses the Hatsu.
 */
public abstract class SmokeMinion extends PathfinderMob {
    private static final EntityDataAccessor<Optional<UUID>> OWNER =
        SynchedEntityData.defineId(SmokeMinion.class, EntityDataSerializers.OPTIONAL_UUID);

    private int crouchTicks;
    private ServerPlayer ownerRef;

    protected SmokeMinion(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        this.setPersistenceRequired();
        this.setCanPickUpLoot(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, SmokeTuning.MINION_BASE_HEALTH)
            .add(Attributes.MOVEMENT_SPEED, SmokeTuning.MINION_SPEED)
            .add(Attributes.ATTACK_DAMAGE, SmokeTuning.MINION_BASE_DAMAGE)
            .add(Attributes.ATTACK_KNOCKBACK, 0.0)
            .add(Attributes.ARMOR, SmokeTuning.MINION_ARMOR)
            .add(Attributes.FOLLOW_RANGE, SmokeTuning.MINION_FOLLOW_RANGE);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OWNER, Optional.empty());
    }

    public UUID ownerId() {
        return this.entityData.get(OWNER).orElse(null);
    }

    /** Called once, before the minion is added to the level: its owner and its stats at the owner's Hatsu level. */
    public void setup(ServerPlayer owner, int hatsuLevel) {
        this.entityData.set(OWNER, Optional.of(owner.getUUID()));
        this.ownerRef = owner;
        set(Attributes.MAX_HEALTH, SmokeTuning.MINION_BASE_HEALTH + hatsuLevel * SmokeTuning.MINION_HEALTH_PER_LEVEL);
        set(Attributes.ATTACK_DAMAGE, SmokeTuning.MINION_BASE_DAMAGE + hatsuLevel * SmokeTuning.MINION_DAMAGE_PER_LEVEL);
        this.setHealth(this.getMaxHealth());
    }

    private void set(net.minecraft.world.entity.ai.attributes.Attribute attr, double value) {
        AttributeInstance a = this.getAttribute(attr);
        if (a != null) a.setBaseValue(value);
    }

    /** Crouch where it stands for a moment, doing nothing, then go to work. */
    public void startCrouch(int ticks) {
        this.crouchTicks = ticks;
        this.setPose(Pose.CROUCHING);
    }

    public boolean isSummoning() {
        return crouchTicks > 0;
    }

    @Nullable
    protected ServerPlayer owner() {
        return ownerRef != null && ownerRef.isAlive() && !ownerRef.hasDisconnected() ? ownerRef : null;
    }

    // ---------------------------------------------------------------- allegiance

    public boolean isAllyOfOwner(Entity e) {
        UUID o = ownerId();
        if (o == null || e == null) return false;
        if (e.getUUID().equals(o)) return true;
        if (e instanceof SmokeMinion m && o.equals(m.ownerId())) return true;
        ServerPlayer owner = owner();
        return owner != null && AllianceUtils.isAlly(e, owner);
    }

    @Override
    public boolean isAlliedTo(Entity other) {
        return isAllyOfOwner(other) || super.isAlliedTo(other);
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        return !isAllyOfOwner(target) && super.canAttack(target);
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        if (target != null && isAllyOfOwner(target)) return;
        super.setTarget(target);
    }

    // ---------------------------------------------------------------- goals

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new CrouchGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.addGoal(5, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new OwnerHurtByGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false,
            e -> e instanceof Enemy && !isAllyOfOwner(e) && e.distanceToSqr(this) <= SmokeTuning.AGGRO_RANGE * SmokeTuning.AGGRO_RANGE));
    }

    private static final class CrouchGoal extends Goal {
        private final SmokeMinion mob;

        CrouchGoal(SmokeMinion mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return mob.crouchTicks > 0;
        }

        @Override
        public boolean canContinueToUse() {
            return mob.crouchTicks > 0;
        }

        @Override
        public boolean isInterruptable() {
            return false;
        }

        @Override
        public void start() {
            mob.getNavigation().stop();
        }
    }

    private static final class FollowOwnerGoal extends Goal {
        private final SmokeMinion mob;
        private int recalc;

        FollowOwnerGoal(SmokeMinion mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            ServerPlayer o = mob.owner();
            return o != null && o.level() == mob.level() && mob.getTarget() == null
                && mob.distanceToSqr(o) > SmokeTuning.FOLLOW_START * SmokeTuning.FOLLOW_START;
        }

        @Override
        public boolean canContinueToUse() {
            ServerPlayer o = mob.owner();
            return o != null && o.level() == mob.level() && mob.getTarget() == null && mob.distanceToSqr(o) > 12.0;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            ServerPlayer o = mob.owner();
            if (o == null) return;
            mob.getLookControl().setLookAt(o, 10f, mob.getMaxHeadXRot());
            if (mob.distanceToSqr(o) > SmokeTuning.TELEPORT_DISTANCE * SmokeTuning.TELEPORT_DISTANCE) {
                double a = mob.getRandom().nextDouble() * Math.PI * 2;
                mob.moveTo(o.getX() + Math.cos(a) * 2.5, o.getY(), o.getZ() + Math.sin(a) * 2.5, mob.getYRot(), 0f);
                mob.getNavigation().stop();
                return;
            }
            if (--recalc <= 0) {
                recalc = 10;
                mob.getNavigation().moveTo(o, 1.3);
            }
        }
    }

    private static final class OwnerHurtByGoal extends TargetGoal {
        private final SmokeMinion mob;
        private LivingEntity attacker;
        private int stamp;

        OwnerHurtByGoal(SmokeMinion mob) {
            super(mob, false);
            this.mob = mob;
            setFlags(EnumSet.of(Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            ServerPlayer o = mob.owner();
            if (o == null) return false;
            attacker = o.getLastHurtByMob();
            return o.getLastHurtByMobTimestamp() != stamp && attacker != null && canAttack(attacker, TargetingConditions.DEFAULT);
        }

        @Override
        public void start() {
            mob.setTarget(attacker);
            ServerPlayer o = mob.owner();
            if (o != null) stamp = o.getLastHurtByMobTimestamp();
            super.start();
        }
    }

    private static final class OwnerHurtTargetGoal extends TargetGoal {
        private final SmokeMinion mob;
        private LivingEntity victim;
        private int stamp;

        OwnerHurtTargetGoal(SmokeMinion mob) {
            super(mob, false);
            this.mob = mob;
            setFlags(EnumSet.of(Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            ServerPlayer o = mob.owner();
            if (o == null) return false;
            victim = o.getLastHurtMob();
            return o.getLastHurtMobTimestamp() != stamp && victim != null && canAttack(victim, TargetingConditions.DEFAULT);
        }

        @Override
        public void start() {
            mob.setTarget(victim);
            ServerPlayer o = mob.owner();
            if (o != null) stamp = o.getLastHurtMobTimestamp();
            super.start();
        }
    }

    // ---------------------------------------------------------------- life

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide && random.nextInt(3) == 0) {
            level().addParticle(ParticleTypes.CLOUD, getRandomX(0.5), getRandomY(), getRandomZ(0.5), 0.0, 0.01, 0.0);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (crouchTicks > 0 && --crouchTicks == 0) setPose(Pose.STANDING);
        if (tickCount % 10 == 0 && level() instanceof ServerLevel sl && ownerId() != null) {
            if (ownerRef == null || ownerRef.hasDisconnected()) ownerRef = sl.getServer().getPlayerList().getPlayer(ownerId());
            // the owner may have changed dimension: look the player up again
            else if (ownerRef.isRemoved()) ownerRef = sl.getServer().getPlayerList().getPlayer(ownerId());
        }
        if (!keepsAlive() && tickCount % 20 == 0) {
            ServerPlayer o = owner();
            if (tickCount > 40 && (o == null || !SmokeManipulation.canUse(net.hxhadventure.abilities.Combat.get(o)))) dissolve();
            else if (tickCount > SmokeTuning.MINION_LIFETIME_TICKS) dissolve();
        }
    }

    /** A minion that is held by something else (Black Voice's decoy) does not time out or dissolve when its owner is not a smoke user. */
    protected boolean keepsAlive() {
        return false;
    }

    /** Back into smoke. */
    public void dissolve() {
        if (level() instanceof ServerLevel sl && !isRemoved()) {
            sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + getBbHeight() * 0.5, getZ(), 14, 0.3, 0.5, 0.3, 0.03);
            sl.playSound(null, blockPosition(), SoundEvents.FIRE_EXTINGUISH, SoundSource.HOSTILE, 0.5f, 1.4f);
        }
        discard();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hit = super.hurt(source, amount);
        if (hit && level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + getBbHeight() * 0.6, getZ(), 4, 0.2, 0.3, 0.2, 0.02);
        }
        return hit;
    }

    /** Smoke does not leave a corpse: it is gone the moment it falls. */
    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide) dissolve();
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return true;
    }
}
