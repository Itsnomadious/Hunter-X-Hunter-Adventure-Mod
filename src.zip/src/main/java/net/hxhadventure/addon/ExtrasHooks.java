package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.entity.player.Player;
import net.hxhadventure.abilities.Combat;

/**
 * Logic called from the mixins in {@code addon.mixin}. It lives here (not in the mixin package)
 * because mixin classes cannot be referenced directly from normal code.
 *
 * These hooks replace the edits the README used to ask for in HxHAdventure's own source.
 */
public final class ExtrasHooks {
    private ExtrasHooks() {}

    /** Kit ids: 8 = Chains (Kurapika), 9 = Skill Hunter (Chrollo), 10 = Doctor Blythe (Neferpitou). */
    public static final int CHAINS_KIT = ChainManager.CHAINS_KIT;
    public static final int HUNTER_KIT = SkillHunter.KIT;
    public static final int BLYTHE_KIT = DoctorBlythe.KIT;
    /** 11 = Explosive Orbs (Silva), Emitters only. */
    public static final int ORBS_KIT = ExplosiveOrbs.KIT;
    /** 12 = Aura Blast (Zeno), Emitters only. */
    public static final int BLAST_KIT = AuraBlast.KIT;
    /** 13 = Bungee Gum (Hisoka), Transmuters only. */
    public static final int GUM_KIT = BungeeGum.KIT;
    /** 14 = Jajanken (Gon), Enhancers only. */
    public static final int JAJANKEN_KIT = Jajanken.KIT;
    /** 15 = Illumi's Needles, Manipulators only. */
    public static final int NEEDLES_KIT = IllumiNeedles.KIT;
    /** 18 = Kalluto's Paper Manipulation, Manipulators only. */
    public static final int PAPER_KIT = PaperManipulation.KIT;

    /** 23 = Shalnark's Black Voice, Manipulators only. */
    public static final int BLACKVOICE_KIT = BlackVoice.KIT;

    /** 19 = Knuckle's Hakoware, Conjurers only. */
    public static final int HAKOWARE_KIT = Hakoware.KIT;

    private static final java.util.Map<Player, Integer> LAST_BIND_MSG = new java.util.WeakHashMap<>();

    /** True while Chain Jail holds the entity or it has the Forced Zetsu effect. No side effects. */
    public static boolean hatsuForced(net.minecraft.world.entity.LivingEntity e) {
        return e != null && !e.level().isClientSide && (ChainManager.isJailed(e) || HatsuEffects.has(e) || BlackVoice.isNenlessBody(e));
    }

    /**
     * Gate for every path that can switch a player's Ten or Ren on: true means "refuse". Called from the
     * mixins so the toggle is rejected up front instead of being turned off a tick later.
     */
    public static boolean nenBlocked(Player p) {
        if (!hatsuForced(p)) return false;
        Integer last = LAST_BIND_MSG.get(p);
        if (last == null || p.tickCount - last >= 20 || p.tickCount < last) {
            LAST_BIND_MSG.put(p, p.tickCount);
            p.displayClientMessage(net.minecraft.network.chat.Component.literal(
                ChainManager.isJailed(p) ? "\u00a77Chains bind you"
                    : BlackVoice.isNenlessBody(p) ? "\u00a77You have no Nen in this body" : "\u00a75Forced Zetsu: Ten and Ren are sealed"), true);
        }
        return true;
    }

    /** Gate for switching Ren on: the same as {@link #nenBlocked}, and Godspeed seals Ren too. */
    public static boolean renBlocked(Player p) {
        if (Vows.isLocked(p, "REN")) {
            Integer lastLock = LAST_BIND_MSG.get(p);
            if (lastLock == null || p.tickCount - lastLock >= 20 || p.tickCount < lastLock) {
                LAST_BIND_MSG.put(p, p.tickCount);
                p.displayClientMessage(net.minecraft.network.chat.Component.literal("\u00a77You swore never to use Ren again"), true);
            }
            return true;
        }
        if (nenBlocked(p)) return true;
        if (!LightningAura.isGodspeed(p)) return false;
        Integer last = LAST_BIND_MSG.get(p);
        if (last == null || p.tickCount - last >= 20 || p.tickCount < last) {
            LAST_BIND_MSG.put(p, p.tickCount);
            p.displayClientMessage(net.minecraft.network.chat.Component.literal("\u00a7bGodspeed: Ren cannot be used"), true);
        }
        return true;
    }

    /** Extends HxHAdventure's R/Z ability list with the chain and Skill Hunter abilities. */
    public static String[] menuSet(String[] base, Combat c) {
        if (c == null) return base;
        int kit = c.getCurrentKit();
        if (kit == CHAINS_KIT || kit == HUNTER_KIT || kit == BLYTHE_KIT || kit == ORBS_KIT || kit == BLAST_KIT || kit == GUM_KIT || kit == JAJANKEN_KIT || kit == NEEDLES_KIT || kit == PAPER_KIT || kit == BLACKVOICE_KIT || kit == HAKOWARE_KIT || kit == Guanyin.KIT || kit == LightningAura.KIT || kit == HideAndSeek.KIT || kit == PainPacker.KIT || kit == RipperCyclotron.KIT || kit == NenStitches.KIT || kit == Blinky.KIT || kit == LaplaceDevil.KIT || kit == MagicalEsthetician.KIT || kit == SmokeManipulation.KIT || kit == CrazySlots.KIT || kit == LittleFlower.KIT || kit == BigBangImpact.KIT) base = basicSet(c); // same basics as the other Ren kits
        return ChainAbilities.extend(base, c);
    }

    /** Attack / Strong attack / Barrage (HxHAdventure's own getRenSet). Ten and Ren have their own keybinds. */
    private static String[] basicSet(Combat c) {
        List<String> list = new ArrayList<>();
        list.add("nen_attack");
        list.add("nen_strong");
        list.add("nen_barrage");
        return list.toArray(new String[0]);
    }
}
