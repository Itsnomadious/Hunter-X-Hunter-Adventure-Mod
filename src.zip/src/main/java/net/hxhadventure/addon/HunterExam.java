package net.hxhadventure.addon;

import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketExamOpen;
import net.hxhadventure.addon.network.PacketExamResult;
import net.hxhadventure.addon.network.PacketExamStage;
import net.hxhadventure.entity.custom.KiteEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/**
 * Server side of the Hunter Exam: the first test (Satotz's questionnaire) and the start of the second, final one (Menchi, see {@link ExamBattle}).
 *
 * <p>Satotz never says whether an answer is right. The client sends all its answers at the end (plus the moves it made in the water puzzle),
 * the server grades them against {@link #KEY}, and only the verdict (passed or not) goes back. Passing is stored on the player ({@link #PASSED_KEY}).
 */
public final class HunterExam {
    public static final int KIND_RECEPTIONIST = 0;
    public static final int KIND_MENCHI = 1;
    public static final int KIND_SATOTZ = 2;

    /** Persistent player flag: the first test (Satotz's questionnaire) has been passed. */
    public static final String PASSED_KEY = "hxh_exam_first_test_passed";

    /** Persistent player flag: the second test (Menchi's free-for-all) has been passed. */
    public static final String SECOND_PASSED_KEY = "hxh_exam_second_test_passed";

    /** Persistent player flag: the player holds a Hunter licence (granted with the second, final test). The Hunter card UI reads this. */
    public static final String LICENSE_KEY = "hxh_hunter_license";

    /** Correct answers out of the 10 questions needed to pass (the 10th is the water puzzle). */
    public static final int PASS_MARK = 8;

    /** How close to Satotz the player must still be when the answers arrive. */
    private static final double MAX_DISTANCE = 12.0;

    /** Answer key for questions 1 to 9: the index of the right option (0 = A, 1 = B, 2 = C, 3 = D). */
    private static final int[] KEY = {2, 1, 1, 1, 1, 2, 1, 2, 2};

    private HunterExam() {}

    /** Exam stages: 0 = not started, 1 = first test passed, 2 = in between (kept for further tests), 3 = completed (Hunter card). */
    public static final int STAGE_DONE = 3;

    /** Persistent player value: the stage above. The three flags above are kept in step with it. */
    public static final String STAGE_KEY = "hxh_exam_stage";

    private static CompoundTag persisted(Player p) {
        return p.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
    }

    /** The player's exam stage (0 to 3). Worlds saved before stages existed are read from the old flags. */
    public static int stage(Player p) {
        CompoundTag t = persisted(p);
        if (t.contains(STAGE_KEY)) return Math.max(0, Math.min(STAGE_DONE, t.getInt(STAGE_KEY)));
        if (t.getBoolean(SECOND_PASSED_KEY) || t.getBoolean(LICENSE_KEY)) return STAGE_DONE;
        return t.getBoolean(PASSED_KEY) ? 1 : 0;
    }

    /** Sets the stage (also from /hxh exam stage), keeps the flags in step and tells the player's client. */
    public static void setStage(ServerPlayer p, int stage) {
        int st = Math.max(0, Math.min(STAGE_DONE, stage));
        CompoundTag t = persisted(p);
        t.putInt(STAGE_KEY, st);
        t.putBoolean(PASSED_KEY, st >= 1);
        t.putBoolean(SECOND_PASSED_KEY, st >= STAGE_DONE);
        t.putBoolean(LICENSE_KEY, st >= STAGE_DONE);
        p.getPersistentData().put(Player.PERSISTED_NBT_TAG, t);
        sync(p);
    }

    /** Sends the stage to the player's client (login, and whenever it changes). The Hunter License menu is only used from stage 3. */
    public static void sync(ServerPlayer p) {
        AddonNetwork.sendToPlayer(new PacketExamStage(stage(p)), p);
    }

    public static boolean hasPassed(Player p) {
        return stage(p) >= 1;
    }

    public static boolean hasPassedSecond(Player p) {
        return stage(p) >= STAGE_DONE;
    }

    /** True once the player has received their Hunter card (the final test is done). */
    public static boolean hasLicense(Player p) {
        return stage(p) >= STAGE_DONE;
    }

    /** The final test is passed: remembers it and hands over the Hunter card. */
    public static void grantLicense(ServerPlayer p) {
        setStage(p, STAGE_DONE);
    }

    private static void setPassed(ServerPlayer p) {
        if (stage(p) < 1) setStage(p, 1);
    }

    /** The player right-clicked an exam NPC: open its dialogue on their screen. */
    public static void open(ServerPlayer sp, ExamNpcEntity npc) {
        // after the final test Menchi has something to say depending on whether Nen is awakened: the nearest Kite is looked up for her
        boolean awakened = sp.getPersistentData().getBoolean("HxHCraft_NenUnlocked");
        BlockPos kite = null;
        if (npc.examKind() == KIND_MENCHI && hasPassedSecond(sp) && !awakened) kite = nearestKite(sp);
        AddonNetwork.sendToPlayer(new PacketExamOpen(npc.getId(), npc.examKind(), hasPassed(sp), hasPassedSecond(sp), ExamBattle.isActive(sp.getUUID()),
            awakened, kite != null, kite == null ? 0 : kite.getX(), kite == null ? 0 : kite.getY(), kite == null ? 0 : kite.getZ()), sp);
    }

    /** Where the nearest (loaded) Kite NPC in the player's dimension stands, or null. */
    private static BlockPos nearestKite(ServerPlayer sp) {
        if (!(sp.level() instanceof ServerLevel sl)) return null;
        KiteEntity best = null;
        for (KiteEntity k : sl.getEntities(EntityTypeTest.forClass(KiteEntity.class), KiteEntity::isAlive)) {
            if (best == null || k.distanceToSqr(sp) < best.distanceToSqr(sp)) best = k;
        }
        return best == null ? null : best.blockPosition();
    }

    /** The player accepted Menchi's test: the test takers spawn. Everything is checked again here. */
    public static void startSecond(ServerPlayer sp, int npcId) {
        Entity e = sp.level().getEntity(npcId);
        if (!(e instanceof MenchiEntity menchi) || !menchi.isAlive() || menchi.distanceTo(sp) > MAX_DISTANCE) {
            return;
        }
        if (!hasPassed(sp) || hasPassedSecond(sp) || ExamBattle.isActive(sp.getUUID())) {
            return;
        }
        ExamBattle.begin(sp, menchi);
    }

    /** The player finished the questionnaire. Everything is checked again here. */
    public static void submit(ServerPlayer sp, int npcId, byte[] answers, byte[] moves) {
        Entity e = sp.level().getEntity(npcId);
        if (!(e instanceof SatotzEntity satotz) || !satotz.isAlive() || satotz.distanceTo(sp) > MAX_DISTANCE) {
            return;
        }
        if (hasPassed(sp)) {
            AddonNetwork.sendToPlayer(new PacketExamResult(true), sp);
            return;
        }
        int score = 0;
        for (int i = 0; i < KEY.length; i++) {
            if (answers != null && i < answers.length && answers[i] == KEY[i]) score++;
        }
        if (WaterPuzzle.verify(moves)) score++;
        boolean passed = score >= PASS_MARK;
        if (passed) setPassed(sp);
        AddonNetwork.sendToPlayer(new PacketExamResult(passed), sp);
    }
}
