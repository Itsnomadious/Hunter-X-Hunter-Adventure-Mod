package net.hxhadventure.addon;

import java.util.Random;
import net.hxhadventure.abilities.Combat;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import org.jetbrains.annotations.Nullable;

/**
 * Killua (NPC): Transmuter, level 65, the weakest of the group but the fastest. His Hatsu is Lightning Aura, run the way a player runs it:
 * Lightning Palm (charge, then a strike, 0.2 s stun), Thunderbolt (a 5 block leap and a bolt called down where he looks, 0.2 s stun) and
 * Godspeed with Whirlwind (a huge speed boost, a moderate damage boost, no Ren, 80% dodge that drops 10% per dodge and resets on a hit;
 * the palm becomes a long dash with a harder hit and a 1 s stun). Lightning Aura users are immune to the stun (tag {@link LightningAura#TAG}).
 */
public class KilluaEntity extends NenFighter {
    public static final NpcStats STATS = new NpcStats("killua", Combat.NEN_TRANSMUTATION)
        .levels(65, 65, 65, 62)
        .body(110.0, 0.33, 0.3, 0.8f)
        .melee(1.0f, 2.4)
        .look("light_blueaura_ten", 0xE6E0F0, 0x4FC3F7);

    private static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.45f, 0.75f, 1.0f), 1.0f);
    private static final Random RND = new Random();

    /** Godspeed's palm stun is 1 s for Killua (the player's is longer). */
    private static final int GODSPEED_STUN_TICKS = 20;

    private boolean godspeed;
    private double dodgeChance = Tuning.WHIRLWIND_CHANCE;
    private int palmReady, boltReady, dashReady, godspeedReady;
    private int windup = -1;      // Lightning Palm charge so far, -1 = none
    private int leap = -1;        // Thunderbolt ticks in the air, -1 = none
    private int noFallTicks;      // fall protection after a dash / leap

    public KilluaEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, STATS);
        addTag(LightningAura.TAG); // Lightning Aura users are immune to its stun
    }

    @Override
    public boolean causeFallDamage(float dist, float mult, DamageSource src) {
        if (noFallTicks > 0 || leap >= 0 || godspeed) return false;
        return super.causeFallDamage(dist, mult, src);
    }

    // ---------------------------------------------------------------- hooks into the base

    @Override
    protected boolean hatsuBusy() { return windup >= 0; }

    @Override
    protected boolean renForbidden() { return godspeed; }

    @Override
    protected float extraOutgoingMult(@Nullable DamageSource src) { return godspeed ? Tuning.GODSPEED_DAMAGE_MULT : 1.0f; }

    @Override
    protected float extraSpeedBonus() { return godspeed ? (float) Tuning.GODSPEED_SPEED : 0.0f; }

    @Override
    protected void onFightEnd() {
        windup = -1;
        leap = -1;
        godspeedOff();
    }

    @Override
    protected void onAuraGone() {
        windup = -1;
        godspeedOff();
    }

    /** Whirlwind: while Godspeed is on an attack is dodged with 80%; every dodge lowers it by 10%, a hit that lands resets it. */
    @Override
    public boolean negatesHit(DamageSource src, float amount) {
        if (!godspeed || src.getEntity() == null) return false;
        if (RND.nextDouble() < dodgeChance) {
            dodgeChance = Math.max(0.0, dodgeChance - Tuning.WHIRLWIND_STEP);
            if (level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1, getZ(), 14, 0.4, 0.6, 0.4, 0.4);
                sl.playSound(null, blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 0.5f, 2.0f);
            }
            return true;
        }
        dodgeChance = Tuning.WHIRLWIND_CHANCE;
        return false;
    }

    // ---------------------------------------------------------------- the Hatsu

    @Override
    protected void tickHatsu(@Nullable LivingEntity t, boolean fighting) {
        if (noFallTicks > 0 && onGround()) noFallTicks--;
        if (!(level() instanceof ServerLevel sl)) return;
        if (!fighting || t == null) {
            if (godspeed) godspeedOff();
            return;
        }
        tickGodspeed(sl);
        if (windup >= 0) {
            tickWindup(sl, t);
            return;
        }
        if (leap >= 0) {
            tickLeap(sl, t);
            return;
        }
        double d = distanceTo(t);
        boolean los = hasLineOfSight(t);

        // Godspeed when the fight is on and the pool allows (Ren and Godspeed exclude each other, so he picks it over a burst)
        if (!godspeed && tickCount >= godspeedReady && d < 30.0 && auraFraction() > 0.30f && canAfford(Tuning.GODSPEED_START_COST)
            && (lastHitAge() < 60 || d < 14.0) && payAura(Tuning.GODSPEED_START_COST)) {
            godspeed = true;
            dodgeChance = Tuning.WHIRLWIND_CHANCE;
            sl.playSound(null, blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.HOSTILE, 0.6f, 2.0f);
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1, getZ(), 30, 0.4, 0.8, 0.4, 0.5);
        }

        if (godspeed) {
            if (los && d > 3.5 && d < 16.0 && tickCount >= dashReady && payAura(Tuning.GPALM_COST)) {
                godspeedDash(sl, t);
                return;
            }
        } else if (los) {
            if (d <= Tuning.LPALM_RANGE - 0.4 && tickCount >= palmReady && payAura(Tuning.LPALM_COST)) {
                palmReady = tickCount + Tuning.LPALM_COOLDOWN_TICKS;
                windup = 0;
                return;
            }
            if (d > 5.0 && d < 28.0 && onGround() && tickCount >= boltReady && payAura(Tuning.BOLT_COST)) {
                boltReady = tickCount + Tuning.BOLT_COOLDOWN_TICKS;
                startLeap(sl, t);
                return;
            }
        }
        if (godspeed && d < 3.5 && tickCount >= palmReady && los) {
            // in close the dash would overshoot: the ordinary punches (with Godspeed's boost) do the work
        }
    }

    // ---------------------------------------------------------------- Lightning Palm

    private void tickWindup(ServerLevel sl, LivingEntity t) {
        windup++;
        getNavigation().stop();
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1.0, getZ(), 2, 0.3, 0.4, 0.3, 0.1);
        if (windup >= Tuning.LPALM_WINDUP_TICKS) {
            windup = -1;
            strike(sl);
        }
    }

    private void strike(ServerLevel sl) {
        swingArm();
        Vec3 eye = getEyePosition();
        Vec3 dir = getLookAngle().normalize();
        Vec3 tip = eye.add(dir.scale(1.2)).add(0, -0.35, 0);
        sl.playSound(null, blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 0.5f, 2.0f);
        sl.playSound(null, blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, 1.0f, 1.5f);
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, tip.x, tip.y, tip.z, 18, 0.3, 0.3, 0.3, 0.35);
        setDeltaMovement(getDeltaMovement().add(dir.x * 0.45, 0, dir.z * 0.45)); // a short lunge with the strike
        hurtMarked = true;
        float amount = (Tuning.LPALM_BASE_DAMAGE + STATS.hatsu * Tuning.LPALM_DAMAGE_PER_LEVEL) * Affinity.projectile(nenType);
        AABB box = new AABB(eye, eye.add(dir.scale(Tuning.LPALM_RANGE))).inflate(1.2);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, box, this::isFoe)) {
            Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(eye);
            double dd = to.length();
            if (dd > Tuning.LPALM_RANGE + e.getBbWidth() * 0.5 || to.normalize().dot(dir) < 0.55) continue;
            if (dd < bestDist) {
                bestDist = dd;
                best = e;
            }
        }
        if (best == null) return;
        hatsuHurt(best, damageSources().mobAttack(this), amount);
        HatsuEffects.stun(best, Tuning.LPALM_STUN_TICKS);
        Vec3 at = best.position().add(0, best.getBbHeight() * 0.5, 0);
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 30, 0.35, 0.5, 0.35, 0.4);
        sl.sendParticles(BLUE, at.x, at.y, at.z, 14, 0.3, 0.5, 0.3, 0.0);
    }

    // ---------------------------------------------------------------- Godspeed palm: a long dash and a harder hit

    private void godspeedDash(ServerLevel sl, LivingEntity t) {
        dashReady = tickCount + Tuning.GPALM_COOLDOWN_TICKS;
        swingArm();
        Vec3 to = t.position().add(0, t.getBbHeight() * 0.5, 0).subtract(position().add(0, getBbHeight() * 0.5, 0));
        double dist = to.length();
        Vec3 look = to.normalize();
        double travel = Math.min(Tuning.GPALM_DASH_SPEED * 2.0, dist + 1.5);
        Vec3 dash = look.scale(travel);
        Vec3 from = position();
        Vec3 side = new Vec3(-look.z, 0, look.x).normalize().scale(0.45);
        for (double s = 0; s <= travel; s += 0.3) {
            Vec3 p = from.add(look.scale(s));
            sl.sendParticles(HxHParticles.KILLUA_LIGHTNING.get(), p.x + side.x, p.y + 0.9, p.z + side.z, 1, 0.05, 0.05, 0.05, 0.01);
            sl.sendParticles(HxHParticles.KILLUA_LIGHTNING.get(), p.x - side.x, p.y + 0.9, p.z - side.z, 1, 0.05, 0.05, 0.05, 0.01);
        }
        float amount = (Tuning.GPALM_BASE_DAMAGE + STATS.hatsu * Tuning.GPALM_DAMAGE_PER_LEVEL) * Affinity.projectile(nenType);
        AABB box = getBoundingBox().expandTowards(dash).inflate(Tuning.GPALM_HIT_RADIUS);
        boolean hit = false;
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, box, this::isFoe)) {
            e.invulnerableTime = 0;
            hatsuHurt(e, damageSources().mobAttack(this), amount);
            HatsuEffects.stun(e, GODSPEED_STUN_TICKS); // 1 s
            e.setDeltaMovement(Vec3.ZERO);
            e.hurtMarked = true;
            Vec3 at = e.position().add(0, e.getBbHeight() * 0.5, 0);
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 30, 0.5, 0.6, 0.5, 0.4);
            sl.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0, 0, 0, 0);
            hit = true;
        }
        noFallTicks = 40;
        // the rush itself: one burst of velocity along the look direction (ground drag carries it about 2.2x)
        double v = Math.min(3.0, Math.max(0.5, (hit ? Math.max(0.0, dist - 1.2) : travel) / 2.2));
        setDeltaMovement(look.x * v, Math.max(0.0, look.y * v) * 0.5, look.z * v);
        hurtMarked = true;
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.TRIDENT_THUNDER, SoundSource.HOSTILE, 1.3f, 1.5f);
    }

    // ---------------------------------------------------------------- Thunderbolt

    private void startLeap(ServerLevel sl, LivingEntity t) {
        swingArm();
        Vec3 flat = new Vec3(t.getX() - getX(), 0, t.getZ() - getZ()).normalize();
        setDeltaMovement(flat.x * Tuning.BOLT_LEAP_FORWARD, Tuning.BOLT_LEAP_SPEED, flat.z * Tuning.BOLT_LEAP_FORWARD);
        hurtMarked = true;
        leap = 0;
        noFallTicks = 40;
        getNavigation().stop();
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.2, getZ(), 25, 0.4, 0.1, 0.4, 0.3);
        sl.playSound(null, blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.HOSTILE, 0.6f, 1.8f);
    }

    private void tickLeap(ServerLevel sl, LivingEntity t) {
        leap++;
        fallDistance = 0;
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.5, getZ(), 3, 0.3, 0.4, 0.3, 0.15);
        boolean apex = getDeltaMovement().y <= 0.05 && leap >= 4;
        if (apex || leap >= Tuning.BOLT_MAX_AIR_TICKS) {
            leap = -1;
            callBolt(sl, t);
        }
    }

    /** The bolt falls where he is looking: on the target (or where it stands now). */
    private void callBolt(ServerLevel sl, LivingEntity t) {
        Vec3 p = t.position();
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sl);
        if (bolt != null) {
            bolt.moveTo(p.x, p.y, p.z);
            bolt.setVisualOnly(true); // looks and sounds like a strike: no fire, no damage of its own
            sl.addFreshEntity(bolt);
        }
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y + 0.3, p.z, 40, 0.8, 0.5, 0.8, 0.5);
        sl.sendParticles(BLUE, p.x, p.y + 0.3, p.z, 20, 0.7, 0.4, 0.7, 0.0);
        float amount = (Tuning.BOLT_BASE_DAMAGE + STATS.hatsu * Tuning.BOLT_DAMAGE_PER_LEVEL) * Affinity.projectile(nenType);
        AABB box = new AABB(p, p).inflate(Tuning.BOLT_RADIUS, Tuning.BOLT_RADIUS + 1.0, Tuning.BOLT_RADIUS);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, box, this::isFoe)) {
            if (e.position().distanceTo(p) > Tuning.BOLT_RADIUS + e.getBbWidth() * 0.5 + 0.5) continue;
            hatsuHurt(e, damageSources().mobAttack(this), amount);
            HatsuEffects.stun(e, Tuning.BOLT_STUN_TICKS);
        }
    }

    // ---------------------------------------------------------------- Godspeed upkeep and look

    private void tickGodspeed(ServerLevel sl) {
        if (!godspeed) return;
        if (!canUseNen() || auraFraction() < 0.10f) {
            godspeedOff();
            return;
        }
        drainAura(Tuning.GODSPEED_UPKEEP / 20f);
        double w = getBbWidth() * 0.6, h = getBbHeight();
        sl.sendParticles(HxHParticles.KILLUA_LIGHTNING.get(), getX(), getY() + h * 0.5, getZ(), 3, w, h * 0.45, w, 0.01);
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + h * 0.5, getZ(), 2, w, h * 0.45, w, 0.25);
        sl.sendParticles(BLUE, getX(), getY() + h * 0.5, getZ(), 2, w, h * 0.45, w, 0.0);
        if (tickCount % 100 == 0) sl.playSound(null, blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.HOSTILE, 0.1f, 2.0f);
    }

    private void godspeedOff() {
        if (!godspeed) return;
        godspeed = false;
        dodgeChance = Tuning.WHIRLWIND_CHANCE;
        godspeedReady = tickCount + 100; // a pause before he can switch it on again
    }
}
