package net.hxhadventure.addon;

/**
 * How each aura form looks. Every form is drawn with the Ten aura (the same Ten texture and the same skin-hugging glow
 * as plain Ten, which is the 1.0 reference), just sized and tinted per body zone:
 *  - size:  1.0 = exactly Ten's size, up to {@link #MAX_SIZE} (125% of Ten); 0 = that zone is not drawn
 *  - power: 0 = as faint as Ten, 1 = the deepest colour (layered, much less transparent). The targeted zone of a form is the strong one
 *
 * Zones: right arm, left arm, torso (torso + head), legs. No client imports, so server and client can both read it.
 */
public enum AuraForm {
    NONE(zone(0f, 0f), zone(0f, 0f), zone(0f, 0f), zone(0f, 0f)),
    /** A slightly bigger, fuller Ten over the whole body. */
    KEN(zone(1.1f, 0.75f), zone(1.1f, 0.75f), zone(1.1f, 0.75f), zone(1.1f, 0.75f)),
    /** All the aura in one limb: only the right arm, slightly bigger than Ten and the deepest colour. */
    KO(zone(1.15f, 1.0f), zone(0f, 0f), zone(0f, 0f), zone(0f, 0f));

    /** No zone may be drawn bigger than this multiple of the Ten aura. */
    public static final float MAX_SIZE = 1.25f;

    public record Zone(float size, float power) {}

    private static Zone zone(float size, float power) {
        return new Zone(Math.min(MAX_SIZE, size), power);
    }

    public final Zone rightArm, leftArm, torso, legs;

    AuraForm(Zone rightArm, Zone leftArm, Zone torso, Zone legs) {
        this.rightArm = rightArm;
        this.leftArm = leftArm;
        this.torso = torso;
        this.legs = legs;
    }

    public static AuraForm byId(int id) {
        AuraForm[] v = values();
        return id >= 0 && id < v.length ? v[id] : NONE;
    }

    /** The form for the current Ken / Ko state. */
    public static AuraForm of(boolean ken, boolean ko) {
        if (ko) return KO;
        if (ken) return KEN;
        return NONE;
    }
}
