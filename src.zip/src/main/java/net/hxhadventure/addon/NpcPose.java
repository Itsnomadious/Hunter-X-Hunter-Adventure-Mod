package net.hxhadventure.addon;

/** An NPC drawn with the player model that can hold its right arm out in front of it (Kite and Hina during their rituals). */
public interface NpcPose {
    boolean armsOut();

    /** Both arms straight out to the sides (Neferpitou while Terpsichora is dancing). */
    default boolean tPose() {
        return false;
    }

    /** Cookie's service stance: 0 = standing, 1 = kneeling behind someone doing their hair, 2 = kneeling beside someone giving a massage. */
    default int stance() {
        return 0;
    }
}
