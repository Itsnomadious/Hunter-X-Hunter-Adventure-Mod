package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * What every Smoky Jail dome of one dimension replaced, saved with the world so the terrain always comes back (even after a restart).
 * A dome loaded from disk is always an ending one: the smoke does not survive a reload.
 */
public class SmokeJailData extends SavedData {
    public static final String ID = "hxh_smoke_jails";

    public static final class Jail {
        public final UUID id;
        public UUID owner;
        public BlockPos center = BlockPos.ZERO;
        public long expire;
        public boolean ending;
        /** Block position (as long) -> what stood there before the smoke, in the order the smoke was put up. */
        public final Map<Long, BlockState> replaced = new LinkedHashMap<>();
        /** Positions still to be filled (not saved). */
        public List<Long> queue = new ArrayList<>();
        public int queueIndex;

        public Jail(UUID id) {
            this.id = id;
        }
    }

    public final Map<UUID, Jail> jails = new LinkedHashMap<>();

    public static SmokeJailData load(CompoundTag tag) {
        SmokeJailData d = new SmokeJailData();
        ListTag list = tag.getList("Jails", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            if (!t.hasUUID("Id")) continue;
            Jail j = new Jail(t.getUUID("Id"));
            if (t.hasUUID("Owner")) j.owner = t.getUUID("Owner");
            j.center = new BlockPos(t.getInt("X"), t.getInt("Y"), t.getInt("Z"));
            j.ending = true; // the dome does not survive a reload
            ListTag paletteTag = t.getList("Palette", Tag.TAG_COMPOUND);
            List<BlockState> palette = new ArrayList<>();
            for (int p = 0; p < paletteTag.size(); p++) {
                palette.add(NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), paletteTag.getCompound(p)));
            }
            long[] keys = t.getLongArray("Keys");
            int[] idx = t.getIntArray("Idx");
            for (int k = 0; k < keys.length && k < idx.length; k++) {
                if (idx[k] >= 0 && idx[k] < palette.size()) j.replaced.put(keys[k], palette.get(idx[k]));
            }
            d.jails.put(j.id, j);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Jail j : jails.values()) {
            CompoundTag t = new CompoundTag();
            t.putUUID("Id", j.id);
            if (j.owner != null) t.putUUID("Owner", j.owner);
            t.putInt("X", j.center.getX());
            t.putInt("Y", j.center.getY());
            t.putInt("Z", j.center.getZ());
            List<BlockState> palette = new ArrayList<>();
            Map<BlockState, Integer> index = new java.util.HashMap<>();
            long[] keys = new long[j.replaced.size()];
            int[] idx = new int[j.replaced.size()];
            int n = 0;
            for (Map.Entry<Long, BlockState> e : j.replaced.entrySet()) {
                Integer at = index.get(e.getValue());
                if (at == null) {
                    at = palette.size();
                    palette.add(e.getValue());
                    index.put(e.getValue(), at);
                }
                keys[n] = e.getKey();
                idx[n] = at;
                n++;
            }
            ListTag paletteTag = new ListTag();
            for (BlockState s : palette) paletteTag.add(NbtUtils.writeBlockState(s));
            t.put("Palette", paletteTag);
            t.putLongArray("Keys", keys);
            t.putIntArray("Idx", idx);
            list.add(t);
        }
        tag.put("Jails", list);
        return tag;
    }
}
