package net.hxhadventure.addon;

import net.minecraft.world.level.GameRules;
import net.minecraftforge.fml.common.Mod;

/**
 * Game rules (all off by default). This class is registered as an event subscriber only so that it is loaded, and the rules
 * registered, when the mod starts.
 * <ul>
 * <li>{@code /gamerule hxhNenTypeChanceEqual true}: every Nen type equally likely (1/6) when a player awakens.</li>
 * <li>{@code /gamerule hxhrarenencolours true}: white can no longer be rolled; every other colour is equally likely (1/19 each).</li>
 * <li>{@code /gamerule hxhtalented true}: Common can no longer be rolled; the other seven talents are equally likely (1/7 each).</li>
 * <li>{@code /gamerule hxhnentypeselect true}: Water Divination lets the player pick their Nen type (once) instead of revealing the one they were given.</li>
 * <li>{@code /gamerule hxhgrateful true}: the 100-Type Guanyin and its moves are enlightened at once (as if 10000 prayers followed by an attack were done).</li>
 * </ul>
 */
@Mod.EventBusSubscriber(modid = "hxhadventure")
public final class NenGameRules {
    private NenGameRules() {}

    /**
     * The "Hunter x Hunter" heading in the game rules screen (lang key gamerule.category.hxh). GameRules.Category is a plain enum with
     * no public way to add to it, so one extra constant is built by hand. If that ever fails the rules just sit under Player.
     */
    public static final GameRules.Category CATEGORY = makeCategory();

    private static GameRules.Category makeCategory() {
        try {
            java.lang.reflect.Field uf = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
            uf.setAccessible(true);
            sun.misc.Unsafe u = (sun.misc.Unsafe) uf.get(null);
            GameRules.Category cat = (GameRules.Category) u.allocateInstance(GameRules.Category.class);
            u.putObject(cat, u.objectFieldOffset(Enum.class.getDeclaredField("name")), "HXH");
            u.putInt(cat, u.objectFieldOffset(Enum.class.getDeclaredField("ordinal")), GameRules.Category.values().length);
            for (java.lang.reflect.Field f : GameRules.Category.class.getDeclaredFields()) {
                if (f.getType() == String.class && !java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                    u.putObject(cat, u.objectFieldOffset(f), "gamerule.category.hxh");
                }
            }
            return cat;
        } catch (Throwable t) {
            return GameRules.Category.PLAYER;
        }
    }

    public static final GameRules.Key<GameRules.BooleanValue> EQUAL_TYPE_CHANCE =
        GameRules.register("hxhNenTypeChanceEqual", CATEGORY, GameRules.BooleanValue.create(false));

    public static final GameRules.Key<GameRules.BooleanValue> RARE_COLOURS =
        GameRules.register("hxhrarenencolours", CATEGORY, GameRules.BooleanValue.create(false));

    public static final GameRules.Key<GameRules.BooleanValue> TALENTED =
        GameRules.register("hxhtalented", CATEGORY, GameRules.BooleanValue.create(false));

    public static final GameRules.Key<GameRules.BooleanValue> NEN_TYPE_SELECT =
        GameRules.register("hxhnentypeselect", CATEGORY, GameRules.BooleanValue.create(false));

    public static final GameRules.Key<GameRules.BooleanValue> GRATEFUL =
        GameRules.register("hxhgrateful", CATEGORY, GameRules.BooleanValue.create(false));
}
