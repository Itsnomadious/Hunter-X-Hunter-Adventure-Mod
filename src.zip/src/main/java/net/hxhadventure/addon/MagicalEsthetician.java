package net.hxhadventure.addon;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketEstheticianFx;

/**
 * Biscuit Krueger's Magical Esthetician (Hatsu kit 27, a Transmuter's).
 * <ul>
 *   <li><b>Magical Esthetician</b> (Z): summons Cookie, an NPC masseuse, in front of the user. Using the skill again sends her away.
 *       Right-click Cookie to choose a service:
 *       <ul>
 *         <li><b>Magical Spa Services</b>: the user sits, Cookie kneels behind them and grooms their hair. Gives <b>Spa Afterglow</b> for 30 minutes:
 *             +10% damage and durability, +0.1% for every Hatsu level.</li>
 *         <li><b>Piano Massage</b>: the user lies face down, Cookie kneels beside them and gives a massage. Gives <b>Piano Massage</b> for 30 minutes:
 *             +25% aura regeneration, +0.1% for every Hatsu level.</li>
 *       </ul></li>
 *   <li><b>Body Transformation</b> (H, held 2 s to switch on or off, like Gon's vow): the user grows and gains +50% damage and durability, +20% speed and
 *       +20% maximum aura. Lasts 10 minutes, then (or when switched off early) a 120 s cooldown.</li>
 * </ul>
 * The server decides everything; clients are told what to draw through {@link PacketEstheticianFx}. Forge hooks: {@link EstheticianEvents}.
 */
public final class MagicalEsthetician {
    private MagicalEsthetician() {}

    public static final int KIT = 27;
    public static final String ID = "magical_esthetician";
    public static final int SERVICE_SPA = 1, SERVICE_PIANO = 2;
    public static final int POSE_NONE = 0, POSE_SIT = 1, POSE_LIE = 2;

    private static final UUID SPEED_ID = UUID.fromString("c00c1e00-5a1b-4c7e-9b2d-0b15c0c1e022");

    // ---------------------------------------------------------------- state
    /** One service in progress: the owner is held in place while Cookie works. */
    private static final class Session {
        final int service;
        final UUID cookie;
        final Vec3 anchor;
        final float yaw;
        final int total;
        int ticks;

        Session(int service, UUID cookie, Vec3 anchor, float yaw) {
            this.service = service;
            this.cookie = cookie;
            this.anchor = anchor;
            this.yaw = yaw;
            this.total = service == SERVICE_SPA ? EstheticianTuning.SPA_TICKS : EstheticianTuning.PIANO_TICKS;
        }
    }

    private static final Map<UUID, UUID> COOKIES = new ConcurrentHashMap<>();   // owner -> Cookie's entity uuid
    private static final Map<UUID, Session> SESSIONS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> SUMMON_READY = new ConcurrentHashMap<>();
    private static final Set<UUID> FORM = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Long> FORM_END = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> FORM_READY = new ConcurrentHashMap<>();

    /** Client side: entity ids of players in the form, and {pose, yaw} of players being served (kept up to date by PacketEstheticianFx). */
    private static final Set<Integer> CLIENT_FORM = ConcurrentHashMap.newKeySet();
    private static final Map<Integer, float[]> CLIENT_POSE = new ConcurrentHashMap<>();

    // ---------------------------------------------------------------- who and what
    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    private static boolean kitOk(Player p) {
        return p instanceof ServerPlayer && canUse(Combat.get(p));
    }

    public static boolean ownsCookie(UUID owner, UUID cookie) {
        return cookie.equals(COOKIES.get(owner));
    }

    /** Lets an NPC (Bisky) own a Cookie so CookieEntity's safety net does not remove her. */
    public static void registerNpcCookie(UUID owner, UUID cookie) {
        COOKIES.put(owner, cookie);
    }

    public static void unregisterNpcCookie(UUID owner) {
        COOKIES.remove(owner);
    }

    public static boolean inService(Player p) {
        return p != null && SESSIONS.containsKey(p.getUUID());
    }

    /** Is this player in Body Transformation? Works on both sides (the client reads its synced copy). */
    public static boolean isForm(Entity e) {
        if (!(e instanceof Player p) || p.level() == null) return false;
        return p.level().isClientSide ? CLIENT_FORM.contains(p.getId()) : FORM.contains(p.getUUID());
    }

    /** POSE_SIT / POSE_LIE while this player is being served, else POSE_NONE. Works on both sides. */
    public static int pose(Entity e) {
        if (!(e instanceof Player p) || p.level() == null) return POSE_NONE;
        if (p.level().isClientSide) {
            float[] f = CLIENT_POSE.get(p.getId());
            return f == null ? POSE_NONE : (int) f[0];
        }
        Session s = SESSIONS.get(p.getUUID());
        return s == null ? POSE_NONE : (s.service == SERVICE_SPA ? POSE_SIT : POSE_LIE);
    }

    /** Client side only: the facing the player was served in. */
    public static float clientPoseYaw(int entityId) {
        float[] f = CLIENT_POSE.get(entityId);
        return f == null ? 0f : f[1];
    }

    public static void setClientForm(int entityId, boolean on) {
        if (on) CLIENT_FORM.add(entityId);
        else CLIENT_FORM.remove(entityId);
    }

    public static boolean clientHasForm(int entityId) {
        return CLIENT_FORM.contains(entityId);
    }

    public static void setClientPose(int entityId, int pose, float yaw) {
        if (pose == POSE_NONE) CLIENT_POSE.remove(entityId);
        else CLIENT_POSE.put(entityId, new float[] {pose, yaw});
    }

    public static void clearClient() {
        CLIENT_FORM.clear();
        CLIENT_POSE.clear();
    }

    // ---------------------------------------------------------------- numbers other code reads
    private static int hatsuLevel(Player p) {
        Combat c = Combat.get(p);
        return c == null ? 1 : c.getHatsuLevel();
    }

    /** Spa Afterglow's bonus (0.10 = +10%): the base plus a little for every Hatsu level. */
    public static float spaBonus(Player p) {
        return EstheticianTuning.SPA_BASE + EstheticianTuning.SPA_PER_LEVEL * hatsuLevel(p);
    }

    /** Piano Massage's bonus (0.25 = +25%). */
    public static float pianoBonus(Player p) {
        return EstheticianTuning.PIANO_BASE + EstheticianTuning.PIANO_PER_LEVEL * hatsuLevel(p);
    }

    /** Damage dealt multiplier: Spa Afterglow and Body Transformation (1.0 when neither is on). */
    public static float damageMult(Player p) {
        float m = 1f;
        if (isForm(p)) m *= EstheticianTuning.TRANSFORM_DAMAGE_MULT;
        if (kitOk(p) && EstheticianEffects.hasSpa(p)) m *= 1f + spaBonus(p);
        return m;
    }

    /** Durability multiplier: damage taken is divided by it. */
    public static float durabilityMult(Player p) {
        float m = 1f;
        if (isForm(p)) m *= EstheticianTuning.TRANSFORM_DURABILITY_MULT;
        if (kitOk(p) && EstheticianEffects.hasSpa(p)) m *= 1f + spaBonus(p);
        return m;
    }

    /** Aura regeneration multiplier (Piano Massage). Used by every place that regenerates aura. */
    public static float regenMult(Player p) {
        if (p != null && kitOk(p) && EstheticianEffects.hasPiano(p)) return 1f + pianoBonus(p);
        return 1f;
    }

    /** Maximum aura multiplier (Body Transformation). Read by Combat.getMaxEnergy on both sides. */
    public static float maxAuraMult(Player p) {
        return isForm(p) ? EstheticianTuning.TRANSFORM_AURA_MULT : 1f;
    }

    // ---------------------------------------------------------------- the Z list
    /** Adds the entry to the Z list once the Hatsu level allows it. */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < EstheticianTuning.MIN_LEVEL) return base;
        String[] out = Arrays.copyOf(base, base.length + 1);
        out[out.length - 1] = ID;
        return out;
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(ID, MagicalEsthetician::useCookie);
    }

    public static String displayName(String id) {
        return ID.equals(id) ? "\u00a7d Magical Esthetician" : null;
    }

    // ---------------------------------------------------------------- helpers
    private static void msg(ServerPlayer sp, String text) {
        sp.displayClientMessage(Component.literal(text), true);
    }

    private static Combat gate(ServerPlayer sp, int minLevel, String name) {
        Combat c = Combat.get(sp);
        if (c == null) return null;
        if (!canUse(c)) {
            msg(sp, "\u00a7cYour Hatsu is not Magical Esthetician");
            return null;
        }
        if (c.getHatsuLevel() < minLevel) {
            msg(sp, "\u00a7c" + name + " unlocks at Level " + minLevel);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            msg(sp, "\u00a75Forced Zetsu: your aura will not answer");
            return null;
        }
        if (HatsuEffects.isStunned(sp)) return null;
        return c;
    }

    private static boolean ready(ServerPlayer sp, Map<UUID, Long> map, String name, long now) {
        long at = map.getOrDefault(sp.getUUID(), 0L);
        return !ChainManager.onCooldown(sp, name, (int) Math.max(0, at - now));
    }

    private static float yawOf(double dx, double dz) {
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    private static Vec3 facing(float yaw) {
        double r = Math.toRadians(yaw);
        return new Vec3(-Math.sin(r), 0, Math.cos(r));
    }

    /** The player's right-hand side for a given facing. */
    private static Vec3 rightOf(float yaw) {
        double r = Math.toRadians(yaw);
        return new Vec3(-Math.cos(r), 0, -Math.sin(r));
    }

    private static CookieEntity cookieOf(ServerPlayer sp) {
        UUID id = COOKIES.get(sp.getUUID());
        if (id == null || !(sp.level() instanceof ServerLevel level)) return null;
        Entity e = level.getEntity(id);
        return e instanceof CookieEntity c && c.isAlive() ? c : null;
    }

    // ---------------------------------------------------------------- Z: Magical Esthetician (call Cookie, or send her away)
    public static void useCookie(ServerPlayer sp) {
        Combat c = gate(sp, EstheticianTuning.MIN_LEVEL, "Magical Esthetician");
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;

        if (COOKIES.containsKey(sp.getUUID())) { // she is out: the skill sends her away
            dismiss(sp, "\u00a7dCookie \u00a77waves goodbye and disappears");
            return;
        }
        if (!ready(sp, SUMMON_READY, "Magical Esthetician", level.getGameTime())) return;
        if (c.getCurrentEnergy() < EstheticianTuning.SUMMON_COST) {
            msg(sp, "\u00a7cNot enough energy");
            return;
        }
        c.consumeEnergy(EstheticianTuning.SUMMON_COST);

        Vec3 look = facing(sp.getYRot());
        Vec3 at = spotNear(level, sp, look);
        CookieEntity cookie = new CookieEntity(HxHEntities.COOKIE.get(), level);
        cookie.setOwner(sp.getUUID());
        cookie.moveTo(at.x, at.y, at.z, yawOf(-look.x, -look.z), 0f); // she faces the one who called her
        cookie.setYHeadRot(cookie.getYRot());
        cookie.setYBodyRot(cookie.getYRot());
        level.addFreshEntity(cookie);
        COOKIES.put(sp.getUUID(), cookie.getUUID());
        SUMMON_READY.put(sp.getUUID(), level.getGameTime() + EstheticianTuning.SUMMON_COOLDOWN_TICKS);

        level.sendParticles(ParticleTypes.HEART, at.x, at.y + 1.6, at.z, 8, 0.4, 0.4, 0.4, 0.0);
        level.sendParticles(ParticleTypes.END_ROD, at.x, at.y + 1.0, at.z, 20, 0.35, 0.8, 0.35, 0.05);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0f, 1.4f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6f, 1.8f);
        msg(sp, "\u00a7dCookie \u00a77is here: right-click her for a service");
    }

    /** A free, solid spot in front of the user (falls back to beside them, then to their own spot). */
    private static Vec3 spotNear(ServerLevel level, ServerPlayer sp, Vec3 look) {
        Vec3 right = rightOf(sp.getYRot());
        Vec3[] tries = {
            look.scale(EstheticianTuning.SUMMON_DISTANCE), right.scale(EstheticianTuning.SUMMON_DISTANCE),
            right.scale(-EstheticianTuning.SUMMON_DISTANCE), look.scale(-EstheticianTuning.SUMMON_DISTANCE)
        };
        for (Vec3 off : tries) {
            Vec3 p = sp.position().add(off);
            BlockPos feet = BlockPos.containing(p);
            if (level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()
                && level.getBlockState(feet.above()).getCollisionShape(level, feet.above()).isEmpty()
                && !level.getBlockState(feet.below()).getCollisionShape(level, feet.below()).isEmpty()) {
                return new Vec3(p.x, feet.getY(), p.z);
            }
        }
        return sp.position().add(look.scale(0.6));
    }

    /** Sends Cookie away: ends any service in progress (with no buff), removes her, and tells the owner. */
    public static void dismiss(ServerPlayer sp, String message) {
        UUID id = COOKIES.remove(sp.getUUID());
        endSession(sp, false);
        if (id != null && sp.level() instanceof ServerLevel level) {
            Entity e = level.getEntity(id);
            if (e != null) {
                level.sendParticles(ParticleTypes.HEART, e.getX(), e.getY() + 1.6, e.getZ(), 6, 0.4, 0.4, 0.4, 0.0);
                level.sendParticles(ParticleTypes.POOF, e.getX(), e.getY() + 0.9, e.getZ(), 14, 0.3, 0.6, 0.3, 0.03);
                level.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0f, 1.2f);
                e.discard();
            }
        }
        if (message != null) msg(sp, message);
    }

    // ---------------------------------------------------------------- the two services
    /** The owner picked a service in Cookie's menu. Everything is checked again here. */
    public static void startService(ServerPlayer sp, int cookieId, int service) {
        if (service != SERVICE_SPA && service != SERVICE_PIANO) return;
        if (!(sp.level() instanceof ServerLevel level)) return;
        Entity e = level.getEntity(cookieId);
        if (!(e instanceof CookieEntity cookie) || !cookie.isAlive() || !ownsCookie(sp.getUUID(), cookie.getUUID())) return;
        if (SESSIONS.containsKey(sp.getUUID())) return;
        if (cookie.distanceTo(sp) > EstheticianTuning.SERVICE_MAX_DISTANCE) {
            msg(sp, "\u00a7cYou are too far from Cookie");
            return;
        }
        Combat c = gate(sp, EstheticianTuning.MIN_LEVEL, "Magical Esthetician");
        if (c == null) return;
        if (ChainManager.isJailed(sp) || !sp.onGround() || sp.isPassenger() || sp.isInWaterOrBubble() || sp.isFallFlying()) {
            msg(sp, "\u00a7cYou need to be standing on solid ground");
            return;
        }
        if (isForm(sp)) {
            msg(sp, "\u00a7cCookie cannot work on you while you are this big");
            return;
        }
        if (c.getCurrentEnergy() < EstheticianTuning.SERVICE_COST) {
            msg(sp, "\u00a7cNot enough energy");
            return;
        }
        NenAddonData d = NenAddonData.get(sp);
        d.leaveZetsuForHatsu(sp);
        c.consumeEnergy(EstheticianTuning.SERVICE_COST);

        Vec3 anchor = sp.position();
        float yaw = sp.getYRot();
        Session s = new Session(service, cookie.getUUID(), anchor, yaw);
        SESSIONS.put(sp.getUUID(), s);

        // where Cookie kneels
        Vec3 spot;
        float cookieYaw;
        if (service == SERVICE_SPA) {
            Vec3 f = facing(yaw);
            spot = anchor.subtract(f.scale(EstheticianTuning.SPA_BEHIND)); // behind them, looking at the back of their head
            cookieYaw = yaw;
        } else {
            Vec3 f = facing(yaw), r = rightOf(yaw);
            spot = anchor.add(r.scale(EstheticianTuning.PIANO_BESIDE)).add(f.scale(EstheticianTuning.PIANO_ALONG)); // beside them, facing them
            cookieYaw = yawOf(-r.x, -r.z);
        }
        cookie.getNavigation().stop();
        cookie.setNoAi(true);
        cookie.teleportTo(spot.x, anchor.y, spot.z);
        cookie.setYRot(cookieYaw);
        cookie.setYHeadRot(cookieYaw);
        cookie.setYBodyRot(cookieYaw);
        cookie.setStance(service);

        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, s.total + 20, 9, false, false, false));
        sp.setSprinting(false);
        sp.setYBodyRot(yaw);
        sp.refreshDimensions();
        AddonNetwork.sendToTrackingAndSelf(PacketEstheticianFx.pose(sp.getId(), service == SERVICE_SPA ? POSE_SIT : POSE_LIE, yaw), sp);
        level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 0.8f, 1.2f);
        msg(sp, service == SERVICE_SPA ? "\u00a7dMagical Spa Services \u00a77(stay still)" : "\u00a7dPiano Massage \u00a77(stay still)");
    }

    private static final int[] PENTATONIC = {0, 2, 4, 7, 9, 12, 14, 16};

    private static void tickSession(ServerPlayer sp, ServerLevel level, Session s) {
        Entity ce = level.getEntity(s.cookie);
        if (!sp.isAlive() || !(ce instanceof CookieEntity cookie) || !cookie.isAlive()
            || ExtrasHooks.hatsuForced(sp) || !canUse(Combat.get(sp))) {
            endSession(sp, false);
            msg(sp, "\u00a77The service is interrupted");
            return;
        }
        s.ticks++;

        // the owner is held in place
        Vec3 v = sp.getDeltaMovement();
        sp.setDeltaMovement(0, Math.min(0, v.y), 0);
        sp.hurtMarked = true;
        sp.setSprinting(false);
        sp.setYBodyRot(s.yaw);
        if (sp.position().distanceToSqr(s.anchor) > 0.25) sp.connection.teleport(s.anchor.x, s.anchor.y, s.anchor.z, sp.getYRot(), sp.getXRot());

        // Cookie stays where she knelt
        cookie.getNavigation().stop();

        double hx = s.anchor.x, hz = s.anchor.z;
        if (s.service == SERVICE_SPA) {
            Vec3 f = facing(s.yaw);
            if (s.ticks % 4 == 0) {
                level.sendParticles(ParticleTypes.END_ROD, hx - f.x * 0.2, s.anchor.y + 1.0, hz - f.z * 0.2, 1, 0.25, 0.2, 0.25, 0.01);
            }
            if (s.ticks % 20 == 0) level.sendParticles(ParticleTypes.HEART, hx, s.anchor.y + 1.5, hz, 1, 0.2, 0.1, 0.2, 0.0);
            if (s.ticks % 30 == 0) level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.6f, 1.4f + level.random.nextFloat() * 0.4f);
        } else {
            if (s.ticks % 10 == 0) {
                int note = PENTATONIC[level.random.nextInt(PENTATONIC.length)];
                float pitch = (float) Math.pow(2.0, (note - 12) / 12.0);
                level.playSound(null, sp.blockPosition(), SoundEvents.NOTE_BLOCK_HARP.value(), SoundSource.PLAYERS, 0.8f, pitch);
                level.sendParticles(ParticleTypes.NOTE, hx, s.anchor.y + 0.9, hz, 1, 0.5, 0.2, 0.5, note / 24.0);
            }
        }

        if (s.ticks >= s.total) finishService(sp, level, s);
    }

    private static void finishService(ServerPlayer sp, ServerLevel level, Session s) {
        int service = s.service;
        endSession(sp, true);
        if (service == SERVICE_SPA) {
            EstheticianEffects.applySpa(sp, EstheticianTuning.BUFF_TICKS);
            int pct = Math.round(spaBonus(sp) * 1000f);
            sp.sendSystemMessage(Component.literal("\u00a7d[Cookie] \u00a7fAll done! Spa Afterglow: +" + (pct / 10f) + "% damage and durability for 30 minutes."));
            level.sendParticles(ParticleTypes.HEART, sp.getX(), sp.getY() + 1.6, sp.getZ(), 10, 0.4, 0.3, 0.4, 0.0);
        } else {
            EstheticianEffects.applyPiano(sp, EstheticianTuning.BUFF_TICKS);
            int pct = Math.round(pianoBonus(sp) * 1000f);
            sp.sendSystemMessage(Component.literal("\u00a7d[Cookie] \u00a7fAll done! Piano Massage: +" + (pct / 10f) + "% aura regeneration for 30 minutes."));
            level.sendParticles(ParticleTypes.NOTE, sp.getX(), sp.getY() + 1.6, sp.getZ(), 8, 0.4, 0.3, 0.4, 0.5);
        }
        level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8f, 1.6f);
    }

    /** The service is over (finished or interrupted): the owner stands up, Cookie stands up. */
    private static void endSession(ServerPlayer sp, boolean finished) {
        Session s = SESSIONS.remove(sp.getUUID());
        if (s == null) return;
        sp.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        sp.refreshDimensions();
        AddonNetwork.sendToTrackingAndSelf(PacketEstheticianFx.pose(sp.getId(), POSE_NONE, 0f), sp);
        if (sp.level() instanceof ServerLevel level && level.getEntity(s.cookie) instanceof CookieEntity cookie) {
            cookie.setStance(0);
            cookie.setNoAi(false);
        }
    }

    /** The owner was hurt: a service in progress is interrupted (called from EstheticianEvents). */
    public static void interrupt(ServerPlayer sp) {
        if (!SESSIONS.containsKey(sp.getUUID())) return;
        endSession(sp, false);
        msg(sp, "\u00a77The service is interrupted");
    }

    // ---------------------------------------------------------------- H: Body Transformation
    /** H, held for 2 seconds (the client does the waiting): switch the form on, or off again. */
    public static void toggleForm(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c)) return;
        if (FORM.contains(sp.getUUID())) {
            endForm(sp, "\u00a77Body Transformation: you return to normal", true);
            return;
        }
        c = gate(sp, EstheticianTuning.TRANSFORM_MIN_LEVEL, "Body Transformation");
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        if (!ready(sp, FORM_READY, "Body Transformation", level.getGameTime())) return;
        if (SESSIONS.containsKey(sp.getUUID())) {
            msg(sp, "\u00a7cWait until Cookie is done");
            return;
        }
        if (c.getCurrentEnergy() < EstheticianTuning.TRANSFORM_COST) {
            msg(sp, "\u00a7cNot enough energy");
            return;
        }
        c.consumeEnergy(EstheticianTuning.TRANSFORM_COST);

        float before = c.getCurrentEnergy();
        FORM.add(sp.getUUID());
        FORM_END.put(sp.getUUID(), level.getGameTime() + EstheticianTuning.TRANSFORM_TICKS);
        c.restoreEnergy(before * (EstheticianTuning.TRANSFORM_AURA_MULT - 1f)); // the tank is bigger now, so what was in it grows too
        applySpeed(sp, true);
        sp.refreshDimensions();
        AddonNetwork.sendToTrackingAndSelf(PacketEstheticianFx.form(sp.getId(), true), sp);
        level.playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.2f, 1.2f);
        level.sendParticles(ParticleTypes.HEART, sp.getX(), sp.getY() + 1.4, sp.getZ(), 14, 0.5, 0.8, 0.5, 0.0);
        level.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1.0, sp.getZ(), 30, 0.5, 0.9, 0.5, 0.12);
        msg(sp, "\u00a7dBody Transformation");
    }

    /** The form ends, however it ended: the stats go, the cooldown starts. */
    private static void endForm(ServerPlayer sp, String message, boolean cooldown) {
        if (!FORM.remove(sp.getUUID())) return;
        FORM_END.remove(sp.getUUID());
        applySpeed(sp, false);
        Combat c = Combat.get(sp);
        if (c != null && sp.isAlive()) {
            float cur = c.getCurrentEnergy();
            c.consumeEnergy(cur - cur / EstheticianTuning.TRANSFORM_AURA_MULT);
        }
        sp.refreshDimensions();
        AddonNetwork.sendToTrackingAndSelf(PacketEstheticianFx.form(sp.getId(), false), sp);
        if (cooldown) {
            long now = sp.level().getGameTime();
            FORM_READY.put(sp.getUUID(), now + EstheticianTuning.TRANSFORM_COOLDOWN_TICKS);
            ChainManager.startCooldown(sp, "Body Transformation", EstheticianTuning.TRANSFORM_COOLDOWN_TICKS);
        }
        if (message != null) msg(sp, message);
    }

    private static void applySpeed(ServerPlayer sp, boolean on) {
        AttributeInstance inst = sp.getAttribute(Attributes.MOVEMENT_SPEED);
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(SPEED_ID);
        if (on && cur == null) {
            inst.addTransientModifier(new AttributeModifier(SPEED_ID, "Body Transformation speed",
                EstheticianTuning.TRANSFORM_SPEED_BONUS, AttributeModifier.Operation.MULTIPLY_TOTAL));
        } else if (!on && cur != null) {
            inst.removeModifier(SPEED_ID);
        }
    }

    // ---------------------------------------------------------------- per tick
    public static void tick(ServerPlayer sp) {
        UUID id = sp.getUUID();
        Combat c = Combat.get(sp);
        if (!canUse(c)) {
            if (COOKIES.containsKey(id) || SESSIONS.containsKey(id) || FORM.contains(id)) clear(sp);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;

        // Cookie goes if her owner leaves the dimension or wanders too far away
        if (COOKIES.containsKey(id)) {
            CookieEntity cookie = cookieOf(sp);
            if (cookie == null) {
                COOKIES.remove(id);
                endSession(sp, false);
            } else if (!SESSIONS.containsKey(id) && cookie.distanceToSqr(sp) > EstheticianTuning.COOKIE_MAX_DISTANCE * EstheticianTuning.COOKIE_MAX_DISTANCE) {
                dismiss(sp, "\u00a7dCookie \u00a77waited, then went home");
            }
        }
        Session s = SESSIONS.get(id);
        if (s != null) tickSession(sp, level, s);

        if (FORM.contains(id)) {
            if (ExtrasHooks.hatsuForced(sp)) {
                endForm(sp, "\u00a75Forced Zetsu: your body shrinks back", true);
                return;
            }
            if (level.getGameTime() >= FORM_END.getOrDefault(id, Long.MAX_VALUE)) {
                endForm(sp, "\u00a77Body Transformation wears off", true);
                return;
            }
            applySpeed(sp, true); // keeps it on if something else cleared the modifiers
            if (sp.tickCount % 200 == 0) {
                long left = (FORM_END.getOrDefault(id, 0L) - level.getGameTime()) / 20;
                if (left <= 60) msg(sp, "\u00a7dBody Transformation: " + left + "s left");
            }
        }
    }

    /** A player who comes into view of someone being served or transformed sees it at once. */
    public static void sendTo(ServerPlayer owner, ServerPlayer viewer) {
        UUID id = owner.getUUID();
        if (FORM.contains(id)) AddonNetwork.sendToPlayer(PacketEstheticianFx.form(owner.getId(), true), viewer);
        Session s = SESSIONS.get(id);
        if (s != null) AddonNetwork.sendToPlayer(PacketEstheticianFx.pose(owner.getId(), s.service == SERVICE_SPA ? POSE_SIT : POSE_LIE, s.yaw), viewer);
    }

    /** Death, logout, a new Hatsu or lost Nen: Cookie goes, the form ends, the buffs are gone. */
    public static void clear(Player p) {
        UUID id = p.getUUID();
        if (p instanceof ServerPlayer sp) {
            boolean had = COOKIES.containsKey(id) || SESSIONS.containsKey(id);
            if (had) dismiss(sp, null);
            if (FORM.contains(id)) endForm(sp, null, false); // dying, logging out or changing Hatsu leaves no cooldown behind
            EstheticianEffects.removeAll(sp);
        } else {
            COOKIES.remove(id);
            SESSIONS.remove(id);
            FORM.remove(id);
        }
        COOKIES.remove(id);
        SESSIONS.remove(id);
        FORM.remove(id);
        FORM_END.remove(id);
        FORM_READY.remove(id);
        SUMMON_READY.remove(id);
    }

    /** The server stopped: nothing carries over to the next world. */
    public static void reset() {
        COOKIES.clear();
        SESSIONS.clear();
        FORM.clear();
        FORM_END.clear();
        FORM_READY.clear();
        SUMMON_READY.clear();
    }
}
