package net.hxhadventure.addon;

/** Numbers for Kalluto's Paper Manipulation (Hatsu kit 18). Change them here. */
public final class PaperTuning {
    private PaperTuning() {}


    // ---- Dance of the Serpent's Bite ----
    public static final int SERPENT_MIN_LEVEL = 10;

    /** Z with nothing in the air: drop the confetti. */
    public static final float DROP_COST = 60f;
    public static final int DROP_COOLDOWN_TICKS = 15;
    /** How long dropped paper stays in the air if you never use it, ticks. */
    public static final int CLOUD_LIFETIME_TICKS = 1200;
    /** Waves one batch of paper can send out. */
    public static final int WAVES_PER_BATCH = 3;

    /** Z with paper in the air: wave the fan. */
    public static final float WAVE_COST = 40f;
    public static final int WAVE_COOLDOWN_TICKS = 8;
    public static final double WAVE_RANGE = 30.0;          // blocks
    public static final double WAVE_WIDTH = 1.1;           // how far from the line an enemy can be and still be caught, blocks
    public static final double WAVE_SPEED = 3.5;           // blocks per tick the paper travels
    public static final float WAVE_BASE_DAMAGE = 6f;
    public static final float WAVE_DAMAGE_PER_LEVEL = 0.12f;

    /** How long a paper mark lasts, ticks; every hit on the marked enemy renews it. */
    public static final int MARK_TICKS = 600;

    /** Shift+Z on a marked enemy: drop another batch and ready the swarm. */
    public static final float PRIME_COST = 80f;
    public static final int PRIME_COOLDOWN_TICKS = 15;

    /** Z with the swarm readied: the massive wave and the vortex. */
    public static final float SWARM_COST = 250f;
    public static final int SWARM_COOLDOWN_TICKS = 160;    // starts when the vortex ends
    public static final int SWARM_TICKS = 60;              // 3 seconds
    public static final int SWARM_HIT_EVERY_TICKS = 5;     // 12 hits over the 3 seconds
    public static final float SWARM_HIT_DAMAGE = 12f;
    public static final float SWARM_DAMAGE_PER_LEVEL = 0.15f;

    /** The Shift+Z swarm's wave: a wide, slow wall of paper that hurts everything it sweeps over. */
    public static final double SWARM_WAVE_SPEED = 0.6;     // blocks per tick (the plain wave is 3.5)
    public static final double SWARM_WAVE_RADIUS = 7.0;    // how far from the line an enemy is still caught, blocks
    public static final float SWARM_WAVE_BASE_DAMAGE = 30f;
    public static final float SWARM_WAVE_DAMAGE_PER_LEVEL = 0.45f;
    /** Confetti per block of travel: raise for an even thicker storm. */
    public static final int SWARM_WAVE_CONFETTI = 260;
    /** The vortex also shreds everyone this close to the marked enemy, for this share of the hit. */
    public static final double SWARM_VORTEX_AOE = 6.0;
    public static final float SWARM_AOE_SHARE = 0.6f;
}
