package net.hxhadventure.addon;

/** Numbers for Morel Mackernasey's Smoke Manipulation (Hatsu kit 28). Change them here. */
public final class SmokeTuning {
    private SmokeTuning() {}

    // ---- Deep Purple (Z: smoke monsters, Shift+Z: clones of the user) ----
    public static final int DEEP_PURPLE_MIN_LEVEL = 10;
    public static final float DEEP_PURPLE_COST = 150f;
    /** 30 seconds. Shared by the monsters and the clones. */
    public static final int DEEP_PURPLE_COOLDOWN_TICKS = 600;
    /** Smoke monsters (or clones) per cast. */
    public static final int GROUP_SIZE = 20;
    /** The user blows smoke for this long before the group steps out of it. */
    public static final int BLOW_TICKS = 24;
    /** The group crouches beside the user for this long after it appears, then goes to work. */
    public static final int CROUCH_TICKS = 24;
    /** How long a group lasts. */
    public static final int MINION_LIFETIME_TICKS = 1200;
    /** Most live minions one user can have; the oldest dissolve first. */
    public static final int MAX_MINIONS = 60;
    /** Ring around the user the group appears in, blocks. */
    public static final double SPAWN_RADIUS_MIN = 2.0, SPAWN_RADIUS_MAX = 4.5;

    // ---- The stats a smoke monster has; a clone has exactly the same ----
    public static final double MINION_BASE_HEALTH = 20.0;
    public static final double MINION_HEALTH_PER_LEVEL = 0.2;
    public static final double MINION_BASE_DAMAGE = 3.0;
    public static final double MINION_DAMAGE_PER_LEVEL = 0.06;
    /** Mob movement speed (a zombie walks at 0.23). */
    public static final double MINION_SPEED = 0.30;
    public static final double MINION_ARMOR = 2.0;
    public static final double MINION_FOLLOW_RANGE = 32.0;
    /** They come back to the user when farther than this; they teleport to the user when farther than the second number. */
    public static final double FOLLOW_START = 9.0, TELEPORT_DISTANCE = 32.0;
    /** Hostile mobs this close to a minion are attacked without being told to. */
    public static final double AGGRO_RANGE = 12.0;

    // ---- Smoky Jail ----
    public static final int JAIL_MIN_LEVEL = 25;
    public static final float JAIL_COST = 350f;
    /** Radius of the dome, blocks. */
    public static final int JAIL_RADIUS = 20;
    /** The dome stays this long (60 s) unless the user ends it with Z again. */
    public static final int JAIL_DURATION_TICKS = 1200;
    /** Counted from the cast (120 s). */
    public static final int JAIL_COOLDOWN_TICKS = 2400;
    /** Smoke blocks put up / taken down per tick. About 4000 blocks, so the dome grows in a couple of seconds. */
    public static final int JAIL_BUILD_PER_TICK = 220;
    public static final int JAIL_CLEAR_PER_TICK = 320;
}
