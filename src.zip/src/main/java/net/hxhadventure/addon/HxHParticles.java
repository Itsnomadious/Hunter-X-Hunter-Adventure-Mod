package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** The addon's particle types (registered from HxHAdventure's constructor). Sprites: assets/hxhadventure/particles + textures/particle. */
public final class HxHParticles {
    private HxHParticles() {}

    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, HxHAdventure.MOD_ID);

    /** The small blue-white lightning crackle of Lightning Aura (Godspeed's aura, the Godspeed palm's trail and hits). */
    public static final RegistryObject<SimpleParticleType> KILLUA_LIGHTNING = PARTICLES.register("killua_lightning", () -> new SimpleParticleType(false));
}
