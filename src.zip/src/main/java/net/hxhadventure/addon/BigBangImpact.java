package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketRockFx;
import net.hxhadventure.entity.ModEntities;
import net.hxhadventure.entity.custom.AuraEntity;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Uvogin's Big Bang Impact (Hatsu kit 31, Enhancers).
 *
 * <ol>
 *   <li><b>Flare and focus:</b> press Z on its entry in the list and keep HOLDING Z. It starts exactly like Jajanken's Rock: a max-size Ren
 *       flare shrinks to nothing, then all the aura converges on the fist and Ko is switched on for real
 *       ({@link BigBangImpactTuning#KO_ENFORCED}). Letting go before the aura is fully in the fist scatters it and costs nothing.</li>
 *   <li><b>Z (pressed normally): the blast.</b> Release to throw the punch: a fully focused Rock (x{@link BigBangImpactTuning#DAMAGE_MULT}) whose
 *       blast destroys every block within {@link BigBangImpactTuning#BLAST_RADIUS} blocks of where the fist lands and shocks the creatures there.</li>
 *   <li><b>Shift+Z (Shift held when Z is pressed): the ground punch.</b> The same focus, but the fist goes into the ground and a ripple runs
 *       {@link BigBangImpactTuning#RIPPLE_LENGTH} blocks ahead in an opening cone, tearing up the ground and stunning every creature it
 *       catches on the ground for {@link BigBangImpactTuning#RIPPLE_STUN_TICKS} ticks.</li>
 * </ol>
 * The look of the charge and of the punch is Jajanken's Rock (same {@link PacketRockFx}), so clients need nothing of their own. The blast
 * is {@link Jajanken#strike} with a bigger radius; the ripple is run here, a slice of the cone every tick ({@link #tickRipples}).
 * Forge hooks live in {@link BigBangImpactEvents}.
 */
public final class BigBangImpact {
    private BigBangImpact() {}

    public static final int KIT = 31;
    public static final String ID = "big_bang_impact";
    private static final String NAME = "Big Bang Impact";

    /** Setting blocks to air: 2 = tell clients, 16 = no shape updates, 32 = no drops (a cone of hundreds of blocks must not spawn items). */
    private static final int BREAK_FLAGS = 2 | 16 | 32;
    private static final int NO_GROUND = Integer.MIN_VALUE;
    /** The ripple starts this far in front of the user, where the fist goes into the ground. */
    private static final double RIPPLE_AHEAD = 1.0;

    private static final class Focus {
        /** Shift was held when Z was pressed: the punch goes into the ground. */
        boolean ground;
        /** Game time of the press, and of the moment the focus itself starts (press + flare). */
        long pressed, start;
        boolean release;
        NenAddonData.AuraSnapshot saved;
        AuraEntity flare;
    }

    /** A ripple on its way: it covers {@link BigBangImpactTuning#RIPPLE_SPEED} more blocks of its cone every tick. */
    private static final class Ripple {
        ServerLevel level;
        UUID owner;
        double ox, oz, dx, dz;
        /** Feet height of the user when the fist went in: the ripple follows the ground within a few blocks of it. */
        int baseY;
        double travelled;
        final Set<UUID> hit = new HashSet<>();
    }

    private static final Map<UUID, Focus> FOCUSING = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> READY_AT = new ConcurrentHashMap<>();
    /** Players whose Z key is down right now, as last reported by the client. */
    private static final Set<UUID> Z_DOWN = ConcurrentHashMap.newKeySet();
    private static final List<Ripple> RIPPLES = new ArrayList<>();

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    public static boolean isFocusing(Player p) {
        return p != null && FOCUSING.containsKey(p.getUUID());
    }

    /** Adds the entry to the Z list once the Hatsu level allows it (runs on the client too, so the menu shows it). */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < BigBangImpactTuning.MIN_LEVEL) return base;
        String[] out = Arrays.copyOf(base, base.length + 1);
        out[out.length - 1] = ID;
        return out;
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(ID, BigBangImpact::begin);
    }

    public static String displayName(String id) {
        return ID.equals(id) ? "§6 Big Bang Impact" : null;
    }

    // ---------------------------------------------------------------- Z pressed: the flare

    public static void begin(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("§cYour Hatsu is not " + NAME), true);
            return;
        }
        if (c.getHatsuLevel() < BigBangImpactTuning.MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("§c" + NAME + " unlocks at Level " + BigBangImpactTuning.MIN_LEVEL), true);
            return;
        }
        if (FOCUSING.containsKey(sp.getUUID())) return;
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("§5Forced Zetsu: your aura will not answer"), true);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        if (ChainManager.onCooldown(sp, NAME, (int) Math.max(0, READY_AT.getOrDefault(sp.getUUID(), 0L) - now))) return;
        if (c.getCurrentEnergy() < BigBangImpactTuning.COST) {
            sp.displayClientMessage(Component.literal("§cNot enough energy"), true);
            return;
        }
        NenAddonData d = NenAddonData.get(sp);
        Focus f = new Focus();
        f.ground = sp.isShiftKeyDown(); // Shift+Z: decided at the press
        f.pressed = now;
        f.start = now + BigBangImpactTuning.FLARE_TICKS;
        f.saved = d.snapshotAura(c);    // what to go back to
        d.clearForRockFlare(sp);        // Ren / Zetsu / forms off: the flare is the only aura out
        f.flare = spawnFlare(sp, level);
        FOCUSING.put(sp.getUUID(), f);
        Prayer.chargeBegan(sp, ID, f.saved); // Ko / root limitations start on the press
        AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 1, Jajanken.ROCK, 0, 0, 0, 0, 0), sp);
        level.playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 0.5f);
        level.sendParticles(ParticleTypes.FLASH, sp.getX(), sp.getY() + 1.0, sp.getZ(), 1, 0, 0, 0, 0.0);
    }

    /** From PacketZHold: Z went down or up. Letting go throws the punch. */
    public static void setZHeld(ServerPlayer sp, boolean held) {
        if (held) {
            Z_DOWN.add(sp.getUUID());
        } else {
            Z_DOWN.remove(sp.getUUID());
            Focus f = FOCUSING.get(sp.getUUID());
            if (f != null) f.release = true;
        }
    }

    // ---------------------------------------------------------------- per tick (player)

    public static void tick(ServerPlayer sp) {
        Focus f = FOCUSING.get(sp.getUUID());
        if (f == null) return;
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || !sp.isAlive() || ExtrasHooks.hatsuForced(sp) || !(sp.level() instanceof ServerLevel level)) {
            end(sp);
            return;
        }
        long now = level.getGameTime();
        long elapsed = now - f.start; // negative while the flare is still shrinking
        // a missed key-up (or a press whose hold packet never came) must not leave the aura focusing for ever
        if (!f.release && now - f.pressed >= 4 && !Z_DOWN.contains(sp.getUUID())) f.release = true;
        if (!f.release && elapsed > BigBangImpactTuning.FOCUS_TICKS + BigBangImpactTuning.HOLD_LIMIT_TICKS) f.release = true; // held far too long: throw it
        if (f.release) {
            FOCUSING.remove(sp.getUUID());
            if (elapsed < BigBangImpactTuning.FOCUS_TICKS) {
                cancel(sp, f, "§7" + NAME + ": the aura scattered (keep holding Z until it is all in the fist)");
                return;
            }
            punch(sp, c, level, f);
            return;
        }
        sp.setSprinting(false);
        if (elapsed < 0) { // the flare: max-size Ren shrinking to nothing
            shrinkFlare(f, now);
            return;
        }
        if (f.flare != null) { // the flare is gone: all the aura goes into the fist
            dropFlare(f);
            level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8f, 0.8f);
        }
        if (BigBangImpactTuning.KO_ENFORCED) NenAddonData.get(sp).enforceKo(sp); // held on every tick, so toggling a form or Ren mid-focus cannot break it
        if (elapsed % 5 == 0) {
            String what = f.ground ? NAME + " (ground)" : NAME;
            String bar = elapsed >= BigBangImpactTuning.FOCUS_TICKS
                ? "§6" + what + ": fully focused, release Z"
                : String.format(Locale.ROOT, "§6%s: %d%%", what, (int) (100.0 * elapsed / BigBangImpactTuning.FOCUS_TICKS));
            sp.displayClientMessage(Component.literal(bar), true);
        }
        if (elapsed == BigBangImpactTuning.FOCUS_TICKS) {
            level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.2f, 0.6f);
        }
    }

    /** The focus ends without a punch but the user is still fine (released too early, no energy): back to how they were. */
    private static void cancel(ServerPlayer sp, Focus f, String message) {
        dropFlare(f);
        AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 0, 0, 0, 0, 0, 0, 0), sp);
        NenAddonData.get(sp).restoreAura(sp, f.saved);
        sp.displayClientMessage(Component.literal(message), true);
    }

    // ---------------------------------------------------------------- the punch

    private static void punch(ServerPlayer sp, Combat c, ServerLevel level, Focus f) {
        if (c.getCurrentEnergy() < BigBangImpactTuning.COST) {
            cancel(sp, f, "§cNot enough energy");
            return;
        }
        c.consumeEnergy(BigBangImpactTuning.COST);
        long now = level.getGameTime();
        READY_AT.put(sp.getUUID(), now + BigBangImpactTuning.COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, NAME, BigBangImpactTuning.COOLDOWN_TICKS);
        sp.swing(InteractionHand.MAIN_HAND, true);
        Prayer.attackOut(sp, ID);

        if (f.ground) {
            groundPunch(sp, level);
            sp.displayClientMessage(Component.literal("§6" + NAME + ": ground ripple"), true);
        } else {
            float dmg = blast(sp, c, level);
            sp.displayClientMessage(Component.literal(String.format(Locale.ROOT, "§6%s: %.0f damage", NAME, dmg)), true);
        }

        // the hit has landed (Ko was on for every hurt event above): back to the state the user was in before the focus
        NenAddonData.get(sp).restoreAura(sp, f.saved);
        Vows.afterCharge(sp, ID);
    }

    /** Z: a fully focused Rock, x{@code DAMAGE_MULT}, with a blast {@code BLAST_RADIUS} blocks wide. Returns the damage of the hit. */
    private static float blast(ServerPlayer sp, Combat c, ServerLevel level) {
        float dmg = Jajanken.fullChargeDamage(c) * BigBangImpactTuning.DAMAGE_MULT;
        NenAddonData d = NenAddonData.peek(sp);
        if (BigBangImpactTuning.KO_ENFORCED && d != null && !d.ko) dmg *= d.koMeleeMult(); // a real Ko is already applied to the hit, so don't count it twice
        dmg *= Vows.power(sp, ID);
        // strike(): the hit itself, then the shock on everything within the radius (its share of the hit), then a crater of the same radius dug out
        // over a few ticks (nearest first, no drops, nothing tougher than ROCK_BLOCK_POWER). The big-blast branch of strike also plays the heavy sounds.
        double radiusMult = BigBangImpactTuning.BLAST_RADIUS / Jajanken.ROCK_BREAK_RADIUS;
        Jajanken.strike(sp, level, dmg, true, radiusMult, true, BigBangImpactTuning.BLAST_MAX_DEPTH);
        return dmg;
    }

    /** Shift+Z: the fist goes into the ground in front of the user and a ripple is set running along the way they face. */
    private static void groundPunch(ServerPlayer sp, ServerLevel level) {
        double rad = Math.toRadians(sp.getYRot());
        Ripple r = new Ripple();
        r.level = level;
        r.owner = sp.getUUID();
        r.dx = -Math.sin(rad); // the way the user faces, flat on the ground
        r.dz = Math.cos(rad);
        r.ox = sp.getX() + r.dx * RIPPLE_AHEAD;
        r.oz = sp.getZ() + r.dz * RIPPLE_AHEAD;
        r.baseY = sp.blockPosition().getY();
        RIPPLES.add(r);

        double y = sp.getY();
        AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 2, Jajanken.ROCK, r.ox, y, r.oz, 0, 0), sp);
        level.playSound(null, r.ox, y, r.oz, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 4.0f, 0.5f);
        level.playSound(null, r.ox, y, r.oz, SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 1.5f, 0.5f);
        level.playSound(null, r.ox, y, r.oz, SoundEvents.IRON_GOLEM_ATTACK, SoundSource.PLAYERS, 1.8f, 0.5f);
        level.sendParticles(ParticleTypes.EXPLOSION, r.ox, y + 0.2, r.oz, 2, 0.3, 0.2, 0.3, 0.0);
        level.sendParticles(ParticleTypes.FLASH, r.ox, y + 0.2, r.oz, 1, 0, 0, 0, 0.0);
    }

    // ---------------------------------------------------------------- the ripple (per server tick)

    /** Moves every ripple on by one slice of its cone. Called once per server tick (BigBangImpactEvents). */
    public static void tickRipples() {
        if (RIPPLES.isEmpty()) return;
        Iterator<Ripple> it = RIPPLES.iterator();
        while (it.hasNext()) {
            Ripple r = it.next();
            ServerPlayer owner = r.level.getServer() == null ? null : r.level.getServer().getPlayerList().getPlayer(r.owner);
            if (owner == null) { // the user logged out
                it.remove();
                continue;
            }
            double from = r.travelled;
            double to = Math.min(BigBangImpactTuning.RIPPLE_LENGTH, from + BigBangImpactTuning.RIPPLE_SPEED);
            slice(r, owner, from, to);
            r.travelled = to;
            if (to >= BigBangImpactTuning.RIPPLE_LENGTH - 1e-9) it.remove();
        }
    }

    public static void clearRipples() {
        RIPPLES.clear();
    }

    /** Half the cone's width this far from where it starts. */
    private static double halfWidth(double along) {
        return BigBangImpactTuning.RIPPLE_START_HALF_WIDTH + along * Math.tan(Math.toRadians(BigBangImpactTuning.RIPPLE_HALF_ANGLE_DEG));
    }

    /** The part of the cone between {@code from} and {@code to} blocks out: stuns what is standing in it, then tears up the ground under it. */
    private static void slice(Ripple r, ServerPlayer owner, double from, double to) {
        ServerLevel level = r.level;
        double lx = -r.dz, lz = r.dx; // unit vector across the cone
        // the slice's bounding box on the ground: its four corners
        double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, minZ = Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        for (double along : new double[] {from, to}) {
            double hw = halfWidth(along);
            for (double side : new double[] {-hw, hw}) {
                double x = r.ox + r.dx * along + lx * side, z = r.oz + r.dz * along + lz * side;
                minX = Math.min(minX, x);
                maxX = Math.max(maxX, x);
                minZ = Math.min(minZ, z);
                maxZ = Math.max(maxZ, z);
            }
        }
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        // 1. creatures first, while the ground under them is still there to measure their height by
        AABB zone = new AABB(minX - 1, r.baseY - BigBangImpactTuning.RIPPLE_DROP - 2, minZ - 1,
            maxX + 1, r.baseY + BigBangImpactTuning.RIPPLE_RISE + 3, maxZ + 1);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, zone)) {
            if (e == owner || !e.isAlive() || e.isSpectator() || e instanceof ArmorStand || AllianceUtils.isAlly(e, owner) || r.hit.contains(e.getUUID())) continue;
            double vx = e.getX() - r.ox, vz = e.getZ() - r.oz;
            double along = vx * r.dx + vz * r.dz;
            if (along < from || along >= to) continue; // it is in some other slice (or outside the cone altogether)
            if (Math.abs(vx * lx + vz * lz) > halfWidth(along) + e.getBbWidth() * 0.5) continue;
            int sy = surfaceY(level, Mth.floor(e.getX()), Mth.floor(e.getZ()), r.baseY, pos);
            if (sy == NO_GROUND) continue;
            if (e.getY() - (sy + 1) > BigBangImpactTuning.RIPPLE_AIR_CLEARANCE) continue; // it jumped the ripple
            r.hit.add(e.getUUID());
            HatsuEffects.stun(e, BigBangImpactTuning.RIPPLE_STUN_TICKS); // Lightning Aura users are immune, as everywhere else
            level.sendParticles(ParticleTypes.CRIT, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 10, 0.3, 0.4, 0.3, 0.2);
            level.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.6f, 1.4f);
        }

        // 2. the ground: every column whose centre is in this slice of the cone
        int x0 = Mth.floor(minX) - 1, x1 = Mth.floor(maxX) + 1, z0 = Mth.floor(minZ) - 1, z1 = Mth.floor(maxZ) + 1;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                double vx = x + 0.5 - r.ox, vz = z + 0.5 - r.oz;
                double along = vx * r.dx + vz * r.dz;
                if (along < from || along >= to || Math.abs(vx * lx + vz * lz) > halfWidth(along)) continue;
                int sy = surfaceY(level, x, z, r.baseY, pos);
                if (sy != NO_GROUND) dig(level, x, z, sy, pos);
            }
        }

        // the sound of it travelling, along the middle of the cone
        double mid = (from + to) * 0.5;
        level.playSound(null, r.ox + r.dx * mid, r.baseY, r.oz + r.dz * mid, SoundEvents.STONE_BREAK, SoundSource.PLAYERS, 2.0f, 0.5f);
    }

    /**
     * The height (block y) of the ground in this column: a block you could stand on (it has a collision shape, no fluid) with free air above it,
     * within {@code RIPPLE_RISE} above and {@code RIPPLE_DROP} below the user's feet. When there are several (a ceiling, a tree's leaves) the one
     * nearest to the floor the user stood on wins, so the ripple follows the ground and not what hangs over it. NO_GROUND if there is none.
     */
    private static int surfaceY(ServerLevel level, int x, int z, int baseY, BlockPos.MutableBlockPos pos) {
        int floor = baseY - 1;
        int best = NO_GROUND, bestDist = Integer.MAX_VALUE;
        for (int y = baseY + BigBangImpactTuning.RIPPLE_RISE - 1; y >= baseY - BigBangImpactTuning.RIPPLE_DROP - 1; y--) {
            pos.set(x, y, z);
            if (!level.isInWorldBounds(pos) || !level.hasChunkAt(pos)) continue;
            BlockState st = level.getBlockState(pos);
            if (st.getCollisionShape(level, pos).isEmpty() || !st.getFluidState().isEmpty()) continue; // nothing to stand on
            pos.set(x, y + 1, z);
            BlockState above = level.getBlockState(pos);
            if (!above.getCollisionShape(level, pos).isEmpty() || !above.getFluidState().isEmpty()) continue; // covered (or under water)
            int dist = Math.abs(y - floor);
            if (dist < bestDist) { // strictly nearer: on a tie the higher one found first stays
                best = y;
                bestDist = dist;
            }
        }
        return best;
    }

    private static boolean breakable(ServerLevel level, BlockPos pos, BlockState st) {
        return !st.isAir() && st.getFluidState().isEmpty() && st.getDestroySpeed(level, pos) >= 0
            && st.getBlock().getExplosionResistance() <= Jajanken.ROCK_BLOCK_POWER;
    }

    /** Tears up one column: the loose cover on top (grass, flowers, snow) and then {@code RIPPLE_DEPTH} layers of ground, nothing dropped. */
    private static void dig(ServerLevel level, int x, int z, int surfaceY, BlockPos.MutableBlockPos pos) {
        BlockState air = Blocks.AIR.defaultBlockState();
        pos.set(x, surfaceY + 1, z);
        BlockState cover = level.getBlockState(pos);
        if (breakable(level, pos, cover)) level.setBlock(pos, air, BREAK_FLAGS); // else it would be left floating over the hole
        for (int k = 0; k < BigBangImpactTuning.RIPPLE_DEPTH; k++) {
            pos.set(x, surfaceY - k, z);
            if (!level.isInWorldBounds(pos)) break;
            BlockState st = level.getBlockState(pos);
            if (!breakable(level, pos, st)) continue;
            if (level.random.nextFloat() < 0.15f) {
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), x + 0.5, surfaceY + 1.0, z + 0.5, 3, 0.3, 0.2, 0.3, 0.1);
            }
            level.setBlock(pos, air, BREAK_FLAGS);
        }
    }

    // ---------------------------------------------------------------- the flare (the same max-size Ren aura as Jajanken's Rock)

    private static AuraEntity spawnFlare(ServerPlayer sp, ServerLevel level) {
        AuraEntity aura = new AuraEntity((EntityType<?>) ModEntities.AURA_ENTITY.get(), level);
        aura.setPos(sp.getX(), sp.getY(), sp.getZ());
        aura.setOwner(sp);
        aura.setAuraColorIndex(AbilityRegistry.getOrCreatePlayerAuraColor(sp) - 1);
        aura.setAuraType(0);
        aura.setAuraScale(Tuning.REN_MAX_SIZE);
        level.addFreshEntity(aura);
        return aura;
    }

    /** Max size -> nothing, fast at first (ease-out), then gone. */
    private static void shrinkFlare(Focus f, long now) {
        if (f.flare == null) return;
        double t = (now - f.pressed) / (double) BigBangImpactTuning.FLARE_TICKS;
        if (t >= 1.0 || !f.flare.isAlive()) {
            dropFlare(f);
            return;
        }
        double left = 1.0 - t;
        f.flare.setAuraScale(Math.max(0.02f, (float) (Tuning.REN_MAX_SIZE * left * left)));
    }

    private static void dropFlare(Focus f) {
        if (f.flare != null) {
            f.flare.discard();
            f.flare = null;
        }
    }

    // ---------------------------------------------------------------- clean-up

    /** The focus is lost without a punch (death, logout, lost the Hatsu, forced Zetsu). Nothing is restored: those causes clear the aura themselves. */
    public static void end(Player p) {
        Z_DOWN.remove(p.getUUID());
        Focus f = FOCUSING.remove(p.getUUID());
        if (f == null) return;
        dropFlare(f);
        NenAddonData d = NenAddonData.peek(p);
        if (d != null) d.dropEnforcedKo();
        if (p instanceof ServerPlayer sp) AddonNetwork.sendToTrackingAndSelf(new PacketRockFx(sp.getId(), 0, 0, 0, 0, 0, 0, 0), sp);
    }

    public static void clear(Player p) {
        end(p);
        READY_AT.remove(p.getUUID());
    }

    /** A player who comes into view of someone mid-focus sees the aura at once. */
    public static void sendTo(ServerPlayer owner, ServerPlayer viewer) {
        Focus f = FOCUSING.get(owner.getUUID());
        if (f == null) return;
        double age = owner.level().getGameTime() - f.pressed; // x carries how long ago the press was, so the viewer's timing lines up
        AddonNetwork.sendToPlayer(new PacketRockFx(owner.getId(), 1, Jajanken.ROCK, age, 0, 0, 0, 0), viewer);
    }
}
