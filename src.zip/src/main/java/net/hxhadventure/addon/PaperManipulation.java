package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketPaperFx;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Kalluto's Paper Manipulation (Hatsu kit 18, Manipulators). Needs Kalluto's Fan ({@link PaperFanItem}) for the waves.
 *
 * <p><b>Dance of the Serpent's Bite</b> (one ability on the R / Z scroll; Z does a different thing depending on what is in the air):
 * <ol>
 *   <li>Z with no paper in the air: the left arm lifts and a big batch of white paper confetti is dropped around you.</li>
 *   <li>Z with paper in the air: wave the fan (it opens itself if folded, and it must be in a hand). A serpent of paper flies out where you
 *       look, up to {@link PaperTuning#WAVE_RANGE} blocks, hurting everything in its path. The first enemy it hits is <b>marked</b> with paper.
 *       While an enemy is marked, every wave also strikes the marked enemy wherever it is (within range). One batch of paper holds
 *       {@link PaperTuning#WAVES_PER_BATCH} waves, then a new batch has to be dropped.</li>
 *   <li>Shift+Z with a marked enemy: drop another batch and ready the swarm. The next Z sends a massive wave that swarms the marked enemy
 *       in a vortex for {@link PaperTuning#SWARM_TICKS} ticks, hitting it again and again, and uses up all the paper in the air (and the mark).</li>
 * </ol>
 * All game state lives on the server (nothing to sync but arm poses, see {@link PacketPaperFx}); every visual is a vanilla particle.
 * Forge hooks live in {@link PaperEvents}.
 */
public final class PaperManipulation {
    private PaperManipulation() {}

    public static final int KIT = 18;
    public static final String SERPENT_ID = "paper_serpent";
    private static final String NAME = "Dance of the Serpent's Bite";

    private static final class Hit {
        final UUID id;
        final double dist;

        Hit(UUID id, double dist) {
            this.id = id;
            this.dist = dist;
        }
    }

    /** One stream of paper flying out: it travels {@link PaperTuning#WAVE_SPEED} blocks a tick and strikes what it reaches. */
    private static final class Stream {
        Vec3 from, dir, u, v;
        double length;
        double front;
        float phase;
        float damage;
        boolean aimed;      // fired where the user looks (the first enemy it hits gets marked), not at the mark
        boolean big;        // the swarm's launch: a wide, slow, damaging wall of paper
        double speed = PaperTuning.WAVE_SPEED;
        final List<Hit> hits = new ArrayList<>();
    }

    private static final class State {
        int cloudTicks;     // > 0 while paper hangs in the air
        int waves;          // waves left in this batch
        boolean primed;     // the swarm is readied: the next Z unleashes it
        UUID mark;
        int markTicks;
        int cd;             // short spam guard between presses
        int swarmCd;        // after a swarm
        UUID swarmTarget;
        int swarmTicks;
        float swarmDamage;
        int swarmDelay;     // ticks until the slow wave reaches the marked enemy and the vortex can start
        final List<Stream> streams = new ArrayList<>();
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    private static ParticleOptions paperParticle;

    private static ParticleOptions paper() {
        if (paperParticle == null) paperParticle = new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(Items.PAPER));
        return paperParticle;
    }

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    /** Adds the paper ability to the scroll once the Hatsu level allows it. */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < PaperTuning.SERPENT_MIN_LEVEL) return base;
        String[] out = Arrays.copyOf(base, base.length + 1);
        out[out.length - 1] = SERPENT_ID;
        return out;
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(SERPENT_ID, PaperManipulation::use);
    }

    /** The paper currently marking this enemy, whoever the user is (for hooks and other abilities). */
    public static boolean isMarked(Entity e) {
        if (e == null) return false;
        for (State s : STATES.values()) if (e.getUUID().equals(s.mark)) return true;
        return false;
    }

    private static State state(ServerPlayer sp) {
        return STATES.computeIfAbsent(sp.getUUID(), k -> new State());
    }

    private static Combat gate(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return null;
        if (!canUse(c)) {
            msg(sp, "\u00a7cYour Hatsu is not Paper Manipulation");
            return null;
        }
        if (c.getHatsuLevel() < PaperTuning.SERPENT_MIN_LEVEL) {
            msg(sp, "\u00a7c" + NAME + " unlocks at Level " + PaperTuning.SERPENT_MIN_LEVEL);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            msg(sp, "\u00a75Forced Zetsu: the paper will not answer");
            return null;
        }
        if (HatsuEffects.isStunned(sp)) return null;
        return c;
    }

    private static boolean pay(ServerPlayer sp, Combat c, float cost) {
        if (c.getCurrentEnergy() < cost) {
            msg(sp, "\u00a7cNot enough energy");
            return false;
        }
        c.consumeEnergy(cost);
        return true;
    }

    private static void msg(ServerPlayer sp, String text) {
        sp.displayClientMessage(Component.literal(text), true);
    }

    private static void sound(ServerPlayer sp, SoundEvent ev, float vol, float pitch) {
        sp.level().playSound(null, sp.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }

    private static boolean hostile(ServerPlayer sp, Entity e) {
        if (!(e instanceof LivingEntity le) || le == sp || !le.isAlive() || e instanceof ArmorStand) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        return !AllianceUtils.isAlly(e, sp);
    }

    private static float damage(ServerPlayer sp, Combat c, float base, float perLevel) {
        return (base + c.getHatsuLevel() * perLevel) * Vows.power(sp, SERPENT_ID);
    }

    private static LivingEntity markedTarget(State s, ServerLevel level) {
        if (s.mark == null) return null;
        return level.getEntity(s.mark) instanceof LivingEntity le && le.isAlive() ? le : null;
    }

    /** The hand holding the fan, opening the fan if it was folded. Null (with a message) when no fan is held. */
    private static InteractionHand takeFan(ServerPlayer sp) {
        InteractionHand hand = PaperFanItem.heldIn(sp);
        if (hand == null) {
            msg(sp, "\u00a7cHold Kalluto's Fan to send the paper");
            return null;
        }
        ItemStack fan = sp.getItemInHand(hand);
        if (!PaperFanItem.isOpen(fan)) {
            PaperFanItem.setOpen(fan, true);
            sound(sp, SoundEvents.BOOK_PAGE_TURN, 0.8f, 1.5f);
        }
        return hand;
    }

    /** Is the arm that holds the fan the left one? */
    private static boolean fanArmIsLeft(ServerPlayer sp, InteractionHand hand) {
        boolean mainIsLeft = sp.getMainArm() == HumanoidArm.LEFT;
        return hand == InteractionHand.MAIN_HAND ? mainIsLeft : !mainIsLeft;
    }

    private static void fx(ServerPlayer sp, int kind, boolean left) {
        AddonNetwork.sendToTrackingAndSelf(new PacketPaperFx(sp.getId(), kind, left), sp);
    }

    // ---------------------------------------------------------------- Z

    /** Z (and Shift+Z) on Dance of the Serpent's Bite. */
    public static void use(ServerPlayer sp) {
        Combat c = gate(sp);
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        State s = state(sp);
        if (s.swarmTicks > 0) {
            msg(sp, "\u00a77The paper is still swarming");
            return;
        }
        if (s.cd > 0) return; // a held or mashed key does not fire twice in the same moment
        if (sp.isShiftKeyDown()) {
            prime(sp, c, s, level);
        } else if (s.primed) {
            swarm(sp, c, s, level);
        } else if (s.waves <= 0) {
            drop(sp, c, s, level);
        } else {
            wave(sp, c, s, level);
        }
    }

    // ---------------------------------------------------------------- 1. the confetti

    private static void drop(ServerPlayer sp, Combat c, State s, ServerLevel level) {
        if (!pay(sp, c, PaperTuning.DROP_COST)) return;
        s.waves = PaperTuning.WAVES_PER_BATCH;
        s.cloudTicks = PaperTuning.CLOUD_LIFETIME_TICKS;
        s.cd = PaperTuning.DROP_COOLDOWN_TICKS;
        fx(sp, PacketPaperFx.DROP, true); // always the left arm
        Vec3 p = sp.position();
        level.sendParticles(paper(), p.x, p.y + 2.1, p.z, 90, 1.7, 0.7, 1.7, 0.04);
        level.sendParticles(ParticleTypes.WHITE_ASH, p.x, p.y + 1.6, p.z, 40, 1.7, 0.9, 1.7, 0.02);
        sound(sp, SoundEvents.BOOK_PAGE_TURN, 1.0f, 0.7f);
        sound(sp, SoundEvents.WOOL_PLACE, 0.8f, 1.6f);
        msg(sp, "\u00a7fPaper confetti drops \u00a77(" + s.waves + " waves)");
    }

    // ---------------------------------------------------------------- 2. the waves and the mark

    private static void wave(ServerPlayer sp, Combat c, State s, ServerLevel level) {
        InteractionHand hand = takeFan(sp);
        if (hand == null) return;
        if (!pay(sp, c, PaperTuning.WAVE_COST)) return;
        s.waves--;
        s.cd = PaperTuning.WAVE_COOLDOWN_TICKS;
        float dmg = damage(sp, c, PaperTuning.WAVE_BASE_DAMAGE, PaperTuning.WAVE_DAMAGE_PER_LEVEL);

        Vec3 look = sp.getLookAngle().normalize();
        Vec3 origin = sp.getEyePosition().add(look.scale(0.6)).add(0, -0.4, 0);

        // 1) where the user is looking
        Stream aimed = aimStream(sp, level, origin, look, dmg);
        s.streams.add(aimed);

        // 2) the marked enemy as well, wherever it is
        LivingEntity target = markedTarget(s, level);
        if (target != null) {
            Vec3 to = target.getBoundingBox().getCenter();
            double dist = to.distanceTo(origin);
            if (dist <= PaperTuning.WAVE_RANGE && dist > 0.01) {
                Stream homing = makeStream(origin, to.subtract(origin).normalize(), dist, dmg, false);
                homing.hits.add(new Hit(target.getUUID(), dist));
                s.streams.add(homing);
            }
        }

        fx(sp, PacketPaperFx.WAVE, fanArmIsLeft(sp, hand));
        sp.swing(hand, true);
        sound(sp, SoundEvents.BOOK_PAGE_TURN, 1.0f, 1.9f);
        sound(sp, SoundEvents.PHANTOM_FLAP, 0.6f, 1.8f);

        if (s.waves <= 0) {
            s.cloudTicks = 0; // the batch is used up
            msg(sp, "\u00a77The last of the paper flies out");
        } else {
            msg(sp, "\u00a7fWave \u00a77(" + s.waves + " left)");
        }
    }

    private static Stream makeStream(Vec3 from, Vec3 dir, double length, float dmg, boolean aimed) {
        Stream st = new Stream();
        st.from = from;
        st.dir = dir;
        st.length = length;
        st.damage = dmg;
        st.aimed = aimed;
        st.phase = (float) (Math.random() * Math.PI * 2);
        Vec3 ref = Math.abs(dir.y) > 0.98 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        st.u = dir.cross(ref).normalize();
        st.v = dir.cross(st.u).normalize();
        return st;
    }

    /** A stream along the look direction: stopped by walls, catching every enemy in its path (nearest first). */
    private static Stream aimStream(ServerPlayer sp, ServerLevel level, Vec3 from, Vec3 dir, float dmg) {
        Vec3 end = from.add(dir.scale(PaperTuning.WAVE_RANGE));
        BlockHitResult wall = level.clip(new ClipContext(from, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        double length = wall.getType() == HitResult.Type.MISS ? PaperTuning.WAVE_RANGE : wall.getLocation().distanceTo(from);
        Stream st = makeStream(from, dir, length, dmg, true);
        Vec3 stop = from.add(dir.scale(length));
        AABB box = new AABB(from, stop).inflate(PaperTuning.WAVE_WIDTH + 1.0);
        for (Entity e : level.getEntities(sp, box, x -> hostile(sp, x))) {
            AABB bb = e.getBoundingBox().inflate(PaperTuning.WAVE_WIDTH * 0.5);
            double d;
            if (bb.contains(from)) {
                d = 0;
            } else {
                Optional<Vec3> hit = bb.clip(from, stop);
                if (hit.isEmpty()) continue;
                d = from.distanceTo(hit.get());
            }
            st.hits.add(new Hit(e.getUUID(), d));
        }
        st.hits.sort(Comparator.comparingDouble(h -> h.dist));
        return st;
    }

    /** The paper front reaches an enemy: it is hurt, and marked if the user had nobody marked. */
    private static void strike(ServerPlayer sp, State s, ServerLevel level, LivingEntity t, Stream st) {
        if (!hostile(sp, t)) return;
        t.invulnerableTime = 0; // each wave lands in full, even right after another hit
        Vows.hatsuHurt(t, level.damageSources().playerAttack(sp), st.damage);
        if (t.getUUID().equals(s.mark)) {
            s.markTicks = PaperTuning.MARK_TICKS; // hitting the marked enemy renews the mark
        } else if (st.aimed && s.mark == null) {
            s.mark = t.getUUID();
            s.markTicks = PaperTuning.MARK_TICKS;
            msg(sp, "\u00a75Marked: \u00a7f" + t.getDisplayName().getString());
            sound(sp, SoundEvents.BOOK_PAGE_TURN, 0.9f, 0.6f);
        }
        Vec3 at = t.position().add(0, t.getBbHeight() * 0.5, 0);
        level.sendParticles(paper(), at.x, at.y, at.z, 28, t.getBbWidth() * 0.5, t.getBbHeight() * 0.4, t.getBbWidth() * 0.5, 0.12);
        level.sendParticles(ParticleTypes.WHITE_ASH, at.x, at.y, at.z, 10, 0.3, 0.4, 0.3, 0.0);
    }

    private static void tickStreams(ServerPlayer sp, State s, ServerLevel level) {
        Iterator<Stream> it = s.streams.iterator();
        while (it.hasNext()) {
            Stream st = it.next();
            double next = Math.min(st.length, st.front + st.speed);
            Iterator<Hit> hi = st.hits.iterator();
            while (hi.hasNext()) {
                Hit h = hi.next();
                if (h.dist <= next || next >= st.length) {
                    hi.remove();
                    if (level.getEntity(h.id) instanceof LivingEntity le && le.isAlive()) strike(sp, s, level, le, st);
                }
            }
            if (st.big) {
                for (double d = st.front; d < next; d += 0.4) spawnGust(level, st, d);
            } else {
                for (double d = st.front; d < next; d += 0.5) spawnSerpent(level, st, d);
            }
            st.front = next;
            if (next >= st.length && st.hits.isEmpty()) it.remove();
        }
    }

    /** The swarm's wave: a gust of wind carrying thousands of paper scraps, a wall about as wide as the wave's reach. */
    private static void spawnGust(ServerLevel level, Stream st, double d) {
        Vec3 c = st.from.add(st.dir.scale(d));
        double r = PaperTuning.SWARM_WAVE_RADIUS * (0.55 + Math.min(0.45, d * 0.04));
        level.sendParticles(paper(), c.x, c.y, c.z, PaperTuning.SWARM_WAVE_CONFETTI, r * 0.5, r * 0.4, r * 0.5, 0.12);
        level.sendParticles(ParticleTypes.WHITE_ASH, c.x, c.y, c.z, PaperTuning.SWARM_WAVE_CONFETTI / 2, r * 0.6, r * 0.45, r * 0.6, 0.02);
        // a rolling wall of scraps flung along the wind: two rings whirling round the front, one inside the other
        double base = d * 0.9 + st.phase;
        for (int k = 0; k < 14; k++) {
            double ang = base + k * (Math.PI * 2 / 14);
            double rr = (k % 2 == 0) ? r : r * 0.6;
            Vec3 p = c.add(st.u.scale(Math.cos(ang) * rr)).add(st.v.scale(Math.sin(ang) * rr));
            level.sendParticles(paper(), p.x, p.y, p.z, 14, 0.5, 0.5, 0.5, 0.12);
        }
    }

    /** Every enemy the wide wave sweeps over, nearest first (it is stopped by walls like the plain wave). */
    private static void bigHits(ServerPlayer sp, ServerLevel level, Stream st) {
        AABB box = new AABB(st.from, st.from.add(st.dir.scale(st.length))).inflate(PaperTuning.SWARM_WAVE_RADIUS + 1.0);
        for (Entity e : level.getEntities(sp, box, x -> hostile(sp, x))) {
            Vec3 v = e.getBoundingBox().getCenter().subtract(st.from);
            double along = v.dot(st.dir);
            if (along < -1.0 || along > st.length + 1.0) continue;
            double perp = v.subtract(st.dir.scale(along)).length();
            if (perp > PaperTuning.SWARM_WAVE_RADIUS + e.getBbWidth() * 0.5) continue;
            st.hits.add(new Hit(e.getUUID(), Math.max(0.0, along)));
        }
        st.hits.sort(Comparator.comparingDouble(h -> h.dist));
    }

    /** Two strands of paper twisting round each other, opening wider as they go: the serpent. */
    private static void spawnSerpent(ServerLevel level, Stream st, double d) {
        Vec3 c = st.from.add(st.dir.scale(d));
        double base = d * 1.3 + st.phase;
        double r = (st.big ? 1.0 : 0.35) + Math.min(1.1, d * 0.03);
        for (int k = 0; k < (st.big ? 4 : 2); k++) {
            double ang = base + k * (Math.PI * 2 / (st.big ? 4 : 2));
            Vec3 p = c.add(st.u.scale(Math.cos(ang) * r)).add(st.v.scale(Math.sin(ang) * r));
            level.sendParticles(paper(), p.x, p.y, p.z, 1, 0.04, 0.04, 0.04, 0.0);
        }
        if (((int) (d * 2)) % 2 == 0) level.sendParticles(ParticleTypes.WHITE_ASH, c.x, c.y, c.z, 2, 0.15, 0.15, 0.15, 0.0);
    }

    // ---------------------------------------------------------------- 3. the swarm

    /** Shift+Z on a marked enemy: another batch of paper, and the swarm is ready. */
    private static void prime(ServerPlayer sp, Combat c, State s, ServerLevel level) {
        if (s.swarmCd > 0) {
            ChainManager.onCooldown(sp, NAME, s.swarmCd);
            return;
        }
        if (markedTarget(s, level) == null) {
            msg(sp, "\u00a7cMark an enemy with the paper first");
            return;
        }
        if (s.primed) {
            msg(sp, "\u00a77The swarm is already waiting. Press Z");
            return;
        }
        if (!pay(sp, c, PaperTuning.PRIME_COST)) return;
        s.primed = true;
        s.cloudTicks = PaperTuning.CLOUD_LIFETIME_TICKS;
        s.cd = PaperTuning.PRIME_COOLDOWN_TICKS;
        fx(sp, PacketPaperFx.DROP, true);
        Vec3 p = sp.position();
        level.sendParticles(paper(), p.x, p.y + 2.1, p.z, 500, 3.2, 1.2, 3.2, 0.06);
        level.sendParticles(ParticleTypes.WHITE_ASH, p.x, p.y + 1.6, p.z, 160, 3.2, 1.4, 3.2, 0.02);
        sound(sp, SoundEvents.BOOK_PAGE_TURN, 1.0f, 0.5f);
        sound(sp, SoundEvents.WOOL_PLACE, 1.0f, 1.3f);
        msg(sp, "\u00a75A second batch hangs in the air \u00a77- press Z to send the swarm");
    }

    /** Z with the swarm ready: the massive wave goes out, uses up all the paper, and the vortex closes on the marked enemy. */
    private static void swarm(ServerPlayer sp, Combat c, State s, ServerLevel level) {
        LivingEntity target = markedTarget(s, level);
        if (target == null) {
            s.primed = false;
            msg(sp, "\u00a77The marked enemy is gone, and the swarm falls apart");
            return;
        }
        Vec3 origin = sp.getEyePosition().add(sp.getLookAngle().scale(0.6)).add(0, -0.4, 0);
        Vec3 to = target.getBoundingBox().getCenter();
        double dist = to.distanceTo(origin);
        if (dist > PaperTuning.WAVE_RANGE) {
            msg(sp, "\u00a7cThe marked enemy is too far away");
            return;
        }
        InteractionHand hand = takeFan(sp);
        if (hand == null) return;
        if (!pay(sp, c, PaperTuning.SWARM_COST)) return;

        s.primed = false;
        s.waves = 0;
        s.cloudTicks = 0; // every scrap of paper in the air goes into the swarm
        s.cd = PaperTuning.WAVE_COOLDOWN_TICKS;
        s.swarmTarget = target.getUUID();
        s.swarmTicks = PaperTuning.SWARM_TICKS;
        s.swarmDamage = damage(sp, c, PaperTuning.SWARM_HIT_DAMAGE, PaperTuning.SWARM_DAMAGE_PER_LEVEL);
        s.swarmDelay = 0;

        if (dist > 0.01) {
            // the wave runs on a little past the marked enemy, wide and slow, and hurts everything it sweeps over
            double length = Math.min(PaperTuning.WAVE_RANGE, dist + 3.0);
            float waveDmg = damage(sp, c, PaperTuning.SWARM_WAVE_BASE_DAMAGE, PaperTuning.SWARM_WAVE_DAMAGE_PER_LEVEL);
            Stream big = makeStream(origin, to.subtract(origin).normalize(), length, waveDmg, false);
            big.big = true;
            big.speed = PaperTuning.SWARM_WAVE_SPEED;
            bigHits(sp, level, big);
            s.streams.add(big);
            s.swarmDelay = (int) Math.ceil(dist / PaperTuning.SWARM_WAVE_SPEED); // the vortex closes when the wave arrives
        }
        fx(sp, PacketPaperFx.SWARM, fanArmIsLeft(sp, hand));
        sp.swing(hand, true);
        sound(sp, SoundEvents.BOOK_PAGE_TURN, 1.2f, 0.6f);
        sound(sp, SoundEvents.PHANTOM_SWOOP, 1.0f, 1.6f);
        msg(sp, "\u00a75" + NAME + ": \u00a7fSwarm");
    }

    private static void tickSwarm(ServerPlayer sp, State s, ServerLevel level) {
        LivingEntity t = level.getEntity(s.swarmTarget) instanceof LivingEntity le && le.isAlive() ? le : null;
        if (t == null) {
            endSwarm(sp, s);
            return;
        }
        if (s.swarmDelay > 0) { // the wave is still crossing the distance
            s.swarmDelay--;
            return;
        }
        int elapsed = PaperTuning.SWARM_TICKS - s.swarmTicks;

        // the vortex: a storm of paper spiralling up round the enemy, thicker and wider towards the top
        double height = t.getBbHeight() + 1.6;
        double baseR = t.getBbWidth() * 0.5 + 1.2;
        Vec3 p = t.position();
        int n = 48;
        level.sendParticles(paper(), p.x, p.y + height * 0.5, p.z, 70, baseR * 0.8, height * 0.4, baseR * 0.8, 0.15);
        level.sendParticles(ParticleTypes.WHITE_ASH, p.x, p.y + height * 0.5, p.z, 25, baseR * 0.8, height * 0.4, baseR * 0.8, 0.02);
        for (int i = 0; i < n; i++) {
            double f = ((elapsed * 0.12) + i / (double) n) % 1.0;
            double h = f * height;
            double ang = elapsed * 0.5 + i * (Math.PI * 2 * 4.0 / n);
            double r = baseR + 1.1 * f;
            double x = p.x + Math.cos(ang) * r;
            double z = p.z + Math.sin(ang) * r;
            level.sendParticles(i % 4 == 0 ? ParticleTypes.WHITE_ASH : paper(), x, p.y + h, z, 0, -Math.sin(ang), 0.08, Math.cos(ang), 0.3);
        }

        if (elapsed % PaperTuning.SWARM_HIT_EVERY_TICKS == 0) {
            t.invulnerableTime = 0;
            Vows.hatsuHurt(t, level.damageSources().playerAttack(sp), s.swarmDamage);
            // knockback would throw the enemy out of the vortex: it stays put (falling still works)
            var dm = t.getDeltaMovement();
            t.setDeltaMovement(0, Math.min(0.0, dm.y), 0);
            t.hurtMarked = true;
            level.sendParticles(paper(), p.x, p.y + t.getBbHeight() * 0.5, p.z, 40, t.getBbWidth() * 0.5, t.getBbHeight() * 0.4, t.getBbWidth() * 0.5, 0.12);
            // the vortex shreds whoever stands close to it too
            for (Entity other : level.getEntities(sp, t.getBoundingBox().inflate(PaperTuning.SWARM_VORTEX_AOE), x -> x != t && hostile(sp, x))) {
                if (!(other instanceof LivingEntity ol)) continue;
                ol.invulnerableTime = 0;
                Vows.hatsuHurt(ol, level.damageSources().playerAttack(sp), s.swarmDamage * PaperTuning.SWARM_AOE_SHARE);
            }
            if (elapsed % 10 == 0) level.playSound(null, t.blockPosition(), SoundEvents.PHANTOM_FLAP, SoundSource.PLAYERS, 0.8f, 1.7f);
        }
        if (--s.swarmTicks <= 0) endSwarm(sp, s);
    }

    private static void endSwarm(ServerPlayer sp, State s) {
        s.swarmTicks = 0;
        s.swarmTarget = null;
        s.mark = null; // the paper that marked the enemy went into the swarm
        s.markTicks = 0;
        s.swarmCd = PaperTuning.SWARM_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, NAME, PaperTuning.SWARM_COOLDOWN_TICKS);
    }

    // ---------------------------------------------------------------- per tick

    public static void serverTick(MinecraftServer server) {
        if (STATES.isEmpty()) return;
        for (Map.Entry<UUID, State> en : new ArrayList<>(STATES.entrySet())) {
            State s = en.getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null) {
                STATES.remove(en.getKey());
                continue;
            }
            Combat c = Combat.get(sp);
            if (!sp.isAlive() || !canUse(c) || ExtrasHooks.hatsuForced(sp)) {
                clear(sp);
                continue;
            }
            if (!(sp.level() instanceof ServerLevel level)) continue;
            tick(sp, s, level, server.getTickCount());
        }
    }

    private static void tick(ServerPlayer sp, State s, ServerLevel level, int gameTick) {
        if (s.cd > 0) s.cd--;
        if (s.swarmCd > 0) s.swarmCd--;

        tickStreams(sp, s, level);

        // the mark: it clings to the enemy until it dies or the paper wears off
        if (s.mark != null) {
            LivingEntity t = markedTarget(s, level);
            if (t == null || --s.markTicks <= 0) {
                s.mark = null;
                s.markTicks = 0;
                if (s.primed) {
                    s.primed = false;
                    msg(sp, "\u00a77The marked enemy is gone, and the swarm falls apart");
                }
            } else if (gameTick % 4 == 0) {
                Vec3 at = t.position().add(0, t.getBbHeight() * 0.55, 0);
                level.sendParticles(paper(), at.x, at.y, at.z, 4, t.getBbWidth() * 0.55, t.getBbHeight() * 0.4, t.getBbWidth() * 0.55, 0.0);
            }
        }

        // the paper hanging in the air round the user
        if (s.cloudTicks > 0 || s.primed) {
            if (gameTick % 2 == 0) {
                Vec3 p = sp.position();
                int n = s.primed ? 70 : 12;
                level.sendParticles(paper(), p.x, p.y + 1.5, p.z, n, s.primed ? 3.0 : 1.8, s.primed ? 1.2 : 0.9, s.primed ? 3.0 : 1.8, 0.01);
                level.sendParticles(ParticleTypes.WHITE_ASH, p.x, p.y + 1.4, p.z, n / 3, 1.8, 0.9, 1.8, 0.0);
            }
            if (s.cloudTicks > 0 && --s.cloudTicks == 0 && !s.primed) {
                s.waves = 0;
                msg(sp, "\u00a77The paper settles to the ground");
            }
        }

        if (s.swarmTicks > 0) tickSwarm(sp, s, level);
    }

    // ---------------------------------------------------------------- ending

    /** Death, losing the Hatsu, Forced Zetsu, logging out: everything in the air falls and the mark comes off. */
    public static void clear(ServerPlayer sp) {
        STATES.remove(sp.getUUID());
    }

    /** An enemy died or left: any mark on it is gone (the tick notices too; this just makes it instant). */
    public static void onDeath(Entity e) {
        if (e == null || STATES.isEmpty()) return;
        for (State s : STATES.values()) if (e.getUUID().equals(s.mark)) s.markTicks = 1;
    }

    public static void reset() {
        STATES.clear();
    }
}
