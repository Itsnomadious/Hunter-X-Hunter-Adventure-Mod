package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketDiveArrowsFx;
import net.hxhadventure.utils.AllianceUtils;

/**
 * The second half of Zeno's Dragon Dive: once the dragon has dissipated, hundreds of golden arrows rain down within
 * DIVE_RADIUS blocks of where its head was. Arrows are not entities: the server decides where and when each one lands
 * (ground height under a random point, or near an enemy), tells nearby clients to draw it falling, and applies the damage
 * and the crater when its fall time is up.
 */
public final class DragonDive {
    private DragonDive() {}

    private static final class Impact {
        final int x, y, z, tick;

        Impact(int x, int y, int z, int tick) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.tick = tick;
        }
    }

    private static final class Rain {
        ResourceKey<Level> dim;
        Vec3 centre;
        UUID owner;
        int age;
        int spawned;
        List<LivingEntity> targets = new ArrayList<>();
        final List<Impact> pending = new ArrayList<>();
    }

    private static final List<Rain> RAINS = new ArrayList<>();

    public static void start(ServerLevel level, Vec3 centre, UUID owner) {
        Rain r = new Rain();
        r.dim = level.dimension();
        r.centre = centre;
        r.owner = owner;
        RAINS.add(r);
        level.playSound(null, centre.x, centre.y, centre.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 6.0f, 0.7f);
    }

    public static void clearAll() {
        RAINS.clear();
    }

    public static void tickAll(MinecraftServer server) {
        if (RAINS.isEmpty()) return;
        for (int i = RAINS.size() - 1; i >= 0; i--) {
            Rain r = RAINS.get(i);
            ServerLevel level = server.getLevel(r.dim);
            if (level == null || !tick(server, level, r)) RAINS.remove(i);
        }
    }

    /** @return false once the rain is over. */
    private static boolean tick(MinecraftServer server, ServerLevel level, Rain r) {
        Entity owner = level.getEntity(r.owner); // a player or an NPC (Zeno)

        // spawn this tick's share of the arrows
        int goal = Math.min(Tuning.DIVE_ARROWS, (int) ((long) Tuning.DIVE_ARROWS * (r.age + 1) / Tuning.DIVE_RAIN_TICKS));
        if (r.age % 10 == 0 && r.spawned < Tuning.DIVE_ARROWS) refreshTargets(level, r, owner);
        List<float[]> fx = new ArrayList<>();
        while (r.spawned < goal) {
            r.spawned++;
            double x, z;
            if (!r.targets.isEmpty() && level.random.nextDouble() < Tuning.DIVE_TARGETED) {
                LivingEntity t = r.targets.get(level.random.nextInt(r.targets.size()));
                x = t.getX() + (level.random.nextDouble() - 0.5) * 5;
                z = t.getZ() + (level.random.nextDouble() - 0.5) * 5;
            } else {
                double a = level.random.nextDouble() * Math.PI * 2;
                double d = Tuning.DIVE_RADIUS * Math.sqrt(level.random.nextDouble());
                x = r.centre.x + Math.cos(a) * d;
                z = r.centre.z + Math.sin(a) * d;
            }
            int bx = Mth.floor(x), bz = Mth.floor(z);
            if (!level.hasChunk(bx >> 4, bz >> 4)) continue; // never force chunks to load
            int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING, bx, bz);
            double top = ground + Tuning.DIVE_ARROW_HEIGHT;
            int delay = Math.max(1, (int) Math.ceil(Tuning.DIVE_ARROW_HEIGHT / Tuning.DIVE_ARROW_SPEED));
            r.pending.add(new Impact(bx, ground, bz, r.age + delay));
            fx.add(new float[]{(float) (bx + 0.5), (float) top, (float) (bz + 0.5), (float) ground});
        }
        if (!fx.isEmpty()) {
            AddonNetwork.sendToNear(new PacketDiveArrowsFx((float) Tuning.DIVE_ARROW_SPEED, fx), level, r.centre, Tuning.DIVE_RADIUS + 160);
        }

        // land the arrows whose time has come
        int[] blockBudget = {Tuning.DIVE_MAX_BLOCKS_PER_TICK};
        for (int i = r.pending.size() - 1; i >= 0; i--) {
            Impact im = r.pending.get(i);
            if (im.tick > r.age) continue;
            r.pending.remove(i);
            land(level, owner, r.owner, im, blockBudget);
        }

        r.age++;
        return r.spawned < Tuning.DIVE_ARROWS || !r.pending.isEmpty();
    }

    private static void refreshTargets(ServerLevel level, Rain r, Entity owner) {
        r.targets.clear();
        AABB box = new AABB(r.centre, r.centre).inflate(Tuning.DIVE_RADIUS, 256, Tuning.DIVE_RADIUS);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (!e.isAlive() || e instanceof ArmorStand || e.getUUID().equals(r.owner)) continue;
            if (owner != null && AllianceUtils.isAlly(e, owner)) continue;
            if (owner instanceof NenFighter nf && !nf.isFoe(e)) continue;
            double dx = e.getX() - r.centre.x, dz = e.getZ() - r.centre.z;
            if (dx * dx + dz * dz > Tuning.DIVE_RADIUS * Tuning.DIVE_RADIUS) continue;
            r.targets.add(e);
            if (r.targets.size() >= 64) break;
        }
    }

    private static void land(ServerLevel level, Entity owner, UUID ownerId, Impact im, int[] blockBudget) {
        if (!level.hasChunk(im.x >> 4, im.z >> 4)) return;
        double cx = im.x + 0.5, cy = im.y, cz = im.z + 0.5;
        level.sendParticles(ParticleTypes.END_ROD, cx, cy + 0.5, cz, 8, 0.4, 0.3, 0.4, 0.18);
        level.sendParticles(ParticleTypes.EXPLOSION, cx, cy + 0.3, cz, 1, 0, 0, 0, 0);
        if (level.random.nextInt(4) == 0) {
            level.playSound(null, cx, cy, cz, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.4f, 1.3f + level.random.nextFloat() * 0.4f);
        }

        // damage
        DamageSource src = owner instanceof net.minecraft.world.entity.player.Player po ? level.damageSources().playerAttack(po)
            : owner instanceof LivingEntity lo ? level.damageSources().mobAttack(lo) : level.damageSources().magic();
        double h = Tuning.DIVE_HIT_RADIUS;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(cx - h, cy - 1, cz - h, cx + h, cy + 4, cz + h))) {
            if (!e.isAlive() || e instanceof ArmorStand || e.getUUID().equals(ownerId)) continue;
            if (owner != null && AllianceUtils.isAlly(e, owner)) continue;
            if (owner instanceof NenFighter nf && !nf.isFoe(e)) continue;
            float mult = owner instanceof net.minecraft.world.entity.player.Player pm ? Vows.hatsuDamageMult(pm) : owner instanceof NenFighter nf2 ? nf2.hatsuScale() : 1f;
            Vows.hatsuHurt(e, src, Tuning.DIVE_ARROW_DAMAGE * mult); // the Hatsu skill: more damage
            e.push(0, 0.35, 0);
            e.hurtMarked = true;
        }

        // crater
        if (!Tuning.DIVE_BREAK_BLOCKS) return;
        int R = Tuning.DIVE_CRATER_RADIUS;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int dx = -R; dx <= R; dx++) {
            for (int dy = -R; dy <= R; dy++) {
                for (int dz = -R; dz <= R; dz++) {
                    if (blockBudget[0] <= 0) return;
                    if (dx * dx + dy * dy + dz * dz > R * R + 1) continue;
                    pos.set(im.x + dx, im.y - 1 + dy, im.z + dz); // centred on the top block that was hit
                    if (!level.isInWorldBounds(pos) || !level.hasChunkAt(pos)) continue;
                    BlockState st = level.getBlockState(pos);
                    if (st.isAir() || !st.getFluidState().isEmpty() || st.getDestroySpeed(level, pos) < 0
                        || st.getBlock().getExplosionResistance() > Tuning.DIVE_BLOCK_POWER) continue;
                    if (level.random.nextInt(12) == 0) {
                        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5, 3, 0.3, 0.2, 0.3, 0.05);
                    }
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                    blockBudget[0]--;
                }
            }
        }
    }
}
