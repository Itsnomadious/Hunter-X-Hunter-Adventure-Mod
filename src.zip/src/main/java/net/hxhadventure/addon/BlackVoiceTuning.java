package net.hxhadventure.addon;

/** Numbers for Shalnark's Black Voice (Hatsu kit 23, Manipulators). Change them here. */
public final class BlackVoiceTuning {
    private BlackVoiceTuning() {}

    // ---- the antenna (right-click someone while holding the phone) ----
    public static final int IMPLANT_MIN_LEVEL = 10;
    public static final float IMPLANT_COST = 150f;
    public static final int IMPLANT_COOLDOWN_TICKS = 20;
    /** How long an antenna stays in before it dissolves, ticks (12000 = 10 minutes). */
    public static final int ANTENNA_TICKS = 12000;
    /** One antenna at the minimum level, plus one more every this many levels. */
    public static final int LEVELS_PER_ANTENNA = 15;
    /** Never more than this many targets at once (one at Hatsu level 10, two from level 15). */
    public static final int MAX_ANTENNAS = 2;
    /** true = each needle planted uses up one Black Voice needle from your inventory (creative mode is free). false = needles are not needed (one is still used up if you carry any). */
    public static final boolean NEEDLE_REQUIRED = false;
    /** A target at or below this share of its max health cannot resist the needle. */
    public static final float WEAK_HP_FRACTION = 0.30f;

    // ---- taking over a body (Shift+Z while holding the phone) ----
    // Your own body is left behind as a still clone (a decoy that can be hit); you take the antenna'd creature's place, drawn as it
    // (the Convert Hands disguise) while the real creature turns invisible and intangible until you come back.
    public static final int CONTROL_MIN_LEVEL = 15;
    public static final float POSSESS_COST = 100f;
    /** Nen drained per second while you are in another body. */
    public static final float POSSESS_UPKEEP = 10f;
    /** How far you can get from the clone of your real body, blocks. Past this you are pulled back into it. */
    public static final double CONTROL_RANGE = 64.0;
    /** true = if the clone of your real body is hit, the damage lands on you and you snap back into it. */
    public static final boolean BODY_HURT_BREAKS_CONTROL = true;

    /** Nen drained per second while you wear a body that has Nen of its own (Chrollo, Hisoka, Gon, Neferpitou): its own pool is used, so 0 by default. */
    public static final float NEN_BODY_UPKEEP = 0f;

    // ---- how the borrowed body fights (your own punches are swapped for the creature's attack) ----
    public static final int ATTACK_COOLDOWN_TICKS = 10;
    /** Damage dealt by a body that has no attack of its own (a villager, a cow...). */
    public static final float FALLBACK_ATTACK_DAMAGE = 2.0f;

    // ---- Auto Pilot (hold Z with it selected: Shalnark's needle in your own head) ----
    public static final int AUTOPILOT_MIN_LEVEL = 20;
    public static final float AUTOPILOT_COST = 150f;
    /** Hold Z this long (1.5 s) to push the needle in. Letting go earlier puts it away. */
    public static final int AUTOPILOT_NEEDLE_HOLD_TICKS = 30;
    /** How long the needle drives you: 30 s. You cannot give any input for all of it. */
    public static final int AUTOPILOT_TICKS = 600;
    /** Ten and Ren are this many times stronger while it lasts. */
    public static final float AUTOPILOT_TEN_REN_MULT = 2.0f;
    public static final int AUTOPILOT_COOLDOWN_TICKS = 1200;
    /** How far the autopilot looks for something to fight, blocks. */
    public static final double AUTOPILOT_SEARCH_RANGE = 24.0;
    /** It swings (the normal Attack) from this close, blocks, and stops walking at a little less than that. */
    public static final double AUTOPILOT_ATTACK_RANGE = 3.0;
    public static final double AUTOPILOT_STOP_RANGE = 1.8;
    /** Ticks between two of its Attacks (the Attack's own 0.5 s cooldown still applies). */
    public static final int AUTOPILOT_ATTACK_INTERVAL = 10;
    /** Besides the normal Attack in front, everything within this many blocks all around you is hit too, for this much damage each swing. */
    public static final double AUTOPILOT_SWEEP_RADIUS = 3.0;
    public static final float AUTOPILOT_SWEEP_DAMAGE = 3.0f;

    // ---- antenna'd mobs when you are not inside them ----
    /** How far an allied mob will look for something to fight, blocks. */
    public static final double ALLY_SCAN_RANGE = 16.0;
    /** How far from you an allied mob lets itself wander before it walks back, squared blocks. */
    public static final double ALLY_FOLLOW_DIST_SQ = 25.0;
}
