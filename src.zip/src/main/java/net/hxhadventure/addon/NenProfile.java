package net.hxhadventure.addon;

import java.util.Random;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketSyncProfile;

/** Per-player data for the awakening: their talent (rolled when the nodes open), and whether Water Divination has shown them their Nen type. Stored on the player. */
public final class NenProfile {
    private NenProfile() {}

    public static final String TAG = "HxHAdventure_Profile";

    private static CompoundTag tag(Player p, boolean create) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(TAG)) {
            if (!create) return null;
            root.put(TAG, new CompoundTag());
        }
        return root.getCompound(TAG);
    }

    /**
     * The player's talent for XP purposes: Common until their Nen is awakened (see {@link #rollAwakening}). Never rolls by itself,
     * so merely joining a world no longer decides anything.
     */
    public static Talent talent(Player p) {
        Talent found = peekTalent(p);
        return found != null ? found : Talent.COMMON;
    }

    /** The stored talent, or null if none has been rolled yet (never rolls). */
    public static Talent peekTalent(Player p) {
        CompoundTag t = tag(p, false);
        return t != null && t.contains("Talent") ? Talent.byId(t.getString("Talent")) : null;
    }

    /**
     * The awakening roll, in this order: 1. aura colour, 2. talent, 3. Nen type. Nothing affects any of them except the game rules
     * hxhrarenencolours (no white), hxhtalented (no Common) and hxhNenTypeChanceEqual (equal types). Each step only happens if
     * that value is not set yet, so a re-awakening after losing Nen keeps the colour and talent, and an admin who set one with a
     * command keeps it. The type stays hidden until Water Divination.
     */
    public static void rollAwakening(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        boolean rare = sp.getServer() != null && sp.getServer().getGameRules().getBoolean(NenGameRules.RARE_COLOURS);
        boolean talented = sp.getServer() != null && sp.getServer().getGameRules().getBoolean(NenGameRules.TALENTED);
        if (sp.getPersistentData().getInt("HxHCraft_PermanentAuraColor") == 0) {          // 1. colour
            sp.getPersistentData().putInt("HxHCraft_PermanentAuraColor", NenRarity.rollColour(new Random(), rare));
        }
        if (peekTalent(sp) == null) {                                                      // 2. talent
            setTalent(sp, Talent.roll(new Random(), talented));
        }
        if (c != null && c.getNenType() == 0) {                                            // 3. Nen type
            c.setNenType(NenTypeRoll.roll(sp));
        }
        AbilityRegistry.syncAuraColor(sp);
        sync(sp);
    }

    /**
     * Players made before this change had a colour and talent rolled on first login. If they have not awakened yet, drop both once
     * so they are rolled at awakening like everyone else. Runs once per player.
     */
    public static void migrateIfNeeded(ServerPlayer sp) {
        CompoundTag t = tag(sp, true);
        if (t.getBoolean("AwakenRollMigrated")) return;
        t.putBoolean("AwakenRollMigrated", true);
        if (!sp.getPersistentData().getBoolean("HxHCraft_NenUnlocked")) {
            t.remove("Talent");
            sp.getPersistentData().remove("HxHCraft_PermanentAuraColor");
        }
    }

    /** Forgets the rolled talent, so the next awakening rolls a new one. */
    public static void clearTalent(Player p) {
        CompoundTag t = tag(p, false);
        if (t != null) t.remove("Talent");
    }

    public static void setTalent(Player p, Talent talent) {
        tag(p, true).putString("Talent", talent.id);
    }

    public static boolean typeRevealed(Player p) {
        CompoundTag t = tag(p, false);
        return t != null && t.getBoolean("TypeRevealed");
    }

    public static void setTypeRevealed(Player p, boolean v) {
        tag(p, true).putBoolean("TypeRevealed", v);
    }

    /** The game rule hxhnentypeselect: Water Divination lets the player pick their Nen type. */
    public static boolean typeSelectable(ServerPlayer sp) {
        return sp.getServer() != null && sp.getServer().getGameRules().getBoolean(NenGameRules.NEN_TYPE_SELECT);
    }

    public static void sync(ServerPlayer sp) {
        AddonNetwork.sendToPlayer(new PacketSyncProfile(talent(sp).ordinal(), typeRevealed(sp), typeSelectable(sp)), sp);
        Vows.sync(sp);
    }

    /** Death keeps the profile: copies it onto the new player (the base mod copies its own keys the same way). */
    public static void copy(Player from, Player to) {
        CompoundTag t = tag(from, false);
        if (t != null) to.getPersistentData().put(TAG, t.copy());
    }
}
