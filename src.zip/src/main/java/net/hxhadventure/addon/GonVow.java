package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketVowFx;

/**
 * Gon's adult form: the Nen vow "I'll use everything." (Jajanken kit, Enhancers). A toggle: use it once to enter the form, again to leave.
 *
 * <p>While it lasts: the player is taller ({@link #HEIGHT_MULT}); max aura, speed, durability (damage taken is divided) and damage dealt
 * are all x{@link #STAT_MULT}; the Ren aura is {@link #REN_SIZE}x; and only Rock answers (Scissors and Paper are refused). Rock in this
 * form is a different move (see {@link Jajanken}): an orb that cycles in size to the sound of {@link HxHSounds#GON_VOW_ORB}, can be
 * held for ever with the user rooted to the spot, gains x{@link #CYCLE_DAMAGE_MULT} damage per finished cycle, and hits in a radius
 * {@link #RADIUS_MULT}x a normal Rock's.
 *
 * <p>The form runs on lifespan instead of a timer: it drains {@link #YEARS_PER_SECOND} years a second, and running out of lifespan kills the user.
 * Losing lifespan does not lower max health.
 *
 * <p>Every vow Rock that is charged adds one level of Nen debt. Ending the form costs {@link #LEVELS_PER_DEBT} Levels per debt level, but if the
 * debt reaches {@link #NEN_LOSS_DEBT} the form ends on the spot and the Nen is lost for good ({@link NenLoss}): a fresh player again, every Nen
 * skill and level at 1, the Nen to be awakened all over again.
 *
 * <p>Server state is a set of UUIDs; clients keep a set of entity ids (fed by {@link PacketVowFx}), so {@link #isActive(Entity)} works on both
 * sides. The hitbox change is an EntityEvent.Size hook ({@link GonVowEvents}); the visual growth is drawn by the client class GonVowClient.
 */
public final class GonVow {
    private GonVow() {}

    public static final String ID = "jajanken_vow";
    public static final String PHRASE = "I'll use everything.";

    // ---- tuning (all in one place) ----
    /** Hatsu level the vow unlocks at. */
    public static final int MIN_LEVEL = 60;
    /**
     * Max aura is multiplied by this, and so are damage dealt by Hatsu hits (the Rock) and by anything that is not a melee hit.
     * Movement speed, melee durability and Attack / Strong attack / Barrage damage are built from Ren and Ko instead (below).
     */
    public static final float STAT_MULT = 10f;
    /** Movement speed: the form's total speed bonus is Ren's speed bonus x this (Ren +100% speed -> +150%). */
    public static final float SPEED_VS_REN = 1.5f;
    /** Attack / Strong attack / Barrage: Ren's damage bonus x this ("100% more than Ren"), plus {@link #MELEE_KO_SHARE} of Ko's. */
    public static final float MELEE_REN_MULT = 2.0f;
    public static final float MELEE_KO_SHARE = 1.0f;
    /** Durability: Ren's durability bonus plus this much more (+540% from Ren becomes +640%). */
    public static final float DURABILITY_EXTRA = 1.0f;
    /** Height (and hitbox) multiplier. */
    public static final float HEIGHT_MULT = 1.5f;
    /** Ren aura size while in the form (the slider's normal maximum is {@link Tuning#REN_MAX_SIZE}). */
    public static final float REN_SIZE = 10f;
    /** The orb's pulse, in ticks: the length of the sound clip (2.6 s). */
    public static final int CYCLE_TICKS = 52;
    /** After each pulse the orb rests as a charged fist for this long (1 s) before the next pulse and the sound clip start. */
    public static final int CYCLE_PAUSE_TICKS = 20;
    /** From the start of one pulse to the start of the next: the pulse, then the rest. The sound clip is restarted on this period. */
    public static final int CYCLE_PERIOD_TICKS = CYCLE_TICKS + CYCLE_PAUSE_TICKS;
    /** How many pulses have finished after {@code elapsed} ticks of charging (a pulse counts as finished when its clip ends). */
    public static int cyclesDone(long elapsed) {
        return elapsed < CYCLE_TICKS ? 0 : (int) ((elapsed - CYCLE_TICKS) / CYCLE_PERIOD_TICKS) + 1;
    }
    /** The crater never goes deeper than this many blocks below the user's feet. */
    public static final int CRATER_MAX_DEPTH = 6;
    /** Damage multiplier per finished cycle. */
    public static final double CYCLE_DAMAGE_MULT = 1.5;
    /** A hard ceiling on a Rock's damage so endless charging can never reach infinity / NaN. */
    public static final float MAX_DAMAGE = 1.0e30f;
    /** Years of lifespan the form costs per second: half a year, as it always was (Emperor Time is now 1 hour a second, so this is no longer tied to it). */
    public static final float YEARS_PER_SECOND = 0.5f;
    /** Every vow Rock that is charged adds one level of Nen debt; each level costs this many Levels when the form ends. */
    public static final int LEVELS_PER_DEBT = 10;
    /** Reaching this much Nen debt (this many vow Rocks charged in one form) loses the Nen for good: back to a fresh player. */
    public static final int NEN_LOSS_DEBT = 10;
    /** Ending the form always costs at least this many debt levels' worth, even with no Rock charged (so at least 10 Levels). */
    public static final int MIN_DEBT_ON_END = 1;
    /** Damage radius (entities and blocks) compared with a normal Rock's. */
    public static final float RADIUS_MULT = 20f;
    /** The punch's crater: false = only creatures are hit by the wide blast, blocks are left alone. */
    public static final boolean CRATER = true;
    public static final int CRATER_BREAKS_PER_TICK = 3000;   // blocks removed per tick: a full 44 block crater (about 357,000 positions, mostly less) is dug out over a few seconds
    public static final int CRATER_READS_PER_TICK = 40000;   // positions looked at per tick (air is free to skip)

    // ---- the orb (also read by the client renderer) ----
    public static final double ORB_START_RADIUS = 0.12;      // the small red orb the very first cycle starts from
    public static final double ORB_ROCK_RADIUS = 0.38;       // a normal Rock's ball: the smallest the orb gets
    public static final double ORB_MAX_RADIUS = 10.0;        // the biggest, around the user

    /**
     * How big the orb is at every tick of a cycle (0 = the smallest, 1 = the full {@link #ORB_MAX_RADIUS}). Measured from the loudness of
     * the sound clip, so the rapid expansion is the high-pitched surge (ticks 2 to 9) and the orb is at its minimum when the clip falls quiet.
     */
    public static final float[] ENVELOPE = {
        0.004f, 0.004f, 0.024f, 0.205f, 0.363f, 0.492f, 0.638f, 0.774f, 0.936f, 1.000f, 0.914f, 0.834f, 0.760f, 0.698f, 0.654f,
        0.623f, 0.597f, 0.579f, 0.572f, 0.571f, 0.568f, 0.561f, 0.552f, 0.544f, 0.538f, 0.533f, 0.527f, 0.517f, 0.496f, 0.461f,
        0.418f, 0.376f, 0.345f, 0.327f, 0.309f, 0.280f, 0.242f, 0.205f, 0.177f, 0.155f, 0.136f, 0.124f, 0.117f, 0.111f, 0.099f,
        0.079f, 0.057f, 0.040f, 0.028f, 0.018f, 0.009f, 0.000f
    };

    /** The orb size (0..1) at {@code phase} ticks into a cycle (fractional ticks are interpolated). */
    public static double envelope(double phase) {
        double p = Math.max(0, Math.min(CYCLE_TICKS - 1e-6, phase));
        int i = (int) p;
        double f = p - i;
        float a = ENVELOPE[i], b = ENVELOPE[Math.min(ENVELOPE.length - 1, i + 1)];
        return a + (b - a) * f;
    }

    // ---- state ----
    private static final Set<UUID> ACTIVE = ConcurrentHashMap.newKeySet();

    /** Per player in the form: the Nen debt built up so far. */
    private static final class State {
        int debt;
    }

    private static final Map<UUID, State> STATE = new ConcurrentHashMap<>();
    /** Client side: entity ids of the players in the form (kept up to date by PacketVowFx). */
    private static final Set<Integer> CLIENT = ConcurrentHashMap.newKeySet();
    private static final UUID SPEED_ID = UUID.fromString("5a1c0d7e-3f0b-4c63-9a0e-7a6b1e2d9c41");

    public static boolean isActive(Entity e) {
        if (!(e instanceof Player p) || p.level() == null) return false;
        return p.level().isClientSide ? CLIENT.contains(p.getId()) : ACTIVE.contains(p.getUUID());
    }

    public static boolean clientHas(int entityId) { return CLIENT.contains(entityId); }

    public static void setClient(int entityId, boolean on) {
        if (on) CLIENT.add(entityId);
        else CLIENT.remove(entityId);
    }

    public static void clearClient() { CLIENT.clear(); }

    public static float energyMult(Player p) { return isActive(p) ? STAT_MULT : 1f; }

    /**
     * Damage multiplier for Hatsu hits (the Rock) and anything that is not a melee hit. It was x10; scaled by 1024 / 2000 now that
     * Neferpitou has 1024 health, so three vow Rocks (not two) still take her down.
     */
    public static final float HATSU_DAMAGE_MULT = STAT_MULT * 0.512f;

    public static float damageMult(Player p) { return isActive(p) ? HATSU_DAMAGE_MULT : 1f; }

    // ---- the same numbers for Gon the NPC (he has no Ren / Ko switches: they are worked out from his Ten level) ----
    /** Total melee multiplier for his plain punches: 1 + 2 x Ren's bonus + Ko's bonus. */
    public static float npcMeleeMult(int tenLevel) {
        float ten = Tuning.tenBonus(tenLevel);
        return 1f + MELEE_REN_MULT * ten * Tuning.REN_TEN_MULT + MELEE_KO_SHARE * ten * Tuning.KO_DAMAGE_SHARE;
    }

    /** What damage he takes is divided by: 1 + Ren's durability bonus + {@link #DURABILITY_EXTRA}. */
    public static float npcDurabilityDivisor(int tenLevel) {
        return 1f + Tuning.tenBonus(tenLevel) * Tuning.REN_TEN_MULT + DURABILITY_EXTRA;
    }

    /** His total speed bonus in the form (a fraction added): Ren's speed bonus x {@link #SPEED_VS_REN}. */
    public static double npcSpeedTotal(int tenLevel) {
        return Tuning.tenSpeedBonus(tenLevel) * Tuning.REN_TEN_MULT * SPEED_VS_REN * Tuning.BUFF_SPEED_SCALE;
    }

    /**
     * What to multiply a melee hit (Attack, Strong attack, Barrage) by on top of the aura multiplier that is already applied (Ren, Ken, Ten
     * or nothing), so that the total is 1 + 2 x Ren's bonus + Ko's bonus whichever of those is on.
     */
    public static float meleeFactor(Player p, NenAddonData d, Combat c) {
        if (!isActive(p) || d == null || c == null) return 1f;
        float target = 1f + MELEE_REN_MULT * d.renDamageBonus() + MELEE_KO_SHARE * d.koDamageBonus();
        return target / (1f + d.auraDamageBonus(c, true));
    }

    /** What damage taken is divided by on top of the aura durability that is already applied, so that the total is Ren's + {@link #DURABILITY_EXTRA}. */
    public static float durabilityFactor(Player p, NenAddonData d, Combat c) {
        if (!isActive(p) || d == null || c == null) return 1f;
        float target = 1f + d.renDurabilityBonus() + DURABILITY_EXTRA;
        return target / (1f + d.auraDurabilityBonus(c));
    }

    /** x1.5 per finished cycle, capped so it can never overflow. */
    public static float cycleMult(int cycles) {
        return (float) Math.min(MAX_DAMAGE, Math.pow(CYCLE_DAMAGE_MULT, Math.max(0, cycles)));
    }

    /** Has this player sworn the Jajanken Vow ({@link Vows#EVERYTHING_VOW})? Works on both sides (the client reads its synced copy). */
    public static boolean isSworn(Player p) {
        if (p == null) return false;
        return p.level().isClientSide ? ClientVows.chosen.contains(Vows.EVERYTHING_VOW) : Vows.has(p, Vows.EVERYTHING_VOW);
    }

    // ---------------- the toggle ----------------
    public static void toggle(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        if (ACTIVE.contains(sp.getUUID())) {
            end(sp, true, "You let the vow go.");
            return;
        }
        if (!isSworn(sp)) {
            sp.displayClientMessage(Component.literal("\u00a7cYou have not sworn the vow: swear \"" + PHRASE + "\" on Jajanken in the Vows menu first"), true);
            return;
        }
        if (!Jajanken.canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Jajanken"), true);
            return;
        }
        if (c.getHatsuLevel() < MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cThe vow unlocks at Level " + MIN_LEVEL), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        if (Jajanken.isCharging(sp)) return;
        if (NenAddonData.get(sp).lifespan < YEARS_PER_SECOND) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough lifespan left to power the vow"), true);
            return;
        }
        float before = c.getCurrentEnergy();
        ACTIVE.add(sp.getUUID());
        STATE.put(sp.getUUID(), new State());
        Jajanken.say(sp, PHRASE);
        c.restoreEnergy(before * (STAT_MULT - 1f)); // the max is x10 now, so what was in the tank is x10 too
        applySpeed(sp, true);
        refresh(sp);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.6f, 0.5f);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.PLAYERS, 0.6f, 1.6f);
    }

    /** Nen debt levels so far (0 outside the form). */
    public static int debt(Player p) {
        State st = p == null ? null : STATE.get(p.getUUID());
        return st == null ? 0 : st.debt;
    }

    /** Game ticks the remaining lifespan can still power the form (0 outside the form). */
    public static long ticksLeft(ServerPlayer sp) {
        if (!STATE.containsKey(sp.getUUID())) return 0;
        return (long) (NenAddonData.get(sp).lifespan / YEARS_PER_SECOND * 20f);
    }

    /**
     * A vow Rock was charged: one more level of Nen debt. When the debt reaches {@link #NEN_LOSS_DEBT} the Nen is lost for good
     * (see {@link NenLoss}) and this returns true: the caller must drop the Rock it was about to start.
     */
    public static boolean addDebt(ServerPlayer sp) {
        State st = STATE.get(sp.getUUID());
        if (st == null) return false;
        st.debt++;
        if (st.debt >= NEN_LOSS_DEBT) {
            loseNen(sp);
            return true;
        }
        sp.displayClientMessage(Component.literal("\u00a74Nen debt " + st.debt + "/" + NEN_LOSS_DEBT + " \u00a77(the form will cost "
            + (LEVELS_PER_DEBT * st.debt) + " Levels; at " + NEN_LOSS_DEBT + " your Nen is lost)"), true);
        return false;
    }

    /**
     * The debt hit the limit: the form ends at once and the Nen goes with it. The Level cost is not charged on top (everything is
     * back to Level 1 anyway); the player is a fresh player who has to awaken their Nen again.
     */
    private static void loseNen(ServerPlayer sp) {
        if (ACTIVE.remove(sp.getUUID())) {
            STATE.remove(sp.getUUID());
            Jajanken.end(sp); // the Rock that was being charged is lost with it
            applySpeed(sp, false);
            refresh(sp);      // normal height again, the 10x Ren aura goes away
        }
        NenLoss.wipe(sp);
    }

    /**
     * Leaves the form, whatever the cause (toggled off, death, logout, a lost Hatsu). The debt is always paid:
     * {@link #LEVELS_PER_DEBT} Levels per debt level, and never less than one debt level's worth.
     * {@code alive}: put the energy tank back to normal size (not needed on death, the pool is refilled then).
     */
    private static void end(ServerPlayer sp, boolean alive, String why) {
        if (!ACTIVE.remove(sp.getUUID())) return;
        State st = STATE.remove(sp.getUUID());
        Jajanken.end(sp); // a Rock in the middle of charging is lost with it
        applySpeed(sp, false);
        Combat c = Combat.get(sp);
        int lost = 0, from = 0, to = 0;
        if (c != null) {
            if (alive) {
                float cur = c.getCurrentEnergy();
                c.consumeEnergy(cur - cur / STAT_MULT);
            }
            int debt = Math.max(MIN_DEBT_ON_END, st == null ? 0 : st.debt);
            from = c.getHatsuLevel();
            to = Math.max(1, from - LEVELS_PER_DEBT * debt);
            lost = from - to;
            c.setHatsuLevel(to);
            float over = c.getCurrentEnergy() - c.getMaxEnergy(); // a lower Level means a smaller tank
            if (over > 0) c.consumeEnergy(over);
        }
        refresh(sp);
        if (alive) {
            sp.displayClientMessage(Component.literal("\u00a77" + why + " \u00a74Nen debt paid: -" + lost + " Levels \u00a77(Level " + from + " to " + to + ")"), true);
            sp.sendSystemMessage(Component.literal("\u00a74The vow is over. Nen debt paid: you lost " + lost + " Levels (Level " + from + " to " + to + ")."));
        }
    }

    /** Death, logout, a lost Hatsu: the form ends and the debt is still paid. */
    public static void clear(ServerPlayer sp, boolean restoreEnergy) {
        if (ACTIVE.contains(sp.getUUID())) end(sp, restoreEnergy && sp.isAlive(), "");
    }

    /** Size, tracking clients and the Ren aura all follow the state. */
    private static void refresh(ServerPlayer sp) {
        sp.refreshDimensions();
        AddonNetwork.sendToTrackingAndSelf(new PacketVowFx(sp.getId(), ACTIVE.contains(sp.getUUID())), sp);
        NenAddonData d = NenAddonData.peek(sp);
        if (d != null) AbilityRegistry.setActiveAuraScale(sp, d.renScale()); // a Ren aura that is already out grows to 10x (or goes back)
    }

    /** A player who comes into view of someone in the form sees them tall at once. */
    public static void sendTo(ServerPlayer owner, ServerPlayer viewer) {
        if (ACTIVE.contains(owner.getUUID())) AddonNetwork.sendToPlayer(new PacketVowFx(owner.getId(), true), viewer);
    }

    private static void applySpeed(ServerPlayer sp, boolean on) {
        AttributeInstance inst = sp.getAttribute(Attributes.MOVEMENT_SPEED);
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(SPEED_ID);
        if (!on) {
            if (cur != null) inst.removeModifier(SPEED_ID);
            return;
        }
        // total speed bonus = Ren's x SPEED_VS_REN. The aura's own speed modifier (Ren, Ten...) is already on, so this one tops it up to that total.
        double amount = 0;
        NenAddonData d = NenAddonData.peek(sp);
        Combat c = Combat.get(sp);
        if (d != null && c != null) {
            double target = d.renSpeedBonus() * SPEED_VS_REN * Tuning.BUFF_SPEED_SCALE;
            double have = d.auraSpeedBonus(c) * Tuning.BUFF_SPEED_SCALE;
            amount = Math.max(0.0, (1.0 + target) / (1.0 + have) - 1.0);
        }
        if (cur != null && Math.abs(cur.getAmount() - amount) < 1e-6) return;
        if (cur != null) inst.removeModifier(SPEED_ID);
        if (amount > 1e-6) inst.addTransientModifier(new AttributeModifier(SPEED_ID, "Gon vow speed", amount, AttributeModifier.Operation.MULTIPLY_TOTAL));
    }

    // ---------------- per tick ----------------
    public static void tick(ServerPlayer sp) {
        if (!ACTIVE.contains(sp.getUUID())) return;
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive() || !Jajanken.canUse(c) || ExtrasHooks.hatsuForced(sp) || ChainManager.isJailed(sp) || !isSworn(sp)) {
            end(sp, sp.isAlive(), "The vow broke.");
            return;
        }
        if (sp.tickCount % 20 == 0) { // one second of the form: pay the years, die if there are none left
            NenAddonData d = NenAddonData.get(sp);
            d.lifespan = Math.max(0f, d.lifespan - YEARS_PER_SECOND);
            d.markSync();
            d.save(); // years are never refunded by a crash or relog
            if (d.lifespan <= 0.001f) {
                d.lifespan = 0f;
                sp.displayClientMessage(Component.literal("\u00a74Your lifespan is exhausted..."), true);
                sp.hurt(sp.level().damageSources().genericKill(), Float.MAX_VALUE);
                return;
            }
            long left = ticksLeft(sp) / 20;
            if (left == 30 || left == 10) {
                sp.displayClientMessage(Component.literal("\u00a74Your lifespan runs out in " + left + " seconds"), true);
            }
        }
        applySpeed(sp, true); // keeps it on through respawn-less changes (another mod clearing modifiers, for example)
    }

    /** A user charging Rock in this form is rooted: all sideways motion is cancelled (falling still works). */
    public static void freeze(ServerPlayer sp) {
        Vec3 m = sp.getDeltaMovement();
        if (m.x != 0 || m.z != 0) {
            sp.setDeltaMovement(0, m.y, 0);
            sp.hurtMarked = true;
        }
    }

    // ---------------- the crater ----------------
    /**
     * Every block inside a sphere of {@code radius} around the centre, nearest first. Built once per radius and kept: a 44 block sphere is
     * about 357,000 positions, packed in an int each (7 bits per axis) and sorted by distance.
     */
    private static int[] order;
    private static double orderRadius = -1;

    private static synchronized int[] orderFor(double radius) {
        if (order != null && orderRadius == radius) return order;
        int r = (int) Math.ceil(radius);
        long[] keys = new long[(2 * r + 1) * (2 * r + 1) * (2 * r + 1)];
        int n = 0;
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    long d2 = (long) x * x + (long) y * y + (long) z * z;
                    if (d2 > radius * radius) continue;
                    keys[n++] = (d2 << 32) | (((x + 64) << 14) | ((y + 64) << 7) | (z + 64));
                }
            }
        }
        Arrays.sort(keys, 0, n);
        int[] out = new int[n];
        for (int i = 0; i < n; i++) out[i] = (int) (keys[i] & 0xFFFFFFFFL);
        order = out;
        orderRadius = radius;
        return out;
    }

    private static final class Crater {
        ServerLevel level;
        BlockPos centre;
        int[] order;
        int next;
        /** Nothing below this height is touched (the user's feet minus {@link #CRATER_MAX_DEPTH}). */
        int minY;
    }

    private static final List<Crater> CRATERS = new ArrayList<>();

    /** Queues a crater: it is dug out over the next ticks (nearest blocks first) so a huge radius never stalls the server. */
    public static void startCrater(ServerLevel level, Vec3 centre, double radius, int userFeetY) {
        startCrater(level, centre, radius, userFeetY, CRATER_MAX_DEPTH);
    }

    /** Same, with its own limit on how far below the user's feet it may dig (Big Bang Impact digs a whole sphere). */
    public static void startCrater(ServerLevel level, Vec3 centre, double radius, int userFeetY, int maxDepth) {
        if (!CRATER) return;
        Crater c = new Crater();
        c.minY = userFeetY - maxDepth;
        c.level = level;
        c.centre = BlockPos.containing(centre);
        c.order = orderFor(radius);
        synchronized (CRATERS) { CRATERS.add(c); }
    }

    /** Called once per server tick. */
    public static void tickCraters() {
        synchronized (CRATERS) {
            if (CRATERS.isEmpty()) return;
            Iterator<Crater> it = CRATERS.iterator();
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
            BlockState air = Blocks.AIR.defaultBlockState();
            while (it.hasNext()) {
                Crater c = it.next();
                int broken = 0, reads = 0;
                while (c.next < c.order.length && broken < CRATER_BREAKS_PER_TICK && reads < CRATER_READS_PER_TICK) {
                    int k = c.order[c.next++];
                    reads++;
                    pos.set(c.centre.getX() + ((k >> 14) & 127) - 64, c.centre.getY() + ((k >> 7) & 127) - 64, c.centre.getZ() + (k & 127) - 64);
                    if (pos.getY() < c.minY || !c.level.isInWorldBounds(pos) || !c.level.hasChunkAt(pos)) continue;
                    BlockState st = c.level.getBlockState(pos);
                    if (st.isAir() || !st.getFluidState().isEmpty() || st.getDestroySpeed(c.level, pos) < 0
                        || st.getBlock().getExplosionResistance() > Jajanken.ROCK_BLOCK_POWER) continue;
                    // 2 = tell clients, 16 = no shape updates, 32 = no drops: a crater this size must not spawn thousands of items
                    c.level.setBlock(pos, air, 2 | 16 | 32);
                    broken++;
                }
                if (c.next >= c.order.length) it.remove();
            }
        }
    }

    public static void clearCraters() {
        synchronized (CRATERS) { CRATERS.clear(); }
    }
}
