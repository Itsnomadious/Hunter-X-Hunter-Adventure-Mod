package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.animal.AbstractGolem;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.monster.Vex;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.level.BlockEvent;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketBlinkyFx;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Shizuku Murasaki's Blinky (Hatsu kit 26, Conjurers): a conjured vacuum cleaner that sucks up anything.
 *
 * <ol>
 *   <li><b>H</b> conjures the vacuum cleaner (or puts it away). The head, with its toothed mouth, is a held item that belongs to you
 *       ({@link BlinkyHeadItem}); the canister and its hose are drawn by the client while the head is in your hand.</li>
 *   <li><b>Attack, Strong attack and Barrage</b> are replaced by swings of Blinky's head while it is in your hand (a left-click on a
 *       creature does the same). Every enemy the head hits is <b>bitten</b>: marked for {@link BlinkyTuning#MARK_TICKS} ticks.</li>
 *   <li><b>Hold right-click</b> and the mouth sucks up the blocks in front of it, nearest first. They are gone: <b>no item drops</b>, and
 *       whatever would have fallen off them is swallowed too.</li>
 *   <li><b>Exsanguinate</b> (Z): the head latches onto the enemy it has bitten and drinks its blood for a few seconds: bite after bite of
 *       blood loss that ignores armour, with Weakness and Slowness as the victim runs dry. Undead, constructs and slimes have none.</li>
 * </ol>
 * Everything is decided on the server; clients only draw ({@link PacketBlinkyFx}, {@code client.BlinkyFx}, {@code client.BlinkyRenderer}).
 * Forge hooks: {@link BlinkyEvents}.
 */
public final class Blinky {
    private Blinky() {}

    public static final int KIT = 26;
    public static final String ID = "blinky";
    public static final String DRAIN_ID = "blinky_drain";
    private static final String NAME = "Blinky";

    private static final String OWNER_TAG = "Owner";
    private static final ParticleOptions BLOOD = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState());

    private static final class State {
        boolean out;
        int cd;                       // toggle cooldown
        long swingReady;              // game time
        long barrageReady;
        int strongStart = -1;
        int strongLast = -100;
        UUID mark;                    // the enemy the head has bitten
        long markUntil;
        long drainReady;              // game time Exsanguinate is ready again
        UUID drainTarget;
        int drainLeft;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    private static State state(ServerPlayer sp) {
        return STATES.computeIfAbsent(sp.getUUID(), k -> new State());
    }

    private static void msg(ServerPlayer sp, String text) {
        sp.displayClientMessage(Component.literal(text), true);
    }

    private static void sound(ServerLevel level, Entity at, SoundEvent ev, float vol, float pitch) {
        level.playSound(null, at.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }

    private static boolean hostile(ServerPlayer sp, Entity e) {
        if (!(e instanceof LivingEntity le) || le == sp || !le.isAlive() || e instanceof ArmorStand) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        return !AllianceUtils.isAlly(e, sp);
    }

    /** Common checks for everything Blinky does. Returns the player's Combat, or null (after telling them why). */
    private static Combat gate(ServerPlayer sp, int minLevel, String what) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return null;
        if (!canUse(c)) {
            msg(sp, "§cYour Hatsu is not Blinky");
            return null;
        }
        if (c.getHatsuLevel() < minLevel) {
            msg(sp, "§c" + what + " unlocks at Level " + minLevel);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            msg(sp, "§5Forced Zetsu: Blinky will not answer");
            return null;
        }
        if (HatsuEffects.isStunned(sp)) return null;
        return c;
    }

    private static boolean pay(ServerPlayer sp, Combat c, float cost) {
        if (c.getCurrentEnergy() < cost) {
            msg(sp, "§cNot enough energy");
            return false;
        }
        c.consumeEnergy(cost);
        return true;
    }

    // ---------------------------------------------------------------- the head (a held item that belongs to you)

    public static boolean isHead(ItemStack st) {
        return !st.isEmpty() && BlinkyItems.HEAD != null && st.is(BlinkyItems.HEAD);
    }

    public static UUID headOwner(ItemStack st) {
        return isHead(st) && st.hasTag() && st.getTag().hasUUID(OWNER_TAG) ? st.getTag().getUUID(OWNER_TAG) : null;
    }

    public static boolean isOwnHead(ItemStack st, Player p) {
        return p.getUUID().equals(headOwner(st));
    }

    /** The hand that holds this player's Blinky (main hand first), or null. */
    public static InteractionHand heldIn(Player p) {
        if (isOwnHead(p.getMainHandItem(), p)) return InteractionHand.MAIN_HAND;
        if (isOwnHead(p.getOffhandItem(), p)) return InteractionHand.OFF_HAND;
        return null;
    }

    public static boolean holdingHead(Player p) {
        return heldIn(p) != null;
    }

    private static boolean hasHead(Player p) {
        for (ItemStack st : p.getInventory().items) if (isOwnHead(st, p)) return true;
        for (ItemStack st : p.getInventory().offhand) if (isOwnHead(st, p)) return true;
        return false;
    }

    private static void giveHead(ServerPlayer sp) {
        if (hasHead(sp)) return;
        ItemStack st = new ItemStack(BlinkyItems.HEAD);
        st.getOrCreateTag().putUUID(OWNER_TAG, sp.getUUID());
        st.getOrCreateTag().putString("OwnerName", sp.getName().getString());
        if (sp.getMainHandItem().isEmpty()) sp.setItemInHand(InteractionHand.MAIN_HAND, st);
        else if (sp.getOffhandItem().isEmpty()) sp.setItemInHand(InteractionHand.OFF_HAND, st);
        else if (!sp.getInventory().add(st)) sp.drop(st, false);
    }

    /** Takes every head belonging to this player out of their inventory. */
    public static void removeHeads(ServerPlayer sp) {
        for (int i = 0; i < sp.getInventory().items.size(); i++) {
            if (isOwnHead(sp.getInventory().items.get(i), sp)) sp.getInventory().items.set(i, ItemStack.EMPTY);
        }
        for (int i = 0; i < sp.getInventory().offhand.size(); i++) {
            if (isOwnHead(sp.getInventory().offhand.get(i), sp)) sp.getInventory().offhand.set(i, ItemStack.EMPTY);
        }
    }

    /** The owner died or the head was dropped: the conjured head never lies on the ground. */
    public static void stripHeadDrops(java.util.Collection<ItemEntity> drops) {
        drops.removeIf(ie -> isHead(ie.getItem()));
    }

    // ---------------------------------------------------------------- list entries

    /** Adds Blinky (conjure) and Exsanguinate to the Z scroll once the Hatsu level allows it. */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < BlinkyTuning.MIN_LEVEL) return base;
        boolean drain = c.getHatsuLevel() >= BlinkyTuning.DRAIN_MIN_LEVEL;
        String[] out = Arrays.copyOf(base, base.length + (drain ? 2 : 1));
        out[base.length] = ID;
        if (drain) out[base.length + 1] = DRAIN_ID;
        return out;
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(ID, Blinky::toggle);
        m.put(DRAIN_ID, Blinky::drain);
    }

    public static String displayName(String id) {
        return switch (id) {
            case ID -> "§3 Blinky";
            case DRAIN_ID -> "§4 Blinky: Exsanguinate";
            default -> null;
        };
    }

    // ---------------------------------------------------------------- H: conjure / put away

    public static void toggle(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        if (!canUse(c)) {
            msg(sp, "§cYour Hatsu is not Blinky");
            return;
        }
        if (c.getHatsuLevel() < BlinkyTuning.MIN_LEVEL) {
            msg(sp, "§c" + NAME + " unlocks at Level " + BlinkyTuning.MIN_LEVEL);
            return;
        }
        State s = state(sp);
        if (hasHead(sp)) {
            putAway(sp, s, "§7Blinky put away");
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            msg(sp, "§5Forced Zetsu: Blinky will not answer");
            return;
        }
        if (HatsuEffects.isStunned(sp)) return;
        if (ChainManager.onCooldown(sp, NAME, s.cd)) return;
        if (!pay(sp, c, BlinkyTuning.CONJURE_COST)) return;
        s.cd = BlinkyTuning.TOGGLE_COOLDOWN_TICKS;
        s.out = true;
        giveHead(sp);
        if (sp.level() instanceof ServerLevel level) {
            Vec3 p = sp.position();
            level.sendParticles(ParticleTypes.CLOUD, p.x, p.y + 0.8, p.z, 18, 0.5, 0.4, 0.5, 0.05);
            level.sendParticles(ParticleTypes.ENCHANT, p.x, p.y + 1.1, p.z, 24, 0.5, 0.6, 0.5, 0.4);
            sound(level, sp, SoundEvents.BEACON_ACTIVATE, 0.6f, 1.8f);
            sound(level, sp, SoundEvents.PISTON_CONTRACT, 0.8f, 1.4f);
        }
        msg(sp, "§3Blinky: §fswing to bite, hold right-click to suck, Z to Exsanguinate");
    }

    private static void putAway(ServerPlayer sp, State s, String message) {
        endDrain(sp, s, false);
        removeHeads(sp);
        s.out = false;
        s.cd = BlinkyTuning.TOGGLE_COOLDOWN_TICKS;
        sp.stopUsingItem();
        if (sp.level() instanceof ServerLevel level) {
            sound(level, sp, SoundEvents.PISTON_EXTEND, 0.7f, 1.6f);
        }
        if (message != null) msg(sp, message);
    }

    // ---------------------------------------------------------------- the swing

    private static boolean armIsLeft(ServerPlayer sp) {
        InteractionHand hand = heldIn(sp);
        boolean mainIsLeft = sp.getMainArm() == HumanoidArm.LEFT;
        return hand == InteractionHand.OFF_HAND ? !mainIsLeft : mainIsLeft;
    }

    private static void fx(ServerPlayer sp, int kind, int ticks) {
        AddonNetwork.sendToTrackingAndSelf(new PacketBlinkyFx(sp.getId(), kind, armIsLeft(sp), ticks), sp);
    }

    /**
     * Called before every ability runs (AbilityRegistryMixin). While Blinky is in hand, the user's three basic attacks are swings of its
     * head instead, and this returns true (the normal attack is cancelled).
     */
    public static boolean interceptBasic(String id, ServerPlayer sp) {
        if (!"nen_attack".equals(id) && !"nen_strong".equals(id) && !"nen_strong_release".equals(id) && !"nen_barrage".equals(id)) return false;
        Combat c = Combat.get(sp);
        if (!canUse(c) || !holdingHead(sp)) return false;
        State s = state(sp);
        switch (id) {
            case "nen_attack" -> swingLight(sp);
            case "nen_strong" -> {
                if (sp.tickCount - s.strongLast > 5 || s.strongStart < 0) s.strongStart = sp.tickCount; // a fresh charge
                s.strongLast = sp.tickCount;
            }
            case "nen_strong_release" -> {
                int start = s.strongStart;
                s.strongStart = -1;
                if (start < 0) return true;
                float progress = Math.min(1f, (sp.tickCount - start) / (float) BlinkyTuning.STRONG_CHARGE_TICKS);
                swingHeavy(sp, progress);
            }
            case "nen_barrage" -> swingBarrage(sp);
            default -> { }
        }
        return true;
    }

    /** A left-click on a creature with Blinky in hand (BlinkyEvents): the head swings instead. */
    public static void swingLight(ServerPlayer sp) {
        Combat c = gate(sp, BlinkyTuning.MIN_LEVEL, NAME);
        if (c == null) return;
        State s = state(sp);
        long now = sp.level().getGameTime();
        if (now < s.swingReady) return;
        s.swingReady = now + BlinkyTuning.SWING_COOLDOWN_TICKS;
        swing(sp, c, s, 1f, 0.0, BlinkyTuning.SWING_MAX_TARGETS, 0.0, PacketBlinkyFx.SWING);
    }

    private static void swingHeavy(ServerPlayer sp, float progress) {
        Combat c = gate(sp, BlinkyTuning.MIN_LEVEL, NAME);
        if (c == null) return;
        State s = state(sp);
        long now = sp.level().getGameTime();
        if (now < s.swingReady) return;
        s.swingReady = now + BlinkyTuning.SWING_COOLDOWN_TICKS + Math.round(progress * 8f);
        float mult = 1f + (BlinkyTuning.STRONG_DAMAGE_MULT - 1f) * progress;
        swing(sp, c, s, mult, BlinkyTuning.STRONG_EXTRA_REACH * progress,
            progress >= 1f ? BlinkyTuning.STRONG_MAX_TARGETS : BlinkyTuning.SWING_MAX_TARGETS,
            BlinkyTuning.STRONG_EXTRA_KNOCKBACK * progress, progress >= 0.5f ? PacketBlinkyFx.HEAVY : PacketBlinkyFx.SWING);
    }

    private static void swingBarrage(ServerPlayer sp) {
        Combat c = gate(sp, BlinkyTuning.MIN_LEVEL, NAME);
        if (c == null) return;
        State s = state(sp);
        long now = sp.level().getGameTime();
        if (now < s.barrageReady) return;
        s.barrageReady = now + BlinkyTuning.BARRAGE_COOLDOWN_TICKS;
        swing(sp, c, s, BlinkyTuning.BARRAGE_DAMAGE_MULT, 0.0, BlinkyTuning.SWING_MAX_TARGETS, 0.0, PacketBlinkyFx.SWING);
    }

    /** One sweep of the head: everything hostile inside the arc in front of the user is struck, and the nearest one is bitten (marked). */
    private static void swing(ServerPlayer sp, Combat c, State s, float mult, double extraReach, int maxTargets, double extraKb, int kind) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        endDrainIfSwinging(sp, s);
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle();
        double reach = BlinkyTuning.SWING_REACH + extraReach;
        double cosArc = Math.cos(Math.toRadians(BlinkyTuning.SWING_ARC_DEGREES));

        List<LivingEntity> hits = new ArrayList<>();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(reach + 1.0), e -> hostile(sp, e))) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            double d = to.length();
            if (d > reach + e.getBbWidth() * 0.5) continue;
            if (d > 0.9 && to.normalize().dot(look) < cosArc) continue;
            if (!sp.hasLineOfSight(e)) continue;
            hits.add(e);
        }
        hits.sort(Comparator.comparingDouble(e -> e.distanceToSqr(sp)));

        sp.swing(heldIn(sp) == null ? InteractionHand.MAIN_HAND : heldIn(sp), true);
        fx(sp, kind, 0);
        Vec3 front = eye.add(look.scale(2.0));
        level.sendParticles(ParticleTypes.SWEEP_ATTACK, front.x, front.y - 0.3, front.z, 1, 0, 0, 0, 0);
        sound(level, sp, SoundEvents.PLAYER_ATTACK_SWEEP, 0.9f, 0.75f);
        if (hits.isEmpty()) return;

        float dmg = (BlinkyTuning.SWING_DAMAGE + c.getHatsuLevel() * BlinkyTuning.SWING_DAMAGE_PER_LEVEL) * c.getSpiritBonus() * mult;
        int n = 0;
        for (LivingEntity e : hits) {
            if (n++ >= maxTargets) break;
            hurt(sp, e, dmg, level.damageSources().playerAttack(sp));
            e.knockback(BlinkyTuning.SWING_KNOCKBACK + extraKb, sp.getX() - e.getX(), sp.getZ() - e.getZ());
            e.hurtMarked = true;
            Vec3 at = e.position().add(0, e.getBbHeight() * 0.6, 0);
            level.sendParticles(ParticleTypes.DAMAGE_INDICATOR, at.x, at.y, at.z, 4, 0.25, 0.3, 0.25, 0.1);
        }
        sound(level, sp, SoundEvents.GENERIC_EAT, 0.9f, 0.6f);
        sound(level, sp, SoundEvents.PLAYER_ATTACK_CRIT, 0.6f, 1.1f);

        // the nearest one is bitten: Exsanguinate can take its blood now
        LivingEntity bitten = hits.get(0);
        if (bitten.isAlive()) {
            boolean fresh = !bitten.getUUID().equals(s.mark);
            s.mark = bitten.getUUID();
            s.markUntil = level.getGameTime() + BlinkyTuning.MARK_TICKS;
            if (fresh && c.getHatsuLevel() >= BlinkyTuning.DRAIN_MIN_LEVEL) {
                msg(sp, "§4Blinky bit " + bitten.getDisplayName().getString() + " §7- Z: Exsanguinate");
            }
        }
    }

    private static void hurt(ServerPlayer sp, LivingEntity e, float amount, net.minecraft.world.damagesource.DamageSource src) {
        e.invulnerableTime = 0;
        Vows.hatsuHurt(e, src, amount * Vows.hatsuDamageMult(sp)); // the Hatsu skill: more damage
    }

    // ---------------------------------------------------------------- suction (right-click held, driven by BlinkyHeadItem)

    /** Every tick the right button is held with Blinky in hand (server). Pulls blocks in every {@link BlinkyTuning#SUCK_INTERVAL_TICKS}. */
    public static void suckTick(ServerPlayer sp) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        Combat c = Combat.get(sp);
        if (!canUse(c) || c.getHatsuLevel() < BlinkyTuning.MIN_LEVEL || ExtrasHooks.hatsuForced(sp) || HatsuEffects.isStunned(sp)
            || sp.isSpectator() || !holdingHead(sp)) {
            sp.stopUsingItem();
            return;
        }
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle();
        // the dust always streams into the mouth, even when there is nothing left to take
        if (sp.tickCount % 2 == 0) {
            Vec3 mouth = eye.add(look.scale(1.4)).add(0, -0.35, 0);
            for (int i = 0; i < 2; i++) {
                double d = 2.0 + level.random.nextDouble() * 3.0;
                double spread = d * 0.22;
                Vec3 from = eye.add(look.scale(d)).add((level.random.nextDouble() - 0.5) * spread * 2, (level.random.nextDouble() - 0.5) * spread * 2 - 0.3,
                    (level.random.nextDouble() - 0.5) * spread * 2);
                Vec3 dir = mouth.subtract(from);
                level.sendParticles(ParticleTypes.CLOUD, from.x, from.y, from.z, 0, dir.x, dir.y, dir.z, 0.12);
            }
        }
        if (sp.getTicksUsingItem() % BlinkyTuning.SUCK_INTERVAL_TICKS != 0) return;
        sound(level, sp, SoundEvents.ENDER_DRAGON_FLAP, 0.25f, 1.9f);

        List<BlockPos> candidates = candidates(sp, level, eye, look);
        int taken = 0;
        List<BlockPos> removed = new ArrayList<>();
        for (BlockPos pos : candidates) {
            if (taken >= BlinkyTuning.SUCK_BLOCKS_PER_PULSE) break;
            BlockState st = level.getBlockState(pos);
            float cost = BlinkyTuning.SUCK_BASE_COST + Math.max(0f, st.getDestroySpeed(level, pos)) * BlinkyTuning.SUCK_COST_PER_HARDNESS;
            if (!visible(sp, level, eye, pos)) continue;
            if (!sp.isCreative()) {
                if (c.getCurrentEnergy() < cost) {
                    msg(sp, "§cNot enough energy");
                    sp.stopUsingItem();
                    break;
                }
            }
            if (MinecraftForge.EVENT_BUS.post(new BlockEvent.BreakEvent(level, pos, st, sp))) continue; // protected land, claims, other mods
            if (!sp.isCreative()) c.consumeEnergy(cost);
            level.levelEvent(2001, pos, Block.getId(st)); // the break sound and crumbs
            level.removeBlock(pos, false);                // no drops: nothing here goes through the loot table
            removed.add(pos);
            taken++;
            Vec3 at = Vec3.atCenterOf(pos);
            Vec3 dir = eye.add(look.scale(1.2)).subtract(at);
            level.sendParticles(ParticleTypes.POOF, at.x, at.y, at.z, 0, dir.x, dir.y, dir.z, 0.25);
        }
        if (taken > 0 && BlinkyTuning.SWALLOW_DEPENDENT_DROPS) swallowDrops(level, removed);
        if (taken > 0) sound(level, sp, SoundEvents.GENERIC_EAT, 0.4f, 0.5f);
    }

    /** Blocks the mouth can take right now, nearest first: inside the cone, breakable, and with at least one open face. */
    private static List<BlockPos> candidates(ServerPlayer sp, ServerLevel level, Vec3 eye, Vec3 look) {
        double range = BlinkyTuning.SUCK_RANGE;
        double cos = Math.cos(Math.toRadians(BlinkyTuning.SUCK_CONE_DEGREES));
        Vec3 centre = eye.add(look.scale(range * 0.5));
        int r = (int) Math.ceil(range * 0.5) + 1;
        int cx = (int) Math.floor(centre.x), cy = (int) Math.floor(centre.y), cz = (int) Math.floor(centre.z);
        List<BlockPos> out = new ArrayList<>();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = cx - r; x <= cx + r; x++) {
            for (int y = cy - r; y <= cy + r; y++) {
                for (int z = cz - r; z <= cz + r; z++) {
                    m.set(x, y, z);
                    double dx = x + 0.5 - eye.x, dy = y + 0.5 - eye.y, dz = z + 0.5 - eye.z;
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d > range || d < 0.6) continue;
                    // close to the face the cone is wider: a block half a metre away is always "in front"
                    if (d > 1.6 && (dx * look.x + dy * look.y + dz * look.z) / d < cos) continue;
                    BlockState st = level.getBlockState(m);
                    if (st.isAir() || st.getBlock() instanceof LiquidBlock) continue;
                    float hard = st.getDestroySpeed(level, m);
                    if (hard < 0f || hard > BlinkyTuning.SUCK_MAX_HARDNESS) continue; // bedrock and the like
                    if (st.hasBlockEntity() && !BlinkyTuning.SUCK_BLOCK_ENTITIES) continue;
                    if (!level.mayInteract(sp, m) || !sp.mayBuild()) continue;
                    if (!exposed(level, m)) continue;
                    out.add(m.immutable());
                }
            }
        }
        out.sort(Comparator.comparingDouble(p -> Vec3.atCenterOf(p).distanceToSqr(eye)));
        return out;
    }

    private static boolean exposed(ServerLevel level, BlockPos pos) {
        for (net.minecraft.core.Direction d : net.minecraft.core.Direction.values()) {
            BlockState n = level.getBlockState(pos.relative(d));
            if (n.isAir() || !n.canOcclude() || n.getBlock() instanceof LiquidBlock) return true;
        }
        return false;
    }

    /** Is this block the first thing the eye sees along the line to it? (No pulling things out through walls.) */
    private static boolean visible(ServerPlayer sp, ServerLevel level, Vec3 eye, BlockPos pos) {
        BlockHitResult hit = level.clip(new ClipContext(eye, Vec3.atCenterOf(pos), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, sp));
        return hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(pos);
    }

    /** Whatever popped off the blocks that were just sucked up goes into the vacuum cleaner as well. */
    private static void swallowDrops(ServerLevel level, List<BlockPos> removed) {
        for (BlockPos p : removed) {
            for (ItemEntity ie : level.getEntitiesOfClass(ItemEntity.class, new AABB(p).inflate(1.0), ie -> ie.getAge() <= 2)) {
                ie.discard();
            }
        }
    }

    // ---------------------------------------------------------------- Exsanguinate

    private static LivingEntity markedTarget(State s, ServerLevel level) {
        if (s.mark == null || level.getGameTime() > s.markUntil) return null;
        return level.getEntity(s.mark) instanceof LivingEntity le && le.isAlive() ? le : null;
    }

    private static boolean bloodless(LivingEntity e) {
        return e.getMobType() == MobType.UNDEAD || e instanceof AbstractGolem || e instanceof Slime || e instanceof Blaze
            || e instanceof Ghast || e instanceof Vex;
    }

    /** Z: the head latches onto the enemy it has bitten and drinks. Pressing it again lets go. */
    public static void drain(ServerPlayer sp) {
        Combat c = gate(sp, BlinkyTuning.DRAIN_MIN_LEVEL, "Exsanguinate");
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        State s = state(sp);
        if (s.drainTarget != null) {
            endDrain(sp, s, true);
            return;
        }
        if (!holdingHead(sp)) {
            msg(sp, "§cHold Blinky to Exsanguinate");
            return;
        }
        long now = level.getGameTime();
        if (now < s.drainReady) {
            ChainManager.onCooldown(sp, "Exsanguinate", (int) (s.drainReady - now));
            return;
        }
        LivingEntity t = markedTarget(s, level);
        if (t == null) {
            msg(sp, "§cBite an enemy with Blinky first");
            return;
        }
        if (sp.distanceTo(t) > BlinkyTuning.DRAIN_RANGE) {
            msg(sp, "§cToo far from the one Blinky bit");
            return;
        }
        if (BlinkyTuning.BLOODLESS_IMMUNE && bloodless(t)) {
            msg(sp, "§7" + t.getDisplayName().getString() + " has no blood to take");
            return;
        }
        if (!pay(sp, c, BlinkyTuning.DRAIN_COST)) return;
        s.drainTarget = t.getUUID();
        s.drainLeft = BlinkyTuning.DRAIN_TICKS;
        s.drainReady = now + BlinkyTuning.DRAIN_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, "Exsanguinate", BlinkyTuning.DRAIN_COOLDOWN_TICKS);
        fx(sp, PacketBlinkyFx.DRAIN, BlinkyTuning.DRAIN_TICKS);
        sound(level, t, SoundEvents.GENERIC_EAT, 1.0f, 0.5f);
        sound(level, t, SoundEvents.WARDEN_HEARTBEAT, 1.0f, 1.0f);
        msg(sp, "§4Exsanguinate");
        if (t instanceof ServerPlayer tp) {
            tp.sendSystemMessage(Component.literal("§4" + sp.getName().getString() + "'s vacuum cleaner has latched onto you and is drinking your blood"));
        }
    }

    private static void endDrain(ServerPlayer sp, State s, boolean message) {
        if (s.drainTarget == null) return;
        UUID id = s.drainTarget;
        s.drainTarget = null;
        s.drainLeft = 0;
        if (sp.level() instanceof ServerLevel level) {
            if (level.getEntity(id) instanceof LivingEntity t) {
                if (BlinkyTuning.DRAIN_HOLDS_VICTIM) HatsuEffects.removeStun(t);
            }
        }
        fx(sp, PacketBlinkyFx.STOP, 0);
        if (message) msg(sp, "§7Blinky lets go");
    }

    /** Swinging the head (or anything else that moves it) while it is latched on tears it off. */
    private static void endDrainIfSwinging(ServerPlayer sp, State s) {
        if (s.drainTarget != null) endDrain(sp, s, true);
    }

    private static void drainTick(ServerPlayer sp, State s, ServerLevel level, Combat c) {
        LivingEntity t = level.getEntity(s.drainTarget) instanceof LivingEntity le && le.isAlive() ? le : null;
        if (t == null || !holdingHead(sp) || ExtrasHooks.hatsuForced(sp) || sp.distanceTo(t) > BlinkyTuning.DRAIN_RANGE + 1.5) {
            endDrain(sp, s, t != null);
            return;
        }
        if (BlinkyTuning.DRAIN_HOLDS_VICTIM) HatsuEffects.stun(t, 8);
        s.drainLeft--;

        // the blood runs from the victim into the mouth
        if (sp.tickCount % 2 == 0) {
            Vec3 from = t.position().add(0, t.getBbHeight() * 0.6, 0);
            Vec3 to = sp.getEyePosition().add(sp.getLookAngle().scale(1.2)).add(0, -0.4, 0);
            for (int i = 0; i <= 6; i++) {
                Vec3 at = from.lerp(to, i / 6.0);
                level.sendParticles(BLOOD, at.x, at.y, at.z, 1, 0.06, 0.06, 0.06, 0.0);
            }
        }
        if (s.drainLeft % BlinkyTuning.DRAIN_INTERVAL_TICKS == 0) {
            float dmg = t.getMaxHealth() * BlinkyTuning.DRAIN_HEALTH_SHARE + BlinkyTuning.DRAIN_FLAT_DAMAGE
                + c.getHatsuLevel() * BlinkyTuning.DRAIN_DAMAGE_PER_LEVEL;
            // blood loss: magic damage, so armour does not help, and the kill is the user's
            hurt(sp, t, dmg, level.damageSources().indirectMagic(sp, sp));
            t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, BlinkyTuning.ANAEMIA_TICKS, 1, false, true));
            t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, BlinkyTuning.ANAEMIA_TICKS, 1, false, true));
            Vec3 at = t.position().add(0, t.getBbHeight() * 0.6, 0);
            level.sendParticles(BLOOD, at.x, at.y, at.z, 10, 0.25, 0.3, 0.25, 0.1);
            sound(level, t, SoundEvents.GENERIC_EAT, 0.6f, 0.5f);
        }
        if (s.drainLeft <= 0 || !t.isAlive()) endDrain(sp, s, false);
    }

    // ---------------------------------------------------------------- per tick

    public static void serverTick(MinecraftServer server) {
        if (server == null || STATES.isEmpty()) return;
        long gameTick = server.getTickCount();
        for (Map.Entry<UUID, State> en : new ArrayList<>(STATES.entrySet())) {
            State s = en.getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null) {
                STATES.remove(en.getKey());
                continue;
            }
            Combat c = Combat.get(sp);
            if (!sp.isAlive() || !canUse(c) || ExtrasHooks.hatsuForced(sp)) {
                clear(sp);
                continue;
            }
            if (!(sp.level() instanceof ServerLevel level)) continue;
            if (s.cd > 0) s.cd--;
            if (s.out && gameTick % 10 == 0 && !hasHead(sp)) { // dropped in a container, swapped away: it is gone
                s.out = false;
                endDrain(sp, s, false);
            }
            if (s.drainTarget != null) drainTick(sp, s, level, c);
            if (s.mark != null) {
                LivingEntity t = markedTarget(s, level);
                if (t == null) {
                    s.mark = null;
                } else if (gameTick % 10 == 0) {
                    level.sendParticles(BLOOD, t.getX(), t.getY() + t.getBbHeight() + 0.35, t.getZ(), 3, 0.15, 0.05, 0.15, 0.0);
                }
            }
        }
    }

    // ---------------------------------------------------------------- ending

    /** Death, losing the Hatsu, Forced Zetsu, logging out: Blinky goes and so does whatever it was holding. */
    public static void clear(ServerPlayer sp) {
        State s = STATES.remove(sp.getUUID());
        if (s != null) {
            if (s.drainTarget != null && sp.level() instanceof ServerLevel level && level.getEntity(s.drainTarget) instanceof LivingEntity t) {
                HatsuEffects.removeStun(t);
            }
            if (s.out) sp.stopUsingItem();
        }
        removeHeads(sp);
    }

    /** Anything with this Hatsu in the hand when the server starts up again is a stray from a previous run. */
    public static void onLogin(ServerPlayer sp) {
        removeHeads(sp);
    }

    public static void reset() {
        STATES.clear();
    }
}
