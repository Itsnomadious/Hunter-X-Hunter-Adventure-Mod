package net.hxhadventure.addon;

/** Numbers for Machi's Nen Stitches (Hatsu kit 25, Transmuters). Change them here; nothing else needs to change to rebalance. */
public final class NenStitchesTuning {
    private NenStitchesTuning() {}

    // ---- unlocks (Hatsu level) ----
    /** H (Nen Threads mode: the three basic attacks become thread slashes). */
    public static final int THREADS_MIN_LEVEL = 1;
    public static final int TRAP_MIN_LEVEL = 10;
    public static final int BIND_MIN_LEVEL = 20;
    public static final int SEW_MIN_LEVEL = 30;

    // ---- slashes (H mode: Attack / Strong attack / Barrage) ----
    /** Attack and Barrage: the slash covers this many blocks ahead and this many blocks across. */
    public static final double SLASH_LENGTH = 6.0;
    public static final double SLASH_WIDTH = 3.0;
    /** Strong attack: 12 blocks of range (the width stays the same). */
    public static final double STRONG_LENGTH = 12.0;
    public static final double STRONG_WIDTH = 3.0;
    /** The slash reaches from this far below the user's feet to this far above them. */
    public static final double SLASH_BELOW = 0.5;
    public static final double SLASH_ABOVE = 2.5;

    public static final float ATTACK_DAMAGE = 6f;
    public static final float ATTACK_COST = 8f;
    public static final int ATTACK_COOLDOWN_TICKS = 10;
    public static final double ATTACK_KNOCKBACK = 0.4;

    public static final float STRONG_DAMAGE = 18f;
    public static final float STRONG_COST = 40f;
    /** Hold the key this long for a full-power strong slash. Releasing early still slashes, with less damage (never below the Attack's). */
    public static final int STRONG_CHARGE_TICKS = 30;
    public static final int STRONG_COOLDOWN_TICKS = 30;
    public static final double STRONG_KNOCKBACK = 1.0;

    public static final float BARRAGE_DAMAGE = 2.5f;
    public static final float BARRAGE_COST = 3f;
    /** Ticks between the slashes of a barrage. */
    public static final int BARRAGE_INTERVAL_TICKS = 3;
    public static final int BARRAGE_MAX_TICKS = 60;
    public static final int BARRAGE_COOLDOWN_TICKS = 40;
    public static final double BARRAGE_KNOCKBACK = 0.15;

    // ---- Nen Thread Trap (Z, once to anchor the first thread, again to connect it) ----
    /** How far away a block can be to anchor a thread on it. */
    public static final double TRAP_PLACE_RANGE = 24.0;
    public static final double TRAP_MIN_LENGTH = 1.0;
    public static final double TRAP_MAX_LENGTH = 16.0;
    /** Traps one user can have out at once; the next one is refused until one is sprung. */
    public static final int TRAP_MAX_ACTIVE = 8;
    /** Paid when the second anchor is placed (the first is free). */
    public static final float TRAP_COST = 60f;
    public static final int TRAP_COOLDOWN_TICKS = 10;
    /** Hold Shift+Z (with Nen Thread Trap selected) this long to remove every thread you have out (3 s). */
    public static final int CLEAR_HOLD_TICKS = 60;
    public static final float TRAP_BASE_DAMAGE = 12f;
    public static final float TRAP_DAMAGE_PER_LEVEL = 0.4f;
    /** A first anchor that is never connected is forgotten after this long (1 minute). */
    public static final int TRAP_PENDING_TICKS = 1200;
    /** A thread left alone breaks after this long. 0 = never (it stays until something walks through it, or its owner dies / logs out). */
    public static final int TRAP_LIFETIME_TICKS = 0;
    /** true: the user also sees their own threads without Gyo. The spec: invisible unless using Gyo, so false. */
    public static final boolean OWNER_SEES_TRAPS = false;
    /** How far from a player the server tells that player about threads (blocks). */
    public static final double TRAP_SYNC_RANGE = 128.0;

    // ---- Binding (Z at someone: 3 seconds; hold Z within 2 blocks: up to 10 seconds) ----
    public static final double BIND_RANGE = 12.0;
    public static final int BIND_BASE_TICKS = 60;
    public static final int BIND_MAX_TICKS = 200;
    /** To keep holding past the base time the user must hold Z, look at the target and stay within this many blocks. */
    public static final double BIND_HOLD_RANGE = 2.0;
    public static final float BIND_COST = 80f;
    /** Aura per second while the hold keeps the bind going past the base time. */
    public static final float BIND_HOLD_UPKEEP = 30f;
    public static final int BIND_COOLDOWN_TICKS = 160;

    // ---- Wound Sewing (hold Z at someone; hold Shift+Z for yourself) ----
    public static final double SEW_RANGE = 5.0;
    /** One pulse of healing every this many ticks. */
    public static final int SEW_PULSE_TICKS = 10;
    /** Health per pulse: base + Hatsu level x per level (level 30 = 2.5 per half second, level 100 = 6). */
    public static final float SEW_BASE_HEAL = 1.0f;
    public static final float SEW_HEAL_PER_LEVEL = 0.05f;
    /** Aura per pulse that actually heals someone (a full-health target costs nothing). */
    public static final float SEW_PULSE_COST = 10f;
    public static final float SEW_MIN_ENERGY = 20f;
    public static final int SEW_COOLDOWN_TICKS = 20;
    /** false: hostile mobs cannot be sewn up. Players and every other creature can. */
    public static final boolean SEW_HEALS_MONSTERS = false;
}
