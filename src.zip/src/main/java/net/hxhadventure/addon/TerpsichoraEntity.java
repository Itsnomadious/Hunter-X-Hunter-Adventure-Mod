package net.hxhadventure.addon;

import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Terpsichora: the 5 block tall Nen dancer. Her hands are always out; a thread runs from each finger to the arms of her user
 * (drawn client-side by TerpsichoraThreadLayer). She fights whatever her user is fighting and dies with her user.
 */
public class TerpsichoraEntity extends PathfinderMob implements GeoEntity {
    private static final EntityDataAccessor<Integer> OWNER_ID = SynchedEntityData.defineId(TerpsichoraEntity.class, EntityDataSerializers.INT);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private UUID ownerUuid;
    private int hitCooldown;
    /** Ticks left before she vanishes (-1 = stays until her user's dance is over). She is only ever out for a second unless a dance is on. */
    private int life = -1;

    public TerpsichoraEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 20.0)
            .add(Attributes.MOVEMENT_SPEED, 0.34)
            .add(Attributes.FOLLOW_RANGE, 64.0)
            .add(Attributes.ATTACK_DAMAGE, 1.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OWNER_ID, -1);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new DanceGoal());
    }

    public void setLife(int ticks) { this.life = ticks; }

    public void setOwner(LivingEntity owner) {
        this.ownerUuid = owner.getUUID();
        this.entityData.set(OWNER_ID, owner.getId());
    }

    /** Whoever the threads are tied to: Neferpitou (NPC) or a player using the Terpsichora ability. */
    @Nullable
    public LivingEntity owner() {
        if (ownerUuid != null && level() instanceof ServerLevel sl && sl.getEntity(ownerUuid) instanceof LivingEntity le && le.isAlive()) return le;
        return null;
    }

    /** Client side: whoever the threads are tied to. */
    @Nullable
    public LivingEntity clientOwner() {
        int id = this.entityData.get(OWNER_ID);
        return id >= 0 && level().getEntity(id) instanceof LivingEntity le ? le : null;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        LivingEntity own = owner();
        if (own == null) { discard(); return; }
        if (this.entityData.get(OWNER_ID) != own.getId()) this.entityData.set(OWNER_ID, own.getId());
        if (own instanceof net.minecraft.world.entity.player.Player pl) {
            int m = Terpsichora.mode(pl);
            if (m == Terpsichora.OFF) { discard(); return; }
            if (m == Terpsichora.DEAD) life = -1; // post-mortem: she stays until the dance is over
        }
        if (life >= 0 && --life < 0) { vanish(); return; } // her second is up
        // She only gives her user the Terpsichora buff and never attacks: she hangs behind her user (player or Neferpitou) until her time is up.
        net.minecraft.world.phys.Vec3 back = own.getLookAngle().multiply(1, 0, 1).normalize().scale(-2.5);
        double tx = own.getX() + back.x, tz = own.getZ() + back.z;
        this.setNoGravity(true);
        this.setPos(getX() + (tx - getX()) * 0.35, getY() + (own.getY() - getY()) * 0.35, getZ() + (tz - getZ()) * 0.35);
        this.setYRot(own.getYRot());
        this.yBodyRot = own.getYRot();
        this.yHeadRot = own.getYRot();
        this.getNavigation().stop();
    }

    /** She is gone as quickly as she came: a little puff of aura. */
    private void vanish() {
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 2.5, getZ(), 24, 0.8, 1.6, 0.8, 0.02);
            sl.playSound(null, blockPosition(), net.minecraft.sounds.SoundEvents.CHAIN_BREAK, net.minecraft.sounds.SoundSource.HOSTILE, 0.6f, 0.8f);
        }
        discard();
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY);
    }

    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }

    /** Walks at whatever her user is fighting; with nobody to fight she stays near her user. */
    private final class DanceGoal extends Goal {
        private int repath;
        DanceGoal() { setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { return false; } // she does not walk or fight: see tick()
        @Override public void tick() {
            LivingEntity o = owner();
            if (o == null) return;
            LivingEntity t = getTarget();
            LivingEntity goal = t != null && t.isAlive() ? t : o;
            getLookControl().setLookAt(goal, 40f, 40f);
            double stop = goal == o ? 4.0 : NeferpitouTuning.TERP_REACH - 1.0;
            if (distanceTo(goal) > stop) {
                if (--repath <= 0) { repath = 5; getNavigation().moveTo(goal, 1.3); }
            } else {
                getNavigation().stop();
            }
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "idle", 5,
            event -> event.setAndContinue(RawAnimation.begin().thenLoop("animation.terpsichora.idle"))));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
