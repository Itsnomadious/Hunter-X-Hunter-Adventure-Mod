package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.server.ServerLifecycleHooks;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.client.ChainFx;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketChainFx;
import net.hxhadventure.addon.network.PacketJudgmentOpen;
import net.hxhadventure.addon.network.PacketJudgmentPrompt;
import net.hxhadventure.utils.AllianceUtils;

/**
 * The Judgment Chain (Kurapika's Chains, Emperor Time only). The user points a hand out and the chain's pointed head, the Stake of
 * Retribution, pierces the target and wraps round their heart. The user then lays up to {@link #MAX_COMMANDS} commands on them
 * (a menu opens), and the victim is asked to accept: refusing, or breaking a command later, means the Stake pierces their heart and kills them.
 * <ul>
 *   <li>Players are free to move while bound (unless a Chain Jail also holds them). Judgment Chains stack with Chain Jail and with each other
 *       (one stake per victim, any number of victims): the Judgment Chain does not need the jail lock to be released.</li>
 *   <li>Creatures that are not players are not asked: they are sealed (forced Zetsu) and made passive.</li>
 *   <li>Shift+Z chains the user themselves. That stake carries no commands: it is what unlocks the death-Vows (see {@link Vows#STAKE_VOWS}).</li>
 *   <li>Hina can pull the Stake out (her menu has a button for it).</li>
 * </ul>
 */
public final class JudgmentChain {
    private JudgmentChain() {}

    public static final String ID = "judgment_chain";
    public static final String NAME = "Judgment Chain";
    public static final int MIN_LEVEL = Tuning.EMPEROR_MIN_LEVEL;
    public static final float COST = 500f;
    public static final int COOLDOWN_TICKS = 200;
    public static final double RANGE = 20.0;
    /** How many commands one Stake can carry (the user can lay at least two). */
    public static final int MAX_COMMANDS = 2;
    /** How long the chain's cast is drawn (ticks). Keep in step with ChainRenderer's judgment drawing. */
    public static final int FX_TICKS = 26;
    /** The user has this long to pick commands once the stake is in. */
    public static final int SESSION_TICKS = 20 * 30;
    /** A bound player has this long to accept; no answer is a refusal. */
    public static final int ACCEPT_TICKS = 20 * 20;

    public static final String NO_NEN = "no_nen";
    public static final String NO_DAY_MOVE = "no_day_move";
    public static final String REVEAL_ABILITIES = "reveal_abilities";
    public static final String REVEAL_STRENGTH = "reveal_strength";
    public static final String NO_HARM = "no_harm";

    public record Command(String id, String text) {}

    /** The commands the user can pick from. Shown in the menu and to the victim. */
    public static final List<Command> COMMANDS = List.of(
        new Command(NO_NEN, "You must never use Nen again."),
        new Command(NO_DAY_MOVE, "You cannot move in daylight."),
        new Command(REVEAL_ABILITIES, "You must reveal all the information about your abilities."),
        new Command(REVEAL_STRENGTH, "You must tell me exactly how strong you are."),
        new Command(NO_HARM, "You must never raise a hand against me."));

    public static String text(String id) {
        for (Command c : COMMANDS) if (c.id().equals(id)) return c.text();
        return id;
    }

    private static boolean valid(String id) {
        for (Command c : COMMANDS) if (c.id().equals(id)) return true;
        return false;
    }

    private record Pending(UUID victim, long expire) {}

    private static final Map<UUID, Pending> PENDING = new HashMap<>();
    private static final Map<UUID, Integer> COOLDOWNS = new HashMap<>();
    /** Ticks a bound player has left to answer. */
    private static final Map<UUID, Integer> PROMPT = new HashMap<>();
    private static StakeData cache;

    // ---------------------------------------------------------------- data

    private static StakeData data() {
        if (cache == null) {
            MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
            if (server == null) return new StakeData();
            cache = server.overworld().getDataStorage().computeIfAbsent(StakeData::load, StakeData::new, StakeData.ID);
        }
        return cache;
    }

    public static void reset() {
        cache = null;
        PENDING.clear();
        COOLDOWNS.clear();
        PROMPT.clear();
    }

    /** Does this entity carry any Stake of Retribution (its own included)? */
    public static boolean hasStake(Entity e) {
        return e != null && data().stakes.containsKey(e.getUUID());
    }

    /** Has this player chained themselves (Shift+Z)? Unlocks the death-Vows. */
    public static boolean hasSelfStake(Player p) {
        if (p == null || p.level().isClientSide) return false;
        StakeData.Stake s = data().stakes.get(p.getUUID());
        return s != null && s.isSelf(p.getUUID());
    }

    public static boolean isStakedNpc(Entity e) {
        if (e == null || e instanceof Player) return false;
        StakeData.Stake s = data().stakes.get(e.getUUID());
        return s != null && s.npc;
    }

    // ---------------------------------------------------------------- casting

    public static void use(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!ChainManager.canUseChains(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not the Chains"), true);
            return;
        }
        if (c.getHatsuLevel() < MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7c" + NAME + " unlocks at Level " + MIN_LEVEL), true);
            return;
        }
        NenAddonData d = NenAddonData.get(sp);
        if (!d.emperor) {
            sp.displayClientMessage(Component.literal("\u00a7c" + NAME + " can only be used in Emperor Time"), true);
            return;
        }
        if (ChainManager.isJailed(sp) || !(sp.level() instanceof ServerLevel level)) return; // NOT blocked by holding someone in Chain Jail
        if (ChainManager.onCooldown(sp, NAME, COOLDOWNS.getOrDefault(sp.getUUID(), 0))) return;

        boolean self = sp.isShiftKeyDown();
        LivingEntity target = sp;
        if (!self) {
            Entity e = ChainManager.rayEntity(sp, RANGE, x -> x instanceof LivingEntity le && le != sp && le.isAlive() && !AllianceUtils.isAlly(le, sp));
            if (!(e instanceof LivingEntity le)) {
                sp.displayClientMessage(Component.literal("\u00a77" + NAME + ": nobody in range (Shift+Z chains yourself)"), true);
                return;
            }
            target = le;
        }
        StakeData data = data();
        if (data.stakes.containsKey(target.getUUID())) {
            sp.displayClientMessage(Component.literal("\u00a7c" + (self ? "You already carry" : "They already carry") + " a Stake of Retribution"), true);
            return;
        }
        if (c.getCurrentEnergy() < COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(COST);
        COOLDOWNS.put(sp.getUUID(), COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, NAME, COOLDOWN_TICKS);
        sp.swing(InteractionHand.MAIN_HAND, true);
        AddonNetwork.sendToTrackingAndSelf(new PacketChainFx(ChainFx.Kind.JUDGMENT, sp.getId(), target.getId(), FX_TICKS, 0, 0, 0, 1f, 0f), sp);
        level.playSound(null, sp.blockPosition(), SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 1.2f, 0.6f);
        level.playSound(null, target.blockPosition(), SoundEvents.TRIDENT_HIT, SoundSource.PLAYERS, 1.0f, 0.5f);
        level.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY() + target.getBbHeight() * 0.7, target.getZ(), 12, 0.2, 0.2, 0.2, 0.2);

        StakeData.Stake st = new StakeData.Stake();
        st.caster = sp.getUUID();
        st.casterName = sp.getName().getString();
        if (self) {
            st.accepted = true;
            data.stakes.put(sp.getUUID(), st);
            data.setDirty();
            Vows.sync(sp); // the client learns the death-Vows are unlocked
            sp.sendSystemMessage(Component.literal("\u00a74The Stake of Retribution is driven into your own heart. \u00a77The death-Vows can now be sworn."));
            AddonNetwork.sendToPlayer(new PacketJudgmentOpen(-1, "", 0), sp);
            return;
        }
        if (!(target instanceof Player)) {
            st.npc = true; // creatures are not asked: sealed and passive
            st.accepted = true;
            data.stakes.put(target.getUUID(), st);
            data.setDirty();
            sealNpc(target);
            sp.sendSystemMessage(Component.literal("\u00a75The Stake wraps round " + target.getName().getString() + "'s heart. \u00a77Their Nen is sealed and they cannot fight."));
            return;
        }
        PENDING.put(sp.getUUID(), new Pending(target.getUUID(), level.getGameTime() + SESSION_TICKS));
        AddonNetwork.sendToPlayer(new PacketJudgmentOpen(target.getId(), target.getName().getString(), MAX_COMMANDS), sp);
    }

    /** The user picked commands in the menu. */
    public static void apply(ServerPlayer sp, int victimId, List<String> ids) {
        Pending p = PENDING.remove(sp.getUUID());
        if (p == null || !(sp.level() instanceof ServerLevel level) || p.expire() < level.getGameTime()) {
            sp.displayClientMessage(Component.literal("\u00a7cThe Stake has slipped out: nothing was commanded"), true);
            return;
        }
        NenAddonData d = NenAddonData.get(sp);
        Entity e = level.getEntity(victimId);
        if (!d.emperor || !(e instanceof ServerPlayer victim) || !victim.getUUID().equals(p.victim()) || !victim.isAlive()) {
            sp.displayClientMessage(Component.literal("\u00a7cThe Stake has slipped out: nothing was commanded"), true);
            return;
        }
        Set<String> picked = new LinkedHashSet<>();
        for (String id : ids) if (valid(id) && picked.size() < MAX_COMMANDS) picked.add(id);
        StakeData data = data();
        if (picked.isEmpty() || data.stakes.containsKey(victim.getUUID())) return;

        StakeData.Stake st = new StakeData.Stake();
        st.caster = sp.getUUID();
        st.casterName = sp.getName().getString();
        st.commands.addAll(picked);
        data.stakes.put(victim.getUUID(), st);
        data.setDirty();
        PROMPT.put(victim.getUUID(), ACCEPT_TICKS);
        sendPrompt(victim, st, ACCEPT_TICKS);
        sp.sendSystemMessage(Component.literal("\u00a75The Stake is in " + victim.getName().getString() + "'s heart. \u00a77They must accept your commands or die."));
    }

    private static void sendPrompt(ServerPlayer victim, StakeData.Stake st, int ticksLeft) {
        AddonNetwork.sendToPlayer(new PacketJudgmentPrompt(st.casterName, new ArrayList<>(st.commands), ticksLeft), victim);
    }

    /** The bound player pressed Accept or Refuse. */
    public static void answer(ServerPlayer victim, boolean accept) {
        StakeData data = data();
        StakeData.Stake st = data.stakes.get(victim.getUUID());
        if (st == null || st.accepted || st.npc || st.isSelf(victim.getUUID())) return;
        PROMPT.remove(victim.getUUID());
        if (!accept) {
            killByStake(victim, st, "You refused the commands");
            return;
        }
        st.accepted = true;
        data.setDirty();
        victim.sendSystemMessage(Component.literal("\u00a74The Stake wraps round your heart. \u00a77You are bound:"));
        for (String id : st.commands) victim.sendSystemMessage(Component.literal("\u00a7c - " + text(id)));
        ServerPlayer caster = casterOf(st);
        if (caster != null) {
            caster.sendSystemMessage(Component.literal("\u00a75" + victim.getName().getString() + " accepted the Stake."));
            if (st.commands.contains(REVEAL_ABILITIES)) revealAbilities(victim, caster);
            if (st.commands.contains(REVEAL_STRENGTH)) revealStrength(victim, caster);
        }
    }

    private static ServerPlayer casterOf(StakeData.Stake st) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        return server == null || st.caster == null ? null : server.getPlayerList().getPlayer(st.caster);
    }

    // ---------------------------------------------------------------- what the victim has to tell

    private static void revealAbilities(ServerPlayer v, ServerPlayer to) {
        Combat c = Combat.get(v);
        NenAddonData d = NenAddonData.get(v);
        to.sendSystemMessage(Component.literal("\u00a75[Judgment] \u00a7f" + v.getName().getString() + " reveals their abilities:"));
        if (c == null || !c.hasNenUnlocked()) {
            to.sendSystemMessage(Component.literal("\u00a77 - They have no Nen."));
            return;
        }
        to.sendSystemMessage(Component.literal("\u00a77 - Nen type: \u00a7f" + Affinity.name(c.getNenType())));
        String kit = HatsuCatalog.textFor(c.getCurrentKit());
        to.sendSystemMessage(Component.literal("\u00a77 - Hatsu (level " + c.getHatsuLevel() + "): \u00a7f" + (kit == null ? "none" : kit)));
        StringBuilder skills = new StringBuilder();
        for (NenSkill s : NenSkill.values()) skills.append(s.label).append(' ').append(d.level(s)).append("  ");
        to.sendSystemMessage(Component.literal("\u00a77 - Skills: \u00a7f" + skills.toString().trim()));
        to.sendSystemMessage(Component.literal("\u00a77 - Sworn rules: \u00a7f" + d.vows.size()));
    }

    private static void revealStrength(ServerPlayer v, ServerPlayer to) {
        Combat c = Combat.get(v);
        NenAddonData d = NenAddonData.get(v);
        to.sendSystemMessage(Component.literal("\u00a75[Judgment] \u00a7f" + v.getName().getString() + " tells you exactly how strong they are:"));
        to.sendSystemMessage(Component.literal("\u00a77 - Health: \u00a7f" + Math.round(v.getHealth()) + " / " + Math.round(v.getMaxHealth())
            + "\u00a77   Armour: \u00a7f" + Math.round(v.getAttributeValue(Attributes.ARMOR))
            + "\u00a77   Attack damage: \u00a7f" + String.format(java.util.Locale.ROOT, "%.1f", v.getAttributeValue(Attributes.ATTACK_DAMAGE))));
        if (c != null && c.hasNenUnlocked()) {
            StringBuilder lv = new StringBuilder();
            for (NenSkill s : NenSkill.values()) lv.append(s.label).append(' ').append(d.effLevel(s)).append("  ");
            to.sendSystemMessage(Component.literal("\u00a77 - Aura: \u00a7f" + Math.round(c.getCurrentEnergy()) + " / " + Math.round(c.getMaxEnergy())
                + "\u00a77   Hatsu level: \u00a7f" + c.getHatsuLevel()));
            to.sendSystemMessage(Component.literal("\u00a77 - Skill levels (with Vows): \u00a7f" + lv.toString().trim()));
        }
    }

    // ---------------------------------------------------------------- enforcement

    private static boolean bound(ServerPlayer sp, String command) {
        StakeData.Stake st = data().stakes.get(sp.getUUID());
        return st != null && st.accepted && !st.npc && !st.isSelf(sp.getUUID()) && st.commands.contains(command);
    }

    private static boolean nenInUse(ServerPlayer sp) {
        NenAddonData d = NenAddonData.peek(sp);
        Combat c = Combat.get(sp);
        if (d == null) return false;
        return (c != null && c.isAuraActive()) || d.ken || d.ko || d.en || d.in || d.gyo || d.emperor;
    }

    /** Called before any ability runs. "You must never use Nen again": any ability but the Ten toggle ends in the Stake. Returns true to refuse it. */
    public static boolean violatesNoNen(ServerPlayer sp, String abilityId) {
        if ("ten_toggle".equals(abilityId) || !bound(sp, NO_NEN)) return false;
        punish(sp, NO_NEN);
        return true;
    }

    /** Every tick, for every player: prompts, and the commands that watch what the player does. */
    public static void tickPlayer(ServerPlayer sp) {
        UUID id = sp.getUUID();
        COOLDOWNS.computeIfPresent(id, (k, v) -> v <= 1 ? null : v - 1);
        StakeData.Stake st = data().stakes.get(id);
        if (st == null || st.isSelf(id) || st.npc || !sp.isAlive()) return;
        if (!st.accepted) {
            Integer left = PROMPT.get(id);
            if (left == null) { // logged in again with an answer still owed
                PROMPT.put(id, ACCEPT_TICKS);
                sendPrompt(sp, st, ACCEPT_TICKS);
                return;
            }
            if (left <= 1) {
                PROMPT.remove(id);
                killByStake(sp, st, "You gave no answer: that is a refusal");
            } else {
                PROMPT.put(id, left - 1);
            }
            return;
        }
        if (st.commands.contains(NO_NEN) && nenInUse(sp)) {
            punish(sp, NO_NEN);
            return;
        }
        if (st.commands.contains(NO_DAY_MOVE) && Vows.test(sp, Vows.Pred.DAY) && Vows.test(sp, Vows.Pred.SKY)) {
            double dx = sp.getX() - sp.xo, dz = sp.getZ() - sp.zo;
            double sq = dx * dx + dz * dz;
            if (sq > 0.0004 && sq < 100 && !sp.isPassenger() && sp.hurtTime == 0 && !sp.isFallFlying()) punish(sp, NO_DAY_MOVE);
        }
    }

    /** A bound player hit someone: "never raise a hand against me" is broken if it was their binder. */
    public static void onPlayerAttack(ServerPlayer attacker, Entity victim) {
        StakeData.Stake st = data().stakes.get(attacker.getUUID());
        if (st == null || !st.accepted || st.npc || !st.commands.contains(NO_HARM) || victim == null || !victim.getUUID().equals(st.caster)) return;
        punish(attacker, NO_HARM);
    }

    private static void punish(ServerPlayer victim, String command) {
        StakeData.Stake st = data().stakes.get(victim.getUUID());
        killByStake(victim, st, "You broke the command: " + text(command));
    }

    /** The Stake of Retribution pierces the heart. The stake is gone with its victim (see onDeath). */
    private static void killByStake(ServerPlayer victim, StakeData.Stake st, String why) {
        victim.sendSystemMessage(Component.literal("\u00a74The Stake of Retribution pierces your heart. \u00a77" + why));
        if (victim.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.DAMAGE_INDICATOR, victim.getX(), victim.getY() + 1.2, victim.getZ(), 14, 0.3, 0.4, 0.3, 0.1);
            level.playSound(null, victim.blockPosition(), SoundEvents.TRIDENT_RETURN, SoundSource.PLAYERS, 1.0f, 0.4f);
        }
        ServerPlayer caster = st == null ? null : casterOf(st);
        if (caster != null && caster != victim) {
            caster.sendSystemMessage(Component.literal("\u00a75The Stake pierced " + victim.getName().getString() + "'s heart. \u00a77" + why));
        }
        victim.hurt(victim.damageSources().genericKill(), Float.MAX_VALUE);
    }

    // ---------------------------------------------------------------- creatures that are not players

    private static void sealNpc(LivingEntity e) {
        HatsuEffects.apply(e, 60, false);
        if (e instanceof Mob m) m.setTarget(null);
    }

    /** Every half second: sealed creatures stay sealed and stay passive. */
    public static void tickNpcs(MinecraftServer server) {
        StakeData data = data();
        if (data.stakes.isEmpty()) return;
        for (Map.Entry<UUID, StakeData.Stake> en : data.stakes.entrySet()) {
            if (!en.getValue().npc) continue;
            for (ServerLevel level : server.getAllLevels()) {
                if (level.getEntity(en.getKey()) instanceof LivingEntity le && le.isAlive()) {
                    sealNpc(le);
                    break;
                }
            }
        }
    }

    // ---------------------------------------------------------------- lifting

    /** The stake dies with whoever carries it. */
    public static void onDeath(Entity e) {
        StakeData data = data();
        if (data.stakes.remove(e.getUUID()) != null) data.setDirty();
        PROMPT.remove(e.getUUID());
    }

    /** Hina: the Stake is pulled out of the player's heart, and the death-Vows sworn under their own stake go with it. Returns false if there was none. */
    public static boolean removeStake(ServerPlayer sp) {
        StakeData data = data();
        StakeData.Stake st = data.stakes.remove(sp.getUUID());
        if (st == null) return false;
        data.setDirty();
        PROMPT.remove(sp.getUUID());
        NenAddonData d = NenAddonData.get(sp);
        boolean vowsGone = d.vows.removeIf(Vows::stakeLocked);
        if (vowsGone) {
            d.markSync();
            d.save();
            Vows.afterLift(sp);
        }
        Vows.sync(sp);
        return true;
    }
}
