package net.hxhadventure.addon;

/** Numbers for Uvogin's Big Bang Impact (Hatsu kit 31, Enhancers). Change them here; nothing else needs to change to rebalance. */
public final class BigBangImpactTuning {
    private BigBangImpactTuning() {}

    // ---- unlocks ----
    /** Hatsu level needed to use it. */
    public static final int MIN_LEVEL = 10;

    // ---- the focus (hold Z; Shift+Z at the press aims the punch at the ground) ----
    // The fist looks and charges exactly like Jajanken's Rock (same flare, same converging aura, same pose): those visuals are timed to
    // Jajanken.ROCK_FLARE_TICKS / ROCK_CHARGE_TICKS, so the numbers below are taken from there.
    /** Ticks of the max-size Ren flare shrinking to nothing before all the aura is in the fist. */
    public static final int FLARE_TICKS = Jajanken.ROCK_FLARE_TICKS;
    /** Ticks of focusing after the flare. The aura has to be fully in the fist: let go of Z earlier and it scatters (nothing is paid). */
    public static final int FOCUS_TICKS = Jajanken.ROCK_CHARGE_TICKS;
    /** Held this long past a full focus, the punch is thrown by itself (also the safety net for a missed key-up). */
    public static final int HOLD_LIMIT_TICKS = 100;
    /** Ko is switched on for real while the aura is in the fist: the body is as open as Ko makes it, and the punch carries Ko's Hatsu bonus. */
    public static final boolean KO_ENFORCED = true;

    // ---- cost ----
    /** Aura paid when the punch is thrown (the same for the forward punch and the ground punch). */
    public static final float COST = 400f;
    public static final int COOLDOWN_TICKS = 200;

    // ---- the forward punch (Z) ----
    /** A fully focused Jajanken Rock's damage (22 + 1 per Hatsu level) times this. */
    public static final float DAMAGE_MULT = 1.5f;
    /**
     * How far the blast reaches, in blocks from where the fist lands: every block inside this sphere that is not tougher than
     * {@link Jajanken#ROCK_BLOCK_POWER} is destroyed (dug out over a few ticks, nearest first, no drops: see GonVow.startCrater).
     * Creatures inside it are caught by the shock too (Jajanken's shock share of the hit, so 40%).
     */
    public static final double BLAST_RADIUS = 10.0;
    /** How far below the user's feet the blast may dig. Equal to the radius, so it is a whole sphere and not a dome (Gon's vow crater stops at 6). */
    public static final int BLAST_MAX_DEPTH = 10;

    // ---- the ground punch (Shift+Z): a ripple through the ground ----
    /** How far the ripple runs, in blocks. */
    public static final double RIPPLE_LENGTH = 20.0;
    /** Half the angle the cone opens by, in degrees (25 -> about 19 blocks wide at the far end). */
    public static final double RIPPLE_HALF_ANGLE_DEG = 25.0;
    /** The cone is this wide on each side of its axis right at the fist, before it starts opening. */
    public static final double RIPPLE_START_HALF_WIDTH = 1.5;
    /** Blocks the ripple travels every tick (1.5 -> it reaches the end in about 14 ticks). */
    public static final double RIPPLE_SPEED = 1.5;
    /** How many layers of ground are destroyed under the surface (1 = only the top block). */
    public static final int RIPPLE_DEPTH = 2;
    /** The ripple follows the ground up and down: this far above the user's feet and this far below it. */
    public static final int RIPPLE_RISE = 3, RIPPLE_DROP = 6;
    /** Creatures hit by the ripple are stunned for this long: 40 ticks = 2 s. Lightning Aura users cannot be stunned (as everywhere else). */
    public static final int RIPPLE_STUN_TICKS = 40;
    /**
     * A creature this high above the ground when the ripple passes under it is missed (jump it!). A normal jump peaks at about 1.25 blocks,
     * so this has to stay below that or a plain jump could never dodge it (it was 1.5).
     */
    public static final double RIPPLE_AIR_CLEARANCE = 1.0;
}
