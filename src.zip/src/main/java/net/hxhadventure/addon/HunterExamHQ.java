package net.hxhadventure.addon;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.serialization.Codec;
import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;
import java.util.Set;
import net.hxhadventure.HxHAdventure;
import net.minecraft.commands.arguments.blocks.BlockStateParser;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/**
 * Hunter Exam headquarters: a very rare natural world-generation structure built from
 * data/hxhadventure/schematics/hunter_hq.schem (Sponge v2 .schem, 114 x 148 x 128).
 *
 * <p>How it spawns (all data-driven, tune without touching code):
 * <ul>
 *   <li>data/hxhadventure/worldgen/structure_set/hunter_hq.json: rarity (spacing / separation / frequency).</li>
 *   <li>data/hxhadventure/worldgen/structure/hunter_hq.json: step and terrain adaptation.</li>
 *   <li>data/hxhadventure/tags/worldgen/biome/has_hunter_hq.json: which biomes it may spawn in.</li>
 * </ul>
 * Find one with {@code /locate structure hxhadventure:hunter_hq}. There is no spawn command any more.
 *
 * <p>Level ground: before it is allowed to spawn, the footprint is sampled. Spots that are mostly water, below sea
 * level or too hilly ({@link #MAX_RELIEF}) are refused (the generator may try a few nearby offsets). On an accepted
 * spot the surface layer is set to the average ground height, anything of the terrain poking up inside the footprint
 * is cleared by the schematic's air, and every column whose ground is lower gets a {@link #FOUNDATION} column down to
 * solid ground (at most {@link #FOUNDATION_MAX} blocks).
 *
 * <p>Skipped on purpose (the world is left untouched there): the outer border ring of the schematic, gray concrete
 * powder, gray and light gray stained glass, and the underground fill below the surface layer (the foundation
 * replaces that). Cyan terracotta ground markers on the surface layer become grass.
 *
 * <p>Added on top of the schematic: hanging lanterns across the big open hall on the third floor (see {@link #HALL_FLOOR_Y}), and the
 * Hunter Exam NPCs: the receptionist in the lobby, Menchi and Satotz in the hall (see {@link #spawnNpcs}). Only structures generated
 * after this change get them; an HQ that already exists in a world is left as it was.
 */
public final class HunterExamHQ {
   private static final String RESOURCE = "/data/hxhadventure/schematics/hunter_hq.schem";

   /** Schematic layer that is the surface (grass / plaza level). Layers below are not pasted. */
   private static final int GROUND_Y = 10;

   /** Largest difference between the highest and lowest sampled ground inside the footprint that is still accepted. */
   private static final int MAX_RELIEF = 14;

   /** Most blocks of stone foundation placed under the surface layer in one column. */
   private static final int FOUNDATION_MAX = 40;

   private static final BlockState FOUNDATION = Blocks.STONE.defaultBlockState();

   // ---- third floor hall lighting (schematic coordinates: x / z across the structure, layers counted from its bottom) ----

   /** Schematic layer of the third floor's floor: the big open hall. Its walkable air starts one layer above. */
   private static final int HALL_FLOOR_Y = 32;

   /** Schematic layer of the hall's ceiling (the floor of the storey above). Lamps hang from it. */
   private static final int HALL_CEILING_Y = 42;

   /** Lamps hang on a square grid this many blocks apart (smaller = brighter hall), centred on {@link #LIGHT_CENTER_X} / {@link #LIGHT_CENTER_Z}. */
   private static final int LIGHT_SPACING = 7;
   private static final int LIGHT_CENTER_X = 57;
   private static final int LIGHT_CENTER_Z = 50;

   /** Chain links between the ceiling and each lantern. */
   private static final int LAMP_CHAIN = 3;

   /** Blocks that belong to the outer border and are never placed. */
   private static final Set<Block> SKIP = Set.of(
      Blocks.GRAY_CONCRETE_POWDER, Blocks.GRAY_STAINED_GLASS, Blocks.LIGHT_GRAY_STAINED_GLASS
   );

   /** Horizontal offsets (blocks) tried around the chunk centre, in order, when the first spot is not level enough. */
   static final int[][] OFFSETS = {{0, 0}, {48, 0}, {-48, 0}, {0, 48}, {0, -48}};

   // ------------------------------------------------------------------ registries

   public static final DeferredRegister<StructureType<?>> STRUCTURE_TYPES =
      DeferredRegister.create(Registries.STRUCTURE_TYPE, HxHAdventure.MOD_ID);
   public static final DeferredRegister<StructurePieceType> PIECE_TYPES =
      DeferredRegister.create(Registries.STRUCTURE_PIECE, HxHAdventure.MOD_ID);

   public static final RegistryObject<StructureType<HqStructure>> TYPE =
      STRUCTURE_TYPES.register("hunter_hq", () -> () -> HqStructure.CODEC);
   public static final RegistryObject<StructurePieceType> PIECE =
      PIECE_TYPES.register("hunter_hq", () -> (StructurePieceType) (ctx, tag) -> new HqPiece(tag));

   private static Schem cached;

   private HunterExamHQ() {
   }

   // ------------------------------------------------------------------ structure

   public static final class HqStructure extends Structure {
      public static final Codec<HqStructure> CODEC = simpleCodec(HqStructure::new);

      public HqStructure(Structure.StructureSettings settings) {
         super(settings);
      }

      @Override
      public StructureType<?> type() {
         return TYPE.get();
      }

      @Override
      protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext ctx) {
         Schem s;
         try {
            s = load();
         } catch (Exception ex) {
            return Optional.empty();
         }
         ChunkPos cp = ctx.chunkPos();
         for (int[] off : OFFSETS) {
            int cx = cp.getMiddleBlockX() + off[0];
            int cz = cp.getMiddleBlockZ() + off[1];
            int ox = cx - s.w / 2;
            int oz = cz - s.l / 2;
            int surface = levelSurface(ctx, s, ox, oz);
            if (surface == Integer.MIN_VALUE) {
               continue;
            }
            int oy = surface - 1; // world Y of the schematic's surface layer
            int top = oy + (s.h - 1 - GROUND_Y);
            if (top >= ctx.heightAccessor().getMaxBuildHeight()) {
               continue;
            }
            int minY = Math.max(ctx.heightAccessor().getMinBuildHeight(), oy - FOUNDATION_MAX);
            BoundingBox box = new BoundingBox(ox, minY, oz, ox + s.w - 1, top, oz + s.l - 1);
            BlockPos start = new BlockPos(cx, oy, cz);
            return Optional.of(new Structure.GenerationStub(start, builder -> builder.addPiece(new HqPiece(box, ox, oy, oz))));
         }
         return Optional.empty();
      }

      /** Average ground height of the footprint, or MIN_VALUE if the spot is not acceptable (water, below sea level, too hilly). */
      private static int levelSurface(Structure.GenerationContext ctx, Schem s, int ox, int oz) {
         ChunkGenerator gen = ctx.chunkGenerator();
         long sum = 0;
         int n = 0;
         int wet = 0;
         int min = Integer.MAX_VALUE;
         int max = Integer.MIN_VALUE;
         for (int x = ox + 6; x < ox + s.w - 6; x += 10) {
            for (int z = oz + 6; z < oz + s.l - 6; z += 10) {
               int floor = gen.getBaseHeight(x, z, Heightmap.Types.OCEAN_FLOOR_WG, ctx.heightAccessor(), ctx.randomState());
               int top = gen.getBaseHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, ctx.heightAccessor(), ctx.randomState());
               if (top != floor) {
                  wet++;
               }
               sum += floor;
               n++;
               min = Math.min(min, floor);
               max = Math.max(max, floor);
            }
         }
         if (n == 0 || wet * 20 > n || max - min > MAX_RELIEF) {
            return Integer.MIN_VALUE;
         }
         int avg = (int) Math.round((double) sum / n);
         return avg > gen.getSeaLevel() ? avg : Integer.MIN_VALUE;
      }
   }

   // ------------------------------------------------------------------ piece

   public static final class HqPiece extends StructurePiece {
      private final int ox;
      private final int oy;
      private final int oz;

      public HqPiece(BoundingBox box, int ox, int oy, int oz) {
         super(PIECE.get(), 0, box);
         this.ox = ox;
         this.oy = oy;
         this.oz = oz;
      }

      public HqPiece(CompoundTag tag) {
         super(PIECE.get(), tag);
         this.ox = tag.getInt("OX");
         this.oy = tag.getInt("OY");
         this.oz = tag.getInt("OZ");
      }

      @Override
      protected void addAdditionalSaveData(StructurePieceSerializationContext ctx, CompoundTag tag) {
         tag.putInt("OX", ox);
         tag.putInt("OY", oy);
         tag.putInt("OZ", oz);
      }

      @Override
      public void postProcess(WorldGenLevel level, StructureManager structures, ChunkGenerator gen, RandomSource random,
                              BoundingBox chunkBox, ChunkPos chunkPos, BlockPos pivot) {
         Schem s;
         try {
            s = load();
         } catch (Exception ex) {
            return;
         }
         // inner area only: the outer border ring of the schematic is never touched
         int x0 = Math.max(chunkBox.minX(), ox + 1);
         int x1 = Math.min(chunkBox.maxX(), ox + s.w - 2);
         int z0 = Math.max(chunkBox.minZ(), oz + 1);
         int z1 = Math.min(chunkBox.maxZ(), oz + s.l - 2);
         if (x0 > x1 || z0 > z1) {
            return;
         }
         int minY = level.getMinBuildHeight();
         int maxY = level.getMaxBuildHeight();
         int wl = s.w * s.l;
         BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();

         for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
               int sx = x - ox;
               int sz = z - oz;

               // stone foundation: fill down from just under the surface layer until solid ground
               for (int y = oy - 1; y >= Math.max(minY, oy - FOUNDATION_MAX); y--) {
                  p.set(x, y, z);
                  if (!fillable(level.getBlockState(p))) {
                     break;
                  }
                  level.setBlock(p, FOUNDATION, 2 | 16);
               }

               for (int sy = GROUND_Y; sy < s.h; sy++) {
                  int y = oy + (sy - GROUND_Y);
                  if (y >= maxY) {
                     break;
                  }
                  BlockState st = s.palette[s.data[sy * wl + sz * s.w + sx]];
                  Block b = st.getBlock();
                  if (sy == GROUND_Y && b == Blocks.CYAN_TERRACOTTA) {
                     st = Blocks.GRASS_BLOCK.defaultBlockState();
                  } else if (SKIP.contains(b)) {
                     continue;
                  }
                  p.set(x, y, z);
                  BlockState cur = level.getBlockState(p);
                  if (cur == st || (cur.isAir() && st.isAir())) {
                     continue;
                  }
                  level.setBlock(p, st, 2 | 16);
                  if (!st.getFluidState().isEmpty()) {
                     level.scheduleTick(p, st.getFluidState().getType(), 0);
                  }
               }

               if (Math.floorMod(sx - LIGHT_CENTER_X, LIGHT_SPACING) == 0 && Math.floorMod(sz - LIGHT_CENTER_Z, LIGHT_SPACING) == 0) {
                  hangHallLamp(level, s, p, x, z, sx, sz);
               }
            }
         }
         spawnNpcs(level, chunkBox);
      }

      /**
       * A lantern on a short chain from the hall's ceiling. Only where the schematic has a solid ceiling and nothing in the way below it
       * (walls, pillars and the stair opening's edges are skipped).
       */
      private void hangHallLamp(WorldGenLevel level, Schem s, BlockPos.MutableBlockPos p, int x, int z, int sx, int sz) {
         int wl = s.w * s.l;
         if (s.palette[s.data[HALL_CEILING_Y * wl + sz * s.w + sx]].isAir()) {
            return;
         }
         for (int k = 1; k <= LAMP_CHAIN + 1; k++) {
            if (!s.palette[s.data[(HALL_CEILING_Y - k) * wl + sz * s.w + sx]].isAir()) {
               return;
            }
         }
         int maxY = level.getMaxBuildHeight();
         for (int k = 1; k <= LAMP_CHAIN; k++) {
            int y = oy + (HALL_CEILING_Y - k - GROUND_Y);
            if (y < maxY) {
               level.setBlock(p.set(x, y, z), Blocks.CHAIN.defaultBlockState(), 2 | 16);
            }
         }
         int ly = oy + (HALL_CEILING_Y - LAMP_CHAIN - 1 - GROUND_Y);
         if (ly < maxY) {
            level.setBlock(p.set(x, ly, z), Blocks.LANTERN.defaultBlockState().setValue(BlockStateProperties.HANGING, true), 2 | 16);
         }
      }

      /**
       * The Hunter Exam NPCs, placed once by the chunk that contains their spot (positions are schematic x / layer / z, yaw as in /tp:
       * 0 faces south, 90 west, 180 north, 270 east): the receptionist in the lobby, Menchi and Satotz in the third floor hall
       * just past the top of the stairs.
       */
      private void spawnNpcs(WorldGenLevel level, BoundingBox chunkBox) {
         spawnNpc(level, chunkBox, HxHEntities.EXAM_RECEPTIONIST.get(), 58, 11, 67, 270f);
         spawnNpc(level, chunkBox, HxHEntities.MENCHI.get(), 66, HALL_FLOOR_Y + 1, 47, 180f);
         spawnNpc(level, chunkBox, HxHEntities.SATOTZ.get(), 73, HALL_FLOOR_Y + 1, 47, 180f);
      }

      private <T extends Mob> void spawnNpc(WorldGenLevel level, BoundingBox chunkBox, EntityType<T> type, int sx, int sy, int sz, float yaw) {
         int x = ox + sx;
         int y = oy + (sy - GROUND_Y);
         int z = oz + sz;
         if (x < chunkBox.minX() || x > chunkBox.maxX() || z < chunkBox.minZ() || z > chunkBox.maxZ()) {
            return;
         }
         T npc = type.create(level.getLevel());
         if (npc == null) {
            return;
         }
         npc.moveTo(x + 0.5, y, z + 0.5, yaw, 0.0f);
         npc.setYHeadRot(yaw);
         npc.setYBodyRot(yaw);
         level.addFreshEntityWithPassengers(npc);
      }

      /** Terrain a foundation column may replace on its way down to solid ground. */
      private static boolean fillable(BlockState st) {
         return st.isAir() || st.canBeReplaced() || !st.getFluidState().isEmpty()
            || st.is(BlockTags.LEAVES) || st.is(BlockTags.LOGS);
      }
   }

   // ------------------------------------------------------------------ schematic loading (Sponge v2)

   private static final class Schem {
      int w;
      int h;
      int l;
      BlockState[] palette;
      int[] data;
   }

   private static synchronized Schem load() throws IOException, CommandSyntaxException {
      if (cached != null) {
         return cached;
      }
      CompoundTag tag;
      try (InputStream in = HunterExamHQ.class.getResourceAsStream(RESOURCE)) {
         if (in == null) {
            throw new IOException("missing resource " + RESOURCE);
         }
         tag = NbtIo.readCompressed(in);
      }
      Schem s = new Schem();
      s.w = tag.getShort("Width") & 0xFFFF;
      s.h = tag.getShort("Height") & 0xFFFF;
      s.l = tag.getShort("Length") & 0xFFFF;

      CompoundTag pal = tag.getCompound("Palette");
      int max = 0;
      for (String k : pal.getAllKeys()) {
         max = Math.max(max, pal.getInt(k));
      }
      s.palette = new BlockState[max + 1];
      java.util.Arrays.fill(s.palette, Blocks.AIR.defaultBlockState());
      for (String k : pal.getAllKeys()) {
         BlockState st;
         try {
            st = BlockStateParser.parseForBlock(BuiltInRegistries.BLOCK.asLookup(), k, false).blockState();
         } catch (CommandSyntaxException ex) {
            st = Blocks.AIR.defaultBlockState();
         }
         s.palette[pal.getInt(k)] = st;
      }

      byte[] raw = tag.getByteArray("BlockData");
      s.data = new int[s.w * s.h * s.l];
      int p = 0;
      int n = 0;
      while (p < raw.length && n < s.data.length) {
         int v = 0;
         int shift = 0;
         byte b;
         do {
            b = raw[p++];
            v |= (b & 0x7F) << shift;
            shift += 7;
         } while ((b & 0x80) != 0 && p < raw.length);
         s.data[n++] = v;
      }
      cached = s;
      return s;
   }
}
