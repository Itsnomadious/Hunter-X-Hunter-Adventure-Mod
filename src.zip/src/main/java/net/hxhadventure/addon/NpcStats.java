package net.hxhadventure.addon;

/**
 * Every number that defines one of the Nen-fighter NPCs (Netero, Zeno, Silva, Bisky, Illumi, Kurapika, Killua), in one place.
 * Levels feed the same formulas a player's levels do (Ten bonus, aura pool, spirit bonus), so an NPC of level L hits and takes
 * damage like a player of level L. Fluent setters keep the per-NPC definitions short.
 */
public final class NpcStats {
    public final String id;
    public final int nenType;

    // ---- levels ----
    public int level = 100, hatsu = 100, ten = 100, ren = 100;

    // ---- body ----
    public double health = 160.0, speed = 0.30, followRange = 64.0, knockbackRes = 0.4;
    public float healPerSecond = 1.0f;

    // ---- aura pool ----
    public float auraPoolMult = 0.25f;

    // ---- melee (Combat.java's numbers x meleeMult x spirit bonus) ----
    public float meleeMult = 1.0f;
    public double reach = 2.5;
    public int punchGap = 10, strongCharge = 40, strongCooldown = 100, barrageCooldown = 60, barrageHitGap = 3;
    public float weightBarrage = 0.22f, weightStrong = 0.20f;

    // ---- look ----
    public String skin;          // textures/entity/<skin>.png
    public String auraTex;       // textures/entity/<auraTex>.png (a *_ten aura texture)
    public boolean slim;
    public int eggPrimary, eggSecondary;
    public int xp = 50;

    public NpcStats(String id, int nenType) {
        this.id = id;
        this.nenType = nenType;
        this.skin = id;
    }

    public NpcStats levels(int level, int hatsu, int ten, int ren) {
        this.level = level;
        this.hatsu = hatsu;
        // an NPC's aura (Ten / Ren: damage, durability, speed) never goes above what a player can reach, so a matched player can always hurt it
        this.ten = Math.min(NpcFeelTuning.PLAYER_CAP, ten);
        this.ren = Math.min(NpcFeelTuning.PLAYER_CAP, ren);
        return this;
    }

    public NpcStats body(double health, double speed, double knockbackRes, float healPerSecond) {
        this.health = health;
        this.speed = speed;
        this.knockbackRes = knockbackRes;
        this.healPerSecond = healPerSecond;
        return this;
    }

    public NpcStats melee(float meleeMult, double reach) {
        this.meleeMult = meleeMult;
        this.reach = reach;
        return this;
    }

    public NpcStats look(String auraTex, int eggPrimary, int eggSecondary) {
        this.auraTex = auraTex;
        this.eggPrimary = eggPrimary;
        this.eggSecondary = eggSecondary;
        return this;
    }

    /** HxHAdventure's spirit bonus for the Hatsu level: 1 + 0.1 sqrt(L). Multiplies punches and Hatsu damage. */
    public float spiritBonus() {
        return 1.0f + (float) Math.sqrt(hatsu) * 0.1f;
    }

    public float maxAura() {
        return Tuning.npcMaxNen(hatsu, ten, ren) * auraPoolMult;
    }

    /** Ten's regen per second, the same as a player's. */
    public float tenRegenPerSecond() {
        float s = (float) Math.sqrt(hatsu);
        float scaled = Math.min(0.5f + hatsu * 0.1f * (1f + s * 0.1f), 2.0f);
        return scaled * 5.5f + Tuning.tenRegen(ten);
    }
}
