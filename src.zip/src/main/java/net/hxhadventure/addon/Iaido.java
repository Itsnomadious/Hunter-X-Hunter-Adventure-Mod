package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;
import net.hxhadventure.utils.AllianceUtils;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The Katana's iaido draw. While the SHEATHED Katana is held (main hand or off hand, the same two places KatanaHipLayer looks), the user's
 * Attack and Strong attack are not punches: the user crouches into the stance (left leg back, right leg forward, left hand on the sheath,
 * right hand on the hilt, body turned and leaning in - the "iaido_draw" clip, played for everyone who can see the user), and after
 * {@link IaidoTuning#WINDUP_TICKS} dashes {@link IaidoTuning#DASH_DISTANCE} blocks forward in one instant, cutting everything on the way
 * and everything within that distance in front of them. The dash follows the user's pitch (look up and it lunges into the air), and when it is
 * done the Katana stays drawn in the hand. Strong attack is HELD instead: the user stays in the stance for as long as the key
 * is down and draws on release; a full charge ({@link IaidoTuning#CHARGE_FULL_TICKS}) lunges {@link IaidoTuning#FULL_CHARGE_DISTANCE_MULT}x as far.
 *
 * <p>Barrage stays a normal barrage (except while the user is crouched in the stance). Numbers: {@link IaidoTuning}.
 * Called from AbilityRegistryMixin before every ability runs; ticked by {@link IaidoEvents}.
 */
public final class Iaido {
    private Iaido() {}

    /** The clip's name: assets/hxhadventure/player_animation/iaido_draw.json. */
    private static final String ANIM = "iaido_draw";
    /** Strong attack: the stance is held on its last frame while the key is down (iaido_charge.json), the cut follows on release (iaido_cut.json). */
    private static final String ANIM_CHARGE = "iaido_charge", ANIM_CUT = "iaido_cut";
    private static final UUID SLOW_UUID = UUID.fromString("33333333-4444-5555-6666-888888888802");

    private static final class State {
        long readyAt;          // game time the next draw is possible
        int windup;            // ticks left in the stance (0 = not drawing)
        float mult = 1f;       // damage multiplier of the draw in progress
        boolean strongHeld;    // Strong attack's key is down: it sends a keep-alive every tick, but one press is one draw
        int strongLast;        // tick of the last keep-alive
        boolean charging;      // Strong attack is being held in the stance (no limit), the draw comes on release
        int charge;            // ticks the stance has been held
        double distMult = 1.0; // lunge distance multiplier of the draw in progress (1 = a normal draw, up to FULL_CHARGE_DISTANCE_MULT)
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    // ---------------------------------------------------------------- is the Katana in hand

    /** The hand holding the sheathed Katana (main hand first), or null. */
    public static InteractionHand heldHand(Player p) {
        if (KatanaItems.KATANA_SHEATHED == null) return null;
        if (p.getMainHandItem().is(KatanaItems.KATANA_SHEATHED)) return InteractionHand.MAIN_HAND;
        if (p.getOffhandItem().is(KatanaItems.KATANA_SHEATHED)) return InteractionHand.OFF_HAND;
        return null;
    }

    public static boolean holding(Player p) {
        return heldHand(p) != null;
    }

    // ---------------------------------------------------------------- Attack / Strong attack

    /**
     * Called before every ability runs (AbilityRegistryMixin), after the Vow gate. With the sheathed Katana in hand, Attack and Strong
     * attack are the iaido draw and this returns true (the normal punch is cancelled). Everything else goes on as usual.
     */
    public static boolean interceptBasic(String id, ServerPlayer sp) {
        if (!"nen_attack".equals(id) && !"nen_strong".equals(id) && !"nen_strong_release".equals(id) && !"nen_barrage".equals(id)) return false;
        if (!holding(sp)) return false;
        State s = STATES.get(sp.getUUID());
        if ("nen_barrage".equals(id)) return s != null && (s.windup > 0 || s.charging); // a normal barrage, just not from inside the stance
        if (!sp.isAlive() || sp.isSpectator() || HatsuEffects.isStunned(sp)) return true;
        s = state(sp);
        switch (id) {
            case "nen_attack" -> begin(sp, s, false);
            case "nen_strong" -> {
                s.strongLast = sp.tickCount;
                if (!s.strongHeld) { // the first tick of a press; the key-repeats that follow do nothing
                    s.strongHeld = true;
                    startCharge(sp, s);
                }
            }
            case "nen_strong_release" -> {
                boolean was = s.strongHeld;
                s.strongHeld = false;
                if (s.charging) releaseCharge(sp, s); // the key came up: the draw
                return was; // a release that belongs to a charge we never started is left to the base mod
            }
            default -> { }
        }
        return true;
    }

    private static State state(ServerPlayer sp) {
        return STATES.computeIfAbsent(sp.getUUID(), k -> new State());
    }

    /** Attack: into the stance, and the dash comes {@link IaidoTuning#WINDUP_TICKS} ticks later, from {@link #serverTick}. */
    private static void begin(ServerPlayer sp, State s, boolean strong) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        if (s.windup > 0 || s.charging || now < s.readyAt) return;
        s.windup = IaidoTuning.WINDUP_TICKS;
        s.mult = 1f;
        s.distMult = 1.0;
        s.readyAt = now + IaidoTuning.WINDUP_TICKS + (strong ? IaidoTuning.STRONG_COOLDOWN_TICKS : IaidoTuning.ATTACK_COOLDOWN_TICKS);
        slow(sp, true);
        anim(sp, ANIM);
        sound(level, sp.position(), SoundEvents.CROSSBOW_LOADING_END, 0.7f, 1.6f); // the thumb on the guard
    }

    /** Strong attack, key goes down: into the stance and stay there for as long as the key is held. */
    private static void startCharge(ServerPlayer sp, State s) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        if (s.windup > 0 || s.charging || level.getGameTime() < s.readyAt) return;
        s.charging = true;
        s.charge = 0;
        slow(sp, true);
        anim(sp, ANIM_CHARGE);
        sound(level, sp.position(), SoundEvents.CROSSBOW_LOADING_END, 0.7f, 1.6f);
    }

    /** Strong attack, key comes up: the draw. The longer it was held (up to a full charge) the further the lunge. */
    private static void releaseCharge(ServerPlayer sp, State s) {
        s.charging = false;
        if (!(sp.level() instanceof ServerLevel level)) return;
        float progress = Math.min(1f, s.charge / (float) IaidoTuning.CHARGE_FULL_TICKS);
        s.distMult = 1.0 + (IaidoTuning.FULL_CHARGE_DISTANCE_MULT - 1.0) * progress;
        s.mult = IaidoTuning.STRONG_DAMAGE_MULT_UNCHARGED + (IaidoTuning.STRONG_DAMAGE_MULT_FULL - IaidoTuning.STRONG_DAMAGE_MULT_UNCHARGED) * progress;
        // the stance is already settled after a real hold; a quick tap still gets the full stance time before the cut
        s.windup = Math.max(2, IaidoTuning.WINDUP_TICKS - s.charge);
        s.readyAt = level.getGameTime() + s.windup + IaidoTuning.STRONG_COOLDOWN_TICKS; // the cooldown counts from the release, not the hold
        anim(sp, ANIM_CUT);
    }

    // ---------------------------------------------------------------- ticking

    /** Every server tick: counts the stance down and fires the dash, drops stances that can no longer be held. */
    public static void serverTick(MinecraftServer server) {
        if (STATES.isEmpty()) return;
        long now = server.overworld().getGameTime();
        Iterator<Map.Entry<UUID, State>> it = STATES.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, State> en = it.next();
            State s = en.getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null) {
                it.remove();
                continue;
            }
            if (s.strongHeld && sp.tickCount - s.strongLast > 5) s.strongHeld = false; // key-up lost, or another ability was picked mid-charge
            if (s.charging) {
                if (!sp.isAlive() || sp.isSpectator() || !holding(sp) || HatsuEffects.isStunned(sp) || !s.strongHeld) {
                    cancel(sp, s);
                } else {
                    s.charge++; // no upper limit: the stance can be held for as long as the user likes
                    chargeFx(sp, s);
                }
            }
            if (s.windup > 0) {
                if (!sp.isAlive() || sp.isSpectator() || !holding(sp) || HatsuEffects.isStunned(sp)) {
                    cancel(sp, s);
                } else if (--s.windup <= 0) {
                    s.windup = 0;
                    dash(sp, s);
                }
            }
            if (s.windup <= 0 && !s.charging && !s.strongHeld && now >= s.readyAt) it.remove();
        }
    }

    /** The stance is dropped without a cut (the Katana was put away, the user died or was stunned...). */
    private static void cancel(ServerPlayer sp, State s) {
        s.windup = 0;
        s.charging = false;
        s.distMult = 1.0;
        slow(sp, false);
        anim(sp, "stop_anim");
    }

    /** A glint at the guard while the stance is held, and a chime + burst the moment the charge is full. */
    private static void chargeFx(ServerPlayer sp, State s) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        if (s.charge == IaidoTuning.CHARGE_FULL_TICKS) {
            sound(level, sp.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 1.0f, 1.8f);
            level.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1.0, sp.getZ(), 14, 0.35, 0.5, 0.35, 0.05);
        } else if (s.charge % 8 == 0) {
            float p = Math.min(1f, s.charge / (float) IaidoTuning.CHARGE_FULL_TICKS);
            level.sendParticles(ParticleTypes.CRIT, sp.getX(), sp.getY() + 0.9, sp.getZ(), 1 + (int) (p * 3), 0.3, 0.4, 0.3, 0.02);
        }
    }

    // ---------------------------------------------------------------- the dash

    private static void dash(ServerPlayer sp, State s) {
        slow(sp, false);
        if (!(sp.level() instanceof ServerLevel level)) return;

        // the dash goes where the user looks: look up and it lunges into the air. On the ground a downward look is levelled (no digging into the floor).
        float pitch = sp.getXRot();
        if (sp.onGround() && pitch > 0f) pitch = 0f;
        Vec3 dir = Vec3.directionFromRotation(pitch, sp.getYRot());
        Vec3 start = sp.position();
        double dist = IaidoTuning.DASH_DISTANCE * s.distMult; // a fully charged Strong attack lunges twice as far (and cuts everything on the way)
        s.distMult = 1.0;

        // who is cut: seen from where the user stands NOW, before the move, so a wall in the way protects whoever is behind it
        Vec3 p0 = start.add(0, sp.getBbHeight() * 0.5, 0);
        Vec3 p1 = p0.add(dir.scale(dist));
        List<LivingEntity> victims = new ArrayList<>();
        AABB area = new AABB(p0, p1).inflate(IaidoTuning.HIT_HALF_WIDTH + 2.0, IaidoTuning.HIT_EXTRA_HEIGHT + 2.5, IaidoTuning.HIT_HALF_WIDTH + 2.0);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, t -> hostile(sp, t))) {
            AABB reach = e.getBoundingBox().inflate(IaidoTuning.HIT_HALF_WIDTH, IaidoTuning.HIT_EXTRA_HEIGHT, IaidoTuning.HIT_HALF_WIDTH);
            if (!reach.contains(p0) && reach.clip(p0, p1).isEmpty()) continue; // not on the path, not within reach
            if (!sp.hasLineOfSight(e)) continue;
            victims.add(e);
        }

        // where the user ends up: as far as the blocks allow. Creatures are passed through, not stopped by.
        Vec3 end = dashEnd(level, sp, dir, dist);
        boolean moved = end.distanceToSqr(start) > 1.0E-4 && sp.connection != null;
        if (moved) {
            sp.connection.teleport(end.x, end.y, end.z, sp.getYRot(), sp.getXRot());
            sp.fallDistance = 0f;
        }

        effects(level, sp, start, end, dir, dist, moved);

        // the cut
        Combat c = Combat.get(sp);
        float dmg = IaidoTuning.ATTACK_DAMAGE * s.mult * (c != null ? c.getSpiritBonus() : 1f);
        int hits = 0;
        for (LivingEntity v : victims) {
            if (!v.isAlive()) continue;
            v.invulnerableTime = 0; // a draw is never swallowed by the hit just before it
            v.hurt(level.damageSources().playerAttack(sp), dmg);
            v.knockback(IaidoTuning.KNOCKBACK, -dir.x, -dir.z); // pushed on along the cut
            v.hurtMarked = true;
            Vec3 at = v.position().add(0, v.getBbHeight() * 0.6, 0);
            level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 8, 0.25, 0.3, 0.25, 0.25);
            level.sendParticles(ParticleTypes.DAMAGE_INDICATOR, at.x, at.y, at.z, 3, 0.2, 0.25, 0.2, 0.1);
            hits++;
        }
        if (hits > 0) {
            sound(level, end, SoundEvents.PLAYER_ATTACK_CRIT, 0.9f, 1.0f);
            InteractionHand nick = heldHand(sp);
            if (nick != null) sp.getItemInHand(nick).hurtAndBreak(1, sp, p -> p.broadcastBreakEvent(nick)); // one nick per draw that connects
        }

        // the blade is out: the sheathed Katana becomes the drawn one, as if the user had right-clicked it (enchantments, wear and name are kept)
        InteractionHand drawn = heldHand(sp);
        if (drawn != null) KatanaItem.swap(sp, drawn, sp.getItemInHand(drawn), KatanaItems.KATANA);
    }

    /** How far the user can dash: the end point, walking the hitbox forward a quarter block at a time and stepping up slabs and stairs. */
    private static Vec3 dashEnd(ServerLevel level, ServerPlayer sp, Vec3 dir, double dist) {
        AABB box = sp.getBoundingBox();
        double best = 0, bestLift = 0, lift = 0;
        for (double d = 0.25; d <= dist + 1.0E-6; d += 0.25) {
            Vec3 off = dir.scale(d);
            if (level.noCollision(sp, box.move(off.x, off.y + lift, off.z))) {
                best = d;
                bestLift = lift;
            } else if (lift == 0 && sp.onGround() && level.noCollision(sp, box.move(off.x, off.y + IaidoTuning.STEP_HEIGHT, off.z))) {
                lift = IaidoTuning.STEP_HEIGHT;
                best = d;
                bestLift = lift;
            } else {
                break;
            }
        }
        return sp.position().add(dir.x * best, dir.y * best + bestLift, dir.z * best);
    }

    /** A bright streak where the user went, the sweep of the blade along the whole cut, a puff where they stood, and the whoosh. */
    private static void effects(ServerLevel level, ServerPlayer sp, Vec3 start, Vec3 end, Vec3 dir, double dist, boolean moved) {
        Vec3 path = end.subtract(start);
        double len = path.length();
        if (moved && len > 0.01) {
            Vec3 step = path.scale(1.0 / len);
            for (double d = 0; d <= len; d += 0.4) {
                Vec3 at = start.add(step.scale(d));
                level.sendParticles(ParticleTypes.END_ROD, at.x, at.y + 0.9, at.z, 1, 0.05, 0.25, 0.05, 0.0);
            }
        }
        for (double d = 0.8; d <= dist; d += 1.0) {
            Vec3 at = start.add(dir.scale(d));
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y + 1.0, at.z, 1, 0, 0, 0, 0);
        }
        level.sendParticles(ParticleTypes.CLOUD, start.x, start.y + 0.15, start.z, 8, 0.3, 0.05, 0.3, 0.04);
        sound(level, start, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.7f);
        sound(level, start, SoundEvents.TRIDENT_RIPTIDE_1, 0.5f, 1.7f);
    }

    // ---------------------------------------------------------------- helpers

    /** Same rule as the other weapons: creatures that are alive, not the user, not allies, not creative / spectator players, not armor stands. */
    private static boolean hostile(ServerPlayer sp, Entity e) {
        if (!(e instanceof LivingEntity le) || le == sp || !le.isAlive() || e instanceof ArmorStand) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        return !AllianceUtils.isAlly(e, sp);
    }

    /** The planted feel of the stance: movement speed is cut for as long as it lasts. */
    private static void slow(ServerPlayer sp, boolean on) {
        AttributeInstance speed = sp.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) return;
        speed.removeModifier(SLOW_UUID);
        if (on) speed.addTransientModifier(new AttributeModifier(SLOW_UUID, "Iaido stance", -IaidoTuning.STANCE_SLOW, AttributeModifier.Operation.MULTIPLY_TOTAL));
    }

    private static void anim(ServerPlayer sp, String name) {
        ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(sp.getUUID(), name, false), sp);
    }

    private static void sound(ServerLevel level, Vec3 at, SoundEvent ev, float vol, float pitch) {
        level.playSound(null, at.x, at.y, at.z, ev, SoundSource.PLAYERS, vol, pitch);
    }

    // ---------------------------------------------------------------- cleanup

    /** Death, logout: forget the user (a transient slow goes with the logout anyway, but a death keeps the entity's attributes). */
    public static void clear(ServerPlayer sp) {
        if (STATES.remove(sp.getUUID()) != null) slow(sp, false);
    }

    public static void reset() {
        STATES.clear();
    }
}
