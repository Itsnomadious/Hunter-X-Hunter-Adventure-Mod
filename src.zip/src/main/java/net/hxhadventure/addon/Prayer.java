package net.hxhadventure.addon;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketPrayFx;

/**
 * The "I must pray before every attack" Condition (bindable to Attack, Strong attack and Barrage attack).
 * <ul>
 *   <li>Press the attack: you start praying (hands clasped, 3 seconds) and the attack is held back.</li>
 *   <li>When the prayer ends the attack is delivered automatically at full damage and counts as one prayer.</li>
 *   <li>Condition only: press the attack again while still praying and it goes off at once, but at half damage and without counting.</li>
 *   <li>The Vow "I cannot use this unless I pray first" (attacks and Hatsu abilities) works the same way but the prayer can never
 *       be cut short. It stacks with the Condition.</li>
 *   <li>Every 100 prayers followed by an attack make the next prayers 1.03473x quicker. At 10000 a prayer takes 0.1 s, so it is
 *       instant: the press attacks straight away at full damage. Nothing ever tells the player they are getting faster.</li>
 * </ul>
 * Also tracks which basic attack is running, so Conditions, Limitations and Vows bound to it multiply its damage.
 */
public final class Prayer {
    private Prayer() {}

    public static final int BASE_TICKS = 60;          // 3 seconds
    public static final int MIN_TICKS = 2;            // 0.1 seconds
    public static final double STEP = 1.03473;        // per 100 prayers
    public static final int MAX_PRAYERS = 10000;
    public static final int LOTUS_FLASH_TICKS = 30;   // how long the Guanyin user's floating-lotus prayer plays at 10000 prayers (visual only)

    private static final class State {
        String id;        // the attack or ability being prayed for
        long endAt;       // gameTime the prayer finishes
        boolean done;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();
    /** The attack currently running: owner -> {until gameTime, halved (0/1), attack id}. */
    private static final Map<UUID, Object[]> WINDOW = new HashMap<>();

    /** Ticks one prayer takes after this many prayers. */
    public static int prayerTicks(int prayers) {
        if (prayers >= MAX_PRAYERS) return MIN_TICKS;
        double t = BASE_TICKS / Math.pow(STEP, prayers / 100);
        return Math.max(MIN_TICKS, (int) Math.round(t));
    }

    /** Until when (gameTime) each player cannot move: the "I cannot move while using this" Limitation. */
    private static final Map<UUID, Long> ROOT = new HashMap<>();
    private static final UUID ROOT_ID = UUID.fromString("a1000000-0000-4000-8000-0000000000a1");

    /** Players held in Ko by the "forces me into Ko" Limitation: until when, and the aura state to go back to. */
    private static final Map<UUID, Object[]> KO = new HashMap<>();

    /** "If it misses I die": per player, ability id -> {deadline gameTime, hit (0/1)}. A hit is any damage the player deals to someone else. */
    private static final Map<UUID, Map<String, long[]>> MISS = new HashMap<>();

    /** How long each damaging ability has to land a hit (ticks after it fires). Charged or flying moves get longer. */
    private static int missWindow(String id) {
        if (Vows.isAttack(id)) return windowTicks(id) + 10;
        return switch (id) {
            case net.hxhadventure.addon.Jajanken.PAPER_ID, net.hxhadventure.addon.DragonHead.ID -> 100;
            case net.hxhadventure.addon.GumCards.ID -> 80;
            default -> 40;
        };
    }

    /** The player dealt damage to someone: every "if it misses" watch they have running is satisfied. */
    public static void noteHit(ServerPlayer sp) {
        Map<String, long[]> m = MISS.get(sp.getUUID());
        if (m != null) for (long[] w : m.values()) w[1] = 1;
    }

    private static void tickMiss(ServerPlayer sp) {
        Map<String, long[]> m = MISS.get(sp.getUUID());
        if (m == null) return;
        long now = sp.level().getGameTime();
        var it = m.entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            if (!sp.isAlive()) {
                it.remove();
            } else if (e.getValue()[1] == 1) {
                it.remove();
            } else if (now > e.getValue()[0]) {
                it.remove();
                Vows.breakVow(sp, Vows.label(e.getKey()) + " missed");
                break;
            }
        }
        if (m.isEmpty()) MISS.remove(sp.getUUID());
    }

    private static int useTicks(String id) {
        return Vows.isAttack(id) ? windowTicks(id) : 15;
    }

    private static int windowTicks(String id) {
        return Vows.STRONG.equals(id) ? 30 : Vows.BARRAGE.equals(id) ? 60 : 14;
    }

    /**
     * Called before an attack or Hatsu ability runs. Returns true to hold it back (a prayer has begun or is still going).
     * When the prayer finishes, the tick delivers the attack itself.
     */
    static boolean gate(ServerPlayer sp, String id, NenAddonData d) {
        long now = sp.level().getGameTime();
        boolean attack = Vows.isAttack(id);
        if (attack) Vows.normalizePrayer(sp, d, id); // never both: the Vow is the stronger form of the Condition
        boolean cond = attack && d.vows.contains(Vows.prayRule(id));
        boolean vow = d.vows.contains(Vows.prayVow(id));
        boolean halved = false;
        boolean root = d.vows.contains(Vows.rootLimit(id));
        if (cond || vow) {
            State st = STATES.get(sp.getUUID());
            if (st == null) {
                int ticks = prayerTicks(d.prayers);
                if (ticks <= MIN_TICKS) {
                    // 10000 prayers: effectively instant, it goes off straight away
                    d.prayers++;
                    d.markSave(); // and no clasped-hands animation any more: 10000 gratitude means there is nothing left to play
                    // ...except the 100-Type Guanyin's users WHILE THE STATUE STANDS, who at 10000 prayers play the lotus hand motion (they already hover). Purely visual (style 2): the attack is not delayed
                    if (d.prayers >= MAX_PRAYERS && Guanyin.canUse(net.hxhadventure.abilities.Combat.get(sp)) && Guanyin.isSummoned(sp)) {
                        AddonNetwork.sendToTrackingAndSelf(new PacketPrayFx(sp.getId(), LOTUS_FLASH_TICKS, 2), sp);
                    }
                } else {
                    State n = new State();
                    n.id = id;
                    n.endAt = now + ticks;
                    STATES.put(sp.getUUID(), n);
                    if (root) ROOT.put(sp.getUUID(), n.endAt + 2); // still for the whole prayer
                    net.hxhadventure.abilities.Combat pc = net.hxhadventure.abilities.Combat.get(sp);
                    // below 10000 prayers everybody (the Guanyin's users too) prays with the ordinary clasped hands; the lotus hand motion is for 10000 only, and only while the Guanyin is summoned (never for a plain punch)
                    AddonNetwork.sendToTrackingAndSelf(new PacketPrayFx(sp.getId(), ticks, d.prayers >= MAX_PRAYERS && Guanyin.canUse(pc) && Guanyin.isSummoned(sp) ? 1 : 0), sp);
                    return true; // praying: it waits
                }
            } else if (!st.done) {
                if (vow || st.id == null) return true; // a Vow: the prayer cannot be cut short
                // Condition only: pressed again before the prayer finished, so it goes off now at half damage
                STATES.remove(sp.getUUID());
                AddonNetwork.sendToTrackingAndSelf(new PacketPrayFx(sp.getId(), 0), sp);
                halved = true;
            } else {
                // the prayer finished and the tick is delivering: full strength, and it counts
                STATES.remove(sp.getUUID());
                AddonNetwork.sendToTrackingAndSelf(new PacketPrayFx(sp.getId(), 0), sp);
                if (d.prayers < MAX_PRAYERS) d.prayers++;
                d.markSave();
            }
        }
        boolean chargeUp = Vows.isChargeUp(id); // charge-ups start their Ko / root / miss rules themselves (chargeBegan, attackOut)
        if (root && !chargeUp) ROOT.put(sp.getUUID(), now + useTicks(id)); // still while it is being used
        if (!chargeUp && d.vows.contains(Vows.missVow(id))) {
            MISS.computeIfAbsent(sp.getUUID(), k -> new HashMap<>()).put(id, new long[] {now + missWindow(id), 0});
        }
        if (!chargeUp && d.vows.contains(Vows.koLimit(id))) {
            net.hxhadventure.abilities.Combat c = net.hxhadventure.abilities.Combat.get(sp);
            if (c != null) {
                Object[] cur = KO.get(sp.getUUID());
                // keep the first snapshot if another use is still holding Ko, so the player goes back to what they really were in
                NenAddonData.AuraSnapshot snap = cur != null ? (NenAddonData.AuraSnapshot) cur[1] : d.snapshotAura(c);
                KO.put(sp.getUUID(), new Object[] {now + useTicks(id), snap});
                d.enforceKo(sp);
            }
        }
        if (attack) WINDOW.put(sp.getUUID(), new Object[] {now + windowTicks(id), halved, id});
        return false;
    }

    /** Charge-ups with a Ko / root limitation sworn: owner -> {ability id, own aura snapshot to restore (or null when the ability restores itself)}. */
    private static final Map<UUID, Object[]> HOLD = new HashMap<>();

    /**
     * A charge-up really started (called by the ability the moment the charge begins, i.e. on the press): the sworn "forces me into Ko" and
     * "cannot move" limitations apply from now until the attack goes out or the charge ends. {@code saved} is the aura state the ability
     * itself will restore, or null if it does not restore anything (then the state is restored here).
     */
    public static void chargeBegan(ServerPlayer sp, String id, NenAddonData.AuraSnapshot saved) {
        NenAddonData d = NenAddonData.peek(sp);
        if (d == null) return;
        boolean ko = d.vows.contains(Vows.koLimit(id));
        boolean root = d.vows.contains(Vows.rootLimit(id));
        if (!ko && !root) return;
        NenAddonData.AuraSnapshot own = null;
        net.hxhadventure.abilities.Combat c = net.hxhadventure.abilities.Combat.get(sp);
        if (ko && saved == null && c != null) own = d.snapshotAura(c);
        HOLD.put(sp.getUUID(), new Object[] {id, own});
        long now = sp.level().getGameTime();
        if (root) ROOT.put(sp.getUUID(), now + 2);
        if (ko) d.enforceKo(sp);
    }

    private static void tickHold(ServerPlayer sp) {
        Object[] h = HOLD.get(sp.getUUID());
        if (h == null) return;
        String id = (String) h[0];
        NenAddonData d = NenAddonData.get(sp);
        if (sp.isAlive() && Vows.chargeActive(sp, id)) {
            long now = sp.level().getGameTime();
            if (d.vows.contains(Vows.rootLimit(id))) ROOT.put(sp.getUUID(), now + 2);
            if (d.vows.contains(Vows.koLimit(id))) d.enforceKo(sp);
            return;
        }
        // the attack went out (or the charge was lost): the limitations end right now
        HOLD.remove(sp.getUUID());
        ROOT.remove(sp.getUUID());
        if (h[1] != null && sp.isAlive()) d.restoreAura(sp, (NenAddonData.AuraSnapshot) h[1]);
    }

    /** A charge-up's attack goes out now (call before it deals damage): the "if it misses I die" watch starts here, not at the press. */
    public static void attackOut(ServerPlayer sp, String id) {
        NenAddonData d = NenAddonData.peek(sp);
        if (d == null || !d.vows.contains(Vows.missVow(id))) return;
        MISS.computeIfAbsent(sp.getUUID(), k -> new HashMap<>()).put(id, new long[] {sp.level().getGameTime() + missWindow(id), 0});
    }

    /** Damage multiplier for a melee hit by this player while one of the basic attacks is running. */
    public static float damageMult(Player p) {
        Object[] w = WINDOW.get(p.getUUID());
        if (w == null) return 1f;
        if (p.level().getGameTime() > (long) w[0]) {
            WINDOW.remove(p.getUUID());
            return 1f;
        }
        float m = Vows.power(p, (String) w[2]);
        return (boolean) w[1] ? m * 0.5f : m;
    }

    private static void tickKo(ServerPlayer sp) {
        Object[] k = KO.get(sp.getUUID());
        if (k == null) return;
        NenAddonData d = NenAddonData.get(sp);
        if (!sp.isAlive()) {
            KO.remove(sp.getUUID());
        } else if (sp.level().getGameTime() <= (long) k[0]) {
            d.enforceKo(sp); // held every tick, so nothing can switch it off mid-use
        } else {
            KO.remove(sp.getUUID());
            d.restoreAura(sp, (NenAddonData.AuraSnapshot) k[1]);
        }
    }

    private static void tickRoot(ServerPlayer sp) {
        Long until = ROOT.get(sp.getUUID());
        net.minecraft.world.entity.ai.attributes.AttributeInstance speed =
            sp.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
        boolean rooted = until != null && sp.isAlive() && sp.level().getGameTime() <= until;
        if (speed == null) return;
        if (rooted) {
            if (speed.getModifier(ROOT_ID) == null) {
                speed.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(ROOT_ID, "hxh_root", -1.0,
                    net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.MULTIPLY_TOTAL));
            }
            net.minecraft.world.phys.Vec3 v = sp.getDeltaMovement();
            if (sp.onGround() && v.y > 0) { // no jumping out of it either
                sp.setDeltaMovement(0, 0, 0);
                sp.hurtMarked = true;
            }
        } else {
            if (until != null) ROOT.remove(sp.getUUID());
            if (speed.getModifier(ROOT_ID) != null) speed.removeModifier(ROOT_ID);
        }
    }

    public static void tick(ServerPlayer sp) {
        tickHold(sp);
        tickRoot(sp);
        tickMiss(sp);
        tickKo(sp);
        State st = STATES.get(sp.getUUID());
        if (st == null) return;
        long now = sp.level().getGameTime();
        if (!sp.isAlive()) {
            STATES.remove(sp.getUUID());
            AddonNetwork.sendToTrackingAndSelf(new PacketPrayFx(sp.getId(), 0), sp);
            return;
        }
        if (st.done || now < st.endAt) return;
        st.done = true;
        // a subtle visual cue only: a few soft glints at the clasped hands
        if (sp.level() instanceof net.minecraft.server.level.ServerLevel sl) {
            net.minecraft.world.phys.Vec3 look = sp.getLookAngle();
            sl.sendParticles(net.minecraft.core.particles.ParticleTypes.END_ROD,
                sp.getX() + look.x * 0.5, sp.getY() + 1.2, sp.getZ() + look.z * 0.5, 4, 0.12, 0.1, 0.12, 0.01);
        }
        deliver(sp, st.id);
        if (STATES.get(sp.getUUID()) == st) { // the ability was refused on the way (a rule forbade it): drop the prayer
            STATES.remove(sp.getUUID());
            AddonNetwork.sendToTrackingAndSelf(new PacketPrayFx(sp.getId(), 0), sp);
        }
    }

    private static java.lang.reflect.Method execute;

    /** Runs the ability the prayer was for, exactly as if the key had just been pressed. */
    private static void deliver(ServerPlayer sp, String id) {
        try {
            if (execute == null) {
                execute = net.hxhadventure.abilities.AbilityRegistry.class.getDeclaredMethod("execute", String.class, ServerPlayer.class);
                execute.setAccessible(true);
            }
            execute.invoke(null, id, sp);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Prayer could not run " + id, e);
        }
    }

    /**
     * Hina lifted some rules: anything already running on behalf of a rule that is no longer sworn stops now
     * (a prayer in progress, the "cannot move" hold, a forced Ko, an "if it misses I die" watch, the halved-damage window).
     */
    public static void releaseUnsworn(ServerPlayer sp) {
        NenAddonData d = NenAddonData.get(sp);
        UUID id = sp.getUUID();

        State st = STATES.get(id);
        if (st != null && st.id != null) {
            boolean stillSworn = d.vows.contains(Vows.prayVow(st.id)) || (Vows.isAttack(st.id) && d.vows.contains(Vows.prayRule(st.id)));
            if (!stillSworn) {
                STATES.remove(id);
                AddonNetwork.sendToTrackingAndSelf(new PacketPrayFx(sp.getId(), 0), sp);
            }
        }

        Object[] w = WINDOW.get(id);
        if (w != null && (boolean) w[1] && !d.vows.contains(Vows.prayRule((String) w[2]))) WINDOW.remove(id);

        if (d.vows.stream().noneMatch(v -> v.endsWith("_lroot"))) ROOT.remove(id); // tickRoot drops the speed modifier next tick

        Map<String, long[]> miss = MISS.get(id);
        if (miss != null) {
            miss.keySet().removeIf(k -> !d.vows.contains(Vows.missVow(k)));
            if (miss.isEmpty()) MISS.remove(id);
        }

        if (d.vows.stream().noneMatch(v -> v.endsWith("_lko"))) {
            Object[] ko = KO.remove(id);
            if (ko != null) d.restoreAura(sp, (NenAddonData.AuraSnapshot) ko[1]);
            Object[] h = HOLD.get(id);
            if (h != null && h[1] != null) {
                HOLD.remove(id);
                d.restoreAura(sp, (NenAddonData.AuraSnapshot) h[1]);
            }
        }
    }

    public static void forget(UUID id) {
        STATES.remove(id);
        WINDOW.remove(id);
        ROOT.remove(id);
        MISS.remove(id);
        KO.remove(id);
        HOLD.remove(id);
    }
}
