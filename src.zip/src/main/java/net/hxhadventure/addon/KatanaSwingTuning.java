package net.hxhadventure.addon;

import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;

/**
 * Numbers and rules for the drawn Katana's two-handed slashes (Attack / Strong attack / Barrage, picked in Combat.style()).
 * The clips are assets/hxhadventure/player_animation/katana_*.json: attack_{diag,lr,rl,vert}, strong_{diag,lr,rl,vert}, barrage_{diag,lr,rl}
 * and katana_charge (the held pose while Strong attack charges). diag = top right to bottom left, lr = left to right, rl = right to left,
 * vert = straight down the middle.
 */
public final class KatanaSwingTuning {
    private KatanaSwingTuning() {}

    /**
     * Strong attack picks a slash by weight (out of the total of all four): the vertical down the middle and the diagonal from the right
     * to the left come up most, the two horizontals are rare. Set a horizontal to 0 to take it out of the Strong attack entirely.
     */
    public static final int STRONG_WEIGHT_VERTICAL = 45;
    public static final int STRONG_WEIGHT_DIAGONAL = 45;
    /** Weight of EACH horizontal (left to right, right to left). */
    public static final int STRONG_WEIGHT_HORIZONTAL = 5;

    // ---- Barrage (hold): slower, one full slash at a time ----
    /** Playback speed of the katana barrage clips (0.3 s clip / 0.75 = 0.4 s per slash). */
    public static final float BARRAGE_ANIM_SPEED = 0.75f;
    /** Ticks between barrage slashes (20 = 1 s). Keep it about equal to the clip length so each slash finishes before the next starts. */
    public static final int BARRAGE_INTERVAL_TICKS = 8;
    /** Ticks into a barrage slash when its hit lands (the cut itself starts ~0.1 s in). */
    public static final int BARRAGE_HIT_DELAY_TICKS = 3;
    /** Each slower slash hits harder, so the damage per second stays what the fast barrage (a hit every 3 ticks) was. */
    public static final float BARRAGE_DAMAGE_MULT = BARRAGE_INTERVAL_TICKS / 3.0f;

    // ---- Sword arc (thin white streak where the blade has been) ----
    /** Brightness of the streak at its newest end (0 to 1); keep it low, it is meant to be almost invisible. */
    public static final float TRAIL_ALPHA = 0.28f;
    /** How long a piece of the streak lasts (ticks). */
    public static final float TRAIL_LIFE_TICKS = 5.0f;
    /** Thickness of the streak, as a length along the blade in model units (the blade is ~1.7 long). Smaller = thinner. */
    public static final float TRAIL_THICKNESS = 0.10f;
    /** Seconds into a slash clip between which the streak is drawn: {from, to} of the cutting part only. */
    public static float[] trailWindow(String anim) {
        if (anim == null) return null;
        if (anim.startsWith("katana_barrage")) return new float[] {0.07f, 0.17f};
        if (anim.startsWith("katana_strong")) return new float[] {0.22f, 0.44f};
        if (anim.startsWith("katana_attack")) return new float[] {0.13f, 0.27f};
        return null;
    }

    /** Playback speed of a katana clip. */
    public static float animSpeed(String anim) {
        return anim != null && anim.startsWith("katana_barrage") ? BARRAGE_ANIM_SPEED : 1.0f;
    }

    /** The drawn Katana in the main hand, held by the right arm (the clips hold it in the right hand, left hand below it on the grip). */
    public static boolean holdingDrawn(Player p) {
        return KatanaItems.KATANA != null && p.getMainHandItem().is(KatanaItems.KATANA) && p.getMainArm() == HumanoidArm.RIGHT;
    }
}
