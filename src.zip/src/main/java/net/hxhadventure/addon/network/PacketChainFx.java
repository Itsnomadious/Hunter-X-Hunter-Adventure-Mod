package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.ChainFx;

/** Server -> client: start/stop a chain visual. kind = ChainFx.Kind ordinal. */
public class PacketChainFx {
    private final byte kind;
    private final int caster, target, duration;
    private final float dx, dy, dz, side, range;

    public PacketChainFx(ChainFx.Kind kind, int caster, int target, int duration, float dx, float dy, float dz, float side, float range) {
        this.kind = (byte) kind.ordinal();
        this.caster = caster;
        this.target = target;
        this.duration = duration;
        this.dx = dx;
        this.dy = dy;
        this.dz = dz;
        this.side = side;
        this.range = range;
    }

    public PacketChainFx(FriendlyByteBuf b) {
        kind = b.readByte();
        caster = b.readVarInt();
        target = b.readVarInt();
        duration = b.readVarInt();
        dx = b.readFloat();
        dy = b.readFloat();
        dz = b.readFloat();
        side = b.readFloat();
        range = b.readFloat();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeByte(kind);
        b.writeVarInt(caster);
        b.writeVarInt(target);
        b.writeVarInt(duration);
        b.writeFloat(dx);
        b.writeFloat(dy);
        b.writeFloat(dz);
        b.writeFloat(side);
        b.writeFloat(range);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> ChainFx.add(kind, caster, target, duration, dx, dy, dz, side, range)));
        ctx.get().setPacketHandled(true);
    }
}
