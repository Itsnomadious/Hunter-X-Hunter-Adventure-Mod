package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.GyoInfoHud;

/** Server -> the Gyo user: what to show under the crosshair about the player they are looking at (empty text = nothing). */
public class PacketGyoInfo {
    private final int entityId;
    private final String text;

    public PacketGyoInfo(int entityId, String text) {
        this.entityId = entityId;
        this.text = text;
    }

    public PacketGyoInfo(FriendlyByteBuf b) {
        entityId = b.readInt();
        text = b.readUtf(200);
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeInt(entityId);
        b.writeUtf(text, 200);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> GyoInfoHud.set(text)));
        ctx.get().setPacketHandled(true);
    }
}
