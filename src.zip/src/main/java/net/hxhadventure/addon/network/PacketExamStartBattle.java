package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.HunterExam;

/** Client -> server: the player accepted Menchi's test (the second, final test). The server checks everything again before the test takers spawn. */
public class PacketExamStartBattle {
    private final int npcId;

    public PacketExamStartBattle(int npcId) {
        this.npcId = npcId;
    }

    public PacketExamStartBattle(FriendlyByteBuf b) {
        npcId = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(npcId);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) HunterExam.startSecond(sp, npcId);
        });
        ctx.get().setPacketHandled(true);
    }
}
