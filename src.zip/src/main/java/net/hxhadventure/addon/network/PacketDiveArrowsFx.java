package net.hxhadventure.addon.network;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.DiveArrowFx;

/** Server -> client: a batch of golden arrows (Dragon Dive) that start falling now. Each is {x, startY, z, impactY}. */
public class PacketDiveArrowsFx {
    private final float speed;
    private final float[] data; // 4 floats per arrow

    public PacketDiveArrowsFx(float speed, List<float[]> arrows) {
        this.speed = speed;
        this.data = new float[arrows.size() * 4];
        for (int i = 0; i < arrows.size(); i++) System.arraycopy(arrows.get(i), 0, data, i * 4, 4);
    }

    public PacketDiveArrowsFx(FriendlyByteBuf b) {
        speed = b.readFloat();
        int n = b.readVarInt();
        data = new float[n * 4];
        for (int i = 0; i < data.length; i++) data[i] = b.readFloat();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeFloat(speed);
        b.writeVarInt(data.length / 4);
        for (float f : data) b.writeFloat(f);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> DiveArrowFx.add(speed, data)));
        ctx.get().setPacketHandled(true);
    }
}
