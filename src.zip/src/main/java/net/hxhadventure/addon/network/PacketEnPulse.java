package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.EnGlowHandler;

/** Server -> client: entities currently sensed by En, with a colour category each. */
public class PacketEnPulse {
    private final int[] ids;
    private final byte[] cats;

    public PacketEnPulse(int[] ids, byte[] cats) {
        this.ids = ids;
        this.cats = cats;
    }

    public PacketEnPulse(FriendlyByteBuf buf) {
        int n = buf.readVarInt();
        ids = new int[n];
        cats = new byte[n];
        for (int i = 0; i < n; i++) {
            ids[i] = buf.readVarInt();
            cats[i] = buf.readByte();
        }
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeVarInt(ids.length);
        for (int i = 0; i < ids.length; i++) {
            buf.writeVarInt(ids[i]);
            buf.writeByte(cats[i]);
        }
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> EnGlowHandler.onPulse(ids, cats)));
        ctx.get().setPacketHandled(true);
    }
}
