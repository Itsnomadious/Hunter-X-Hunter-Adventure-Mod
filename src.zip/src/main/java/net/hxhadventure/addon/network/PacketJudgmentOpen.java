package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.JudgmentScreen;

/** Server -> the caster: the Stake is in. victimId >= 0 opens the command menu for that player; -1 (a self-stake) opens the Vows menu. */
public class PacketJudgmentOpen {
    private final int victimId;
    private final String name;
    private final int max;

    public PacketJudgmentOpen(int victimId, String name, int max) {
        this.victimId = victimId;
        this.name = name;
        this.max = max;
    }

    public PacketJudgmentOpen(FriendlyByteBuf b) {
        victimId = b.readVarInt() - 1;
        name = b.readUtf(64);
        max = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(victimId + 1);
        b.writeUtf(name, 64);
        b.writeVarInt(max);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            if (victimId < 0) net.minecraft.client.Minecraft.getInstance().setScreen(net.hxhadventure.addon.client.OMenu.vows());
            else net.minecraft.client.Minecraft.getInstance().setScreen(new JudgmentScreen(victimId, name, max));
        }));
        ctx.get().setPacketHandled(true);
    }
}
