package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.NeedleFx;

/**
 * Server -> clients: needles are stuck in (or pulled out of) an entity's head. {@code anchor} is the entity,
 * {@code style} is 1 = a few across the forehead, 2 = a crowd over the back of the skull, 0 = none.
 */
public class PacketNeedleFx {
    private final int anchor;
    private final int style;

    public PacketNeedleFx(int anchor, int style) {
        this.anchor = anchor;
        this.style = style;
    }

    public PacketNeedleFx(FriendlyByteBuf b) {
        anchor = b.readVarInt();
        style = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(anchor);
        b.writeVarInt(style);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> NeedleFx.set(anchor, style)));
        ctx.get().setPacketHandled(true);
    }
}
