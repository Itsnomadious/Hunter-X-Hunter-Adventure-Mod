package net.hxhadventure.addon.network;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.JudgmentChain;

/** Client -> server: the commands the caster picked for the player they pierced (the server checks everything again). */
public class PacketJudgmentApply {
    private final int victimId;
    private final List<String> ids;

    public PacketJudgmentApply(int victimId, List<String> ids) {
        this.victimId = victimId;
        this.ids = ids;
    }

    public PacketJudgmentApply(FriendlyByteBuf b) {
        victimId = b.readVarInt();
        int n = Math.min(8, b.readVarInt());
        ids = new ArrayList<>(n);
        for (int i = 0; i < n; i++) ids.add(b.readUtf(64));
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(victimId);
        b.writeVarInt(ids.size());
        for (String id : ids) b.writeUtf(id, 64);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) JudgmentChain.apply(sp, victimId, ids);
        });
        ctx.get().setPacketHandled(true);
    }
}
