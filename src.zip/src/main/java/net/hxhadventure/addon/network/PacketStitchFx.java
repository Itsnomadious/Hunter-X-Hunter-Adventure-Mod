package net.hxhadventure.addon.network;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.StitchFx;

/**
 * Server -> clients: what to draw for Machi's Nen Stitches.
 * <ul>
 *   <li>TRAP_SYNC: the full list of threads near the receiver (replaces what the client has). TRAP_ADD: one new thread.
 *       TRAP_BREAK: thread {@code i1} was cut at (d0, d1, d2), or just vanished when there is no position.</li>
 *   <li>PENDING: the first anchor of a thread being placed, at (d0, d1, d2) (only sent to its owner). PENDING_CLEAR: it is gone.</li>
 *   <li>SLASH: owner {@code i1}; origin (d0, d1, d2); direction (d3, d4) on the horizontal plane; length d5; width d6; {@code i2} = kind
 *       (0 attack, 1 strong, 2 barrage); {@code i3} = 1 for a left-handed slash.</li>
 *   <li>BIND: owner {@code i1} ties up entity {@code i2}. BIND_END: entity {@code i2} is free.</li>
 *   <li>SEW: owner {@code i1} sews up entity {@code i2} (the owner itself for a self-heal). SEW_END: owner {@code i1} stopped.</li>
 * </ul>
 */
public class PacketStitchFx {
    public static final int TRAP_SYNC = 1, TRAP_ADD = 2, TRAP_BREAK = 3, PENDING = 4, PENDING_CLEAR = 5,
        SLASH = 6, BIND = 7, BIND_END = 8, SEW = 9, SEW_END = 10;

    /** One thread of a trap: its id, its owner's entity id and its two ends. */
    public record TrapData(int id, int owner, Vec3 a, Vec3 b) {}

    private final int mode, i1, i2, i3;
    private final double[] d;
    private final List<TrapData> traps;

    private PacketStitchFx(int mode, int i1, int i2, int i3, double[] d, List<TrapData> traps) {
        this.mode = mode;
        this.i1 = i1;
        this.i2 = i2;
        this.i3 = i3;
        this.d = d;
        this.traps = traps;
    }

    private static final double[] NONE = new double[0];

    public static PacketStitchFx trapSync(List<TrapData> list) { return new PacketStitchFx(TRAP_SYNC, 0, 0, 0, NONE, list); }

    public static PacketStitchFx trapAdd(TrapData t) { return new PacketStitchFx(TRAP_ADD, 0, 0, 0, NONE, List.of(t)); }

    public static PacketStitchFx trapBreak(int id, Vec3 at) { return new PacketStitchFx(TRAP_BREAK, id, 0, 0, new double[] {at.x, at.y, at.z}, List.of()); }

    /** The thread simply vanishes (its owner died, logged out or lost the Hatsu): no snap. */
    public static PacketStitchFx trapRemove(int id) { return new PacketStitchFx(TRAP_BREAK, id, 0, 0, NONE, List.of()); }

    public static PacketStitchFx pending(Vec3 at) { return new PacketStitchFx(PENDING, 0, 0, 0, new double[] {at.x, at.y, at.z}, List.of()); }

    public static PacketStitchFx pendingClear() { return new PacketStitchFx(PENDING_CLEAR, 0, 0, 0, NONE, List.of()); }

    public static PacketStitchFx slash(int owner, Vec3 origin, double dirX, double dirZ, double length, double width, int kind, boolean left) {
        return new PacketStitchFx(SLASH, owner, kind, left ? 1 : 0, new double[] {origin.x, origin.y, origin.z, dirX, dirZ, length, width}, List.of());
    }

    public static PacketStitchFx bind(int owner, int target) { return new PacketStitchFx(BIND, owner, target, 0, NONE, List.of()); }

    public static PacketStitchFx bindEnd(int target) { return new PacketStitchFx(BIND_END, 0, target, 0, NONE, List.of()); }

    public static PacketStitchFx sew(int owner, int target) { return new PacketStitchFx(SEW, owner, target, 0, NONE, List.of()); }

    public static PacketStitchFx sewEnd(int owner) { return new PacketStitchFx(SEW_END, owner, 0, 0, NONE, List.of()); }

    public PacketStitchFx(FriendlyByteBuf b) {
        mode = b.readByte();
        i1 = b.readVarInt();
        i2 = b.readVarInt();
        i3 = b.readVarInt();
        int n = b.readByte();
        d = new double[n];
        for (int k = 0; k < n; k++) d[k] = b.readDouble();
        int count = b.readVarInt();
        traps = new ArrayList<>(count);
        for (int k = 0; k < count; k++) {
            int id = b.readVarInt();
            int owner = b.readVarInt();
            Vec3 a = new Vec3(b.readDouble(), b.readDouble(), b.readDouble());
            Vec3 e = new Vec3(b.readDouble(), b.readDouble(), b.readDouble());
            traps.add(new TrapData(id, owner, a, e));
        }
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeByte(mode);
        b.writeVarInt(i1);
        b.writeVarInt(i2);
        b.writeVarInt(i3);
        b.writeByte(d.length);
        for (double v : d) b.writeDouble(v);
        b.writeVarInt(traps.size());
        for (TrapData t : traps) {
            b.writeVarInt(t.id());
            b.writeVarInt(t.owner());
            b.writeDouble(t.a().x);
            b.writeDouble(t.a().y);
            b.writeDouble(t.a().z);
            b.writeDouble(t.b().x);
            b.writeDouble(t.b().y);
            b.writeDouble(t.b().z);
        }
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> StitchFx.receive(mode, i1, i2, i3, d, traps)));
        ctx.get().setPacketHandled(true);
    }
}
