package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.PaperFx;

/**
 * Server -> clients: an entity is playing a Paper Manipulation arm move.
 * {@code kind}: 1 = DROP (the left arm lifts to let the confetti fall), 2 = WAVE (an arm waves the fan), 3 = SWARM (the big sweep).
 * {@code left}: true for the left arm (the wave and the sweep use whichever arm holds the fan).
 */
public class PacketPaperFx {
    public static final int DROP = 1, WAVE = 2, SWARM = 3;

    private final int owner;
    private final int kind;
    private final boolean left;

    public PacketPaperFx(int owner, int kind, boolean left) {
        this.owner = owner;
        this.kind = kind;
        this.left = left;
    }

    public PacketPaperFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        kind = b.readVarInt();
        left = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeVarInt(kind);
        b.writeBoolean(left);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> PaperFx.add(owner, kind, left)));
        ctx.get().setPacketHandled(true);
    }
}
