package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.BlytheFx;

/**
 * Server -> client: Doctor Blythe of this owner. {@code active} false means it is gone. The anchor and yaw are fixed
 * for as long as it is out (it never moves); {@code targets} are the entity ids its fingers are touching right now,
 * nearest first. Sent when it appears, disappears, or the touched set changes, and to anyone who starts tracking the owner.
 */
public class PacketBlytheFx {
    private final int owner;
    private final boolean active;
    private final double x, y, z;
    private final float yaw;
    private final int[] targets;

    public PacketBlytheFx(int owner, boolean active, double x, double y, double z, float yaw, int[] targets) {
        this.owner = owner;
        this.active = active;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.targets = targets;
    }

    public PacketBlytheFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        active = b.readBoolean();
        x = b.readDouble();
        y = b.readDouble();
        z = b.readDouble();
        yaw = b.readFloat();
        int n = b.readVarInt();
        targets = new int[n];
        for (int i = 0; i < n; i++) targets[i] = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeBoolean(active);
        b.writeDouble(x);
        b.writeDouble(y);
        b.writeDouble(z);
        b.writeFloat(yaw);
        b.writeVarInt(targets.length);
        for (int t : targets) b.writeVarInt(t);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> BlytheFx.set(owner, active, x, y, z, yaw, targets)));
        ctx.get().setPacketHandled(true);
    }
}
