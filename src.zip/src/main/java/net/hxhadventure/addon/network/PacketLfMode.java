package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.LittleFlowerClient;

/** Server -> client: Little Flower's H mode went on or off (so the client reads and holds back the mouse buttons). */
public class PacketLfMode {
    private final boolean on;

    public PacketLfMode(boolean on) { this.on = on; }
    public PacketLfMode(FriendlyByteBuf b) { on = b.readBoolean(); }
    public void toBytes(FriendlyByteBuf b) { b.writeBoolean(on); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> LittleFlowerClient.setMode(on)));
        ctx.get().setPacketHandled(true);
    }
}
