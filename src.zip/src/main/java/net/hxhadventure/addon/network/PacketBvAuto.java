package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.BlackVoiceClient;

/**
 * Server -> client: Black Voice's Auto Pilot. While {@code on}, the client ignores everything the player presses and instead turns the
 * view to (yaw, pitch) and presses the keys named in {@code flags} (the NPC brain's decisions). {@code on = false} gives the controls back.
 */
public class PacketBvAuto {
    public static final int FORWARD = 1, JUMP = 2, SPRINT = 4;

    private final boolean on;
    private final float yaw, pitch;
    private final byte flags;

    public PacketBvAuto(boolean on, float yaw, float pitch, int flags) {
        this.on = on;
        this.yaw = yaw;
        this.pitch = pitch;
        this.flags = (byte) flags;
    }

    public PacketBvAuto(FriendlyByteBuf b) {
        on = b.readBoolean();
        yaw = b.readFloat();
        pitch = b.readFloat();
        flags = b.readByte();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeBoolean(on);
        b.writeFloat(yaw);
        b.writeFloat(pitch);
        b.writeByte(flags);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> BlackVoiceClient.setAuto(on, yaw, pitch, flags)));
        ctx.get().setPacketHandled(true);
    }
}
