package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.HatsuCatalog;
import net.hxhadventure.addon.NenProfile;

/** Client -> server: the Hatsu picked in the Water Divination menu. Everything is checked here; the menu only offers what is allowed. */
public class PacketSelectHatsu {
    private final int kit;

    public PacketSelectHatsu(int kit) { this.kit = kit; }
    public PacketSelectHatsu(FriendlyByteBuf b) { kit = b.readVarInt(); }
    public void toBytes(FriendlyByteBuf b) { b.writeVarInt(kit); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) select(sp, kit);
        });
        ctx.get().setPacketHandled(true);
    }

    private static void select(ServerPlayer sp, int kit) {
        Combat c = Combat.get(sp);
        if (c == null || !c.hasNenUnlocked()) {
            sp.sendSystemMessage(Component.literal("\u00a7cYour nodes are not open yet. Find Kite."));
            return;
        }
        if (!NenProfile.typeRevealed(sp)) {
            sp.sendSystemMessage(Component.literal("\u00a7cLearn your Nen type first."));
            return;
        }
        HatsuCatalog.Option o = HatsuCatalog.find(c.getNenType(), kit);
        if (o == null) {
            sp.sendSystemMessage(Component.literal("\u00a7cThat Hatsu does not belong to your Nen type."));
            return;
        }
        if (c.getHatsuLevel() < HatsuCatalog.MIN_LEVEL) {
            sp.sendSystemMessage(Component.literal("\u00a7cYou must reach Level " + HatsuCatalog.MIN_LEVEL + " to choose a Hatsu."));
            return;
        }
        if (c.getCurrentKit() == kit) {
            sp.sendSystemMessage(Component.literal("\u00a77That is already your Hatsu."));
            return;
        }
        if (c.getCurrentKit() > 1 && c.getHatsuLevel() < HatsuCatalog.FREE_CHANGE_LEVEL && !c.canRespinNow()) {
            int last = sp.getPersistentData().getInt("HxHCraft_LastRespinLevel");
            int need = last <= 1 ? HatsuCatalog.CHANGE_EVERY_LEVELS : last + HatsuCatalog.CHANGE_EVERY_LEVELS;
            sp.sendSystemMessage(Component.literal("\u00a7cYour Hatsu is settled. You can change it again at Level " + need + "."));
            return;
        }

        // whatever the old Hatsu had out in the world goes (the same clean-up a death does)
        HatsuCatalog.clearAll(sp, c);

        if (!c.setKit(kit)) {
            sp.sendSystemMessage(Component.literal("\u00a7cThat Hatsu cannot be chosen."));
            return;
        }
        CompoundTag data = sp.getPersistentData();
        data.putString("HxHCraft_HatsuAbility", o.text());
        c.recordRespinLevel();
        sp.sendSystemMessage(Component.literal("\u00a7b[Water Divination] \u00a7fHatsu chosen: \u00a7e" + o.name()));
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0f, 1.5f);
    }
}
