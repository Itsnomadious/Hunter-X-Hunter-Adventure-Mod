package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.PainFx;

/**
 * Server -> client, Pain Packer visuals. kind: 0 ARMOR (id = player entity id; flag = armour on or off), 1 SUN (id = sun id; the ball of
 * aura leaves {@code from} and settles at {@code to}; size = diameter in blocks; deploy = ticks to swell; life = ticks until it goes
 * out; range = reach of the heat in blocks, used to size the scorched ground), 2 SUN_END (id = sun id), 3 HEAT (id = player entity id;
 * flag = the armour glows white-hot because the user's sun is burning).
 */
public class PacketPainFx {
    public static final byte ARMOR = 0, SUN = 1, SUN_END = 2, HEAT = 3;

    private final byte kind;
    private final int id, deploy, life;
    private final boolean flag;
    private final double fx, fy, fz, tx, ty, tz;
    private final float size, range;

    private PacketPainFx(byte kind, int id, boolean flag, Vec3 from, Vec3 to, float size, float range, int deploy, int life) {
        this.kind = kind;
        this.id = id;
        this.flag = flag;
        this.fx = from.x;
        this.fy = from.y;
        this.fz = from.z;
        this.tx = to.x;
        this.ty = to.y;
        this.tz = to.z;
        this.size = size;
        this.range = range;
        this.deploy = deploy;
        this.life = life;
    }

    public static PacketPainFx armor(int playerId, boolean on) {
        return new PacketPainFx(ARMOR, playerId, on, Vec3.ZERO, Vec3.ZERO, 0f, 0f, 0, 0);
    }

    public static PacketPainFx heat(int playerId, boolean on) {
        return new PacketPainFx(HEAT, playerId, on, Vec3.ZERO, Vec3.ZERO, 0f, 0f, 0, 0);
    }

    public static PacketPainFx sun(int sunId, Vec3 from, Vec3 to, float diameter, float range, int deploy, int life) {
        return new PacketPainFx(SUN, sunId, true, from, to, diameter, range, deploy, life);
    }

    public static PacketPainFx sunEnd(int sunId) {
        return new PacketPainFx(SUN_END, sunId, false, Vec3.ZERO, Vec3.ZERO, 0f, 0f, 0, 0);
    }

    public PacketPainFx(FriendlyByteBuf b) {
        kind = b.readByte();
        id = b.readVarInt();
        flag = b.readBoolean();
        fx = b.readDouble();
        fy = b.readDouble();
        fz = b.readDouble();
        tx = b.readDouble();
        ty = b.readDouble();
        tz = b.readDouble();
        size = b.readFloat();
        range = b.readFloat();
        deploy = b.readVarInt();
        life = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeByte(kind);
        b.writeVarInt(id);
        b.writeBoolean(flag);
        b.writeDouble(fx);
        b.writeDouble(fy);
        b.writeDouble(fz);
        b.writeDouble(tx);
        b.writeDouble(ty);
        b.writeDouble(tz);
        b.writeFloat(size);
        b.writeFloat(range);
        b.writeVarInt(deploy);
        b.writeVarInt(life);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> PainFx.handle(kind, id, flag, fx, fy, fz, tx, ty, tz, size, range, deploy, life)));
        ctx.get().setPacketHandled(true);
    }
}
