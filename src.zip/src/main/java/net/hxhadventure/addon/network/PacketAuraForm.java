package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.AuraForm;
import net.hxhadventure.addon.client.AuraForms;

/** Server -> every client tracking a player (and the player): which aura form they are in, so the right limbs glow. */
public class PacketAuraForm {
    private final int entityId;
    private final int form;

    public PacketAuraForm(int entityId, AuraForm form) {
        this.entityId = entityId;
        this.form = form.ordinal();
    }

    public PacketAuraForm(FriendlyByteBuf b) {
        entityId = b.readVarInt();
        form = b.readByte();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(entityId);
        b.writeByte(form);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> AuraForms.set(entityId, AuraForm.byId(form))));
        ctx.get().setPacketHandled(true);
    }
}
