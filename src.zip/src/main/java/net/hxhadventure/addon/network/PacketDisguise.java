package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.DisguiseHandler;

/** Server -> client (Convert Hands): render entity `displayed` as entity `as`; on=false removes it. */
public class PacketDisguise {
    private final int displayed, as;
    private final boolean on;
    /** Black Voice: the wearer also takes the creature's hitbox and eye height (the camera sits where its eyes are). */
    private final boolean resize;

    public PacketDisguise(int displayed, int as, boolean on) {
        this(displayed, as, on, false);
    }

    public PacketDisguise(int displayed, int as, boolean on, boolean resize) {
        this.displayed = displayed;
        this.as = as;
        this.on = on;
        this.resize = resize;
    }

    public PacketDisguise(FriendlyByteBuf b) {
        displayed = b.readVarInt();
        as = b.readVarInt();
        on = b.readBoolean();
        resize = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(displayed);
        b.writeVarInt(as);
        b.writeBoolean(on);
        b.writeBoolean(resize);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> DisguiseHandler.set(displayed, as, on, resize)));
        ctx.get().setPacketHandled(true);
    }
}
