package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.JudgmentChain;

/** Client -> server: the bound player accepted the Stake's commands or refused them (refusing is death). */
public class PacketJudgmentAnswer {
    private final boolean accept;

    public PacketJudgmentAnswer(boolean accept) {
        this.accept = accept;
    }

    public PacketJudgmentAnswer(FriendlyByteBuf b) {
        accept = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeBoolean(accept);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) JudgmentChain.answer(sp, accept);
        });
        ctx.get().setPacketHandled(true);
    }
}
