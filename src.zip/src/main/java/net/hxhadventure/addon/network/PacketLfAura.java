package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.LittleFlowerClient;

/** Server -> client: what a Little Flower user's palms look like. flags: bit 0 = H mode on, bit 1 = left palm on someone, bit 2 = right palm on someone. */
public class PacketLfAura {
    private final int entityId, flags;
    private final long touchStart;

    public PacketLfAura(int entityId, int flags, long touchStart) {
        this.entityId = entityId;
        this.flags = flags;
        this.touchStart = touchStart;
    }

    public PacketLfAura(FriendlyByteBuf b) {
        entityId = b.readVarInt();
        flags = b.readByte();
        touchStart = b.readLong();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(entityId);
        b.writeByte(flags);
        b.writeLong(touchStart);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> LittleFlowerClient.setAura(entityId, flags, touchStart)));
        ctx.get().setPacketHandled(true);
    }
}
