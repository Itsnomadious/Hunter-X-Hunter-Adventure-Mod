package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.ChainHand;

/** Server -> every client tracking a player: this player's Hatsu is (or no longer is) the Chains, so draw them on the right hand. */
public class PacketChainHand {
    private final int entityId;
    private final boolean on;

    public PacketChainHand(int entityId, boolean on) {
        this.entityId = entityId;
        this.on = on;
    }

    public PacketChainHand(FriendlyByteBuf b) {
        entityId = b.readVarInt();
        on = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(entityId);
        b.writeBoolean(on);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ChainHand.set(entityId, on)));
        ctx.get().setPacketHandled(true);
    }
}
