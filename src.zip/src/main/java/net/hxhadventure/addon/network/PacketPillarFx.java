package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.PillarFx;

/** Server -> client: a golden pillar of aura fires into the sky from this point for this many ticks (Dragon Head's summon beam). */
public class PacketPillarFx {
    private final double x, y, z;
    private final int ticks;

    public PacketPillarFx(Vec3 at, int ticks) {
        this.x = at.x;
        this.y = at.y;
        this.z = at.z;
        this.ticks = ticks;
    }

    public PacketPillarFx(FriendlyByteBuf b) {
        x = b.readDouble();
        y = b.readDouble();
        z = b.readDouble();
        ticks = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeDouble(x);
        b.writeDouble(y);
        b.writeDouble(z);
        b.writeVarInt(ticks);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> PillarFx.add(x, y, z, ticks)));
        ctx.get().setPacketHandled(true);
    }
}
