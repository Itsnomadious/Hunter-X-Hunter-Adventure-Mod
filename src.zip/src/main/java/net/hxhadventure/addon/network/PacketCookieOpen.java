package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.CookieScreen;

/** Server -> client: the owner right-clicked Cookie. Opens her menu. */
public class PacketCookieOpen {
    private final int cookieId;

    public PacketCookieOpen(int cookieId) {
        this.cookieId = cookieId;
    }

    public PacketCookieOpen(FriendlyByteBuf b) {
        cookieId = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(cookieId);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> net.minecraft.client.Minecraft.getInstance().setScreen(new CookieScreen(cookieId))));
        ctx.get().setPacketHandled(true);
    }
}
