package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.MagicalEsthetician;

/** Client -> server: the player picked a service in Cookie's menu (1 = Magical Spa Services, 2 = Piano Massage). The server checks everything again. */
public class PacketCookieService {
    private final int cookieId;
    private final int service;

    public PacketCookieService(int cookieId, int service) {
        this.cookieId = cookieId;
        this.service = service;
    }

    public PacketCookieService(FriendlyByteBuf b) {
        cookieId = b.readVarInt();
        service = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(cookieId);
        b.writeVarInt(service);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) MagicalEsthetician.startService(sp, cookieId, service);
        });
        ctx.get().setPacketHandled(true);
    }
}
