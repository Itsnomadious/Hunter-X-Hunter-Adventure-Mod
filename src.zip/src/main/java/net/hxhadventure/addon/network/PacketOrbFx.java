package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.OrbFx;

/**
 * Server -> client, Explosive Orbs visuals. kind: 0 CHARGE (id = owner entity id; size = charge already built, ticks = time to full),
 * 1 END (owner's hand orbs vanish), 2 LAUNCH (id = orb id; position, velocity per tick, radius, lifetime),
 * 3 BOOM (orb id; position; size = blast radius), 4 REMOVE (orb id, no explosion).
 */
public class PacketOrbFx {
    public static final byte CHARGE = 0, END = 1, LAUNCH = 2, BOOM = 3, REMOVE = 4;

    private final byte kind;
    private final int id, ticks;
    private final double x, y, z;
    private final float vx, vy, vz, size;

    private PacketOrbFx(byte kind, int id, double x, double y, double z, float vx, float vy, float vz, float size, int ticks) {
        this.kind = kind;
        this.id = id;
        this.x = x;
        this.y = y;
        this.z = z;
        this.vx = vx;
        this.vy = vy;
        this.vz = vz;
        this.size = size;
        this.ticks = ticks;
    }

    public static PacketOrbFx charge(int owner, int ticksToFull, float built) {
        return new PacketOrbFx(CHARGE, owner, 0, 0, 0, 0, 0, 0, built, ticksToFull);
    }

    public static PacketOrbFx end(int owner) {
        return new PacketOrbFx(END, owner, 0, 0, 0, 0, 0, 0, 0, 0);
    }

    public static PacketOrbFx launch(int orb, Vec3 pos, Vec3 vel, float radius, int life) {
        return new PacketOrbFx(LAUNCH, orb, pos.x, pos.y, pos.z, (float) vel.x, (float) vel.y, (float) vel.z, radius, life);
    }

    public static PacketOrbFx boom(int orb, Vec3 pos, float blastRadius) {
        return new PacketOrbFx(BOOM, orb, pos.x, pos.y, pos.z, 0, 0, 0, blastRadius, 0);
    }

    public static PacketOrbFx remove(int orb) {
        return new PacketOrbFx(REMOVE, orb, 0, 0, 0, 0, 0, 0, 0, 0);
    }

    public PacketOrbFx(FriendlyByteBuf b) {
        kind = b.readByte();
        id = b.readVarInt();
        x = b.readDouble();
        y = b.readDouble();
        z = b.readDouble();
        vx = b.readFloat();
        vy = b.readFloat();
        vz = b.readFloat();
        size = b.readFloat();
        ticks = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeByte(kind);
        b.writeVarInt(id);
        b.writeDouble(x);
        b.writeDouble(y);
        b.writeDouble(z);
        b.writeFloat(vx);
        b.writeFloat(vy);
        b.writeFloat(vz);
        b.writeFloat(size);
        b.writeVarInt(ticks);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> OrbFx.handle(kind, id, x, y, z, vx, vy, vz, size, ticks)));
        ctx.get().setPacketHandled(true);
    }
}
