package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.CrazySlotsFx;

/**
 * Server -> clients: an entity is playing a Crazy Slots move.
 * {@code kind}: 1 = WALTZ (Silent Waltz: the blade grows, then the user spins once; {@code ticks} = enlarge + spin),
 * 2 = SLAM (the staff is raised and brought down; {@code ticks} = how long the move takes), 3 = STOP (end any pose).
 * {@code left}: true when the weapon is in the left arm.
 */
public class PacketCrazySlotsFx {
    public static final int WALTZ = 1, SLAM = 2, STOP = 3;

    private final int owner;
    private final int kind;
    private final boolean left;
    private final int ticks;

    public PacketCrazySlotsFx(int owner, int kind, boolean left, int ticks) {
        this.owner = owner;
        this.kind = kind;
        this.left = left;
        this.ticks = ticks;
    }

    public PacketCrazySlotsFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        kind = b.readVarInt();
        left = b.readBoolean();
        ticks = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeVarInt(kind);
        b.writeBoolean(left);
        b.writeVarInt(ticks);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> CrazySlotsFx.add(owner, kind, left, ticks)));
        ctx.get().setPacketHandled(true);
    }
}
