package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.HunterExam;

/**
 * Client -> server: the player finished Satotz's questionnaire. {@code answers} holds the chosen option (0 = A ... 3 = D) of questions 1 to 9;
 * {@code moves} are the moves made in the water puzzle (see WaterPuzzle). The server grades them.
 */
public class PacketExamSubmit {
    private final int npcId;
    private final byte[] answers;
    private final byte[] moves;

    public PacketExamSubmit(int npcId, byte[] answers, byte[] moves) {
        this.npcId = npcId;
        this.answers = answers;
        this.moves = moves;
    }

    public PacketExamSubmit(FriendlyByteBuf b) {
        npcId = b.readVarInt();
        answers = b.readByteArray(32);
        moves = b.readByteArray(512);
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(npcId);
        b.writeByteArray(answers);
        b.writeByteArray(moves);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) HunterExam.submit(sp, npcId, answers, moves);
        });
        ctx.get().setPacketHandled(true);
    }
}
