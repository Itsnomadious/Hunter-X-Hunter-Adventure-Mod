package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.IllumiNeedles;

/** Client -> server: the player right-clicked this entity with Body Alteration selected, so save its look. */
public class PacketNeedleSave {
    private final int entityId;

    public PacketNeedleSave(int entityId) {
        this.entityId = entityId;
    }

    public PacketNeedleSave(FriendlyByteBuf b) {
        entityId = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(entityId);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) IllumiNeedles.saveAppearance(sp, entityId);
        });
        ctx.get().setPacketHandled(true);
    }
}
