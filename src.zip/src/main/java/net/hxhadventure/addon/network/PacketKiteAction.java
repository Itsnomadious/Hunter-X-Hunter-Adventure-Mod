package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.NenAwakening;

/** Client -> server: the player accepted Kite's offer to force their aura nodes open (id = Kite's entity id). */
public class PacketKiteAction {
    private final int kiteId;

    public PacketKiteAction(int kiteId) { this.kiteId = kiteId; }
    public PacketKiteAction(FriendlyByteBuf b) { kiteId = b.readVarInt(); }
    public void toBytes(FriendlyByteBuf b) { b.writeVarInt(kiteId); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) NenAwakening.start(sp, kiteId);
        });
        ctx.get().setPacketHandled(true);
    }
}
