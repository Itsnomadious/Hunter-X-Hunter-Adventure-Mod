package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.EmperorEyes;

/** Server -> every client tracking a player: that player's Emperor Time started or ended (drives the red eyes). */
public class PacketEmperorFx {
    private final int entityId;
    private final boolean on;

    public PacketEmperorFx(int entityId, boolean on) {
        this.entityId = entityId;
        this.on = on;
    }

    public PacketEmperorFx(FriendlyByteBuf b) {
        entityId = b.readVarInt();
        on = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(entityId);
        b.writeBoolean(on);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> EmperorEyes.set(entityId, on)));
        ctx.get().setPacketHandled(true);
    }
}
