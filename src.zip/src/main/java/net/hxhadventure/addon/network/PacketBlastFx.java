package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.BlastFx;

/** Server -> client: an Aura Blast was fired by this entity from this palm position, along this direction, this far. */
public class PacketBlastFx {
    private final int owner;
    private final double ox, oy, oz;
    private final float dx, dy, dz, length, extra;
    private final boolean golden;

    public PacketBlastFx(int owner, Vec3 origin, Vec3 dir, float length) {
        this(owner, origin, dir, length, 0f, false);
    }

    /** {@code extra}: blocks added to the cone's radius everywhere; {@code golden}: drawn in gold (Aspect of Guanyin). */
    public PacketBlastFx(int owner, Vec3 origin, Vec3 dir, float length, float extra, boolean golden) {
        this.extra = extra;
        this.golden = golden;
        this.owner = owner;
        this.ox = origin.x;
        this.oy = origin.y;
        this.oz = origin.z;
        this.dx = (float) dir.x;
        this.dy = (float) dir.y;
        this.dz = (float) dir.z;
        this.length = length;
    }

    public PacketBlastFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        ox = b.readDouble();
        oy = b.readDouble();
        oz = b.readDouble();
        dx = b.readFloat();
        dy = b.readFloat();
        dz = b.readFloat();
        length = b.readFloat();
        extra = b.readFloat();
        golden = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeDouble(ox);
        b.writeDouble(oy);
        b.writeDouble(oz);
        b.writeFloat(dx);
        b.writeFloat(dy);
        b.writeFloat(dz);
        b.writeFloat(length);
        b.writeFloat(extra);
        b.writeBoolean(golden);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> BlastFx.add(owner, ox, oy, oz, dx, dy, dz, length, extra, golden)));
        ctx.get().setPacketHandled(true);
    }
}
