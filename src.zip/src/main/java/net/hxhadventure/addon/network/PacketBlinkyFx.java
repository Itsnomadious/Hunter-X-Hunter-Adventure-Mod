package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.BlinkyFx;

/**
 * Server -> clients: an entity is playing a Blinky arm move.
 * {@code kind}: 1 = SWING (the head sweeps across), 2 = HEAVY (the big overhead sweep), 3 = DRAIN (the head is held out, latched on, for
 * {@code ticks}), 4 = STOP (end the drain pose). {@code left}: true when the head is in the left arm.
 */
public class PacketBlinkyFx {
    public static final int SWING = 1, HEAVY = 2, DRAIN = 3, STOP = 4;

    private final int owner;
    private final int kind;
    private final boolean left;
    private final int ticks;

    public PacketBlinkyFx(int owner, int kind, boolean left, int ticks) {
        this.owner = owner;
        this.kind = kind;
        this.left = left;
        this.ticks = ticks;
    }

    public PacketBlinkyFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        kind = b.readVarInt();
        left = b.readBoolean();
        ticks = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeVarInt(kind);
        b.writeBoolean(left);
        b.writeVarInt(ticks);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> BlinkyFx.add(owner, kind, left, ticks)));
        ctx.get().setPacketHandled(true);
    }
}
