package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.EstheticianClient;

/**
 * Server -> clients tracking a player: either their service pose (none / sitting / lying face down, and the way they face) or whether
 * they are in Body Transformation.
 */
public class PacketEstheticianFx {
    private static final int KIND_POSE = 0, KIND_FORM = 1;

    private final int owner;
    private final int kind;
    private final int value;
    private final float yaw;

    private PacketEstheticianFx(int owner, int kind, int value, float yaw) {
        this.owner = owner;
        this.kind = kind;
        this.value = value;
        this.yaw = yaw;
    }

    public static PacketEstheticianFx pose(int owner, int pose, float yaw) {
        return new PacketEstheticianFx(owner, KIND_POSE, pose, yaw);
    }

    public static PacketEstheticianFx form(int owner, boolean on) {
        return new PacketEstheticianFx(owner, KIND_FORM, on ? 1 : 0, 0f);
    }

    public PacketEstheticianFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        kind = b.readVarInt();
        value = b.readVarInt();
        yaw = b.readFloat();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeVarInt(kind);
        b.writeVarInt(value);
        b.writeFloat(yaw);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            if (kind == KIND_FORM) EstheticianClient.setForm(owner, value == 1);
            else EstheticianClient.setPose(owner, value, yaw);
        }));
        ctx.get().setPacketHandled(true);
    }
}
