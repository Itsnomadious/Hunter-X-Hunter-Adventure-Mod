package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.hxhadventure.addon.client.ClientQuests;
import net.hxhadventure.addon.client.LaptopScreen;
import net.hxhadventure.addon.quest.QuestData;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;

/** Server -> client: the player's quest log. With {@code open} it also opens the laptop at {@code pos}; otherwise it refreshes an open laptop. */
public class PacketQuestSync {
    private final BlockPos pos;
    private final boolean open;
    private final QuestData.Snapshot data;

    public PacketQuestSync(BlockPos pos, boolean open, QuestData.Snapshot data) {
        this.pos = pos;
        this.open = open;
        this.data = data;
    }

    public PacketQuestSync(FriendlyByteBuf b) {
        pos = b.readBlockPos();
        open = b.readBoolean();
        data = QuestData.Snapshot.read(b);
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeBlockPos(pos);
        b.writeBoolean(open);
        data.write(b);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            ClientQuests.set(data.active);
            LaptopScreen.onSync(pos, open, data);
        }));
        ctx.get().setPacketHandled(true);
    }
}
