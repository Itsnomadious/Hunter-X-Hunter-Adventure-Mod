package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.PrayFx;

/** Server -> clients: this player clasps their hands to pray for this many ticks (0 = stop). */
public class PacketPrayFx {
    private final int owner;
    private final int ticks;
    /** 0 = the ordinary clasped-hands prayer, 1 = the 100-Type Guanyin's lotus prayer, 2 = the same lotus, visual only (instant prayer at 10000: first-person hands are left alone). */
    private final int style;

    public PacketPrayFx(int owner, int ticks) {
        this(owner, ticks, 0);
    }

    public PacketPrayFx(int owner, int ticks, int style) {
        this.owner = owner;
        this.ticks = ticks;
        this.style = style;
    }

    public PacketPrayFx(FriendlyByteBuf buf) {
        owner = buf.readVarInt();
        ticks = buf.readVarInt();
        style = buf.readVarInt();
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeVarInt(owner);
        buf.writeVarInt(ticks);
        buf.writeVarInt(style);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> PrayFx.set(owner, ticks, style)));
        ctx.get().setPacketHandled(true);
    }
}
