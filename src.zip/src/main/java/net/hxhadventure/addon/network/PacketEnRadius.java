package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.NenAddonData;

/** Client -> server: the radius chosen with the En slider on the Mastery screen. */
public class PacketEnRadius {
    private final float radius;

    public PacketEnRadius(float radius) { this.radius = radius; }
    public PacketEnRadius(FriendlyByteBuf buf) { this.radius = buf.readFloat(); }
    public void toBytes(FriendlyByteBuf buf) { buf.writeFloat(radius); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;
            Combat c = Combat.get(sp);
            if (c == null || !c.hasNenUnlocked()) return;
            NenAddonData.get(sp).setEnChosen(radius);
        });
        ctx.get().setPacketHandled(true);
    }
}
