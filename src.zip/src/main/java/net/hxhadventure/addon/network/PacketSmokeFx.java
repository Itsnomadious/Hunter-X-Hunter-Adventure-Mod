package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.SmokeFx;

/**
 * Server -> clients: an entity is playing a Smoke Manipulation arm move.
 * {@code kind}: 1 = BLOW (the pipe is lifted to the mouth for Deep Purple), 2 = JAIL (the big breath out for Smoky Jail).
 * {@code left}: true when the arm that holds the pipe is the left one.
 */
public class PacketSmokeFx {
    public static final int BLOW = 1, JAIL = 2;

    private final int owner;
    private final int kind;
    private final boolean left;

    public PacketSmokeFx(int owner, int kind, boolean left) {
        this.owner = owner;
        this.kind = kind;
        this.left = left;
    }

    public PacketSmokeFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        kind = b.readVarInt();
        left = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeVarInt(kind);
        b.writeBoolean(left);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> SmokeFx.add(owner, kind, left)));
        ctx.get().setPacketHandled(true);
    }
}
