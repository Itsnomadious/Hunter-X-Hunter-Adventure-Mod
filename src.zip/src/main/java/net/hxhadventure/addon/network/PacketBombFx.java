package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.LittleFlowerClient;

/** Server -> client: this creature now carries (or no longer carries) a Countdown bomb, drawn on its chest. */
public class PacketBombFx {
    private final int entityId;
    private final boolean on;

    public PacketBombFx(int entityId, boolean on) {
        this.entityId = entityId;
        this.on = on;
    }

    public PacketBombFx(FriendlyByteBuf b) {
        entityId = b.readVarInt();
        on = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(entityId);
        b.writeBoolean(on);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> LittleFlowerClient.setBomb(entityId, on)));
        ctx.get().setPacketHandled(true);
    }
}
