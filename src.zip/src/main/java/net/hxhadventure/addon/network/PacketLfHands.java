package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.LittleFlower;

/** Client -> server: the left and right mouse buttons while Little Flower's mode is on. */
public class PacketLfHands {
    private final boolean left, right;

    public PacketLfHands(boolean left, boolean right) { this.left = left; this.right = right; }
    public PacketLfHands(FriendlyByteBuf b) { left = b.readBoolean(); right = b.readBoolean(); }
    public void toBytes(FriendlyByteBuf b) { b.writeBoolean(left); b.writeBoolean(right); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) LittleFlower.setHands(sp, left, right);
        });
        ctx.get().setPacketHandled(true);
    }
}
