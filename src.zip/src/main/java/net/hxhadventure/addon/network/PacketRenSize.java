package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.NenAddonData;

/** Client -> server: the Ren aura size chosen with the slider on the Mastery screen. */
public class PacketRenSize {
    private final float size;

    public PacketRenSize(float size) { this.size = size; }
    public PacketRenSize(FriendlyByteBuf buf) { this.size = buf.readFloat(); }
    public void toBytes(FriendlyByteBuf buf) { buf.writeFloat(size); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;
            Combat c = Combat.get(sp);
            if (c == null || !c.hasNenUnlocked()) return;
            NenAddonData.get(sp).setRenSize(sp, size);
        });
        ctx.get().setPacketHandled(true);
    }
}
