package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.ClientProfile;

/** Server -> the player: their talent and whether Water Divination has shown them their Nen type. */
public class PacketSyncProfile {
    private final int talent;
    private final boolean revealed;
    private final boolean canSelect;

    public PacketSyncProfile(int talent, boolean revealed, boolean canSelect) {
        this.talent = talent;
        this.revealed = revealed;
        this.canSelect = canSelect;
    }

    public PacketSyncProfile(FriendlyByteBuf b) {
        talent = b.readVarInt();
        revealed = b.readBoolean();
        canSelect = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(talent);
        b.writeBoolean(revealed);
        b.writeBoolean(canSelect);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientProfile.set(talent, revealed, canSelect)));
        ctx.get().setPacketHandled(true);
    }
}
