package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.PuppeteerFx;

/**
 * Server -> clients: a Puppeteer appeared or vanished. {@code anchor} is the entity it is drawn around:
 * mode 1 = a freshly conjured puppeteer waiting beside its user (anchor = the user),
 * mode 2 = a puppeteer controlling a target (anchor = the target), mode 0 = gone.
 */
public class PacketPuppeteerFx {
    private final int anchor;
    private final int mode;

    public PacketPuppeteerFx(int anchor, int mode) {
        this.anchor = anchor;
        this.mode = mode;
    }

    public PacketPuppeteerFx(FriendlyByteBuf b) {
        anchor = b.readVarInt();
        mode = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(anchor);
        b.writeVarInt(mode);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> PuppeteerFx.set(anchor, mode)));
        ctx.get().setPacketHandled(true);
    }
}
