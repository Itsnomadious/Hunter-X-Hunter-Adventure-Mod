package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.LaplaceFx;

/**
 * Server -> one client: this user's Laplace Devil domain is open (or closed), and whether THIS client's player was inside the dome
 * when it opened. Affected clients lose the real user and the Devil and get the double; everybody else (and the user) keeps the real user
 * and the Devil and never sees the double.
 */
public class PacketLaplaceFx {
    private final int ownerId, doubleId, devilId;
    private final boolean active, affected;

    public PacketLaplaceFx(int ownerId, int doubleId, int devilId, boolean active, boolean affected) {
        this.ownerId = ownerId;
        this.doubleId = doubleId;
        this.devilId = devilId;
        this.active = active;
        this.affected = affected;
    }

    public PacketLaplaceFx(FriendlyByteBuf b) {
        ownerId = b.readVarInt();
        doubleId = b.readVarInt();
        devilId = b.readVarInt();
        active = b.readBoolean();
        affected = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(ownerId);
        b.writeVarInt(doubleId);
        b.writeVarInt(devilId);
        b.writeBoolean(active);
        b.writeBoolean(affected);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> LaplaceFx.set(ownerId, doubleId, devilId, active, affected)));
        ctx.get().setPacketHandled(true);
    }
}
