package net.hxhadventure.addon.network;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry.ChannelBuilder;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** Separate channel so the addon needs no edits to ModMessages. */
public final class AddonNetwork {
    private static SimpleChannel channel;
    private static int nextId = 0;

    private AddonNetwork() {}

    public static void register() {
        channel = ChannelBuilder.named(ResourceLocation.fromNamespaceAndPath("hxhadventure", "addon"))
            .networkProtocolVersion(() -> "1.0")
            .clientAcceptedVersions(s -> true)
            .serverAcceptedVersions(s -> true)
            .simpleChannel();
        channel.messageBuilder(PacketAddonAction.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketAddonAction::new).encoder(PacketAddonAction::toBytes)
            .consumerMainThread(PacketAddonAction::handle).add();
        channel.messageBuilder(PacketZHold.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketZHold::new).encoder(PacketZHold::toBytes)
            .consumerMainThread(PacketZHold::handle).add();
        channel.messageBuilder(PacketSyncAddon.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketSyncAddon::new).encoder(PacketSyncAddon::toBytes)
            .consumerMainThread(PacketSyncAddon::handle).add();
        channel.messageBuilder(PacketChainFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketChainFx::new).encoder(PacketChainFx::toBytes)
            .consumerMainThread(PacketChainFx::handle).add();
        channel.messageBuilder(PacketBookFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketBookFx::new).encoder(PacketBookFx::toBytes)
            .consumerMainThread(PacketBookFx::handle).add();
        channel.messageBuilder(PacketDisguise.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketDisguise::new).encoder(PacketDisguise::toBytes)
            .consumerMainThread(PacketDisguise::handle).add();
        channel.messageBuilder(PacketEmperorFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketEmperorFx::new).encoder(PacketEmperorFx::toBytes)
            .consumerMainThread(PacketEmperorFx::handle).add();
        channel.messageBuilder(PacketChainHand.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketChainHand::new).encoder(PacketChainHand::toBytes)
            .consumerMainThread(PacketChainHand::handle).add();
        channel.messageBuilder(PacketChainMark.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketChainMark::new).encoder(PacketChainMark::toBytes)
            .consumerMainThread(PacketChainMark::handle).add();
        channel.messageBuilder(PacketEnPulse.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketEnPulse::new).encoder(PacketEnPulse::toBytes)
            .consumerMainThread(PacketEnPulse::handle).add();
        channel.messageBuilder(PacketOrbFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketOrbFx::new).encoder(PacketOrbFx::toBytes)
            .consumerMainThread(PacketOrbFx::handle).add();
        channel.messageBuilder(PacketBlastFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketBlastFx::new).encoder(PacketBlastFx::toBytes)
            .consumerMainThread(PacketBlastFx::handle).add();
        channel.messageBuilder(PacketPillarFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketPillarFx::new).encoder(PacketPillarFx::toBytes)
            .consumerMainThread(PacketPillarFx::handle).add();
        channel.messageBuilder(PacketCooldown.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketCooldown::new).encoder(PacketCooldown::toBytes)
            .consumerMainThread(PacketCooldown::handle).add();
        channel.messageBuilder(PacketBlytheFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketBlytheFx::new).encoder(PacketBlytheFx::toBytes)
            .consumerMainThread(PacketBlytheFx::handle).add();
        channel.messageBuilder(PacketAuraForm.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketAuraForm::new).encoder(PacketAuraForm::toBytes)
            .consumerMainThread(PacketAuraForm::handle).add();
        channel.messageBuilder(PacketEnRadius.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketEnRadius::new).encoder(PacketEnRadius::toBytes)
            .consumerMainThread(PacketEnRadius::handle).add();
        channel.messageBuilder(PacketRenSize.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketRenSize::new).encoder(PacketRenSize::toBytes)
            .consumerMainThread(PacketRenSize::handle).add();
        channel.messageBuilder(PacketDiveArrowsFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketDiveArrowsFx::new).encoder(PacketDiveArrowsFx::toBytes)
            .consumerMainThread(PacketDiveArrowsFx::handle).add();
        channel.messageBuilder(PacketInFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketInFx::new).encoder(PacketInFx::toBytes)
            .consumerMainThread(PacketInFx::handle).add();
        channel.messageBuilder(PacketGyoInfo.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketGyoInfo::new).encoder(PacketGyoInfo::toBytes)
            .consumerMainThread(PacketGyoInfo::handle).add();
        channel.messageBuilder(PacketInVisibility.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketInVisibility::new).encoder(PacketInVisibility::toBytes)
            .consumerMainThread(PacketInVisibility::handle).add();
        channel.messageBuilder(PacketCardFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketCardFx::new).encoder(PacketCardFx::toBytes)
            .consumerMainThread(PacketCardFx::handle).add();
        channel.messageBuilder(PacketGumFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketGumFx::new).encoder(PacketGumFx::toBytes)
            .consumerMainThread(PacketGumFx::handle).add();
        channel.messageBuilder(PacketTerpsichoraFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketTerpsichoraFx::new).encoder(PacketTerpsichoraFx::toBytes)
            .consumerMainThread(PacketTerpsichoraFx::handle).add();
        channel.messageBuilder(PacketPuppeteerFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketPuppeteerFx::new).encoder(PacketPuppeteerFx::toBytes)
            .consumerMainThread(PacketPuppeteerFx::handle).add();
        channel.messageBuilder(PacketRockFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketRockFx::new).encoder(PacketRockFx::toBytes)
            .consumerMainThread(PacketRockFx::handle).add();
        channel.messageBuilder(PacketVowFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketVowFx::new).encoder(PacketVowFx::toBytes)
            .consumerMainThread(PacketVowFx::handle).add();
        channel.messageBuilder(PacketLfMode.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketLfMode::new).encoder(PacketLfMode::toBytes)
            .consumerMainThread(PacketLfMode::handle).add();
        channel.messageBuilder(PacketLfHands.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketLfHands::new).encoder(PacketLfHands::toBytes)
            .consumerMainThread(PacketLfHands::handle).add();
        channel.messageBuilder(PacketNeedleFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketNeedleFx::new).encoder(PacketNeedleFx::toBytes)
            .consumerMainThread(PacketNeedleFx::handle).add();
        channel.messageBuilder(PacketNeedleDisguise.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketNeedleDisguise::new).encoder(PacketNeedleDisguise::toBytes)
            .consumerMainThread(PacketNeedleDisguise::handle).add();
        channel.messageBuilder(PacketNeedleSave.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketNeedleSave::new).encoder(PacketNeedleSave::toBytes)
            .consumerMainThread(PacketNeedleSave::handle).add();
        channel.messageBuilder(PacketSyncProfile.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketSyncProfile::new).encoder(PacketSyncProfile::toBytes)
            .consumerMainThread(PacketSyncProfile::handle).add();
        channel.messageBuilder(PacketKiteAction.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketKiteAction::new).encoder(PacketKiteAction::toBytes)
            .consumerMainThread(PacketKiteAction::handle).add();
        channel.messageBuilder(PacketSelectNenType.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketSelectNenType::new).encoder(PacketSelectNenType::toBytes)
            .consumerMainThread(PacketSelectNenType::handle).add();
        channel.messageBuilder(PacketSelectHatsu.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketSelectHatsu::new).encoder(PacketSelectHatsu::toBytes)
            .consumerMainThread(PacketSelectHatsu::handle).add();
        channel.messageBuilder(PacketChooseVow.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketChooseVow::new).encoder(PacketChooseVow::toBytes)
            .consumerMainThread(PacketChooseVow::handle).add();
        channel.messageBuilder(PacketPrayFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketPrayFx::new).encoder(PacketPrayFx::toBytes)
            .consumerMainThread(PacketPrayFx::handle).add();
        channel.messageBuilder(PacketGuanyinFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketGuanyinFx::new).encoder(PacketGuanyinFx::toBytes)
            .consumerMainThread(PacketGuanyinFx::handle).add();
        channel.messageBuilder(PacketHinaOpen.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketHinaOpen::new).encoder(PacketHinaOpen::toBytes)
            .consumerMainThread(PacketHinaOpen::handle).add();
        channel.messageBuilder(PacketHinaExorcise.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketHinaExorcise::new).encoder(PacketHinaExorcise::toBytes)
            .consumerMainThread(PacketHinaExorcise::handle).add();
        channel.messageBuilder(PacketJudgmentOpen.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketJudgmentOpen::new).encoder(PacketJudgmentOpen::toBytes)
            .consumerMainThread(PacketJudgmentOpen::handle).add();
        channel.messageBuilder(PacketJudgmentApply.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketJudgmentApply::new).encoder(PacketJudgmentApply::toBytes)
            .consumerMainThread(PacketJudgmentApply::handle).add();
        channel.messageBuilder(PacketJudgmentPrompt.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketJudgmentPrompt::new).encoder(PacketJudgmentPrompt::toBytes)
            .consumerMainThread(PacketJudgmentPrompt::handle).add();
        channel.messageBuilder(PacketJudgmentAnswer.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketJudgmentAnswer::new).encoder(PacketJudgmentAnswer::toBytes)
            .consumerMainThread(PacketJudgmentAnswer::handle).add();
        channel.messageBuilder(PacketSyncVows.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketSyncVows::new).encoder(PacketSyncVows::toBytes)
            .consumerMainThread(PacketSyncVows::handle).add();
        channel.messageBuilder(PacketSmokeFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketSmokeFx::new).encoder(PacketSmokeFx::toBytes)
            .consumerMainThread(PacketSmokeFx::handle).add();
        channel.messageBuilder(PacketPaperFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketPaperFx::new).encoder(PacketPaperFx::toBytes)
            .consumerMainThread(PacketPaperFx::handle).add();
        channel.messageBuilder(PacketPainFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketPainFx::new).encoder(PacketPainFx::toBytes)
            .consumerMainThread(PacketPainFx::handle).add();
        channel.messageBuilder(PacketCookieOpen.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketCookieOpen::new).encoder(PacketCookieOpen::toBytes)
            .consumerMainThread(PacketCookieOpen::handle).add();
        channel.messageBuilder(PacketCookieService.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketCookieService::new).encoder(PacketCookieService::toBytes)
            .consumerMainThread(PacketCookieService::handle).add();
        channel.messageBuilder(PacketEstheticianFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketEstheticianFx::new).encoder(PacketEstheticianFx::toBytes)
            .consumerMainThread(PacketEstheticianFx::handle).add();
        channel.messageBuilder(PacketCyclotronFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketCyclotronFx::new).encoder(PacketCyclotronFx::toBytes)
            .consumerMainThread(PacketCyclotronFx::handle).add();
        channel.messageBuilder(PacketBlinkyFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketBlinkyFx::new).encoder(PacketBlinkyFx::toBytes)
            .consumerMainThread(PacketBlinkyFx::handle).add();
        channel.messageBuilder(PacketLaplaceFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketLaplaceFx::new).encoder(PacketLaplaceFx::toBytes)
            .consumerMainThread(PacketLaplaceFx::handle).add();
        channel.messageBuilder(PacketStitchFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketStitchFx::new).encoder(PacketStitchFx::toBytes)
            .consumerMainThread(PacketStitchFx::handle).add();
        channel.messageBuilder(PacketCrazySlotsFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketCrazySlotsFx::new).encoder(PacketCrazySlotsFx::toBytes)
            .consumerMainThread(PacketCrazySlotsFx::handle).add();
        channel.messageBuilder(PacketBvAuto.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketBvAuto::new).encoder(PacketBvAuto::toBytes)
            .consumerMainThread(PacketBvAuto::handle).add();
        channel.messageBuilder(PacketBombFx.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketBombFx::new).encoder(PacketBombFx::toBytes)
            .consumerMainThread(PacketBombFx::handle).add();
        channel.messageBuilder(PacketLfAura.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketLfAura::new).encoder(PacketLfAura::toBytes)
            .consumerMainThread(PacketLfAura::handle).add();
        channel.messageBuilder(PacketLfWarn.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketLfWarn::new).encoder(PacketLfWarn::toBytes)
            .consumerMainThread(PacketLfWarn::handle).add();
        channel.messageBuilder(PacketLfGuard.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketLfGuard::new).encoder(PacketLfGuard::toBytes)
            .consumerMainThread(PacketLfGuard::handle).add();
        channel.messageBuilder(PacketExamOpen.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketExamOpen::new).encoder(PacketExamOpen::toBytes)
            .consumerMainThread(PacketExamOpen::handle).add();
        channel.messageBuilder(PacketExamSubmit.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketExamSubmit::new).encoder(PacketExamSubmit::toBytes)
            .consumerMainThread(PacketExamSubmit::handle).add();
        channel.messageBuilder(PacketExamResult.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketExamResult::new).encoder(PacketExamResult::toBytes)
            .consumerMainThread(PacketExamResult::handle).add();
        channel.messageBuilder(PacketExamStartBattle.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketExamStartBattle::new).encoder(PacketExamStartBattle::toBytes)
            .consumerMainThread(PacketExamStartBattle::handle).add();
        channel.messageBuilder(PacketExamStage.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketExamStage::new).encoder(PacketExamStage::toBytes)
            .consumerMainThread(PacketExamStage::handle).add();
        channel.messageBuilder(PacketQuestSync.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketQuestSync::new).encoder(PacketQuestSync::toBytes)
            .consumerMainThread(PacketQuestSync::handle).add();
        channel.messageBuilder(PacketQuestLog.class, nextId++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketQuestLog::new).encoder(PacketQuestLog::toBytes)
            .consumerMainThread(PacketQuestLog::handle).add();
        channel.messageBuilder(PacketQuestAction.class, nextId++, NetworkDirection.PLAY_TO_SERVER)
            .decoder(PacketQuestAction::new).encoder(PacketQuestAction::toBytes)
            .consumerMainThread(PacketQuestAction::handle).add();
    }

    public static <M> void sendToServer(M msg) {
        channel.sendToServer(msg);
    }

    public static <M> void sendToTrackingAndSelf(M msg, net.minecraft.world.entity.Entity e) {
        channel.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> e), msg);
    }

    public static <M> void sendToTracking(M msg, net.minecraft.world.entity.Entity e) {
        channel.send(PacketDistributor.TRACKING_ENTITY.with(() -> e), msg);
    }

    /** To every player within radius blocks of a point in a level. */
    public static <M> void sendToNear(M msg, net.minecraft.server.level.ServerLevel level, net.minecraft.world.phys.Vec3 pos, double radius) {
        channel.send(PacketDistributor.NEAR.with(() ->
            new PacketDistributor.TargetPoint(pos.x, pos.y, pos.z, radius, level.dimension())), msg);
    }

    public static <M> void sendToPlayer(M msg, ServerPlayer player) {
        channel.send(PacketDistributor.PLAYER.with(() -> player), msg);
    }
}
