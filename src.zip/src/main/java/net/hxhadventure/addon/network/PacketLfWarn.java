package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.LittleFlowerClient;

/** Server -> client: a Little Flower palm is on you. need: 0 = over, 1 = press left click, 2 = right click, 3 = both, to brace (take a fifth). */
public class PacketLfWarn {
    private final int need;

    public PacketLfWarn(int need) { this.need = need; }
    public PacketLfWarn(FriendlyByteBuf b) { need = b.readByte(); }
    public void toBytes(FriendlyByteBuf b) { b.writeByte(need); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> LittleFlowerClient.setGuardNeed(need)));
        ctx.get().setPacketHandled(true);
    }
}
