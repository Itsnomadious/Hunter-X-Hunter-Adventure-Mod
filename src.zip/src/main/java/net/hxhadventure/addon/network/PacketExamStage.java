package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.ClientAddonState;

/** Server -> client: the player's Hunter Exam stage (0 to 3, see HunterExam#stage). From stage 3 the O menu is the Hunter License. */
public class PacketExamStage {
    private final int stage;

    public PacketExamStage(int stage) {
        this.stage = stage;
    }

    public PacketExamStage(FriendlyByteBuf b) {
        stage = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(stage);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> ClientAddonState.examStage = stage);
        ctx.get().setPacketHandled(true);
    }
}
