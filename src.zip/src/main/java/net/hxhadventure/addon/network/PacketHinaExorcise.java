package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.Exorcism;

/** Client -> server: the player told Hina "yes, remove my Nen restrictions" (the server checks everything again). */
public class PacketHinaExorcise {
    private final int hinaId;
    /** true = lift the Stake of Retribution instead of the Nen restrictions. */
    private final boolean stake;

    public PacketHinaExorcise(int hinaId, boolean stake) {
        this.hinaId = hinaId;
        this.stake = stake;
    }

    public PacketHinaExorcise(FriendlyByteBuf b) {
        hinaId = b.readVarInt();
        stake = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(hinaId);
        b.writeBoolean(stake);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) Exorcism.start(sp, hinaId, stake);
        });
        ctx.get().setPacketHandled(true);
    }
}
