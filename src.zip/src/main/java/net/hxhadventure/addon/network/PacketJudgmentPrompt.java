package net.hxhadventure.addon.network;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.JudgmentAcceptScreen;

/** Server -> the bound player: someone's Stake of Retribution is in their heart; here are the commands, accept or die. */
public class PacketJudgmentPrompt {
    private final String caster;
    private final List<String> ids;
    private final int ticks;

    public PacketJudgmentPrompt(String caster, List<String> ids, int ticks) {
        this.caster = caster;
        this.ids = ids;
        this.ticks = ticks;
    }

    public PacketJudgmentPrompt(FriendlyByteBuf b) {
        caster = b.readUtf(64);
        int n = Math.min(8, b.readVarInt());
        ids = new ArrayList<>(n);
        for (int i = 0; i < n; i++) ids.add(b.readUtf(64));
        ticks = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeUtf(caster, 64);
        b.writeVarInt(ids.size());
        for (String id : ids) b.writeUtf(id, 64);
        b.writeVarInt(ticks);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> net.minecraft.client.Minecraft.getInstance().setScreen(new JudgmentAcceptScreen(caster, ids, ticks))));
        ctx.get().setPacketHandled(true);
    }
}
