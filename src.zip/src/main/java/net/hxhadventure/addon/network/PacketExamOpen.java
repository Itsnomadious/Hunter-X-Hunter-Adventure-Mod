package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.ExamScreen;

/** Server -> client: the player right-clicked a Hunter Exam NPC. Opens its dialogue (kind = HunterExam.KIND_*) and says whether the first and second tests are already passed and whether Menchi's test is running. */
public class PacketExamOpen {
    private final int npcId;
    private final int kind;
    private final boolean passed;
    private final boolean secondPassed;
    private final boolean battleActive;
    private final boolean awakened;
    private final boolean hasKite;
    private final int kiteX, kiteY, kiteZ;

    public PacketExamOpen(int npcId, int kind, boolean passed, boolean secondPassed, boolean battleActive,
                          boolean awakened, boolean hasKite, int kiteX, int kiteY, int kiteZ) {
        this.npcId = npcId;
        this.kind = kind;
        this.passed = passed;
        this.secondPassed = secondPassed;
        this.battleActive = battleActive;
        this.awakened = awakened;
        this.hasKite = hasKite;
        this.kiteX = kiteX;
        this.kiteY = kiteY;
        this.kiteZ = kiteZ;
    }

    public PacketExamOpen(FriendlyByteBuf b) {
        npcId = b.readVarInt();
        kind = b.readVarInt();
        passed = b.readBoolean();
        secondPassed = b.readBoolean();
        battleActive = b.readBoolean();
        awakened = b.readBoolean();
        hasKite = b.readBoolean();
        kiteX = b.readInt();
        kiteY = b.readInt();
        kiteZ = b.readInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(npcId);
        b.writeVarInt(kind);
        b.writeBoolean(passed);
        b.writeBoolean(secondPassed);
        b.writeBoolean(battleActive);
        b.writeBoolean(awakened);
        b.writeBoolean(hasKite);
        b.writeInt(kiteX);
        b.writeInt(kiteY);
        b.writeInt(kiteZ);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> net.minecraft.client.Minecraft.getInstance().setScreen(new ExamScreen(npcId, kind, passed, secondPassed, battleActive, awakened, hasKite, kiteX, kiteY, kiteZ))));
        ctx.get().setPacketHandled(true);
    }
}
