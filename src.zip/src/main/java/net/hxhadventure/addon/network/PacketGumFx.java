package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.GumFx;

/**
 * Server -> client, Bungee Gum visuals (the client draws the elastic thread and the aura itself, so no per-tick particle traffic).
 * kind: 0 THREAD (id = caster entity id; target = entity id the thread ends on, or -1 to end at the point x, y, z),
 * 1 THREAD_OFF (id = caster), 2 TETHER (id = debuffed entity id; target = caster entity id; x = debuff stage 0..3),
 * 3 TETHER_OFF (id = debuffed entity id), 4 BIND (id = bound entity id; x = ticks left of Bungee Bind), 5 BIND_OFF (id = bound entity id).
 */
public class PacketGumFx {
    public static final byte THREAD = 0, THREAD_OFF = 1, TETHER = 2, TETHER_OFF = 3, BIND = 4, BIND_OFF = 5;

    private final byte kind;
    private final int id, target;
    private final double x, y, z;

    private PacketGumFx(byte kind, int id, int target, double x, double y, double z) {
        this.kind = kind;
        this.id = id;
        this.target = target;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    /** Thread from the caster to an entity (targetEntity &gt;= 0) or to a fixed point (targetEntity &lt; 0). */
    public static PacketGumFx thread(int caster, int targetEntity, Vec3 point) {
        Vec3 p = point == null ? Vec3.ZERO : point;
        return new PacketGumFx(THREAD, caster, targetEntity, p.x, p.y, p.z);
    }

    public static PacketGumFx threadOff(int caster) {
        return new PacketGumFx(THREAD_OFF, caster, -1, 0, 0, 0);
    }

    public static PacketGumFx tether(int victim, int caster, int stage) {
        return new PacketGumFx(TETHER, victim, caster, stage, 0, 0);
    }

    public static PacketGumFx tetherOff(int victim) {
        return new PacketGumFx(TETHER_OFF, victim, -1, 0, 0, 0);
    }

    public static PacketGumFx bind(int victim, int ticksLeft) {
        return new PacketGumFx(BIND, victim, -1, ticksLeft, 0, 0);
    }

    public static PacketGumFx bindOff(int victim) {
        return new PacketGumFx(BIND_OFF, victim, -1, 0, 0, 0);
    }

    public PacketGumFx(FriendlyByteBuf b) {
        kind = b.readByte();
        id = b.readVarInt();
        target = b.readInt();
        x = b.readDouble();
        y = b.readDouble();
        z = b.readDouble();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeByte(kind);
        b.writeVarInt(id);
        b.writeInt(target);
        b.writeDouble(x);
        b.writeDouble(y);
        b.writeDouble(z);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> GumFx.handle(kind, id, target, x, y, z)));
        ctx.get().setPacketHandled(true);
    }
}
