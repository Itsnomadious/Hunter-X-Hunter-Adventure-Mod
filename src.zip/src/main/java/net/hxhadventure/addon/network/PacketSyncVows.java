package net.hxhadventure.addon.network;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.ClientVows;

/** Server -> the player: every rule they have sworn (the Vows menu reads this). */
public class PacketSyncVows {
    private final List<String> ids;

    public PacketSyncVows(List<String> ids) { this.ids = ids; }

    public PacketSyncVows(FriendlyByteBuf buf) {
        int n = buf.readVarInt();
        ids = new ArrayList<>(n);
        for (int i = 0; i < n; i++) ids.add(buf.readUtf(64));
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeVarInt(ids.size());
        for (String id : ids) buf.writeUtf(id, 64);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> ClientVows.set(ids));
        ctx.get().setPacketHandled(true);
    }
}
