package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.CardFx;

/**
 * Server -> clients tracking a Bungee Gum user: every card currently in flight (id, position, velocity), each tick.
 * Cards missing from the latest packet are gone; an empty packet clears them all.
 */
public class PacketCardFx {
    private final int owner;
    private final int[] ids;
    private final float[] data; // 6 per card: x y z, vx vy vz

    public PacketCardFx(int owner, int[] ids, float[] data) {
        this.owner = owner;
        this.ids = ids;
        this.data = data;
    }

    public PacketCardFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        int n = b.readVarInt();
        ids = new int[n];
        data = new float[n * 6];
        for (int i = 0; i < n; i++) {
            ids[i] = b.readVarInt();
            for (int k = 0; k < 6; k++) data[i * 6 + k] = b.readFloat();
        }
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeVarInt(ids.length);
        for (int i = 0; i < ids.length; i++) {
            b.writeVarInt(ids[i]);
            for (int k = 0; k < 6; k++) b.writeFloat(data[i * 6 + k]);
        }
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> CardFx.handle(owner, ids, data)));
        ctx.get().setPacketHandled(true);
    }
}
