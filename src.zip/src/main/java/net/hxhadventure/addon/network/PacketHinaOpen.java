package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.HinaScreen;

/** Server -> client: the player right-clicked Hina. Opens her menu, with how many ticks of rest she still needs and whether a Stake of Retribution stands in their heart. */
public class PacketHinaOpen {
    private final int hinaId;
    private final int cooldown;
    private final boolean hasStake;

    public PacketHinaOpen(int hinaId, int cooldown, boolean hasStake) {
        this.hinaId = hinaId;
        this.cooldown = cooldown;
        this.hasStake = hasStake;
    }

    public PacketHinaOpen(FriendlyByteBuf b) {
        hinaId = b.readVarInt();
        cooldown = b.readVarInt();
        hasStake = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(hinaId);
        b.writeVarInt(cooldown);
        b.writeBoolean(hasStake);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> net.minecraft.client.Minecraft.getInstance().setScreen(new HinaScreen(hinaId, cooldown, hasStake))));
        ctx.get().setPacketHandled(true);
    }
}
