package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.BookRenderer;

/** Server -> client: book state of an entity (0 none, 1 closed, 2 open), current page, bookmarked page, and animation flags (1 = page turn, 2 = bookmark placed). */
public class PacketBookFx {
    private final int entityId;
    private final byte state;
    private final byte page;
    private final byte mark;
    private final byte flags;

    public PacketBookFx(int entityId, int state, int page, int mark, int flags) {
        this.entityId = entityId;
        this.state = (byte) state;
        this.page = (byte) page;
        this.mark = (byte) mark;
        this.flags = (byte) flags;
    }

    public PacketBookFx(FriendlyByteBuf b) {
        entityId = b.readVarInt();
        state = b.readByte();
        page = b.readByte();
        mark = b.readByte();
        flags = b.readByte();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(entityId);
        b.writeByte(state);
        b.writeByte(page);
        b.writeByte(mark);
        b.writeByte(flags);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> BookRenderer.set(entityId, state, page, mark, flags)));
        ctx.get().setPacketHandled(true);
    }
}
