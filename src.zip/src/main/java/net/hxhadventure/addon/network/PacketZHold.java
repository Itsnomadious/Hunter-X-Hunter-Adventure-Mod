package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.SkillHunter;

/** Client -> server: the Z (use ability) key was pressed or released. Lets Sun and Moon charge only while held. */
public class PacketZHold {
    private final boolean held;

    public PacketZHold(boolean held) { this.held = held; }
    public PacketZHold(FriendlyByteBuf buf) { this.held = buf.readBoolean(); }
    public void toBytes(FriendlyByteBuf buf) { buf.writeBoolean(held); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) {
                SkillHunter.setZHeld(sp, held);
                net.hxhadventure.addon.ExplosiveOrbs.setZHeld(sp, held);
                net.hxhadventure.addon.DragonHead.setZHeld(sp, held);
                net.hxhadventure.addon.Jajanken.setZHeld(sp, held);
                net.hxhadventure.addon.RipperCyclotron.setZHeld(sp, held);
                net.hxhadventure.addon.BigBangImpact.setZHeld(sp, held);
                net.hxhadventure.addon.NenStitches.setZHeld(sp, held);
                net.hxhadventure.addon.BlackVoice.setZHeld(sp, held);
                net.hxhadventure.addon.ChainManager.setZHeld(sp, held);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
