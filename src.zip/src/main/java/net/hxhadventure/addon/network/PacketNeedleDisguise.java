package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.NeedleAppearance;
import net.hxhadventure.addon.client.NeedleDisguise;

/** Server -> clients: draw this entity with a saved look (Body Alteration). A null look takes the disguise off. */
public class PacketNeedleDisguise {
    private final int entityId;
    private final NeedleAppearance look;

    public PacketNeedleDisguise(int entityId, NeedleAppearance look) {
        this.entityId = entityId;
        this.look = look;
    }

    public PacketNeedleDisguise(FriendlyByteBuf b) {
        entityId = b.readVarInt();
        look = b.readBoolean() ? NeedleAppearance.read(b) : null;
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(entityId);
        b.writeBoolean(look != null);
        if (look != null) look.write(b);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> NeedleDisguise.set(entityId, look)));
        ctx.get().setPacketHandled(true);
    }
}
