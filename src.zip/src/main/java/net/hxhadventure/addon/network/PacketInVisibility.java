package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.NenAddonData;

/** Client -> server: the Mastery screen's "show / hide my Nen" slider (only honoured at Genius In or above). */
public class PacketInVisibility {
    private final boolean visible;

    public PacketInVisibility(boolean visible) { this.visible = visible; }
    public PacketInVisibility(FriendlyByteBuf buf) { this.visible = buf.readBoolean(); }
    public void toBytes(FriendlyByteBuf buf) { buf.writeBoolean(visible); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) NenAddonData.get(sp).setInVisible(visible);
        });
        ctx.get().setPacketHandled(true);
    }
}
