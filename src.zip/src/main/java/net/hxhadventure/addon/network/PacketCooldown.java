package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.ClientCooldowns;

/**
 * Server -> client: an ability cooldown started (ticks &gt; 0), was cleared (ticks == 0), or every cooldown
 * should be forgotten (ticks &lt; 0, used on death / login). Drives the cooldown list in the bottom right.
 */
public class PacketCooldown {
    private final String name;
    private final int ticks;

    public PacketCooldown(String name, int ticks) {
        this.name = name;
        this.ticks = ticks;
    }

    public static PacketCooldown clearAll() {
        return new PacketCooldown("", -1);
    }

    public PacketCooldown(FriendlyByteBuf b) {
        name = b.readUtf(64);
        ticks = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeUtf(name, 64);
        b.writeVarInt(ticks);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            if (ticks < 0) ClientCooldowns.clear();
            else ClientCooldowns.set(name, ticks);
        }));
        ctx.get().setPacketHandled(true);
    }
}
