package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.InFx;

/** Server -> every client tracking a player: this player's Nen constructs (Chains, Bungee Gum) are now hidden by In, or visible again. */
public class PacketInFx {
    private final int entityId;
    private final boolean hidden;

    public PacketInFx(int entityId, boolean hidden) {
        this.entityId = entityId;
        this.hidden = hidden;
    }

    public PacketInFx(FriendlyByteBuf b) {
        entityId = b.readVarInt();
        hidden = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(entityId);
        b.writeBoolean(hidden);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> InFx.set(entityId, hidden)));
        ctx.get().setPacketHandled(true);
    }
}
