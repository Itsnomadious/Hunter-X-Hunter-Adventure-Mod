package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.NenGameRules;
import net.hxhadventure.addon.NenProfile;

/**
 * Client -> server: the Nen type picked in Water Divination. Only valid while the game rule hxhnentypeselect is on, the player's
 * nodes are open and their type has not been revealed yet (so it is a one-time choice, exactly like the normal reveal).
 */
public class PacketSelectNenType {
    private final int type;

    public PacketSelectNenType(int type) { this.type = type; }
    public PacketSelectNenType(FriendlyByteBuf b) { type = b.readVarInt(); }
    public void toBytes(FriendlyByteBuf b) { b.writeVarInt(type); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) select(sp, type);
        });
        ctx.get().setPacketHandled(true);
    }

    private static void select(ServerPlayer sp, int type) {
        Combat c = Combat.get(sp);
        if (c == null || !c.hasNenUnlocked()) {
            sp.sendSystemMessage(Component.literal("\u00a7cYour nodes are not open yet. Find Kite."));
            return;
        }
        if (sp.getServer() == null || !sp.getServer().getGameRules().getBoolean(NenGameRules.NEN_TYPE_SELECT)) {
            sp.sendSystemMessage(Component.literal("\u00a7cChoosing your Nen type is turned off."));
            NenProfile.sync(sp);
            return;
        }
        if (NenProfile.typeRevealed(sp)) return;
        if (type < Combat.NEN_ENHANCEMENT || type > Combat.NEN_SPECIALIZATION) return;
        if (NenProfile.peekTalent(sp) == null) NenProfile.rollAwakening(sp); // Nen from before talents existed: fill in what is missing
        c.setNenType(type);
        NenProfile.setTypeRevealed(sp, true);
        NenProfile.sync(sp);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.0F);
    }
}
