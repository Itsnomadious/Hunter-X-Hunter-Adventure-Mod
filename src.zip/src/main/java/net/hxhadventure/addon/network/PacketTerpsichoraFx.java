package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.TerpsichoraFx;

/**
 * Server -> clients tracking a player: the state of that player's Terpsichora.
 * 0 = gone, 1 = the buffs are on (the figure has gone), 2 = post-mortem (the corpse is still being worked),
 * 3 = the buffs are on and the figure is out right now (its first second).
 */
public class PacketTerpsichoraFx {
    private final int owner;
    private final int mode;

    public PacketTerpsichoraFx(int owner, int mode) {
        this.owner = owner;
        this.mode = mode;
    }

    public PacketTerpsichoraFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        mode = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeVarInt(mode);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> TerpsichoraFx.set(owner, mode)));
        ctx.get().setPacketHandled(true);
    }
}
