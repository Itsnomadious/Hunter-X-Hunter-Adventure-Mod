package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.ExamScreen;

/** Server -> client: the verdict on the questionnaire. Only pass or fail is sent, never which answers were right. */
public class PacketExamResult {
    private final boolean passed;

    public PacketExamResult(boolean passed) {
        this.passed = passed;
    }

    public PacketExamResult(FriendlyByteBuf b) {
        passed = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeBoolean(passed);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> ExamScreen.onResult(passed)));
        ctx.get().setPacketHandled(true);
    }
}
