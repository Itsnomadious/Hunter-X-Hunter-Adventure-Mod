package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.ChainMarks;

/** Server -> clients tracking the victim (and the owner): an invisible Dowsing Chain mark was put on / taken off this entity. */
public class PacketChainMark {
    private final int victim, owner;
    private final boolean on;

    public PacketChainMark(int victim, int owner, boolean on) {
        this.victim = victim;
        this.owner = owner;
        this.on = on;
    }

    public PacketChainMark(FriendlyByteBuf b) {
        victim = b.readVarInt();
        owner = b.readVarInt();
        on = b.readBoolean();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(victim);
        b.writeVarInt(owner);
        b.writeBoolean(on);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ChainMarks.set(victim, owner, on)));
        ctx.get().setPacketHandled(true);
    }
}
