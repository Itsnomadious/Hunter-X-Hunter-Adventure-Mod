package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.GonVowClient;

/** Server -> clients tracking a player: that player entered or left Gon's adult form (the "I'll use everything." vow). */
public class PacketVowFx {
    private final int owner;
    private final boolean on;

    public PacketVowFx(int owner, boolean on) {
        this.owner = owner;
        this.on = on;
    }

    public PacketVowFx(FriendlyByteBuf buf) {
        owner = buf.readVarInt();
        on = buf.readBoolean();
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeVarInt(owner);
        buf.writeBoolean(on);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> GonVowClient.set(owner, on)));
        ctx.get().setPacketHandled(true);
    }
}
