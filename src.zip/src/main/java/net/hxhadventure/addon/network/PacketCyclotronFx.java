package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.CyclotronFx;

/**
 * Server -> clients tracking a player: the state of that player's Ripper Cyclotron.
 * mode 0 = gone, 1 = spinning (a = how many ticks ago the spin started), 2 = the punch was thrown ((x, y, z) is where it landed,
 * a = the aura's width in blocks when it was thrown).
 */
public class PacketCyclotronFx {
    private final int owner, mode;
    private final double x, y, z, a;

    private PacketCyclotronFx(int owner, int mode, double x, double y, double z, double a) {
        this.owner = owner;
        this.mode = mode;
        this.x = x;
        this.y = y;
        this.z = z;
        this.a = a;
    }

    public static PacketCyclotronFx gone(int owner) { return new PacketCyclotronFx(owner, 0, 0, 0, 0, 0); }

    public static PacketCyclotronFx spin(int owner, long age) { return new PacketCyclotronFx(owner, 1, 0, 0, 0, age); }

    public static PacketCyclotronFx punch(int owner, Vec3 at, double diameter) { return new PacketCyclotronFx(owner, 2, at.x, at.y, at.z, diameter); }

    public PacketCyclotronFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        mode = b.readByte();
        x = b.readDouble();
        y = b.readDouble();
        z = b.readDouble();
        a = b.readDouble();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeByte(mode);
        b.writeDouble(x);
        b.writeDouble(y);
        b.writeDouble(z);
        b.writeDouble(a);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> CyclotronFx.set(owner, mode, x, y, z, a)));
        ctx.get().setPacketHandled(true);
    }
}
