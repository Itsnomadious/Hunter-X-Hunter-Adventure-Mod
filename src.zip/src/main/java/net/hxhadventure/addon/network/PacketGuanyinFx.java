package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.GuanyinFx;

/**
 * Server -> clients: something about the 100-Type Guanyin Bodhisattva of this player. {@code type} is one of the constants below;
 * {@code pos} / {@code dir} / {@code extra} mean what the client's {@link GuanyinFx} says for that type.
 */
public class PacketGuanyinFx {
    public static final int OFF = 0, ON = 1, PALM = 2, FIRST = 3, THIRD = 4, NINETY = 5, ZERO = 6, FLASH = 7,
        /** To the user only: whether they are enlightened (the client hides the Z menu skill that manifests the statue). */
        AWAKE = 8, ASLEEP = 9;

    private final int owner;
    private final int type;
    private final double x, y, z;
    private final float dx, dy, dz;
    private final int extra;

    public PacketGuanyinFx(int owner, int type, Vec3 pos, Vec3 dir, int extra) {
        this.owner = owner;
        this.type = type;
        this.x = pos.x;
        this.y = pos.y;
        this.z = pos.z;
        this.dx = (float) dir.x;
        this.dy = (float) dir.y;
        this.dz = (float) dir.z;
        this.extra = extra;
    }

    public PacketGuanyinFx(int owner, int type) {
        this(owner, type, Vec3.ZERO, Vec3.ZERO, 0);
    }

    public PacketGuanyinFx(FriendlyByteBuf b) {
        owner = b.readVarInt();
        type = b.readVarInt();
        x = b.readDouble();
        y = b.readDouble();
        z = b.readDouble();
        dx = b.readFloat();
        dy = b.readFloat();
        dz = b.readFloat();
        extra = b.readVarInt();
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(owner);
        b.writeVarInt(type);
        b.writeDouble(x);
        b.writeDouble(y);
        b.writeDouble(z);
        b.writeFloat(dx);
        b.writeFloat(dy);
        b.writeFloat(dz);
        b.writeVarInt(extra);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
            () -> () -> GuanyinFx.receive(owner, type, x, y, z, dx, dy, dz, extra)));
        ctx.get().setPacketHandled(true);
    }
}
