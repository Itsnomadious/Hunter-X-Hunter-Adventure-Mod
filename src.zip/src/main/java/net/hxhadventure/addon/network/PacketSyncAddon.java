package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.ClientAddonState;
import net.hxhadventure.addon.NenAddonData;
import net.hxhadventure.addon.NenSkill;

/** Server -> client state mirror (HUD, skills screen). */
public class PacketSyncAddon {
    private final boolean zetsu;
    private final boolean en;
    private final boolean emperor;
    private final float lifespan;
    private final byte bookState, bookmark, activePage, stolenKit;
    private final int stolenMask;
    private final boolean hunter, bookHeld;
    private final float enRadius;
    private final float enChosen;
    private final float renSize;
    private final boolean ken, ko;
    private final boolean in, gyo, inVisible, shu;
    private final int[] level = new int[NenSkill.values().length];
    private final float[] progress = new float[NenSkill.values().length];

    public PacketSyncAddon(NenAddonData d) {
        zetsu = d.zetsu;
        en = d.en;
        emperor = d.emperor;
        lifespan = d.lifespan;
        bookState = (byte) d.bookState;
        bookmark = (byte) d.bookmark;
        activePage = (byte) d.activePage;
        stolenKit = (byte) d.stolenKit;
        stolenMask = d.stolenMask;
        hunter = d.hostKit;
        bookHeld = d.bookHeld;
        enRadius = d.enRadius;
        enChosen = d.enChosen;
        renSize = d.renSize;
        ken = d.ken;
        ko = d.ko;
        in = d.in;
        gyo = d.gyo;
        inVisible = d.inVisible;
        shu = d.shu;
        for (NenSkill s : NenSkill.values()) {
            level[s.ordinal()] = d.level(s);
            progress[s.ordinal()] = d.progress(s);
        }
    }

    public PacketSyncAddon(FriendlyByteBuf buf) {
        zetsu = buf.readBoolean();
        en = buf.readBoolean();
        emperor = buf.readBoolean();
        lifespan = buf.readFloat();
        bookState = buf.readByte();
        bookmark = buf.readByte();
        activePage = buf.readByte();
        stolenKit = buf.readByte();
        stolenMask = buf.readInt();
        hunter = buf.readBoolean();
        bookHeld = buf.readBoolean();
        enRadius = buf.readFloat();
        enChosen = buf.readFloat();
        renSize = buf.readFloat();
        ken = buf.readBoolean();
        ko = buf.readBoolean();
        in = buf.readBoolean();
        gyo = buf.readBoolean();
        inVisible = buf.readBoolean();
        shu = buf.readBoolean();
        for (int i = 0; i < level.length; i++) {
            level[i] = buf.readShort();
            progress[i] = buf.readFloat();
        }
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeBoolean(zetsu);
        buf.writeBoolean(en);
        buf.writeBoolean(emperor);
        buf.writeFloat(lifespan);
        buf.writeByte(bookState);
        buf.writeByte(bookmark);
        buf.writeByte(activePage);
        buf.writeByte(stolenKit);
        buf.writeInt(stolenMask);
        buf.writeBoolean(hunter);
        buf.writeBoolean(bookHeld);
        buf.writeFloat(enRadius);
        buf.writeFloat(enChosen);
        buf.writeFloat(renSize);
        buf.writeBoolean(ken);
        buf.writeBoolean(ko);
        buf.writeBoolean(in);
        buf.writeBoolean(gyo);
        buf.writeBoolean(inVisible);
        buf.writeBoolean(shu);
        for (int i = 0; i < level.length; i++) {
            buf.writeShort(level[i]);
            buf.writeFloat(progress[i]);
        }
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> apply()));
        ctx.get().setPacketHandled(true);
    }

    private void apply() {
        ClientAddonState.zetsu = zetsu;
        ClientAddonState.en = en;
        ClientAddonState.emperor = emperor;
        ClientAddonState.lifespan = lifespan;
        ClientAddonState.bookState = bookState;
        ClientAddonState.bookmark = bookmark;
        ClientAddonState.activePage = activePage;
        ClientAddonState.stolenKit = stolenKit;
        ClientAddonState.stolenMask = stolenMask;
        ClientAddonState.hostKit = hunter;
        ClientAddonState.bookHeld = bookHeld;
        ClientAddonState.enRadius = enRadius;
        ClientAddonState.enChosen = enChosen;
        ClientAddonState.renSize = renSize;
        ClientAddonState.ken = ken;
        ClientAddonState.ko = ko;
        ClientAddonState.in = in;
        ClientAddonState.gyo = gyo;
        ClientAddonState.inVisible = inVisible;
        ClientAddonState.shu = shu;
        System.arraycopy(level, 0, ClientAddonState.level, 0, level.length);
        System.arraycopy(progress, 0, ClientAddonState.progress, 0, progress.length);
    }
}
