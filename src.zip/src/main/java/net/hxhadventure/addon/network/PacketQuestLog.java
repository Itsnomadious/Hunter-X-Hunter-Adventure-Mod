package net.hxhadventure.addon.network;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.hxhadventure.addon.client.ClientQuests;
import net.hxhadventure.addon.quest.QuestData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;

/** Server -> client: the player's active quests and their progress. Sent on login and whenever the quest log changes, so no laptop is needed. */
public class PacketQuestLog {
    private final List<QuestData.Active> active;

    public PacketQuestLog(List<QuestData.Active> active) {
        this.active = active;
    }

    public PacketQuestLog(FriendlyByteBuf b) {
        int n = b.readVarInt();
        active = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            String id = b.readUtf(64);
            int len = b.readVarInt();
            int[] p = new int[len];
            for (int j = 0; j < len; j++) p[j] = b.readVarInt();
            active.add(new QuestData.Active(id, p));
        }
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(active.size());
        for (QuestData.Active a : active) {
            b.writeUtf(a.id, 64);
            b.writeVarInt(a.progress.length);
            for (int v : a.progress) b.writeVarInt(v);
        }
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientQuests.set(active)));
        ctx.get().setPacketHandled(true);
    }
}
