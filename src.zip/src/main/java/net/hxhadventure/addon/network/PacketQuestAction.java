package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.hxhadventure.addon.quest.QuestData;
import net.hxhadventure.block.LaptopBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;

/** Client -> server: a button on the laptop (accept, abandon, submit). Checked here: the sender must be near a laptop and a licensed Hunter. */
public class PacketQuestAction {
    private static final double MAX_DISTANCE_SQ = 12.0 * 12.0;

    private final int action;
    private final BlockPos pos;
    private final String questId;

    public PacketQuestAction(int action, BlockPos pos, String questId) {
        this.action = action;
        this.pos = pos;
        this.questId = questId;
    }

    public PacketQuestAction(FriendlyByteBuf b) {
        action = b.readVarInt();
        pos = b.readBlockPos();
        questId = b.readUtf(64);
    }

    public void toBytes(FriendlyByteBuf b) {
        b.writeVarInt(action);
        b.writeBlockPos(pos);
        b.writeUtf(questId, 64);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null || !sp.level().isLoaded(pos)) return;
            if (!(sp.level().getBlockState(pos).getBlock() instanceof LaptopBlock)) return;
            if (sp.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > MAX_DISTANCE_SQ) return;
            QuestData.handle(sp, action, questId);
            QuestData.sync(sp, pos, false);
        });
        ctx.get().setPacketHandled(true);
    }
}
