package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.LittleFlower;

/** Client -> server: the mouse buttons of somebody a Little Flower palm is on (their counter). */
public class PacketLfGuard {
    private final boolean left, right;

    public PacketLfGuard(boolean left, boolean right) { this.left = left; this.right = right; }
    public PacketLfGuard(FriendlyByteBuf b) { left = b.readBoolean(); right = b.readBoolean(); }
    public void toBytes(FriendlyByteBuf b) { b.writeBoolean(left); b.writeBoolean(right); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) LittleFlower.setGuard(sp, left, right);
        });
        ctx.get().setPacketHandled(true);
    }
}
