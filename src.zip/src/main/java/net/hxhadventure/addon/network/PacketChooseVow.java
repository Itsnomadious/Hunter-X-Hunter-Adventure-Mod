package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.Vows;

/** Client -> server: the player confirmed a Condition, Limitation or Vow in the Vows menu. The server checks it again. */
public class PacketChooseVow {
    private final String ruleId;

    public PacketChooseVow(String ruleId) { this.ruleId = ruleId; }
    public PacketChooseVow(FriendlyByteBuf buf) { this.ruleId = buf.readUtf(64); }
    public void toBytes(FriendlyByteBuf buf) { buf.writeUtf(ruleId, 64); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) Vows.choose(sp, ruleId);
        });
        ctx.get().setPacketHandled(true);
    }
}
