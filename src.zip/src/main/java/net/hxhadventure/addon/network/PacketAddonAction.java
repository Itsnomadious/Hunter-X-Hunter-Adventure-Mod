package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.NenAddonData;
import net.hxhadventure.addon.Tuning;

/** Client -> server hotkey actions. */
public class PacketAddonAction {
    public enum Action { TOGGLE_REN, TOGGLE_ZETSU, TOGGLE_EN, TOGGLE_KEN, TOGGLE_KO, HATSU, TOGGLE_IN, TOGGLE_GYO, TOGGLE_SHU }

    private final Action action;

    public PacketAddonAction(Action action) { this.action = action; }
    public PacketAddonAction(FriendlyByteBuf buf) { this.action = buf.readEnum(Action.class); }
    public void toBytes(FriendlyByteBuf buf) { buf.writeEnum(action); }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) run(sp);
        });
        ctx.get().setPacketHandled(true);
    }

    private void run(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !c.hasNenUnlocked()) {
            sp.displayClientMessage(Component.literal("\u00a7cUnlock your Nen first"), true);
            return;
        }
        if (net.hxhadventure.addon.ChainManager.isJailed(sp)) {
            sp.displayClientMessage(Component.literal("\u00a77Chains bind you"), true);
            return;
        }
        if (net.hxhadventure.addon.BlackVoice.isNenlessBody(sp)) {
            sp.displayClientMessage(Component.literal("\u00a77You have no Nen in this body. Shift+H to come back"), true);
            return;
        }
        if (net.hxhadventure.addon.BlackVoice.isAutoPilot(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Auto Pilot: the needle has the controls"), true);
            return;
        }
        NenAddonData d = NenAddonData.get(sp);
        if ((action == Action.TOGGLE_REN || action == Action.TOGGLE_KEN || action == Action.TOGGLE_KO) && d.delaySwitch(sp, c, action)) {
            sp.displayClientMessage(Component.literal("\u00a77Switching aura..."), true);
            return;
        }
        perform(sp, action);
    }

    /** Applies the action itself (also called when a delayed aura switch comes due). */
    public static void perform(ServerPlayer sp, Action action) {
        Combat c = Combat.get(sp);
        if (c == null || !c.hasNenUnlocked() || net.hxhadventure.addon.ChainManager.isJailed(sp)) return;
        NenAddonData d = NenAddonData.get(sp);
        switch (action) {
            case TOGGLE_REN -> {
                if (!c.isAuraActive() && net.hxhadventure.addon.Vows.refuseLocked(sp, "REN")) return;
                if (!c.isAuraActive() && c.getHatsuLevel() < Tuning.REN_MIN_HATSU_LEVEL) {
                    sp.displayClientMessage(Component.literal("\u00a7cRen unlocks at Level " + Tuning.REN_MIN_HATSU_LEVEL), true);
                    return;
                }
                if (d.zetsu) d.setZetsu(sp, false, "\u00a77Zetsu: Off");
                AbilityRegistry.execute("ren_toggle", sp);
            }
            case TOGGLE_ZETSU -> {
                if (!d.zetsu && net.hxhadventure.addon.Vows.refuseLocked(sp, "ZETSU")) return;
                d.setZetsu(sp, !d.zetsu, null);
            }
            case TOGGLE_EN -> d.setEn(sp, !d.en, null);
            case TOGGLE_KEN -> d.toggleKen(sp);
            case TOGGLE_KO -> d.toggleKo(sp);
            case TOGGLE_IN -> d.setIn(sp, !d.in, null);
            case TOGGLE_GYO -> d.setGyo(sp, !d.gyo, null);
            case TOGGLE_SHU -> d.setShu(sp, !d.shu, null);
            case HATSU -> hatsuMode(sp, c);
        }
    }

    /**
     * The single Hatsu Mode key (H): Black Voice's phone, Skill Hunter's book, Emperor Time (Chains), Hakoware on/off, Godspeed (Lightning), Pain Packer's armor on/off, Bungee Gum state, the Guanyin's summoning, Terpsichora or Gon's "I'll give everything"
     * (Jajanken). Using a Hatsu mode while in Zetsu drops you out of Zetsu first. Also called by the H key's own packet (UseEverything).
     */
    public static void hatsuMode(ServerPlayer sp, Combat c) {
        if (net.hxhadventure.addon.BlackVoice.returnKey(sp)) return; // Shift+H inside a borrowed body: back to your own
        if (c == null || !c.hasNenUnlocked()) {
            sp.displayClientMessage(Component.literal("\u00a7cUnlock your Nen first"), true);
            return;
        }
        if (net.hxhadventure.addon.ChainManager.isJailed(sp)) {
            sp.displayClientMessage(Component.literal("\u00a77Chains bind you"), true);
            return;
        }
        if (net.hxhadventure.addon.Vows.refuseLocked(sp, "HATSU")) return;
        if (net.hxhadventure.addon.BlackVoice.isNenlessBody(sp)) {
            sp.displayClientMessage(Component.literal("\u00a77You have no Nen in this body. Shift+H to come back"), true);
            return;
        }
        if (net.hxhadventure.addon.BlackVoice.isAutoPilot(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Auto Pilot: the needle has the controls"), true);
            return;
        }
        NenAddonData d = NenAddonData.get(sp);
        if (net.hxhadventure.addon.BlackVoice.canUse(c)) {
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.BlackVoice.togglePhone(sp);
        } else if (net.hxhadventure.addon.SkillHunter.isHunter(sp, c)) {
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.SkillHunter.toggleBook(sp);
        } else if (net.hxhadventure.addon.ChainManager.canUseChains(c)) {
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.ChainManager.emperorTime(sp);
        } else if (net.hxhadventure.addon.LightningAura.canUse(c)) {
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.LightningAura.toggleGodspeed(sp);
        } else if (net.hxhadventure.addon.Hakoware.canUse(c)) {
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.Hakoware.toggle(sp);
        } else if (net.hxhadventure.addon.Jajanken.canUse(c)) {
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.GonVow.toggle(sp);
        } else if (net.hxhadventure.addon.Guanyin.canUse(c)) {
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.Guanyin.hPressed(sp); // before enlightenment H prays, after it H manifests the statue
        } else if (net.hxhadventure.addon.PainPacker.canUse(c)) {
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.PainPacker.toggle(sp);
        } else if (net.hxhadventure.addon.MagicalEsthetician.canUse(c)) {
            // Biscuit's Body Transformation (the client only sends H after a 2 second hold)
            if (c.getHatsuLevel() >= net.hxhadventure.addon.EstheticianTuning.TRANSFORM_MIN_LEVEL) d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.MagicalEsthetician.toggleForm(sp);
        } else if (net.hxhadventure.addon.Blinky.canUse(c)) {
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.Blinky.toggle(sp);
        } else if (net.hxhadventure.addon.CrazySlots.canUse(c)) {
            // Kite's Crazy Slots: summon the clown (Z rolls the roulette)
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.CrazySlots.toggle(sp);
        } else if (net.hxhadventure.addon.LittleFlower.canUse(c)) {
            // Genthru's Little Flower: the palms on / off (left and right click are the hands)
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.LittleFlower.toggle(sp);
        } else if (net.hxhadventure.addon.NenStitches.canUse(c)) {
            // Machi's Nen Stitches: Threads mode on / off (the basic attacks become slashes)
            d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.NenStitches.toggle(sp);
        } else if (net.hxhadventure.addon.BungeeGum.canUse(c)) {
            // Hisoka's Bungee Gum state: 10% less damage taken, anyone who hits you in melee gets Rubber and Gum
            if (!net.hxhadventure.addon.BungeeGum.inState(sp)) d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.BungeeGum.toggleState(sp);
        } else if (net.hxhadventure.addon.Terpsichora.canUse(c)) {
            // Neferpitou's Terpsichora: the figure appears for a second, its buffs last a minute (it is no longer in the Z list)
            if (c.getHatsuLevel() >= Tuning.TERPSI_MIN_LEVEL) d.leaveZetsuForHatsu(sp);
            net.hxhadventure.addon.Terpsichora.activate(sp);
        } else {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu has no mode to switch"), true);
        }
    }
}
