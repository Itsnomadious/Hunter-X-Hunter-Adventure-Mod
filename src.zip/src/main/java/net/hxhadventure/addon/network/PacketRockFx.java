package net.hxhadventure.addon.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent.Context;
import net.hxhadventure.addon.client.JajankenFx;

/**
 * Server -> clients tracking a player: the state of that player's Jajanken move (Rock or Scissors).
 * move: 0 = Rock, 1 = Scissors.
 * mode 0 = gone, 1 = charging (x = ticks since the press: the max-size Ren flare first, then the aura converges on the fist),
 * 2 = the punch was thrown ((x, y, z) is where it landed, a = how many times a normal Rock's blast size it is: 0 or 1 normally, 20 in Gon's adult form),
 * 3 = the Scissors slash ((x, y, z) is where the dash started, a = how far it went, b = the yaw it went in),
 * 4 = the Paper ball was thrown ((x, y, z) is where it starts, a = the charge 0..1, b / c = the yaw / pitch it flies along),
 * 5 = the Paper ball burst at (x, y, z).
 */
public class PacketRockFx {
    private final int owner;
    private final int mode;
    private final int move;
    private final double x, y, z;
    private final double a;
    private final float b, c;

    public PacketRockFx(int owner, int mode, int move, double x, double y, double z, double a, float b) {
        this(owner, mode, move, x, y, z, a, b, 0f);
    }

    public PacketRockFx(int owner, int mode, int move, double x, double y, double z, double a, float b, float c) {
        this.owner = owner;
        this.mode = mode;
        this.move = move;
        this.x = x;
        this.y = y;
        this.z = z;
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public PacketRockFx(FriendlyByteBuf buf) {
        owner = buf.readVarInt();
        mode = buf.readVarInt();
        move = buf.readVarInt();
        x = buf.readDouble();
        y = buf.readDouble();
        z = buf.readDouble();
        a = buf.readDouble();
        b = buf.readFloat();
        c = buf.readFloat();
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeVarInt(owner);
        buf.writeVarInt(mode);
        buf.writeVarInt(move);
        buf.writeDouble(x);
        buf.writeDouble(y);
        buf.writeDouble(z);
        buf.writeDouble(a);
        buf.writeFloat(b);
        buf.writeFloat(c);
    }

    public void handle(Supplier<Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> JajankenFx.set(owner, mode, move, x, y, z, a, b, c)));
        ctx.get().setPacketHandled(true);
    }
}
