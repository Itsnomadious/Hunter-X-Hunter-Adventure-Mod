package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedBowAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedCrossbowAttackGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.Tags;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketNeedleDisguise;
import net.hxhadventure.addon.network.PacketNeedleFx;

/**
 * Illumi's Needles (Hatsu kit 15, Manipulators). Three skills on the R / Z ability scroll:
 *
 * <ol>
 *   <li><b>Body Alteration</b>: with the ability selected, right-click anyone to save how they look. Z then drives the
 *       needles into your own head and you take on that look (skin and model; chat name too, see
 *       {@link Tuning#NEEDLES_BODY_COPIES_NAME}). Z again pulls them out.</li>
 *   <li><b>Corpse Control</b>: Z draws a needle, right-click an undead or a corpse to plant it in its head. It becomes
 *       your ally. Up to {@link Tuning#NEEDLES_CORPSE_MAX} at once.</li>
 *   <li><b>Needle People</b>: the same, but on any mob that is not a boss, with no limit on how many. Each one costs
 *       {@link Tuning#NEEDLES_PEOPLE_COST} Nen, which is an enormous amount.</li>
 * </ol>
 * Sneak + ability lets that skill's controlled bodies go; sneak + right-click on one frees just that one. Controlled
 * bodies are tracked by UUID on the server and ticked like Puppeteer's. Clients are only told what to draw
 * (PacketNeedleFx / PacketNeedleDisguise). Forge hooks live in {@link NeedleEvents}.
 */
public final class IllumiNeedles {
    private IllumiNeedles() {}

    public static final int KIT = 15;
    public static final String BODY_ID = "body_alteration";
    public static final String CORPSE_ID = "corpse_control";
    public static final String PEOPLE_ID = "needle_people";

    /** Needle layouts for PacketNeedleFx: none, a few across the forehead, or a crowd over the back of the skull. */
    public static final int OFF = 0, FOREHEAD = 1, SKULL = 2;

    private static final int ARM_NONE = 0, ARM_CORPSE = 1, ARM_PEOPLE = 2;
    private static final String SAVE_TAG = "hxh_needles_saved";

    private static final class State {
        NeedleAppearance saved;
        boolean transformed;
        int armed = ARM_NONE;
        int cooldown;
        final LinkedHashSet<UUID> corpses = new LinkedHashSet<>();
        final LinkedHashSet<UUID> people = new LinkedHashSet<>();
    }

    private static final Map<UUID, State> STATES = new HashMap<>();          // player uuid -> state
    private static final Map<UUID, UUID> CONTROLLER = new HashMap<>();       // controlled uuid -> owner uuid
    private static final Map<UUID, Integer> KIND = new HashMap<>();          // controlled uuid -> ARM_CORPSE / ARM_PEOPLE
    private static final Map<UUID, Integer> IDS = new HashMap<>();           // controlled uuid -> entity id (for packets)
    private static final Map<UUID, Integer> MISSING = new HashMap<>();       // controlled uuid -> ticks it could not be found
    private static final Map<UUID, Goal> GOALS = new HashMap<>();            // attack goals we gave to mobs that had none

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    /** Adds the unlocked needle abilities to the scroll. */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c)) return base;
        List<String> list = new ArrayList<>(Arrays.asList(base));
        int lvl = c.getHatsuLevel();
        if (lvl >= Tuning.NEEDLES_BODY_MIN_LEVEL) list.add(BODY_ID);
        if (lvl >= Tuning.NEEDLES_CORPSE_MIN_LEVEL) list.add(CORPSE_ID);
        if (lvl >= Tuning.NEEDLES_PEOPLE_MIN_LEVEL) list.add(PEOPLE_ID);
        return list.toArray(new String[0]);
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(BODY_ID, IllumiNeedles::bodyAlteration);
        m.put(CORPSE_ID, sp -> arm(sp, ARM_CORPSE));
        m.put(PEOPLE_ID, sp -> arm(sp, ARM_PEOPLE));
    }

    public static boolean isControlled(Entity e) {
        return e != null && CONTROLLER.containsKey(e.getUUID());
    }

    /** The owner's UUID if e carries somebody's needle, else null. */
    public static UUID controllerOf(Entity e) {
        return e == null ? null : CONTROLLER.get(e.getUUID());
    }

    // ---------------- state ----------------
    private static State state(ServerPlayer sp) {
        State s = STATES.get(sp.getUUID());
        if (s == null) {
            s = new State();
            CompoundTag persisted = sp.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
            if (persisted.contains(SAVE_TAG, Tag.TAG_COMPOUND)) s.saved = NeedleAppearance.load(persisted.getCompound(SAVE_TAG));
            STATES.put(sp.getUUID(), s);
        }
        return s;
    }

    /** The saved look lives under Forge's PlayerPersisted tag, which (unlike plain persistent data) survives death. */
    private static void persist(ServerPlayer sp, State s) {
        CompoundTag persisted = sp.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        if (s.saved != null) persisted.put(SAVE_TAG, s.saved.save());
        else persisted.remove(SAVE_TAG);
        sp.getPersistentData().put(Player.PERSISTED_NBT_TAG, persisted);
    }

    private static boolean gate(ServerPlayer sp, Combat c, int minLevel, String name) {
        if (c == null || !sp.isAlive()) return false;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("§cYour Hatsu is not Illumi's Needles"), true);
            return false;
        }
        if (c.getHatsuLevel() < minLevel) {
            sp.displayClientMessage(Component.literal("§c" + name + " unlocks at Level " + minLevel), true);
            return false;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("§5Forced Zetsu: the needles cannot be used"), true);
            return false;
        }
        return true;
    }

    // ================= 1. Body Alteration =================

    /** Server side of "right-click someone with Body Alteration selected" (the client sends the target's entity id). */
    public static void saveAppearance(ServerPlayer sp, int entityId) {
        Combat c = Combat.get(sp);
        if (!gate(sp, c, Tuning.NEEDLES_BODY_MIN_LEVEL, "Body Alteration")) return;
        Entity t = sp.level().getEntity(entityId);
        if (!(t instanceof LivingEntity le) || t == sp || !t.isAlive()) return;
        if (sp.distanceToSqr(t) > Tuning.NEEDLES_SAVE_RANGE * Tuning.NEEDLES_SAVE_RANGE) {
            sp.displayClientMessage(Component.literal("§cToo far away to study them"), true);
            return;
        }
        State s = state(sp);
        s.saved = NeedleAppearance.of(le);
        persist(sp, s);
        if (sp.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.ENCHANT, t.getX(), t.getY() + t.getBbHeight() * 0.6, t.getZ(), 20, 0.3, 0.4, 0.3, 0.6);
        }
        playSound(sp, SoundEvents.BOOK_PAGE_TURN, 0.8f, 1.3f);
        sp.displayClientMessage(Component.literal("§5Appearance saved: §f" + s.saved.name
            + (s.transformed ? " §7(applied)" : " §7- press Z to take it on")), true);
        if (s.transformed) {
            sendDisguise(sp, s.saved);
            sp.refreshDisplayName();
        }
    }

    /** Z on Body Alteration: put the needles in and become the saved look; Z again takes them out. */
    public static void bodyAlteration(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        State s = state(sp);
        if (s.transformed) {
            revert(sp, s);
            playSound(sp, SoundEvents.CHAIN_BREAK, 0.7f, 1.4f);
            sp.displayClientMessage(Component.literal("§7The needles come out. You are yourself again"), true);
            return;
        }
        if (!gate(sp, c, Tuning.NEEDLES_BODY_MIN_LEVEL, "Body Alteration")) return;
        if (s.saved == null) {
            sp.displayClientMessage(Component.literal("§cNobody saved yet. Select Body Alteration and right-click someone"), true);
            return;
        }
        if (ChainManager.onCooldown(sp, "Body Alteration", s.cooldown)) return;
        if (c.getCurrentEnergy() < Tuning.NEEDLES_BODY_COST) {
            sp.displayClientMessage(Component.literal("§cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.NEEDLES_BODY_COST);
        s.transformed = true;
        s.cooldown = Tuning.NEEDLES_BODY_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, "Body Alteration", Tuning.NEEDLES_BODY_COOLDOWN_TICKS);
        sendDisguise(sp, s.saved);
        AddonNetwork.sendToTrackingAndSelf(new PacketNeedleFx(sp.getId(), FOREHEAD), sp);
        sp.refreshDisplayName();
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        playSound(sp, SoundEvents.CHAIN_PLACE, 1.0f, 1.8f);
        playSound(sp, SoundEvents.BONE_MEAL_USE, 0.8f, 0.7f);
        sp.displayClientMessage(Component.literal("§5Body Alteration: §f" + s.saved.name), true);
    }

    private static void revert(ServerPlayer sp, State s) {
        if (!s.transformed) return;
        s.transformed = false;
        AddonNetwork.sendToTrackingAndSelf(new PacketNeedleDisguise(sp.getId(), null), sp);
        AddonNetwork.sendToTrackingAndSelf(new PacketNeedleFx(sp.getId(), OFF), sp);
        sp.refreshDisplayName();
    }

    private static void sendDisguise(ServerPlayer sp, NeedleAppearance a) {
        AddonNetwork.sendToTrackingAndSelf(new PacketNeedleDisguise(sp.getId(), a), sp);
    }

    /** The name chat and nameplates should show for this player right now, or null for their own. */
    public static Component displayNameOf(ServerPlayer sp) {
        if (!Tuning.NEEDLES_BODY_COPIES_NAME) return null;
        State s = STATES.get(sp.getUUID());
        if (s == null || !s.transformed || s.saved == null || s.saved.name.isEmpty()) return null;
        return Component.literal(s.saved.name);
    }

    // ================= 2 + 3. Corpse Control and Needle People =================

    /**
     * Undead mobs and "corpses" (see {@link Puppeteer#isValidTarget}: this mod has no corpse entity of its own, so a
     * corpse is anything whose entity id contains "corpse"). Never bosses.
     */
    public static boolean isCorpseTarget(Entity e) {
        return Puppeteer.isValidTarget(e);
    }

    /** Any mob except a boss. Players are not mobs, so they are left alone (nothing can steer a player's body). */
    public static boolean isPeopleTarget(Entity e) {
        return e instanceof Mob m && m.isAlive() && !m.getType().is(Tags.EntityTypes.BOSSES);
    }

    private static boolean takenByOther(Entity e) {
        return isControlled(e) || Puppeteer.isPuppet(e) || SkillHunter.controllerOf(e.getUUID()) != null || BlackVoice.isAntenna(e);
    }

    private static String nameOf(int kind) {
        return kind == ARM_CORPSE ? "Corpse Control" : "Needle People";
    }

    /** Z on Corpse Control / Needle People: draw a needle (or put it away). Sneak + Z lets that skill's bodies go. */
    private static void arm(ServerPlayer sp, int kind) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        State s = state(sp);
        LinkedHashSet<UUID> mine = kind == ARM_CORPSE ? s.corpses : s.people;
        if (sp.isShiftKeyDown() && (!mine.isEmpty() || s.armed == kind)) {
            int n = mine.size();
            releaseKind(sp, s, kind);
            if (s.armed == kind) s.armed = ARM_NONE;
            sp.displayClientMessage(Component.literal("§7The needles are drawn out" + (n > 0 ? " (" + n + " freed)" : "")), true);
            return;
        }
        if (s.armed == kind) {
            s.armed = ARM_NONE;
            sp.displayClientMessage(Component.literal("§7Needle put away"), true);
            return;
        }
        int min = kind == ARM_CORPSE ? Tuning.NEEDLES_CORPSE_MIN_LEVEL : Tuning.NEEDLES_PEOPLE_MIN_LEVEL;
        if (!gate(sp, c, min, nameOf(kind))) return;
        if (kind == ARM_CORPSE && s.corpses.size() >= Tuning.NEEDLES_CORPSE_MAX) {
            sp.displayClientMessage(Component.literal("§cYou cannot control more than " + Tuning.NEEDLES_CORPSE_MAX + " corpses"), true);
            return;
        }
        s.armed = kind;
        playSound(sp, SoundEvents.CHAIN_PLACE, 0.6f, 1.9f);
        sp.displayClientMessage(Component.literal(kind == ARM_CORPSE
            ? "§5Needle drawn §7- right-click an undead or a corpse"
            : "§5Needle drawn §7- right-click anything that is not a boss (§c" + (int) Tuning.NEEDLES_PEOPLE_COST + " Nen§7)"), true);
    }

    /** Right-click on an entity (server). Returns true if it was used and the event should be cancelled. */
    public static boolean handleRightClick(ServerPlayer sp, Entity target) {
        State s = STATES.get(sp.getUUID());
        if (s == null || target == null) return false;
        // sneak + right-click on one of your own: pull its needle out
        if (sp.isShiftKeyDown() && (s.corpses.contains(target.getUUID()) || s.people.contains(target.getUUID()))) {
            release(sp.server, target.getUUID());
            playSound(sp, SoundEvents.CHAIN_BREAK, 0.7f, 1.2f);
            sp.displayClientMessage(Component.literal("§7Needle removed §8(" + s.corpses.size() + " corpses, " + s.people.size() + " people)"), true);
            return true;
        }
        if (s.armed == ARM_NONE) return false;
        Combat c = Combat.get(sp);
        if (!canUse(c) || !sp.isAlive()) {
            s.armed = ARM_NONE;
            return false;
        }
        int kind = s.armed;
        if (takenByOther(target)) {
            sp.displayClientMessage(Component.literal("§cAlready controlled"), true);
            return true;
        }
        if (kind == ARM_CORPSE) {
            if (!isCorpseTarget(target)) {
                if (target instanceof LivingEntity) sp.displayClientMessage(Component.literal("§cCorpse Control only works on the undead and on corpses"), true);
                return false;
            }
            if (s.corpses.size() >= Tuning.NEEDLES_CORPSE_MAX) {
                sp.displayClientMessage(Component.literal("§cYou cannot control more than " + Tuning.NEEDLES_CORPSE_MAX + " corpses"), true);
                return true;
            }
        } else if (!isPeopleTarget(target)) {
            if (target instanceof LivingEntity) {
                boolean boss = target.getType().is(Tags.EntityTypes.BOSSES);
                sp.displayClientMessage(Component.literal(boss ? "§cA boss's will is too strong for the needles"
                    : "§cThe needles can only control mobs"), true);
            }
            return false;
        }
        if (ChainManager.onCooldown(sp, nameOf(kind), s.cooldown)) return true;
        float cost = kind == ARM_CORPSE ? Tuning.NEEDLES_CORPSE_COST : Tuning.NEEDLES_PEOPLE_COST;
        if (c.getCurrentEnergy() < cost) {
            sp.displayClientMessage(Component.literal("§cNot enough energy (" + (int) cost + " needed)"), true);
            return true;
        }
        c.consumeEnergy(cost);
        attach(sp, s, target, kind);
        return true;
    }

    private static void attach(ServerPlayer sp, State s, Entity target, int kind) {
        s.armed = ARM_NONE;
        s.cooldown = Tuning.NEEDLES_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, nameOf(kind), Tuning.NEEDLES_COOLDOWN_TICKS);
        (kind == ARM_CORPSE ? s.corpses : s.people).add(target.getUUID());
        CONTROLLER.put(target.getUUID(), sp.getUUID());
        KIND.put(target.getUUID(), kind);
        IDS.put(target.getUUID(), target.getId());
        MISSING.remove(target.getUUID());
        if (target instanceof Mob m) {
            m.setPersistenceRequired();
            m.setTarget(null);
            if (kind == ARM_PEOPLE) giveTeeth(m);
        }
        AddonNetwork.sendToTrackingAndSelf(new PacketNeedleFx(target.getId(), kind == ARM_CORPSE ? FOREHEAD : SKULL), target);
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        playSound(sp, SoundEvents.CHAIN_PLACE, 1.0f, 1.9f);
        sp.level().playSound(null, target.blockPosition(), SoundEvents.BONE_MEAL_USE, SoundSource.HOSTILE, 1.0f, 0.6f);
        if (sp.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.CRIT, target.getX(), target.getEyeY(), target.getZ(), 12, 0.2, 0.2, 0.2, 0.3);
        }
        sp.displayClientMessage(Component.literal(kind == ARM_CORPSE
            ? "§5Corpse controlled §8(" + s.corpses.size() + "/" + Tuning.NEEDLES_CORPSE_MAX + ")"
            : "§5Person controlled §8(" + s.people.size() + ")"), true);
    }

    /**
     * A mob with no way to hurt anything (a villager, a cow...) is given a plain melee goal, if it has an attack damage
     * attribute at all, so a controlled body can still fight for you. Mobs that already attack are left alone.
     */
    private static void giveTeeth(Mob m) {
        if (!(m instanceof PathfinderMob pm) || pm.getAttribute(Attributes.ATTACK_DAMAGE) == null) return;
        boolean armed = pm.goalSelector.getAvailableGoals().stream().anyMatch(w -> {
            Goal g = w.getGoal();
            return g instanceof MeleeAttackGoal || g instanceof RangedAttackGoal || g instanceof RangedBowAttackGoal<?>
                || g instanceof RangedCrossbowAttackGoal<?>;
        });
        if (armed) return;
        Goal teeth = new MeleeAttackGoal(pm, 1.2, true);
        pm.goalSelector.addGoal(2, teeth);
        GOALS.put(m.getUUID(), teeth);
    }

    // ---------------- ending ----------------
    /** Lets one controlled body go (needle pulled, or it died). */
    public static void release(MinecraftServer server, UUID puppet) {
        UUID owner = CONTROLLER.remove(puppet);
        KIND.remove(puppet);
        Integer id = IDS.remove(puppet);
        MISSING.remove(puppet);
        Goal teeth = GOALS.remove(puppet);
        if (owner != null) {
            State s = STATES.get(owner);
            if (s != null) {
                s.corpses.remove(puppet);
                s.people.remove(puppet);
            }
        }
        if (server == null) return;
        Entity e = find(server, puppet);
        if (e instanceof Mob m) {
            m.setTarget(null);
            if (teeth != null) m.goalSelector.removeGoal(teeth);
        }
        if (id != null) {
            PacketNeedleFx off = new PacketNeedleFx(id, OFF);
            if (e != null) AddonNetwork.sendToTracking(off, e);
            else for (net.minecraft.server.level.ServerPlayer p : server.getPlayerList().getPlayers()) AddonNetwork.sendToPlayer(off, p);
        }
    }

    private static void releaseKind(ServerPlayer sp, State s, int kind) {
        for (UUID id : new ArrayList<>(kind == ARM_CORPSE ? s.corpses : s.people)) release(sp.server, id);
    }

    /** The owner died, logged out or lost the Hatsu: every needle comes out and they change back. */
    public static void onOwnerGone(ServerPlayer sp) {
        State s = STATES.get(sp.getUUID());
        if (s == null) return;
        for (UUID id : new ArrayList<>(s.corpses)) release(sp.server, id);
        for (UUID id : new ArrayList<>(s.people)) release(sp.server, id);
        revert(sp, s);
        STATES.remove(sp.getUUID());
    }

    /** Any entity died: if it carried a needle, that body is let go. */
    public static void onDeath(Entity e) {
        if (isControlled(e)) release(e.getServer(), e.getUUID());
    }

    public static void reset() {
        STATES.clear();
        CONTROLLER.clear();
        KIND.clear();
        IDS.clear();
        MISSING.clear();
        GOALS.clear();
    }

    // ---------------- per tick ----------------
    public static void serverTick(MinecraftServer server) {
        if (STATES.isEmpty()) return;
        boolean think = server.getTickCount() % 10 == 0;
        for (Map.Entry<UUID, State> en : new ArrayList<>(STATES.entrySet())) {
            State s = en.getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null || !sp.isAlive()) {
                if (sp != null) onOwnerGone(sp);
                else {
                    for (UUID id : new ArrayList<>(s.corpses)) release(server, id);
                    for (UUID id : new ArrayList<>(s.people)) release(server, id);
                    STATES.remove(en.getKey());
                }
                continue;
            }
            if (s.cooldown > 0) s.cooldown--;
            Combat c = Combat.get(sp);
            if (!canUse(c)) {
                onOwnerGone(sp);
                continue;
            }
            if (ExtrasHooks.hatsuForced(sp)) {
                s.armed = ARM_NONE;
                if (s.transformed) {
                    revert(sp, s);
                    sp.displayClientMessage(Component.literal("§5Forced Zetsu: the needles fall out"), true);
                }
            }
            if (!think) continue;
            for (UUID id : new ArrayList<>(s.corpses)) tickBody(server, sp, id, ARM_CORPSE);
            for (UUID id : new ArrayList<>(s.people)) tickBody(server, sp, id, ARM_PEOPLE);
        }
    }

    private static void tickBody(MinecraftServer server, ServerPlayer owner, UUID id, int kind) {
        Entity e = find(server, id);
        if (e == null) {
            // unloaded chunk or another dimension for a while: keep it, but not forever
            if (MISSING.merge(id, 10, Integer::sum) > 1200) release(server, id);
            return;
        }
        MISSING.remove(id);
        if (!e.isAlive()) {
            release(server, id);
            return;
        }
        if (e.level() != owner.level()) return;
        control(owner, e, kind);
    }

    private static void control(ServerPlayer owner, Entity e, int kind) {
        if (e instanceof Mob m) {
            if (kind == ARM_CORPSE && m.isOnFire() && !m.isInLava()) m.clearFire(); // the needle keeps the body from burning up in the sun
            LivingEntity tgt = pickTarget(owner, m);
            m.setTarget(tgt);
            if (tgt == null) follow(owner, m);
        } else {
            // a corpse that cannot think: just glide it along behind the owner
            double dx = owner.getX() - e.getX(), dz = owner.getZ() - e.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > Tuning.NEEDLES_FOLLOW_DISTANCE) {
                double step = Math.min(2.5, d - Tuning.NEEDLES_FOLLOW_DISTANCE);
                e.setPos(e.getX() + dx / d * step, e.getY(), e.getZ() + dz / d * step);
            }
        }
    }

    private static void follow(ServerPlayer owner, Mob m) {
        double d = m.distanceTo(owner);
        if (d > Tuning.NEEDLES_TELEPORT_DISTANCE) {
            m.teleportTo(owner.getX() + (m.getRandom().nextDouble() - 0.5) * 3, owner.getY(), owner.getZ() + (m.getRandom().nextDouble() - 0.5) * 3);
            m.getNavigation().stop();
        } else if (d > Tuning.NEEDLES_FOLLOW_DISTANCE) {
            m.getNavigation().moveTo(owner, 1.2);
        } else {
            m.getNavigation().stop();
        }
    }

    private static LivingEntity pickTarget(ServerPlayer owner, Mob m) {
        LivingEntity t = owner.getLastHurtMob();
        if (okTarget(owner, m, t) && owner.tickCount - owner.getLastHurtMobTimestamp() < 200) return t;
        t = owner.getLastHurtByMob();
        if (okTarget(owner, m, t) && owner.tickCount - owner.getLastHurtByMobTimestamp() < 200) return t;
        List<LivingEntity> near = m.level().getEntitiesOfClass(LivingEntity.class, m.getBoundingBox().inflate(Tuning.NEEDLES_CONTROL_RANGE),
            x -> x instanceof Enemy && okTarget(owner, m, x));
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity x : near) {
            double d = x.distanceToSqr(m);
            if (d < bd) {
                bd = d;
                best = x;
            }
        }
        return best;
    }

    private static boolean okTarget(ServerPlayer owner, Mob m, LivingEntity t) {
        if (t == null || !t.isAlive() || t == m || t == owner) return false;
        if (owner.getUUID().equals(controllerOf(t))) return false; // never one of your own
        if (t instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        return m.canAttack(t);
    }

    // ---------------- helpers ----------------
    private static Entity find(MinecraftServer server, UUID id) {
        for (ServerLevel lvl : server.getAllLevels()) {
            Entity e = lvl.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    /** A player who comes into view of somebody with needles in them sees them (and any disguise) straight away. */
    public static void sendTo(ServerPlayer viewer, Entity target) {
        if (target == null) return;
        Integer kind = KIND.get(target.getUUID());
        if (kind != null) {
            AddonNetwork.sendToPlayer(new PacketNeedleFx(target.getId(), kind == ARM_CORPSE ? FOREHEAD : SKULL), viewer);
        } else if (target instanceof ServerPlayer p) {
            State s = STATES.get(p.getUUID());
            if (s != null && s.transformed && s.saved != null) {
                AddonNetwork.sendToPlayer(new PacketNeedleDisguise(p.getId(), s.saved), viewer);
                AddonNetwork.sendToPlayer(new PacketNeedleFx(p.getId(), FOREHEAD), viewer);
            }
        }
    }

    private static void playSound(ServerPlayer sp, SoundEvent ev, float vol, float pitch) {
        sp.level().playSound(null, sp.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }
}
