package net.hxhadventure.addon;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registers Cookie's attributes (mod event bus). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class EstheticianModEvents {
    private EstheticianModEvents() {}

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(HxHEntities.COOKIE.get(), CookieEntity.createAttributes().build());
    }
}
