package net.hxhadventure.addon;

/** Numbers for Biscuit Krueger's Magical Esthetician (Hatsu kit 27, Transmuters). Change them here. */
public final class EstheticianTuning {
    private EstheticianTuning() {}

    // ---- unlocks ----
    /** Hatsu level needed to summon Cookie (the Z skill). */
    public static final int MIN_LEVEL = 10;
    /** Hatsu level needed for Body Transformation (the H skill, held for 2 s). */
    public static final int TRANSFORM_MIN_LEVEL = 30;

    // ---- Cookie ----
    /** Aura paid to summon Cookie. Sending her away again (using the skill a second time) is free. */
    public static final float SUMMON_COST = 150f;
    /** Pause after calling or dismissing her, so the skill cannot be spammed. */
    public static final int SUMMON_COOLDOWN_TICKS = 40;
    /** Cookie is dismissed on her own if her owner gets farther than this (blocks) or leaves the dimension. */
    public static final double COOKIE_MAX_DISTANCE = 48.0;
    /** The owner has to be this close to Cookie to ask for a service (blocks). */
    public static final double SERVICE_MAX_DISTANCE = 8.0;
    /** How far Cookie appears in front of the summoner (blocks). */
    public static final double SUMMON_DISTANCE = 1.8;

    // ---- the two services ----
    /** Aura paid for each service. */
    public static final float SERVICE_COST = 100f;
    /** How long the owner sits through a Magical Spa Service (200 ticks = 10 s). */
    public static final int SPA_TICKS = 200;
    /** How long the owner lies through a Piano Massage (200 ticks = 10 s). */
    public static final int PIANO_TICKS = 200;
    /** How long either buff lasts once the service is done (36000 ticks = 30 minutes). */
    public static final int BUFF_TICKS = 36000;
    /** Spa Afterglow: damage dealt AND durability, +10% plus 0.1% for every Hatsu level. */
    public static final float SPA_BASE = 0.10f;
    public static final float SPA_PER_LEVEL = 0.001f;
    /** Piano Massage: aura regeneration, +25% plus 0.1% for every Hatsu level. */
    public static final float PIANO_BASE = 0.25f;
    public static final float PIANO_PER_LEVEL = 0.001f;

    // ---- positions during a service (blocks) ----
    /** Spa: Cookie kneels this far behind the seated owner. */
    public static final double SPA_BEHIND = 0.62;
    /** Piano Massage: Cookie kneels this far to the side of the owner's body, and this far along it from the feet. */
    public static final double PIANO_BESIDE = 0.78;
    public static final double PIANO_ALONG = 0.30;
    /** How far the model sinks when sitting (render only; the hitbox shrinks with it). */
    public static final float SIT_DROP = 0.58f;
    public static final float SIT_HEIGHT = 1.25f;
    public static final float LIE_SIZE = 0.6f;
    /** Cookie sinks this far when she kneels (render only). */
    public static final float KNEEL_DROP = 0.55f;

    // ---- Body Transformation (H, hold 2 s to switch on or off) ----
    /** 12000 ticks = 10 minutes. */
    public static final int TRANSFORM_TICKS = 12000;
    /** Cooldown once the form ends, however it ended (2400 ticks = 120 s). */
    public static final int TRANSFORM_COOLDOWN_TICKS = 2400;
    public static final float TRANSFORM_COST = 250f;
    public static final float TRANSFORM_DAMAGE_MULT = 1.5f;       // +50% damage
    public static final float TRANSFORM_DURABILITY_MULT = 1.5f;   // +50% durability (damage taken is divided)
    public static final float TRANSFORM_SPEED_BONUS = 0.20f;      // +20% movement speed
    public static final float TRANSFORM_AURA_MULT = 1.2f;         // +20% maximum aura
    /** Height (and hitbox) multiplier: the user grows. */
    public static final float TRANSFORM_HEIGHT_MULT = 1.3f;
}
