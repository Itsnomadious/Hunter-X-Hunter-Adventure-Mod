package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registers Chrollo's attributes and spawn egg, and applies his Nen to the damage he deals and takes. */
public final class ChrolloEvents {
    private ChrolloEvents() {}

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ChrolloModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent e) {
            e.put(HxHEntities.CHROLLO.get(), ChrolloEntity.createAttributes().build());
            e.put(HxHEntities.BYSTANDER.get(), BystanderEntity.createAttributes().build());
        }

        @SubscribeEvent
        public static void creativeTab(BuildCreativeModeTabContentsEvent e) {
            if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) e.accept(HxHEntities.CHROLLO_SPAWN_EGG.get());
        }
    }

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class ChrolloGame {
        /** Chrollo disguised as a Bystander: creatures that go for him pick someone else, unless he is the only one there. */
        @SubscribeEvent
        public static void onChangeTarget(LivingChangeTargetEvent event) {
            if (event.getEntity().level().isClientSide) return;
            if (event.getNewTarget() instanceof ChrolloEntity c && c.isDisguised() && event.getEntity() instanceof net.minecraft.world.entity.Mob m) {
                LivingEntity alt = c.altTargetFor(m);
                if (alt != null) event.setNewTarget(alt);
            }
        }

        /** Same slot as the players' handler (AddonServerEvents.onHurt), run after it. */
        @SubscribeEvent(priority = EventPriority.LOW)
        public static void onHurt(LivingHurtEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide) return;
            DamageSource src = event.getSource();
            float amount = event.getAmount();
            Entity cause = src.getEntity();

            if (cause instanceof ChrolloEntity h && h != victim) {
                amount *= h.outgoingMult(src);
            }
            if (victim instanceof ChrolloEntity h) amount *= h.incomingMult(src);
            event.setAmount(amount);
        }
    }
}
