package net.hxhadventure.addon;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.abilities.Combat;

/**
 * Shu: coats the item in hand in aura. More weapon damage, far less durability loss, faster mining, but the user takes more damage while it is on.
 * Durability: 10% less loss per 10 levels, then from level 80 a steep climb to 10x Netherite's durability (20310 uses) at level 100, for any coated tool or weapon.
 * The numbers live in {@link Tuning} (SHU_*). Self-registering, so no existing event class needs editing for the durability part.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class Shu {
    private Shu() {}

    /** A weapon here is any damageable item whose main-hand attributes give attack damage (swords, axes, katanas, trident...). */
    public static boolean isWeapon(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isDamageableItem()) return false;
        return !stack.getAttributeModifiers(EquipmentSlot.MAINHAND).get(Attributes.ATTACK_DAMAGE).isEmpty();
    }

    /** Damage multiplier for a melee hit with the weapon in hand (1 when Shu is off or the hand holds no weapon). */
    public static float damageMult(Player p, NenAddonData d) {
        if (d == null || !d.shu || !isWeapon(p.getMainHandItem())) return 1f;
        return (1f + Tuning.shuDamageBonus(d.effLevel(NenSkill.SHU))) * Vows.power(p, "SHU"); // x1.05 for each Limitation sworn on Shu
    }

    /** Damage-taken multiplier for the user while Shu is on (1 when it is off). */
    public static float takenMult(NenAddonData d) {
        if (d == null || !d.shu) return 1f;
        return 1f + Tuning.shuDamageTaken(d.effLevel(NenSkill.SHU));
    }

    // ---- mining speed: Shu multiplies the tool's break speed (diamond pickaxe 8 -> 50 at Shu 100); real Efficiency is multiplied too ----
    /** Break-speed multiplier Shu gives the tool in hand on this block, or 1 (not damageable, or not effective on the block, like Efficiency in vanilla). */
    public static float miningMult(Player p, net.minecraft.world.level.block.state.BlockState state, int shuLevel) {
        ItemStack tool = p.getMainHandItem();
        if (tool.isEmpty() || !tool.isDamageableItem() || tool.getDestroySpeed(state) <= 1f) return 1f;
        return Tuning.shuMiningMult(shuLevel);
    }

    /** Runs on both sides: the client needs the same speed or its own crack animation would lag behind the server's. */
    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed e) {
        Player p = e.getEntity();
        int lvl;
        if (p.level().isClientSide) {
            if (!ClientAddonState.shu) return;
            lvl = Vows.effLevel(p, NenSkill.SHU, ClientAddonState.level[NenSkill.SHU.ordinal()]); // same effective level the server uses
        } else {
            if (!(p instanceof ServerPlayer sp)) return;
            NenAddonData d = NenAddonData.peek(sp);
            Combat c = Combat.get(sp);
            if (d == null || !d.shu || c == null || !c.hasNenUnlocked()) return;
            lvl = d.effLevel(NenSkill.SHU);
        }
        float m = miningMult(p, e.getState(), lvl);
        if (m != 1f) e.setNewSpeed(e.getNewSpeed() * m);
    }

    /** Mining with Shu on trains it (same 0.5 xp a weapon hit gives), only for blocks the tool is actually effective on. */
    @SubscribeEvent
    public static void onBlockBroken(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer sp)) return;
        ItemStack tool = sp.getMainHandItem();
        if (tool.isEmpty() || !tool.isDamageableItem() || tool.getDestroySpeed(e.getState()) <= 1f) return;
        NenAddonData d = NenAddonData.peek(sp);
        Combat c = Combat.get(sp);
        if (d != null && d.shu && c != null && c.hasNenUnlocked()) d.addXp(NenSkill.SHU, 0.5f, c);
    }

    // ---- durability: each point of durability the held item loses is given back with a chance equal to Shu's save share (see Tuning.shuDurabilitySave) ----
    private static final class Seen {
        Item item;
        int slot = -1;
        int damage;
    }

    private static final Map<Player, Seen> SEEN = new WeakHashMap<>();

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer sp)) return;
        Seen s = SEEN.computeIfAbsent(sp, k -> new Seen());
        ItemStack stack = sp.getMainHandItem();
        int slot = sp.getInventory().selected;
        if (stack.isEmpty() || !stack.isDamageableItem()) { // any coated tool or weapon, not only weapons
            s.item = null;
            return;
        }
        int now = stack.getDamageValue();
        if (s.item == stack.getItem() && s.slot == slot && now > s.damage) {
            NenAddonData d = NenAddonData.peek(sp);
            Combat c = Combat.get(sp);
            if (d != null && d.shu && c != null && c.hasNenUnlocked()) {
                float save = Tuning.shuDurabilitySave(d.effLevel(NenSkill.SHU), stack.getMaxDamage());
                int lost = now - s.damage;
                int kept = 0;
                for (int i = 0; i < lost; i++) if (sp.getRandom().nextFloat() >= save) kept++;
                now = s.damage + kept;
                stack.setDamageValue(now);
            }
        }
        s.item = stack.getItem();
        s.slot = slot;
        s.damage = now;
    }
}
