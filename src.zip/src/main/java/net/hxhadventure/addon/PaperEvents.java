package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks for {@link PaperManipulation}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PaperEvents {
    private PaperEvents() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) PaperManipulation.serverTick(ServerLifecycleHooks.getCurrentServer());
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        PaperManipulation.onDeath(e.getEntity());
        if (e.getEntity() instanceof ServerPlayer sp) PaperManipulation.clear(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) PaperManipulation.clear(sp);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        PaperManipulation.reset();
    }
}
