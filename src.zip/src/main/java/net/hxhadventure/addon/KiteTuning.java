package net.hxhadventure.addon;

import net.hxhadventure.abilities.Combat;

/**
 * Every number that defines the Kite NPC's Nen, in one place. Kite is a level 100 Nen user with 90 in every skill.
 * (His weapon numbers are in {@link CrazySlotsTuning}.)
 */
public final class KiteTuning {
    private KiteTuning() {}

    // ---- levels: level 100, and 90 in everything ----
    public static final int LEVEL = 100;
    public static final int HATSU_LEVEL = 90;
    public static final int TEN_LEVEL = 90;
    public static final int ZETSU_LEVEL = 90;
    public static final int KEN_LEVEL = 90;
    public static final int REN_LEVEL = 90;
    public static final int EN_LEVEL = 90;
    public static final int GYO_LEVEL = 90;
    public static final int IN_LEVEL = 90;
    public static final int NEN_TYPE = Combat.NEN_CONJURATION; // Kite is a Conjurer (Crazy Slots)

    /** The level of a Nen skill for Kite, for anything that wants to compare it with a player's (En vs In, Gyo, ...). */
    public static int skillLevel(NenSkill s) {
        return switch (s) {
            case TEN -> TEN_LEVEL;
            case REN -> REN_LEVEL;
            case EN -> EN_LEVEL;
            case GYO -> GYO_LEVEL;
            case IN -> IN_LEVEL;
            case ZETSU -> ZETSU_LEVEL;
            case HATSU -> HATSU_LEVEL;
            default -> 1;
        };
    }
}
