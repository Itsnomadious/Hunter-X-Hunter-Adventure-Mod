package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.entity.ModEntities;
import net.hxhadventure.entity.custom.AuraEntity;
import net.hxhadventure.utils.AllianceUtils;
import org.joml.Vector3f;

/**
 * Bungee Barrier (Bungee Gum, Z menu). The user forms a wide, rubbery shield in front of them. Every projectile that touches it (arrows,
 * tridents, thrown items, pearls...) sticks in the gum and is held there, following the shield as the user turns. Press Z again (or wait
 * {@link Tuning#BARRIER_MAX_TICKS} ticks) and the gum lets go: every caught projectile is fired back, at whoever shot it if they are in range,
 * otherwise at the nearest enemy, otherwise straight ahead, a little faster than it came.
 * The user drops into a wide stance, brings their hands together in front of the chest and pulls them apart vertically (right up, left down) while an
 * aura formed between them is stretched out like dough, and holds that pose until released ({@link BarrierPose}, {@code BarrierFx}); the user is not put
 * into Ren. The catch area itself is the same as before.
 * Fireballs and other self-accelerating projectiles (AbstractHurtingProjectile) pass through: their own thrust would fight the gum.
 */
public final class BungeeBarrier {
    private BungeeBarrier() {}

    public static final String ID = "gum_barrier";
    private static final String NAME = "Bungee Barrier";

    private static final DustParticleOptions PINK = new DustParticleOptions(new Vector3f(0.92f, 0.42f, 0.84f), 1.3f);
    private static final DustParticleOptions PINK_DARK = new DustParticleOptions(new Vector3f(0.78f, 0.25f, 0.68f), 1.0f);

    /** A projectile held in the gum: where it sits in the shield's own frame, and how fast it was going. */
    private static final class Caught {
        UUID id;
        double du;   // sideways, along the shield
        double dy;   // up, from the shield's middle
        double dn;   // thickness: which face it stuck to
        double speed;
    }

    private static final class Shield {
        int age;
        final List<Caught> caught = new ArrayList<>();
        Vec3 normal = new Vec3(0, 0, 1);
        Vec3 center = Vec3.ZERO;
        final List<AuraEntity> hands = new ArrayList<>();   // the two small Ren-style auras, one at each hand
    }

    private static final Map<UUID, Shield> SHIELDS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> READY_AT = new ConcurrentHashMap<>();

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(ID, BungeeBarrier::use);
    }

    /** Z: raise the barrier; Z again: let go and fire back everything it caught. */
    public static void use(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!BungeeGum.canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Bungee Gum"), true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.BARRIER_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cBungee Barrier unlocks at Level " + Tuning.BARRIER_MIN_LEVEL), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        Shield s = SHIELDS.get(sp.getUUID());
        if (s != null) {
            release(sp, s, level, true);
            return;
        }
        long now = level.getGameTime();
        if (ChainManager.onCooldown(sp, NAME, (int) Math.max(0, READY_AT.getOrDefault(sp.getUUID(), 0L) - now))) return;
        if (c.getCurrentEnergy() < Tuning.BARRIER_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.BARRIER_COST);
        Shield n = new Shield();
        place(sp, n);
        spawnHandAuras(sp, level, n);
        SHIELDS.put(sp.getUUID(), n);
        level.playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_PLACE, SoundSource.PLAYERS, 1.5f, 0.7f);
        level.playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_STEP, SoundSource.PLAYERS, 1.2f, 1.2f);
        sp.displayClientMessage(Component.literal("\u00a7dBungee Barrier \u00a77(Z again to let go and fire back what it caught)"), true);
    }

    /** The effect Ren is made of (the player's own colour, drawn by the normal aura renderer): a flame at each hand and the dough stretched between them. Their size and place follow BarrierPose. */
    private static void spawnHandAuras(ServerPlayer sp, ServerLevel level, Shield s) {
        for (int mode : new int[] {BarrierPose.HAND_RIGHT, BarrierPose.HAND_LEFT, BarrierPose.DOUGH}) {
            AuraEntity a = new AuraEntity(ModEntities.AURA_ENTITY.get(), level);
            a.setPos(sp.getX(), sp.getY(), sp.getZ());
            a.setOwner(sp);
            a.setHand(mode);
            a.setAuraColorIndex(AbilityRegistry.getOrCreatePlayerAuraColor(sp) - 1);
            a.setAuraType(0);
            level.addFreshEntity(a);
            s.hands.add(a);
        }
    }

    private static void dropAura(Shield s) {
        for (AuraEntity a : s.hands) {
            if (!a.isRemoved()) a.discard();
        }
        s.hands.clear();
    }

    /** The shield stands in front of the user, facing where they face, at chest height. */
    private static void place(ServerPlayer sp, Shield s) {
        Vec3 look = sp.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        s.normal = flat.lengthSqr() < 1.0e-4 ? s.normal : flat.normalize();
        s.center = new Vec3(sp.getX(), sp.getY() + sp.getBbHeight() * 0.5, sp.getZ()).add(s.normal.scale(Tuning.BARRIER_DISTANCE));
    }

    private static Vec3 sideways(Shield s) {
        return new Vec3(-s.normal.z, 0, s.normal.x);
    }

    // =====================================================================================================
    // per tick
    // =====================================================================================================

    public static void tick(ServerPlayer sp) {
        Shield s = SHIELDS.get(sp.getUUID());
        if (s == null) return;
        Combat c = Combat.get(sp);
        if (c == null || !BungeeGum.canUse(c) || !sp.isAlive() || ExtrasHooks.hatsuForced(sp) || !(sp.level() instanceof ServerLevel level)) {
            drop(sp, s);
            return;
        }
        s.age++;
        place(sp, s);
        holdCaught(s, level);
        catchNew(sp, s, level);
        if (s.age >= Tuning.BARRIER_MAX_TICKS) release(sp, s, level, true);
    }

    private static Vec3 worldPoint(Shield s, double du, double dy, double dn) {
        return s.center.add(sideways(s).scale(du)).add(0, dy, 0).add(s.normal.scale(dn));
    }

    /** Caught projectiles stay pinned in the shield, wherever it moves. */
    private static void holdCaught(Shield s, ServerLevel level) {
        Iterator<Caught> it = s.caught.iterator();
        while (it.hasNext()) {
            Caught k = it.next();
            Entity e = level.getEntity(k.id);
            if (!(e instanceof Projectile p) || !p.isAlive()) {
                it.remove();
                continue;
            }
            p.setPos(worldPoint(s, k.du, k.dy, k.dn));
            p.setDeltaMovement(Vec3.ZERO);
            p.setNoGravity(true);
            p.hasImpulse = true;
        }
    }

    private static boolean catchable(ServerPlayer sp, Entity e) {
        if (!(e instanceof Projectile p) || e instanceof AbstractHurtingProjectile || e instanceof FishingHook) return false;
        if (!e.isAlive() || e.isRemoved()) return false;
        Entity owner = p.getOwner();
        return owner != sp && !(owner != null && AllianceUtils.isAlly(owner, sp));
    }

    private static void catchNew(ServerPlayer sp, Shield s, ServerLevel level) {
        if (s.caught.size() >= Tuning.BARRIER_MAX_CAUGHT) return;
        double reach = Tuning.BARRIER_HALF_WIDTH + 6.0;
        AABB area = new AABB(s.center, s.center).inflate(reach);
        Vec3 side = sideways(s);
        for (Projectile p : level.getEntitiesOfClass(Projectile.class, area, e -> catchable(sp, e))) {
            if (s.caught.size() >= Tuning.BARRIER_MAX_CAUGHT) break;
            if (isCaught(s, p)) continue;
            Vec3 pos = p.position();
            Vec3 vel = p.getDeltaMovement();
            Vec3 rel0 = pos.subtract(s.center);
            Vec3 rel1 = pos.add(vel).subtract(s.center);
            double n0 = rel0.dot(s.normal);
            double n1 = rel1.dot(s.normal);
            double half = Tuning.BARRIER_THICKNESS;
            // does its path (this tick's step) pass through the slab?
            boolean through = (n0 > half && n1 < -half) || (n0 < -half && n1 > half)
                || Math.abs(n0) <= half || Math.abs(n1) <= half;
            if (!through) continue;
            // where along the step it meets the middle of the slab (or just where it is, if it is already inside)
            double t = Math.abs(n0) <= half ? 0.0 : Math.min(1.0, Math.max(0.0, n0 / (n0 - n1)));
            Vec3 hitPoint = pos.add(vel.scale(t));
            Vec3 rel = hitPoint.subtract(s.center);
            double du = rel.dot(side);
            double dy = rel.y;
            if (Math.abs(du) > Tuning.BARRIER_HALF_WIDTH || Math.abs(dy) > Tuning.BARRIER_HALF_HEIGHT) continue;
            Caught k = new Caught();
            k.id = p.getUUID();
            k.du = du;
            k.dy = dy;
            k.dn = n0 >= 0 ? 0.25 : -0.25; // sticks to the face it came in on
            k.speed = vel.length();
            s.caught.add(k);
            p.setPos(worldPoint(s, k.du, k.dy, k.dn));
            p.setDeltaMovement(Vec3.ZERO);
            p.setNoGravity(true);
            p.hasImpulse = true;
            level.sendParticles(PINK, p.getX(), p.getY(), p.getZ(), 10, 0.25, 0.25, 0.25, 0.03);
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.SLIME_BLOCK_HIT, SoundSource.PLAYERS, 1.2f, 1.0f);
        }
    }

    private static boolean isCaught(Shield s, Entity e) {
        for (Caught k : s.caught) if (k.id.equals(e.getUUID())) return true;
        return false;
    }

    // =====================================================================================================
    // letting go
    // =====================================================================================================

    /** The gum lets go: every caught projectile goes back at an enemy. */
    private static void release(ServerPlayer sp, Shield s, ServerLevel level, boolean withCooldown) {
        SHIELDS.remove(sp.getUUID());
        dropAura(s);
        int n = 0;
        for (Caught k : s.caught) {
            Entity e = level.getEntity(k.id);
            if (!(e instanceof Projectile p) || !p.isAlive()) continue;
            fireBack(sp, p, k, level);
            n++;
        }
        level.playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_BREAK, SoundSource.PLAYERS, 1.5f, 0.9f);
        if (n > 0) level.playSound(null, sp.blockPosition(), SoundEvents.CROSSBOW_SHOOT, SoundSource.PLAYERS, 1.0f, 0.8f);
        s.caught.clear();
        if (withCooldown) {
            READY_AT.put(sp.getUUID(), level.getGameTime() + Tuning.BARRIER_COOLDOWN_TICKS);
            ChainManager.startCooldown(sp, NAME, Tuning.BARRIER_COOLDOWN_TICKS);
        }
        sp.displayClientMessage(Component.literal(n > 0 ? "\u00a7dBungee Barrier: fired back " + n : "\u00a77Bungee Barrier: released"), true);
    }

    private static void fireBack(ServerPlayer sp, Projectile p, Caught k, ServerLevel level) {
        LivingEntity target = null;
        if (p.getOwner() instanceof LivingEntity shooter && shooter.isAlive() && shooter != sp && !AllianceUtils.isAlly(shooter, sp)
            && shooter.distanceToSqr(p) <= Tuning.BARRIER_RETURN_RANGE * Tuning.BARRIER_RETURN_RANGE) {
            target = shooter; // back at whoever shot it
        }
        if (target == null) target = nearestFoe(sp, p, level);
        Vec3 from = p.position();
        Vec3 dir;
        if (target != null) {
            dir = BungeeGum.centerOf(target).subtract(from);
            dir = dir.lengthSqr() < 1.0e-4 ? sp.getLookAngle() : dir.normalize();
        } else {
            dir = sp.getLookAngle().normalize();
        }
        double speed = Math.min(4.0, Math.max(Tuning.BARRIER_RETURN_SPEED, k.speed * 1.5));
        p.setOwner(sp); // it is the user's projectile now
        p.setNoGravity(true);
        p.shoot(dir.x, dir.y, dir.z, (float) speed, 0.0f);
        p.hasImpulse = true;
        p.hurtMarked = true;
        level.sendParticles(PINK, from.x, from.y, from.z, 6, 0.2, 0.2, 0.2, 0.02);
    }

    private static LivingEntity nearestFoe(ServerPlayer sp, Entity from, ServerLevel level) {
        LivingEntity best = null;
        double bestD = Tuning.BARRIER_RETURN_RANGE * Tuning.BARRIER_RETURN_RANGE;
        AABB box = from.getBoundingBox().inflate(Tuning.BARRIER_RETURN_RANGE);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (e == sp || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, sp)) continue;
            if (e instanceof Player p && (p.isCreative() || p.isSpectator())) continue;
            double d = e.distanceToSqr(from);
            if (d < bestD) {
                bestD = d;
                best = e;
            }
        }
        return best;
    }

    /** Interrupted (death, Nen lost, forced into Zetsu): the shield goes and whatever it holds simply falls free. */
    private static void drop(ServerPlayer sp, Shield s) {
        SHIELDS.remove(sp.getUUID());
        dropAura(s);
        if (sp.level() instanceof ServerLevel level) {
            for (Caught k : s.caught) {
                if (level.getEntity(k.id) instanceof Projectile p) p.setNoGravity(false);
            }
        }
        s.caught.clear();
    }

    /** Death / logout / Nen lost. */
    public static void clear(Player p) {
        Shield s = SHIELDS.remove(p.getUUID());
        READY_AT.remove(p.getUUID());
        if (s != null) dropAura(s);
        if (s != null && p.level() instanceof ServerLevel level) {
            for (Caught k : s.caught) {
                if (level.getEntity(k.id) instanceof Projectile pr) pr.setNoGravity(false);
            }
        }
    }
}
