package net.hxhadventure.addon;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;

/** The Katana, drawn: an iron sword (same damage, speed and durability). Right-click sheathes it. Nothing else. */
public class KatanaItem extends SwordItem {
    /** An iron sword's durability, shared with the sheathed form so no wear is lost when swapping. */
    public static final int DURABILITY = Tiers.IRON.getUses();

    public KatanaItem(Item.Properties props) {
        super(Tiers.IRON, 3, -2.4F, props); // the same stats as an iron sword
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) swap(player, hand, stack, KatanaItems.KATANA_SHEATHED);
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }

    /** Replaces the held stack with the other form of the Katana, keeping its NBT (enchantments, damage, name...). */
    static void swap(Player player, InteractionHand hand, ItemStack old, Item newItem) {
        ItemStack fresh = new ItemStack(newItem);
        if (old.getTag() != null) fresh.setTag(old.getTag().copy());
        player.setItemInHand(hand, fresh);
    }
}
