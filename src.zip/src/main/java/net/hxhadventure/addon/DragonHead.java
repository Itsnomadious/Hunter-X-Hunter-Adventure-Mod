package net.hxhadventure.addon;

import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketPillarFx;

/**
 * Zeno's Dragon Head (second ability of Hatsu kit 12, Emitters). Press Z and keep HOLDING it for 3 seconds while the aura
 * gathers; release to fire a golden beam into the sky and call the dragon (see DragonHeadEntity), which you start out riding.
 * Press Z again with it out to dismiss it. One dragon per user; it stays until it is dismissed.
 */
public final class DragonHead {
    private DragonHead() {}

    public static final String ID = "dragon_head";
    public static final String DIVE_ID = "dragon_dive";

    private static final class Charge {
        long start;
        boolean release;
    }

    private static final Map<UUID, Charge> CHARGING = new ConcurrentHashMap<>();
    private static final Map<UUID, UUID> DRAGONS = new ConcurrentHashMap<>();   // owner -> dragon entity
    private static final Map<UUID, Long> READY_AT = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> DIVE_READY_AT = new ConcurrentHashMap<>();

    public static String[] extend(String[] base, Combat c) {
        if (!AuraBlast.canUse(c) || c.getHatsuLevel() < Tuning.DRAGON_MIN_LEVEL) return base;
        String[] out = Arrays.copyOf(base, base.length + 2);
        out[base.length] = ID;
        out[base.length + 1] = DIVE_ID;
        return out;
    }

    private static DragonHeadEntity find(ServerPlayer sp) {
        UUID id = DRAGONS.get(sp.getUUID());
        if (id == null) return null;
        Entity e = sp.serverLevel().getEntity(id);
        if (e instanceof DragonHeadEntity d && d.isAlive()) return d;
        DRAGONS.remove(sp.getUUID());
        return null;
    }

    /** Z pressed. */
    public static void begin(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!AuraBlast.canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Dragon's Head"), true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.DRAGON_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cDragon Head unlocks at Level " + Tuning.DRAGON_MIN_LEVEL), true);
            return;
        }
        DragonHeadEntity existing = find(sp);
        if (existing != null) { // pressing it with the dragon out sends it away
            if (existing.isDiving()) return; // mid Dragon Dive: it cannot be called off
            existing.dismiss();
            DRAGONS.remove(sp.getUUID());
            READY_AT.put(sp.getUUID(), sp.level().getGameTime() + Tuning.DRAGON_COOLDOWN_TICKS);
            ChainManager.startCooldown(sp, "Dragon Head", Tuning.DRAGON_COOLDOWN_TICKS);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.5f, 0.6f);
            sp.displayClientMessage(Component.literal("\u00a76Dragon Head dismissed"), true);
            return;
        }
        if (CHARGING.containsKey(sp.getUUID())) return;
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        long now = sp.level().getGameTime();
        if (ChainManager.onCooldown(sp, "Dragon Head", (int) Math.max(0, READY_AT.getOrDefault(sp.getUUID(), 0L) - now))) return;
        if (c.getCurrentEnergy() < Tuning.DRAGON_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        Charge ch = new Charge();
        ch.start = now;
        CHARGING.put(sp.getUUID(), ch);
        Prayer.chargeBegan(sp, ID, null);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.2f, 0.7f);
    }

    /** Z pressed on Dragon Dive: the summoned dragon coils into rings, dissipates, and a rain of golden arrows follows. */
    public static void dive(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!AuraBlast.canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Dragon's Head"), true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.DRAGON_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cDragon Dive unlocks at Level " + Tuning.DRAGON_MIN_LEVEL), true);
            return;
        }
        DragonHeadEntity dragon = find(sp);
        if (dragon == null) {
            sp.displayClientMessage(Component.literal("\u00a7cSummon the Dragon Head first"), true);
            return;
        }
        if (dragon.isDiving()) return;
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        long now = sp.level().getGameTime();
        if (ChainManager.onCooldown(sp, "Dragon Dive", (int) Math.max(0, DIVE_READY_AT.getOrDefault(sp.getUUID(), 0L) - now))) return;
        if (c.getCurrentEnergy() < Tuning.DIVE_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.DIVE_COST);
        DIVE_READY_AT.put(sp.getUUID(), now + Tuning.DIVE_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Dragon Dive", Tuning.DIVE_COOLDOWN_TICKS);
        // the dragon is spent by the dive: it can be summoned again once the dive is over and the usual cooldown has run
        int headCd = Tuning.DIVE_RING_TICKS + Tuning.DIVE_DISSIPATE_TICKS + Tuning.DRAGON_COOLDOWN_TICKS;
        READY_AT.put(sp.getUUID(), now + headCd);
        ChainManager.startCooldown(sp, "Dragon Head", headCd);
        dragon.startDive();
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true); // the default punch swing (first person too)
        sp.displayClientMessage(Component.literal("\u00a76Dragon Dive"), true);
    }

    public static boolean isCharging(Player p) {
        return p != null && CHARGING.containsKey(p.getUUID());
    }

    /** Called by the client's Z-held packet: letting go is what fires the beam. */
    public static void setZHeld(ServerPlayer sp, boolean held) {
        if (held) return;
        Charge ch = CHARGING.get(sp.getUUID());
        if (ch != null) ch.release = true;
    }

    public static void tick(ServerPlayer sp) {
        Charge ch = CHARGING.get(sp.getUUID());
        if (ch == null) return;
        Combat c = Combat.get(sp);
        if (c == null || !AuraBlast.canUse(c) || !sp.isAlive() || ExtrasHooks.hatsuForced(sp)
            || !(sp.level() instanceof ServerLevel level)) {
            CHARGING.remove(sp.getUUID());
            return;
        }
        long elapsed = level.getGameTime() - ch.start;
        if (ch.release) {
            CHARGING.remove(sp.getUUID());
            if (elapsed >= Tuning.DRAGON_CHARGE_TICKS) summon(sp, c, level);
            else sp.displayClientMessage(Component.literal("\u00a77Dragon Head: the aura scattered (hold Z for 3 seconds)"), true);
            return;
        }
        // golden aura gathers around the user, tighter and brighter as the charge builds
        double f = Math.min(1.0, elapsed / (double) Tuning.DRAGON_CHARGE_TICKS);
        for (int i = 0; i < 2 + (int) (4 * f); i++) {
            double a = level.random.nextDouble() * Math.PI * 2, r = 1.8 - 1.0 * f;
            level.sendParticles(ParticleTypes.WAX_ON, sp.getX() + Math.cos(a) * r, sp.getY() + level.random.nextDouble() * 2.0,
                sp.getZ() + Math.sin(a) * r, 1, 0, 0.05, 0, 0.0);
        }
        if (elapsed % 5 == 0) {
            String bar = elapsed >= Tuning.DRAGON_CHARGE_TICKS
                ? "\u00a76Dragon Head: ready, release Z"
                : String.format(java.util.Locale.ROOT, "\u00a76Dragon Head: %.1f / %.1fs", elapsed / 20.0, Tuning.DRAGON_CHARGE_TICKS / 20.0);
            sp.displayClientMessage(Component.literal(bar), true);
        }
    }

    private static void summon(ServerPlayer sp, Combat c, ServerLevel level) {
        if (c.getCurrentEnergy() < Tuning.DRAGON_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.DRAGON_COST);
        Prayer.attackOut(sp, ID);
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true); // the default punch swing (first person too)
        Vec3 at = sp.position();
        AddonNetwork.sendToNear(new PacketPillarFx(at, Tuning.DRAGON_PILLAR_TICKS), level, at, 200);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 4.0f, 1.4f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.ENDER_DRAGON_GROWL, SoundSource.PLAYERS, 3.0f, 0.8f);

        DragonHeadEntity dragon = new DragonHeadEntity(HxHEntities.DRAGON_HEAD.get(), level);
        dragon.setOwner(sp.getUUID());
        dragon.moveTo(at.x, at.y + 0.5, at.z, sp.getYRot(), 0f);
        level.addFreshEntity(dragon);
        DRAGONS.put(sp.getUUID(), dragon.getUUID());
        sp.startRiding(dragon, true); // the user starts out in the driver's seat
        sp.displayClientMessage(Component.literal("\u00a76Dragon Head"), true);
        Vows.afterCharge(sp, ID);
    }

    /** Death / logout: the dragon goes with its owner. */
    public static void clear(Player p) {
        CHARGING.remove(p.getUUID());
        READY_AT.remove(p.getUUID());
        DIVE_READY_AT.remove(p.getUUID());
        UUID id = DRAGONS.remove(p.getUUID());
        if (id != null && p.level() instanceof ServerLevel l && l.getEntity(id) instanceof DragonHeadEntity d) d.dismiss();
    }
}
