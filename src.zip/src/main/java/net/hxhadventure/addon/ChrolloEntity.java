package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.Tags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Chrollo, a Specialist Nen user (NPC) who fights with Skill Hunter. He leaves people alone until they hurt him; then he fights like a
 * player of his levels would (Ten always on, Ken as his fighting stance, Attack / Barrage /
 * Strong attack) and opens his book: The Sun and Moon marks the
 * target, then the mark explodes. His numbers are all in {@link ChrolloTuning}, a few levels below Hisoka's.
 */
public class ChrolloEntity extends PathfinderMob implements GeoEntity, NpcMelee.Host, NpcFightGoal.FightNpc {

    // ---- synced to the client: which aura forms to draw ----
    private static final EntityDataAccessor<Integer> NEN_FLAGS = SynchedEntityData.defineId(ChrolloEntity.class, EntityDataSerializers.INT);
    public static final int F_TEN = 1, F_KEN = 4;
    /** Bandit's Secret is out (drawn in front of him). */
    private static final EntityDataAccessor<Boolean> BOOK_OUT = SynchedEntityData.defineId(ChrolloEntity.class, EntityDataSerializers.BOOLEAN);
    /** Convert Hands: the Bystander skin he is wearing (0-4), -1 = his own. */
    private static final EntityDataAccessor<Integer> DISGUISE = SynchedEntityData.defineId(ChrolloEntity.class, EntityDataSerializers.INT);

    private static final int NEN_TYPE = ChrolloTuning.NEN_TYPE;
    private static final java.util.UUID MOD_TEN_ARMOR = UUID.fromString("b2000000-0000-4000-8000-000000000001");
    private static final java.util.UUID MOD_TEN_TOUGH = UUID.fromString("b2000000-0000-4000-8000-000000000002");
    private static final java.util.UUID MOD_AFF_SPEED = UUID.fromString("b2000000-0000-4000-8000-000000000004");
    private static final java.util.UUID MOD_ATTACK_SLOW = UUID.fromString("b2000000-0000-4000-8000-000000000005");
    private static final java.util.UUID MOD_TEN_SPEED = UUID.fromString("b2000000-0000-4000-8000-000000000006");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    // ---- aura / Nen ----
    private enum Stance { NONE, KEN }
    private final float maxAura = ChrolloTuning.maxAura();
    private float aura = maxAura;
    private boolean exhausted;
    private boolean ten, ken;
    private Stance stance = Stance.NONE;
    private int formCooldown;
    private int lastHitTick = -1000;
    private int idleTicks;
    private boolean wasFighting;

    // ---- attacks ----
    private final NpcMelee melee = new NpcMelee(this, this, meleeCfg());
    private final float meleeGovern = NpcBalance.governedMelee(profile());

    static MeleeCore.Cfg meleeCfg() {
        return MeleeCore.Cfg.of(ChrolloTuning.PUNCH_DAMAGE, ChrolloTuning.PUNCH_RANGE, ChrolloTuning.STRONG_DAMAGE, ChrolloTuning.STRONG_RANGE, ChrolloTuning.STRONG_KNOCKBACK,
            ChrolloTuning.STRONG_CHARGE_TICKS, ChrolloTuning.STRONG_MAX_HOLD_TICKS, ChrolloTuning.STRONG_COOLDOWN_TICKS,
            ChrolloTuning.BARRAGE_DAMAGE, ChrolloTuning.BARRAGE_TICKS, ChrolloTuning.BARRAGE_HIT_GAP, ChrolloTuning.BARRAGE_COOLDOWN_TICKS,
            ChrolloTuning.PUNCH_WEIGHT_BARRAGE, ChrolloTuning.PUNCH_WEIGHT_STRONG);
    }

    /** What the balance model (NpcBalance) knows about this NPC. */
    static NpcBalance.Profile profile() {
        return new NpcBalance.Profile("chrollo", ChrolloTuning.MAX_HEALTH, ChrolloTuning.HATSU_LEVEL, Math.min(NpcFeelTuning.PLAYER_CAP, ChrolloTuning.TEN_LEVEL))
            .affinity(Affinity.dealt(NEN_TYPE), Affinity.taken(NEN_TYPE)).ren(0).regen(ChrolloTuning.HEAL_PER_SECOND).cfg(meleeCfg());
    }
    private boolean punchOne = true;

    private final Map<UUID, Long> foes = new HashMap<>();

    public ChrolloEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 50;
        this.addTag("phantom_troupe"); // a member of the Phantom Troupe (Vows.isTroupe also checks the type itself)
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, NpcBalance.governedHealth(profile()))
            .add(Attributes.MOVEMENT_SPEED, ChrolloTuning.BASE_SPEED)
            .add(Attributes.ATTACK_DAMAGE, 5.0)
            .add(Attributes.FOLLOW_RANGE, ChrolloTuning.FOLLOW_RANGE)
            .add(Attributes.KNOCKBACK_RESISTANCE, ChrolloTuning.KNOCKBACK_RESISTANCE);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(NEN_FLAGS, 0);
        this.entityData.define(BOOK_OUT, false);
        this.entityData.define(DISGUISE, -1);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new NpcFightGoal(this, this, t -> false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        // no target goals on purpose: he only ever fights what hurt him (see hurt())
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        this.aura = maxAura;
        this.setPersistenceRequired();
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("ChrolloAura", aura);
        tag.putBoolean("ChrolloExhausted", exhausted);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("ChrolloAura")) aura = Math.max(0f, Math.min(maxAura, tag.getFloat("ChrolloAura")));
        exhausted = tag.getBoolean("ChrolloExhausted");
    }

    // =====================================================================================================
    // queries used by the goal, the gum and the damage events
    // =====================================================================================================

    public float aura() { return aura; }

    public float maxAura() { return maxAura; }

    public boolean isExhausted() { return exhausted; }

    public boolean isAttacking() { return melee.isAttacking(); }

    /** Nen can be used: he has aura left and nothing (Chain Jail, Forced Zetsu) is holding it down. */
    public boolean canUseNen() {
        return !exhausted && !ExtrasHooks.hatsuForced(this);
    }

    public int nenFlags() { return this.entityData.get(NEN_FLAGS); }

    /** HxHAdventure's spirit bonus for his Hatsu level: 1 + 0.1 sqrt(L). Multiplies his punches. */
    public float spiritBonus() {
        float s = (float) Math.sqrt(ChrolloTuning.HATSU_LEVEL);
        float m = 1.0f + s * 0.1f;
        return m;
    }

    /** Multiplier on damage he deals (the same pieces a player's gets: affinity and the aura form). */
    public float outgoingMult() {
        return outgoingMult(null);
    }

    /** Same as a player's: Ten / Ken scale melee hits, Hatsu hits (dealt through Vows.hatsuHurt) ignore them. */
    public float outgoingMult(net.minecraft.world.damagesource.DamageSource src) {
        float m = Affinity.dealt(NEN_TYPE);
        if (src == null || !Vows.isHatsuHit(src)) m *= NpcAura.outgoing(ChrolloTuning.TEN_LEVEL, ten, false, ken, false);
        return m;
    }

    /** Multiplier on damage he takes (affinity and the aura form; Ten's armour works through his armour attribute). */
    public float incomingMult(DamageSource src) {
        float m = Affinity.taken(NEN_TYPE);
        if (src.is(DamageTypes.LIGHTNING_BOLT)) m *= 1f - Affinity.lightningReduction(NEN_TYPE);
        if (src.is(DamageTypes.FALL)) m *= 1f - Affinity.fallReduction(NEN_TYPE);
        if (Affinity.isStatusDamage(src)) m *= 1f - Affinity.statusReduction(NEN_TYPE);
        m *= NpcAura.incoming(ChrolloTuning.TEN_LEVEL, ten, false, ken, false); // durability, the same as a player's
        return m;
    }

    /** Pays for an ability out of his aura (Transmuters pay less). False, and nothing paid, if he cannot afford it. */
    boolean payAura(float cost) {
        if (!canUseNen()) return false;
        float c = cost * (1f - Math.min(0.5f, Affinity.abilityRefund(NEN_TYPE)));
        if (aura < c) return false;
        aura -= c;
        return true;
    }

    /** Whether something counts as an enemy: what he is fighting, or anything that hurt him lately. Gum and area hits only touch these. */
    public boolean isFoe(Entity e) {
        if (!(e instanceof LivingEntity le) || e == this || !le.isAlive() || e instanceof ArmorStand || e instanceof ChrolloEntity || e instanceof BystanderEntity) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        if (e == getTarget()) return true;
        Long t = foes.get(e.getUUID());
        return t != null && level().getGameTime() - t <= ChrolloTuning.FOE_MEMORY_TICKS;
    }

    private void noteFoe(LivingEntity e) {
        foes.put(e.getUUID(), level().getGameTime());
        if (foes.size() > 32) {
            long now = level().getGameTime();
            foes.values().removeIf(t -> now - t > ChrolloTuning.FOE_MEMORY_TICKS);
        }
    }

    private boolean validTarget(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof ArmorStand || e instanceof ChrolloEntity || e instanceof BystanderEntity) return false;
        return !(e instanceof Player p && (p.isCreative() || p.isSpectator()));
    }

    // =====================================================================================================
    // being hurt: he fights back
    // =====================================================================================================

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide) {
            lastHitTick = tickCount;
            if (source.getEntity() instanceof LivingEntity attacker) provoke(attacker);
        }
        return hit;
    }

    /** Something attacked him (or one of his Bystanders): it becomes his enemy, and he conjures Bandit's Secret. */
    public void provoke(LivingEntity attacker) {
        if (level().isClientSide || !validTarget(attacker)) return;
        noteFoe(attacker);
        LivingEntity cur = getTarget();
        if (cur == null || !cur.isAlive() || distanceToSqr(cur) > 16.0) setTarget(attacker);
        bookIdleTicks = 0;
        if (level() instanceof ServerLevel sl) conjureBook(sl);
    }

    // =====================================================================================================
    // per tick (server)
    // =====================================================================================================

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !isAlive() || !(level() instanceof ServerLevel)) return;
        LivingEntity t = getTarget();
        if (t != null && (!t.isAlive() || t.level() != level() || distanceToSqr(t) > 96.0 * 96.0
            || (t instanceof Player p && (p.isCreative() || p.isSpectator())))) {
            setTarget(null);
            t = null;
        }
        boolean fighting = t != null;
        if (fighting) idleTicks = 0; else idleTicks++;
        if (!fighting && wasFighting) cancelAttack();
        wasFighting = fighting;

        tickNen(fighting, t);
        melee.tick(t, t != null && inReach(t), false);
        skillHunter(t);
        refreshModifiers();
        syncFlags();
    }

    // =====================================================================================================
    // Nen: the aura pool and the stances
    // =====================================================================================================

    private void tickNen(boolean fighting, @Nullable LivingEntity t) {
        if (formCooldown > 0) formCooldown--;

        // regeneration and upkeep, a twentieth of a second's worth every tick
        final float perTick = 1f / 20f;
        if (exhausted) {
            aura += (ChrolloTuning.BASE_REGEN + maxAura * ChrolloTuning.EXHAUST_REGEN_PCT) * perTick;
        } else {
            aura += (ten ? ChrolloTuning.tenRegenPerSecond() : ChrolloTuning.BASE_REGEN) * perTick;
            if (!fighting && idleTicks > ChrolloTuning.REST_DELAY_TICKS) aura += maxAura * ChrolloTuning.REST_REGEN_PCT * perTick;
            float eff = Math.min(0.5f, Affinity.efficiency(NEN_TYPE));
            if (ken) aura -= Tuning.KEN_UPKEEP * (1f - eff) * perTick;
            if (ten && tickCount % 20 == 0 && getHealth() < getMaxHealth() && tickCount - lastHitTick > 40) heal(ChrolloTuning.HEAL_PER_SECOND);
        }
        aura = Math.max(0f, Math.min(maxAura, aura));

        if (!exhausted && aura <= 0.01f) {
            runDry();
        } else if (exhausted && aura >= maxAura * ChrolloTuning.EXHAUST_RESUME_FRACTION) {
            exhausted = false;
            level().playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 0.8f, 1.4f);
        }

        // Chain Jail / Forced Zetsu hold everything down, like they do for a player
        boolean blocked = exhausted || ExtrasHooks.hatsuForced(this);
        ten = !blocked;
        if (blocked) {
            if (stance != Stance.NONE) setStance(Stance.NONE, true);
            return;
        }

        // Ken is his fighting stance (NPCs do not use Ren)
        Stance want = fighting ? Stance.KEN : Stance.NONE;
        if (want != stance && formCooldown <= 0) setStance(want, false);
    }

    private void runDry() {
        exhausted = true;
        aura = 0f;
        ten = false;
        setStance(Stance.NONE, true);
        clearMark();
        if (level() instanceof ServerLevel sl) {
            sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 1.0f, 0.7f);
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0, getZ(), 20, 0.4, 0.6, 0.4, 0.02);
        }
    }

    private void setStance(Stance s, boolean force) {
        if (s == stance) return;
        stance = s;
        formCooldown = ChrolloTuning.FORM_SWITCH_TICKS;
        ken = s == Stance.KEN;
        if (!(level() instanceof ServerLevel sl)) return;
        switch (s) {
            case KEN -> sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 0.8f, 1.2f);
            case NONE -> {
                if (!force) sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 0.4f, 1.5f);
            }
        }
    }

    private void syncFlags() {
        int f = (ten ? F_TEN : 0) | (ken ? F_KEN : 0);
        if (this.entityData.get(NEN_FLAGS) != f) this.entityData.set(NEN_FLAGS, f);
    }

    /** Ten and Ken speed, the Transmuter's speed and the slow of a punch in progress. */
    private void refreshModifiers() {
        updateAttackSlow(); // every tick: a punch's slow lasts nine
        if (tickCount % 5 != 0) return;
        // Ten's old armour / toughness and the old Ren speed are gone: one speed bonus, the player's (Ten, Ken x1)
        setMod(Attributes.MOVEMENT_SPEED, MOD_AFF_SPEED, Affinity.speedBonus(NEN_TYPE), AttributeModifier.Operation.MULTIPLY_TOTAL);        // Ten's movement speed, the same curve a player gets (Tuning.tenSpeedBonus), capped for NPCs
        setMod(Attributes.MOVEMENT_SPEED, MOD_TEN_SPEED, NpcAura.speedBonus(ChrolloTuning.TEN_LEVEL, ten, false, ken, false), AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    private void setMod(Attribute attr, UUID id, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = getAttribute(attr);
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(id);
        if (Math.abs(amount) < 1e-6) {
            if (cur != null) inst.removeModifier(id);
            return;
        }
        if (cur != null && Math.abs(cur.getAmount() - amount) < 1e-6) return;
        if (cur != null) inst.removeModifier(id);
        inst.addTransientModifier(new AttributeModifier(id, "Chrollo Nen", amount, op));
    }

    // =====================================================================================================
    // Attack / Barrage / Strong attack (Combat.java's moves, run by the NPC)
    // =====================================================================================================

    @Override
    public NpcMelee melee() { return melee; }

    /** Called by the combat goal every tick the target is within reach: picks the next move when free to. */
    @Override
    public void chooseAttack(LivingEntity t) {
        if (false) return;
        melee.choose(t);
    }

    @Override
    public boolean inReach(LivingEntity t) {
        return distanceTo(t) - t.getBbWidth() * 0.5 <= ChrolloTuning.REACH && Math.abs(t.getY() - getY()) < 2.5;
    }

    private void cancelAttack() {
        melee.cancel();
    }

    /** Spirit bonus (and the NPC's own boosts) x the fairness governor (NpcBalance). */
    @Override
    public float meleeScale() {
        return spiritBonus() * meleeGovern;
    }

    @Override
    public void swingAnim() {
        triggerPunchAnim();
    }

    void triggerPunchAnim() {
        triggerAnim("attack_controller", punchOne ? "punch1" : "punch2");
        punchOne = !punchOne;
    }

    private void updateAttackSlow() {
        setMod(Attributes.MOVEMENT_SPEED, MOD_ATTACK_SLOW, -melee.slow(), AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    // =====================================================================================================
    // Skill Hunter: Bandit's Secret (the book) and its pages. He has every page of the player's book except Ask:
    // Gallery Fake (Bystanders), Order Stamp, The Sun and Moon, Convert Hands and Black Voice.
    // =====================================================================================================

    private int stampCooldown = 100, markCooldown = 200, galleryCooldown, blackVoiceCooldown = 100, convertCooldown = 200;
    private int pageGcd, bookIdleTicks, disguiseTicks;

    // The Sun and Moon: one mark on his target, the opposite one on Bystanders near him
    private int markTicks;
    private Vec3 markPos;
    private UUID markTarget;
    private boolean markSun, nextSun = true;
    private final Map<UUID, Boolean> bystanderMarks = new HashMap<>(); // marked Bystander -> true when its mark is the Sun
    private final Map<UUID, Boolean> bystanderBrand = new HashMap<>(); // every Bystander is born marked: true = Sun, false = Moon
    private boolean nextBrandSun = true;

    private final List<UUID> bystanders = new ArrayList<>();
    private final Map<UUID, Long> puppets = new HashMap<>();           // Black Voice: controlled creature -> game time it is released

    public boolean isBookOut() { return this.entityData.get(BOOK_OUT); }

    /** Convert Hands is on: he wears a Bystander's skin. */
    public boolean isDisguised() { return this.entityData.get(DISGUISE) >= 0; }

    public int disguiseSkin() { return this.entityData.get(DISGUISE); }

    // ---- the book ----

    private void conjureBook(ServerLevel sl) {
        if (isBookOut()) return;
        this.entityData.set(BOOK_OUT, true);
        sl.sendParticles(ParticleTypes.ENCHANT, getX(), getY() + 1.2, getZ(), 25, 0.4, 0.4, 0.4, 0.6);
        sl.playSound(null, blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.HOSTILE, 1.0f, 0.8f);
    }

    /** The fight is over: the book goes away, the Bystanders fade and the disguise comes off. */
    private void putAwayBook(ServerLevel sl) {
        this.entityData.set(BOOK_OUT, false);
        endDisguise();
        releasePuppets(sl);
        fadeBystanders(sl);
        clearMark();
        sl.playSound(null, blockPosition(), SoundEvents.BOOK_PUT, SoundSource.HOSTILE, 1.0f, 1.0f);
    }

    /** Every tick while he fights: opens the book when there is a fight, picks pages, runs the marks, the puppets and the disguise. */
    private void skillHunter(@Nullable LivingEntity t) {
        if (!(level() instanceof ServerLevel sl)) return;
        if (stampCooldown > 0) stampCooldown--;
        if (markCooldown > 0) markCooldown--;
        if (galleryCooldown > 0) galleryCooldown--;
        if (blackVoiceCooldown > 0) blackVoiceCooldown--;
        if (convertCooldown > 0) convertCooldown--;
        if (pageGcd > 0) pageGcd--;

        tickMarks(sl);
        tickBrands(sl);
        tickPuppets(sl, t);
        if (isDisguised()) {
            disguiseTicks++;
            if (tickCount % 10 == 0) redirectAggro(sl);
        }

        // the book: out as soon as there is a fight, away after a while of peace
        if (t != null) {
            bookIdleTicks = 0;
            conjureBook(sl);
        } else if (isBookOut() && ++bookIdleTicks > ChrolloTuning.BOOK_AWAY_TICKS) {
            putAwayBook(sl);
        }

        if (t == null || !canUseNen() || !isBookOut() || pageGcd > 0 || tickCount % 5 != 0) return;
        if (isDisguised() && disguiseTicks < ChrolloTuning.CONVERT_MIN_HOLD_TICKS) return; // let the disguise work before the next page

        double d = distanceTo(t);
        int crowd = liveBystanders(sl);
        boolean hurtLately = tickCount - lastHitTick < 60;

        // a crowd around him (more than 3 Bystanders): the Sun and Moon on his target comes before every other page
        if (crowd > 3 && markCooldown <= 0 && markTicks == 0 && d < 12.0 && payAura(ChrolloTuning.MARK_COST)) {
            useSunMoon(sl, t);
            return;
        }
        if (convertCooldown <= 0 && !isDisguised() && (getHealth() < getMaxHealth() * 0.6f || (hurtLately && crowd >= 3)) && useConvertHands(sl, t)) return;
        if (galleryCooldown <= 0 && crowd < ChrolloTuning.MAX_BYSTANDERS && useGallery(sl, t)) return;
        // (Order Stamp is not used on his target any more: Chrollo can no longer force Zetsu on anyone)
        if (markCooldown <= 0 && markTicks == 0 && d < 12.0 && payAura(ChrolloTuning.MARK_COST)) {
            useSunMoon(sl, t);
            return;
        }
        if (blackVoiceCooldown <= 0 && puppets.size() < ChrolloTuning.MAX_PUPPETS) useBlackVoice(sl, t);
    }

    /** Every page he turns: the pause before the next one, the effects, and the disguise ends (unless the page is Convert Hands). */
    private void pageUsed(ServerLevel sl, @Nullable LivingEntity t, boolean convertHands, float pitch) {
        if (!convertHands) endDisguise();
        pageGcd = ChrolloTuning.PAGE_GCD_TICKS;
        if (t != null) bookFx(sl, t);
        sl.playSound(null, blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.HOSTILE, 1.0f, pitch);
    }

    private void bookFx(ServerLevel sl, LivingEntity t) {
        sl.sendParticles(ParticleTypes.ENCHANT, getX(), getY() + 1.4, getZ(), 20, 0.4, 0.3, 0.4, 0.6);
        sl.sendParticles(ParticleTypes.END_ROD, t.getX(), t.getY() + 1.0, t.getZ(), 12, 0.3, 0.6, 0.3, 0.05);
    }

    // ---- Gallery Fake: Bystanders ----

    /** Bystanders he still has out (the ones that died or faded are forgotten). */
    private int liveBystanders(ServerLevel sl) {
        bystanders.removeIf(id -> !(sl.getEntity(id) instanceof BystanderEntity b) || !b.isAlive());
        return bystanders.size();
    }

    @Nullable
    private BystanderEntity nearestBystander(ServerLevel sl) {
        BystanderEntity best = null;
        double bd = Double.MAX_VALUE;
        for (UUID id : bystanders) {
            if (sl.getEntity(id) instanceof BystanderEntity b && b.isAlive()) {
                double d2 = distanceToSqr(b);
                if (d2 < bd) {
                    bd = d2;
                    best = b;
                }
            }
        }
        return best;
    }

    private boolean useGallery(ServerLevel sl, LivingEntity t) {
        BlockPos spot = spotForBystander(sl);
        if (spot == null || !payAura(ChrolloTuning.GALLERY_COST)) return false;
        galleryCooldown = ChrolloTuning.GALLERY_COOLDOWN_TICKS;
        spawnBystander(sl, spot);
        pageUsed(sl, t, false, 1.4f);
        return true;
    }

    /** A Bystander steps out of the crowd: random skin, and it goes for whatever he is fighting. */
    @Nullable
    private BystanderEntity spawnBystander(ServerLevel sl, BlockPos spot) {
        BystanderEntity b = HxHEntities.BYSTANDER.get().create(sl);
        if (b == null) return null;
        b.setOwner(this);
        b.setSkin(random.nextInt(BystanderEntity.SKINS));
        b.moveTo(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, random.nextFloat() * 360f, 0f);
        b.setPersistenceRequired();
        sl.addFreshEntity(b);
        LivingEntity t = getTarget();
        if (t != null) b.setTarget(t);
        bystanders.add(b.getUUID());
        bystanderBrand.put(b.getUUID(), nextBrandSun); // already carries the Sun or the Moon, alternating
        nextBrandSun = !nextBrandSun;
        sl.sendParticles(ParticleTypes.ENCHANT, b.getX(), b.getY() + 1.0, b.getZ(), 20, 0.3, 0.6, 0.3, 0.4);
        sl.playSound(null, spot, SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.HOSTILE, 0.8f, 1.5f);
        return b;
    }

    private void fadeBystanders(ServerLevel sl) {
        for (UUID id : bystanders) {
            if (sl.getEntity(id) instanceof BystanderEntity b) b.fade(sl);
        }
        bystanders.clear();
        bystanderMarks.clear();
        bystanderBrand.clear();
    }

    // ---- Convert Hands: he takes a Bystander's appearance and slips into the crowd ----

    private boolean useConvertHands(ServerLevel sl, LivingEntity t) {
        BlockPos dest = convertSpot(sl);
        if (dest == null) return false;
        BystanderEntity look = nearestBystander(sl);
        BlockPos newSpot = null;
        if (look == null) { // nobody to copy yet: a Bystander is conjured first
            if (liveBystanders(sl) >= ChrolloTuning.MAX_BYSTANDERS) return false;
            newSpot = spotForBystander(sl);
            if (newSpot == null) return false;
        }
        if (!payAura(ChrolloTuning.CONVERT_COST)) return false;
        if (look == null) {
            look = spawnBystander(sl, newSpot);
            if (look == null) return false;
        }
        convertCooldown = ChrolloTuning.CONVERT_COOLDOWN_TICKS;
        this.entityData.set(DISGUISE, look.skin());
        disguiseTicks = 0;

        sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.9, getZ(), 15, 0.3, 0.5, 0.3, 0.02);
        getNavigation().stop();
        teleportTo(dest.getX() + 0.5, dest.getY(), dest.getZ() + 0.5);
        sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.9, getZ(), 15, 0.3, 0.5, 0.3, 0.02);
        sl.playSound(null, blockPosition(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.HOSTILE, 1.0f, 1.0f);

        redirectAggro(sl);
        pageUsed(sl, t, true, 1.0f);
        return true;
    }

    private void endDisguise() {
        if (this.entityData.get(DISGUISE) != -1) this.entityData.set(DISGUISE, -1);
        disguiseTicks = 0;
    }

    /**
     * While he wears a Bystander's face, creatures that were after him go for someone else instead (a Bystander first, otherwise
     * whoever is nearest), unless he is the only target around.
     */
    private void redirectAggro(ServerLevel sl) {
        for (Mob m : sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(48.0), x -> x.getTarget() == this)) {
            LivingEntity alt = altTargetFor(m);
            if (alt != null) m.setTarget(alt);
        }
    }

    /** Someone other than Chrollo for this creature to go after, or null when there is nobody else (he is then the only target). */
    @Nullable
    public LivingEntity altTargetFor(Mob m) {
        LivingEntity alt = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, m.getBoundingBox().inflate(24.0))) {
            if (e == this || e == m || !e.isAlive() || e instanceof ArmorStand || e instanceof ChrolloEntity) continue;
            if (e instanceof Player p && (p.isCreative() || p.isSpectator())) continue;
            double d2 = m.distanceToSqr(e) * (e instanceof BystanderEntity ? 0.25 : 1.0); // the crowd draws them first
            if (d2 < best) {
                best = d2;
                alt = e;
            }
        }
        return alt;
    }

    // ---- finding a place to stand ----

    private static boolean safeToStand(ServerLevel sl, BlockPos p) {
        BlockPos below = p.below();
        BlockState floor = sl.getBlockState(below);
        BlockState feet = sl.getBlockState(p);
        BlockState head = sl.getBlockState(p.above());
        if (!floor.isFaceSturdy(sl, below, net.minecraft.core.Direction.UP)) return false;
        if (!feet.getCollisionShape(sl, p).isEmpty() || !head.getCollisionShape(sl, p.above()).isEmpty()) return false;
        if (!feet.getFluidState().isEmpty() || !head.getFluidState().isEmpty()) return false;
        if (floor.is(Blocks.MAGMA_BLOCK) || floor.is(Blocks.CAMPFIRE) || floor.is(Blocks.SOUL_CAMPFIRE) || floor.is(BlockTags.FIRE)) return false;
        return !(feet.is(BlockTags.FIRE) || feet.is(Blocks.SWEET_BERRY_BUSH) || feet.is(Blocks.COBWEB) || feet.is(Blocks.POWDER_SNOW) || feet.is(Blocks.WITHER_ROSE));
    }

    /** A safe standing block in this column, looking up to 3 blocks up and down from the given one. */
    @Nullable
    private static BlockPos settle(ServerLevel sl, BlockPos base) {
        if (safeToStand(sl, base)) return base;
        for (int dy = 1; dy <= 3; dy++) {
            if (safeToStand(sl, base.above(dy))) return base.above(dy);
            if (safeToStand(sl, base.below(dy))) return base.below(dy);
        }
        return null;
    }

    /** A safe block 2 to 5 blocks from him for a new Bystander. */
    @Nullable
    private BlockPos spotForBystander(ServerLevel sl) {
        for (int i = 0; i < 16; i++) {
            double a = random.nextDouble() * Math.PI * 2;
            double r = 2.0 + random.nextDouble() * 3.0;
            BlockPos p = settle(sl, BlockPos.containing(getX() + Math.cos(a) * r, getY(), getZ() + Math.sin(a) * r));
            if (p != null) return p;
        }
        return null;
    }

    /**
     * Where Convert Hands puts him: a safe block within 8 blocks of where he stands, and his X never changes by more than 5.
     * Of the spots found, the one closest to the crowd wins, so he disappears among the Bystanders.
     */
    @Nullable
    private BlockPos convertSpot(ServerLevel sl) {
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        double range = ChrolloTuning.CONVERT_RANGE, maxDx = ChrolloTuning.CONVERT_MAX_DX;
        for (int i = 0; i < 40; i++) {
            double dx = (random.nextDouble() * 2 - 1) * maxDx;
            double zr = Math.sqrt(Math.max(0.0, range * range - dx * dx));
            double dz = (random.nextDouble() * 2 - 1) * zr;
            BlockPos p = settle(sl, BlockPos.containing(getX() + dx, getY(), getZ() + dz));
            if (p == null) continue;
            double ex = p.getX() + 0.5 - getX(), ey = p.getY() - getY(), ez = p.getZ() + 0.5 - getZ();
            if (Math.abs(ex) > maxDx || ex * ex + ey * ey + ez * ez > range * range) continue;
            double score = 10000.0;
            for (UUID id : bystanders) {
                if (sl.getEntity(id) instanceof BystanderEntity b && b.isAlive()) score = Math.min(score, b.distanceToSqr(p.getX() + 0.5, p.getY(), p.getZ() + 0.5));
            }
            if (score < bestScore) {
                bestScore = score;
                best = p;
            }
        }
        return best;
    }

    // ---- The Sun and Moon ----

    private void useSunMoon(ServerLevel sl, LivingEntity t) {
        markCooldown = ChrolloTuning.MARK_COOLDOWN_TICKS;
        markTicks = ChrolloTuning.MARK_FUSE_TICKS;
        markPos = t.position();
        markTarget = t.getUUID();
        markSun = nextSun;
        nextSun = !nextSun;
        bystanderMarks.clear();
        applyBystanderMarks(sl);
        pageUsed(sl, t, false, 1.2f);
    }

    /** Any Bystander within 4 blocks of him while his mark is on the target gets the opposite mark (a Sun on the target = a Moon on them). */
    private void applyBystanderMarks(ServerLevel sl) {
        if (markTicks <= 0) return;
        double r2 = ChrolloTuning.SUN_MOON_SHARE_RADIUS * ChrolloTuning.SUN_MOON_SHARE_RADIUS;
        for (UUID id : bystanders) {
            if (bystanderMarks.containsKey(id)) continue;
            if (sl.getEntity(id) instanceof BystanderEntity b && b.isAlive() && distanceToSqr(b) <= r2) bystanderMarks.put(id, !markSun);
        }
    }

    private void clearMark() {
        markTicks = 0;
        markTarget = null;
        bystanderMarks.clear();
    }

    /** A placed mark counts down. A marked Bystander that reaches the marked target sets the pair off; otherwise the lone mark explodes where it was put. */
    private void tickMarks(ServerLevel sl) {
        if (markTicks <= 0) return;
        Vec3 p = markPos;
        markTicks--;
        if (tickCount % 4 == 0) {
            sl.sendParticles(markSun ? ParticleTypes.FLAME : ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y + 0.5, p.z, 3, 0.4, 0.5, 0.4, 0.01);
            for (Map.Entry<UUID, Boolean> e : bystanderMarks.entrySet()) {
                Entity b = sl.getEntity(e.getKey());
                if (b != null) sl.sendParticles(e.getValue() ? ParticleTypes.FLAME : ParticleTypes.SOUL_FIRE_FLAME, b.getX(), b.getY() + 1.0, b.getZ(), 3, 0.3, 0.5, 0.3, 0.01);
            }
        }
        if (tickCount % 10 == 0) applyBystanderMarks(sl);

        Entity tgt = markTarget == null ? null : sl.getEntity(markTarget);
        if (tgt != null && tgt.isAlive()) {
            double touch2 = ChrolloTuning.SUN_MOON_TOUCH * ChrolloTuning.SUN_MOON_TOUCH;
            for (UUID id : bystanderMarks.keySet()) {
                Entity b = sl.getEntity(id);
                if (b != null && b.isAlive() && b.distanceToSqr(tgt) <= touch2) {
                    explodeMark(sl, tgt.position().add(b.position()).scale(0.5), true);
                    clearMark();
                    return;
                }
            }
        }
        if (markTicks == 0) {
            explodeMark(sl, p, false);
            clearMark();
        }
    }

    /** The mark's blast: hurts his enemies only, never breaks blocks. A Sun and a Moon going off together hit harder and wider. */
    private void explodeMark(ServerLevel sl, Vec3 p, boolean pair) {
        float mult = pair ? ChrolloTuning.PAIR_BONUS : 1f;
        sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.x, p.y + 0.5, p.z, 1, 0, 0, 0, 0);
        sl.playSound(null, BlockPos.containing(p), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.5f, 0.9f);
        if (ChrolloTuning.MARKS_BREAK_BLOCKS) breakBlocks(sl, p, ChrolloTuning.MARK_BLOCK_POWER * mult);
        double r = ChrolloTuning.MARK_RADIUS * mult;
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new AABB(p.x - r, p.y - r, p.z - r, p.x + r, p.y + r, p.z + r), this::isFoe)) {
            e.invulnerableTime = 0; // the Bystanders have been hitting it: its hit-immunity must not swallow the blast
            e.hurt(damageSources().mobAttack(this), ChrolloTuning.MARK_DAMAGE * mult * spiritBonus());
        }
    }

    /** The blast's block damage: a rough sphere of blocks is broken (and drops), except unbreakable ones and the toughest like obsidian. */
    private void breakBlocks(ServerLevel sl, Vec3 p, double radius) {
        int ir = (int) Math.ceil(radius);
        BlockPos c = BlockPos.containing(p);
        for (int dx = -ir; dx <= ir; dx++) {
            for (int dy = -ir; dy <= ir; dy++) {
                for (int dz = -ir; dz <= ir; dz++) {
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d > radius || (d > radius * 0.7 && random.nextFloat() < 0.45f)) continue; // ragged edge
                    BlockPos pos = c.offset(dx, dy, dz);
                    net.minecraft.world.level.block.state.BlockState st = sl.getBlockState(pos);
                    if (st.isAir() || !st.getFluidState().isEmpty()) continue;
                    float hardness = st.getDestroySpeed(sl, pos);
                    if (hardness < 0f || hardness >= 50f) continue; // bedrock, barriers, obsidian and tougher
                    sl.destroyBlock(pos, true, this);
                }
            }
        }
    }

    // ---- the Sun and the Moon on every Bystander ----

    /** Marked Bystanders glow with their mark; a Sun and a Moon that are within a block of each other AND of his target blow up together. */
    private void tickBrands(ServerLevel sl) {
        if (bystanderBrand.isEmpty()) return;
        bystanderBrand.keySet().removeIf(id -> !(sl.getEntity(id) instanceof BystanderEntity b) || !b.isAlive());
        if (bystanderBrand.isEmpty()) return;
        if (tickCount % 6 == 0) {
            for (Map.Entry<UUID, Boolean> e : bystanderBrand.entrySet()) {
                Entity b = sl.getEntity(e.getKey());
                if (b != null) sl.sendParticles(e.getValue() ? ParticleTypes.FLAME : ParticleTypes.SOUL_FIRE_FLAME, b.getX(), b.getY() + 1.0, b.getZ(), 2, 0.25, 0.5, 0.25, 0.005);
            }
        }
        if (tickCount % 2 != 0) return;
        LivingEntity tgt = getTarget();
        if (tgt == null || !tgt.isAlive() || !isFoe(tgt)) return;
        double gap = ChrolloTuning.BRAND_BOOM_GAP;
        net.minecraft.world.phys.AABB tb = tgt.getBoundingBox().inflate(gap);
        List<BystanderEntity> suns = new ArrayList<>();
        List<BystanderEntity> moons = new ArrayList<>();
        for (Map.Entry<UUID, Boolean> e : bystanderBrand.entrySet()) {
            if (sl.getEntity(e.getKey()) instanceof BystanderEntity b && b.isAlive() && tb.intersects(b.getBoundingBox())) (e.getValue() ? suns : moons).add(b);
        }
        for (BystanderEntity sun : suns) {
            for (BystanderEntity moon : moons) {
                if (!sun.getBoundingBox().inflate(gap).intersects(moon.getBoundingBox())) continue;
                Vec3 at = tgt.position().add(sun.position()).add(moon.position()).scale(1.0 / 3.0);
                bystanderBrand.remove(sun.getUUID());
                bystanderBrand.remove(moon.getUUID());
                bystanders.remove(sun.getUUID());
                bystanders.remove(moon.getUUID());
                sun.discard();
                moon.discard();
                explodeMark(sl, at, true);
                return;
            }
        }
    }

    // ---- Black Voice ----

    private void useBlackVoice(ServerLevel sl, LivingEntity t) {
        Mob best = null;
        double bd = Double.MAX_VALUE;
        for (Mob m : sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(12.0))) {
            if (!(m instanceof Enemy) || m == this || m == t || !m.isAlive() || m.getType().is(Tags.EntityTypes.BOSSES) || puppets.containsKey(m.getUUID())) continue;
            double d2 = distanceToSqr(m);
            if (d2 < bd) {
                bd = d2;
                best = m;
            }
        }
        if (best == null || !payAura(ChrolloTuning.BLACK_VOICE_COST)) return;
        blackVoiceCooldown = ChrolloTuning.BLACK_VOICE_COOLDOWN_TICKS;
        best.setPersistenceRequired();
        puppets.put(best.getUUID(), sl.getGameTime() + ChrolloTuning.BLACK_VOICE_TICKS);
        best.setTarget(t);
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, best.getX(), best.getY() + best.getBbHeight() + 0.2, best.getZ(), 15, 0.2, 0.2, 0.2, 0.1);
        pageUsed(sl, t, false, 1.6f);
    }

    /** Controlled creatures fight what he fights, until the voice fades. */
    private void tickPuppets(ServerLevel sl, @Nullable LivingEntity t) {
        if (puppets.isEmpty() || tickCount % 10 != 0) return;
        long now = sl.getGameTime();
        for (Iterator<Map.Entry<UUID, Long>> it = puppets.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Long> e = it.next();
            if (!(sl.getEntity(e.getKey()) instanceof Mob m) || !m.isAlive()) {
                it.remove();
            } else if (now >= e.getValue() || t == null) {
                m.setTarget(null);
                it.remove();
            } else {
                if (m.getTarget() != t) m.setTarget(t);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, m.getX(), m.getY() + m.getBbHeight() + 0.25, m.getZ(), 2, 0.05, 0.1, 0.05, 0.0);
            }
        }
    }

    private void releasePuppets(ServerLevel sl) {
        for (UUID id : puppets.keySet()) {
            if (sl.getEntity(id) instanceof Mob m) m.setTarget(null);
        }
        puppets.clear();
    }

    // =====================================================================================================
    // end of life
    // =====================================================================================================

    @Override
    public void die(DamageSource source) {
        if (level() instanceof ServerLevel sl) {
            releasePuppets(sl);
            fadeBystanders(sl);
        }
        cleanUp();
        super.die(source);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        cleanUp();
        super.remove(reason);
    }

    private void cleanUp() {
    }

    // =====================================================================================================
    // animation (GeckoLib): the same walk / idle / punch clips as the Kite NPC
    // =====================================================================================================

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement_controller", 1, event -> {
            if (this.isInWater()) {
                return PlayState.STOP;
            } else if (event.isMoving()) {
                event.getController().setAnimationSpeed(1.0);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.walk"));
            } else {
                event.getController().setAnimationSpeed(0.5);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.idle"));
            }
        }));
        controllers.add(new AnimationController<>(this, "attack_controller", 1, state -> PlayState.STOP)
            .triggerableAnim("punch1", RawAnimation.begin().thenPlay("punch1"))
            .triggerableAnim("punch2", RawAnimation.begin().thenPlay("punch2")));
    }

    /** The Geo punch clips are gone: the NPC is drawn with the player model, so a punch is the normal arm swing. */
    @Override
    public void triggerAnim(String controllerName, String animName) {
        if (!level().isClientSide && animName.startsWith("punch")) net.hxhadventure.addon.SwingUtil.forceSwing(this, net.minecraft.world.InteractionHand.MAIN_HAND);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
