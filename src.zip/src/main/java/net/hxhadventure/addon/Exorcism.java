package net.hxhadventure.addon;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.entity.ModEntities;
import net.hxhadventure.entity.custom.AuraEntity;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;

/**
 * Hina lifting Conditions, Limitations and Vows. The same ritual as Kite opening the nodes (NenAwakening): the player is held still,
 * Hina steps behind them and presses a hand to their back, aura gathers and at the peak it surges through them; at that moment
 * every Condition, Limitation and Vow is gone for good (the same as /hxh remove restrictions). Then she needs an hour to recover.
 */
public final class Exorcism {
    private Exorcism() {}

    private static final org.slf4j.Logger LOGGER = com.mojang.logging.LogUtils.getLogger();

    public static final int COOLDOWN_TICKS = 72000; // one real hour (20 ticks a second)
    public static final int TOTAL_TICKS = NenAwakening.TOTAL_TICKS;
    public static final int SURGE_TICK = NenAwakening.SURGE_TICK;
    private static final double BEHIND = 0.85;
    private static final double MAX_DISTANCE = 8.0;
    private static final String KEY = "HxHCraft_HinaReadyAt";

    private static final class Ritual {
        UUID hina;
        Vec3 anchor;
        float yaw;
        int ticks;
        AuraEntity surge;
        /** She lifts the Stake of Retribution instead of the restrictions. */
        boolean stake;
    }

    private static final Map<UUID, Ritual> RITUALS = new ConcurrentHashMap<>();

    public static boolean inRitual(ServerPlayer sp) {
        return RITUALS.containsKey(sp.getUUID());
    }

    /** Is this Hina in the middle of a ritual right now? (If not, she must never stay frozen: see HinaEntity.) */
    public static boolean hasRitualFor(UUID hinaUuid) {
        for (Ritual r : RITUALS.values()) if (hinaUuid.equals(r.hina)) return true;
        return false;
    }

    /** Ticks left before Hina can help this player again (0 = ready). */
    public static int cooldownLeft(ServerPlayer sp) {
        long readyAt = sp.getPersistentData().getLong(KEY);
        long now = sp.level().getGameTime();
        if (readyAt <= now) return 0;
        // a world clock that went backwards (new world, time set) must not lock the player out for longer than the cooldown
        return (int) Math.min(COOLDOWN_TICKS, readyAt - now);
    }

    /** The player said yes in Hina's menu. Checked again here. */
    public static void start(ServerPlayer sp, int hinaId, boolean stake) {
        if (inRitual(sp) || !(sp.level() instanceof ServerLevel level)) return;
        Combat c = Combat.get(sp);
        NenAddonData d = NenAddonData.get(sp);
        Entity e = level.getEntity(hinaId);
        if (!(e instanceof HinaEntity hina) || !hina.isAlive() || hina.distanceTo(sp) > MAX_DISTANCE) {
            sp.sendSystemMessage(Component.literal("§cYou are too far from Hina."));
            return;
        }
        if (c == null || !c.hasNenUnlocked()) return;
        if (stake) {
            if (!JudgmentChain.hasStake(sp)) {
                sp.sendSystemMessage(Component.literal("§d[Hina] §fThere is no Stake in your heart."));
                return;
            }
        } else if (d.vows.isEmpty() && d.prayers == 0) {
            sp.sendSystemMessage(Component.literal("§d[Hina] §fYou have nothing sworn. There is nothing for me to lift."));
            return;
        }
        if (cooldownLeft(sp) > 0) {
            sp.sendSystemMessage(Component.literal("§d[Hina] §fI have not recovered yet. Come back in a little while."));
            return;
        }
        for (Ritual r : RITUALS.values()) if (hina.getUUID().equals(r.hina)) {
            sp.sendSystemMessage(Component.literal("§cHina is busy with someone else."));
            return;
        }

        Ritual r = new Ritual();
        r.hina = hina.getUUID();
        r.stake = stake;
        r.anchor = sp.position();
        r.yaw = sp.getYRot();
        RITUALS.put(sp.getUUID(), r);

        Vec3 facing = Vec3.directionFromRotation(0, r.yaw).multiply(1, 0, 1).normalize();
        hina.beginRitual();
        hina.teleportTo(r.anchor.x - facing.x * BEHIND, r.anchor.y, r.anchor.z - facing.z * BEHIND);
        hina.setYRot(r.yaw);
        hina.setYHeadRot(r.yaw);
        hina.setYBodyRot(r.yaw);

        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, TOTAL_TICKS + 20, 9, false, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, TOTAL_TICKS + 20, 4, false, false, false));
        LOGGER.info("[Hina] ritual started for {} (hina {})", sp.getName().getString(), hina.getUUID());
        sp.sendSystemMessage(Component.literal("§d[Hina] §fStay still. Let it go."));
        level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0f, 0.5f);
    }

    private static void tick(ServerPlayer sp) {
        Ritual r = RITUALS.get(sp.getUUID());
        if (r == null) return;
        try {
            tickRitual(sp, r);
        } catch (Throwable t) {
            // whatever went wrong, the ritual ends: the player is released and Hina is never left frozen
            LOGGER.error("Hina's ritual failed", t);
            sp.sendSystemMessage(Component.literal("§c[Hina] The ritual failed: " + t));
            end(sp, r, false);
        }
    }

    private static void tickRitual(ServerPlayer sp, Ritual r) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        Entity he = level.getEntity(r.hina);
        if (!sp.isAlive() || !(he instanceof HinaEntity hina) || !hina.isAlive()) {
            LOGGER.warn("[Hina] ritual ended early at tick {}: player alive={}, hina entity={}", r.ticks, sp.isAlive(), he);
            end(sp, r, false);
            return;
        }
        r.ticks++;
        if (r.ticks == 1 || r.ticks % 20 == 0) LOGGER.info("[Hina] ritual tick {}", r.ticks);

        Vec3 v = sp.getDeltaMovement();
        sp.setDeltaMovement(0, Math.min(0, v.y), 0);
        sp.hurtMarked = true;
        sp.setSprinting(false);
        if (sp.position().distanceToSqr(r.anchor) > 0.5) sp.connection.teleport(r.anchor.x, r.anchor.y, r.anchor.z, sp.getYRot(), sp.getXRot());
        hina.setYRot(r.yaw);
        hina.setYHeadRot(r.yaw);
        hina.setYBodyRot(r.yaw);

        Vec3 facing = Vec3.directionFromRotation(0, r.yaw).multiply(1, 0, 1).normalize();
        Vec3 hand = r.anchor.subtract(facing.scale(0.15)).add(0, 1.25, 0);
        float progress = Math.min(1f, r.ticks / (float) SURGE_TICK);

        if (r.ticks < SURGE_TICK) {
            if (r.ticks % 2 == 0) {
                level.sendParticles(ParticleTypes.END_ROD, hand.x, hand.y, hand.z, 1 + (int) (progress * 3), 0.12, 0.12, 0.12, 0.01);
                level.sendParticles(ParticleTypes.ENCHANT, sp.getX(), sp.getY() + 1.0, sp.getZ(), 2 + (int) (progress * 6), 0.5, 0.8, 0.5, 0.4);
            }
            if (r.ticks % 12 == 0) {
                level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 0.8f, 0.5f + progress * 1.2f);
            }
        } else if (r.ticks == SURGE_TICK) {
            surge(sp, level, r);
        } else if (r.ticks % 2 == 0) {
            level.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1.0, sp.getZ(), 6, 0.6, 1.0, 0.6, 0.15);
        }

        if (r.ticks >= TOTAL_TICKS) end(sp, r, true);
    }

    /** The peak: every rule is lifted. Her hour of rest starts now. */
    private static void surge(ServerPlayer sp, ServerLevel level, Ritual r) {
        try {
            if (r.stake) JudgmentChain.removeStake(sp); // the Stake of Retribution, and the death-Vows sworn under it
            else Vows.removeAllRestrictions(sp); // every Condition, Limitation and Vow: the same as /hxh remove restrictions
            sp.getPersistentData().putLong(KEY, level.getGameTime() + COOLDOWN_TICKS); // her hour of rest starts only once it worked
        } catch (Throwable t) {
            LOGGER.error("Hina could not remove the restrictions", t);
            sp.sendSystemMessage(Component.literal("§c[Hina] Something went wrong and nothing was removed: " + t));
        }

        AuraEntity aura = new AuraEntity(ModEntities.AURA_ENTITY.get(), level);
        aura.setOwner(sp);
        aura.setAuraColorIndex(net.hxhadventure.abilities.AbilityRegistry.getOrCreatePlayerAuraColor(sp) - 1); // their own Ren colour
        aura.setAuraType(0);
        aura.setAuraScale(Tuning.REN_MAX_SIZE); // the surge is a Ren aura at its maximum size
        aura.setPos(sp.getX(), sp.getY(), sp.getZ());
        level.addFreshEntity(aura);
        r.surge = aura;

        ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(sp.getUUID(), "aura_up", false), sp);
        level.sendParticles(ParticleTypes.FLASH, sp.getX(), sp.getY() + 1.0, sp.getZ(), 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1.0, sp.getZ(), 80, 0.4, 0.9, 0.4, 0.35);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + 1.0, sp.getZ(), 40, 0.5, 0.9, 0.5, 0.3);
        level.playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.8f);
        level.playSound(null, sp.blockPosition(), SoundEvents.TRIDENT_THUNDER, SoundSource.PLAYERS, 0.8f, 1.2f);
    }

    private static void end(ServerPlayer sp, Ritual r, boolean completed) {
        LOGGER.info("[Hina] ritual end, completed={}, ticks={}", completed, r.ticks);
        RITUALS.remove(sp.getUUID());
        sp.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        sp.removeEffect(MobEffects.DAMAGE_RESISTANCE);
        if (r.surge != null && !r.surge.isRemoved()) r.surge.discard();
        if (sp.level() instanceof ServerLevel level && level.getEntity(r.hina) instanceof HinaEntity hina) hina.endRitual();
        if (completed) {
            sp.sendSystemMessage(Component.literal(r.stake
                ? "§d[Hina] §fIt is done. The Stake of Retribution is out of your heart. I need an hour to rest before I can do this again."
                : "§d[Hina] §fIt is done. Nothing you swore binds you any more. I need an hour to rest before I can do this again."));
        }
    }

    // NOTE: Forge names its generated handler classes <package>.__<SimpleClassName>_<method>_<Event>, so these names must differ from NenAwakening.Events
    // (same name = Hina's handlers silently ran Kite's instead and the ritual never ticked).
    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class ExorcismEvents {
        @SubscribeEvent
        public static void onExorcismTick(TickEvent.PlayerTickEvent e) {
            if (e.phase == TickEvent.Phase.START && e.player instanceof ServerPlayer sp) tick(sp);
        }

        @SubscribeEvent
        public static void onExorcismLogout(PlayerEvent.PlayerLoggedOutEvent e) {
            if (e.getEntity() instanceof ServerPlayer sp) {
                Ritual r = RITUALS.get(sp.getUUID());
                if (r != null) end(sp, r, false);
            }
        }

        @SubscribeEvent
        public static void onExorcismClone(PlayerEvent.Clone e) {
            long at = e.getOriginal().getPersistentData().getLong(KEY);
            if (at != 0) e.getEntity().getPersistentData().putLong(KEY, at); // dying does not reset her rest
        }
    }
}
