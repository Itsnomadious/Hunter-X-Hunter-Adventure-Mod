package net.hxhadventure.addon;

/**
 * Every number behind how the melee NPCs MOVE and HIT (the "feel"), in one place. The attack numbers themselves (Attack 5, Strong 15,
 * Barrage 1.5, reach, charge time...) still come from each NPC's own tuning; this file is only about timing, footwork and impact.
 * Ideas taken from Jujutsu Craft's NPC AI: attacks that step into the target and snap to face it, a guard / backstep / avoid reaction,
 * a high-speed gap closer, and knockback applied as a direct launch (not vanilla's weak nudge).
 */
public final class NpcFeelTuning {
    private NpcFeelTuning() {}

    // ---- Attack: a three-hit combo instead of one punch every 10 ticks standing still ----
    public static final int COMBO_HITS = 3;
    public static final int COMBO_GAP_TICKS = 7;          // between the start of one swing and the next
    public static final int WINDUP_TICKS = 3;             // swing starts, the hit lands this much later (the tell)
    public static final int COMBO_RECOVERY_TICKS = 16;    // the opening a player gets after the finisher
    public static final float FINISHER_DAMAGE_MULT = 1.25f;
    public static final double COMBO_KNOCK_H = 0.20;      // the first hits barely push, so the next one connects
    public static final double FINISHER_KNOCK_H = 0.95, FINISHER_KNOCK_V = 0.32;
    public static final double COMBO_LUNGE_SPEED = 0.32;  // each swing steps into the target (blocks / tick)
    public static final int COMBO_LUNGE_TICKS = 3;
    public static final float COMBO_SLOW = 0.08f;

    // ---- Strong attack: telegraphed, commits to a direction (dodgeable), launches, and is punishable on a miss ----
    public static final int STRONG_LOCK_TICKS = 6;        // the last ticks of the charge: aim is locked and the NPC lunges
    public static final double STRONG_LUNGE_SPEED = 0.75;
    public static final float STRONG_SLOW = 0.50f;
    public static final int STRONG_WHIFF_RECOVERY = 14;   // extra recovery when the blow hits nothing
    public static final double STRONG_LAUNCH_V = 0.25;    // plus 0.20 x charge progress

    // ---- Barrage: keeps on top of the target, holds it in place, ends with a launcher ----
    public static final float BARRAGE_SLOW = 0.10f;
    public static final double BARRAGE_PIN_PULL = 0.10;   // pulled toward the NPC when further than BARRAGE_PIN_DIST
    public static final double BARRAGE_PIN_DIST = 1.4;
    public static final double BARRAGE_END_KNOCK_H = 0.9, BARRAGE_END_KNOCK_V = 0.30;
    public static final double BARRAGE_LUNGE_SPEED = 0.20;

    /** How much of the victim's knockback resistance still counts against a launch (1 = vanilla, 0 = JJK's "ignore it"). */
    public static final double LAUNCH_RESIST_SHARE = 0.5;
    /** The reach added to a hit's range for the NPC's own target, so a hit the AI judged "in reach" is never lost to aim. */
    public static final double TARGET_HIT_LEEWAY = 2.0;
    /** A blow reaches this far past the NPC's body surface (plus the attack's own range): the hit volume starts AT the body, not ahead of it. */
    public static final double BODY_REACH_BONUS = 1.0;
    /** The front of an NPC: a victim counts when the angle to where it faces is within this cosine (-0.17 = 100 degrees either side). */
    public static final double FRONT_COS = -0.17;
    /** No single melee blow from an NPC takes more than this share of a player's maximum health (applied after Ten / Ren / Ken durability). */
    public static final double MELEE_HIT_CAP = 0.30;
    /** Logs every blow that hits nobody (distance, angle), to find out why an NPC is not landing hits. */
    public static final boolean DEBUG_MELEE = false;

    // ---- Footwork ----
    public static final double PURSUIT_SPEED = 1.35;      // path speed modifier (was 1.25)
    public static final double DIRECT_STEER_DIST = 6.0;   // closer than this it steers straight at the target instead of re-pathing
    public static final double RUSH_MIN_DIST = 6.0, RUSH_MAX_DIST = 16.0;
    public static final double RUSH_SPEED = 0.85;         // blocks / tick, the gap closer (JJK's high-speed move)
    public static final int RUSH_TICKS = 9, RUSH_COOLDOWN = 90;
    public static final double STRAFE_SIDE = 0.65, STRAFE_FORWARD = 0.25;
    public static final int STRAFE_FLIP_MIN = 22, STRAFE_FLIP_RANGE = 24;
    public static final double BACKSTEP_CHANCE = 0.30;    // after a finished combo: hit-and-run
    public static final double BACKSTEP_SPEED = 0.50;
    public static final int BACKSTEP_TICKS = 4;

    // ---- Reactions: sidestep a charging Strong attack or an incoming projectile ----
    public static final double DODGE_CHARGE_CHANCE = 0.45;
    public static final double DODGE_PROJECTILE_CHANCE = 0.60;
    public static final double DODGE_SPEED = 0.80;
    public static final int DODGE_TICKS = 4, DODGE_COOLDOWN = 70;
    public static final double DODGE_TRIGGER_DIST = 4.5;
    /** Share of a player's blows the dodge is assumed to cost on average (used by the balance model). */
    public static final double DODGE_EXPECTED_AVOID = 0.15;

    /**
     * Whether the Nen fighters (Netero, Zeno, Silva, Bisky, Illumi, Kurapika, Killua) use Ren in a fight. Hisoka, Chrollo, Gon and Neferpitou never do
     * (Ten / Ken only); with this off the whole cast fights the same way and hits about as hard. Ren roughly doubles an NPC's damage and speed bonus.
     */
    public static final boolean FIGHTERS_USE_REN = false;

    // ---- Balance guarantee (see NpcBalance) ----
    /** Matched player: no mastery level, Ten or Ren skill above this (the player caps). */
    public static final int PLAYER_CAP = 100;
    /** Brawl ratio M = (time the player survives trading blows) / (time they need to kill). Kept inside [FLOOR, CEIL]. */
    public static final double M_FLOOR = CLOSE_SHARE_FLOOR(), M_CEIL = 0.40;
    /** A skilled player must reach this share of the NPC's health before dying when avoiding at most MAX_AVOID of its damage. */
    public static final double CLOSE_SHARE = 0.90, MAX_AVOID = 0.85;
    private static double CLOSE_SHARE_FLOOR() { return 0.90 * (1.0 - 0.85); }   // = CLOSE_SHARE x (1 - MAX_AVOID) = 0.135
    /** Longest contact time (seconds of landing blows) a fight is allowed to demand of the matched player. */
    public static final double MAX_CONTACT_SECONDS = 60.0;
    /** Share of the time the matched player is actually in hitting range (knockback, repositioning, dodges). */
    public static final double PLAYER_UPTIME = 0.75;
    /** The NPC's Hatsu adds this much on top of its melee damage in the model. */
    public static final double HATSU_PRESSURE = 0.35;
    public static final double G_MIN = 0.05, G_MAX = 1.60;
    public static final boolean GOVERNOR_ENABLED = true;
    public static final boolean HEALTH_CAP_ENABLED = true;
}
