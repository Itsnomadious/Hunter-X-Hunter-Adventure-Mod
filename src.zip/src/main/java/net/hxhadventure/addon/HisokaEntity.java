package net.hxhadventure.addon;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Hisoka, a Transmuter Nen user (NPC). He leaves people alone until they hurt him; then he fights like a player of his
 * levels would: Ten always on, Ken as his fighting stance (and whenever he is being hit), his
 * own attacks, Attack / Barrage / Strong attack, and his Bungee Gum ({@link HisokaGum}).
 *
 * His aura is a pool like a player's. Every form costs aura per second and every gum move costs aura; when it runs dry he
 * can no longer keep up any Nen (Ten, Ken and the gum all go) until he has recovered a share of it.
 * The numbers are all in {@link HisokaTuning}.
 */
public class HisokaEntity extends PathfinderMob implements GeoEntity, NpcMelee.Host, NpcFightGoal.FightNpc {

    // ---- synced to the client: which aura forms to draw ----
    private static final EntityDataAccessor<Integer> NEN_FLAGS = SynchedEntityData.defineId(HisokaEntity.class, EntityDataSerializers.INT);
    public static final int F_TEN = 1, F_KEN = 4;

    private static final int NEN_TYPE = HisokaTuning.NEN_TYPE;
    private static final java.util.UUID MOD_TEN_ARMOR = UUID.fromString("b2000000-0000-4000-8000-000000000001");
    private static final java.util.UUID MOD_TEN_TOUGH = UUID.fromString("b2000000-0000-4000-8000-000000000002");
    private static final java.util.UUID MOD_AFF_SPEED = UUID.fromString("b2000000-0000-4000-8000-000000000004");
    private static final java.util.UUID MOD_ATTACK_SLOW = UUID.fromString("b2000000-0000-4000-8000-000000000005");
    private static final java.util.UUID MOD_TEN_SPEED = UUID.fromString("b2000000-0000-4000-8000-000000000006");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    final HisokaGum gum = new HisokaGum(this);

    // ---- aura / Nen ----
    private enum Stance { NONE, KEN }
    private final float maxAura = HisokaTuning.maxAura();
    private float aura = maxAura;
    private boolean exhausted;
    private boolean ten, ken;
    private Stance stance = Stance.NONE;
    private int formCooldown;
    private int lastHitTick = -1000;
    private int idleTicks;
    private boolean wasFighting;

    // ---- attacks ----
    private final NpcMelee melee = new NpcMelee(this, this, meleeCfg());
    private final float meleeGovern = NpcBalance.governedMelee(profile());

    static MeleeCore.Cfg meleeCfg() {
        return MeleeCore.Cfg.of(HisokaTuning.PUNCH_DAMAGE, HisokaTuning.PUNCH_RANGE, HisokaTuning.STRONG_DAMAGE, HisokaTuning.STRONG_RANGE, HisokaTuning.STRONG_KNOCKBACK,
            HisokaTuning.STRONG_CHARGE_TICKS, HisokaTuning.STRONG_MAX_HOLD_TICKS, HisokaTuning.STRONG_COOLDOWN_TICKS,
            HisokaTuning.BARRAGE_DAMAGE, HisokaTuning.BARRAGE_TICKS, HisokaTuning.BARRAGE_HIT_GAP, HisokaTuning.BARRAGE_COOLDOWN_TICKS,
            HisokaTuning.PUNCH_WEIGHT_BARRAGE, HisokaTuning.PUNCH_WEIGHT_STRONG);
    }

    /** What the balance model (NpcBalance) knows about this NPC. */
    static NpcBalance.Profile profile() {
        return new NpcBalance.Profile("hisoka", HisokaTuning.MAX_HEALTH, HisokaTuning.HATSU_LEVEL, Math.min(NpcFeelTuning.PLAYER_CAP, HisokaTuning.TEN_LEVEL))
            .affinity(Affinity.dealt(NEN_TYPE), Affinity.taken(NEN_TYPE)).ren(0).regen(HisokaTuning.HEAL_PER_SECOND).cfg(meleeCfg());
    }
    private boolean punchOne = true;

    private final Map<UUID, Long> foes = new HashMap<>();

    public HisokaEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 50;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, NpcBalance.governedHealth(profile()))
            .add(Attributes.MOVEMENT_SPEED, HisokaTuning.BASE_SPEED)
            .add(Attributes.ATTACK_DAMAGE, 5.0)
            .add(Attributes.FOLLOW_RANGE, HisokaTuning.FOLLOW_RANGE)
            .add(Attributes.KNOCKBACK_RESISTANCE, HisokaTuning.KNOCKBACK_RESISTANCE);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(NEN_FLAGS, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new NpcFightGoal(this, this, t -> gum.busy()));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        // no target goals on purpose: he only ever fights what hurt him (see hurt())
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        this.aura = maxAura;
        this.setPersistenceRequired();
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("HisokaAura", aura);
        tag.putBoolean("HisokaExhausted", exhausted);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("HisokaAura")) aura = Math.max(0f, Math.min(maxAura, tag.getFloat("HisokaAura")));
        exhausted = tag.getBoolean("HisokaExhausted");
    }

    // =====================================================================================================
    // queries used by the goal, the gum and the damage events
    // =====================================================================================================

    public float aura() { return aura; }

    public float maxAura() { return maxAura; }

    public boolean isExhausted() { return exhausted; }

    public boolean isAttacking() { return melee.isAttacking(); }

    /** Nen can be used: he has aura left and nothing (Chain Jail, Forced Zetsu) is holding it down. */
    public boolean canUseNen() {
        return !exhausted && !ExtrasHooks.hatsuForced(this);
    }

    public int nenFlags() { return this.entityData.get(NEN_FLAGS); }

    /** HxHAdventure's spirit bonus for his Hatsu level: 1 + 0.1 sqrt(L). Multiplies his punches. */
    public float spiritBonus() {
        float s = (float) Math.sqrt(HisokaTuning.HATSU_LEVEL);
        float m = 1.0f + s * 0.1f;
        return m;
    }

    /** Multiplier on damage he deals (the same pieces a player's gets: affinity and the aura form). */
    public float outgoingMult() {
        return outgoingMult(null);
    }

    /** Same as a player's: Ten / Ken scale melee hits, Hatsu hits (dealt through Vows.hatsuHurt) ignore them. */
    public float outgoingMult(net.minecraft.world.damagesource.DamageSource src) {
        float m = Affinity.dealt(NEN_TYPE);
        if (src == null || !Vows.isHatsuHit(src)) m *= NpcAura.outgoing(HisokaTuning.TEN_LEVEL, ten, false, ken, false);
        return m;
    }

    /** Multiplier on damage he takes (affinity and the aura form; Ten's armour works through his armour attribute). */
    public float incomingMult(DamageSource src) {
        float m = Affinity.taken(NEN_TYPE);
        if (src.is(DamageTypes.LIGHTNING_BOLT)) m *= 1f - Affinity.lightningReduction(NEN_TYPE);
        if (src.is(DamageTypes.FALL)) m *= 1f - Affinity.fallReduction(NEN_TYPE);
        if (Affinity.isStatusDamage(src)) m *= 1f - Affinity.statusReduction(NEN_TYPE);
        m *= NpcAura.incoming(HisokaTuning.TEN_LEVEL, ten, false, ken, false); // durability, the same as a player's
        return m;
    }

    /** Pays for an ability out of his aura (Transmuters pay less). False, and nothing paid, if he cannot afford it. */
    boolean payAura(float cost) {
        if (!canUseNen()) return false;
        float c = cost * (1f - Math.min(0.5f, Affinity.abilityRefund(NEN_TYPE)));
        if (aura < c) return false;
        aura -= c;
        return true;
    }

    /** Whether something counts as an enemy: what he is fighting, or anything that hurt him lately. Gum and area hits only touch these. */
    public boolean isFoe(Entity e) {
        if (!(e instanceof LivingEntity le) || e == this || !le.isAlive() || e instanceof ArmorStand || e instanceof HisokaEntity) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        if (e == getTarget()) return true;
        Long t = foes.get(e.getUUID());
        return t != null && level().getGameTime() - t <= HisokaTuning.FOE_MEMORY_TICKS;
    }

    private void noteFoe(LivingEntity e) {
        foes.put(e.getUUID(), level().getGameTime());
        if (foes.size() > 32) {
            long now = level().getGameTime();
            foes.values().removeIf(t -> now - t > HisokaTuning.FOE_MEMORY_TICKS);
        }
    }

    private boolean validTarget(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof ArmorStand || e instanceof HisokaEntity) return false;
        return !(e instanceof Player p && (p.isCreative() || p.isSpectator()));
    }

    // =====================================================================================================
    // being hurt: he fights back
    // =====================================================================================================

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide) {
            lastHitTick = tickCount;
            if (source.getEntity() instanceof LivingEntity attacker && validTarget(attacker)) {
                noteFoe(attacker);
                LivingEntity cur = getTarget();
                if (cur == null || !cur.isAlive() || distanceToSqr(cur) > 16.0) setTarget(attacker);
            }
        }
        return hit;
    }

    // =====================================================================================================
    // per tick (server)
    // =====================================================================================================

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !isAlive() || !(level() instanceof ServerLevel)) return;
        LivingEntity t = getTarget();
        if (t != null && (!t.isAlive() || t.level() != level() || distanceToSqr(t) > 96.0 * 96.0
            || (t instanceof Player p && (p.isCreative() || p.isSpectator())))) {
            setTarget(null);
            t = null;
        }
        boolean fighting = t != null;
        if (fighting) idleTicks = 0; else idleTicks++;
        if (!fighting && wasFighting) cancelAttack();
        wasFighting = fighting;

        tickNen(fighting, t);
        melee.tick(t, t != null && inReach(t), gum.busy());
        gum.tick(t);
        refreshModifiers();
        syncFlags();
    }

    // =====================================================================================================
    // Nen: the aura pool and the stances
    // =====================================================================================================

    private void tickNen(boolean fighting, @Nullable LivingEntity t) {
        if (formCooldown > 0) formCooldown--;

        // regeneration and upkeep, a twentieth of a second's worth every tick
        final float perTick = 1f / 20f;
        if (exhausted) {
            aura += (HisokaTuning.BASE_REGEN + maxAura * HisokaTuning.EXHAUST_REGEN_PCT) * perTick;
        } else {
            aura += (ten ? HisokaTuning.tenRegenPerSecond() : HisokaTuning.BASE_REGEN) * perTick;
            if (!fighting && idleTicks > HisokaTuning.REST_DELAY_TICKS) aura += maxAura * HisokaTuning.REST_REGEN_PCT * perTick;
            float eff = Math.min(0.5f, Affinity.efficiency(NEN_TYPE));
            if (ken) aura -= Tuning.KEN_UPKEEP * (1f - eff) * perTick;
            if (ten && tickCount % 20 == 0 && getHealth() < getMaxHealth() && tickCount - lastHitTick > 40) heal(HisokaTuning.HEAL_PER_SECOND);
        }
        aura = Math.max(0f, Math.min(maxAura, aura));

        if (!exhausted && aura <= 0.01f) {
            runDry();
        } else if (exhausted && aura >= maxAura * HisokaTuning.EXHAUST_RESUME_FRACTION) {
            exhausted = false;
            level().playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 0.8f, 1.4f);
        }

        // Chain Jail / Forced Zetsu hold everything down, like they do for a player
        boolean blocked = exhausted || ExtrasHooks.hatsuForced(this);
        ten = !blocked;
        if (blocked) {
            if (stance != Stance.NONE) setStance(Stance.NONE, true);
            return;
        }

        // Ken is his fighting stance (NPCs do not use Ren)
        Stance want = fighting ? Stance.KEN : Stance.NONE;
        if (want != stance && formCooldown <= 0) setStance(want, false);
    }

    private void runDry() {
        exhausted = true;
        aura = 0f;
        ten = false;
        setStance(Stance.NONE, true);
        gum.release();
        if (level() instanceof ServerLevel sl) {
            sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 1.0f, 0.7f);
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0, getZ(), 20, 0.4, 0.6, 0.4, 0.02);
        }
    }

    private void setStance(Stance s, boolean force) {
        if (s == stance) return;
        stance = s;
        formCooldown = HisokaTuning.FORM_SWITCH_TICKS;
        ken = s == Stance.KEN;
        if (!(level() instanceof ServerLevel sl)) return;
        switch (s) {
            case KEN -> sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 0.8f, 1.2f);
            case NONE -> {
                if (!force) sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 0.4f, 1.5f);
            }
        }
    }

    private void syncFlags() {
        int f = (ten ? F_TEN : 0) | (ken ? F_KEN : 0);
        if (this.entityData.get(NEN_FLAGS) != f) this.entityData.set(NEN_FLAGS, f);
    }

    /** Ten and Ken speed, the Transmuter's speed and the slow of a punch in progress. */
    private void refreshModifiers() {
        updateAttackSlow(); // every tick: a punch's slow lasts nine
        if (tickCount % 5 != 0) return;
        // Ten's old armour / toughness and the old Ren speed are gone: one speed bonus, the player's (Ten, Ken x1)
        setMod(Attributes.MOVEMENT_SPEED, MOD_AFF_SPEED, Affinity.speedBonus(NEN_TYPE), AttributeModifier.Operation.MULTIPLY_TOTAL);        // Ten's movement speed, the same curve a player gets (Tuning.tenSpeedBonus), capped for NPCs
        setMod(Attributes.MOVEMENT_SPEED, MOD_TEN_SPEED, NpcAura.speedBonus(HisokaTuning.TEN_LEVEL, ten, false, ken, false), AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    private void setMod(Attribute attr, UUID id, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = getAttribute(attr);
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(id);
        if (Math.abs(amount) < 1e-6) {
            if (cur != null) inst.removeModifier(id);
            return;
        }
        if (cur != null && Math.abs(cur.getAmount() - amount) < 1e-6) return;
        if (cur != null) inst.removeModifier(id);
        inst.addTransientModifier(new AttributeModifier(id, "Hisoka Nen", amount, op));
    }

    // =====================================================================================================
    // Attack / Barrage / Strong attack (Combat.java's moves, run by the NPC)
    // =====================================================================================================

    @Override
    public NpcMelee melee() { return melee; }

    /** Called by the combat goal every tick the target is within reach: picks the next move when free to. */
    @Override
    public void chooseAttack(LivingEntity t) {
        if (gum.busy()) return;
        melee.choose(t);
    }

    @Override
    public boolean inReach(LivingEntity t) {
        return distanceTo(t) - t.getBbWidth() * 0.5 <= HisokaTuning.REACH && Math.abs(t.getY() - getY()) < 2.5;
    }

    private void cancelAttack() {
        melee.cancel();
    }

    /** Spirit bonus (and the NPC's own boosts) x the fairness governor (NpcBalance). */
    @Override
    public float meleeScale() {
        return spiritBonus() * meleeGovern;
    }

    @Override
    public void swingAnim() {
        triggerPunchAnim();
    }

    void triggerPunchAnim() {
        triggerAnim("attack_controller", punchOne ? "punch1" : "punch2");
        punchOne = !punchOne;
    }

    private void updateAttackSlow() {
        setMod(Attributes.MOVEMENT_SPEED, MOD_ATTACK_SLOW, -melee.slow(), AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    // =====================================================================================================
    // end of life
    // =====================================================================================================

    @Override
    public void die(DamageSource source) {
        cleanUp();
        super.die(source);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        cleanUp();
        super.remove(reason);
    }

    private void cleanUp() {
        if (!level().isClientSide) gum.clear();
    }

    // =====================================================================================================
    // animation (GeckoLib): the same walk / idle / punch clips as the Kite NPC
    // =====================================================================================================

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement_controller", 1, event -> {
            if (this.isInWater()) {
                return PlayState.STOP;
            } else if (event.isMoving()) {
                event.getController().setAnimationSpeed(1.0);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.walk"));
            } else {
                event.getController().setAnimationSpeed(0.5);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.idle"));
            }
        }));
        controllers.add(new AnimationController<>(this, "attack_controller", 1, state -> PlayState.STOP)
            .triggerableAnim("punch1", RawAnimation.begin().thenPlay("punch1"))
            .triggerableAnim("punch2", RawAnimation.begin().thenPlay("punch2")));
    }

    /** The Geo punch clips are gone: the NPC is drawn with the player model, so a punch is the normal arm swing. */
    @Override
    public void triggerAnim(String controllerName, String animName) {
        if (!level().isClientSide && animName.startsWith("punch")) net.hxhadventure.addon.SwingUtil.forceSwing(this, net.minecraft.world.InteractionHand.MAIN_HAND);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
