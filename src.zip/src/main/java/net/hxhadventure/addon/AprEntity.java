package net.hxhadventure.addon;

import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * A.P.R. ("Annual Percentage Rate"), Hakoware's banker mascot. It hovers beside the debtor, grows with the debt (a small slime at
 * nothing owed, three players tall at the moment of bankruptcy) and says its line every time interest comes due. The number on
 * its forehead is the aura owed. All the rules live in {@link Hakoware}; this is only the body.
 */
public class AprEntity extends MascotEntity {
    /** How far along the debt is, 0 (nothing owed) to 1 (bankrupt): drives the size. */
    private static final EntityDataAccessor<Float> GROWTH = SynchedEntityData.defineId(AprEntity.class, EntityDataSerializers.FLOAT);
    /** The aura owed, shown on the forehead counter. */
    private static final EntityDataAccessor<Integer> DEBT = SynchedEntityData.defineId(AprEntity.class, EntityDataSerializers.INT);

    private UUID ownerId, targetId;
    private float targetGrowth;
    private int speechTicks;
    private int leaving = -1;       // > 0: counting down to leaving after the debt was paid
    private float side = 1f;        // which flank of the debtor it hovers on
    private boolean placed;

    /** Client side: the size actually drawn, eased toward the synced value. */
    private float shownGrowth, shownGrowthO;

    public AprEntity(EntityType<? extends AprEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(GROWTH, 0f);
        this.entityData.define(DEBT, 0);
    }

    public void bind(LivingEntity owner, LivingEntity target) {
        this.ownerId = owner.getUUID();
        this.targetId = target.getUUID();
        this.side = (target.getId() & 1) == 0 ? 1f : -1f;
    }

    public UUID targetId() { return targetId; }

    public float growth() { return this.entityData.get(GROWTH); }

    public int debtShown() { return this.entityData.get(DEBT); }

    public void setTargetGrowth(float g) { this.targetGrowth = Mth.clamp(g, 0f, 1f); }

    public void setDebt(int d) {
        if (this.entityData.get(DEBT) != d) this.entityData.set(DEBT, d);
    }

    /** Model height in blocks for a growth value. */
    public static float heightFor(float growth) {
        return Mth.lerp(Mth.clamp(growth, 0f, 1f), HakowareTuning.APR_MIN_HEIGHT, HakowareTuning.APR_MAX_HEIGHT);
    }

    /** Client side, for the renderer: eased growth. */
    public float renderGrowth(float partial) {
        return Mth.lerp(partial, shownGrowthO, shownGrowth);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        float h = heightFor(growth());
        return EntityDimensions.fixed(h * 0.75f, h);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (GROWTH.equals(key)) refreshDimensions();
        super.onSyncedDataUpdated(key);
    }

    /** Says a line above its head (a nametag standing in for a speech bubble). */
    public void say(String line) {
        this.setCustomName(Component.literal("\u00a7e\u201c" + line + "\u201d"));
        this.setCustomNameVisible(true);
        this.speechTicks = HakowareTuning.SPEECH_BUBBLE_TICKS;
    }

    /** The debt was paid: a last word, then it leaves. */
    public void dismiss(String line) {
        if (line != null) say(line);
        this.leaving = 40;
    }

    public boolean isLeaving() { return leaving >= 0; }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            shownGrowthO = shownGrowth;
            shownGrowth += (growth() - shownGrowth) * 0.2f;
            return;
        }
        if (!(level() instanceof ServerLevel sl)) return;

        if (speechTicks > 0 && --speechTicks == 0) {
            this.setCustomName(null);
            this.setCustomNameVisible(false);
        }
        if (leaving >= 0 && --leaving < 0) {
            sl.sendParticles(net.minecraft.core.particles.ParticleTypes.POOF, getX(), getY() + getBbHeight() * 0.5, getZ(), 14, 0.3, 0.3, 0.3, 0.02);
            discard();
            return;
        }
        // the grown size moves toward where the debt says it should be, a little each tick
        float g = growth();
        if (Math.abs(g - targetGrowth) > 0.004f) {
            this.entityData.set(GROWTH, g + Mth.clamp(targetGrowth - g, -0.02f, 0.02f));
        }

        LivingEntity target = targetId != null && sl.getEntity(targetId) instanceof LivingEntity t && t.isAlive() ? t : null;
        if (target == null || (leaving < 0 && !Hakoware.isTracked(getUUID()))) {
            discard(); // the debtor is gone, or the contract is (restart, release): nothing to hover beside
            return;
        }
        LivingEntity owner = ownerId != null && sl.getEntity(ownerId) instanceof LivingEntity o ? o : null;

        // hover beside the debtor, on the flank the user is not standing behind
        float h = heightFor(growth());
        Vec3 line = owner != null ? target.position().subtract(owner.position()).multiply(1, 0, 1) : new Vec3(0, 0, 1);
        line = line.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : line.normalize();
        Vec3 perp = new Vec3(-line.z, 0, line.x).scale(side);
        double out = target.getBbWidth() * 0.5 + h * 0.4 + 0.35;
        double bob = Math.sin(tickCount * 0.12) * Math.min(0.12, h * 0.1);
        double wantX = target.getX() + perp.x * out;
        double wantZ = target.getZ() + perp.z * out;
        double wantY = Math.max(target.getY(), target.getY() + target.getBbHeight() * 0.8 - h * 0.5) + bob;
        if (!placed) {
            placed = true;
            this.setPos(wantX, wantY, wantZ);
        } else {
            this.setPos(getX() + (wantX - getX()) * 0.3, getY() + (wantY - getY()) * 0.3, getZ() + (wantZ - getZ()) * 0.3);
        }
        if (owner != null) { // face the user
            float want = (float) (Mth.atan2(-(owner.getX() - getX()), owner.getZ() - getZ()) * (180.0 / Math.PI));
            this.setYRot(Mth.rotLerp(0.3f, getYRot(), want));
        }
    }
}
