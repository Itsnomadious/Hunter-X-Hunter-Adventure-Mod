package net.hxhadventure.addon;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketBlastFx;
import net.hxhadventure.addon.network.PacketPillarFx;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Zeno Zoldyck (NPC): Emission, Dragon's Head. He uses it the way a player does, with the player's numbers and visuals:
 * <ul>
 *   <li><b>Aura Blast</b>: a cone of raw aura from the palm, in the open at range (also thrown point blank to knock someone off him);</li>
 *   <li><b>Dragon Head</b>: stands still holding the aura for 3 seconds, then the golden pillar and the 60 block dragon, which hunts his target and rams it;</li>
 *   <li><b>Dragon Dive</b>: with the dragon near the target, it coils, dissipates and the rain of golden arrows falls (his finisher, on its cooldown).</li>
 * </ul>
 * He holds a few blocks of distance (a caster), punches when cornered, and uses Ten / Ren / Ken from {@link NenFighter}.
 */
public class ZenoEntity extends NenFighter {
    public static final NpcStats STATS = new NpcStats("zeno", Combat.NEN_EMISSION)
        .levels(100, 97, 98, 96)
        .body(180.0, 0.31, 0.4, 1.0f)
        .melee(1.0f, 2.5)
        .look("yellowaura_ten", 0xE8E8E8, 0x6B2FA0);

    private static final Random RND = new Random();
    private static final int DRAGON_LIFE_TICKS = 20 * 40; // a dragon that never gets to dive is sent away after this long

    private long blastReady, dragonReady, diveReady;
    private int chargeTicks = -1;       // >= 0 while gathering aura for the Dragon Head
    private UUID dragon;
    private int dragonAge;

    public ZenoEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, STATS);
    }

    @Override
    protected boolean hatsuBusy() {
        return chargeTicks >= 0;
    }

    @Override
    protected double preferredRange() {
        return 7.0;
    }

    @Override
    protected void onFightEnd() {
        chargeTicks = -1;
        dismissDragon();
    }

    @Override
    protected void onAuraGone() {
        chargeTicks = -1;
        dismissDragon();
    }

    @Override
    protected void tickHatsu(@Nullable LivingEntity target, boolean fighting) {
        if (!(level() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        DragonHeadEntity d = findDragon(level);

        if (!fighting || target == null) return;
        getLookControl().setLookAt(target, 60.0f, 60.0f);

        // ---- Dragon Head: the 3 second charge, then the pillar and the dragon ----
        if (chargeTicks >= 0) {
            chargeTicks++;
            double f = Math.min(1.0, chargeTicks / (double) Tuning.DRAGON_CHARGE_TICKS);
            for (int i = 0; i < 2 + (int) (4 * f); i++) {
                double a = random.nextDouble() * Math.PI * 2, r = 1.8 - 1.0 * f;
                level.sendParticles(ParticleTypes.WAX_ON, getX() + Math.cos(a) * r, getY() + random.nextDouble() * 2.0, getZ() + Math.sin(a) * r, 1, 0, 0.05, 0, 0.0);
            }
            if (lastHitAge() < 3 && getHealth() < getMaxHealth() * 0.25f) chargeTicks = -1; // nearly dead: the aura scatters
            else if (chargeTicks >= Tuning.DRAGON_CHARGE_TICKS) {
                chargeTicks = -1;
                summonDragon(level, now);
            }
            return;
        }

        // ---- the dragon is out: steer it, and dive when it is over the target ----
        if (d != null) {
            dragonAge++;
            d.setNpcGoal(target.position().add(0, target.getBbHeight() * 0.5, 0));
            double dist = d.centre().distanceTo(target.position());
            if (!d.isDiving() && now >= diveReady && dist < 25.0 && dragonAge > 60 && payAura(Tuning.DIVE_COST)) {
                diveReady = now + Tuning.DIVE_COOLDOWN_TICKS;
                dragonReady = now + Tuning.DIVE_RING_TICKS + Tuning.DIVE_DISSIPATE_TICKS + Tuning.DRAGON_COOLDOWN_TICKS;
                d.setNpcGoal(null);
                d.startDive();
                swingArm();
            } else if (!d.isDiving() && dragonAge > DRAGON_LIFE_TICKS) {
                dismissDragon();
            }
        }

        double dist = distanceTo(target);
        boolean los = hasLineOfSight(target);

        // ---- Dragon Head: summon it when the fight is not at arm's length ----
        if (d == null && dist > 5.0 && now >= dragonReady && los && canAfford(Tuning.DRAGON_COST + Tuning.BLAST_COST)) {
            if (payAura(Tuning.DRAGON_COST)) {
                chargeTicks = 0;
                getNavigation().stop();
                level.playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 1.2f, 0.7f);
                return;
            }
        }

        // ---- Aura Blast: the opener and the workhorse; at point blank it throws the target off him ----
        if (now >= blastReady && los && dist <= Tuning.BLAST_RANGE - 1.0 && payAura(Tuning.BLAST_COST)) {
            blastReady = now + Tuning.BLAST_COOLDOWN_TICKS + RND.nextInt(20);
            fireBlast(level, target);
        }
    }

    // =========================================================================================================
    // Dragon Head
    // =========================================================================================================

    private void summonDragon(ServerLevel level, long now) {
        swingArm();
        Vec3 at = position();
        AddonNetwork.sendToNear(new PacketPillarFx(at, Tuning.DRAGON_PILLAR_TICKS), level, at, 200);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 4.0f, 1.4f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 3.0f, 0.8f);
        DragonHeadEntity dh = new DragonHeadEntity(HxHEntities.DRAGON_HEAD.get(), level);
        dh.setOwner(getUUID());
        dh.moveTo(at.x, at.y + 0.5, at.z, getYRot(), 0f);
        level.addFreshEntity(dh);
        dragon = dh.getUUID();
        dragonAge = 0;
        dragonReady = now + Tuning.DRAGON_COOLDOWN_TICKS;
    }

    @Nullable
    private DragonHeadEntity findDragon(ServerLevel level) {
        if (dragon == null) return null;
        Entity e = level.getEntity(dragon);
        if (e instanceof DragonHeadEntity d && d.isAlive()) return d;
        dragon = null;
        return null;
    }

    private void dismissDragon() {
        if (dragon != null && level() instanceof ServerLevel sl && sl.getEntity(dragon) instanceof DragonHeadEntity d) {
            if (!d.isDiving()) d.dismiss(); // a dive already under way finishes: the arrows still fall
            else d.setNpcGoal(null);
        }
        dragon = null;
        dragonAge = 0;
    }

    // =========================================================================================================
    // Aura Blast (the player's AuraBlast.beam, run by an NPC: same cone, damage, knockback, ground breaking and visuals)
    // =========================================================================================================

    private void fireBlast(ServerLevel level, LivingEntity target) {
        swingArm();
        Vec3 aim = target.position().add(0, target.getBbHeight() * 0.5, 0);
        Vec3 eye = getEyePosition();
        Vec3 dir = aim.subtract(eye).normalize();
        double rad = Math.toRadians(getYRot());
        Vec3 right = new Vec3(-Math.cos(rad), 0, -Math.sin(rad));
        Vec3 origin = eye.add(right.scale(0.3)).add(0, -0.3, 0).add(dir.scale(0.4));
        float base = Tuning.BLAST_BASE_DAMAGE + stats().hatsu * Tuning.BLAST_DAMAGE_PER_LEVEL;
        base *= Affinity.projectile(nenType); // emitters: +15% projectile damage
        double range = Tuning.BLAST_RANGE;

        HitResult wall = level.clip(new ClipContext(origin, origin.add(dir.scale(range)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        double len = wall.getType() == HitResult.Type.MISS ? range : Math.max(1.0, wall.getLocation().distanceTo(origin));
        AddonNetwork.sendToTrackingAndSelf(new PacketBlastFx(getId(), origin, dir, (float) len, 0f, false), this);
        level.playSound(null, blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 1.6f, 0.8f);
        level.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.0f, 1.5f);

        Set<Long> broken = new HashSet<>();
        AABB box = new AABB(origin, origin.add(dir.scale(len))).inflate(AuraBlast.radiusAt(len) + 1.0);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, this::isFoe)) {
            Vec3 v = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(origin);
            double proj = v.dot(dir);
            if (proj < 0 || proj > len + 0.5) continue;
            double perp = v.subtract(dir.scale(proj)).length();
            if (perp > AuraBlast.radiusAt(proj) + e.getBbWidth() * 0.5) continue;
            float falloff = (float) (1.0 - 0.4 * proj / range);
            hatsuHurt(e, damageSources().mobAttack(this), base * falloff);
            Vec3 push = dir.scale(Tuning.BLAST_KNOCKBACK * falloff).add(0, 0.5, 0);
            e.push(push.x, push.y, push.z);
            e.hurtMarked = true;
            level.sendParticles(ParticleTypes.EXPLOSION, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 1, 0, 0, 0, 0);
            if (Tuning.BLAST_BREAK_GROUND) {
                BlockPos feet = e.blockPosition().below();
                for (int x = -1; x <= 1; x++) {
                    for (int z = -1; z <= 1; z++) breakColumn(level, feet.getX() + x, feet.getY() + 1, feet.getZ() + z, 3, broken);
                }
            }
        }
        if (Tuning.BLAST_BREAK_GROUND) {
            for (int t = 1; t <= (int) len && broken.size() < Tuning.BLAST_MAX_BLOCKS; t++) {
                Vec3 p = origin.add(dir.scale(t));
                int w = (int) Math.min(2, Math.ceil(AuraBlast.radiusAt(t) * 0.7));
                for (int x = -w; x <= w; x++) {
                    for (int z = -w; z <= w; z++) {
                        if (x * x + z * z > w * w + 1 || RND.nextFloat() > 0.8f) continue;
                        breakColumn(level, net.minecraft.util.Mth.floor(p.x) + x, net.minecraft.util.Mth.floor(p.y), net.minecraft.util.Mth.floor(p.z) + z, 4, broken);
                    }
                }
            }
        }
        Vec3 dm = getDeltaMovement(); // pushed back by his own blast
        setDeltaMovement(dm.x - dir.x * Tuning.BLAST_RECOIL * 0.5, dm.y + 0.1, dm.z - dir.z * Tuning.BLAST_RECOIL * 0.5);
        hurtMarked = true;
    }

    private static void breakColumn(ServerLevel level, int x, int topY, int z, int scan, Set<Long> broken) {
        if (broken.size() >= Tuning.BLAST_MAX_BLOCKS) return;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int y = topY; y > topY - scan; y--) {
            pos.set(x, y, z);
            if (!level.isInWorldBounds(pos)) return;
            BlockState st = level.getBlockState(pos);
            if (st.isAir() || !st.getFluidState().isEmpty()) continue;
            for (int depth = 0; depth < 2; depth++) {
                pos.set(x, y - depth, z);
                BlockState s2 = level.getBlockState(pos);
                if (s2.isAir() || !s2.getFluidState().isEmpty() || s2.getDestroySpeed(level, pos) < 0
                    || s2.getBlock().getExplosionResistance() > Tuning.BLAST_BLOCK_POWER || !broken.add(pos.asLong())) continue;
                if (RND.nextFloat() < 0.05f) net.minecraft.world.level.block.Block.dropResources(s2, level, pos);
                if (RND.nextFloat() < 0.15f) {
                    level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, s2), x + 0.5, y + 1.0, z + 0.5, 4, 0.3, 0.2, 0.3, 0.05);
                }
                level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            }
            return;
        }
    }
}
