package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registers Hisoka's attributes and spawn egg, and applies his Nen to the damage he deals and takes. */
public final class HisokaEvents {
    private HisokaEvents() {}

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class HisokaModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent e) {
            e.put(HxHEntities.HISOKA.get(), HisokaEntity.createAttributes().build());
        }

        @SubscribeEvent
        public static void creativeTab(BuildCreativeModeTabContentsEvent e) {
            if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) e.accept(HxHEntities.HISOKA_SPAWN_EGG.get());
        }
    }

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class HisokaGame {
        /** Same slot as the players' handler (AddonServerEvents.onHurt), run after it. */
        @SubscribeEvent(priority = EventPriority.LOW)
        public static void onHurt(LivingHurtEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide) return;
            DamageSource src = event.getSource();
            float amount = event.getAmount();
            Entity cause = src.getEntity();

            if (cause instanceof HisokaEntity h && h != victim) {
                if (src.getDirectEntity() == cause) h.gum.onMeleeHit(victim); // his hits build the gum up on the victim
                amount *= h.outgoingMult(src);
            }
            if (victim instanceof HisokaEntity h) amount *= h.incomingMult(src);
            event.setAmount(amount);
        }
    }
}
