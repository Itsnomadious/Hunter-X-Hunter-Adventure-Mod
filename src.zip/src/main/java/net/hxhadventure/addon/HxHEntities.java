package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** The addon's entity types (registered from HxHAdventure' constructor). */
public final class HxHEntities {
    private HxHEntities() {}

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, HxHAdventure.MOD_ID);

    /** Zeno's Dragon Head. Only the head has a hitbox (3.5 x 3.5); the 60 block body is drawn along the head's trail. */
    public static final RegistryObject<EntityType<DragonHeadEntity>> DRAGON_HEAD = ENTITIES.register("dragon_head",
        () -> EntityType.Builder.<DragonHeadEntity>of(DragonHeadEntity::new, MobCategory.MISC)
            .sized(3.5f, 3.5f)
            .fireImmune()
            .noSave()
            .clientTrackingRange(10)
            .updateInterval(1) // it moves ~2 blocks a tick: it needs a position update every tick to look smooth
            .build("dragon_head"));

    /** Hisoka, the Transmuter NPC (see HisokaEntity). */
    public static final RegistryObject<EntityType<HisokaEntity>> HISOKA = ENTITIES.register("hisoka",
        () -> EntityType.Builder.<HisokaEntity>of(HisokaEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f)
            .clientTrackingRange(64) // far enough to see his thread
            .build("hisoka"));

    /** A.P.R., Hakoware's banker mascot (see AprEntity). Starts the size of a small slime; the real size comes from its growth. */
    public static final RegistryObject<EntityType<AprEntity>> APR = ENTITIES.register("apr",
        () -> EntityType.Builder.<AprEntity>of(AprEntity::new, MobCategory.MISC)
            .sized(0.4f, 0.5f).fireImmune().noSave().noSummon().clientTrackingRange(12).updateInterval(1).build("apr"));

    /** I.R.S., the demon cat A.P.R. turns into when a debtor goes bankrupt (see IrsEntity). Saved with the world. */
    public static final RegistryObject<EntityType<IrsEntity>> IRS = ENTITIES.register("irs",
        () -> EntityType.Builder.<IrsEntity>of(IrsEntity::new, MobCategory.MISC)
            .sized(0.5f, 0.6f).fireImmune().noSummon().clientTrackingRange(10).updateInterval(2).build("irs"));

    /** A Hide and Seek circle (Knov): a ring of symbols on a block face that leads into a room of the Nen dimension. Saved with the world. */
    public static final RegistryObject<EntityType<HideSeekPortalEntity>> HIDE_SEEK_PORTAL = ENTITIES.register("hide_seek_portal",
        () -> EntityType.Builder.<HideSeekPortalEntity>of(HideSeekPortalEntity::new, MobCategory.MISC)
            .sized(2.0f, 2.0f).fireImmune().noSummon().clientTrackingRange(16).updateInterval(20).build("hide_seek_portal"));

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, HxHAdventure.MOD_ID);

    public static final RegistryObject<Item> HISOKA_SPAWN_EGG = ITEMS.register("hisoka_spawn_egg",
        () -> new ForgeSpawnEggItem(HISOKA, 0xD6489A, 0xF2D94E, new Item.Properties()));

    /** Neferpitou, the Chimera Ant captain NPC (see NeferpitouEntity). */
    public static final RegistryObject<EntityType<NeferpitouEntity>> NEFERPITOU = ENTITIES.register("neferpitou",
        () -> EntityType.Builder.<NeferpitouEntity>of(NeferpitouEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(96).updateInterval(1).build("neferpitou"));

    /** Terpsichora, the 5 block tall dancer (see TerpsichoraEntity). Used by both the Neferpitou NPC and the player ability. */
    public static final RegistryObject<EntityType<TerpsichoraEntity>> TERPSICHORA = ENTITIES.register("terpsichora",
        () -> EntityType.Builder.<TerpsichoraEntity>of(TerpsichoraEntity::new, MobCategory.MISC)
            .sized(1.6f, 5.0f).noSave().clientTrackingRange(64).updateInterval(2).build("terpsichora"));

    public static final RegistryObject<Item> NEFERPITOU_SPAWN_EGG = ITEMS.register("neferpitou_spawn_egg",
        () -> new ForgeSpawnEggItem(NEFERPITOU, 0xD9B48F, 0x2E1F16, new Item.Properties()));

    /** Gon, the Jajanken Enhancer NPC (see GonEntity). */
    public static final RegistryObject<EntityType<GonEntity>> GON = ENTITIES.register("gon",
        () -> EntityType.Builder.<GonEntity>of(GonEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f)
            .clientTrackingRange(96) // far enough to see his aura and the vow's black hair
            .updateInterval(1)
            .build("gon"));

    public static final RegistryObject<Item> GON_SPAWN_EGG = ITEMS.register("gon_spawn_egg",
        () -> new ForgeSpawnEggItem(GON, 0x3E8E3E, 0x1B1B1B, new Item.Properties()));

    /** Hina, the Nen exorcist NPC (see HinaEntity): lifts Conditions, Limitations and Vows. */
    public static final RegistryObject<EntityType<HinaEntity>> HINA = ENTITIES.register("hina",
        () -> EntityType.Builder.<HinaEntity>of(HinaEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(64).build("hina"));

    public static final RegistryObject<Item> HINA_SPAWN_EGG = ITEMS.register("hina_spawn_egg",
        () -> new ForgeSpawnEggItem(HINA, 0xF4B6D8, 0xE8C84A, new Item.Properties()));

    /** Chrollo, the Specialist (Skill Hunter) NPC (see ChrolloEntity). */
    public static final RegistryObject<EntityType<ChrolloEntity>> CHROLLO = ENTITIES.register("chrollo",
        () -> EntityType.Builder.<ChrolloEntity>of(ChrolloEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(64).build("chrollo"));

    /** A Bystander conjured by Chrollo's Gallery Fake page (see BystanderEntity). Not saved: they fade with the fight. */
    public static final RegistryObject<EntityType<BystanderEntity>> BYSTANDER = ENTITIES.register("bystander",
        () -> EntityType.Builder.<BystanderEntity>of(BystanderEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).noSave().clientTrackingRange(48).build("bystander"));

    /** Cookie, the masseuse Biscuit Krueger's Magical Esthetician summons (see CookieEntity). Never saved: she is gone with the skill. */
    public static final RegistryObject<EntityType<CookieEntity>> COOKIE = ENTITIES.register("cookie",
        () -> EntityType.Builder.<CookieEntity>of(CookieEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).noSave().clientTrackingRange(64).build("cookie"));

    /** Laplace Devil (Tserriednich): the Devil above the dome. Never moves, not saved (see LaplaceDevilEntity). */
    public static final RegistryObject<EntityType<LaplaceDevilEntity>> LAPLACE_DEVIL = ENTITIES.register("laplace_devil",
        () -> EntityType.Builder.<LaplaceDevilEntity>of(LaplaceDevilEntity::new, MobCategory.MISC)
            .sized(4.0f, 14.0f).fireImmune().noSave().noSummon().clientTrackingRange(24).updateInterval(20).build("laplace_devil"));

    /** The user's double inside a Laplace Devil dome (see LaplaceDoubleEntity). Not saved: it goes with the domain. */
    public static final RegistryObject<EntityType<LaplaceDoubleEntity>> LAPLACE_DOUBLE = ENTITIES.register("laplace_double",
        () -> EntityType.Builder.<LaplaceDoubleEntity>of(LaplaceDoubleEntity::new, MobCategory.MISC)
            .sized(0.6f, 1.8f).noSave().noSummon().clientTrackingRange(16).build("laplace_double"));

    /** A smoke monster summoned by Deep Purple (see SmokeMonsterEntity). Not saved: it goes with its owner. */
    public static final RegistryObject<EntityType<SmokeMonsterEntity>> SMOKE_MONSTER = ENTITIES.register("smoke_monster",
        () -> EntityType.Builder.<SmokeMonsterEntity>of(SmokeMonsterEntity::new, MobCategory.MISC)
            .sized(0.6f, 2.0f).fireImmune().noSave().noSummon().clientTrackingRange(48).build("smoke_monster"));

    /** A clone of the user summoned by Deep Purple (see SmokeCloneEntity). Same stats as a smoke monster. */
    public static final RegistryObject<EntityType<SmokeCloneEntity>> SMOKE_CLONE = ENTITIES.register("smoke_clone",
        () -> EntityType.Builder.<SmokeCloneEntity>of(SmokeCloneEntity::new, MobCategory.MISC)
            .sized(0.6f, 1.8f).fireImmune().noSave().noSummon().clientTrackingRange(48).build("smoke_clone"));

    /** Crazy Slots' clown (Kite's Hatsu, see CrazySlotsEntity). Not saved: it goes with its owner or the weapon it turns into. */
    public static final RegistryObject<EntityType<CrazySlotsEntity>> CRAZY_SLOTS = ENTITIES.register("crazy_slots",
        () -> EntityType.Builder.<CrazySlotsEntity>of(CrazySlotsEntity::new, MobCategory.MISC)
            .sized(0.9f, 1.3f).fireImmune().noSave().noSummon().clientTrackingRange(24).updateInterval(1).build("crazy_slots"));

    public static final RegistryObject<Item> CHROLLO_SPAWN_EGG = ITEMS.register("chrollo_spawn_egg",
        () -> new ForgeSpawnEggItem(CHROLLO, 0x1B1B1B, 0xC9C2B0, new Item.Properties()));

    // ---- Nen-fighter NPCs (see NenFighter) ----
    public static final RegistryObject<EntityType<NeteroEntity>> NETERO = ENTITIES.register("netero",
        () -> EntityType.Builder.<NeteroEntity>of(NeteroEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(96).updateInterval(1).build("netero"));
    public static final RegistryObject<Item> NETERO_SPAWN_EGG = ITEMS.register("netero_spawn_egg",
        () -> new ForgeSpawnEggItem(NETERO, NeteroEntity.STATS.eggPrimary, NeteroEntity.STATS.eggSecondary, new Item.Properties()));
    public static final RegistryObject<EntityType<ZenoEntity>> ZENO = ENTITIES.register("zeno",
        () -> EntityType.Builder.<ZenoEntity>of(ZenoEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(96).updateInterval(1).build("zeno"));
    public static final RegistryObject<Item> ZENO_SPAWN_EGG = ITEMS.register("zeno_spawn_egg",
        () -> new ForgeSpawnEggItem(ZENO, ZenoEntity.STATS.eggPrimary, ZenoEntity.STATS.eggSecondary, new Item.Properties()));
    public static final RegistryObject<EntityType<SilvaEntity>> SILVA = ENTITIES.register("silva",
        () -> EntityType.Builder.<SilvaEntity>of(SilvaEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(96).updateInterval(1).build("silva"));
    public static final RegistryObject<Item> SILVA_SPAWN_EGG = ITEMS.register("silva_spawn_egg",
        () -> new ForgeSpawnEggItem(SILVA, SilvaEntity.STATS.eggPrimary, SilvaEntity.STATS.eggSecondary, new Item.Properties()));
    public static final RegistryObject<EntityType<BiskyEntity>> BISKY = ENTITIES.register("bisky",
        () -> EntityType.Builder.<BiskyEntity>of(BiskyEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(96).updateInterval(1).build("bisky"));
    public static final RegistryObject<Item> BISKY_SPAWN_EGG = ITEMS.register("bisky_spawn_egg",
        () -> new ForgeSpawnEggItem(BISKY, BiskyEntity.STATS.eggPrimary, BiskyEntity.STATS.eggSecondary, new Item.Properties()));
    public static final RegistryObject<EntityType<IllumiEntity>> ILLUMI = ENTITIES.register("illumi",
        () -> EntityType.Builder.<IllumiEntity>of(IllumiEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(96).updateInterval(1).build("illumi"));
    public static final RegistryObject<Item> ILLUMI_SPAWN_EGG = ITEMS.register("illumi_spawn_egg",
        () -> new ForgeSpawnEggItem(ILLUMI, IllumiEntity.STATS.eggPrimary, IllumiEntity.STATS.eggSecondary, new Item.Properties()));
    public static final RegistryObject<EntityType<KurapikaEntity>> KURAPIKA = ENTITIES.register("kurapika",
        () -> EntityType.Builder.<KurapikaEntity>of(KurapikaEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(96).updateInterval(1).build("kurapika"));
    public static final RegistryObject<Item> KURAPIKA_SPAWN_EGG = ITEMS.register("kurapika_spawn_egg",
        () -> new ForgeSpawnEggItem(KURAPIKA, KurapikaEntity.STATS.eggPrimary, KurapikaEntity.STATS.eggSecondary, new Item.Properties()));
    public static final RegistryObject<EntityType<KilluaEntity>> KILLUA = ENTITIES.register("killua",
        () -> EntityType.Builder.<KilluaEntity>of(KilluaEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(96).updateInterval(1).build("killua"));
    public static final RegistryObject<Item> KILLUA_SPAWN_EGG = ITEMS.register("killua_spawn_egg",
        () -> new ForgeSpawnEggItem(KILLUA, KilluaEntity.STATS.eggPrimary, KilluaEntity.STATS.eggSecondary, new Item.Properties()));

    // ---- Hunter Exam NPCs (see ExamNpcEntity, HunterExam) ----
    public static final RegistryObject<EntityType<ExamReceptionistEntity>> EXAM_RECEPTIONIST = ENTITIES.register("exam_receptionist",
        () -> EntityType.Builder.<ExamReceptionistEntity>of(ExamReceptionistEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(64).build("exam_receptionist"));
    public static final RegistryObject<EntityType<MenchiEntity>> MENCHI = ENTITIES.register("menchi",
        () -> EntityType.Builder.<MenchiEntity>of(MenchiEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(64).build("menchi"));
    /** A test taker of Menchi's free-for-all (see ExamTakerEntity, ExamBattle). Never saved: they only exist while the test runs. */
    public static final RegistryObject<EntityType<ExamTakerEntity>> EXAM_TAKER = ENTITIES.register("exam_taker",
        () -> EntityType.Builder.<ExamTakerEntity>of(ExamTakerEntity::new, MobCategory.MISC)
            .sized(0.6f, 1.8f).noSave().clientTrackingRange(64).build("exam_taker"));
    /** A Nen user among Menchi's test takers (see ExamNenTakerEntity). Never saved. */
    public static final RegistryObject<EntityType<ExamNenTakerEntity>> EXAM_NEN_TAKER = ENTITIES.register("exam_nen_taker",
        () -> EntityType.Builder.<ExamNenTakerEntity>of(ExamNenTakerEntity::new, MobCategory.MISC)
            .sized(0.6f, 1.8f).noSave().clientTrackingRange(64).build("exam_nen_taker"));
    public static final RegistryObject<EntityType<SatotzEntity>> SATOTZ = ENTITIES.register("satotz",
        () -> EntityType.Builder.<SatotzEntity>of(SatotzEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(64).build("satotz"));
    /** The Hunter Exam guide that stands in every village and points to the nearest exam hall (see ExamGuideEntity, VillageGuides). */
    public static final RegistryObject<EntityType<ExamGuideEntity>> EXAM_GUIDE = ENTITIES.register("exam_guide",
        () -> EntityType.Builder.<ExamGuideEntity>of(ExamGuideEntity::new, MobCategory.CREATURE)
            .sized(0.6f, 1.8f).clientTrackingRange(64).build("exam_guide"));
    public static final RegistryObject<Item> EXAM_GUIDE_SPAWN_EGG = ITEMS.register("exam_guide_spawn_egg",
        () -> new ForgeSpawnEggItem(EXAM_GUIDE, 0x3B6E3B, 0xE8D9A0, new Item.Properties()));
}
