package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketHinaOpen;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Hina, the Nen exorcist (NPC). She never fights and cannot be hurt. Right-click her and she asks whether you want every Nen Condition, Limitation and Vow removed; on yes the ritual plays and they are all lifted,
 * then she needs an hour to recover (see Exorcism).
 */
public class HinaEntity extends PathfinderMob implements GeoEntity, NpcPose {
    private static final net.minecraft.network.syncher.EntityDataAccessor<Boolean> ARMS_OUT =
        net.minecraft.network.syncher.SynchedEntityData.defineId(HinaEntity.class, net.minecraft.network.syncher.EntityDataSerializers.BOOLEAN);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public HinaEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 40.0)
            .add(Attributes.MOVEMENT_SPEED, 0.25);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ARMS_OUT, false);
    }

    @Override
    public boolean armsOut() {
        return this.entityData.get(ARMS_OUT);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    /** She is a healer, not a fighter: only creative players (and /kill) can remove her. */
    @Override
    public boolean isInvulnerableTo(DamageSource src) {
        return !src.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY) && !src.isCreativePlayer();
    }

    /** Safety net: if she is posed for a ritual that is no longer running (an error, a logout, a reload), she is released. */
    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.tickCount % 20 == 0 && this.entityData.get(ARMS_OUT) && !Exorcism.hasRitualFor(this.getUUID())) {
            endRitual();
        }
    }

    /** The ritual starts: she stops walking and holds out her hand (Kite's "awaken" clip). */
    public void beginRitual() {
        this.getNavigation().stop();
        this.setNoAi(true);
        this.entityData.set(ARMS_OUT, true); // hand out, pressed to their back
    }

    public void endRitual() {
        this.entityData.set(ARMS_OUT, false);
        this.setNoAi(false);
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return super.mobInteract(player, hand);
        if (!this.level().isClientSide && player instanceof ServerPlayer sp && !Exorcism.inRitual(sp)) {
            AddonNetwork.sendToPlayer(new PacketHinaOpen(this.getId(), Exorcism.cooldownLeft(sp), JudgmentChain.hasStake(sp)), sp);
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    @Override
    public void registerControllers(ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement_controller", 1, event -> {
            if (this.isInWater()) return PlayState.STOP;
            if (event.isMoving()) {
                event.getController().setAnimationSpeed(1.0);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.walk"));
            }
            event.getController().setAnimationSpeed(0.5);
            return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.idle"));
        }));
        controllers.add(new AnimationController<>(this, "attack_controller", 1, state -> PlayState.STOP)
            .triggerableAnim("awaken", RawAnimation.begin().thenPlay("awaken")));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
}
