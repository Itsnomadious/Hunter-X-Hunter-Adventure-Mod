package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** The addon's sound events (registered from HxHAdventure's constructor). The files are in assets/hxhadventure/sounds and sounds.json. */
public final class HxHSounds {
    private HxHSounds() {}

    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, HxHAdventure.MOD_ID);

    /**
     * One full cycle of Gon's adult-form Rock orb ({@link GonVow#CYCLE_TICKS} ticks long): quiet, then the high-pitched surge as the
     * aura expands, then the long fade as it contracts back to the smallest size. {@link GonVow#ENVELOPE} was measured from this
     * same clip, so the orb on screen follows the sound.
     */
    public static final RegistryObject<SoundEvent> GON_VOW_ORB = SOUNDS.register("gon_vow_orb",
        () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(HxHAdventure.MOD_ID, "gon_vow_orb")));

    /** The sound of Ren going up (not played during it): fades out gradually instead of cutting off. */
    public static final RegistryObject<SoundEvent> REN = SOUNDS.register("ren",
        () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(HxHAdventure.MOD_ID, "ren")));

    /** Ren going up with the aura set to {@link Tuning#REN_BIG_SOUND_SIZE} or bigger: also fades out gradually. */
    public static final RegistryObject<SoundEvent> REN_BIG = SOUNDS.register("ren_big",
        () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(HxHAdventure.MOD_ID, "ren_big")));
}
