package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks for {@link ExamBattle}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ExamBattleEvents {
    private ExamBattleEvents() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) ExamBattle.serverTick(ServerLifecycleHooks.getCurrentServer());
    }

    /** Last, and not for a death another handler refused, so only a real death loses the test. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ExamBattle.onPlayerDeath(sp);
    }

    /** Test takers hit each other for half. Last, so it applies on top of every other multiplier (Nen included). */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onHurt(LivingHurtEvent e) {
        if (e.getEntity() instanceof ExamContestant && e.getSource().getEntity() instanceof ExamContestant) {
            e.setAmount(e.getAmount() * ExamBattle.CONTESTANT_DAMAGE);
        }
    }

    /** A contestant went down: counts for the player when they were the one who did it. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onContestantDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ExamContestant c && c.battleId() != null && e.getSource().getEntity() instanceof ServerPlayer sp) {
            ExamBattle.onPlayerKill(sp, c.battleId());
        }
    }

    /** The client needs the exam stage to know which O menu to open. */
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) HunterExam.sync(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ExamBattle.onLogout(sp);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        ExamBattle.reset();
    }
}
