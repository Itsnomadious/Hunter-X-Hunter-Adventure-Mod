package net.hxhadventure.addon;

/** All balance numbers in one place. */
public final class Tuning {
    private Tuning() {}

    public static final int EN_MIN_HATSU_LEVEL = 5;

    // Emperor Time
    public static final int EMPEROR_MIN_LEVEL = 30;
    public static final float LIFESPAN_MAX = 100f;        // years of life a fresh character has
    public static final float HOURS_PER_YEAR = 365.25f * 24f; // 8766
    public static final float EMPEROR_YEARS_PER_SECOND = 1f / HOURS_PER_YEAR; // every second of Emperor Time takes 1 hour off the user's life
    /** Years left at which an Emperor Time (or the vow) that is draining lifespan counts as having run dry. */
    public static final float LIFESPAN_EMPTY = 1e-6f;
    public static final float AGE_MAX_HP_LOSS = 0f;       // losing lifespan no longer lowers max health (Emperor Time and Gon's vow). Was 0.5: at 0 years left, max health cut by half
    public static final int EMPEROR_COOLDOWN_TICKS = 600;
    /** Emperor Time: damage dealt, movement speed and durability (damage taken is divided by this) are all multiplied by this, on top of everything else. */
    public static final float EMPEROR_BOOST = 1.5f;
    public static final float EMPEROR_CHAIN_BOOST = 1.5f; // chains hit/heal/hold harder during Emperor Time
    // Doctor Blythe (Neferpitou's specialist doll, Hatsu kit 10)
    public static final int BLYTHE_MIN_LEVEL = 10;
    public static final float BLYTHE_SUMMON_COST = 200f;
    public static final float BLYTHE_UPKEEP = 15f;              // energy per second while Blythe is out
    public static final float BLYTHE_HEAL_COST = 2.5f;          // energy per injured target per pulse
    public static final int BLYTHE_COOLDOWN_TICKS = 100;        // after it leaves, before it can be summoned again
    public static final int BLYTHE_PULSE_TICKS = 10;            // heal pulse interval; must be a multiple of 5
    public static final double BLYTHE_BEHIND = 1.3;             // Blythe is planted this far behind the user's back
    public static final double BLYTHE_REACH = 5.0;              // radius of the zone its fingers can touch
    public static final double BLYTHE_TETHER_RANGE = 20.0;      // the tail snaps (Blythe is lost) beyond this distance
    public static final int BLYTHE_MAX_TARGETS = 10;            // one tendril per finger
    public static final boolean BLYTHE_HEALS_ENEMIES = false;   // true: heals anything its fingers touch, not just allies and the user

    /** Health restored to each touched target per pulse: about 1.5 HP/s at level 1, 5.5 HP/s at level 100. */
    public static float blytheHealPerPulse(int level) {
        return (1.5f + level * 0.04f) * (BLYTHE_PULSE_TICKS / 20f);
    }

    // Terpsichora (Neferpitou's second Hatsu, also kit 10, Specialists)
    public static final int TERPSI_MIN_LEVEL = 40;
    public static final float TERPSI_SUMMON_COST = 300f;
    public static final int TERPSI_BUFF_TICKS = 1200;           // how long the buffs last once Terpsichora has been called (1 minute)
    /** The caster cannot move for this long when Terpsichora is summoned (0.5 s). */
    public static final int TERPSI_FREEZE_TICKS = 10;
    public static final int TERPSI_FLASH_TICKS = 20;            // how long the figure itself stays out when called (1 second)
    public static final int TERPSI_COOLDOWN_TICKS = 600;        // after the buffs end, before it can be called again
    public static final float TERPSI_BOOST = 1.8f;              // movement speed and damage dealt while it is active
    public static final float TERPSI_DEAD_BOOST = 2.5f;         // post-mortem: REPLACES the 1.8x (not stacked on it)
    public static final int TERPSI_DEAD_TICKS = 600;            // how long the corpse keeps fighting (30 s)
    public static final float TERPSI_REVIVE_HEALTH = 0.5f;      // fraction of max health the corpse is raised with

    // Aura Blast (Zeno's emitter technique, Hatsu kit 12)
    public static final int BLAST_MIN_LEVEL = 15;
    public static final float BLAST_COST = 125f;
    public static final int BLAST_COOLDOWN_TICKS = 40;          // short: two seconds
    public static final double BLAST_RANGE = 16.0;              // blocks; the blast stops at the first wall
    public static final float BLAST_BASE_DAMAGE = 18f;          // good damage, not a kill: ~9 hearts before level, falloff, armour
    public static final float BLAST_DAMAGE_PER_LEVEL = 0.3f;
    public static final float BLAST_KNOCKBACK = 2.2f;
    public static final double BLAST_RECOIL = 0.5;              // how hard it pushes the user back
    public static final boolean BLAST_BREAK_GROUND = true;      // false: damage and knockback only
    public static final float BLAST_BLOCK_POWER = 15f;          // ground with blast resistance above this survives (stone 6, obsidian 1200)
    public static final int BLAST_MAX_BLOCKS = 500;             // cap on blocks removed per blast

    // Dragon Head (Zeno's second ability, also Hatsu kit 12)
    public static final int DRAGON_MIN_LEVEL = 25;
    public static final float DRAGON_COST = 400f;              // paid when the beam is fired
    public static final int DRAGON_CHARGE_TICKS = 60;          // hold Z this long, release to fire the beam and summon it
    public static final int DRAGON_COOLDOWN_TICKS = 100;       // after it is dismissed
    public static final int DRAGON_PILLAR_TICKS = 40;          // how long the golden beam into the sky lasts
    public static final double DRAGON_LENGTH = 60.0;           // blocks, head to tail (3x the original 20)
    public static final double DRAGON_THICKNESS = 1.5;         // body and head size multiplier (1.0 = the original thickness)
    public static final double DRAGON_SPEED = 1.9;             // blocks per tick at full speed: about 4x a horse (~0.48 blocks/tick)
    public static final int DRAGON_MAX_RIDERS = 5;
    public static final float DRAGON_RAM_DAMAGE = 14f;         // to enemies the head ploughs into at speed (0 = harmless)

    // Dragon Dive (Zeno's third ability: the dragon coils into rings, dissipates, and golden arrows rain down)
    public static final float DIVE_COST = 600f;               // 1.5x Dragon Head's cost, on the same scale
    public static final int DIVE_COOLDOWN_TICKS = 600;
    public static final int DIVE_RING_TICKS = 50;              // the dragon coils into concentric rings
    public static final int DIVE_DISSIPATE_TICKS = 20;         // the rings burst apart; the rain starts when this ends
    public static final double DIVE_RADIUS = 100.0;            // blocks around the dragon's head
    public static final int DIVE_ARROWS = 700;                 // total arrows in one dive
    public static final int DIVE_RAIN_TICKS = 100;             // they fall spread over this long
    public static final double DIVE_ARROW_SPEED = 3.0;         // blocks per tick
    public static final double DIVE_ARROW_HEIGHT = 45.0;       // they start this far above the ground they hit
    public static final double DIVE_TARGETED = 0.3;            // fraction of arrows aimed at nearby enemies (the rest land at random)
    public static final float DIVE_ARROW_DAMAGE = 14f;
    public static final double DIVE_HIT_RADIUS = 3.0;
    public static final boolean DIVE_BREAK_BLOCKS = true;
    public static final int DIVE_CRATER_RADIUS = 2;            // blocks removed around each impact
    public static final float DIVE_BLOCK_POWER = 30f;          // blocks with blast resistance above this survive (obsidian 1200)
    public static final int DIVE_MAX_BLOCKS_PER_TICK = 400;    // server safety cap

    // Explosive Orbs (Silva's emitter technique, Hatsu kit 11)
    public static final int ORBS_MIN_LEVEL = 20;
    public static final float ORBS_COST = 300f;                 // paid when you start charging
    public static final float ORBS_UPKEEP = 20f;                // energy per second while hovering
    public static final int ORBS_COOLDOWN_TICKS = 300;
    public static final double ORBS_RISE = 5.0;                 // blocks you levitate while charging
    public static final double ORBS_FORWARD = 2.0;              // blocks you also drift forward while rising
    public static final int ORBS_CHARGE_TICKS = 80;             // time to reach full size
    public static final float ORBS_MIN_THROW = 0.3f;            // releasing Z below this charge just disperses the orbs
    public static final float ORBS_MAX_RADIUS = 1.5f;           // each orb's radius at full charge (blocks)
    public static final double ORBS_SPEED = 1.6;                // blocks per tick
    public static final int ORBS_LIFE_TICKS = 80;               // an orb that hits nothing explodes after this long
    public static final float ORBS_BLAST_RADIUS = 9f;           // blast radius of one full orb
    public static final float ORBS_BASE_DAMAGE = 45f;           // per orb at the centre, before level, charge and falloff
    public static final float ORBS_DAMAGE_PER_LEVEL = 0.5f;
    public static final float ORBS_KNOCKBACK = 2.5f;
    public static final boolean ORBS_BREAK_BLOCKS = true;       // false: damage only, no crater
    /** Blast "strength" at the centre; a block is destroyed where strength * (1 - distance / radius) >= its blast resistance. Stone is 6, obsidian 1200. */
    public static final float ORBS_BLOCK_POWER = 60f;

    // Bungee Gum (Hisoka's transmuter technique, Hatsu kit 13). Z throws the thread; Z again reels the target in, Shift+Z pulls you to it.
    public static final int GUM_MIN_LEVEL = 5;
    public static final float GUM_THROW_COST = 50f;             // paid when the thread is thrown
    public static final float GUM_REEL_COST = 200f;             // paid when you reel a block / object in (Z on an attached thread)
    public static final float GUM_PULL_COST = 100f;             // paid when you pull yourself to it (Shift+Z)
    public static final double GUM_RANGE = 32.0;                // how far the thread flies before it falls short
    public static final double GUM_SPEED = 3.0;                 // blocks per tick
    public static final int GUM_HOLD_TICKS = 200;               // an attached thread snaps by itself after this long
    public static final double GUM_SNAP_LENGTH = 48.0;          // ...or if it is stretched past this many blocks
    public static final int GUM_MISS_COOLDOWN_TICKS = 10;       // thread fell short, was recalled or snapped
    public static final int GUM_PULL_COOLDOWN_TICKS = 20;       // after pulling yourself in
    public static final int GUM_SLAM_COOLDOWN_TICKS = 60;      // after a full reel / spin / slam
    // reel: the object is dragged in, swung around the user, then smashed down in front of them
    public static final double GUM_ORBIT_RADIUS = 5.5;          // blocks from the user while it spins
    public static final int GUM_PULL_IN_MAX_TICKS = 30;         // longest the reel-in part may take
    public static final int GUM_SPIN_TICKS = 40;                // how long it is swung around
    public static final double GUM_SPIN_SPEED = 0.9;            // radians per tick
    public static final float GUM_SPIN_DAMAGE = 3f;             // to anything the spinning object sweeps into, before level
    public static final int GUM_SPIN_HIT_GAP = 10;              // ticks before the same victim can be swept again
    public static final double GUM_SPIN_HIT_RADIUS = 2.2;
    public static final double GUM_SLAM_DISTANCE = 5.0;         // the slam lands this far in front of the user
    public static final double GUM_SLAM_HEIGHT = 4.5;           // how high the object is raised first
    public static final int GUM_LIFT_TICKS = 6;
    public static final double GUM_SLAM_SPEED = 2.6;            // blocks per tick on the way down
    public static final double GUM_SLAM_RADIUS = 4.5;
    public static final float GUM_SLAM_DAMAGE = 16f;            // at the centre, before level and falloff
    public static final float GUM_DAMAGE_PER_LEVEL = 0.25f;
    public static final float GUM_SLAM_KNOCKBACK = 1.6f;
    public static final float GUM_BLOCK_POWER = 30f;            // blocks with more blast resistance cannot be torn loose (obsidian 1200)
    public static final boolean GUM_BLOCK_DROPS = true;         // a slammed block shatters and drops what mining it would
    // pulling yourself in
    public static final double GUM_PULL_SPEED = 3.0;            // blocks per tick at full speed
    public static final int GUM_PULL_MAX_TICKS = 50;
    // "Properties of Rubber and Gum": the debuff that slowly builds up on whatever a Bungee Gum user hits
    public static final float GUM_BUILDUP_MELEE = 20f;          // per melee hit by the user
    public static final float GUM_BUILDUP_THREAD = 20f;         // the thread sticking to it
    public static final float GUM_BUILDUP_SPIN = 12f;           // swept by the spinning object
    public static final float GUM_BUILDUP_SLAM = 40f;           // caught in the slam
    public static final float GUM_BUILDUP_MAX = 100f;
    public static final float[] GUM_STAGES = {20f, 45f, 70f, 100f}; // build-up needed for stage I..IV of the debuff
    public static final double GUM_SLOW_PER_STAGE = 0.10;       // movement speed lost per stage (stage IV = 40% slower)
    public static final int GUM_DECAY_DELAY_TICKS = 160;        // build-up starts draining this long after the last hit...
    public static final float GUM_DECAY_PER_SECOND = 2f;        // ...at this rate, so it lingers for around 50 s from full
    public static final double GUM_TETHER_RANGE = 50.0;         // a debuffed target cannot get further than this from the user (the tether is only visible with Gyo)
    public static final double GUM_TETHER_SNAP_OVER = 10.0;     // flung / teleported this far past the range: snapped straight back
    // Tether Pull (second skill): Z drags the tethered target to you and hits it hard
    public static final int GUM_PULL_MIN_LEVEL = 10;
    public static final float GUM_YANK_COST = 250f;
    public static final int GUM_YANK_COOLDOWN_TICKS = 0;
    public static final int GUM_YANK_MAX_TICKS = 40;            // longest the drag may take
    public static final float GUM_YANK_DAMAGE = 22f;            // the blow, before level and affinity
    public static final float GUM_YANK_PER_LEVEL = 0.4f;
    public static final float GUM_YANK_KNOCKBACK = 1.8f;
    public static final float GUM_BUILDUP_YANK = 30f;
    // Cards (third skill): Z throws three nen-coated cards; Shift+Z throws a whole deck up, Z again sends it at the nearest tethered target
    public static final double GUM_PULL_START_SPEED = 1.2;      // Shift+Z: the first tick of the pull-in...
    public static final double GUM_PULL_RAMP = 0.7;             // ...then this much faster every tick, up to GUM_PULL_SPEED
    public static final double GUM_SPIN_FOLLOW_SPEED = 7.0;     // the spinning object can move this far per tick (wide + fast orbit)

    // ---- Bungee Gum state (H): -10% damage taken, and anyone who melees the user gets Rubber and Gum ----
    public static final float GUM_STATE_DAMAGE_TAKEN = 0.90f;
    public static final int GUM_STATE_MIN_LEVEL = 5;
    public static final float GUM_BUILDUP_BIND = 40f;           // Bungee Bind sticks this much gum on its victim
    public static final int GUM_DRAWN_GRACE_TICKS = 4;          // someone being dragged in cannot attack for this long after the last tick of it

    // ---- Playing Card item (replaces the Cards move) ----
    public static final float PLAYING_CARD_DAMAGE = 3f;         // base, before Ten / Ren / Ken scaling (applied like any other hit the player lands)
    public static final double PLAYING_CARD_SPEED = 2.4;        // blocks per tick
    public static final int PLAYING_CARD_LIFE = 30;             // ticks in flight
    public static final int PLAYING_CARD_STICK_TICKS = 400;     // a card thrown in Bungee Gum state stays stuck where it landed this long (Tether Pull brings it back)
    public static final double PLAYING_CARD_RETURN_SPEED = 2.6;
    public static final int PLAYING_CARD_COOLDOWN_TICKS = 6;

    // ---- Bungee Barrier ----
    public static final int BARRIER_MIN_LEVEL = 20;
    public static final float BARRIER_COST = 150f;
    public static final int BARRIER_MAX_TICKS = 200;            // held up for 10 s at most, then it lets go by itself
    public static final int BARRIER_COOLDOWN_TICKS = 100;
    public static final double BARRIER_DISTANCE = 2.4;          // in front of the user
    public static final double BARRIER_HALF_WIDTH = 2.5;
    public static final double BARRIER_HALF_HEIGHT = 1.8;
    public static final double BARRIER_THICKNESS = 0.7;
    public static final int BARRIER_MAX_CAUGHT = 32;
    public static final double BARRIER_RETURN_SPEED = 2.2;      // minimum speed of a projectile fired back (1.5x its caught speed if faster)
    public static final double BARRIER_RETURN_RANGE = 64.0;

    // ---- Bungee Bind ----
    public static final int BIND_MIN_LEVEL = 25;
    public static final float BIND_COST = 150f;
    public static final double BIND_RANGE = 2.0;                // "within 2 blocks"
    public static final int BIND_TICKS = 120;                   // 6 seconds
    public static final int BIND_COOLDOWN_TICKS = 300;

    public static final int CARDS_MIN_LEVEL = 15;
    public static final float CARD_COST = 60f;
    public static final int CARD_COOLDOWN_TICKS = 25;
    public static final double CARD_SPEED = 2.2;                // blocks per tick
    public static final int CARD_LIFE = 30;
    public static final double CARD_SPREAD_DEG = 5.0;           // between the three cards
    public static final float CARD_DAMAGE = 5f;                 // per card ("mediocre"), before level and affinity
    public static final float CARD_DAMAGE_PER_LEVEL = 0.1f;
    public static final float GUM_BUILDUP_CARD = 20f;           // per card thrown in Bungee Gum state that hits: the same as a melee hit, so it tethers the same
    public static final float CARD_DECK_COST = 300f;
    public static final int CARD_DECK_SIZE = 52;
    public static final int CARD_DECK_TICKS = 140;              // how long the deck hangs and falls before it fades
    public static final int CARD_DECK_COOLDOWN_TICKS = 240;
    public static final double CARD_DART_SPEED = 2.4;
    public static final int CARD_DART_STAGGER = 14;             // cards leave over this many ticks, so they stream rather than clump
    public static final int CARD_DART_LIFE = 90;
    public static final float CARD_DART_DAMAGE = 1.2f;          // per card of the deck, before level and affinity
    public static final float CARD_DART_PER_LEVEL = 0.025f;
    public static final float GUM_BUILDUP_DART = 1f;            // per deck card that hits

    // Max Nen: grows with player level and with the Ten and Ren skills, and the growth speeds up as you get stronger.
    //   s       = 0.6 * level + 0.2 * (Ten - 1) + 0.2 * (Ren - 1)      ("Nen power": about equal to the level when Ten and Ren match it)
    //   maxNen  = NEN_BASE + NEN_CURVE * s^2
    // Targets this is tuned to:  level 60 + Ten 60 + Ren 60  ->  about 30,000
    //                            level 100 + Ten 100 + Ren 100 -> about 80,000
    // (Vows / limitations multiply or add on top of this and are free to go past it; there is no hard cap here.)
    public static final float NEN_BASE = 2000f;          // what a level 1 character has (about 2,000)
    public static final float NEN_CURVE = 7.87f;         // multiplier on s squared
    public static final float NEN_LEVEL_WEIGHT = 0.6f;   // share of s that comes from player level
    public static final float NEN_TEN_WEIGHT = 0.2f;     // ... from each Ten skill level above 1
    public static final float NEN_REN_WEIGHT = 0.2f;     // ... from each Ren skill level above 1

    /** Level 60 + Ten 60 + Ren 60 = about 30,000. Level 100 + Ten 100 + Ren 100 = about 80,000. */
    public static float maxNen(int level, int tenLevel, int renLevel) {
        float s = NEN_LEVEL_WEIGHT * level
            + NEN_TEN_WEIGHT * Math.max(0, tenLevel - 1)
            + NEN_REN_WEIGHT * Math.max(0, renLevel - 1);
        return NEN_BASE + NEN_CURVE * s * s;
    }

    /**
     * The player formula as it was before the rescale above (1000 + 600/level + 200 per Ten and Ren level above 1).
     * Only the NPC bosses (Gon, Hisoka, Neferpitou) use it, so their aura pools stay exactly as they were balanced.
     * Switch their *Tuning.maxAura() to maxNen(...) if you want them on the player curve instead
     * (careful: Neferpitou is level 300, and the player curve grows with the square of the level).
     */
    public static float npcMaxNen(int level, int tenLevel, int renLevel) {
        return 1000f + level * 600f
            + Math.max(0, tenLevel - 1) * 200f
            + Math.max(0, renLevel - 1) * 200f;
    }

    /** Levels where a grade is earned (Great, Excellent, Genius). Each one halves all level XP from then on. */
    public static final int[] EXP_HALVING_LEVELS = {20, 40, 60};

    /** Multiplier on level XP gained at this level: 1 below Great, 0.5 from Great, 0.25 from Excellent, 0.125 from Genius. */
    public static float levelExpMult(int level) {
        float m = 1f;
        for (int t : EXP_HALVING_LEVELS) if (level >= t) m *= 0.5f;
        return m;
    }

    // In and Gyo
    public static final int IN_MIN_HATSU_LEVEL = 10;     // In and Gyo unlock with Hatsu itself
    public static final float IN_UPKEEP = 8f;            // Nen per second while In is held
    public static final float GYO_UPKEEP = 12f;          // Nen per second while Gyo is held

    // ---- Shu (coats a weapon in aura) ----
    public static final float SHU_UPKEEP = 6f;                     // Nen per second while Shu is held
    public static final float SHU_DAMAGE_L1 = 0.05f;               // +5% weapon damage at level 1
    public static final float SHU_DAMAGE_L100 = 0.50f;             // +50% at level 100
    public static final float SHU_DAMAGE_PER_5_OVER_100 = 0.05f;   // then +5% for every 5 levels past 100
    public static final float SHU_TAKEN_L1 = 0.20f;                // +20% damage taken at level 1
    public static final float SHU_TAKEN_L100 = 0.075f;             // +7.5% damage taken at level 100 (stays there past 100)
    public static final float SHU_DURABILITY_PER_10 = 0.10f;       // every 10 levels below 80: 10% less durability loss (70% at level 70)
    public static final int SHU_DURABILITY_BOOST_LEVEL = 80;       // from this level the coating makes the item last far longer (80% less loss = 5x durability at level 80)
    public static final int SHU_DURABILITY_TARGET_L100 = 10 * 2031; // at level 100 a coated item lasts 10x a Netherite tool (2031 uses) = 20310 uses
    public static final float SHU_MINING_DIAMOND_SPEED = 8f;       // vanilla diamond tool base mining speed
    public static final float SHU_MINING_SPEED_L100 = 50f;         // a diamond pickaxe mines at this speed at Shu 100 (so x6.25 mining speed)

    /** Fraction ADDED to weapon damage by Shu at this (effective) level: 0.05 = +5%. */
    public static float shuDamageBonus(int level) {
        if (level <= NenSkill.MAX_LEVEL) {
            float t = (Math.max(1, level) - 1) / (float) (NenSkill.MAX_LEVEL - 1);
            return SHU_DAMAGE_L1 + t * (SHU_DAMAGE_L100 - SHU_DAMAGE_L1);
        }
        return SHU_DAMAGE_L100 + ((level - NenSkill.MAX_LEVEL) / 5) * SHU_DAMAGE_PER_5_OVER_100;
    }

    /** Fraction ADDED to the damage the user takes while Shu is on: 0.20 at level 1 down to 0.075 at level 100. */
    public static float shuDamageTaken(int level) {
        float t = (Math.min(NenSkill.MAX_LEVEL, Math.max(1, level)) - 1) / (float) (NenSkill.MAX_LEVEL - 1);
        return SHU_TAKEN_L1 + t * (SHU_TAKEN_L100 - SHU_TAKEN_L1);
    }

    /** Mining-speed multiplier from Shu: x1 at level 0, x(50/8) = x6.25 at level 100 (diamond 8 -> 50), still climbing linearly past 100. Multiplies whatever the tool already mines at, real Efficiency included. */
    public static float shuMiningMult(int level) {
        float atL100 = SHU_MINING_SPEED_L100 / SHU_MINING_DIAMOND_SPEED;
        return 1f + Math.max(0, level) / (float) NenSkill.MAX_LEVEL * (atL100 - 1f);
    }

    /**
     * Share of durability loss Shu cancels for an item with this much max durability. Below level 80: 10% per full 10 levels (so 70% at 70).
     * From level 80 the item's effective durability grows steeply (exponentially) from 5x (the 80% it already had at level 80) to
     * {@link #SHU_DURABILITY_TARGET_L100} total uses at level 100, i.e. 10x Netherite whatever the item is: a wooden sword, an iron katana and
     * a diamond pickaxe all last 20310 uses at Shu 100. An item that already has more than that is only given the level-80 bonus. Never 100%.
     */
    public static float shuDurabilitySave(int level, int maxDurability) {
        if (level < SHU_DURABILITY_BOOST_LEVEL) return Math.max(0f, (level / 10) * SHU_DURABILITY_PER_10);
        float at80 = 1f / (1f - 8 * SHU_DURABILITY_PER_10);                       // 5x
        float at100 = Math.max(at80, SHU_DURABILITY_TARGET_L100 / (float) Math.max(1, maxDurability));
        float t = Math.min(1f, (level - SHU_DURABILITY_BOOST_LEVEL) / (float) (NenSkill.MAX_LEVEL - SHU_DURABILITY_BOOST_LEVEL));
        float mult = (float) (at80 * Math.pow(at100 / at80, t));                   // x5 .. x(20310 / maxDurability)
        return 1f - 1f / mult;
    }
    public static final double GYO_RANGE = 24.0;         // how far away Gyo can read someone's grade
    public static final int IN_VISIBILITY_LEVEL = 60;    // In level (Genius) at which the "show / hide my Nen" slider appears

    public static final String[] GRADE_NAMES = {"Novice", "Great", "Excellent", "Genius", "Ultimate"};

    /** 0 Novice, 1 Great (20), 2 Excellent (40), 3 Genius (60), 4 Ultimate (100): the grade a level (or skill level) has reached. */
    public static int gradeRank(int level) {
        if (level >= 100) return 4;
        if (level >= 60) return 3;
        if (level >= 40) return 2;
        if (level >= 20) return 1;
        return 0;
    }

    public static final int REN_MIN_HATSU_LEVEL = 3;
    public static final float REN_BASE_UPKEEP = 80.0f; // Ren drain per second (Combat uses this too)
    public static final float ABILITY_COST_THRESHOLD = 14.0f; // single-tick energy drop treated as an ability use
    /**
     * Aura states. Ten is the basic aura and is always on (only Zetsu, Ko and Chain Jail / Forced Zetsu take it away).
     * Ren, Ken and Ko are alternatives to each other (turning one on turns the others off). See tenBonus() below for what each gives.
     */
    public static final float KEN_UPKEEP = 40.0f;  // energy/sec while Ken is on
    public static final float KO_UPKEEP = 22.0f;   // energy/sec while Ko is on
    public static final int FORM_COOLDOWN_TICKS = 5; // minimum gap between presses of a form key

    /** PLAYER upkeep as a share of max aura, per second (the flat numbers above are still used by NPCs and En). */
    public static final float REN_UPKEEP_PCT = 0.008f; // 0.8% of max aura / sec
    public static final float KEN_UPKEEP_PCT = 0.005f; // 0.5% of max aura / sec
    public static final float KO_UPKEEP_PCT = 0.006f;  // 0.6% of max aura / sec
    public static float renUpkeep(float maxEnergy) { return maxEnergy * REN_UPKEEP_PCT; }
    public static float kenUpkeep(float maxEnergy) { return maxEnergy * KEN_UPKEEP_PCT; }
    public static float koUpkeep(float maxEnergy) { return maxEnergy * KO_UPKEEP_PCT; }

    /** Ken and Ko unlock at this Hatsu level (the same "Level" Ren's unlock uses). */
    public static final int FORM_MIN_HATSU_LEVEL = 20;

    /**
     * Delay (ticks) before switching from one aura state (Ren / Ken / Ko) to another applies: 0.5s at no mastery, shrinking linearly to 0.
     * {@code masteryLevel} is the AVERAGE of all Nen skill levels (the combined level divided by the number of skills), so every skill counts equally:
     * 80 average = 0.1s, 100 average (every skill maxed) = instant.
     */
    public static final int SWITCH_DELAY_BASE_TICKS = 10;
    public static final int SWITCH_DELAY_ZERO_LEVEL = 100;
    public static int switchDelayTicks(float masteryLevel) {
        float t = 1f - Math.max(0f, masteryLevel) / (float) SWITCH_DELAY_ZERO_LEVEL;
        return t <= 0f ? 0 : Math.round(SWITCH_DELAY_BASE_TICKS * t);
    }
    /** While Ko is on, incoming damage is multiplied by this (defence is completely shut off). */
    public static final float KO_INCOMING_MULT = 1.35f;

    public static final float EN_BASE_RADIUS = 6.0f;
    /** Radius at En level 100 (before affinity multipliers). */
    public static final float EN_MAX_RADIUS = 200.0f;
    public static final int EN_MAX_ENTITIES = 96;

    /** The En level at which the radius reaches 50 blocks. */
    public static final int EN_FREE_LEVEL = 80;

    /** 6 blocks at En 1, 50 blocks at En 80 (straight line), then 50 to 200 blocks between En 80 and En 100. Emitters still get their +25% on top. */
    public static float enRadius(int enLevel, float affinityMult) {
        int lvl = Math.max(1, Math.min(250, enLevel)); // Vows can lift the effective level past 100: the curve just keeps going
        float base;
        if (lvl <= EN_FREE_LEVEL) {
            float t = (lvl - 1) / (float) (EN_FREE_LEVEL - 1);
            base = EN_BASE_RADIUS + t * (EN_FREE_RADIUS - EN_BASE_RADIUS);
        } else {
            float t = (lvl - EN_FREE_LEVEL) / (float) (NenSkill.MAX_LEVEL - EN_FREE_LEVEL);
            base = EN_FREE_RADIUS + t * (EN_MAX_RADIUS - EN_FREE_RADIUS);
        }
        return base * affinityMult;
    }

    /** Up to this radius En costs the same as Ko (22/s). */
    public static final float EN_FREE_RADIUS = 50.0f;
    /** Cost curve past 50 blocks, straight lines between these points: 100m = 665/s, 150m = 1288/s, 200m = 2291/s. */
    private static final float[] EN_COST_RADIUS = {50f, 100f, 150f, 200f};
    private static final float[] EN_COST_VALUE = {KO_UPKEEP, 665f, 1288f, 2291f};

    /** En upkeep per second at this radius (affinity discounts still apply where it is charged). Past 200m it keeps the last slope. */
    public static float enUpkeep(float radius, int enLevel) {
        if (radius <= EN_COST_RADIUS[0]) return EN_COST_VALUE[0];
        int n = EN_COST_RADIUS.length;
        for (int i = 1; i < n; i++) {
            if (radius <= EN_COST_RADIUS[i] || i == n - 1) {
                float t = (radius - EN_COST_RADIUS[i - 1]) / (EN_COST_RADIUS[i] - EN_COST_RADIUS[i - 1]);
                return EN_COST_VALUE[i - 1] + t * (EN_COST_VALUE[i] - EN_COST_VALUE[i - 1]);
            }
        }
        return EN_COST_VALUE[n - 1];
    }

    /** Size of the Ren aura that Gon's flares and the exorcism surge use (the slider has no fixed cap any more). */
    public static final float REN_MAX_SIZE = 5.0f;
    public static final float REN_BIG_SOUND_SIZE = 2.2f;           // Ren set to this size or bigger plays its bigger sound

    /** Ren slider maximum: 1x, +0.4x per 20 Ren levels up to 3x at level 100, then +1x per 10 levels (4x at 110, 5x at 120). No cap, so vows can go on. */
    public static float renMaxSize(int renLevel) {
        int lvl = Math.max(0, renLevel);
        if (lvl < 100) return 1.0f + 0.4f * (lvl / 20);
        return 3.0f + (lvl - 100) / 10;
    }

    /** The radius actually used: the slider's pick (or 50 when never set), never above what the player's En level allows. */
    public static float enSelectedRadius(float chosen, float maxRadius) {
        float want = chosen > 0f ? chosen : EN_FREE_RADIUS;
        return Math.max(1.0f, Math.min(want, maxRadius));
    }

    public static float zetsuDamagePenalty(int level) {
        return Math.max(0.05f, 0.25f - level * 0.002f);
    }

    public static float zetsuStealthRange(int level) {
        return Math.max(1.0f, 6.0f - level * 0.04f); // keeps shrinking past level 100 (Vows), down to 1 block
    }

    /** Nen regenerated per second while Ten is held. */
    public static float tenRegen(int tenLevel) {
        return tenLevel * 0.05f;
    }

    /**
     * Percentage regen: a share of max Nen per second, so a huge pool still refills in a few minutes.
     * Only Zetsu has one now; Ten regenerates Nen with its flat per-level amount alone (see tenRegen).
     * Zetsu refills an empty pool in 125 s (1 / 0.008), before its flat regen is added on top.
     */
    public static final float ZETSU_REGEN_PCT = 0.008f;   // 0.8% of max Nen per second

    /** Zetsu must always out-regenerate Ten, whatever the two skill levels are. */
    public static final float ZETSU_MIN_TEN_RATIO = 1.5f;

    /** Zetsu regeneration is doubled. */
    public static final float ZETSU_REGEN_MULT = 2.0f;

    /** Nen regenerated per second while Zetsu is held: its own curve, but never below 1.5x what Ten gives. */
    public static float zetsuRegen(int zetsuLevel, int tenLevel) {
        return ZETSU_REGEN_MULT * Math.max(3.0f + zetsuLevel * 0.10f, tenRegen(tenLevel) * ZETSU_MIN_TEN_RATIO);
    }

    // ---------------------------------------------------------------------------------------------
    // PLAYER AURA BUFFS: Ten / Ren / Ken / Ko. Everything below is driven by the Ten skill level.
    //   tenBonus(L) = 0.20 at Ten level 1, rising by 0.028283 per level: +300% at level 100.
    //   Ten : durability and damage +tenBonus; speed +tenSpeedBonus (its own curve, +1.1% per level)
    //   Ren : doubles Ten                       (all three x2)
    //   Ken : Ren + Ten, you give up 20% damage (damage x0.8 of Ten's bonus, durability x1.8, speed x1.0)
    //   Ko  : forced out of Ten, all aura in the right arm: melee damage x2 of Ten's bonus, no speed or durability
    //   Zetsu: every bonus is off.
    // ---------------------------------------------------------------------------------------------
    public static final float TEN_BASE_BONUS = 0.20f;
    public static final float TEN_BONUS_PER_LEVEL = 0.028283f;
    public static final float REN_TEN_MULT = 2.0f;
    public static final float KEN_DAMAGE_SHARE = 0.80f;
    public static final float KEN_DURABILITY_SHARE = 1.80f;
    public static final float KEN_SPEED_SHARE = 1.0f;
    public static final float KO_DAMAGE_SHARE = 2.0f;
    /** Scales ONLY the movement-speed part of the buffs (1 = exactly the percentages above; +300% speed is 4x walking speed). */
    public static final float BUFF_SPEED_SCALE = 1.0f;

    // Ten's MOVEMENT SPEED has its own, gentler curve (damage and durability keep tenBonus above): +20% at level 1, then +1.1% per level.
    public static final float TEN_SPEED_BASE_BONUS = 0.20f;
    public static final float TEN_SPEED_PER_LEVEL = 0.011f;
    /** Jump Boost level (as the game shows it: 2 = Jump Boost II) while Ten (or Ren / Ken) gives a speed bonus. */
    public static final int TEN_JUMP_BOOST_LEVEL = 2;
    /** Jump Boost level while Godspeed is on (replaces Ten's). */
    public static final int GODSPEED_JUMP_BOOST_LEVEL = 5;
    /** NPCs with Ten get the same speed bonus, but never more than this (+100%) so Hisoka and Neferpitou stay hittable. */
    public static final float NPC_TEN_SPEED_CAP = 1.0f;

    /** Ten's movement-speed bonus as a fraction (0.2 = +20%): 20% at Ten level 1, +1.1% per level after that (about +129% at level 100). */
    public static float tenSpeedBonus(int tenLevel) {
        int lvl = Math.max(1, Math.min(250, tenLevel));
        return TEN_SPEED_BASE_BONUS + (lvl - 1) * TEN_SPEED_PER_LEVEL;
    }

    /** The speed bonus an NPC gets from Ten at this level (the player's number, capped). */
    public static double npcTenSpeed(int tenLevel) {
        return Math.min(NPC_TEN_SPEED_CAP, tenSpeedBonus(tenLevel));
    }

    /** Ten's bonus as a fraction (0.2 = +20%): 20% at Ten level 1, 300% at level 100. Vows can push the level past 100. */
    public static float tenBonus(int tenLevel) {
        int lvl = Math.max(1, Math.min(250, tenLevel));
        return TEN_BASE_BONUS + (lvl - 1) * TEN_BONUS_PER_LEVEL;
    }

    // ---- NPC ONLY from here down: the old Ken / Ko numbers, still used by Hisoka, Gon, Chrollo, Neferpitou and Kite ----

    /** Ken: fraction of incoming damage blocked by the full-body shield (30% at level 1, 50% at level 100). */
    public static float kenDefence(int level) {
        return 0.30f + level * 0.002f;
    }

    /** Ken: fraction of your own damage given up for it (20% at level 1, 10% at level 100). */
    public static float kenDamagePenalty(int level) {
        return Math.max(0.10f, 0.20f - level * 0.001f);
    }

    /**
     * Ren's damage gain over plain Ten at this level. HxHAdventure's spirit bonus is 1 + 0.1*sqrt(L), and Ren adds
     * 0.2*sqrt(L) on top: so Ren multiplies punch damage by this much (1.18x at level 1, 2.0x at level 100).
     */
    public static float renDamageGain(int hatsuLevel) {
        float r = (float) Math.sqrt(Math.max(0, hatsuLevel));
        return (1f + 0.3f * r) / (1f + 0.1f * r);
    }

    // Illumi's Needles (Hatsu kit 15, Manipulators). Ability scroll: Body Alteration, Corpse Control, Needle People.
    public static final int NEEDLES_BODY_MIN_LEVEL = 10;
    public static final int NEEDLES_CORPSE_MIN_LEVEL = 25;
    public static final int NEEDLES_PEOPLE_MIN_LEVEL = 60;
    // Body Alteration: right-click someone (with the ability selected) to save their look, Z to put the needles in
    public static final float NEEDLES_BODY_COST = 200f;          // paid when you transform; changing back is free
    public static final int NEEDLES_BODY_COOLDOWN_TICKS = 100;
    public static final double NEEDLES_SAVE_RANGE = 8.0;         // how far away someone can be and still be copied
    public static final boolean NEEDLES_BODY_COPIES_NAME = true; // chat name / death messages show the copied name while transformed
    // Corpse Control: undead and corpses, at most NEEDLES_CORPSE_MAX at once
    public static final float NEEDLES_CORPSE_COST = 150f;        // paid when the needle goes in
    public static final int NEEDLES_CORPSE_MAX = 10;
    // Needle People: anything but bosses (and players), no limit, but each one costs a huge amount of Nen.
    // For scale: max Nen is about 2,000 at level 1, 30,000 at level 60 and 80,000 at level 100 (with Ten and Ren matching the level).
    public static final float NEEDLES_PEOPLE_COST = 2500f;
    public static final int NEEDLES_COOLDOWN_TICKS = 40;         // after a needle is planted
    // how controlled bodies behave (same numbers as Puppeteer)
    public static final double NEEDLES_CONTROL_RANGE = 12.0;     // how far from itself a controlled body looks for hostile mobs
    public static final double NEEDLES_FOLLOW_DISTANCE = 5.0;    // they walk back to you when further than this
    public static final double NEEDLES_TELEPORT_DISTANCE = 28.0;

    // ---- Lightning Aura (Killua's Hatsu, a Transmuter's): Lightning Palm, Thunderbolt, then Whirlwind and Godspeed together ----
    public static final int LIGHTNING_PALM_MIN_LEVEL = 10;
    public static final int LIGHTNING_BOLT_MIN_LEVEL = 25;
    public static final int GODSPEED_MIN_LEVEL = 45;             // Whirlwind (the dodge) comes with Godspeed, so it unlocks here too
    // Lightning Palm: hands behind the back, charge builds, then both palms strike at once
    public static final float LPALM_COST = 90f;
    public static final int LPALM_COOLDOWN_TICKS = 50;
    public static final int LPALM_WINDUP_TICKS = 14;             // the charge before the strike
    public static final double LPALM_RANGE = 3.6;                // reach of the strike, blocks
    public static final float LPALM_BASE_DAMAGE = 9f;
    public static final float LPALM_DAMAGE_PER_LEVEL = 0.2f;
    public static final int LPALM_STUN_TICKS = 4;                // 0.2 s: a weak stun
    // Thunderbolt: leap about five blocks, then call a bolt down where you are looking
    public static final float BOLT_COST = 160f;
    public static final int BOLT_COOLDOWN_TICKS = 160;
    public static final double BOLT_LEAP_SPEED = 0.92;           // upward speed; about five blocks of height
    public static final double BOLT_LEAP_FORWARD = 0.25;
    public static final int BOLT_MAX_AIR_TICKS = 16;             // the bolt falls at the top of the leap, or at the latest after this long
    public static final double BOLT_RANGE = 40.0;                // how far away the bolt can be called
    public static final double BOLT_RADIUS = 2.6;                // blocks around where it lands
    public static final float BOLT_BASE_DAMAGE = 14f;
    public static final float BOLT_DAMAGE_PER_LEVEL = 0.25f;
    public static final int BOLT_STUN_TICKS = 4;                 // 0.2 s
    // Godspeed (H) and Whirlwind
    public static final float GODSPEED_START_COST = 60f;
    public static final float GODSPEED_UPKEEP = 21.6f;           // energy per second while it lasts (18 + 20%)
    public static final double GODSPEED_SPEED = 1.1;             // +110% movement speed ("massively")
    public static final float GODSPEED_DAMAGE_MULT = 1.5f;       // "moderately" more damage
    public static final double WHIRLWIND_CHANCE = 0.80;          // dodge chance, back to this whenever a hit lands
    public static final double WHIRLWIND_STEP = 0.10;            // every dodged attack lowers the chance by this much
    // Godspeed Lightning Palm: replaces Lightning Palm while Godspeed is on (works like hxhcraft's Godspeed Rush)
    public static final float GPALM_COST = 180f;
    public static final int GPALM_COOLDOWN_TICKS = 100;
    public static final double GPALM_DASH_SPEED = 4.8;           // the burst of velocity along the look direction, blocks per tick
    public static final double GPALM_HIT_RADIUS = 2.5;           // everything this close to the path of the rush is struck
    public static final float GPALM_BASE_DAMAGE = 24f;
    public static final float GPALM_DAMAGE_PER_LEVEL = 0.45f;
    public static final int GPALM_STUN_TICKS = 60;               // 3 s, frozen where they stand
    public static final int GPALM_HITSTOP_TICKS = 2;             // 0.1 s: the user freezes for a moment when the palm connects
    public static final int GPALM_HIT_FX_TICKS = 12;             // how long the user's lightning stays summoned around an enemy that was hit

    public static float hatsuRefund(int level) {
        return level * 0.0025f;
    }

    /** The share of Ko's damage bonus that applies to Hatsu abilities (0.25 = a +600% Ko gives +150%). */
    public static final float KO_HATSU_SHARE = 0.25f;

    /** Hatsu damage: +0.29% per Hatsu level up to 100 (about +30% at 100), and +0.6% for every level above 100 (Vows can lift it that high). */
    public static final float HATSU_DAMAGE_PER_LEVEL = 0.0029f;
    public static final float HATSU_DAMAGE_PER_LEVEL_OVER_100 = 0.006f;

    /** Fraction ADDED to the damage of Hatsu abilities at this (effective) Hatsu level: 0.29 = +29%. */
    public static float hatsuDamageBonus(int level) {
        int upTo100 = Math.max(0, Math.min(level, NenSkill.MAX_LEVEL));
        int over = Math.max(0, level - NenSkill.MAX_LEVEL);
        return upTo100 * HATSU_DAMAGE_PER_LEVEL + over * HATSU_DAMAGE_PER_LEVEL_OVER_100;
    }

    // ---- Hide and Seek (Knov's Hatsu, an Emitter's): Hide and Seek (the circle) and Scream ----
    public static final int HIDESEEK_MIN_LEVEL = 10;
    public static final float HIDESEEK_COST = 70f;
    public static final int HIDESEEK_COOLDOWN_TICKS = 40;
    public static final double HIDESEEK_RANGE = 6.0;             // how far away a block can be marked
    public static final int HIDESEEK_MAX_PORTALS = 8;            // circles one user can keep open; the oldest closes first
    public static final int HIDESEEK_BASE_ROOMS = 2;             // rooms a user may own at the minimum level...
    public static final int HIDESEEK_LEVELS_PER_ROOM = 8;        // ...plus one more for every this many levels
    public static final int HIDESEEK_MAX_ROOMS = 16;
    public static final int ROOM_MIN_SIZE = 7;                   // rooms are odd sized boxes; width and depth between these (blocks)
    public static final int ROOM_MAX_SIZE = 33;
    public static final int ROOM_MIN_HEIGHT = 5;
    public static final int ROOM_MAX_HEIGHT = 17;

    public static final int SCREAM_MIN_LEVEL = 25;
    public static final float SCREAM_COST = 140f;
    public static final int SCREAM_COOLDOWN_TICKS = 160;         // 8 s
    public static final double SCREAM_RANGE = 12.0;
    public static final int SCREAM_CLASP_TICKS = 10;             // hands come together and the loop forms between them
    public static final int SCREAM_TRAVEL_TICKS = 6;             // the loop flies out and wraps around the target
    public static final int SCREAM_HOLD_TICKS = 8;               // the loop tightens, then "Close."
    public static final double SCREAM_RADIUS_BASE = 0.5;         // radius of the loop at the minimum level; the target must fit inside it
    public static final double SCREAM_RADIUS_PER_LEVEL = 0.011;
    public static final double SCREAM_RADIUS_MAX = 1.6;
    public static final double SCREAM_WHOLE_MAX_HEIGHT = 1.0;    // living things up to this tall are taken whole; bigger ones lose the part the loop is round
    // body parts: share of the target's max health taken with the part (1.0 = a head is a kill)
    public static final float SCREAM_HEAD_FRACTION = 1.0f;
    public static final float SCREAM_TORSO_FRACTION = 0.6f;
    public static final float SCREAM_ARM_FRACTION = 0.25f;
    public static final float SCREAM_LEG_FRACTION = 0.25f;
    public static final int SCREAM_LIMB_DEBUFF_TICKS = 400;      // a lost arm weakens, a lost leg slows, for this long (20 s)
}
