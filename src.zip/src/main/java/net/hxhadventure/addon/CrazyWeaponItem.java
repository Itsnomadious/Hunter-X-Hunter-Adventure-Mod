package net.hxhadventure.addon;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * A weapon conjured by Crazy Slots: the Scythe (2), the Staff (3) or the Carbine (4), each with the clown on one end. It belongs to the one
 * who rolled it and never lies on the ground. The scythe goes after one use; the staff and the carbine stay until the user puts them away (H). The item holds no rules except the carbine's
 * trigger (hold right-click); everything else lives in {@link CrazySlots} and {@link CrazySlotsEvents}.
 */
public class CrazyWeaponItem extends Item {
    private final CrazySlots.Weapon weapon;
    private final boolean big;

    public CrazyWeaponItem(Properties props, CrazySlots.Weapon weapon, boolean big) {
        super(props);
        this.weapon = weapon;
        this.big = big;
    }

    public CrazySlots.Weapon weapon() { return weapon; }

    public boolean isBig() { return big; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (weapon != CrazySlots.Weapon.CARBINE || !CrazySlots.isOwnWeapon(stack, player)) return InteractionResultHolder.pass(stack);
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000; // held for as long as the button is
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.NONE;
    }

    @Override
    public void onUseTick(Level level, LivingEntity user, ItemStack stack, int remaining) {
        if (weapon == CrazySlots.Weapon.CARBINE && !level.isClientSide && user instanceof ServerPlayer sp) CrazySlots.carbineHold(sp);
    }

    /** Using the carbine is not a new "equip": it must not bob while firing. */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || !oldStack.is(newStack.getItem());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        if (stack.hasTag() && stack.getTag().contains("OwnerName")) {
            tip.add(Component.literal("§7Crazy Slots of " + stack.getTag().getString("OwnerName")));
        }
        switch (weapon) {
            case SCYTHE -> {
                tip.add(Component.literal("§82: Scythe"));
                tip.add(Component.literal("§8Z: Silent Waltz (the only way to use it)"));
                tip.add(Component.literal("§8Attack, Strong attack and Barrage: two-handed swings, x" + CrazySlotsTuning.SCYTHE_ATTACK_MULT + " damage"));
                tip.add(Component.literal("§8It cannot be put away until it is used"));
            }
            case STAFF -> {
                tip.add(Component.literal("§83: Staff"));
                tip.add(Component.literal("§8Z: sweep (2 s cooldown)"));
                tip.add(Component.literal("§8H: put it away"));
                tip.add(Component.literal("§cBe killed by Neferpitou while holding it and you are reborn a Chimera Ant"));
            }
            case CARBINE -> {
                tip.add(Component.literal("§84: Carbine (suppressed)"));
                tip.add(Component.literal("§8Hold right-click: fire (" + CrazySlotsTuning.CARBINE_MAGAZINE + " rounds)"));
                tip.add(Component.literal("§8H: put it away"));
                if (CrazySlotsTuning.CARBINE_USES_AMMO && stack.hasTag() && stack.getTag().contains("Ammo")) tip.add(Component.literal("§8Rounds left: " + stack.getTag().getInt("Ammo")));
            }
        }
    }
}
