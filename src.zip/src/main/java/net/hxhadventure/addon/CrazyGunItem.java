package net.hxhadventure.addon;

import java.util.function.Consumer;
import net.hxhadventure.addon.client.CrazyGunRenderer;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * The Crazy Slots gun (slot 4) drawn with HxH Craft's clown shotgun model (GeckoLib). It is still the carbine: all of its rules (the trigger,
 * ammo) stay in {@link CrazyWeaponItem} / {@link CrazySlots}; this class only gives it that model and its "pop in" animation.
 *
 * The pop-in (the whole gun grows from nothing in a quarter of a second, played at half speed) starts when the client flags the stack with
 * {@link #APPEAR_TAG} (see CrazyGunClientEvents); the renderer clears the flag again as it starts the animation.
 */
public class CrazyGunItem extends CrazyWeaponItem implements GeoItem {
    public static final String APPEAR_TAG = "PlayAppearAnim";

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public CrazyGunItem(Properties props, CrazySlots.Weapon weapon) {
        super(props, weapon, false);
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private CrazyGunRenderer renderer;

            @Override
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (renderer == null) renderer = new CrazyGunRenderer();
                return renderer;
            }
        });
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<CrazyGunItem>(this, "appear_controller", 0, state -> {
            ItemStack stack = state.getData(DataTickets.ITEMSTACK);
            if (stack != null && stack.hasTag() && stack.getTag().getBoolean(APPEAR_TAG)) {
                stack.getTag().remove(APPEAR_TAG);
                state.getController().forceAnimationReset();
                return state.setAndContinue(RawAnimation.begin().thenPlay("shotgun_appear"));
            }
            return state.setAndContinue(RawAnimation.begin().thenPlay("shotgun_appear"));
        }).setAnimationSpeed(0.5));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
