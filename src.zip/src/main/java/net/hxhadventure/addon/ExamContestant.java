package net.hxhadventure.addon;

import java.util.UUID;
import net.minecraft.server.level.ServerLevel;

/** Anything that fights in Menchi's test (see {@link ExamBattle}): the zombie-strength test takers and the Nen users among them. */
public interface ExamContestant {
    /** Ties it to the test of this player. */
    void setBattle(UUID player);

    /** The player whose test it belongs to, or null. */
    UUID battleId();

    void setSkin(int skin);

    /** Disappears in a puff. */
    void fade(ServerLevel sl);
}
