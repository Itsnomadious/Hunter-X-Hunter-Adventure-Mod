package net.hxhadventure.addon;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/** Registers Morel's pipe and the smoke block without touching ModItem / ModBlocks (same way as Kalluto's fan). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class SmokeItems {
    private SmokeItems() {}

    public static Item PIPE;
    public static Block SMOKE_BLOCK;

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.BLOCKS, helper -> {
            SMOKE_BLOCK = new SmokeBlock();
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "smoke"), SMOKE_BLOCK);
        });
        event.register(ForgeRegistries.Keys.ITEMS, helper -> {
            PIPE = new SmokePipeItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "morels_pipe"), PIPE);
        });
    }

    @SubscribeEvent
    public static void creativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES && PIPE != null) e.accept(PIPE);
    }
}
