package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketSmokeFx;

/**
 * Morel Mackernasey's Smoke Manipulation (Hatsu kit 28, Manipulators). Needs Morel's pipe ({@link SmokePipeItem}) in a hand.
 *
 * <p><b>Deep Purple</b> (Z): the user blows smoke, and a group of {@link SmokeTuning#GROUP_SIZE} smoke monsters steps out of it.
 * Shift+Z does the same with clones of the user. Both have the same stats and share a {@link SmokeTuning#DEEP_PURPLE_COOLDOWN_TICKS}
 * tick cooldown.
 *
 * <p><b>Smoky Jail</b>: the user breathes out a dome of indestructible smoke {@link SmokeTuning#JAIL_RADIUS} blocks across (see
 * {@link SmokeJail}). Z again lets the smoke clear early.
 *
 * <p>All state lives on the server; the client only gets arm poses ({@link PacketSmokeFx}). Forge hooks are in {@link SmokeEvents}.
 */
public final class SmokeManipulation {
    private SmokeManipulation() {}

    public static final int KIT = 28;
    public static final String DEEP_PURPLE_ID = "smoke_deep_purple";
    public static final String JAIL_ID = "smoke_jail";
    private static final String PURPLE_NAME = "Deep Purple";
    private static final String JAIL_NAME = "Smoky Jail";

    private static final class State {
        long purpleCdUntil;   // server tick
        long jailCdUntil;
        int blowTicks;        // > 0 while the user is blowing smoke
        boolean blowClones;
        final List<UUID> minions = new ArrayList<>();
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    private static State state(ServerPlayer sp) {
        return STATES.computeIfAbsent(sp.getUUID(), k -> new State());
    }

    /** Adds the two abilities to the Z scroll once the Hatsu level allows them. */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c)) return base;
        List<String> out = new ArrayList<>(Arrays.asList(base));
        if (c.getHatsuLevel() >= SmokeTuning.DEEP_PURPLE_MIN_LEVEL) out.add(DEEP_PURPLE_ID);
        if (c.getHatsuLevel() >= SmokeTuning.JAIL_MIN_LEVEL) out.add(JAIL_ID);
        return out.toArray(new String[0]);
    }

    public static String displayName(String id) {
        return switch (id) {
            case DEEP_PURPLE_ID -> "§5 Smoke: Deep Purple";
            case JAIL_ID -> "§5 Smoke: Smoky Jail";
            default -> null;
        };
    }

    public static void registerAll(Map<String, Consumer<ServerPlayer>> m) {
        m.put(DEEP_PURPLE_ID, SmokeManipulation::deepPurple);
        m.put(JAIL_ID, SmokeManipulation::smokyJail);
    }

    private static Combat gate(ServerPlayer sp, int minLevel, String name) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return null;
        if (!canUse(c)) {
            msg(sp, "§cYour Hatsu is not Smoke Manipulation");
            return null;
        }
        if (c.getHatsuLevel() < minLevel) {
            msg(sp, "§c" + name + " unlocks at Level " + minLevel);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            msg(sp, "§5Forced Zetsu: the smoke will not answer");
            return null;
        }
        if (HatsuEffects.isStunned(sp)) return null;
        return c;
    }

    private static boolean pay(ServerPlayer sp, Combat c, float cost) {
        if (c.getCurrentEnergy() < cost) {
            msg(sp, "§cNot enough energy");
            return false;
        }
        c.consumeEnergy(cost);
        return true;
    }

    private static void msg(ServerPlayer sp, String text) {
        sp.displayClientMessage(Component.literal(text), true);
    }

    private static void sound(ServerPlayer sp, SoundEvent ev, float vol, float pitch) {
        sp.level().playSound(null, sp.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }

    /** The hand with the pipe, or null (with a message): Smoke Manipulation needs the real item. */
    private static InteractionHand needPipe(ServerPlayer sp) {
        InteractionHand hand = SmokePipeItem.heldIn(sp);
        if (hand == null) msg(sp, "§cHold Morel's pipe to use Smoke Manipulation");
        return hand;
    }

    private static boolean pipeArmIsLeft(ServerPlayer sp, InteractionHand hand) {
        boolean mainIsLeft = sp.getMainArm() == HumanoidArm.LEFT;
        return hand == InteractionHand.MAIN_HAND ? mainIsLeft : !mainIsLeft;
    }

    private static long now(ServerPlayer sp) {
        return sp.server.getTickCount();
    }

    // ---------------------------------------------------------------- Deep Purple

    /** Z (monsters) and Shift+Z (clones) on Deep Purple. */
    public static void deepPurple(ServerPlayer sp) {
        Combat c = gate(sp, SmokeTuning.DEEP_PURPLE_MIN_LEVEL, PURPLE_NAME);
        if (c == null || !(sp.level() instanceof ServerLevel)) return;
        State s = state(sp);
        if (s.blowTicks > 0) return; // already blowing
        InteractionHand hand = needPipe(sp);
        if (hand == null) return;
        int left = (int) (s.purpleCdUntil - now(sp));
        if (left > 0) {
            ChainManager.onCooldown(sp, PURPLE_NAME, left);
            return;
        }
        if (!pay(sp, c, SmokeTuning.DEEP_PURPLE_COST)) return;
        boolean clones = sp.isShiftKeyDown();
        s.purpleCdUntil = now(sp) + SmokeTuning.DEEP_PURPLE_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, PURPLE_NAME, SmokeTuning.DEEP_PURPLE_COOLDOWN_TICKS);
        s.blowTicks = SmokeTuning.BLOW_TICKS;
        s.blowClones = clones;
        AddonNetwork.sendToTrackingAndSelf(new PacketSmokeFx(sp.getId(), PacketSmokeFx.BLOW, pipeArmIsLeft(sp, hand)), sp);
        sound(sp, SoundEvents.CAMPFIRE_CRACKLE, 1.0f, 0.6f);
        msg(sp, clones ? "§5Deep Purple: clones" : "§5Deep Purple: smoke monsters");
    }

    private static Vec3 mouth(ServerPlayer sp) {
        return sp.getEyePosition().add(sp.getLookAngle().scale(0.45)).add(0.0, -0.12, 0.0);
    }

    /** One tick of the blow: smoke from the mouth, and a cloud that spreads over the ground around the user. */
    private static void blowTick(ServerPlayer sp, ServerLevel level, State s) {
        Vec3 m = mouth(sp);
        level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, m.x, m.y, m.z, 4, 0.05, 0.05, 0.05, 0.03);
        double progress = 1.0 - (double) s.blowTicks / SmokeTuning.BLOW_TICKS;
        double spread = 0.8 + 3.0 * progress;
        level.sendParticles(ParticleTypes.CLOUD, sp.getX(), sp.getY() + 0.2, sp.getZ(), 18, spread, 0.15, spread, 0.01);
        level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, sp.getX(), sp.getY() + 0.1, sp.getZ(), 4, spread, 0.1, spread, 0.0);
        if (s.blowTicks % 6 == 0) sound(sp, SoundEvents.FIRE_EXTINGUISH, 0.5f, 0.7f);
    }

    /** The smoke is thick enough: the group steps out of it. */
    private static void summon(ServerPlayer sp, ServerLevel level, State s) {
        MinecraftServer server = level.getServer();
        Combat c = Combat.get(sp);
        int hatsu = c == null ? 1 : c.getHatsuLevel();
        int count = SmokeTuning.GROUP_SIZE;

        // keep the total in check: the oldest minions dissolve first
        prune(server, s);
        while (!s.minions.isEmpty() && s.minions.size() + count > SmokeTuning.MAX_MINIONS) {
            Entity old = find(server, s.minions.remove(0));
            if (old instanceof SmokeMinion m) m.dissolve();
        }

        for (int i = 0; i < count; i++) {
            SmokeMinion m;
            if (s.blowClones) {
                SmokeCloneEntity clone = new SmokeCloneEntity(HxHEntities.SMOKE_CLONE.get(), level);
                clone.copyLook(sp);
                m = clone;
            } else {
                m = new SmokeMonsterEntity(HxHEntities.SMOKE_MONSTER.get(), level);
            }
            m.setup(sp, hatsu);
            double angle = (i + level.random.nextDouble() * 0.8) / count * Math.PI * 2.0;
            double r = SmokeTuning.SPAWN_RADIUS_MIN + level.random.nextDouble() * (SmokeTuning.SPAWN_RADIUS_MAX - SmokeTuning.SPAWN_RADIUS_MIN);
            double x = sp.getX() + Math.cos(angle) * r;
            double z = sp.getZ() + Math.sin(angle) * r;
            double y = groundY(level, x, sp.getY(), z);
            m.moveTo(x, y, z, sp.getYRot(), 0f);
            m.startCrouch(SmokeTuning.CROUCH_TICKS);
            if (level.addFreshEntity(m)) {
                s.minions.add(m.getUUID());
                level.sendParticles(ParticleTypes.CLOUD, x, y + 0.7, z, 8, 0.3, 0.5, 0.3, 0.02);
            }
        }
        sound(sp, SoundEvents.WOOL_PLACE, 1.2f, 0.6f);
    }

    /** Standing height at (x, z) near the user's own height: the first free block with a solid one below it. */
    private static double groundY(ServerLevel level, double x, double userY, double z) {
        int bx = (int) Math.floor(x), bz = (int) Math.floor(z), by = (int) Math.floor(userY);
        for (int dy = 2; dy >= -4; dy--) {
            BlockPos p = new BlockPos(bx, by + dy, bz);
            if (level.getBlockState(p).getCollisionShape(level, p).isEmpty()
                && level.getBlockState(p.above()).getCollisionShape(level, p.above()).isEmpty()
                && !level.getBlockState(p.below()).getCollisionShape(level, p.below()).isEmpty()) {
                return p.getY();
            }
        }
        return userY;
    }

    private static Entity find(MinecraftServer server, UUID id) {
        for (ServerLevel l : server.getAllLevels()) {
            Entity e = l.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    private static void prune(MinecraftServer server, State s) {
        for (Iterator<UUID> it = s.minions.iterator(); it.hasNext(); ) {
            Entity e = find(server, it.next());
            if (e == null || !e.isAlive()) it.remove();
        }
    }

    // ---------------------------------------------------------------- Smoky Jail

    /** Z on Smoky Jail: breathe the dome out, or (with a dome standing) let it clear. */
    public static void smokyJail(ServerPlayer sp) {
        Combat c = gate(sp, SmokeTuning.JAIL_MIN_LEVEL, JAIL_NAME);
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        State s = state(sp);
        if (SmokeJail.isOpen(sp.getUUID())) { // pressing it again only releases: no pipe, no aura needed
            SmokeJail.close(sp.getUUID());
            msg(sp, "§5The smoke clears");
            return;
        }
        InteractionHand hand = needPipe(sp);
        if (hand == null) return;
        int left = (int) (s.jailCdUntil - now(sp));
        if (left > 0) {
            ChainManager.onCooldown(sp, JAIL_NAME, left);
            return;
        }
        if (!pay(sp, c, SmokeTuning.JAIL_COST)) return;
        s.jailCdUntil = now(sp) + SmokeTuning.JAIL_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, JAIL_NAME, SmokeTuning.JAIL_COOLDOWN_TICKS);
        AddonNetwork.sendToTrackingAndSelf(new PacketSmokeFx(sp.getId(), PacketSmokeFx.JAIL, pipeArmIsLeft(sp, hand)), sp);
        Vec3 m = mouth(sp);
        level.sendParticles(ParticleTypes.CLOUD, sp.getX(), sp.getY() + 0.3, sp.getZ(), 260, 4.0, 0.4, 4.0, 0.05);
        level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, m.x, m.y, m.z, 40, 0.3, 0.2, 0.3, 0.08);
        SmokeJail.open(sp, level);
        msg(sp, "§5Smoky Jail §7(Z again to clear it)");
    }

    // ---------------------------------------------------------------- ticking and clean-up

    private static int lastTick = -1;

    public static void serverTick(MinecraftServer server) {
        if (server == null) return;
        if (server.getTickCount() == lastTick) return; // never run twice in one tick, even if the hook were registered twice
        lastTick = server.getTickCount();
        SmokeJail.tick(server);
        if (STATES.isEmpty()) return;
        for (Iterator<Map.Entry<UUID, State>> it = STATES.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, State> en = it.next();
            State s = en.getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null) {
                dissolveAll(server, s);
                it.remove();
                continue;
            }
            if (s.blowTicks > 0 && sp.level() instanceof ServerLevel level) {
                if (!sp.isAlive() || !canUse(Combat.get(sp))) {
                    s.blowTicks = 0;
                    continue;
                }
                try {
                    blowTick(sp, level, s);
                    if (--s.blowTicks == 0) summon(sp, level, s);
                } catch (Throwable t) { // a failure in one cast must never take the whole server tick (and the game) down with it
                    com.mojang.logging.LogUtils.getLogger().error("[hxh] Deep Purple failed", t);
                    s.blowTicks = 0;
                    dissolveAll(server, s);
                    msg(sp, "\u00a7cDeep Purple failed (see the log)");
                }
            }
        }
    }

    private static void dissolveAll(MinecraftServer server, State s) {
        for (UUID id : s.minions) {
            if (find(server, id) instanceof SmokeMinion m) m.dissolve();
        }
        s.minions.clear();
    }

    /** Death, logout, losing Nen or changing Hatsu: the minions turn back into smoke and the dome clears. */
    public static void clear(ServerPlayer sp) {
        SmokeJail.close(sp.getUUID());
        State s = STATES.remove(sp.getUUID());
        if (s != null && sp.getServer() != null) dissolveAll(sp.getServer(), s);
    }

    public static void reset() {
        STATES.clear();
        lastTick = -1;
        SmokeJail.reset();
    }
}
