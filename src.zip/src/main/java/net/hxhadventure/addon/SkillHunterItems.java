package net.hxhadventure.addon;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/** Registers the Skill Hunter book item without touching ModItem. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class SkillHunterItems {
    private SkillHunterItems() {}

    public static Item BOOK;

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.ITEMS, helper -> {
            BOOK = new SkillHunterBookItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "skill_hunter_book"), BOOK);
        });
    }
}
