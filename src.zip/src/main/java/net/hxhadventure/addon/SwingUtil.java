package net.hxhadventure.addon;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;

/**
 * Vanilla's LivingEntity.swing silently ignores a new swing while the previous one is still in its first half, so a quick second
 * attack (or an NPC's own goal swinging in the same tick as our punch) could show no arm movement at all. Resetting the swing
 * state first makes every attack restart the swing animation, and the swing packet is then sent to every tracking player.
 */
public final class SwingUtil {
    private SwingUtil() {}

    public static void forceSwing(LivingEntity e, InteractionHand hand) {
        if (e.level().isClientSide) return;
        e.swinging = false;
        e.swingTime = 0;
        e.swing(hand, true);
    }
}
