package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Smoky Jail: a dome of indestructible {@link SmokeBlock}s, {@link SmokeTuning#JAIL_RADIUS} blocks across, with the user at its centre.
 * The dome is the shell of a half ball (floor included) one block thick, put up from the floor to the top over a couple of seconds.
 * Whatever stood in the shell is remembered ({@link SmokeJailData}) and put back when the smoke clears, so the world is never damaged.
 */
public final class SmokeJail {
    private SmokeJail() {}

    /** Dimensions that have at least one dome. Looked at every tick, so it is kept small. */
    private static final Map<ResourceKey<Level>, SmokeJailData> ACTIVE = new HashMap<>();

    private static SmokeJailData data(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(SmokeJailData::load, SmokeJailData::new, SmokeJailData.ID);
    }

    // ---------------------------------------------------------------- queries

    /** Is this block one a dome put up? (A smoke block nobody owns fades away, see SmokeBlock.) */
    public static boolean isTracked(ServerLevel level, BlockPos pos) {
        SmokeJailData d = ACTIVE.get(level.dimension());
        if (d == null) return false;
        long key = pos.asLong();
        for (SmokeJailData.Jail j : d.jails.values()) if (j.replaced.containsKey(key)) return true;
        return false;
    }

    /** Does this user have a dome standing (not already clearing)? */
    public static boolean isOpen(UUID owner) {
        for (SmokeJailData d : ACTIVE.values()) {
            for (SmokeJailData.Jail j : d.jails.values()) if (owner.equals(j.owner) && !j.ending) return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- open / close

    private static boolean inBall(int dx, int dy, int dz, int r) {
        return dy >= 0 && dx * dx + dy * dy + dz * dz <= r * r;
    }

    /** The dome goes up around the user. */
    public static void open(ServerPlayer sp, ServerLevel level) {
        close(sp.getUUID());
        SmokeJailData d = data(level);
        SmokeJailData.Jail j = new SmokeJailData.Jail(UUID.randomUUID());
        j.owner = sp.getUUID();
        j.center = sp.blockPosition().below(); // the floor is the block under the user's feet
        j.expire = level.getGameTime() + SmokeTuning.JAIL_DURATION_TICKS;
        int r = SmokeTuning.JAIL_RADIUS;
        List<Long> queue = new ArrayList<>();
        for (int dy = 0; dy <= r; dy++) {
            int y = j.center.getY() + dy;
            if (y < level.getMinBuildHeight() || y >= level.getMaxBuildHeight()) continue;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (!inBall(dx, dy, dz, r)) continue;
                    boolean edge = !inBall(dx + 1, dy, dz, r) || !inBall(dx - 1, dy, dz, r) || !inBall(dx, dy + 1, dz, r)
                        || !inBall(dx, dy - 1, dz, r) || !inBall(dx, dy, dz + 1, r) || !inBall(dx, dy, dz - 1, r);
                    if (edge) queue.add(BlockPos.asLong(j.center.getX() + dx, y, j.center.getZ() + dz));
                }
            }
        }
        j.queue = queue;
        d.jails.put(j.id, j);
        d.setDirty();
        ACTIVE.put(level.dimension(), d);
        level.playSound(null, sp.blockPosition(), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 2.0f, 0.5f);
    }

    /** The smoke starts to clear (the user ended it, died, left, or the time ran out). */
    public static void close(UUID owner) {
        for (SmokeJailData d : ACTIVE.values()) {
            for (SmokeJailData.Jail j : d.jails.values()) {
                if (owner.equals(j.owner) && !j.ending) {
                    j.ending = true;
                    d.setDirty();
                }
            }
        }
    }

    // ---------------------------------------------------------------- ticking

    /** Called once a server tick. */
    public static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) return;
        for (Iterator<Map.Entry<ResourceKey<Level>, SmokeJailData>> it = ACTIVE.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<ResourceKey<Level>, SmokeJailData> en = it.next();
            ServerLevel level = server.getLevel(en.getKey());
            SmokeJailData d = en.getValue();
            if (level == null || d.jails.isEmpty()) {
                it.remove();
                continue;
            }
            for (Iterator<SmokeJailData.Jail> ji = d.jails.values().iterator(); ji.hasNext(); ) {
                SmokeJailData.Jail j = ji.next();
                if (!j.ending) {
                    ServerPlayer owner = j.owner == null ? null : server.getPlayerList().getPlayer(j.owner);
                    if (owner == null || !owner.isAlive() || owner.level() != level || level.getGameTime() >= j.expire) {
                        j.ending = true;
                        d.setDirty();
                    }
                }
                if (j.ending) {
                    if (clear(level, j, SmokeTuning.JAIL_CLEAR_PER_TICK, true)) {
                        ji.remove();
                        d.setDirty();
                    }
                } else {
                    build(level, j, d);
                }
            }
        }
    }

    private static void build(ServerLevel level, SmokeJailData.Jail j, SmokeJailData d) {
        if (j.queueIndex >= j.queue.size() || SmokeItems.SMOKE_BLOCK == null) return;
        BlockState smoke = SmokeItems.SMOKE_BLOCK.defaultBlockState();
        int placed = 0;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        while (j.queueIndex < j.queue.size() && placed < SmokeTuning.JAIL_BUILD_PER_TICK) {
            long key = j.queue.get(j.queueIndex++);
            p.set(BlockPos.getX(key), BlockPos.getY(key), BlockPos.getZ(key));
            if (!level.hasChunkAt(p)) continue;
            BlockState old = level.getBlockState(p);
            if (old.is(SmokeItems.SMOKE_BLOCK) || old.hasBlockEntity() || old.getDestroySpeed(level, p) < 0f) continue; // bedrock etc. stay
            j.replaced.put(key, old); // remembered before it is replaced
            level.setBlock(p, smoke, 2);
            placed++;
            if ((j.queueIndex & 7) == 0) {
                level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, 1, 0.3, 0.3, 0.3, 0.01);
            }
        }
        if (placed > 0) d.setDirty();
        if (j.queueIndex >= j.queue.size()) j.queue = new ArrayList<>();
    }

    /**
     * Puts back up to {@code limit} blocks (all of them when limit &lt;= 0). Returns true when nothing is left to put back
     * (blocks in unloaded chunks wait until the chunk is there again).
     */
    private static boolean clear(ServerLevel level, SmokeJailData.Jail j, int limit, boolean fx) {
        j.queue = new ArrayList<>();
        j.queueIndex = 0;
        int done = 0;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (Iterator<Map.Entry<Long, BlockState>> it = j.replaced.entrySet().iterator(); it.hasNext(); ) {
            if (limit > 0 && done >= limit) break;
            Map.Entry<Long, BlockState> e = it.next();
            long key = e.getKey();
            p.set(BlockPos.getX(key), BlockPos.getY(key), BlockPos.getZ(key));
            if (!level.hasChunkAt(p)) continue;
            if (level.getBlockState(p).is(SmokeItems.SMOKE_BLOCK)) level.setBlock(p, e.getValue(), 3); // somebody else's change is left alone
            it.remove();
            done++;
            if (fx && (done & 7) == 0) {
                level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, 1, 0.3, 0.3, 0.3, 0.01);
            }
        }
        return j.replaced.isEmpty();
    }

    // ---------------------------------------------------------------- lifecycle

    /** A dimension finished loading: domes left over from before are cleared (their record is on disk). */
    public static void onLevelLoad(ServerLevel level) {
        SmokeJailData d = level.getDataStorage().get(SmokeJailData::load, SmokeJailData.ID);
        if (d != null && !d.jails.isEmpty()) ACTIVE.put(level.dimension(), d);
    }

    /** The server is stopping: every dome is taken down at once, so the world is saved without smoke in it. */
    public static void onServerStopping(MinecraftServer server) {
        for (Map.Entry<ResourceKey<Level>, SmokeJailData> en : ACTIVE.entrySet()) {
            ServerLevel level = server.getLevel(en.getKey());
            if (level == null) continue;
            SmokeJailData d = en.getValue();
            for (Iterator<SmokeJailData.Jail> ji = d.jails.values().iterator(); ji.hasNext(); ) {
                SmokeJailData.Jail j = ji.next();
                j.ending = true;
                if (clear(level, j, 0, false)) ji.remove();
            }
            d.setDirty();
        }
    }

    public static void reset() {
        ACTIVE.clear();
    }
}
