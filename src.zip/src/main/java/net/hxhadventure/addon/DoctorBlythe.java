package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketBlytheFx;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Neferpitou's Doctor Blythe (Hatsu kit 10, Specialists): a giant doll that heals through its fingers.
 *
 * <ul>
 *   <li>It is planted {@link Tuning#BLYTHE_BEHIND} blocks behind the user when summoned and <b>never moves</b> afterwards.</li>
 *   <li>It is joined to the user by the user's "tail" (drawn client-side as a cord from the lower back). If the user gets
 *       further than {@link Tuning#BLYTHE_TETHER_RANGE} from it, the tail snaps and Blythe is lost.</li>
 *   <li>Every finger sends a tendril to whatever it touches. Allies (and the user) inside its reach get healed
 *       every {@link Tuning#BLYTHE_PULSE_TICKS} ticks. Pressing the ability again withdraws it.</li>
 * </ul>
 * It is not an entity: the server only keeps an anchor and a target list and tells clients what to draw
 * (see PacketBlytheFx / BlytheFx / BlytheRenderer), the same way the chains and the book work.
 */
public final class DoctorBlythe {
    private DoctorBlythe() {}

    /** The Hatsu kit id (rolled by Water Divination for Specialists, or /hxh set skill nerferpitou). */
    public static final int KIT = 10;
    public static final String ID = "doctor_blythe";

    private static final Map<Player, State> STATES = new WeakHashMap<>();

    private static final class State {
        boolean active;
        ResourceKey<Level> dim;
        Vec3 anchor = Vec3.ZERO;
        Vec3 forward = new Vec3(0, 0, 1);
        float yaw;
        int cooldown;
        int[] targets = new int[0];
    }

    private static State state(Player p) {
        return STATES.computeIfAbsent(p, k -> new State());
    }

    public static boolean isOut(Player p) {
        State s = p == null ? null : STATES.get(p);
        return s != null && s.active;
    }

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    /** Adds Doctor Blythe to the R/Z menu for a player whose Hatsu it is and who has the level for it. */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < Tuning.BLYTHE_MIN_LEVEL) return base;
        String[] out = Arrays.copyOf(base, base.length + 1);
        out[base.length] = ID;
        return out;
    }

    // ---------------- summon / withdraw ----------------
    public static void toggle(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Doctor Blythe"), true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.BLYTHE_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cDoctor Blythe unlocks at Level " + Tuning.BLYTHE_MIN_LEVEL), true);
            return;
        }
        State s = state(sp);
        if (s.active) { // pressing again withdraws it
            dismiss(sp, s, "\u00a77Doctor Blythe withdrawn");
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: Doctor Blythe cannot be summoned"), true);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        if (ChainManager.onCooldown(sp, "Doctor Blythe", s.cooldown)) return;
        if (!sp.onGround()) {
            sp.displayClientMessage(Component.literal("\u00a7cDoctor Blythe needs solid ground"), true);
            return;
        }
        if (c.getCurrentEnergy() < Tuning.BLYTHE_SUMMON_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        if (!PitouSkills.clearOthers(sp, PitouSkills.BLYTHE)) return;
        c.consumeEnergy(Tuning.BLYTHE_SUMMON_COST);

        // Planted behind the user's back, facing the way the user faces, and it stays exactly here.
        double rad = Math.toRadians(sp.getYRot());
        s.forward = new Vec3(-Math.sin(rad), 0, Math.cos(rad));
        s.anchor = sp.position().subtract(s.forward.scale(Tuning.BLYTHE_BEHIND));
        s.yaw = sp.getYRot();
        s.dim = level.dimension();
        s.active = true;
        s.targets = new int[0];

        playSound(sp, SoundEvents.SOUL_ESCAPE, 1.0f, 0.6f);
        sp.displayClientMessage(Component.literal("\u00a7dDoctor Blythe"), true);
        send(sp, s);
        syncTargets(sp, s, contacts(sp, level, s));
    }

    private static void dismiss(ServerPlayer sp, State s, String msg) {
        if (!s.active) return;
        s.active = false;
        s.cooldown = Tuning.BLYTHE_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, "Doctor Blythe", Tuning.BLYTHE_COOLDOWN_TICKS);
        s.targets = new int[0];
        send(sp, s);
        playSound(sp, SoundEvents.CHAIN_BREAK, 0.8f, 0.8f);
        if (msg != null) sp.displayClientMessage(Component.literal(msg), true);
    }

    /** Another of Neferpitou's skills is being summoned: Blythe is put away. */
    public static void withdraw(ServerPlayer sp) {
        State s = STATES.get(sp);
        if (s != null && s.active) dismiss(sp, s, "\u00a77Doctor Blythe withdrawn");
    }

    /** Death / logout: Blythe goes with its user. */
    public static void clear(Player p) {
        State s = STATES.get(p);
        if (s == null) return;
        if (s.active && p instanceof ServerPlayer sp) {
            s.active = false;
            s.targets = new int[0];
            send(sp, s);
        }
        STATES.remove(p);
    }

    // ---------------- per tick ----------------
    public static void tick(ServerPlayer sp) {
        State s = STATES.get(sp);
        if (s == null) return;
        if (s.cooldown > 0) s.cooldown--;
        if (!s.active) return;

        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || !sp.isAlive()) {
            dismiss(sp, s, null);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level) || level.dimension() != s.dim) {
            dismiss(sp, s, null);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            dismiss(sp, s, "\u00a75Forced Zetsu: Doctor Blythe vanishes");
            return;
        }
        double range = Tuning.BLYTHE_TETHER_RANGE;
        if (sp.position().distanceToSqr(s.anchor) > range * range) {
            dismiss(sp, s, "\u00a77The tail snaps: Doctor Blythe is lost");
            return;
        }
        if (sp.tickCount % 20 == 0) {
            if (c.getCurrentEnergy() < Tuning.BLYTHE_UPKEEP) {
                dismiss(sp, s, "\u00a7cEnergy depleted! Doctor Blythe withdrawn.");
                return;
            }
            c.consumeEnergy(Tuning.BLYTHE_UPKEEP);
        }
        if (sp.tickCount % 5 == 0) { // BLYTHE_PULSE_TICKS is a multiple of 5, so every pulse lands on one of these
            List<LivingEntity> touched = contacts(sp, level, s);
            syncTargets(sp, s, touched);
            if (sp.tickCount % Tuning.BLYTHE_PULSE_TICKS == 0) pulse(sp, c, level, touched);
        }
    }

    // ---------------- contact + healing ----------------
    /** Centre of the zone the fingers cover: where the user stood when summoning it. */
    private static Vec3 zone(State s) {
        return s.anchor.add(s.forward.scale(Tuning.BLYTHE_BEHIND)).add(0, 1.0, 0);
    }

    private static boolean eligible(ServerPlayer owner, LivingEntity e) {
        if (e == owner) return true;
        if (Tuning.BLYTHE_HEALS_ENEMIES) return true;
        return AllianceUtils.isAlly(e, owner);
    }

    /** Everything its fingers can touch right now, nearest first, at most one per finger. */
    private static List<LivingEntity> contacts(ServerPlayer sp, ServerLevel level, State s) {
        Vec3 center = zone(s);
        double r = Tuning.BLYTHE_REACH;
        AABB box = new AABB(center, center).inflate(r, 3.0, r);
        List<LivingEntity> list = new ArrayList<>();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (!e.isAlive() || e instanceof ArmorStand || SkillHunter.isFake(e) || !eligible(sp, e)) continue;
            Vec3 mid = e.position().add(0, e.getBbHeight() * 0.5, 0);
            if (mid.distanceToSqr(center) > r * r) continue;
            list.add(e);
        }
        list.sort(Comparator.comparingDouble(e -> e.position().distanceToSqr(center)));
        return list.size() > Tuning.BLYTHE_MAX_TARGETS ? new ArrayList<>(list.subList(0, Tuning.BLYTHE_MAX_TARGETS)) : list;
    }

    private static void pulse(ServerPlayer sp, Combat c, ServerLevel level, List<LivingEntity> touched) {
        float amount = Tuning.blytheHealPerPulse(c.getHatsuLevel());
        boolean healed = false;
        for (LivingEntity e : touched) {
            if (e.getHealth() >= e.getMaxHealth()) continue;
            if (c.getCurrentEnergy() < Tuning.BLYTHE_HEAL_COST) break; // out of energy: no more healing this pulse
            c.consumeEnergy(Tuning.BLYTHE_HEAL_COST);
            e.heal(amount);
            healed = true;
            level.sendParticles(ParticleTypes.HEART, e.getX(), e.getY() + e.getBbHeight() + 0.2, e.getZ(), 1, 0.3, 0.1, 0.3, 0.0);
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 3, 0.3, 0.4, 0.3, 0.0);
        }
        if (healed && sp.tickCount % 40 == 0) playSound(sp, SoundEvents.AMETHYST_BLOCK_CHIME, 0.5f, 0.7f);
    }

    // ---------------- networking ----------------
    private static void syncTargets(ServerPlayer sp, State s, List<LivingEntity> touched) {
        int[] ids = touched.stream().mapToInt(Entity::getId).toArray();
        if (Arrays.equals(ids, s.targets)) return;
        s.targets = ids;
        send(sp, s);
    }

    private static void send(ServerPlayer sp, State s) {
        AddonNetwork.sendToTrackingAndSelf(new PacketBlytheFx(sp.getId(), s.active,
            s.anchor.x, s.anchor.y, s.anchor.z, s.yaw, s.targets), sp);
    }

    /** A player who comes into view of someone with Blythe out sees it straight away. */
    public static void sendTo(ServerPlayer owner, ServerPlayer viewer) {
        State s = STATES.get(owner);
        if (s == null || !s.active) return;
        AddonNetwork.sendToPlayer(new PacketBlytheFx(owner.getId(), true,
            s.anchor.x, s.anchor.y, s.anchor.z, s.yaw, s.targets), viewer);
    }

    private static void playSound(ServerPlayer sp, SoundEvent ev, float vol, float pitch) {
        sp.level().playSound(null, sp.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }
}
