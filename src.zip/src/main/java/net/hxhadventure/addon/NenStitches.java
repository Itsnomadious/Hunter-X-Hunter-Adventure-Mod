package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketStitchFx;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Machi's Nen Stitches (Hatsu kit 25, Transmuters): the user turns their aura into threads.
 * <ul>
 *   <li><b>H: Nen Threads.</b> Switches a mode on and off. While it is on, Attack, Strong attack and Barrage are carried out as slashes of
 *       threads over the ground ahead ({@link NenStitchesTuning#SLASH_LENGTH} x {@link NenStitchesTuning#SLASH_WIDTH} blocks; the Strong
 *       attack reaches {@link NenStitchesTuning#STRONG_LENGTH}) with slashing animations.</li>
 *   <li><b>Z, Nen Thread Trap.</b> Press Z while looking at a block to anchor a thread there, then look at another and press Z again to
 *       stretch the thread between them. Whoever walks through it breaks it and takes damage. The thread is invisible unless the viewer has
 *       Gyo on. Shift+Z drops an anchor that has been placed but not connected; HOLD Shift+Z for 3 s to remove every thread you have out.</li>
 *   <li><b>Z, Thread Bind.</b> Ties whoever you are looking at up in threads for {@link NenStitchesTuning#BIND_BASE_TICKS} ticks (3 s). Keep
 *       holding Z while looking at them from within {@link NenStitchesTuning#BIND_HOLD_RANGE} blocks to hold them for up to
 *       {@link NenStitchesTuning#BIND_MAX_TICKS} ticks (10 s).</li>
 *   <li><b>Z, Wound Sewing.</b> Hold Z with your fingers flying: whoever you are looking at is healed for as long as the key is held.
 *       Hold Shift+Z to sew up yourself.</li>
 * </ul>
 * Everything is decided here on the server; clients are only told what to draw ({@link PacketStitchFx}). Forge hooks: {@link NenStitchesEvents}.
 */
public final class NenStitches {
    private NenStitches() {}

    public static final int KIT = 25;
    public static final String TRAP_ID = "nen_stitch_trap";
    public static final String BIND_ID = "nen_stitch_bind";
    public static final String SEW_ID = "nen_stitch_sew";
    private static final String NAME = "Nen Stitches";
    private static final String NAME_TRAP = "Nen Thread Trap";
    private static final String NAME_BIND = "Thread Bind";
    private static final String NAME_SEW = "Wound Sewing";

    public static final int ATTACK = 0, STRONG = 1, BARRAGE = 2;

    private static final class Trap {
        int id;
        ResourceKey<Level> dim;
        Vec3 a, b, mid;
        BlockPos blockA, blockB;
        AABB box;
        long placed;
    }

    private static final class Bind {
        UUID target;
        long start;
        int upkeepClock;
    }

    private static final class Sew {
        long start;
        int target = -1;
        boolean release;
    }

    private static final class State {
        boolean on;
        // the first anchor of a thread being placed
        Vec3 pendingPos;
        BlockPos pendingBlock;
        ResourceKey<Level> pendingDim;
        long pendingAt;
        final List<Trap> traps = new ArrayList<>();
        Bind bind;
        Sew sew;
        // slashes
        boolean left;
        long slashReadyAt;
        int strongStart = -1, strongLast = -1;
        int barrageLast = -1, barrageTicks;
        long barrageCoolUntil;
        // Shift+Z held: removes every thread (player tick count when the hold began, -1 = not holding)
        int clearStart = -1;
    }

    private static final Map<UUID, State> STATES = new ConcurrentHashMap<>();
    private static final Map<String, Long> READY = new ConcurrentHashMap<>();
    /** Players whose Z key is down right now, as last reported by the client. */
    private static final Set<UUID> Z_DOWN = ConcurrentHashMap.newKeySet();
    /** Players whose client was last sent a non-empty list of threads (so an empty one is sent once to wipe it). */
    private static final Set<UUID> SENT_THREADS = ConcurrentHashMap.newKeySet();
    private static final AtomicInteger TRAP_IDS = new AtomicInteger(1);

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    /** Is the user's Nen Threads mode (H) on right now? */
    public static boolean isOn(Player p) {
        State s = p == null ? null : STATES.get(p.getUUID());
        return s != null && s.on;
    }

    /** Adds the skills to the Z list once the Hatsu level allows them (runs on the client too, so the menu shows them). */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c)) return base;
        List<String> out = new ArrayList<>(Arrays.asList(base));
        int lvl = c.getHatsuLevel();
        if (lvl >= NenStitchesTuning.TRAP_MIN_LEVEL) out.add(TRAP_ID);
        if (lvl >= NenStitchesTuning.BIND_MIN_LEVEL) out.add(BIND_ID);
        if (lvl >= NenStitchesTuning.SEW_MIN_LEVEL) out.add(SEW_ID);
        return out.toArray(new String[0]);
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(TRAP_ID, NenStitches::placeTrap);
        m.put(BIND_ID, NenStitches::bind);
        m.put(SEW_ID, NenStitches::sew);
    }

    public static String displayName(String id) {
        return switch (id) {
            case TRAP_ID -> "\u00a7f Nen Thread Trap";
            case BIND_ID -> "\u00a7f Thread Bind";
            case SEW_ID -> "\u00a7f Wound Sewing";
            default -> null;
        };
    }

    private static State state(ServerPlayer sp) {
        return STATES.computeIfAbsent(sp.getUUID(), k -> new State());
    }

    private static void say(ServerPlayer sp, String text) {
        sp.displayClientMessage(Component.literal(text), true);
    }

    private static boolean ready(ServerPlayer sp, String name) {
        long at = READY.getOrDefault(sp.getUUID() + name, 0L);
        return !ChainManager.onCooldown(sp, name, (int) Math.max(0, at - sp.level().getGameTime()));
    }

    private static void cooldown(ServerPlayer sp, String name, int ticks) {
        READY.put(sp.getUUID() + name, sp.level().getGameTime() + ticks);
        ChainManager.startCooldown(sp, name, ticks);
    }

    private static boolean pay(ServerPlayer sp, Combat c, float cost) {
        if (c.getCurrentEnergy() < cost) {
            say(sp, "\u00a7cNot enough energy");
            return false;
        }
        c.consumeEnergy(cost);
        return true;
    }

    private static void anim(ServerPlayer sp, String name, boolean barrage) {
        ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(sp.getUUID(), name, barrage), sp);
    }

    private static Combat gate(ServerPlayer sp, int minLevel, String name) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return null;
        if (!canUse(c)) {
            say(sp, "\u00a7cYour Hatsu is not Nen Stitches");
            return null;
        }
        if (c.getHatsuLevel() < minLevel) {
            say(sp, "\u00a7c" + name + " unlocks at Level " + minLevel);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            say(sp, "\u00a75Forced Zetsu: your aura will not answer");
            return null;
        }
        if (HatsuEffects.isStunned(sp)) return null;
        return c;
    }

    /** Anything the user may hurt or tie up. */
    private static boolean hostile(ServerPlayer sp, Entity e) {
        if (!(e instanceof LivingEntity le) || le == sp || !le.isAlive() || e instanceof ArmorStand) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        return !AllianceUtils.isAlly(e, sp);
    }

    private static Vec3 flatLook(ServerPlayer sp) {
        return Vec3.directionFromRotation(0, sp.getYRot());
    }

    /** The user's right-hand side as seen from behind (flat). */
    private static Vec3 rightOf(Vec3 flat) {
        return new Vec3(-flat.z, 0, flat.x);
    }

    // ---------------------------------------------------------------- H: Nen Threads mode

    public static void toggle(ServerPlayer sp) {
        Combat c = gate(sp, NenStitchesTuning.THREADS_MIN_LEVEL, NAME);
        if (c == null) return;
        State s = state(sp);
        s.on = !s.on;
        if (!s.on) cancelCharges(sp, s);
        say(sp, s.on ? "\u00a7fNen Stitches: Threads on \u00a77(Attack, Strong attack and Barrage are slashes)" : "\u00a77Nen Stitches: Threads off");
        sp.level().playSound(null, sp.blockPosition(), s.on ? SoundEvents.AMETHYST_BLOCK_CHIME : SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 0.9f, s.on ? 1.8f : 1.3f);
    }

    private static void cancelCharges(ServerPlayer sp, State s) {
        if (s.strongStart >= 0) anim(sp, "stop_anim", false);
        s.strongStart = -1;
        s.strongLast = -1;
        s.barrageLast = -1;
        s.barrageTicks = 0;
    }

    // ---------------------------------------------------------------- Attack / Strong attack / Barrage become slashes

    /**
     * Called before every ability runs (AbilityRegistryMixin), after the Vow gate. While the Threads mode is on, the user's three basic
     * attacks are carried out as slashes instead and this returns true (the normal attack is cancelled).
     */
    public static boolean interceptBasic(String id, ServerPlayer sp) {
        State s = STATES.get(sp.getUUID());
        if (s == null || !s.on) return false;
        if (!"nen_attack".equals(id) && !"nen_strong".equals(id) && !"nen_strong_release".equals(id) && !"nen_barrage".equals(id)) return false;
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c)) {
            s.on = false;
            return false;
        }
        if (ExtrasHooks.hatsuForced(sp) || HatsuEffects.isStunned(sp)) {
            s.on = false;
            cancelCharges(sp, s);
            say(sp, "\u00a75Forced Zetsu: your aura will not answer");
            return false;
        }
        long now = sp.level().getGameTime();
        switch (id) {
            case "nen_attack" -> {
                if (now < s.slashReadyAt) return true;
                if (!pay(sp, c, NenStitchesTuning.ATTACK_COST)) return true;
                s.slashReadyAt = now + NenStitchesTuning.ATTACK_COOLDOWN_TICKS;
                slash(sp, c, s, ATTACK, 0f);
            }
            case "nen_strong" -> {
                s.strongLast = sp.tickCount;
                if (s.strongStart < 0 && now >= s.slashReadyAt) {
                    s.strongStart = sp.tickCount;
                    s.barrageLast = -1;
                    anim(sp, "slash_charge", false);
                }
            }
            case "nen_strong_release" -> {
                if (s.strongStart < 0) return true;
                float progress = Math.min(1f, (sp.tickCount - s.strongStart) / (float) NenStitchesTuning.STRONG_CHARGE_TICKS);
                s.strongStart = -1;
                s.strongLast = -1;
                if (now < s.slashReadyAt || !pay(sp, c, NenStitchesTuning.STRONG_COST)) {
                    anim(sp, "stop_anim", false);
                    return true;
                }
                s.slashReadyAt = now + NenStitchesTuning.STRONG_COOLDOWN_TICKS;
                slash(sp, c, s, STRONG, progress);
            }
            case "nen_barrage" -> {
                if (now < s.barrageCoolUntil) return true;
                if (s.strongStart >= 0) {
                    s.strongStart = -1;
                    s.strongLast = -1;
                    anim(sp, "stop_anim", false);
                }
                s.barrageLast = sp.tickCount;
                if (s.barrageTicks <= 0) s.barrageTicks = 0;
            }
            default -> { }
        }
        return true;
    }

    /** Per tick while the mode is on: drops a charge whose key-up was lost and fires the slashes of a held barrage. */
    private static void tickBasics(ServerPlayer sp, Combat c, State s, ServerLevel level) {
        if (s.strongStart >= 0 && sp.tickCount - s.strongLast > 5) {
            s.strongStart = -1;
            s.strongLast = -1;
            anim(sp, "stop_anim", false);
        }
        if (s.barrageLast < 0) return;
        if (sp.tickCount - s.barrageLast > 5 || s.barrageTicks >= NenStitchesTuning.BARRAGE_MAX_TICKS) {
            s.barrageLast = -1;
            s.barrageTicks = 0;
            s.barrageCoolUntil = level.getGameTime() + NenStitchesTuning.BARRAGE_COOLDOWN_TICKS;
            return;
        }
        s.barrageTicks++;
        if (s.barrageTicks % NenStitchesTuning.BARRAGE_INTERVAL_TICKS != 1) return;
        if (c.getCurrentEnergy() < NenStitchesTuning.BARRAGE_COST) {
            say(sp, "\u00a7cNot enough energy");
            s.barrageLast = -1;
            s.barrageTicks = 0;
            s.barrageCoolUntil = level.getGameTime() + NenStitchesTuning.BARRAGE_COOLDOWN_TICKS;
            return;
        }
        c.consumeEnergy(NenStitchesTuning.BARRAGE_COST);
        slash(sp, c, s, BARRAGE, 0f);
    }

    /** One slash of threads over the rectangle that starts at the user and runs ahead of them. */
    private static void slash(ServerPlayer sp, Combat c, State s, int kind, float progress) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        double length = kind == STRONG ? NenStitchesTuning.STRONG_LENGTH : NenStitchesTuning.SLASH_LENGTH;
        double width = kind == STRONG ? NenStitchesTuning.STRONG_WIDTH : NenStitchesTuning.SLASH_WIDTH;
        float base = switch (kind) {
            case STRONG -> NenStitchesTuning.ATTACK_DAMAGE + (NenStitchesTuning.STRONG_DAMAGE - NenStitchesTuning.ATTACK_DAMAGE) * progress;
            case BARRAGE -> NenStitchesTuning.BARRAGE_DAMAGE;
            default -> NenStitchesTuning.ATTACK_DAMAGE;
        };
        double kb = switch (kind) {
            case STRONG -> NenStitchesTuning.ATTACK_KNOCKBACK + (NenStitchesTuning.STRONG_KNOCKBACK - NenStitchesTuning.ATTACK_KNOCKBACK) * progress;
            case BARRAGE -> NenStitchesTuning.BARRAGE_KNOCKBACK;
            default -> NenStitchesTuning.ATTACK_KNOCKBACK;
        };
        String attackId = switch (kind) {
            case STRONG -> Vows.STRONG;
            case BARRAGE -> Vows.BARRAGE;
            default -> Vows.ATTACK;
        };
        float damage = base * c.getSpiritBonus() * Vows.power(sp, attackId) * Vows.hatsuDamageMult(sp);

        Vec3 f = flatLook(sp);
        Vec3 r = rightOf(f);
        boolean left = kind != STRONG && s.left;
        if (kind != STRONG) s.left = !s.left; // alternate hands
        int hits = slashHit(sp, level, f, r, length, width, damage, kb);

        Vec3 hand = sp.position().add(0, sp.getEyeHeight() * 0.72, 0).add(f.scale(0.4)).add(r.scale(left ? -0.35 : 0.35));
        AddonNetwork.sendToTrackingAndSelf(PacketStitchFx.slash(sp.getId(), hand, f.x, f.z, length, width, kind, left), sp);
        String animName = kind == STRONG ? "slash_strong"
            : kind == BARRAGE ? (left ? "slash_fast_left" : "slash_fast_right")
            : (left ? "slash_left" : "slash_right");
        anim(sp, animName, kind == BARRAGE);
        sp.swing(InteractionHand.MAIN_HAND, true);
        level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, kind == STRONG ? 1.2f : 0.7f, kind == STRONG ? 0.8f : 1.5f + level.random.nextFloat() * 0.3f);
        if (kind == STRONG) level.playSound(null, sp.blockPosition(), SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 1.0f, 1.4f);
        if (hits > 0 && kind != BARRAGE) level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 0.8f, 1.6f);
    }

    /** Hurts everything hostile in the rectangle (length ahead, width across, from just below the user's feet to above their head). */
    private static int slashHit(ServerPlayer sp, ServerLevel level, Vec3 f, Vec3 r, double length, double width, float damage, double knockback) {
        Vec3 origin = sp.position();
        Vec3 eye = sp.getEyePosition();
        double reach = length * 0.5 + width * 0.5 + 2.0;
        Vec3 centre = origin.add(f.scale(length * 0.5));
        AABB box = new AABB(centre.x - reach, sp.getY() - NenStitchesTuning.SLASH_BELOW - 3.0, centre.z - reach,
            centre.x + reach, sp.getY() + NenStitchesTuning.SLASH_ABOVE + 3.0, centre.z + reach);
        int hits = 0;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> hostile(sp, x))) {
            double ex = e.getX() - origin.x, ez = e.getZ() - origin.z;
            double along = ex * f.x + ez * f.z;
            double across = ex * r.x + ez * r.z;
            double hw = e.getBbWidth() * 0.5;
            if (along < -0.3 - hw || along > length + hw || Math.abs(across) > width * 0.5 + hw) continue;
            if (e.getY() > sp.getY() + NenStitchesTuning.SLASH_ABOVE || e.getY() + e.getBbHeight() < sp.getY() - NenStitchesTuning.SLASH_BELOW) continue;
            Vec3 core = e.position().add(0, e.getBbHeight() * 0.5, 0);
            if (level.clip(new ClipContext(eye, core, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp)).getType() != HitResult.Type.MISS) continue; // threads do not pass through walls
            e.invulnerableTime = 0;
            Vows.hatsuHurt(e, level.damageSources().playerAttack(sp), damage);
            e.knockback(knockback, sp.getX() - e.getX(), sp.getZ() - e.getZ());
            e.hurtMarked = true;
            level.sendParticles(ParticleTypes.CRIT, core.x, core.y, core.z, 6, 0.3, 0.4, 0.3, 0.15);
            hits++;
        }
        return hits;
    }

    // ---------------------------------------------------------------- aiming helpers

    /** The first creature along the user's line of sight, within range and not behind a wall (the same kind of ray the game uses for melee). */
    private static LivingEntity lookTarget(ServerPlayer sp, ServerLevel level, double range, boolean needHostile) {
        Vec3 eye = sp.getEyePosition();
        Vec3 end = eye.add(sp.getLookAngle().normalize().scale(range));
        HitResult wall = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        double wallDist = wall.getType() == HitResult.Type.MISS ? range + 1 : wall.getLocation().distanceTo(eye);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(1.5),
            x -> x != sp && x.isAlive() && !(x instanceof ArmorStand) && (!needHostile || hostile(sp, x)))) {
            AABB bb = e.getBoundingBox().inflate(0.3);
            Optional<Vec3> hit = bb.clip(eye, end);
            if (hit.isEmpty() && !bb.contains(eye)) continue;
            double dist = hit.isPresent() ? eye.distanceTo(hit.get()) : 0;
            if (dist > wallDist || dist >= bestDist) continue;
            bestDist = dist;
            best = e;
        }
        return best;
    }

    /** Distance from a point to the nearest point of a box (0 when inside). */
    private static double gap(Vec3 p, AABB bb) {
        double dx = Math.max(Math.max(bb.minX - p.x, 0), p.x - bb.maxX);
        double dy = Math.max(Math.max(bb.minY - p.y, 0), p.y - bb.maxY);
        double dz = Math.max(Math.max(bb.minZ - p.z, 0), p.z - bb.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ---------------------------------------------------------------- Nen Thread Trap

    public static void placeTrap(ServerPlayer sp) {
        Combat c = gate(sp, NenStitchesTuning.TRAP_MIN_LEVEL, NAME_TRAP);
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        State s = state(sp);
        if (sp.isShiftKeyDown()) {
            // Shift+Z: drops an anchor that was never connected; HOLDING it for 3 s removes every thread
            boolean hadAnchor = s.pendingPos != null;
            if (hadAnchor) clearPending(sp, s);
            if (s.traps.isEmpty() && s.bind == null) {
                say(sp, hadAnchor ? "\u00a77The anchored thread is let go" : "\u00a77You have no threads out");
                return;
            }
            if (s.clearStart < 0) {
                s.clearStart = sp.tickCount;
                say(sp, (hadAnchor ? "\u00a77Anchor let go. " : "") + "\u00a7fKeep holding Shift+Z for "
                    + (NenStitchesTuning.CLEAR_HOLD_TICKS / 20) + "s to remove every thread");
            }
            return;
        }
        if (!ready(sp, NAME_TRAP)) return;
        Vec3 eye = sp.getEyePosition();
        Vec3 end = eye.add(sp.getLookAngle().normalize().scale(NenStitchesTuning.TRAP_PLACE_RANGE));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, sp));
        if (hit.getType() != HitResult.Type.BLOCK) {
            say(sp, "\u00a7cLook at a block to anchor a thread");
            return;
        }
        Vec3 p = hit.getLocation().add(Vec3.atLowerCornerOf(hit.getDirection().getNormal()).scale(0.04)); // a hair off the surface, so it is not inside the block
        BlockPos support = hit.getBlockPos();

        boolean fresh = s.pendingPos == null || !level.dimension().equals(s.pendingDim);
        if (fresh) { // the first anchor
            s.pendingPos = p;
            s.pendingDim = level.dimension();
            s.pendingAt = level.getGameTime();
            s.pendingBlock = support;
            AddonNetwork.sendToPlayer(PacketStitchFx.pending(p), sp);
            anim(sp, "thread_flick", false);
            say(sp, "\u00a7fThread anchored \u00a77: look at another block and press Z again (Shift+Z to let go)");
            level.playSound(null, sp.blockPosition(), SoundEvents.TRIPWIRE_ATTACH, SoundSource.PLAYERS, 0.8f, 1.8f);
            return;
        }

        double len = s.pendingPos.distanceTo(p);
        if (len < NenStitchesTuning.TRAP_MIN_LENGTH) {
            say(sp, "\u00a7cToo short: pick a block further from the first anchor");
            return;
        }
        if (len > NenStitchesTuning.TRAP_MAX_LENGTH) {
            say(sp, String.format(java.util.Locale.ROOT, "\u00a7cThe thread would be %.0f blocks long (the most is %.0f)", len, NenStitchesTuning.TRAP_MAX_LENGTH));
            return;
        }
        if (s.traps.size() >= NenStitchesTuning.TRAP_MAX_ACTIVE) {
            say(sp, "\u00a7cYou already have " + NenStitchesTuning.TRAP_MAX_ACTIVE + " threads out");
            return;
        }
        if (!pay(sp, c, NenStitchesTuning.TRAP_COST)) return;

        Trap t = new Trap();
        t.id = TRAP_IDS.getAndIncrement();
        t.dim = level.dimension();
        t.a = s.pendingPos;
        t.b = p;
        t.mid = t.a.add(t.b).scale(0.5);
        t.blockA = s.pendingBlock;
        t.blockB = support;
        t.box = new AABB(t.a, t.b).inflate(0.35);
        t.placed = level.getGameTime();
        s.traps.add(t);
        clearPending(sp, s);
        cooldown(sp, NAME_TRAP, NenStitchesTuning.TRAP_COOLDOWN_TICKS);
        AddonNetwork.sendToNear(PacketStitchFx.trapAdd(new PacketStitchFx.TrapData(t.id, sp.getId(), t.a, t.b)), level, t.mid, NenStitchesTuning.TRAP_SYNC_RANGE);
        anim(sp, "thread_flick", false);
        say(sp, "\u00a7fThread set \u00a77(" + s.traps.size() + "/" + NenStitchesTuning.TRAP_MAX_ACTIVE + ")");
        level.playSound(null, sp.blockPosition(), SoundEvents.TRIPWIRE_CLICK_ON, SoundSource.PLAYERS, 0.8f, 1.9f);
    }

    /** Shift+Z held: after {@link NenStitchesTuning#CLEAR_HOLD_TICKS} every thread (traps, an unconnected anchor, a bind) is removed. */
    private static void tickClear(ServerPlayer sp, State s, ServerLevel level) {
        if (s.clearStart < 0) return;
        int elapsed = sp.tickCount - s.clearStart;
        // letting go of Z or Shift cancels it (the first few ticks are grace for the key packet to arrive)
        if (elapsed >= 4 && (!Z_DOWN.contains(sp.getUUID()) || !sp.isShiftKeyDown())) {
            s.clearStart = -1;
            say(sp, "\u00a77Thread removal cancelled");
            return;
        }
        if (s.traps.isEmpty() && s.bind == null) {
            s.clearStart = -1;
            return;
        }
        if (elapsed < NenStitchesTuning.CLEAR_HOLD_TICKS) {
            if (elapsed % 5 == 0) {
                say(sp, String.format(java.util.Locale.ROOT, "\u00a7fRemoving threads... %.1fs \u00a77of %.0fs",
                    elapsed / 20.0, NenStitchesTuning.CLEAR_HOLD_TICKS / 20.0));
            }
            return;
        }
        s.clearStart = -1;
        int removed = s.traps.size();
        MinecraftServer server = sp.getServer();
        for (Trap t : s.traps) {
            ServerLevel lv = server == null ? null : server.getLevel(t.dim);
            if (lv != null) snapped(lv, t, null);
        }
        s.traps.clear();
        if (s.bind != null) {
            endBind(sp, s, level, true);
            removed++;
        }
        clearPending(sp, s);
        say(sp, "\u00a7fEvery thread removed \u00a77(" + removed + ")");
        level.playSound(null, sp.blockPosition(), SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 1.0f, 1.2f);
    }

    private static void clearPending(ServerPlayer sp, State s) {
        if (s.pendingPos == null) return;
        s.pendingPos = null;
        s.pendingDim = null;
        s.pendingBlock = null;
        AddonNetwork.sendToPlayer(PacketStitchFx.pendingClear(), sp);
    }

    private static boolean supported(ServerLevel lv, BlockPos pos) {
        return !lv.isLoaded(pos) || !lv.getBlockState(pos).isAir();
    }

    /** Does this creature's body touch the thread? */
    private static boolean crosses(LivingEntity e, Trap t) {
        AABB bb = e.getBoundingBox().inflate(0.1);
        return bb.contains(t.a) || bb.contains(t.b) || bb.clip(t.a, t.b).isPresent();
    }

    private static boolean trapVictim(ServerPlayer owner, LivingEntity e) {
        if (e == owner || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, owner)) return false;
        return !(e instanceof Player p && (p.isCreative() || p.isSpectator()));
    }

    private static void tickTraps(ServerPlayer sp, State s) {
        if (s.traps.isEmpty()) return;
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        Combat c = Combat.get(sp);
        int hatsuLevel = c == null ? 1 : c.getHatsuLevel();
        Iterator<Trap> it = s.traps.iterator();
        while (it.hasNext()) {
            Trap t = it.next();
            ServerLevel lv = server.getLevel(t.dim);
            if (lv == null) continue;
            if (NenStitchesTuning.TRAP_LIFETIME_TICKS > 0 && lv.getGameTime() - t.placed > NenStitchesTuning.TRAP_LIFETIME_TICKS) {
                it.remove();
                snapped(lv, t, null);
                continue;
            }
            if (sp.tickCount % 20 == 0 && (!supported(lv, t.blockA) || !supported(lv, t.blockB))) { // what it was tied to is gone
                it.remove();
                snapped(lv, t, null);
                continue;
            }
            if (sp.tickCount % 2 != 0) continue;
            final Trap trap = t;
            List<LivingEntity> hits = lv.getEntitiesOfClass(LivingEntity.class, t.box, e -> trapVictim(sp, e) && crosses(e, trap));
            if (hits.isEmpty()) continue;
            it.remove();
            float dmg = (NenStitchesTuning.TRAP_BASE_DAMAGE + hatsuLevel * NenStitchesTuning.TRAP_DAMAGE_PER_LEVEL) * Vows.power(sp, TRAP_ID);
            for (LivingEntity e : hits) {
                e.invulnerableTime = 0;
                Vows.hatsuHurt(e, lv.damageSources().playerAttack(sp), dmg);
            }
            snapped(lv, t, hits.get(0));
            say(sp, "\u00a7fA thread was cut by " + hits.get(0).getName().getString());
        }
    }

    /** A thread is gone: clients stop drawing it (with a flash and a sound when something cut it). */
    private static void snapped(ServerLevel lv, Trap t, LivingEntity by) {
        if (by == null) {
            AddonNetwork.sendToNear(PacketStitchFx.trapRemove(t.id), lv, t.mid, NenStitchesTuning.TRAP_SYNC_RANGE);
            return;
        }
        Vec3 at = by.position().add(0, by.getBbHeight() * 0.5, 0);
        AddonNetwork.sendToNear(PacketStitchFx.trapBreak(t.id, at), lv, t.mid, NenStitchesTuning.TRAP_SYNC_RANGE);
        lv.playSound(null, at.x, at.y, at.z, SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 1.0f, 1.6f);
        lv.playSound(null, at.x, at.y, at.z, SoundEvents.TRIPWIRE_CLICK_OFF, SoundSource.PLAYERS, 1.0f, 1.5f);
        lv.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 12, 0.3, 0.4, 0.3, 0.2);
    }

    /** Every few seconds each player is told about every thread near them (so a thread is there for someone who arrives later, and stale ones go). */
    private static void syncViewer(ServerPlayer viewer) {
        if (viewer.tickCount % 100 != 17) return;
        MinecraftServer server = viewer.getServer();
        if (server == null) return;
        List<PacketStitchFx.TrapData> list = new ArrayList<>();
        Vec3 pos = viewer.position();
        double r2 = NenStitchesTuning.TRAP_SYNC_RANGE * NenStitchesTuning.TRAP_SYNC_RANGE;
        for (Map.Entry<UUID, State> en : STATES.entrySet()) {
            if (en.getValue().traps.isEmpty()) continue;
            ServerPlayer owner = server.getPlayerList().getPlayer(en.getKey());
            int ownerId = owner == null ? -1 : owner.getId();
            for (Trap t : en.getValue().traps) {
                if (t.dim.equals(viewer.level().dimension()) && t.mid.distanceToSqr(pos) <= r2) list.add(new PacketStitchFx.TrapData(t.id, ownerId, t.a, t.b));
            }
        }
        if (list.isEmpty() && !SENT_THREADS.contains(viewer.getUUID())) return;
        if (list.isEmpty()) SENT_THREADS.remove(viewer.getUUID());
        else SENT_THREADS.add(viewer.getUUID());
        AddonNetwork.sendToPlayer(PacketStitchFx.trapSync(list), viewer);
    }

    // ---------------------------------------------------------------- Thread Bind

    public static void bind(ServerPlayer sp) {
        Combat c = gate(sp, NenStitchesTuning.BIND_MIN_LEVEL, NAME_BIND);
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        State s = state(sp);
        if (s.bind != null || !ready(sp, NAME_BIND)) return;
        LivingEntity target = lookTarget(sp, level, NenStitchesTuning.BIND_RANGE, true);
        if (target == null) {
            say(sp, "\u00a7cNo one in sight to bind");
            return;
        }
        if (!pay(sp, c, NenStitchesTuning.BIND_COST)) return;
        Bind b = new Bind();
        b.target = target.getUUID();
        b.start = level.getGameTime();
        s.bind = b;
        holdStill(target);
        AddonNetwork.sendToNear(PacketStitchFx.bind(sp.getId(), target.getId()), level, target.position(), 96);
        anim(sp, "thread_point", false);
        say(sp, "\u00a7fThread Bind \u00a77(hold Z within " + (int) NenStitchesTuning.BIND_HOLD_RANGE + " blocks to keep them)");
        level.playSound(null, target.blockPosition(), SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 1.0f, 1.7f);
        level.playSound(null, target.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8f, 2.0f);
    }

    /** Freezes the creature for a moment (renewed every few ticks while the bind lasts). Not stopped by a Lightning Aura user's stun immunity. */
    private static void holdStill(LivingEntity t) {
        if (HatsuEffects.LIGHTNING_STUN == null) return;
        MobEffectInstance cur = t.getEffect(HatsuEffects.LIGHTNING_STUN);
        if (cur == null || cur.getDuration() < 8) t.addEffect(new MobEffectInstance(HatsuEffects.LIGHTNING_STUN, 12, 0, false, false, true));
        if (t instanceof Mob m) m.getNavigation().stop();
        t.setDeltaMovement(0, Math.min(0, t.getDeltaMovement().y), 0);
    }

    private static void tickBind(ServerPlayer sp, State s, ServerLevel level) {
        Bind b = s.bind;
        if (b == null) return;
        if (!(level.getEntity(b.target) instanceof LivingEntity t) || !t.isAlive()) {
            endBind(sp, s, level, true);
            return;
        }
        long elapsed = level.getGameTime() - b.start;
        if (elapsed >= NenStitchesTuning.BIND_BASE_TICKS) {
            // past the 3 seconds only the hold keeps them: Z down, the target in front of the user, and close
            boolean holding = Z_DOWN.contains(sp.getUUID())
                && gap(sp.getEyePosition(), t.getBoundingBox()) <= NenStitchesTuning.BIND_HOLD_RANGE
                && sp.getLookAngle().normalize().dot(t.position().add(0, t.getBbHeight() * 0.5, 0).subtract(sp.getEyePosition()).normalize()) >= 0.8;
            Combat c = Combat.get(sp);
            if (!holding || elapsed >= NenStitchesTuning.BIND_MAX_TICKS || c == null) {
                endBind(sp, s, level, true);
                return;
            }
            if (++b.upkeepClock >= 20) {
                b.upkeepClock = 0;
                if (c.getCurrentEnergy() < NenStitchesTuning.BIND_HOLD_UPKEEP) {
                    say(sp, "\u00a7cNot enough energy to keep holding them");
                    endBind(sp, s, level, true);
                    return;
                }
                c.consumeEnergy(NenStitchesTuning.BIND_HOLD_UPKEEP);
            }
            if (elapsed % 10 == 0) say(sp, String.format(java.util.Locale.ROOT, "\u00a7fHolding: %.1fs \u00a77of %.0fs", elapsed / 20.0, NenStitchesTuning.BIND_MAX_TICKS / 20.0));
        }
        if (sp.tickCount % 4 == 0) holdStill(t);
        else if (t.getDeltaMovement().y > 0) t.setDeltaMovement(0, 0, 0);
        if (elapsed % 40 == 0) AddonNetwork.sendToNear(PacketStitchFx.bind(sp.getId(), t.getId()), level, t.position(), 96); // late arrivals see the threads too
    }

    private static void endBind(ServerPlayer sp, State s, ServerLevel level, boolean withCooldown) {
        Bind b = s.bind;
        if (b == null) return;
        s.bind = null;
        if (level.getEntity(b.target) instanceof LivingEntity t) {
            HatsuEffects.removeStun(t);
            AddonNetwork.sendToNear(PacketStitchFx.bindEnd(t.getId()), level, t.position(), 96);
            level.playSound(null, t.blockPosition(), SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 0.8f, 1.5f);
        }
        if (withCooldown) cooldown(sp, NAME_BIND, NenStitchesTuning.BIND_COOLDOWN_TICKS);
    }

    // ---------------------------------------------------------------- Wound Sewing

    public static void sew(ServerPlayer sp) {
        Combat c = gate(sp, NenStitchesTuning.SEW_MIN_LEVEL, NAME_SEW);
        if (c == null) return;
        State s = state(sp);
        if (s.sew != null || !ready(sp, NAME_SEW)) return;
        if (c.getCurrentEnergy() < NenStitchesTuning.SEW_MIN_ENERGY) {
            say(sp, "\u00a7cNot enough energy");
            return;
        }
        Sew z = new Sew();
        z.start = sp.level().getGameTime();
        s.sew = z;
        say(sp, "\u00a7fWound Sewing \u00a77(hold Z at someone, Shift+Z for yourself)");
    }

    /** Can this creature be sewn up? */
    private static boolean healable(LivingEntity e) {
        if (e == null || !e.isAlive() || e instanceof ArmorStand) return false;
        if (e instanceof Player p && p.isSpectator()) return false;
        return NenStitchesTuning.SEW_HEALS_MONSTERS || !(e instanceof Enemy);
    }

    private static void tickSew(ServerPlayer sp, State s, ServerLevel level) {
        Sew z = s.sew;
        if (z == null) return;
        Combat c = Combat.get(sp);
        long elapsed = level.getGameTime() - z.start;
        // a missed key-up (or a press whose hold packet never came) must not leave the hands flying for ever
        if (!z.release && elapsed >= 4 && !Z_DOWN.contains(sp.getUUID())) z.release = true;
        if (z.release || c == null) {
            endSew(sp, s, true);
            return;
        }
        LivingEntity target = sp.isShiftKeyDown() ? sp : lookTarget(sp, level, NenStitchesTuning.SEW_RANGE, false);
        if (!healable(target)) target = null;
        int id = target == null ? -1 : target.getId();
        if (id != z.target || elapsed % 10 == 0) { // tell the clients where the threads go (and now and then, for late arrivals)
            z.target = id;
            AddonNetwork.sendToTrackingAndSelf(PacketStitchFx.sew(sp.getId(), id), sp);
        }
        if (elapsed % NenStitchesTuning.SEW_PULSE_TICKS != 0 || target == null) return;
        if (target.getHealth() >= target.getMaxHealth()) {
            say(sp, target == sp ? "\u00a77You are already whole" : "\u00a77Nothing to sew up");
            return;
        }
        if (c.getCurrentEnergy() < NenStitchesTuning.SEW_PULSE_COST) {
            say(sp, "\u00a7cNot enough energy");
            endSew(sp, s, true);
            return;
        }
        c.consumeEnergy(NenStitchesTuning.SEW_PULSE_COST);
        float heal = (NenStitchesTuning.SEW_BASE_HEAL + c.getHatsuLevel() * NenStitchesTuning.SEW_HEAL_PER_LEVEL) * Vows.power(sp, SEW_ID);
        float before = target.getHealth();
        target.heal(heal);
        float healed = target.getHealth() - before;
        say(sp, String.format(java.util.Locale.ROOT, "\u00a7fWound Sewing: +%.1f HP \u00a77(%s)", healed, target == sp ? "yourself" : target.getName().getString()));
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.55, 0);
        level.sendParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 4, 0.25, 0.3, 0.25, 0.02);
        level.playSound(null, target.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.5f, 1.4f + level.random.nextFloat() * 0.6f);
    }

    private static void endSew(ServerPlayer sp, State s, boolean withCooldown) {
        if (s.sew == null) return;
        s.sew = null;
        AddonNetwork.sendToTrackingAndSelf(PacketStitchFx.sewEnd(sp.getId()), sp);
        if (withCooldown) cooldown(sp, NAME_SEW, NenStitchesTuning.SEW_COOLDOWN_TICKS);
    }

    // ---------------------------------------------------------------- Z held / released (PacketZHold)

    public static void setZHeld(ServerPlayer sp, boolean held) {
        if (held) {
            Z_DOWN.add(sp.getUUID());
            return;
        }
        Z_DOWN.remove(sp.getUUID());
        State s = STATES.get(sp.getUUID());
        if (s != null && s.sew != null) s.sew.release = true;
    }

    // ---------------------------------------------------------------- per tick

    public static void tick(ServerPlayer sp) {
        syncViewer(sp); // everyone is told about the threads near them, Nen Stitches user or not
        State s = STATES.get(sp.getUUID());
        if (s == null || !(sp.level() instanceof ServerLevel level)) return;
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || !sp.isAlive()) { // the Hatsu was changed or lost
            clear(sp);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp) || HatsuEffects.isStunned(sp)) { // Forced Zetsu or paralysis: the threads go slack
            if (s.on) {
                s.on = false;
                cancelCharges(sp, s);
            }
            endSew(sp, s, false);
        }
        if (s.pendingPos != null && (!level.dimension().equals(s.pendingDim) || level.getGameTime() - s.pendingAt > NenStitchesTuning.TRAP_PENDING_TICKS)) {
            clearPending(sp, s);
            say(sp, "\u00a77The anchored thread went slack");
        }
        if (s.on) tickBasics(sp, c, s, level);
        tickTraps(sp, s);
        tickClear(sp, s, level);
        tickBind(sp, s, level);
        tickSew(sp, s, level);
    }

    // ---------------------------------------------------------------- clean-up

    /** Everything the user had out goes (death, logout, Hatsu changed, Nen lost): threads vanish, anyone tied up is freed. */
    public static void clear(Player p) {
        Z_DOWN.remove(p.getUUID());
        State s = STATES.remove(p.getUUID());
        READY.keySet().removeIf(k -> k.startsWith(p.getUUID().toString()));
        if (s == null || !(p instanceof ServerPlayer sp)) return;
        if (s.bind != null && sp.level() instanceof ServerLevel level && level.getEntity(s.bind.target) instanceof LivingEntity t) {
            HatsuEffects.removeStun(t);
            AddonNetwork.sendToNear(PacketStitchFx.bindEnd(t.getId()), level, t.position(), 96);
        }
        if (s.sew != null) AddonNetwork.sendToTrackingAndSelf(PacketStitchFx.sewEnd(sp.getId()), sp);
        if (s.strongStart >= 0) anim(sp, "stop_anim", false);
        if (s.pendingPos != null) AddonNetwork.sendToPlayer(PacketStitchFx.pendingClear(), sp);
        MinecraftServer server = sp.getServer();
        for (Trap t : s.traps) {
            ServerLevel lv = server == null ? null : server.getLevel(t.dim);
            if (lv != null) AddonNetwork.sendToNear(PacketStitchFx.trapRemove(t.id), lv, t.mid, NenStitchesTuning.TRAP_SYNC_RANGE);
        }
    }
}
