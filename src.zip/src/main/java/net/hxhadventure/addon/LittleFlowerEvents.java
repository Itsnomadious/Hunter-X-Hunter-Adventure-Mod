package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks for {@link LittleFlower}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class LittleFlowerEvents {
    private LittleFlowerEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase == TickEvent.Phase.START && e.player instanceof ServerPlayer sp) LittleFlower.tick(sp);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) LittleFlower.serverTick(ServerLifecycleHooks.getCurrentServer());
    }

    @SubscribeEvent
    public static void onChat(ServerChatEvent e) {
        ServerPlayer sp = e.getPlayer();
        String text = e.getRawText();
        sp.server.execute(() -> LittleFlower.onChat(sp, text));
    }

    /** Touching someone (right click) is how a victim reaches Genthru. */
    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        LittleFlower.onTouch(e.getEntity(), e.getTarget());
    }

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent e) {
        LittleFlower.onTouch(e.getEntity(), e.getTarget());
        if (LittleFlower.isOn(e.getEntity())) e.setCanceled(true); // the palms replace the punch
    }

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        LittleFlower.restore(e.getEntity());
    }

    /** Somebody walks into view of a creature carrying a bomb: they get to see the bomb. */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking e) {
        if (e.getEntity() instanceof ServerPlayer sp) LittleFlower.onStartTracking(sp, e.getTarget());
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) LittleFlower.onLogin(sp);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) LittleFlower.clear(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) LittleFlower.clear(sp);
    }
}
