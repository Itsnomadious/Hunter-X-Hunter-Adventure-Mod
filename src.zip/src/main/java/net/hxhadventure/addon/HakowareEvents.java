package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks for {@link Hakoware}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class HakowareEvents {
    private HakowareEvents() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) Hakoware.serverTick(ServerLifecycleHooks.getCurrentServer());
    }

    /** Lowest priority: runs after the addon's own damage scaling, so the amount is the final strength of the blow. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onHurt(LivingHurtEvent e) {
        Hakoware.onHurt(e);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        Hakoware.onAnyDeath(e.getEntity());
        if (e.getEntity() instanceof ServerPlayer sp) Hakoware.clear(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) Hakoware.clear(sp);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        Hakoware.reset();
    }
}
