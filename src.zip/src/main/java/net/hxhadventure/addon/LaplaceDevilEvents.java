package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Forge event hooks for {@link LaplaceDevil}. Self-registering, so no existing event class needs editing. */
public final class LaplaceDevilEvents {
    private LaplaceDevilEvents() {}

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class LaplaceModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent e) {
            e.put(HxHEntities.LAPLACE_DOUBLE.get(), LaplaceDoubleEntity.createAttributes().build());
        }
    }

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class LaplaceGame {
        @SubscribeEvent
        public static void onLaplaceTick(TickEvent.PlayerTickEvent e) {
            if (e.phase == TickEvent.Phase.END && e.player instanceof ServerPlayer sp) LaplaceDevil.tick(sp); // END: the START phase is not delivered reliably (see AddonServerEvents)
        }

        /** Nothing the domain affects can pick the real user as a target. */
        @SubscribeEvent
        public static void onChangeTarget(LivingChangeTargetEvent e) {
            LivingEntity target = e.getNewTarget();
            if (target == null || e.getEntity().level().isClientSide) return;
            if (LaplaceDevil.isBlindedTo(e.getEntity(), target)) e.setCanceled(true);
        }

        /** The hidden user cannot hurt anything: no swing lands, no projectile or Nen attack that has them as its source. */
        @SubscribeEvent
        public static void onAttackEntity(AttackEntityEvent e) {
            if (!e.getEntity().level().isClientSide && LaplaceDevil.isOpen(e.getEntity())) e.setCanceled(true);
        }

        @SubscribeEvent
        public static void onAttack(LivingAttackEvent e) {
            LivingEntity victim = e.getEntity();
            if (victim.level().isClientSide) return;
            Entity attacker = e.getSource().getEntity();
            if (attacker == null || attacker == victim) return;
            if (LaplaceDevil.isOpen(attacker)) {
                e.setCanceled(true);
            } else if (LaplaceDevilTuning.AFFECTED_CANNOT_HIT_USER && LaplaceDevil.isBlindedTo(attacker, victim)) {
                e.setCanceled(true);
            }
        }

        @SubscribeEvent
        public static void onDeath(LivingDeathEvent e) {
            if (e.getEntity() instanceof ServerPlayer sp) LaplaceDevil.clear(sp);
        }

        /** The double is a decoy: no loot, no experience. */
        @SubscribeEvent
        public static void onDrops(LivingDropsEvent e) {
            if (e.getEntity() instanceof LaplaceDoubleEntity) e.setCanceled(true);
        }

        @SubscribeEvent
        public static void onXp(LivingExperienceDropEvent e) {
            if (e.getEntity() instanceof LaplaceDoubleEntity) e.setCanceled(true);
        }

        /** Somebody comes into view of the user, the Devil or the double. */
        @SubscribeEvent
        public static void onStartTracking(PlayerEvent.StartTracking e) {
            if (e.getEntity() instanceof ServerPlayer viewer) LaplaceDevil.sendTo(viewer, e.getTarget());
        }

        @SubscribeEvent
        public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
            if (e.getEntity() instanceof ServerPlayer sp) LaplaceDevil.repairOnLogin(sp);
        }

        @SubscribeEvent
        public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
            LaplaceDevil.clear(e.getEntity());
        }

        /** The domain is a dome in one world: it cannot follow the user to another. */
        @SubscribeEvent
        public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
            LaplaceDevil.clear(e.getEntity());
        }

        @SubscribeEvent
        public static void onServerStopped(ServerStoppedEvent e) {
            LaplaceDevil.reset();
        }
    }
}
