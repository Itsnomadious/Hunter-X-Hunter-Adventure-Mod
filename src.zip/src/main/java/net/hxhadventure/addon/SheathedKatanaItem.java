package net.hxhadventure.addon;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;

/**
 * The Katana in its sheath. Held, it is not drawn in the hand: client/KatanaHipLayer draws it on the user's left hip. Right-click draws the
 * Katana again.
 *
 * <p>It is a {@link SwordItem} ONLY so that every enchanting check (enchanting table, anvil, books, Forge's category tests) treats it as a
 * sword, exactly like the drawn Katana: Sharpness, Smite, Fire Aspect, Looting, Sweeping Edge, Knockback, Unbreaking, Mending... all work, and
 * enchantments are kept when it is drawn or sheathed (KatanaItem.swap copies the NBT). Everything else that makes a sword a weapon is switched
 * off here: no attack damage or speed, no extra wear from hitting or mining, no cobweb / tool behaviour. The iaido draw does the cutting.
 */
public class SheathedKatanaItem extends SwordItem {
    public SheathedKatanaItem(Item.Properties props) {
        super(Tiers.IRON, 3, -2.4F, props); // the same tier as the drawn Katana, so the same enchantability (14)
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) KatanaItem.swap(player, hand, stack, KatanaItems.KATANA);
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }

    // ---- not a weapon: all of SwordItem's combat / tool behaviour is switched off ----

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        return ImmutableMultimap.of();
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        return false; // no wear for a punch
    }

    @Override
    public boolean mineBlock(ItemStack stack, Level level, BlockState state, BlockPos pos, LivingEntity miner) {
        return false; // no wear for mining
    }

    @Override
    public float getDestroySpeed(ItemStack stack, BlockState state) {
        return 1.0F;
    }

    @Override
    public boolean isCorrectToolForDrops(BlockState state) {
        return false;
    }
}
