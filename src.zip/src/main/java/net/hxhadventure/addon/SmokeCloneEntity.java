package net.hxhadventure.addon;

import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Deep Purple's clone: looks exactly like the user (skin, name, armour, held items) but has the stats of a smoke monster, not the user's.
 * The copied items have their attribute modifiers stripped so armour and weapons change how it looks, never what it can do.
 */
public class SmokeCloneEntity extends SmokeMinion implements NpcPose {
    public SmokeCloneEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    /** Call once, before the clone is added to the level. */
    public void copyLook(ServerPlayer sp) {
        this.setCustomName(sp.getName());
        this.setCustomNameVisible(true);
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack copy = sp.getItemBySlot(slot).copy();
            if (!copy.isEmpty()) copy.getOrCreateTag().put("AttributeModifiers", new ListTag());
            this.setItemSlot(slot, copy);
            this.setDropChance(slot, 0f);
        }
    }

    // ---- Black Voice: the clone left behind when the user takes over a body ----
    private boolean decoy;

    /**
     * Turns this clone into the decoy of the user's own body (Black Voice's body swap): it stands still, never goes away on its own, and
     * every hit on it is handed to the user (see BlackVoice.onCloneHurt). Call after {@link #setup}, before adding it to the level.
     */
    public void makeDecoy(ServerPlayer sp) {
        this.decoy = true;
        AttributeInstance hp = this.getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) hp.setBaseValue(sp.getMaxHealth());
        this.setHealth(sp.getHealth());
        this.setNoAi(true);
        this.setSilent(true);
        // it stands there reading a phone: the phone in its hand (and nothing in the other), the arm held out in front of it
        if (BlackVoiceItems.PHONE != null) this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(BlackVoiceItems.PHONE));
        this.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
        this.setDropChance(EquipmentSlot.MAINHAND, 0f);
    }

    /** NpcPose: a Black Voice decoy holds its right arm up, looking at its phone. */
    @Override
    public boolean armsOut() {
        return decoy;
    }

    @Override
    protected boolean keepsAlive() {
        return decoy;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (decoy) return net.hxhadventure.addon.BlackVoice.onCloneHurt(this, source, amount);
        return super.hurt(source, amount);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.FIRE_EXTINGUISH;
    }
}
