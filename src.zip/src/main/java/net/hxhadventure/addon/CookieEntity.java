package net.hxhadventure.addon;

import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketCookieOpen;

/**
 * Cookie, the masseuse Biscuit Krueger's Magical Esthetician summons. She is an NPC drawn with the player model (see CookieRenderer): she
 * stands where she was called, looks at whoever comes near, cannot be hurt, and does nothing for anyone but the player who summoned her.
 * Right-click her for the menu (Magical Spa Services or Piano Massage). She is never saved with the world and is gone when her owner
 * sends her away, dies, logs out or loses the Hatsu (see {@link MagicalEsthetician}).
 */
public class CookieEntity extends PathfinderMob implements NpcPose {
    private static final EntityDataAccessor<Integer> STANCE =
        SynchedEntityData.defineId(CookieEntity.class, EntityDataSerializers.INT);

    private UUID owner;

    public CookieEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setCustomName(Component.literal("Cookie"));
        setCustomNameVisible(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 40.0)
            .add(Attributes.MOVEMENT_SPEED, 0.25);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STANCE, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
    }

    public UUID getOwnerId() {
        return owner;
    }

    @Override
    public int stance() {
        return this.entityData.get(STANCE);
    }

    public void setStance(int stance) {
        this.entityData.set(STANCE, stance);
    }

    @Override
    public boolean armsOut() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    /** She cannot be hurt, only removed by creative players (and /kill). */
    @Override
    public boolean isInvulnerableTo(DamageSource src) {
        return !src.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY) && !src.isCreativePlayer();
    }

    /** Nobody shoves her out of position while she works. */
    @Override
    public boolean isPushable() {
        return false;
    }

    /** Safety net: a Cookie nobody owns any more (a reload, a crash, a stray spawn) goes away. */
    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.tickCount > 40 && this.tickCount % 20 == 0
            && (owner == null || !MagicalEsthetician.ownsCookie(owner, this.getUUID()))) {
            this.discard();
        }
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return super.mobInteract(player, hand);
        if (!this.level().isClientSide && player instanceof ServerPlayer sp) {
            if (owner == null || !owner.equals(sp.getUUID())) {
                sp.displayClientMessage(Component.literal("\u00a7dCookie \u00a77only works for the one who called her"), true);
            } else if (!MagicalEsthetician.inService(sp)) {
                AddonNetwork.sendToPlayer(new PacketCookieOpen(this.getId()), sp);
            }
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
    }
}
