package net.hxhadventure.addon;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketPainFx;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Feitan's Pain Packer (Hatsu kit 21, a Transmuter's): aura turned into heat, fed by the pain the user has suffered.
 * <ul>
 *   <li><b>Pain.</b> Every point of damage the user takes is stored as pain ({@link PainPackerTuning#PAIN_PER_DAMAGE} each, up to
 *       {@link PainPackerTuning#PAIN_CAP}); it fades slowly once the wounds are old.</li>
 *   <li><b>Pain Packer</b> (H, or Z on its entry in the list): once hurt, the user conjures a suit of armour. Ren is forced on for as long as
 *       it lasts (it cannot be switched off by hand). The armour protects against the heat of Rising Sun. Pressing it again takes the
 *       armour off.</li>
 *   <li><b>Rising Sun</b> (Z): a ball of aura leaves the user, rises and in 3 seconds swells into a miniature sun that hovers in the air
 *       and burns everything within its range. All the pain is spent: the more there was, the bigger the sun (1 to 8 blocks), the
 *       longer its reach (10 to 60 blocks), the hotter it burns and the longer it lasts. The user is only spared while wearing the armour.</li>
 * </ul>
 * Everything is decided on the server; clients are told what to draw through {@link PacketPainFx}. Forge hooks: {@link PainPackerEvents}.
 */
public final class PainPacker {
    private PainPacker() {}

    public static final int KIT = 21;
    public static final String ID = "pain_packer";
    public static final String SUN_ID = "rising_sun";

    private static final DustParticleOptions CRIMSON = new DustParticleOptions(new Vector3f(0.65f, 0.08f, 0.12f), 1.2f);
    private static final DustParticleOptions EMBER = new DustParticleOptions(new Vector3f(1.0f, 0.55f, 0.1f), 1.0f);

    private static final Map<UUID, Float> PAIN = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_HURT = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> LAST_PAIN_MSG = new ConcurrentHashMap<>();
    private static final Set<UUID> ARMOR = ConcurrentHashMap.newKeySet();
    /** Wearers whose armour is glowing white-hot because their sun is burning (clients are told, see PacketPainFx.HEAT). */
    private static final Set<UUID> HEAT = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Long> ARMOR_READY = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> SUN_READY = new ConcurrentHashMap<>();
    /** Game time until which the armour still shields its wearer from fire (the sun's heat and what it left burning). */
    private static final Map<UUID, Long> HEAT_SHIELD_UNTIL = new ConcurrentHashMap<>();
    private static final Map<UUID, Sun> SUNS = new ConcurrentHashMap<>();
    private static final AtomicInteger SUN_IDS = new AtomicInteger(1);

    /** One sun in the air. Owned by one player; at most one each. */
    private static final class Sun {
        final int id;
        final ResourceKey<Level> dim;
        final Vec3 pos;
        final float diameter;
        final float range;
        final float damagePerHit;
        final int deploy;
        final int life;
        int age;

        Sun(int id, ResourceKey<Level> dim, Vec3 pos, float diameter, float range, float damagePerHit, int deploy, int life) {
            this.id = id;
            this.dim = dim;
            this.pos = pos;
            this.diameter = diameter;
            this.range = range;
            this.damagePerHit = damagePerHit;
            this.deploy = deploy;
            this.life = life;
        }
    }

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    /** Is this player's armour on right now? */
    public static boolean isArmored(Player p) {
        return p != null && ARMOR.contains(p.getUUID());
    }

    public static boolean hasSun(Player p) {
        return p != null && SUNS.containsKey(p.getUUID());
    }

    public static float pain(Player p) {
        return p == null ? 0f : PAIN.getOrDefault(p.getUUID(), 0f);
    }

    /** True while the armour shields its wearer from fire (used by PainPackerEvents). */
    public static boolean heatShielded(Player p) {
        if (!isArmored(p)) return false;
        if (hasSun(p)) return true;
        return p.level().getGameTime() < HEAT_SHIELD_UNTIL.getOrDefault(p.getUUID(), 0L);
    }

    /** Adds the entries to the Z list once the Hatsu level allows them. */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c)) return base;
        int lvl = c.getHatsuLevel();
        String[] out = base;
        if (lvl >= PainPackerTuning.MIN_LEVEL) {
            out = Arrays.copyOf(out, out.length + 1);
            out[out.length - 1] = ID;
        }
        if (lvl >= PainPackerTuning.SUN_MIN_LEVEL) {
            out = Arrays.copyOf(out, out.length + 1);
            out[out.length - 1] = SUN_ID;
        }
        return out;
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(ID, PainPacker::toggle);
        m.put(SUN_ID, PainPacker::risingSun);
    }

    public static String displayName(String id) {
        if (ID.equals(id)) return "\u00a74 Pain Packer";
        if (SUN_ID.equals(id)) return "\u00a76 Rising Sun";
        return null;
    }

    // ---------------------------------------------------------------- shared helpers

    private static void msg(ServerPlayer sp, String text) {
        sp.displayClientMessage(Component.literal(text), true);
    }

    private static String num(float v) {
        return String.valueOf(Math.round(v));
    }

    /** Common gate for a move. Returns the Combat or null (with the reason shown to the player). */
    private static Combat gate(ServerPlayer sp, int minLevel, String name) {
        Combat c = Combat.get(sp);
        if (c == null) return null;
        if (!canUse(c)) {
            msg(sp, "\u00a7cYour Hatsu is not Pain Packer");
            return null;
        }
        if (c.getHatsuLevel() < minLevel) {
            msg(sp, "\u00a7c" + name + " unlocks at Level " + minLevel);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            msg(sp, "\u00a75Forced Zetsu: your aura will not answer");
            return null;
        }
        if (HatsuEffects.isStunned(sp)) return null;
        return c;
    }

    private static boolean ready(ServerPlayer sp, Map<UUID, Long> map, String name, long now) {
        long at = map.getOrDefault(sp.getUUID(), 0L);
        return !ChainManager.onCooldown(sp, name, (int) Math.max(0, at - now));
    }

    private static void anim(ServerPlayer sp, String name) {
        ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(sp.getUUID(), name, false), sp);
    }

    private static DamageSource heatSource(ServerLevel level, ServerPlayer owner) {
        Holder<DamageType> type = level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.ON_FIRE);
        return new DamageSource(type, owner, owner);
    }

    // ---------------------------------------------------------------- pain

    /** Called for every blow the user takes (see PainPackerEvents): the damage is stored as pain. */
    public static void addPain(ServerPlayer sp, float damage) {
        if (damage <= 0f) return;
        UUID id = sp.getUUID();
        float before = PAIN.getOrDefault(id, 0f);
        float after = Math.min(PainPackerTuning.PAIN_CAP, before + damage * PainPackerTuning.PAIN_PER_DAMAGE);
        PAIN.put(id, after);
        LAST_HURT.put(id, sp.level().getGameTime());
        Integer last = LAST_PAIN_MSG.get(id);
        if (last == null || sp.tickCount - last >= 10 || sp.tickCount < last) {
            LAST_PAIN_MSG.put(id, sp.tickCount);
            msg(sp, "\u00a74Pain: " + num(after) + " / " + num(PainPackerTuning.PAIN_CAP));
        }
    }

    private static void decayPain(ServerPlayer sp, long now) {
        UUID id = sp.getUUID();
        Float p = PAIN.get(id);
        if (p == null) return;
        if (now - LAST_HURT.getOrDefault(id, 0L) < PainPackerTuning.PAIN_DECAY_DELAY_TICKS) return;
        float next = p - PainPackerTuning.PAIN_DECAY_PER_TICK;
        if (next <= 0f) PAIN.remove(id);
        else PAIN.put(id, next);
    }

    // ---------------------------------------------------------------- Pain Packer (the armour)

    /** H, or Z on Pain Packer: conjure the armour, or take it off again. */
    public static void toggle(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c)) return;
        if (isArmored(sp)) {
            end(sp, "\u00a77Pain Packer: the armor dissolves");
            return;
        }
        c = gate(sp, PainPackerTuning.MIN_LEVEL, "Pain Packer");
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        if (!ready(sp, ARMOR_READY, "Pain Packer", level.getGameTime())) return;
        float pain = pain(sp);
        if (pain < PainPackerTuning.ARMOR_MIN_PAIN) {
            msg(sp, "\u00a7cYou have not been hurt enough: Pain Packer needs " + num(PainPackerTuning.ARMOR_MIN_PAIN) + " pain (you have " + num(pain) + ")");
            return;
        }
        if (c.getCurrentEnergy() < PainPackerTuning.ARMOR_COST) {
            msg(sp, "\u00a7cNot enough energy");
            return;
        }
        // Ren is forced on for as long as the armour lasts
        if (!c.isAuraActive()) {
            AbilityRegistry.toggleRen(sp, true);
            if (!c.isAuraActive()) {
                msg(sp, "\u00a7cPain Packer needs Ren, and your Ren will not come up");
                return;
            }
        }
        c.consumeEnergy(PainPackerTuning.ARMOR_COST);
        ARMOR_READY.put(sp.getUUID(), level.getGameTime() + PainPackerTuning.TOGGLE_COOLDOWN_TICKS);
        ARMOR.add(sp.getUUID());
        AddonNetwork.sendToTrackingAndSelf(PacketPainFx.armor(sp.getId(), true), sp);
        msg(sp, "\u00a74Pain Packer: the armor forms \u00a77(Ren is forced on)");
        level.playSound(null, sp.blockPosition(), SoundEvents.ANVIL_PLACE, SoundSource.PLAYERS, 0.8f, 0.6f);
        level.playSound(null, sp.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.8f, 0.7f);
        level.sendParticles(CRIMSON, sp.getX(), sp.getY() + 1.0, sp.getZ(), 50, 0.5, 0.9, 0.5, 0.0);
        level.sendParticles(ParticleTypes.FLAME, sp.getX(), sp.getY() + 1.0, sp.getZ(), 20, 0.4, 0.8, 0.4, 0.03);
    }

    /** The armour comes off (with a message), and the clients stop drawing it. Ren is left as it is. */
    public static void end(ServerPlayer sp, String message) {
        if (!ARMOR.remove(sp.getUUID())) return;
        AddonNetwork.sendToTrackingAndSelf(PacketPainFx.armor(sp.getId(), false), sp);
        if (message != null) msg(sp, message);
        if (sp.level() instanceof ServerLevel level) {
            level.playSound(null, sp.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, 0.8f, 0.7f);
            level.sendParticles(ParticleTypes.SMOKE, sp.getX(), sp.getY() + 1.0, sp.getZ(), 20, 0.4, 0.8, 0.4, 0.02);
        }
    }

    /** Zetsu and Hatsu lockouts end the armour (called by NenAddonData and Vows). */
    public static void endForZetsu(ServerPlayer sp) {
        end(sp, "\u00a77Pain Packer: the armor dissolves");
    }

    private static void tickArmor(ServerPlayer sp, ServerLevel level, Combat c) {
        UUID id = sp.getUUID();
        if (!ARMOR.contains(id)) return;
        NenAddonData d = NenAddonData.peek(sp);
        if (ExtrasHooks.hatsuForced(sp) || (d != null && d.zetsu)) {
            end(sp, "\u00a77Pain Packer: the armor falls away");
            return;
        }
        // Ren is forced: if anything dropped it, put it back; if it will not come back (no aura left), the armour goes too
        if (!c.isAuraActive()) {
            AbilityRegistry.toggleRen(sp, true);
            if (!c.isAuraActive()) {
                end(sp, "\u00a7cPain Packer ends: your aura is spent");
                return;
            }
        }
        if (sp.tickCount % 4 == 0) {
            level.sendParticles(CRIMSON, sp.getX(), sp.getY() + 0.9, sp.getZ(), 2, 0.35, 0.8, 0.35, 0.0);
        }
        if (heatShielded(sp) && sp.isOnFire()) sp.clearFire();
    }

    // ---------------------------------------------------------------- Rising Sun

    /** Z: call the sun. */
    public static void risingSun(ServerPlayer sp) {
        Combat c = gate(sp, PainPackerTuning.SUN_MIN_LEVEL, "Rising Sun");
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        if (SUNS.containsKey(sp.getUUID())) {
            msg(sp, "\u00a76Your sun is still in the sky");
            return;
        }
        if (!ready(sp, SUN_READY, "Rising Sun", level.getGameTime())) return;
        float pain = pain(sp);
        if (pain < PainPackerTuning.SUN_MIN_PAIN) {
            msg(sp, "\u00a7cYou have not suffered enough: Rising Sun needs " + num(PainPackerTuning.SUN_MIN_PAIN) + " pain (you have " + num(pain) + ")");
            return;
        }
        if (c.getCurrentEnergy() < PainPackerTuning.SUN_COST) {
            msg(sp, "\u00a7cNot enough energy");
            return;
        }
        c.consumeEnergy(PainPackerTuning.SUN_COST);

        // the more pain, the bigger, farther reaching, hotter and longer lasting
        float t = Mth.clamp((pain - PainPackerTuning.SUN_MIN_PAIN) / Math.max(0.001f, PainPackerTuning.PAIN_CAP - PainPackerTuning.SUN_MIN_PAIN), 0f, 1f);
        float diameter = Mth.lerp(t, PainPackerTuning.SUN_MIN_SIZE, PainPackerTuning.SUN_MAX_SIZE);
        float range = Mth.lerp(t, PainPackerTuning.SUN_MIN_RANGE, PainPackerTuning.SUN_MAX_RANGE);
        int burn = Math.round(Mth.lerp(t, PainPackerTuning.SUN_MIN_BURN_TICKS, PainPackerTuning.SUN_MAX_BURN_TICKS));
        float dps = Mth.lerp(t, PainPackerTuning.SUN_DPS_MIN, PainPackerTuning.SUN_DPS_MAX) + c.getHatsuLevel() * PainPackerTuning.SUN_DPS_PER_LEVEL;
        dps *= Vows.power(sp, SUN_ID);
        float perHit = dps * PainPackerTuning.SUN_DAMAGE_INTERVAL / 20f;

        // it hovers above the user, lower if a ceiling is in the way
        Vec3 from = sp.position().add(0, sp.getBbHeight(), 0);
        double height = PainPackerTuning.SUN_HEIGHT_BASE + PainPackerTuning.SUN_HEIGHT_PER_SIZE * diameter;
        BlockHitResult up = level.clip(new ClipContext(from, from.add(0, height + diameter * 0.5, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        if (up.getType() != HitResult.Type.MISS) {
            height = Math.max(2.0, up.getLocation().y - from.y - diameter * 0.5 - 0.5);
        }
        Vec3 pos = from.add(0, height, 0);

        PAIN.remove(sp.getUUID()); // all of it is spent
        SUN_READY.put(sp.getUUID(), level.getGameTime() + PainPackerTuning.SUN_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Rising Sun", PainPackerTuning.SUN_COOLDOWN_TICKS);

        int deploy = PainPackerTuning.SUN_DEPLOY_TICKS;
        Sun sun = new Sun(SUN_IDS.getAndIncrement(), level.dimension(), pos, diameter, range, perHit, deploy, deploy + burn);
        SUNS.put(sp.getUUID(), sun);
        AddonNetwork.sendToNear(PacketPainFx.sun(sun.id, new Vec3(sp.getX(), sp.getEyeY() + 0.4, sp.getZ()), pos, diameter, range, deploy, sun.life), level, pos, 256);

        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        anim(sp, "aura_up");
        level.playSound(null, sp.blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.2f, 0.6f);
        level.playSound(null, sp.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0f, 0.5f);
        level.sendParticles(ParticleTypes.FLAME, sp.getX(), sp.getEyeY() + 0.4, sp.getZ(), 25, 0.2, 0.2, 0.2, 0.15);
        if (isArmored(sp)) {
            msg(sp, "\u00a76Rising Sun: " + num(diameter) + " blocks, " + num(range) + " block reach \u00a77(the armor shields you from the heat)");
        } else {
            msg(sp, "\u00a76Rising Sun: " + num(diameter) + " blocks, " + num(range) + " block reach \u00a7c(no armor: the heat will burn you too)");
        }
    }

    private static void endSun(ServerPlayer sp) {
        Sun s = SUNS.remove(sp.getUUID());
        if (s == null) return;
        setHeat(sp, false);
        HEAT_SHIELD_UNTIL.put(sp.getUUID(), sp.level().getGameTime() + PainPackerTuning.HEAT_GRACE_TICKS);
        if (sp.level() instanceof ServerLevel level) {
            AddonNetwork.sendToNear(PacketPainFx.sunEnd(s.id), level, s.pos, 256);
            level.playSound(null, s.pos.x, s.pos.y, s.pos.z, SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 3.0f, 0.5f);
        }
        msg(sp, "\u00a77The sun goes out");
    }

    private static void setHeat(ServerPlayer sp, boolean on) {
        boolean changed = on ? HEAT.add(sp.getUUID()) : HEAT.remove(sp.getUUID());
        if (changed) AddonNetwork.sendToTrackingAndSelf(PacketPainFx.heat(sp.getId(), on), sp);
    }

    private static void tickSun(ServerPlayer sp, ServerLevel level) {
        Sun s = SUNS.get(sp.getUUID());
        if (s == null) return;
        if (!sp.isAlive() || sp.level().dimension() != s.dim) {
            endSun(sp);
            return;
        }
        s.age++;
        if (s.age >= s.life) {
            endSun(sp);
            return;
        }
        if (s.age == s.deploy) {
            level.playSound(null, s.pos.x, s.pos.y, s.pos.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 4.0f, 0.5f);
            level.playSound(null, s.pos.x, s.pos.y, s.pos.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 3.0f, 0.5f);
            level.playSound(null, s.pos.x, s.pos.y, s.pos.z, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 3.0f, 0.5f);
            // the flash of it finishing, and a ring of flame thrown outwards from it
            level.sendParticles(ParticleTypes.FLASH, s.pos.x, s.pos.y, s.pos.z, 1, 0, 0, 0, 0);
            int ring = 24;
            double rad = s.diameter * 0.5 + 0.5;
            for (int i = 0; i < ring; i++) {
                double a = Math.PI * 2 * i / ring;
                level.sendParticles(ParticleTypes.FLAME, s.pos.x + Math.cos(a) * rad, s.pos.y, s.pos.z + Math.sin(a) * rad, 0, Math.cos(a), 0.0, Math.sin(a), 0.6);
            }
        }
        if (s.age < s.deploy) return;
        if (s.age % 60 == 0) level.playSound(null, s.pos.x, s.pos.y, s.pos.z, SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 4.0f, 0.6f);
        // a deep rumble that never quite stops, and cracks of lightning over it
        if (s.age % 90 == 0) level.playSound(null, s.pos.x, s.pos.y, s.pos.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 2.0f, 0.4f);
        if (s.age % 25 == 0) {
            level.playSound(null, s.pos.x, s.pos.y, s.pos.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 1.5f, 1.3f + level.random.nextFloat() * 0.5f);
        }

        boolean armored = isArmored(sp);
        if (armored != HEAT.contains(sp.getUUID())) setHeat(sp, armored); // the armour glows while the sun burns
        if (armored && sp.tickCount % 4 == 0) {
            level.sendParticles(ParticleTypes.FLAME, sp.getX(), sp.getY() + 1.0, sp.getZ(), 3, 0.35, 0.8, 0.35, 0.02);
            level.sendParticles(ParticleTypes.SMALL_FLAME, sp.getX(), sp.getY() + 1.8, sp.getZ(), 2, 0.2, 0.2, 0.2, 0.04);
        }
        if (armored) {
            HEAT_SHIELD_UNTIL.put(sp.getUUID(), level.getGameTime() + PainPackerTuning.HEAT_GRACE_TICKS);
            if (sp.isOnFire()) sp.clearFire();
        }
        if ((s.age - s.deploy) % PainPackerTuning.SUN_DAMAGE_INTERVAL != 0) return;
        burn(sp, level, s, armored);
    }

    /** The heat: everything within range takes it, less the farther it is, and less again with no clear line to the sun. */
    private static void burn(ServerPlayer sp, ServerLevel level, Sun s, boolean armored) {
        AABB box = new AABB(s.pos, s.pos).inflate(s.range);
        DamageSource src = heatSource(level, sp);
        for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, box, e -> e.isAlive() && !(e instanceof ArmorStand))) {
            if (le == sp) {
                if (armored) continue; // the armour is made for exactly this
            } else {
                if (PainPackerTuning.SPARE_ALLIES && AllianceUtils.isAlly(le, sp)) continue;
                if (le instanceof Player p && (p.isCreative() || p.isSpectator())) continue;
            }
            Vec3 mid = le.position().add(0, le.getBbHeight() * 0.5, 0);
            double dist = mid.distanceTo(s.pos);
            if (dist > s.range) continue;
            float falloff = 1f - (1f - PainPackerTuning.SUN_EDGE_HEAT) * (float) (dist / s.range);
            BlockHitResult line = level.clip(new ClipContext(s.pos, mid, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, le));
            boolean open = line.getType() == HitResult.Type.MISS;
            float amount = s.damagePerHit * falloff * (open ? 1f : PainPackerTuning.SUN_SHELTER_MULT);
            if (amount <= 0f) continue;

            Vec3 keep = le.getDeltaMovement();
            le.invulnerableTime = 0;
            if (le == sp) sp.hurt(level.damageSources().inFire(), amount);
            else Vows.hatsuHurt(le, src, amount);
            le.setDeltaMovement(keep); // heat does not push
            if (open) le.setSecondsOnFire(PainPackerTuning.SUN_IGNITE_SECONDS);
            double w = le.getBbWidth() * 0.5;
            level.sendParticles(ParticleTypes.FLAME, le.getX(), le.getY() + le.getBbHeight() * 0.5, le.getZ(), 5, w, le.getBbHeight() * 0.3, w, 0.02);
            level.sendParticles(EMBER, le.getX(), le.getY() + le.getBbHeight() * 0.5, le.getZ(), 3, w, le.getBbHeight() * 0.3, w, 0.0);
        }
    }

    // ---------------------------------------------------------------- housekeeping

    public static void tick(ServerPlayer sp) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        UUID id = sp.getUUID();
        Combat c = Combat.get(sp);
        if (!canUse(c)) {
            if (ARMOR.contains(id) || SUNS.containsKey(id) || PAIN.containsKey(id)) clear(sp);
            return;
        }
        decayPain(sp, level.getGameTime());
        tickArmor(sp, level, c);
        tickSun(sp, level);
    }

    /** A player who comes into view of someone in the armour sees it at once. */
    public static void sendTo(ServerPlayer owner, ServerPlayer viewer) {
        if (ARMOR.contains(owner.getUUID())) AddonNetwork.sendToPlayer(PacketPainFx.armor(owner.getId(), true), viewer);
        if (HEAT.contains(owner.getUUID())) AddonNetwork.sendToPlayer(PacketPainFx.heat(owner.getId(), true), viewer);
    }

    /** Death, logout, a new Hatsu or lost Nen: everything is put away. */
    public static void clear(Player p) {
        UUID id = p.getUUID();
        if (p instanceof ServerPlayer sp) {
            if (ARMOR.remove(id)) AddonNetwork.sendToTrackingAndSelf(PacketPainFx.armor(sp.getId(), false), sp);
            if (HEAT.remove(id)) AddonNetwork.sendToTrackingAndSelf(PacketPainFx.heat(sp.getId(), false), sp);
            Sun s = SUNS.remove(id);
            if (s != null && sp.level() instanceof ServerLevel level) AddonNetwork.sendToNear(PacketPainFx.sunEnd(s.id), level, s.pos, 256);
        } else {
            ARMOR.remove(id);
            HEAT.remove(id);
            SUNS.remove(id);
        }
        PAIN.remove(id);
        LAST_HURT.remove(id);
        LAST_PAIN_MSG.remove(id);
        ARMOR_READY.remove(id);
        SUN_READY.remove(id);
        HEAT_SHIELD_UNTIL.remove(id);
    }

    /** The server stopped: nothing carries over to the next world. */
    public static void reset() {
        PAIN.clear();
        LAST_HURT.clear();
        LAST_PAIN_MSG.clear();
        ARMOR.clear();
        HEAT.clear();
        ARMOR_READY.clear();
        SUN_READY.clear();
        HEAT_SHIELD_UNTIL.clear();
        SUNS.clear();
    }
}
