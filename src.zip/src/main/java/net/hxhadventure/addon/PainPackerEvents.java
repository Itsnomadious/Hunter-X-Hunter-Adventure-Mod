package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.abilities.Combat;

/** Forge event hooks for {@link PainPacker}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PainPackerEvents {
    private PainPackerEvents() {}

    /** The armour is made to survive the sun: fire does nothing to its wearer while the sun burns (and a few seconds after). */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onAttack(LivingAttackEvent e) {
        if (e.isCanceled() || !(e.getEntity() instanceof ServerPlayer sp) || sp.level().isClientSide) return;
        if (!PainPacker.heatShielded(sp)) return;
        DamageSource src = e.getSource();
        if (src.is(DamageTypeTags.IS_FIRE)) {
            e.setCanceled(true);
            if (sp.isOnFire()) sp.clearFire();
        }
    }

    /** Lowest priority: runs after every other modifier, so what is stored as pain is what the blow really did. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp) || sp.level().isClientSide) return;
        float amount = e.getAmount();
        if (amount <= 0f) return;
        Combat c = Combat.get(sp);
        if (!PainPacker.canUse(c) || !c.hasNenUnlocked()) return;
        // the user's own sun is not a wound to be stored
        if (PainPacker.hasSun(sp) && e.getSource().is(DamageTypeTags.IS_FIRE)) return;
        PainPacker.addPain(sp, amount);
        if (PainPacker.isArmored(sp) && PainPackerTuning.ARMOR_DAMAGE_TAKEN_MULT != 1.0f) {
            e.setAmount(amount * PainPackerTuning.ARMOR_DAMAGE_TAKEN_MULT);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        PainPacker.reset();
    }
}
