package net.hxhadventure.addon;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Neferpitou's Hatsu has three skills (Doctor Blythe, Terpsichora, the Puppeteer) and only one of them can be out at a time:
 * summoning one dismisses the other two. Terpsichora's post-mortem dance cannot be cut, so nothing else can be summoned during it.
 */
public final class PitouSkills {
    private PitouSkills() {}

    public static final String BLYTHE = "blythe", TERPSI = "terpsichora", PUPPET = "puppeteer";

    /** Call just before summoning {@code keeping}: puts the other two away. Returns false (and says why) if that is not possible. */
    public static boolean clearOthers(ServerPlayer sp, String keeping) {
        if (!TERPSI.equals(keeping) && Terpsichora.mode(sp) == Terpsichora.DEAD) {
            sp.displayClientMessage(Component.literal("\u00a74Terpsichora's dance cannot be interrupted"), true);
            return false;
        }
        if (!BLYTHE.equals(keeping)) DoctorBlythe.withdraw(sp);
        if (!TERPSI.equals(keeping)) Terpsichora.withdraw(sp);
        if (!PUPPET.equals(keeping)) Puppeteer.releaseAll(sp);
        return true;
    }
}
