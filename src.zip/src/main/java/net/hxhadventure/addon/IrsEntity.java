package net.hxhadventure.addon;

import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * I.R.S. ("Individual Ren Suppressor"): what A.P.R. turns into when a debtor goes bankrupt. A small demon cat that floats at the
 * debtor's shoulder for {@link HakowareTuning#IRS_DAYS} Minecraft days and keeps them in Forced Zetsu the whole time.
 * It is saved with the world; a player debtor also carries the sentence in their own data ({@link Hakoware#CURSE_KEY}), so it comes
 * back if the creature is ever lost.
 */
public class IrsEntity extends MascotEntity {
    private UUID debtorId;
    private long until;
    private int missing;
    private boolean placed;

    public IrsEntity(EntityType<? extends IrsEntity> type, Level level) {
        super(type, level);
    }

    public void setDebtor(UUID debtor, long untilGameTime) {
        this.debtorId = debtor;
        this.until = untilGameTime;
    }

    public UUID debtorId() { return debtorId; }

    public long until() { return until; }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return EntityDimensions.fixed(HakowareTuning.IRS_HEIGHT * 0.9f, HakowareTuning.IRS_HEIGHT);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        if (debtorId != null) tag.putUUID("Debtor", debtorId);
        tag.putLong("Until", until);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.hasUUID("Debtor")) debtorId = tag.getUUID("Debtor");
        until = tag.getLong("Until");
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) return;
        if (debtorId == null) { discard(); return; }

        if (until > 0 && sl.getGameTime() >= until) {
            Hakoware.curseEnded(sl.getServer(), debtorId);
            discard();
            return;
        }

        LivingEntity debtor = sl.getEntity(debtorId) instanceof LivingEntity le ? le : null;
        if (debtor == null) {
            // a player who changed dimension: the sentence follows them
            ServerPlayer p = sl.getServer().getPlayerList().getPlayer(debtorId);
            if (p != null && p.level() != sl) {
                Hakoware.spawnIrs(p, until);
                discard();
                return;
            }
            // anything else that is not here: unloaded, offline or dead. After a long time gone it lets go (a player's sentence
            // is also kept in their own data, so it is raised again when they come back).
            if (p == null && ++missing > 6000) discard();
            return;
        }
        missing = 0;
        if (!debtor.isAlive()) { // the debtor is dead: I.R.S. goes with them and the sentence is over
            Hakoware.curseEnded(sl.getServer(), debtorId);
            discard();
            return;
        }

        if (tickCount % 20 == 0) HatsuEffects.apply(debtor, 100); // Forced Zetsu, kept up for as long as the sentence runs

        // float at the debtor's shoulder, a little behind, bobbing
        double yaw = Math.toRadians(debtor.yBodyRot);
        Vec3 fwd = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        double wantX = debtor.getX() + right.x * 0.7 - fwd.x * 0.35;
        double wantZ = debtor.getZ() + right.z * 0.7 - fwd.z * 0.35;
        double wantY = debtor.getY() + debtor.getBbHeight() + 0.25 + Math.sin(tickCount * 0.15) * 0.07;
        if (!placed) {
            placed = true;
            this.setPos(wantX, wantY, wantZ);
        } else {
            this.setPos(getX() + (wantX - getX()) * 0.25, getY() + (wantY - getY()) * 0.25, getZ() + (wantZ - getZ()) * 0.25);
        }
        this.setYRot(debtor.yBodyRot);
    }
}
