package net.hxhadventure.addon;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Lightning Aura, Killua's Hatsu (Hatsu kit 16, a Transmuter's): aura turned into electricity.
 * <ul>
 *   <li><b>Lightning Palm</b> (Z): hands go behind the back while a charge builds, then both palms strike at once. Weak 0.2 s stun.
 *       While Godspeed is on it is replaced by the Godspeed version (modelled on hxhcraft's Godspeed Rush): you burst forward along your
 *       look direction in a single lunge, a trail of lightning behind you, and every enemy within reach of the lunge is hit at once,
 *       frozen on the spot and stunned. No fall damage until you land.</li>
 *   <li><b>Thunderbolt</b> (Z): leap about five blocks and call a bolt down where you are looking. 0.2 s stun.</li>
 *   <li><b>Godspeed</b> (H): blue electricity sparks off the user, much more speed and moderately more damage; Ren cannot be used meanwhile.
 *       <b>Whirlwind</b> comes with it: an 80% chance to dodge an attack, 10% less for every attack dodged in a row, back to 80% once one lands.</li>
 * </ul>
 * The stun is a debuff ({@link HatsuEffects#LIGHTNING_STUN}); Lightning Aura users (players on this Hatsu, or anything tagged
 * {@code lightning_aura}) are immune to it.
 */
public final class LightningAura {
    private LightningAura() {}

    public static final int KIT = 16;
    public static final String PALM_ID = "lightning_palm";
    public static final String BOLT_ID = "thunderbolt";
    /** Entities with this tag (NPCs) count as Lightning Aura users: immune to the stun. */
    public static final String TAG = "lightning_aura";

    private static final UUID SPEED_ID = UUID.fromString("a1000000-0000-4000-8000-000000000016");
    private static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.45f, 0.75f, 1.0f), 1.0f);
    private static final Random RND = new Random();

    private static final Map<UUID, Long> PALM_READY = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> BOLT_READY = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> GPALM_READY = new ConcurrentHashMap<>();
    private static final Set<UUID> GODSPEED = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Double> DODGE = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> WINDUP = new ConcurrentHashMap<>();   // Lightning Palm: ticks of charge so far
    private static final Map<UUID, Integer> RUSH_AIR = new ConcurrentHashMap<>(); // Godspeed palm: ticks since the rush (fall protection lasts until landing)
    private static final Map<UUID, Integer> LEAP = new ConcurrentHashMap<>();     // Thunderbolt: ticks in the air so far
    /** Hit-stop: the user freezes for a moment after the Godspeed palm connects, then the rush carries on. */
    private static final class Stop {
        int ticks;
        final Vec3 dash;
        final Vec3 anchor;
        Stop(int ticks, Vec3 dash, Vec3 anchor) {
            this.ticks = ticks;
            this.dash = dash;
            this.anchor = anchor;
        }
    }
    private static final Map<UUID, Stop> HIT_STOP = new ConcurrentHashMap<>();
    private static final Map<UUID, Map<UUID, Integer>> HIT_FX = new ConcurrentHashMap<>(); // palm user -> struck enemy -> ticks of lightning left
    private static final Set<UUID> NO_FALL = ConcurrentHashMap.newKeySet();

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    public static boolean isGodspeed(Player p) {
        return p != null && GODSPEED.contains(p.getUUID());
    }

    /** Lightning Aura users cannot be paralysed by it. */
    public static boolean isImmune(LivingEntity e) {
        if (e == null) return false;
        if (e.getTags().contains(TAG)) return true;
        if (e instanceof Player p) {
            Combat c = Combat.get(p);
            return canUse(c);
        }
        return false;
    }

    /** Godspeed's extra damage ("moderately"). */
    public static float damageMult(Player p) {
        return isGodspeed(p) ? Tuning.GODSPEED_DAMAGE_MULT : 1f;
    }

    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c)) return base;
        int lvl = c.getHatsuLevel();
        String[] out = base;
        if (lvl >= Tuning.LIGHTNING_PALM_MIN_LEVEL) {
            out = Arrays.copyOf(out, out.length + 1);
            out[out.length - 1] = PALM_ID;
        }
        if (lvl >= Tuning.LIGHTNING_BOLT_MIN_LEVEL) {
            out = Arrays.copyOf(out, out.length + 1);
            out[out.length - 1] = BOLT_ID;
        }
        return out;
    }

    // ---------------------------------------------------------------- shared checks

    /** Common gate for a Z ability. Returns the level or null (with the reason shown to the player). */
    private static Combat gate(ServerPlayer sp, int minLevel, String name) {
        Combat c = Combat.get(sp);
        if (c == null) return null;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("§cYour Hatsu is not Lightning Aura"), true);
            return null;
        }
        if (c.getHatsuLevel() < minLevel) {
            sp.displayClientMessage(Component.literal("§c" + name + " unlocks at Level " + minLevel), true);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("§5Forced Zetsu: your aura will not answer"), true);
            return null;
        }
        if (HatsuEffects.isStunned(sp)) return null;
        if (WINDUP.containsKey(sp.getUUID()) || LEAP.containsKey(sp.getUUID())) return null; // one move at a time
        return c;
    }

    private static boolean ready(ServerPlayer sp, Map<UUID, Long> map, String name, long now) {
        long at = map.getOrDefault(sp.getUUID(), 0L);
        return !ChainManager.onCooldown(sp, name, (int) Math.max(0, at - now));
    }

    private static boolean pay(ServerPlayer sp, Combat c, float cost) {
        if (c.getCurrentEnergy() < cost) {
            sp.displayClientMessage(Component.literal("§cNot enough energy"), true);
            return false;
        }
        c.consumeEnergy(cost);
        return true;
    }

    private static void anim(ServerPlayer sp, String name) {
        ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(sp.getUUID(), name, false), sp);
    }

    private static boolean hostile(ServerPlayer sp, Entity e) {
        return e instanceof LivingEntity le && le != sp && le.isAlive() && !(e instanceof ArmorStand) && !AllianceUtils.isAlly(e, sp);
    }

    private static float damage(ServerPlayer sp, Combat c, float base, float perLevel, String id) {
        float amount = base + c.getHatsuLevel() * perLevel;
        NenAddonData d = NenAddonData.peek(sp);
        if (d != null) amount *= Affinity.projectile(d.effType(c)); // the same emission bonus the other Hatsu use for their attacks
        return amount * Vows.power(sp, id);
    }

    // ---------------------------------------------------------------- Lightning Palm

    /** Z: Lightning Palm, or its Godspeed version while Godspeed is on. */
    public static void palm(ServerPlayer sp) {
        if (isGodspeed(sp)) {
            godspeedPalm(sp);
            return;
        }
        Combat c = gate(sp, Tuning.LIGHTNING_PALM_MIN_LEVEL, "Lightning Palm");
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        if (!ready(sp, PALM_READY, "Lightning Palm", level.getGameTime()) || !pay(sp, c, Tuning.LPALM_COST)) return;
        PALM_READY.put(sp.getUUID(), level.getGameTime() + Tuning.LPALM_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Lightning Palm", Tuning.LPALM_COOLDOWN_TICKS);
        WINDUP.put(sp.getUUID(), 0);
        anim(sp, "lightning_charge"); // hands behind the back
        level.playSound(null, sp.blockPosition(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 1.2f, 2.0f);
    }

    private static void tickWindup(ServerPlayer sp, ServerLevel level) {
        Integer t = WINDUP.get(sp.getUUID());
        if (t == null) return;
        if (!sp.isAlive() || HatsuEffects.isStunned(sp)) {
            WINDUP.remove(sp.getUUID());
            anim(sp, "stop_anim");
            return;
        }
        t++;
        WINDUP.put(sp.getUUID(), t);
        // the charge builds behind the back
        Vec3 look = Vec3.directionFromRotation(0, sp.getYRot());
        Vec3 behind = sp.position().add(look.scale(-0.45)).add(0, 0.95, 0);
        int n = 1 + t / 3;
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, behind.x, behind.y, behind.z, n, 0.25, 0.2, 0.25, 0.25);
        level.sendParticles(BLUE, behind.x, behind.y, behind.z, n, 0.2, 0.2, 0.2, 0.0);
        if (t % 4 == 0) level.playSound(null, sp.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.15f + t * 0.02f, 1.6f + t * 0.03f);
        if (t >= Tuning.LPALM_WINDUP_TICKS) {
            WINDUP.remove(sp.getUUID());
            strike(sp, level);
        }
    }

    /** Both palms strike together. */
    private static void strike(ServerPlayer sp, ServerLevel level) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        anim(sp, "lightning_strike");
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true); // the default punch swing (first person too)
        Vec3 eye = sp.getEyePosition();
        Vec3 dir = sp.getLookAngle().normalize();
        Vec3 tip = eye.add(dir.scale(1.2)).add(0, -0.35, 0);
        level.playSound(null, sp.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 0.5f, 2.0f);
        level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.0f, 1.5f);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, tip.x, tip.y, tip.z, 18, 0.3, 0.3, 0.3, 0.35);
        // a short lunge with the strike
        Vec3 dm = sp.getDeltaMovement();
        sp.setDeltaMovement(dm.x + dir.x * 0.45, dm.y, dm.z + dir.z * 0.45);
        sp.hurtMarked = true;

        float amount = damage(sp, c, Tuning.LPALM_BASE_DAMAGE, Tuning.LPALM_DAMAGE_PER_LEVEL, PALM_ID);
        AABB box = new AABB(eye, eye.add(dir.scale(Tuning.LPALM_RANGE))).inflate(1.2);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : level.getEntities(sp, box, x -> hostile(sp, x))) {
            Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(eye);
            double d = to.length();
            if (d > Tuning.LPALM_RANGE + e.getBbWidth() * 0.5 || to.normalize().dot(dir) < 0.55) continue;
            if (d < bestDist) {
                bestDist = d;
                best = (LivingEntity) e;
            }
        }
        if (best == null) return;
        Vows.hatsuHurt(best, level.damageSources().playerAttack(sp), amount);
        HatsuEffects.stun(best, Tuning.LPALM_STUN_TICKS);
        Vec3 at = best.position().add(0, best.getBbHeight() * 0.5, 0);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 30, 0.35, 0.5, 0.35, 0.4);
        level.sendParticles(BLUE, at.x, at.y, at.z, 14, 0.3, 0.5, 0.3, 0.0);
    }

    // ---------------------------------------------------------------- Godspeed Lightning Palm

    /**
     * The Godspeed palm works like hxhcraft's Godspeed Rush: one burst of velocity along the look direction (no stepping or
     * teleporting, so walls stop you like they would anything else), and everything hostile within reach of that burst is struck
     * at once, frozen and stunned. A lightning trail is drawn along the path and a sphere of lightning blooms where you strike.
     */
    private static void godspeedPalm(ServerPlayer sp) {
        Combat c = gate(sp, Tuning.GODSPEED_MIN_LEVEL, "Godspeed");
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        if (!ready(sp, GPALM_READY, "Godspeed Lightning Palm", level.getGameTime()) || !pay(sp, c, Tuning.GPALM_COST)) return;
        GPALM_READY.put(sp.getUUID(), level.getGameTime() + Tuning.GPALM_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Godspeed Lightning Palm", Tuning.GPALM_COOLDOWN_TICKS);
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true); // the default punch swing (first person too)

        Vec3 look = sp.getLookAngle().normalize();
        Vec3 dash = look.scale(Tuning.GPALM_DASH_SPEED);
        Vec3 side = new Vec3(-look.z, 0, look.x).normalize().scale(0.45);
        Vec3 from = sp.position();

        // the lightning trail along the whole path of the rush, down both sides of the body
        for (double t = 0; t <= Tuning.GPALM_DASH_SPEED; t += 0.3) {
            Vec3 p = from.add(look.scale(t));
            level.sendParticles(HxHParticles.KILLUA_LIGHTNING.get(), p.x + side.x, p.y + 0.9, p.z + side.z, 1, 0.05, 0.05, 0.05, 0.01);
            level.sendParticles(HxHParticles.KILLUA_LIGHTNING.get(), p.x - side.x, p.y + 0.9, p.z - side.z, 1, 0.05, 0.05, 0.05, 0.01);
        }

        // everything hostile in reach of the lunge is hit at once
        float amount = damage(sp, c, Tuning.GPALM_BASE_DAMAGE, Tuning.GPALM_DAMAGE_PER_LEVEL, PALM_ID);
        AABB box = sp.getBoundingBox().expandTowards(dash).inflate(Tuning.GPALM_HIT_RADIUS);
        List<LivingEntity> hits = level.getEntitiesOfClass(LivingEntity.class, box, e -> hostile(sp, e));
        for (LivingEntity target : hits) godspeedStrike(sp, amount, target, level);

        // no fall damage until the landing
        NO_FALL.add(sp.getUUID());
        RUSH_AIR.put(sp.getUUID(), 0);
        if (hits.isEmpty()) {
            launch(sp, dash);
        } else {
            // hit-stop: the user freezes for 0.1 s as the blow lands, then the rush carries on
            sp.setDeltaMovement(Vec3.ZERO);
            sp.hurtMarked = true;
            sp.connection.send(new ClientboundSetEntityMotionPacket(sp));
            HIT_STOP.put(sp.getUUID(), new Stop(Tuning.GPALM_HITSTOP_TICKS, dash, sp.position()));
        }

        Vec3 centre = hits.isEmpty() ? from.add(look.scale(3.0)) : hits.get(0).position();
        if (hits.isEmpty()) lightningSphere(level, centre.x, centre.y + 1.0, centre.z, 25, 1.0, 2.2);
        level.playSound(null, centre.x, centre.y, centre.z, SoundEvents.TRIDENT_THUNDER, SoundSource.PLAYERS, 1.3f, 1.5f);
        anim(sp, "punch1");
    }

    /** One enemy caught by the rush: hurt, frozen where it stands, its aggro dropped, and a sphere of lightning around it. */
    private static void godspeedStrike(ServerPlayer sp, float amount, LivingEntity target, ServerLevel level) {
        target.invulnerableTime = 0; // so every enemy in the path takes the full hit
        Vows.hatsuHurt(target, level.damageSources().playerAttack(sp), amount);
        HatsuEffects.stun(target, Tuning.GPALM_STUN_TICKS);
        target.setDeltaMovement(Vec3.ZERO);
        target.hurtMarked = true;
        if (target instanceof ServerPlayer tp) tp.connection.send(new ClientboundSetEntityMotionPacket(tp));
        if (target instanceof Mob mob) {
            mob.setTarget(null);
            mob.getNavigation().stop();
            if (mob instanceof Creeper creeper) creeper.setSwellDir(-1);
        }
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.5, 0);
        // the same lightning that surrounds the user is summoned around the enemy: a big burst now, then it dies down over a moment
        auraBurst(level, target, 5);
        HIT_FX.computeIfAbsent(sp.getUUID(), k -> new ConcurrentHashMap<>()).put(target.getUUID(), Tuning.GPALM_HIT_FX_TICKS);
        lightningSphere(level, at.x, at.y, at.z, 25, 1.0, 2.2);
        level.sendParticles(HxHParticles.KILLUA_LIGHTNING.get(), target.getX(), target.getY() + 0.8, target.getZ(), 6, 0.2, 0.3, 0.2, 0.02);
        level.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0, 0, 0, 0);
    }

    /**
     * The Godspeed aura (lightning crackle, electric sparks, blue dust spread over the whole body) at {@code scale} times its passive
     * strength, but around any entity. The enemy a Godspeed palm hits gets this for a moment.
     */
    private static void auraBurst(ServerLevel level, LivingEntity e, int scale) {
        double w = e.getBbWidth() * 0.6;
        double h = e.getBbHeight();
        double y = e.getY() + h * 0.5;
        level.sendParticles(HxHParticles.KILLUA_LIGHTNING.get(), e.getX(), y, e.getZ(), 3 * scale, w, h * 0.45, w, 0.01);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, e.getX(), y, e.getZ(), 2 * scale, w, h * 0.45, w, 0.25);
        level.sendParticles(BLUE, e.getX(), y, e.getZ(), 2 * scale, w, h * 0.45, w, 0.0);
    }

    /** Keeps the burst going on every enemy the palm struck until its few ticks run out. */
    private static void tickHitFx(ServerPlayer sp, ServerLevel level) {
        Map<UUID, Integer> m = HIT_FX.get(sp.getUUID());
        if (m == null) return;
        // (ConcurrentHashMap's removeIf hands out read-only entries, so setValue crashed here: iterate and put instead)
        java.util.Iterator<Map.Entry<UUID, Integer>> it = m.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> en = it.next();
            int left = en.getValue();
            if (left <= 0 || !(level.getEntity(en.getKey()) instanceof LivingEntity le) || !le.isAlive()) {
                it.remove();
                continue;
            }
            auraBurst(level, le, 2);
            m.put(en.getKey(), left - 1);
        }
        if (m.isEmpty()) HIT_FX.remove(sp.getUUID());
    }

    /** {@code count} lightning crackles scattered through a shell between radius {@code minR} and {@code minR + spread} around a point. */
    private static void lightningSphere(ServerLevel level, double x, double y, double z, int count, double minR, double spread) {
        for (int i = 0; i < count; i++) {
            double theta = RND.nextDouble() * Math.PI * 2;
            double phi = Math.acos(2 * RND.nextDouble() - 1);
            double r = minR + RND.nextDouble() * spread;
            level.sendParticles(HxHParticles.KILLUA_LIGHTNING.get(), x + r * Math.sin(phi) * Math.cos(theta), y + r * Math.cos(phi),
                z + r * Math.sin(phi) * Math.sin(theta), 1, 0, 0, 0, 0.01);
        }
    }

    /** The burst of velocity itself. */
    private static void launch(ServerPlayer sp, Vec3 dash) {
        sp.setDeltaMovement(dash);
        sp.hurtMarked = true;
        sp.connection.send(new ClientboundSetEntityMotionPacket(sp));
    }

    /** Holds the user still for the hit-stop, then lets the rush go. */
    private static void tickHitStop(ServerPlayer sp) {
        Stop st = HIT_STOP.get(sp.getUUID());
        if (st == null) return;
        if (!sp.isAlive()) {
            HIT_STOP.remove(sp.getUUID());
            return;
        }
        if (--st.ticks > 0) {
            sp.setDeltaMovement(Vec3.ZERO);
            sp.hurtMarked = true;
            sp.connection.send(new ClientboundSetEntityMotionPacket(sp));
            if (sp.position().distanceToSqr(st.anchor) > 0.04) sp.connection.teleport(st.anchor.x, st.anchor.y, st.anchor.z, sp.getYRot(), sp.getXRot());
            return;
        }
        HIT_STOP.remove(sp.getUUID());
        launch(sp, st.dash);
    }

    /** Keeps the fall damage off for the whole rush; ends a moment after the player lands (the grace stops it ending on the launch tick). */
    private static void tickRush(ServerPlayer sp) {
        Integer t = RUSH_AIR.get(sp.getUUID());
        if (t == null) return;
        sp.fallDistance = 0;
        if (!sp.isAlive() || (t >= 6 && sp.onGround())) {
            RUSH_AIR.remove(sp.getUUID());
            return;
        }
        RUSH_AIR.put(sp.getUUID(), t + 1);
    }

    // ---------------------------------------------------------------- Thunderbolt

    /** Z: leap, then call the bolt down where you are looking. */
    public static void thunderbolt(ServerPlayer sp) {
        Combat c = gate(sp, Tuning.LIGHTNING_BOLT_MIN_LEVEL, "Thunderbolt");
        if (c == null || !(sp.level() instanceof ServerLevel level)) return;
        if (!ready(sp, BOLT_READY, "Thunderbolt", level.getGameTime()) || !pay(sp, c, Tuning.BOLT_COST)) return;
        BOLT_READY.put(sp.getUUID(), level.getGameTime() + Tuning.BOLT_COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, "Thunderbolt", Tuning.BOLT_COOLDOWN_TICKS);
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true); // the default punch swing (first person too)
        Vec3 flat = Vec3.directionFromRotation(0, sp.getYRot());
        sp.setDeltaMovement(flat.x * Tuning.BOLT_LEAP_FORWARD, Tuning.BOLT_LEAP_SPEED, flat.z * Tuning.BOLT_LEAP_FORWARD);
        sp.hurtMarked = true;
        sp.connection.send(new ClientboundSetEntityMotionPacket(sp));
        LEAP.put(sp.getUUID(), 0);
        NO_FALL.add(sp.getUUID());
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + 0.2, sp.getZ(), 25, 0.4, 0.1, 0.4, 0.3);
        level.playSound(null, sp.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.6f, 1.8f);
    }

    private static void tickLeap(ServerPlayer sp, ServerLevel level) {
        Integer t = LEAP.get(sp.getUUID());
        if (t == null) return;
        if (!sp.isAlive()) {
            LEAP.remove(sp.getUUID());
            return;
        }
        t++;
        LEAP.put(sp.getUUID(), t);
        sp.fallDistance = 0;
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + 0.5, sp.getZ(), 3, 0.3, 0.4, 0.3, 0.15);
        boolean apex = sp.getDeltaMovement().y <= 0.05 && t >= 4;
        if (apex || t >= Tuning.BOLT_MAX_AIR_TICKS) {
            LEAP.remove(sp.getUUID());
            callBolt(sp, level);
        }
    }

    /** Where the player is looking: the first living thing or block, else the point at maximum range brought down to the ground. */
    private static Vec3 aimPoint(ServerPlayer sp, ServerLevel level) {
        Vec3 eye = sp.getEyePosition();
        Vec3 dir = sp.getLookAngle().normalize();
        Vec3 end = eye.add(dir.scale(Tuning.BOLT_RANGE));
        BlockHitResult block = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        double limit = block.getType() == HitResult.Type.MISS ? Tuning.BOLT_RANGE : block.getLocation().distanceTo(eye);
        EntityHitResult ent = ProjectileUtil.getEntityHitResult(level, sp, eye, eye.add(dir.scale(limit)),
            sp.getBoundingBox().expandTowards(dir.scale(limit)).inflate(1.0), e -> hostile(sp, e) && e.isPickable());
        if (ent != null) return ent.getLocation();
        if (block.getType() != HitResult.Type.MISS) return block.getLocation();
        BlockHitResult down = level.clip(new ClipContext(end, end.add(0, -30, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        return down.getType() == HitResult.Type.MISS ? end : down.getLocation();
    }

    private static void callBolt(ServerPlayer sp, ServerLevel level) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        Vec3 p = aimPoint(sp, level);
        visualBolt(level, p.x, p.y, p.z);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y + 0.3, p.z, 40, 0.8, 0.5, 0.8, 0.5);
        level.sendParticles(BLUE, p.x, p.y + 0.3, p.z, 20, 0.7, 0.4, 0.7, 0.0);
        float amount = damage(sp, c, Tuning.BOLT_BASE_DAMAGE, Tuning.BOLT_DAMAGE_PER_LEVEL, BOLT_ID);
        AABB box = new AABB(p, p).inflate(Tuning.BOLT_RADIUS, Tuning.BOLT_RADIUS + 1.0, Tuning.BOLT_RADIUS);
        for (Entity e : level.getEntities(sp, box, x -> hostile(sp, x))) {
            double d = e.position().distanceTo(p);
            if (d > Tuning.BOLT_RADIUS + e.getBbWidth() * 0.5 + 0.5) continue;
            LivingEntity le = (LivingEntity) e;
            Vows.hatsuHurt(le, level.damageSources().playerAttack(sp), amount);
            HatsuEffects.stun(le, Tuning.BOLT_STUN_TICKS);
        }
    }

    /** A real lightning strike that only looks and sounds like one: no fire, no damage of its own. */
    private static void visualBolt(ServerLevel level, double x, double y, double z) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt == null) return;
        bolt.moveTo(x, y, z);
        bolt.setVisualOnly(true);
        level.addFreshEntity(bolt);
    }

    // ---------------------------------------------------------------- Godspeed and Whirlwind

    /** H: Godspeed on or off. */
    public static void toggleGodspeed(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c)) return;
        if (isGodspeed(sp)) {
            godspeedOff(sp, true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.GODSPEED_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("§cGodspeed unlocks at Level " + Tuning.GODSPEED_MIN_LEVEL), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("§5Forced Zetsu: your aura will not answer"), true);
            return;
        }
        if (!pay(sp, c, Tuning.GODSPEED_START_COST)) return;
        if (c.isAuraActive()) AbilityRegistry.toggleRen(sp, false); // Ren and Godspeed do not mix
        GODSPEED.add(sp.getUUID());
        DODGE.put(sp.getUUID(), Tuning.WHIRLWIND_CHANCE);
        applySpeed(sp, true);
        sp.displayClientMessage(Component.literal("§b⚡ Godspeed: On §7(Ren is sealed, Whirlwind is active)"), true);
        if (sp.level() instanceof ServerLevel level) {
            level.playSound(null, sp.blockPosition(), SoundEvents.TRIDENT_THUNDER, SoundSource.PLAYERS, 1.0f, 1.6f);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + 1, sp.getZ(), 50, 0.5, 0.9, 0.5, 0.5);
            // hxhcraft's activation burst: a big sphere of lightning crackles all around the user
            lightningSphere(level, sp.getX(), sp.getY() + 1.2, sp.getZ(), 300, 3.0, 0.0);
            level.sendParticles(ParticleTypes.FLASH, sp.getX(), sp.getY() + 1.2, sp.getZ(), 1, 0, 0, 0, 0);
        }
    }

    /** Zetsu: Godspeed is switched off (with its message). */
    public static void endGodspeed(ServerPlayer sp) {
        godspeedOff(sp, true);
    }

    private static void godspeedOff(ServerPlayer sp, boolean message) {
        if (!GODSPEED.remove(sp.getUUID())) return;
        DODGE.remove(sp.getUUID());
        applySpeed(sp, false);
        if (message) sp.displayClientMessage(Component.literal("§7Godspeed: Off"), true);
    }

    private static void applySpeed(Player p, boolean on) {
        AttributeInstance inst = p.getAttribute(Attributes.MOVEMENT_SPEED);
        if (inst == null) return;
        inst.removeModifier(SPEED_ID);
        if (on) inst.addTransientModifier(new AttributeModifier(SPEED_ID, "Godspeed", Tuning.GODSPEED_SPEED, AttributeModifier.Operation.MULTIPLY_TOTAL));
    }

    private static void tickGodspeed(ServerPlayer sp, ServerLevel level) {
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || ExtrasHooks.hatsuForced(sp)) {
            godspeedOff(sp, true);
            return;
        }
        float upkeep = Tuning.GODSPEED_UPKEEP / 20f;
        if (c.getCurrentEnergy() < upkeep) {
            sp.displayClientMessage(Component.literal("§cGodspeed ends: your aura is spent"), true);
            godspeedOff(sp, false);
            return;
        }
        c.consumeEnergy(upkeep);
        if (c.isAuraActive()) AbilityRegistry.toggleRen(sp, false); // nothing can switch Ren on meanwhile (see ExtrasHooks.renBlocked)
        // the aura is blue electricity sparking off the body
        double w = sp.getBbWidth() * 0.6;
        double h = sp.getBbHeight();
        level.sendParticles(HxHParticles.KILLUA_LIGHTNING.get(), sp.getX(), sp.getY() + h * 0.5, sp.getZ(), 3, w, h * 0.45, w, 0.01);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + h * 0.5, sp.getZ(), 2, w, h * 0.45, w, 0.25);
        level.sendParticles(BLUE, sp.getX(), sp.getY() + h * 0.5, sp.getZ(), 2, w, h * 0.45, w, 0.0);
        // one soft crackle every few seconds instead of a constant buzz
        if (sp.tickCount % 100 == 0) {
            level.playSound(null, sp.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.1f, 2.0f);
        }
        if (RND.nextInt(30) == 0) { // an arc leaps off now and then
            Vec3 a = sp.position().add((RND.nextDouble() - 0.5) * 2, RND.nextDouble() * h, (RND.nextDouble() - 0.5) * 2);
            level.sendParticles(ParticleTypes.END_ROD, a.x, a.y, a.z, 3, 0.1, 0.1, 0.1, 0.05);
        }
    }

    /**
     * Whirlwind: called for every attack aimed at the player. True means the attack is dodged. 80% to dodge; every attack dodged
     * lowers it by 10%; one that lands puts it back to 80%.
     */
    public static boolean whirlwindDodges(ServerPlayer sp) {
        if (!isGodspeed(sp)) return false;
        double chance = DODGE.getOrDefault(sp.getUUID(), Tuning.WHIRLWIND_CHANCE);
        if (RND.nextDouble() < chance) {
            double next = Math.max(0, chance - Tuning.WHIRLWIND_STEP);
            DODGE.put(sp.getUUID(), next);
            sp.displayClientMessage(Component.literal("§b⚡ Whirlwind §7(next dodge " + Math.round(next * 100) + "%)"), true);
            if (sp.level() instanceof ServerLevel level) {
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + 1, sp.getZ(), 14, 0.4, 0.6, 0.4, 0.4);
                level.playSound(null, sp.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.5f, 2.0f);
            }
            return true;
        }
        DODGE.put(sp.getUUID(), Tuning.WHIRLWIND_CHANCE);
        return false;
    }

    // ---------------------------------------------------------------- housekeeping

    public static void tick(ServerPlayer sp) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        UUID id = sp.getUUID();
        if (!canUse(Combat.get(sp))) {
            if (isGodspeed(sp) || WINDUP.containsKey(id) || LEAP.containsKey(id) || RUSH_AIR.containsKey(id) || HIT_STOP.containsKey(id)) clear(sp);
            return;
        }
        if (isGodspeed(sp)) tickGodspeed(sp, level);
        tickWindup(sp, level);
        tickHitStop(sp);
        tickRush(sp);
        tickHitFx(sp, level);
        tickLeap(sp, level);
        if (NO_FALL.contains(id) && sp.onGround() && !LEAP.containsKey(id) && !RUSH_AIR.containsKey(id)) NO_FALL.remove(id);
    }

    /** Thunderbolt's leap must not hurt the user when they land. Used by LightningEvents. */
    public static boolean noFall(Player p) {
        return NO_FALL.contains(p.getUUID());
    }

    /** Death, logout, a new Hatsu or lost Nen: everything is put away. */
    public static void clear(Player p) {
        UUID id = p.getUUID();
        GODSPEED.remove(id);
        DODGE.remove(id);
        WINDUP.remove(id);
        RUSH_AIR.remove(id);
        HIT_FX.remove(id);
        HIT_STOP.remove(id);
        LEAP.remove(id);
        NO_FALL.remove(id);
        PALM_READY.remove(id);
        BOLT_READY.remove(id);
        GPALM_READY.remove(id);
        applySpeed(p, false);
    }
}
