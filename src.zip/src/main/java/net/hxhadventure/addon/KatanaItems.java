package net.hxhadventure.addon;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/** Registers the Katana and its sheathed form without touching ModItem (same way as Morel's pipe, see {@link SmokeItems}). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class KatanaItems {
    private KatanaItems() {}

    /** The drawn Katana: an iron sword in the hand. */
    public static Item KATANA;
    /** The sheathed Katana: it is worn on the hip instead of being held out. Right-click draws it. Enchantable like a sword (see SheathedKatanaItem). */
    public static Item KATANA_SHEATHED;

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.ITEMS, helper -> {
            KATANA = new KatanaItem(new Item.Properties());
            KATANA_SHEATHED = new SheathedKatanaItem(new Item.Properties().durability(KatanaItem.DURABILITY));
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "katana"), KATANA);
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "katana_sheathed"), KATANA_SHEATHED);
        });
    }

    @SubscribeEvent
    public static void creativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.COMBAT && KATANA != null) e.accept(KATANA);
    }
}
