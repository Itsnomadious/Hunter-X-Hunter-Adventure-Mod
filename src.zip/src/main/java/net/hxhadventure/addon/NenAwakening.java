package net.hxhadventure.addon;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.entity.ModEntities;
import net.hxhadventure.entity.custom.AuraEntity;
import net.hxhadventure.entity.custom.KiteEntity;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;

/**
 * Kite forces a player's aura nodes open. The player is held still, Kite steps behind them and presses a hand to their back,
 * aura gathers, and at the peak it surges through the player: Nen is awakened and the aura colour, talent and Nen type are rolled
 * (the type stays hidden until Water Divination reveals it).
 */
public final class NenAwakening {
    private NenAwakening() {}

    public static final int TOTAL_TICKS = 100;
    public static final int SURGE_TICK = 70;
    private static final double KITE_BEHIND = 0.85;
    private static final double MAX_DISTANCE = 8.0;

    private static final class Ritual {
        UUID kite;
        Vec3 anchor;
        float yaw;
        int ticks;
        AuraEntity surge;
    }

    private static final Map<UUID, Ritual> RITUALS = new ConcurrentHashMap<>();

    public static boolean inRitual(ServerPlayer sp) {
        return RITUALS.containsKey(sp.getUUID());
    }

    /** The player accepted Kite's offer. Returns false (and says why) if it cannot start. */
    public static boolean start(ServerPlayer sp, int kiteId) {
        Combat c = Combat.get(sp);
        if (c == null || c.hasNenUnlocked()) {
            sp.sendSystemMessage(Component.literal("\u00a76[Kite] \u00a7fYour nodes are already open."));
            return false;
        }
        if (inRitual(sp) || !(sp.level() instanceof ServerLevel level)) return false;
        Entity e = level.getEntity(kiteId);
        if (!(e instanceof KiteEntity kite) || !kite.isAlive() || kite.distanceTo(sp) > MAX_DISTANCE) {
            sp.sendSystemMessage(Component.literal("\u00a7cYou are too far from Kite."));
            return false;
        }
        for (Ritual r : RITUALS.values()) if (kite.getUUID().equals(r.kite)) {
            sp.sendSystemMessage(Component.literal("\u00a7cKite is busy with someone else."));
            return false;
        }

        Ritual r = new Ritual();
        r.kite = kite.getUUID();
        r.anchor = sp.position();
        r.yaw = sp.getYRot();
        RITUALS.put(sp.getUUID(), r);

        Vec3 facing = Vec3.directionFromRotation(0, r.yaw).multiply(1, 0, 1).normalize();
        kite.beginAwakening();
        kite.teleportTo(r.anchor.x - facing.x * KITE_BEHIND, r.anchor.y, r.anchor.z - facing.z * KITE_BEHIND);
        kite.setYRot(r.yaw);
        kite.setYHeadRot(r.yaw);
        kite.setYBodyRot(r.yaw);

        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, TOTAL_TICKS + 20, 9, false, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, TOTAL_TICKS + 20, 4, false, false, false));
        sp.sendSystemMessage(Component.literal("\u00a76[Kite] \u00a7fStay still. Do not fight it."));
        level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0f, 0.5f);
        return true;
    }

    /** /hxh forceawaken: awakens Nen at once, no ritual. Returns false if the player was already awakened. */
    public static boolean forceAwaken(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || c.hasNenUnlocked()) return false;
        c.setKit(1);
        c.updatePlayerMaxHealth();
        sp.getPersistentData().putBoolean("HxHCraft_NenUnlocked", true);
        NenProfile.setTypeRevealed(sp, false);
        NenProfile.rollAwakening(sp);
        return true;
    }

    private static void tick(ServerPlayer sp) {
        Ritual r = RITUALS.get(sp.getUUID());
        if (r == null) return;
        if (!(sp.level() instanceof ServerLevel level)) return;
        Entity ke = level.getEntity(r.kite);
        if (!sp.isAlive() || !(ke instanceof KiteEntity kite) || !kite.isAlive()) {
            end(sp, r, false);
            return;
        }
        r.ticks++;

        // held in place: no walking, no jumping, no drifting
        Vec3 v = sp.getDeltaMovement();
        sp.setDeltaMovement(0, Math.min(0, v.y), 0);
        sp.hurtMarked = true;
        sp.setSprinting(false);
        if (sp.position().distanceToSqr(r.anchor) > 0.5) sp.connection.teleport(r.anchor.x, r.anchor.y, r.anchor.z, sp.getYRot(), sp.getXRot());
        kite.setYRot(r.yaw);
        kite.setYHeadRot(r.yaw);
        kite.setYBodyRot(r.yaw);
        kite.setTarget(null);

        Vec3 facing = Vec3.directionFromRotation(0, r.yaw).multiply(1, 0, 1).normalize();
        Vec3 hand = r.anchor.subtract(facing.scale(0.15)).add(0, 1.25, 0); // the player's back, between the shoulders
        float progress = Math.min(1f, r.ticks / (float) SURGE_TICK);

        if (r.ticks < SURGE_TICK) {
            if (r.ticks % 2 == 0) {
                level.sendParticles(ParticleTypes.END_ROD, hand.x, hand.y, hand.z, 1 + (int) (progress * 3), 0.12, 0.12, 0.12, 0.01);
                level.sendParticles(ParticleTypes.ENCHANT, sp.getX(), sp.getY() + 1.0, sp.getZ(), 2 + (int) (progress * 6), 0.5, 0.8, 0.5, 0.4);
            }
            if (r.ticks % 12 == 0) {
                level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 0.8f, 0.5f + progress * 1.2f);
            }
        } else if (r.ticks == SURGE_TICK) {
            surge(sp, level, r);
        } else if (r.ticks % 2 == 0) {
            level.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1.0, sp.getZ(), 6, 0.6, 1.0, 0.6, 0.15);
        }

        if (r.ticks >= TOTAL_TICKS) end(sp, r, true);
    }

    /** The peak: the nodes open. Nen is awakened and a type is assigned (kept secret). */
    private static void surge(ServerPlayer sp, ServerLevel level, Ritual r) {
        Combat c = Combat.get(sp);
        if (c != null && !c.hasNenUnlocked()) {
            c.setKit(1);
            c.updatePlayerMaxHealth();
            sp.getPersistentData().putBoolean("HxHCraft_NenUnlocked", true);
            NenProfile.setTypeRevealed(sp, false);
            NenProfile.rollAwakening(sp); // colour, then talent, then Nen type (also syncs)
        }
        AuraEntity aura = new AuraEntity(ModEntities.AURA_ENTITY.get(), level);
        aura.setOwner(sp);
        aura.setAuraType(0);
        aura.setAuraScale(1.6f);
        aura.setPos(sp.getX(), sp.getY(), sp.getZ());
        level.addFreshEntity(aura);
        r.surge = aura;

        ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(sp.getUUID(), "aura_up", false), sp);
        level.sendParticles(ParticleTypes.FLASH, sp.getX(), sp.getY() + 1.0, sp.getZ(), 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1.0, sp.getZ(), 80, 0.4, 0.9, 0.4, 0.35);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + 1.0, sp.getZ(), 40, 0.5, 0.9, 0.5, 0.3);
        level.playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.8f);
        level.playSound(null, sp.blockPosition(), SoundEvents.TRIDENT_THUNDER, SoundSource.PLAYERS, 0.8f, 1.2f);
    }

    private static void end(ServerPlayer sp, Ritual r, boolean completed) {
        RITUALS.remove(sp.getUUID());
        sp.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        sp.removeEffect(MobEffects.DAMAGE_RESISTANCE);
        if (r.surge != null && !r.surge.isRemoved()) r.surge.discard();
        if (sp.level() instanceof ServerLevel level && level.getEntity(r.kite) instanceof KiteEntity kite) kite.endAwakening();
        if (completed) {
            sp.sendSystemMessage(Component.literal("\u00a76[Kite] \u00a7fThere. Your nodes are open. Craft a Water Divination glass and place it down, fill it with a water bucket, float a leaf on it, and it will tell you what kind of Nen you have."));
        }
    }

    // =====================================================================================================
    // events
    // =====================================================================================================

    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class Events {
        @SubscribeEvent
        public static void onTick(TickEvent.PlayerTickEvent e) {
            if (e.phase == TickEvent.Phase.START && e.player instanceof ServerPlayer sp) tick(sp);
        }

        @SubscribeEvent
        public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
            if (e.getEntity() instanceof ServerPlayer sp) {
                NenProfile.migrateIfNeeded(sp);
                NenProfile.sync(sp);
            }
        }

        @SubscribeEvent
        public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
            if (e.getEntity() instanceof ServerPlayer sp) NenProfile.sync(sp);
        }

        @SubscribeEvent
        public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
            if (e.getEntity() instanceof ServerPlayer sp) NenProfile.sync(sp);
        }

        @SubscribeEvent
        public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
            if (e.getEntity() instanceof ServerPlayer sp) {
                Ritual r = RITUALS.get(sp.getUUID());
                if (r != null) end(sp, r, false);
            }
        }

        @SubscribeEvent
        public static void onClone(PlayerEvent.Clone e) {
            NenProfile.copy(e.getOriginal(), e.getEntity());
        }
    }
}
