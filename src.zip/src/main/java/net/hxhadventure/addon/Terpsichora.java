package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketTerpsichoraFx;

/**
 * Neferpitou's Terpsichora (Hatsu kit 10, Specialists, shares the kit with Doctor Blythe): a giant ballerina-puppeteer
 * whose aura strings are tied to the user and who works the user's own body like a marionette.
 *
 * <ul>
 *   <li><b>Called with the H (Hatsu Mode) key</b> (it is no longer in the Z list). The figure only appears for
 *       {@link Tuning#TERPSI_FLASH_TICKS} (1 second) and then vanishes, but the buffs it applies, movement speed and damage dealt
 *       multiplied by {@link Tuning#TERPSI_BOOST} (1.8x), last {@link Tuning#TERPSI_BUFF_TICKS} (1 minute). It costs energy once,
 *       when it is called, and goes on cooldown when the buffs end.</li>
 *   <li><b>Post-mortem:</b> if the user would die while the buffs are on, death is refused once. The corpse is raised at
 *       {@link Tuning#TERPSI_REVIVE_HEALTH} of max health for {@link Tuning#TERPSI_DEAD_TICKS} ticks (30 s) with
 *       {@link Tuning#TERPSI_DEAD_BOOST} (2.5x) speed and damage in place of the 1.8x, while the screen goes red and the figure
 *       is out again, working the corpse's strings. When the time is up the user dies for real. Dying again during those 30
 *       seconds is final, and so is logging out (it counts as the time running out).</li>
 * </ul>
 * The server keeps a mode per player and tells clients what to draw
 * (PacketTerpsichoraFx / TerpsichoraFx for the arm pose and red screen; the figure itself is a TerpsichoraEntity).
 */
public final class Terpsichora {
    private Terpsichora() {}

    public static final int KIT = DoctorBlythe.KIT;
    public static final String ID = "terpsichora";

    /** OFF, ACTIVE (the buffs are on, the figure has gone) and DEAD (post-mortem) are the server's modes. MANIFEST is only ever sent to
     *  clients: the buffs are on and the figure is out right now (its first second), so the arms are posed. */
    public static final int OFF = 0, ACTIVE = 1, DEAD = 2, MANIFEST = 3;

    private static final UUID SPEED_ID = UUID.fromString("a1000000-0000-4000-8000-000000000042");
    private static final Map<Player, State> STATES = new WeakHashMap<>();

    private static final class State {
        int mode = OFF;
        int cooldown;
        int deadTicks;
        int buffTicks;   // ticks of buff left while ACTIVE
        int manifest;    // ticks the figure still has out while ACTIVE
    }

    private static State state(Player p) {
        return STATES.computeIfAbsent(p, k -> new State());
    }

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    public static int mode(Player p) {
        State s = p == null ? null : STATES.get(p);
        return s == null ? OFF : s.mode;
    }

    /** Terpsichora is no longer in the R/Z menu: it is called with the H key (see PacketAddonAction.hatsuMode). */
    public static String[] extend(String[] base, Combat c) {
        return base;
    }

    /** Damage-dealt multiplier for this player right now (1.0 when Terpsichora is not out). */
    public static float damageMult(Player p) {
        return switch (mode(p)) {
            case ACTIVE -> Tuning.TERPSI_BOOST;
            case DEAD -> Tuning.TERPSI_DEAD_BOOST;
            default -> 1.0f;
        };
    }

    // ---------------- call / end ----------------
    /** The H key: the figure appears for a second, the buffs last a minute. */
    public static void activate(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Neferpitou's"), true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.TERPSI_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cTerpsichora unlocks at Level " + Tuning.TERPSI_MIN_LEVEL), true);
            return;
        }
        State s = state(sp);
        if (s.mode == DEAD) {
            sp.displayClientMessage(Component.literal("\u00a74The strings cannot be cut now"), true);
            return;
        }
        if (s.mode == ACTIVE) {
            sp.displayClientMessage(Component.literal("\u00a77Terpsichora's strings are still on you: " + (s.buffTicks / 20 + 1) + "s left"), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: Terpsichora cannot be summoned"), true);
            return;
        }
        if (ChainManager.onCooldown(sp, "Terpsichora", s.cooldown)) return;
        if (c.getCurrentEnergy() < Tuning.TERPSI_SUMMON_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        if (!PitouSkills.clearOthers(sp, PitouSkills.TERPSI)) return;
        c.consumeEnergy(Tuning.TERPSI_SUMMON_COST);
        // she needs a moment: the caster cannot move for half a second
        sp.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, Tuning.TERPSI_FREEZE_TICKS, 9, false, false, false));
        s.mode = ACTIVE;
        s.buffTicks = Tuning.TERPSI_BUFF_TICKS;
        s.manifest = Tuning.TERPSI_FLASH_TICKS;
        applySpeed(sp, Tuning.TERPSI_BOOST);
        playSound(sp, SoundEvents.WITHER_AMBIENT, 0.9f, 0.5f);
        sp.displayClientMessage(Component.literal("\u00a7cTerpsichora"), true);
        send(sp, MANIFEST);
        spawnDoll(sp, Tuning.TERPSI_FLASH_TICKS);
    }

    /** The 5 block Terpsichora entity (new GeckoLib model). {@code life} is how many ticks it stays (-1 = until the dance is over). */
    private static void spawnDoll(ServerPlayer sp, int life) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        TerpsichoraEntity doll = HxHEntities.TERPSICHORA.get().create(level);
        if (doll == null) return;
        Vec3 back = sp.getLookAngle().multiply(1, 0, 1).normalize().scale(-2.5);
        doll.moveTo(sp.getX() + back.x, sp.getY(), sp.getZ() + back.z, sp.getYRot(), 0f);
        doll.setOwner(sp);
        doll.setLife(life);
        level.addFreshEntity(doll);
    }

    /** Post-mortem: the figure is out until the dance is over. Re-uses the one that is still out from the first second, if any. */
    private static void keepDoll(ServerPlayer sp) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        boolean found = false;
        for (TerpsichoraEntity d : level.getEntitiesOfClass(TerpsichoraEntity.class, sp.getBoundingBox().inflate(48), e -> e.owner() == sp)) {
            d.setLife(-1);
            found = true;
        }
        if (!found) spawnDoll(sp, -1);
    }

    /** Another of Neferpitou's skills is being summoned: the strings are put away. */
    public static void withdraw(ServerPlayer sp) {
        State s = STATES.get(sp);
        if (s != null && s.mode == ACTIVE) {
            dismiss(sp, s, "\u00a77Terpsichora withdrawn");
            for (TerpsichoraEntity d : sp.level() instanceof ServerLevel lv ? lv.getEntitiesOfClass(TerpsichoraEntity.class, sp.getBoundingBox().inflate(48), e -> e.owner() == sp) : new ArrayList<TerpsichoraEntity>()) d.discard();
        }
    }

    /** The buffs are over (or something ended them): the speed goes, the cooldown starts, clients are told. */
    private static void dismiss(ServerPlayer sp, State s, String msg) {
        if (s.mode != ACTIVE) return;
        s.mode = OFF;
        s.buffTicks = 0;
        s.manifest = 0;
        s.cooldown = Tuning.TERPSI_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, "Terpsichora", Tuning.TERPSI_COOLDOWN_TICKS);
        removeSpeed(sp);
        send(sp, OFF);
        playSound(sp, SoundEvents.CHAIN_BREAK, 0.8f, 0.6f);
        if (msg != null) sp.displayClientMessage(Component.literal(msg), true);
    }

    // ---------------- per tick ----------------
    public static void tick(ServerPlayer sp) {
        State s = STATES.get(sp);
        if (s == null) return;
        if (s.cooldown > 0) s.cooldown--;
        if (s.mode == OFF) return;

        if (s.mode == DEAD) {
            tickDead(sp, s);
            return;
        }

        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || !sp.isAlive()) {
            dismiss(sp, s, null);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            dismiss(sp, s, "\u00a75Forced Zetsu: Terpsichora's strings are cut");
            return;
        }
        if (s.manifest > 0 && --s.manifest == 0) send(sp, ACTIVE); // the figure has gone: the arms drop, the buffs stay
        if (--s.buffTicks <= 0) {
            dismiss(sp, s, "\u00a77Terpsichora's strings fall away");
            return;
        }
        applySpeed(sp, Tuning.TERPSI_BOOST); // re-applied in case something stripped it
    }

    private static void tickDead(ServerPlayer sp, State s) {
        if (!sp.isAlive()) return; // the death event cleans up
        applySpeed(sp, Tuning.TERPSI_DEAD_BOOST);
        s.deadTicks--;
        if (s.deadTicks % 20 == 0 && s.deadTicks > 0) {
            sp.displayClientMessage(Component.literal("\u00a74\u00a7lTERPSICHORA \u00a7c" + (s.deadTicks / 20) + "s"), true);
        }
        if (s.deadTicks > 0) return;

        // Time is up: the user dies for real. The mode stays DEAD so onLethal lets this death through.
        sp.displayClientMessage(Component.literal("\u00a74The strings go slack..."), true);
        sp.hurt(sp.damageSources().genericKill(), Float.MAX_VALUE);
        if (sp.isAlive()) sp.kill(); // belt and braces
        clear(sp);
    }

    // ---------------- death ----------------
    /**
     * Called from a HIGHEST-priority LivingDeathEvent handler for players. Returns true if it refused the death
     * (the event is cancelled and the corpse has been raised).
     */
    public static boolean onLethal(ServerPlayer sp, LivingDeathEvent event) {
        State s = STATES.get(sp);
        if (s == null || s.mode != ACTIVE) return false;
        // /kill, the void and an exhausted Emperor Time lifespan are not something a puppeteer can undo.
        if (event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return false;
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c)) return false;

        event.setCanceled(true);
        s.mode = DEAD;
        s.deadTicks = Tuning.TERPSI_DEAD_TICKS;
        s.manifest = 0;
        keepDoll(sp); // the figure is out for the whole of the post-mortem dance

        sp.setHealth(Math.max(1f, sp.getMaxHealth() * Tuning.TERPSI_REVIVE_HEALTH));
        sp.clearFire();
        sp.fallDistance = 0f;
        sp.setAirSupply(sp.getMaxAirSupply());
        sp.invulnerableTime = 20; // the blow that killed it cannot land a second time
        for (MobEffectInstance e : new ArrayList<>(sp.getActiveEffects())) {
            if (e.getEffect().getCategory() == MobEffectCategory.HARMFUL) sp.removeEffect(e.getEffect());
        }
        applySpeed(sp, Tuning.TERPSI_DEAD_BOOST);
        send(sp, DEAD);
        playSound(sp, SoundEvents.WITHER_SPAWN, 0.9f, 0.6f);
        playSound(sp, SoundEvents.ENDER_DRAGON_GROWL, 0.8f, 0.5f);
        sp.displayClientMessage(Component.literal("\u00a74\u00a7lTERPSICHORA \u00a7c" + (Tuning.TERPSI_DEAD_TICKS / 20) + "s"), true);
        return true;
    }

    /** Death (including the final one) or anything else that ends the dance: remove the boost and tell clients. */
    public static void clear(Player p) {
        State s = STATES.remove(p);
        if (p instanceof ServerPlayer sp) {
            removeSpeed(sp);
            if (s != null && s.mode != OFF) send(sp, OFF);
        }
    }

    /** Logging out mid-dance counts as the time running out, so it cannot be used to escape the death. */
    public static void onLogout(Player p) {
        State s = STATES.get(p);
        if (s != null && s.mode == DEAD && p.isAlive()) {
            p.hurt(p.damageSources().genericKill(), Float.MAX_VALUE);
            if (p.isAlive()) p.kill();
        }
        clear(p);
    }

    // ---------------- speed ----------------
    private static void applySpeed(ServerPlayer sp, float mult) {
        AttributeInstance inst = sp.getAttribute(Attributes.MOVEMENT_SPEED);
        if (inst == null) return;
        double amount = mult - 1.0;
        AttributeModifier cur = inst.getModifier(SPEED_ID);
        if (cur != null && Math.abs(cur.getAmount() - amount) < 1e-6) return;
        if (cur != null) inst.removeModifier(SPEED_ID);
        inst.addTransientModifier(new AttributeModifier(SPEED_ID, "Terpsichora speed", amount, AttributeModifier.Operation.MULTIPLY_TOTAL));
    }

    private static void removeSpeed(ServerPlayer sp) {
        AttributeInstance inst = sp.getAttribute(Attributes.MOVEMENT_SPEED);
        if (inst != null && inst.getModifier(SPEED_ID) != null) inst.removeModifier(SPEED_ID);
    }

    // ---------------- networking ----------------
    private static void send(ServerPlayer sp, int mode) {
        AddonNetwork.sendToTrackingAndSelf(new PacketTerpsichoraFx(sp.getId(), mode), sp);
    }

    /** A player who comes into view of someone with Terpsichora out sees it straight away. */
    public static void sendTo(ServerPlayer owner, ServerPlayer viewer) {
        State s = STATES.get(owner);
        if (s == null || s.mode == OFF) return;
        AddonNetwork.sendToPlayer(new PacketTerpsichoraFx(owner.getId(), s.mode == ACTIVE && s.manifest > 0 ? MANIFEST : s.mode), viewer);
    }

    private static void playSound(ServerPlayer sp, SoundEvent ev, float vol, float pitch) {
        sp.level().playSound(null, sp.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }
}
