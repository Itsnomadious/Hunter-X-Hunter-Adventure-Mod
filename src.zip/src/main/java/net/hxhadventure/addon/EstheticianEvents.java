package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Forge event hooks for {@link MagicalEsthetician}. Self-registering, so no existing event class needs editing for them. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class EstheticianEvents {
    private EstheticianEvents() {}

    @SubscribeEvent
    public static void onEstheticianTick(TickEvent.PlayerTickEvent e) {
        if (e.phase == TickEvent.Phase.START && e.player instanceof ServerPlayer sp) MagicalEsthetician.tick(sp);
    }

    /**
     * Damage dealt (Spa Afterglow, Body Transformation) and durability (the same two): damage taken is divided. Runs after the other hurt
     * handlers, so it multiplies what they already worked out. Being hurt also interrupts a service.
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onHurt(LivingHurtEvent e) {
        if (e.getEntity().level().isClientSide) return;
        float amount = e.getAmount();
        boolean changed = false;
        if (e.getEntity() instanceof ServerPlayer vp) {
            if (amount > 0f) MagicalEsthetician.interrupt(vp);
            float d = MagicalEsthetician.durabilityMult(vp);
            if (d != 1f) {
                amount /= d;
                changed = true;
            }
        }
        if (e.getSource().getEntity() instanceof ServerPlayer attacker && attacker != e.getEntity()) {
            float m = MagicalEsthetician.damageMult(attacker);
            if (m != 1f) {
                amount *= m;
                changed = true;
            }
        }
        if (changed) e.setAmount(amount);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) MagicalEsthetician.clear(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) MagicalEsthetician.clear(sp);
    }

    /** Someone who starts tracking a player mid-service (or in the form) sees it at once. */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking e) {
        if (e.getEntity() instanceof ServerPlayer viewer && e.getTarget() instanceof ServerPlayer owner) {
            MagicalEsthetician.sendTo(owner, viewer);
        }
    }

    /**
     * The body's size: sitting and lying shrink the hitbox and the eye height (so the camera sits where the head is), Body Transformation
     * grows them. Both sides ask MagicalEsthetician, which keeps a synced copy on the client.
     */
    // EntityEvent.Size is flagged for removal in newer Forge, but 1.20.1 has no replacement hook for resizing a player's hitbox
    // (GonVowEvents does the same); it has to be reworked with the scale attribute if the mod moves to 1.20.5+/1.21.
    @SuppressWarnings("removal")
    @SubscribeEvent
    public static void onSize(EntityEvent.Size e) {
        if (!(e.getEntity() instanceof Player p) || p.level() == null) return;
        int pose = MagicalEsthetician.pose(p);
        if (pose == MagicalEsthetician.POSE_SIT) {
            e.setNewSize(EntityDimensions.scalable(0.6f, EstheticianTuning.SIT_HEIGHT));
            e.setNewEyeHeight(EstheticianTuning.SIT_HEIGHT - 0.15f);
        } else if (pose == MagicalEsthetician.POSE_LIE) {
            e.setNewSize(EntityDimensions.scalable(EstheticianTuning.LIE_SIZE, EstheticianTuning.LIE_SIZE));
            e.setNewEyeHeight(0.4f);
        }
        if (MagicalEsthetician.isForm(p)) {
            e.setNewSize(e.getNewSize().scale(EstheticianTuning.TRANSFORM_HEIGHT_MULT));
            e.setNewEyeHeight(e.getNewEyeHeight() * EstheticianTuning.TRANSFORM_HEIGHT_MULT);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        MagicalEsthetician.reset();
    }
}
