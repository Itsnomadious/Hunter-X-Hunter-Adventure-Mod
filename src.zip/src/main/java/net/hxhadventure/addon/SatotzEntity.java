package net.hxhadventure.addon;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

/** Satotz, who runs the first test of the Hunter Exam (a questionnaire) on the third floor. */
public class SatotzEntity extends ExamNpcEntity {
    public SatotzEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    @Override
    public int examKind() {
        return HunterExam.KIND_SATOTZ;
    }
}
