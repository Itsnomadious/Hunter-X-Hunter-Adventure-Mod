package net.hxhadventure.addon;

/** Numbers for Knuckle's Hakoware (Hatsu kit 19, Conjurers). Change them here. */
public final class HakowareTuning {
    private HakowareTuning() {}


    /** Hatsu level needed to use it. */
    public static final int MIN_LEVEL = 10;
    /** Aura paid to switch Hakoware on (switching it off is free). */
    public static final float ACTIVATE_COST = 150f;
    public static final int TOGGLE_COOLDOWN_TICKS = 20;
    /** Most debtors one user can have at once. */
    public static final int MAX_CONTRACTS = 3;

    // ---- the loan ----
    /** Aura LENT to the debtor for every point of damage one of the user's blows would have done (kept low: the debt must not balloon). */
    public static final float LEND_PER_DAMAGE = 14f;
    /** Even the weakest blow lends at least this much. */
    public static final float MIN_LEND_PER_BLOW = 10f;
    /** Aura REPAID for every point of damage one of the debtor's blows would have done to the user (high: getting hit clears the debt fast). */
    public static final float REPAY_PER_DAMAGE = 110f;
    /** Even the weakest blow on the user repays at least this much. */
    public static final float MIN_REPAY_PER_BLOW = 70f;

    // ---- A.P.R.'s interest ----
    /** Interest added every INTEREST_TICKS: this share of the debt. */
    public static final float INTEREST_RATE = 0.10f;
    /** true: 10% of everything owed so far (interest on interest). false: 10% of the aura first lent. */
    public static final boolean COMPOUND = true;
    public static final int INTEREST_TICKS = 200;           // 10 seconds
    /** Interest only builds while the debtor is this close to the user, blocks. */
    public static final double INTEREST_RANGE = 32.0;
    public static final String SPEECH = "It's time, adding interest";
    /** Also print A.P.R.'s line in the chat of the user and the debtor (it always shows above A.P.R.). */
    public static final boolean SPEECH_IN_CHAT = true;
    public static final int SPEECH_BUBBLE_TICKS = 50;

    // ---- A.P.R.'s size: model height in blocks (a player is 1.8 tall) ----
    public static final float APR_MIN_HEIGHT = 0.5f;        // about a small slime
    public static final float APR_MAX_HEIGHT = 5.4f;        // 3x a player, reached at the moment of bankruptcy

    // ---- bankruptcy ----
    /** Used as "remaining aura (P.O.P)" for anything that has no aura of its own: max health x this. */
    public static final float FALLBACK_POP_PER_HEALTH = 100f;
    /** I.R.S. stays with the debtor for this many Minecraft days (24000 ticks each; 30 days = about 10 real hours). */
    public static final int IRS_DAYS = 30;
    public static final long TICKS_PER_DAY = 24000L;
    public static final float IRS_HEIGHT = 0.6f;
}
