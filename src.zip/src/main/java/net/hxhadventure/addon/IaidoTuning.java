package net.hxhadventure.addon;

/** Numbers for the Katana's iaido draw (Attack / Strong attack while the sheathed Katana is held). Change them here. */
public final class IaidoTuning {
    private IaidoTuning() {}

    // ---- timing (ticks, 20 = 1 second) ----
    /**
     * Time spent in the crouched stance before the dash. The "iaido_draw" clip (assets/hxhadventure/player_animation/iaido_draw.json) is
     * authored around this: it settles into the stance by 0.20 s and the cut starts at 0.25 s, so keep this at 5 unless the clip is re-timed.
     */
    public static final int WINDUP_TICKS = 5;
    /** Pause after the dash before another draw is possible: Attack, and Strong attack (the heavier cut). */
    public static final int ATTACK_COOLDOWN_TICKS = 18;
    public static final int STRONG_COOLDOWN_TICKS = 26;
    /** Movement speed lost while crouched in the stance (0.9 = 90% slower), so the user is planted for the draw. */
    public static final double STANCE_SLOW = 0.90;

    // ---- Strong attack: hold to charge ----
    /**
     * Strong attack is held, not tapped: the user stays crouched in the stance for as long as the key is down (no limit) and the draw is
     * released when it comes up. This many ticks of holding is a FULL charge (40 = 2 s, the same as the other Strong attacks).
     */
    public static final int CHARGE_FULL_TICKS = 40;
    /** Lunge distance multiplier of a fully charged draw (1x = a tap). A partial charge lunges proportionally between 1x and this. */
    public static final double FULL_CHARGE_DISTANCE_MULT = 2.0;

    // ---- the dash ----
    /** How far the user dashes, and how far in front of them the cut reaches (blocks). The dash follows where the user LOOKS: look up and it lunges up into the air. */
    public static final double DASH_DISTANCE = 4.0;
    /** Half-width of the path that is cut (blocks, each side of the user's line) and extra height above / below a creature's body. */
    public static final double HIT_HALF_WIDTH = 1.5;
    public static final double HIT_EXTRA_HEIGHT = 1.0;
    /** The dash climbs a slab or stair this high, like walking. */
    public static final double STEP_HEIGHT = 0.6;

    // ---- damage ----
    /** Base damage of the cut, multiplied by the user's spirit bonus like the normal Attack (and by Ten / Ren through the usual hit event). Was 9, now 35% less. */
    public static final float ATTACK_DAMAGE = 9f * 0.65f;
    /** Strong attack, relative to Attack: +10% when released at once, +30% when fully charged (in between: in proportion to the charge). */
    public static final float STRONG_DAMAGE_MULT_UNCHARGED = 1.10f;
    public static final float STRONG_DAMAGE_MULT_FULL = 1.30f;
    public static final double KNOCKBACK = 0.5;
}
