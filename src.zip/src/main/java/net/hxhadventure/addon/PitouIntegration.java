package net.hxhadventure.addon;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * The only place Neferpitou touches the abilities she borrows. Each method has a working built-in version; if you already
 * have your own Terpsichora, Doctor Blythe or "I'll use everything" code, call it from here and the NPC will use it instead.
 */
public final class PitouIntegration {
    private PitouIntegration() {}

    /** Is this entity currently in Gon's "I'll use everything." form? */
    public static boolean isUsingUseEverything(LivingEntity e) {
        return GonVow.isActive(e) || (e instanceof GonEntity g && g.isUsingEverything());
    }

    /**
     * Neferpitou brings out Terpsichora against {@code target}. Built-in: the 5-block Terpsichora entity beside her, out for
     * {@code life} ticks (-1 = until she is dismissed, used once she has been raised from the dead).
     */
    public static void summonTerpsichora(NeferpitouEntity pitou, @Nullable LivingEntity target, int life) {
        if (!(pitou.level() instanceof ServerLevel level)) return;
        TerpsichoraEntity doll = HxHEntities.TERPSICHORA.get().create(level);
        if (doll == null) return;
        Vec3 back = pitou.getLookAngle().multiply(1, 0, 1).normalize().scale(-2.5);
        doll.moveTo(pitou.getX() + back.x, pitou.getY(), pitou.getZ() + back.z, pitou.getYRot(), 0f);
        doll.setOwner(pitou);
        doll.setLife(life);
        if (target != null) doll.setTarget(target);
        level.addFreshEntity(doll);
        pitou.registerTerpsichora(doll, 0);
    }

    /** Puts Terpsichora away. */
    public static void dismissTerpsichora(NeferpitouEntity pitou) {
        if (pitou.level() instanceof ServerLevel level) {
            for (TerpsichoraEntity d : level.getEntitiesOfClass(TerpsichoraEntity.class, pitou.getBoundingBox().inflate(64), e -> e.owner() == pitou)) d.discard();
        }
    }

    /** Neferpitou brings out Doctor Blythe for {@code patient} (herself or an ally). Built-in: a healing over a few seconds. */
    public static void summonDoctorBlythe(NeferpitouEntity pitou, LivingEntity patient) {
        pitou.startBlytheHeal(patient);
    }
}
