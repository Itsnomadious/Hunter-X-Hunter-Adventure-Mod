package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketSyncVows;

/**
 * Nen Vows and Limitations (Rule of Equivalent Exchange). A Condition, Limitation or Vow is bound to a Nen skill (Ten, Zetsu, Ren,
 * En, Hatsu, In, Gyo) or to one Hatsu ability. Once sworn it can never be removed. Each one is really enforced by the server,
 * and in return multiplies the strength of what it is bound to:
 * <ul>
 *   <li>Conditions and Limitations on a skill multiply that skill's main effect (En: range, Ten: armour and regen, ...).</li>
 *   <li>Vows on a skill raise its effective level, which may go past 100.</li>
 *   <li>On a Hatsu ability every kind multiplies its power (Chain Jail: duration, Holy Chain: healing, the rest: damage).</li>
 * </ul>
 * Everything stacks multiplicatively, but the rule bonus on any one target is capped at {@link #MAX_RULE_POWER}.
 *
 * <p>Lockout Vows ({@link Enforce#LOCK}) are the biggest sacrifice: the player swears never to use a skill again (Ten can never be
 * locked) and in return a different skill's level (may pass 100), their maximum aura, or their En (range and a dodge chance) is boosted.
 * On top of that the Hatsu skill adds to the damage of every Hatsu ability ({@link Tuning#hatsuDamageBonus}).
 */
public final class Vows {
    private Vows() {}

    public enum Kind {
        CONDITION("Condition"), LIMITATION("Limitation"), VOW("Vow");
        public final String label;
        Kind(String label) { this.label = label; }
    }

    /** What a rule demands. CUSTOM rules are enforced inside the ability itself (see the ids below). */
    public enum Enforce { ONLY_WHEN, EXCLUDES, BOTH_FORCED, FORCED_IF, FORCED_AFTER, DIE_IF, CUSTOM, LOCK,
        /** While the skill is on, the aura form named in {@code arg} (REN or KO) is forced on and cannot be switched off. */
        FORCES,
        /** Cooldown: after one use the ability (or skill) cannot be used again for {@code ticks}. */
        COOLDOWN,
        /** Using it costs health: {@code arg} hearts, or "HALF" for half of maximum health. Refused when too weak to pay. */
        HEALTH_COST,
        /** Using it drains {@code arg} hunger points (20 empties the stomach). Refused when there is too little to pay. */
        HUNGER_COST,
        /** After using it the effects named in {@code arg} (comma separated: blindness, slowness, weakness, nausea, hunger, fatigue) hit the user for {@code ticks}. */
        EFFECT_AFTER }

    public enum Pred { CROUCH, SKY, DAY, NIGHT, LOW_HP, HIGH_HP,
        RAIN, UNDERGROUND, EMPTY_HAND, HOLDING, NO_ARMOR, HUNGRY, WATER, CRITICAL_HP }

    /** Pairs of "only when" conditions that can never both hold, so swearing both would forbid the thing for good. */
    private static final Map<String, String> OPPOSITE = Map.of(
        "DAY", "NIGHT", "NIGHT", "DAY", "SKY", "UNDERGROUND", "UNDERGROUND", "SKY",
        "EMPTY_HAND", "HOLDING", "HOLDING", "EMPTY_HAND", "LOW_HP", "HIGH_HP", "HIGH_HP", "LOW_HP");

    public record Rule(String id, String target, Kind kind, String text, float mult, Enforce enforce, String arg, int ticks) {
        /** Short description of the reward, for the menu. */
        public String boostText() {
            if (enforce == Enforce.LOCK) return LOCKS.get(id).reward();
            if (id.equals(EVERYTHING_VOW)) return "unlocks the \"I'll use everything.\" form (Jajanken, Level " + GonVow.MIN_LEVEL + ")";
            if (isSkill(target)) {
                if (kind == Kind.VOW) return "+" + pct(mult) + "% " + label(target) + " level: more " + EFFECT.getOrDefault(target, "strength") + " (can pass 100)";
                return "+" + pct(mult) + "% " + EFFECT.getOrDefault(target, "strength");
            }
            if (isForm(target)) return fmtMult(mult) + " " + label(target) + " strength";
            return fmtMult(mult) + " " + abilityStat(target);
        }
    }

    /**
     * A lockout: the player swears never to use {@code locked} again (null for the En range rule, which only restricts En) and gets
     * {@code boost} (0.2 = +20%) on the level of each skill in {@code boosts}, {@code auraMult} on their maximum aura, or, for
     * {@code enRange}, an En limited to {@link #EN_RESTRICTED_RADIUS} with an auto-dodge. Rules in the same {@code group} are
     * alternatives: only one of them can be sworn.
     */
    public record Lock(String locked, String group, List<NenSkill> boosts, float boost, float auraMult, boolean enRange, float enRadius, String reward) {
        /** The original form: {@code enRange} true means the 1 meter En restriction (with its dodge). */
        public Lock(String locked, String group, List<NenSkill> boosts, float boost, float auraMult, boolean enRange, String reward) {
            this(locked, group, boosts, boost, auraMult, enRange, enRange ? EN_RESTRICTED_RADIUS : 0f, reward);
        }
    }

    /** Rule id -> lockout, for the rules whose {@link Rule#enforce()} is {@link Enforce#LOCK}. */
    public static final Map<String, Lock> LOCKS = new LinkedHashMap<>();

    /** The En restriction: En can only reach this far (blocks) but the player has a chance to dodge any attack while En is on. */
    public static final float EN_RESTRICTED_RADIUS = 1f;
    public static final float EN_DODGE_CHANCE = 0.20f;
    public static final String EN_RANGE_VOW = "en_range";

    /** The Shu En restriction: En only reaches this far (blocks), no dodge, and in return Shu's level is raised by {@link #EN_SHU_BOOST}. */
    public static final String EN_SHU_VOW = "en_range_shu";
    public static final float EN_SHU_RADIUS = 4f;
    public static final float EN_SHU_BOOST = 0.20f;

    // ---- Limitations on Shu: restrictions that only hold while Shu is on, each giving +5% weapon damage (they no longer raise Shu's level) ----
    public static final String SHU_FORCE_REN = "shu_v_ren";
    public static final String SHU_FORCE_KO = "shu_v_ko";
    public static final String SHU_NO_GYO = "shu_v_gyo";
    public static final String SHU_NO_IN = "shu_v_in";
    /** Damage bonus of each of those four Limitations (Limitations are not halved like Vows: 1.05 is +5% Shu weapon damage). */
    private static final float SHU_LIMIT_MULT = 1.05f;

    /** The aura forms that rules can be bound to (they are not Nen skills and have no level of their own). */
    public static final List<String> FORM_KEYS = List.of("KEN", "KO");

    /**
     * Jajanken's Vow: swearing it is what unlocks the "I'll use everything." form (the H key / ability menu entry). It has no
     * damage bonus of its own (the form is the reward) and, like every rule, can never be taken back except by Hina or losing the Nen.
     * Sworn on Rock, the move the form is built around. Can only be sworn by a Jajanken user at {@link GonVow#MIN_LEVEL}.
     */
    public static final String EVERYTHING_VOW = "jajanken_everything";

    /** Can this player swear the rule right now? (Only the Jajanken vow has a requirement.) */
    public static boolean canSwear(Combat c, String ruleId) {
        if (!EVERYTHING_VOW.equals(ruleId)) return true;
        return c != null && Jajanken.canUse(c) && c.getHatsuLevel() >= GonVow.MIN_LEVEL;
    }

    // ---- ids of the rules the Chains check for themselves ----
    public static final String JAIL_TROUPE = "chain_jail_c2";
    public static final String JAIL_TROUPE_VOW = "chain_jail_v3";
    public static final String HOLY_NO_SELF = "holy_chain_l2";
    public static final String HOLY_SELF_VOW = "holy_chain_v3";
    public static final String SWEEP_MISS_VOW = "chain_sweep_v3";

    /**
     * The Vows that kill the user when broken. They can only be sworn by someone whose own heart carries the Stake of Retribution: they
     * chained themselves with the Judgment Chain (Shift+Z in Emperor Time). Hina's "remove the Stake" lifts them with it.
     */
    public static final Set<String> STAKE_VOWS = Set.of(JAIL_TROUPE_VOW, HOLY_SELF_VOW, SWEEP_MISS_VOW);

    /** Pseudo rule id sent to the client in the sworn list: "this player carries their own Stake of Retribution". Never a real rule. */
    public static final String STAKE_FLAG = "__stake";

    public static boolean stakeLocked(String ruleId) { return STAKE_VOWS.contains(ruleId); }

    /** How much of a Vow's designed bonus is kept (0.5 = half). */
    private static final float VOW_EFFECTIVENESS = 1f; // the numbers in the catalog are final (they used to be halved for Vows)

    /**
     * Rule bonuses multiply with each other (and with Hatsu level, Ten, Ren...), so one target can never gain more than this from
     * Conditions, Limitations and Vows together: x1.5 = +50%. Chain Jail duration and Holy Chain healing are utility, not damage.
     */
    public static final float MAX_RULE_POWER = 1.5f;
    public static final float MAX_RULE_POWER_UTILITY = 2.0f;

    static float ruleCap(String target) {
        return ChainAbilities.JAIL.equals(target) || ChainAbilities.HOLY.equals(target) ? MAX_RULE_POWER_UTILITY : MAX_RULE_POWER;
    }

    private static final int FIVE_MIN = 6000;
    private static final int ONE_MIN = 1200;

    /** Rule id -> rule, in catalog order. */
    public static final Map<String, Rule> RULES = new LinkedHashMap<>();
    /** What each skill's Conditions and Limitations boost, for the menu. */
    private static final Map<String, String> EFFECT = new LinkedHashMap<>();
    /** Hatsu abilities that can be bound (instant abilities: toggles are left out so a rule can never trap one switched on). */
    public static final List<String> HATSU_IDS = List.of(
        ChainAbilities.SWEEP, ChainAbilities.HOLY, ChainAbilities.JAIL,
        Jajanken.ROCK_ID, Jajanken.SCISSORS_ID, Jajanken.PAPER_ID,
        AuraBlast.ID, BungeeGum.ID, BungeeBarrier.ID, BungeeBind.ID, DragonHead.ID, LightningAura.PALM_ID, LightningAura.BOLT_ID, PaperManipulation.SERPENT_ID, HideAndSeek.ID, HideAndSeek.SCREAM_ID, PainPacker.SUN_ID, RipperCyclotron.ID, BigBangImpact.ID,
        NenStitches.TRAP_ID, NenStitches.BIND_ID, NenStitches.SEW_ID);
    /** The basic Nen attacks (HxHAdventure's own Attack / Strong attack / Barrage). Rules can be bound to these too. */
    public static final String ATTACK = "nen_attack", STRONG = "nen_strong", BARRAGE = "nen_barrage";
    public static final List<String> ATTACK_IDS = List.of(ATTACK, STRONG, BARRAGE);
    private static final Map<String, String> ABILITY_LABEL = new LinkedHashMap<>();

    /** Id of the "I must pray before every attack" Condition bound to an attack. */
    public static String prayRule(String attackId) { return attackId + "_c2"; }

    /** Id of the Vow "I cannot use this unless I pray first; the prayer cannot be cut short". Bound to attacks and Hatsu abilities. */
    public static String prayVow(String abilityId) { return abilityId + "_vpray"; }

    /** The weaker prayer Condition that swearing this rule replaces (the Vow replaces the Condition on the same attack), or null. */
    public static String weakerPrayer(String ruleId) {
        Rule r = RULES.get(ruleId);
        if (r == null || !isAttack(r.target()) || !ruleId.equals(prayVow(r.target()))) return null;
        return prayRule(r.target());
    }

    /**
     * Only one prayer restriction can stand on an attack. If an older save holds both the Condition and the Vow, the weaker one (the
     * Condition) is dropped. Returns true if something was removed.
     */
    public static boolean normalizePrayer(ServerPlayer sp, NenAddonData d, String abilityId) {
        if (!isAttack(abilityId) || !d.vows.contains(prayVow(abilityId)) || !d.vows.remove(prayRule(abilityId))) return false;
        d.markSync();
        d.save();
        sync(sp);
        return true;
    }

    /** Id of the Limitation "I cannot move while using this" (also holds for the whole of a prayer). Bound to attacks and Hatsu abilities. */
    public static String rootLimit(String abilityId) { return abilityId + "_lroot"; }

    /** Id of the Limitation "using this forces me into Ko". Bound to attacks and Hatsu abilities. */
    public static String koLimit(String abilityId) { return abilityId + "_lko"; }

    // ---- ids of the added rules (every ability, attack and, where it makes sense, skill gets them) ----
    public static String cd5(String t) { return t + "_cd5"; }
    public static String daily(String t) { return t + "_ldaily"; }
    public static String weekly(String t) { return t + "_vweek"; }

    /** Id of the Vow "if this misses, I die". Bound to every ability that deals damage. */
    public static String missVow(String abilityId) { return abilityId + "_vmiss"; }

    /** Abilities that deal damage, so "if it misses I die" can be sworn on them (Dowsing Chain has its own, enforced by the chains). */
    public static final List<String> DAMAGING_IDS = List.of(
        ATTACK, STRONG, BARRAGE, Jajanken.ROCK_ID, Jajanken.SCISSORS_ID, Jajanken.PAPER_ID, AuraBlast.ID, DragonHead.ID);

    /** Hatsu abilities that are charged while Z is held: their Ko / root limitations run from the press until the attack goes out. */
    public static boolean isChargeUp(String id) {
        return Jajanken.ROCK_ID.equals(id) || Jajanken.SCISSORS_ID.equals(id) || Jajanken.PAPER_ID.equals(id)
            || DragonHead.ID.equals(id) || RipperCyclotron.ID.equals(id) || BigBangImpact.ID.equals(id);
    }

    /** Is this charge-up still being charged right now? */
    public static boolean chargeActive(Player p, String id) {
        if (Jajanken.ROCK_ID.equals(id) || Jajanken.SCISSORS_ID.equals(id) || Jajanken.PAPER_ID.equals(id)) return Jajanken.isCharging(p);
        if (DragonHead.ID.equals(id)) return DragonHead.isCharging(p);
        if (BigBangImpact.ID.equals(id)) return BigBangImpact.isFocusing(p);
        return RipperCyclotron.isSpinning(p);
    }

    public static boolean isAttack(String id) { return ATTACK_IDS.contains(id); }
    /** Anything a rule can be bound to besides a Nen skill: a Hatsu ability or a basic attack. */
    public static boolean isBoundAbility(String id) { return HATSU_IDS.contains(id) || ATTACK_IDS.contains(id); }

    static {
        EFFECT.put("TEN", "speed, durability, damage and regen");
        EFFECT.put("ZETSU", "regen");
        EFFECT.put("REN", "power");
        EFFECT.put("EN", "range");
        EFFECT.put("HATSU", "aura refund and Hatsu damage");
        EFFECT.put("IN", "stealth");
        EFFECT.put("SHU", "weapon damage");
        EFFECT.put("GYO", "sight");

        ABILITY_LABEL.put(ChainAbilities.SWEEP, "Dowsing Chain");
        ABILITY_LABEL.put(ChainAbilities.HOLY, "Holy Chain");
        ABILITY_LABEL.put(ChainAbilities.JAIL, "Chain Jail");
        ABILITY_LABEL.put(Jajanken.ROCK_ID, "Jajanken: Rock");
        ABILITY_LABEL.put(Jajanken.SCISSORS_ID, "Jajanken: Scissors");
        ABILITY_LABEL.put(Jajanken.PAPER_ID, "Jajanken: Paper");
        ABILITY_LABEL.put(AuraBlast.ID, "Aura Blast");
        ABILITY_LABEL.put(BungeeGum.ID, "Bungee Gum");
        ABILITY_LABEL.put(BungeeBarrier.ID, "Bungee Barrier");
        ABILITY_LABEL.put(BungeeBind.ID, "Bungee Bind");
        ABILITY_LABEL.put(DragonHead.ID, "Dragon Head");
        ABILITY_LABEL.put(LightningAura.PALM_ID, "Lightning Palm");
        ABILITY_LABEL.put(LightningAura.BOLT_ID, "Thunderbolt");
        ABILITY_LABEL.put(HideAndSeek.ID, "Hide and Seek");
        ABILITY_LABEL.put(HideAndSeek.SCREAM_ID, "Scream");
        ABILITY_LABEL.put(PainPacker.SUN_ID, "Rising Sun");
        ABILITY_LABEL.put(RipperCyclotron.ID, "Ripper Cyclotron");
        ABILITY_LABEL.put(BigBangImpact.ID, "Big Bang Impact");
        ABILITY_LABEL.put(NenStitches.TRAP_ID, "Nen Thread Trap");
        ABILITY_LABEL.put(NenStitches.BIND_ID, "Thread Bind");
        ABILITY_LABEL.put(NenStitches.SEW_ID, "Wound Sewing");
        ABILITY_LABEL.put(PaperManipulation.SERPENT_ID, "Dance of the Serpent's Bite");
        ABILITY_LABEL.put(ATTACK, "Attack");
        ABILITY_LABEL.put(STRONG, "Strong Attack");
        ABILITY_LABEL.put(BARRAGE, "Barrage Attack");

        // ---- Nen skills ----
        for (NenSkill s : NenSkill.values()) {
            String k = s.name();
            String id = k.toLowerCase(Locale.ROOT);
            String l = s.label;
            boolean hatsu = s == NenSkill.HATSU;
            String subject = hatsu ? "Hatsu abilities" : l;
            // Ten is always on (it comes back by itself), so "only while crouched" would leave it off nearly all the time
            if (s != NenSkill.TEN) add(id + "_l1", k, Kind.LIMITATION, subject + " can only be used while crouched", 1.05f, Enforce.ONLY_WHEN, "CROUCH", 0);
            switch (s) {
                case TEN -> {
                    add(id + "_l2", k, Kind.LIMITATION, "Ten can only be used in daylight", 1.05f, Enforce.ONLY_WHEN, "DAY", 0);
                    add(id + "_l3", k, Kind.LIMITATION, "Ten can only be used at night", 1.05f, Enforce.ONLY_WHEN, "NIGHT", 0);
                }
                case ZETSU -> add(id + "_l2", k, Kind.LIMITATION, "Zetsu can only be used outdoors", 1.05f, Enforce.ONLY_WHEN, "SKY", 0);
                case HATSU -> add(id + "_l2", k, Kind.LIMITATION, "Hatsu abilities can only be used outdoors", 1.05f, Enforce.ONLY_WHEN, "SKY", 0);
                case EN -> add(id + "_l2", k, Kind.LIMITATION, "En turns off Ken", 1.05f, Enforce.EXCLUDES, "KEN", 0);
                case REN -> add(id + "_l2", k, Kind.LIMITATION, "Ren turns off Gyo", 1.05f, Enforce.EXCLUDES, "GYO", 0);
                case IN -> add(id + "_l2", k, Kind.LIMITATION, "In turns off Gyo", 1.05f, Enforce.EXCLUDES, "GYO", 0);
                case GYO -> add(id + "_l2", k, Kind.LIMITATION, "Gyo turns off In", 1.05f, Enforce.EXCLUDES, "IN", 0);
                default -> { }
            }
            addSkillExtras(id, k, l, subject, s);
            switch (s) {
                case TEN -> add(id + "_v1", k, Kind.VOW, "Using Ten and En together forces me into Zetsu for 5 minutes", 1.05f, Enforce.BOTH_FORCED, "EN", FIVE_MIN);
                case ZETSU -> add(id + "_v1", k, Kind.VOW, "Using Zetsu in daylight locks me in Zetsu for 5 minutes", 1.05f, Enforce.FORCED_IF, "DAY", FIVE_MIN);
                case REN -> add(id + "_v1", k, Kind.VOW, "Using Ren and En together forces me into Zetsu for 5 minutes", 1.05f, Enforce.BOTH_FORCED, "EN", FIVE_MIN);
                case EN -> add(id + "_v1", k, Kind.VOW, "Using En and Gyo together forces me into Zetsu for 5 minutes", 1.05f, Enforce.BOTH_FORCED, "GYO", FIVE_MIN);
                case HATSU -> add(id + "_v1", k, Kind.VOW, "After using any Hatsu ability I am locked in Zetsu for 1 minute", 1.05f, Enforce.FORCED_AFTER, "", ONE_MIN);
                case IN -> add(id + "_v1", k, Kind.VOW, "Using In and En together forces me into Zetsu for 5 minutes", 1.05f, Enforce.BOTH_FORCED, "EN", FIVE_MIN);
                case GYO -> add(id + "_v1", k, Kind.VOW, "Using Gyo and En together forces me into Zetsu for 5 minutes", 1.05f, Enforce.BOTH_FORCED, "EN", FIVE_MIN);
            }
        }

        // ---- Shu: Limitations that hold only while Shu is on (+5% damage each) ----
        add(SHU_FORCE_REN, "SHU", Kind.LIMITATION, "Using Shu forces me into Ren", SHU_LIMIT_MULT, Enforce.FORCES, "REN", 0);
        add(SHU_FORCE_KO, "SHU", Kind.LIMITATION, "Using Shu forces me into Ko", SHU_LIMIT_MULT, Enforce.FORCES, "KO", 0);
        add(SHU_NO_GYO, "SHU", Kind.LIMITATION, "Using Shu disables my Gyo", SHU_LIMIT_MULT, Enforce.EXCLUDES, "GYO", 0);
        add(SHU_NO_IN, "SHU", Kind.LIMITATION, "Using Shu disables my In", SHU_LIMIT_MULT, Enforce.EXCLUDES, "IN", 0);

        // ---- Hatsu abilities ----
        for (String a : HATSU_IDS) {
            String l = ABILITY_LABEL.get(a);
            add(a + "_l1", a, Kind.LIMITATION, l + " can only be used while crouched", 1.04f, Enforce.ONLY_WHEN, "CROUCH", 0);
            add(rootLimit(a), a, Kind.LIMITATION, "I cannot move while using " + l, 1.08f, Enforce.CUSTOM, "", 0);
            add(koLimit(a), a, Kind.LIMITATION, "Using " + l + " forces me into Ko", 1.04f, Enforce.CUSTOM, "", 0);
            add(a + "_v1", a, Kind.VOW, "After using " + l + " I am locked in Zetsu for 1 minute", 1.20f, Enforce.FORCED_AFTER, "", ONE_MIN);
            add(prayVow(a), a, Kind.VOW, "I cannot use " + l + " unless I pray first, and the prayer cannot be cut short", 1.15f, Enforce.CUSTOM, "", 0);
            addAbilityExtras(a, l);
        }
        // ---- Lockouts: never use a skill again, power up something else. Ten can never be locked. ----
        final String up = " (can pass 100)";
        List<NenSkill> none = List.of();
        // Ren: three alternatives (only one can be sworn)
        addLock("ren_lock_zetsu", "REN", "I cannot use Ren anymore, so my Zetsu grows stronger",
            new Lock("REN", "REN_LOCK", List.of(NenSkill.ZETSU), 0.20f, 1f, false, "+20% Zetsu level" + up));
        addLock("ren_lock_hatsu", "REN", "I cannot use Ren anymore, so my Hatsu grows stronger",
            new Lock("REN", "REN_LOCK", List.of(NenSkill.HATSU), 0.20f, 1f, false, "+20% Hatsu level" + up));
        addLock("ren_lock_aura", "REN", "I cannot use Ren anymore, so my maximum aura grows",
            new Lock("REN", "REN_LOCK", none, 0f, 1.3f, false, "Maximum aura +30%"));
        // En: restrict it to 1 meter for a dodge chance, or give it up entirely (only one of these three)
        addLock(EN_RANGE_VOW, "EN", "I restrict my En to a range of 1 meter, and my body learns to dodge",
            new Lock(null, "EN_LOCK", none, 0f, 1f, true, "20% auto-dodge while En is on"));
        addLock(EN_SHU_VOW, "EN", "I restrict my En to a range of 4 meters, so my Shu grows stronger",
            new Lock(null, "EN_LOCK", List.of(NenSkill.SHU), EN_SHU_BOOST, 1f, true, EN_SHU_RADIUS, "+20% Shu level" + up));
        addLock("en_lock_ten", "EN", "I cannot use En anymore, so my Ten grows stronger",
            new Lock("EN", "EN_LOCK", List.of(NenSkill.TEN), 0.10f, 1f, false, "+10% Ten level" + up));
        addLock("en_lock_hatsu", "EN", "I cannot use En anymore, so my Hatsu grows stronger",
            new Lock("EN", "EN_LOCK", List.of(NenSkill.HATSU), 0.10f, 1f, false, "+10% Hatsu level" + up));
        addLock("in_lock", "IN", "I cannot use In anymore, so my Gyo grows stronger",
            new Lock("IN", "IN_LOCK", List.of(NenSkill.GYO), 0.10f, 1f, false, "+10% Gyo level" + up));
        addLock("gyo_lock", "GYO", "I cannot use Gyo anymore, so my In grows stronger",
            new Lock("GYO", "GYO_LOCK", List.of(NenSkill.IN), 0.10f, 1f, false, "+10% In level" + up));
        addLock("zetsu_lock", "ZETSU", "I cannot use Zetsu anymore, so my Ren grows stronger",
            new Lock("ZETSU", "ZETSU_LOCK", List.of(NenSkill.REN), 0.10f, 1f, false, "+10% Ren level" + up));
        addLock("hatsu_lock", "HATSU", "I cannot use Hatsu anymore, so my Ten and Ren grow far stronger",
            new Lock("HATSU", "HATSU_LOCK", List.of(NenSkill.TEN, NenSkill.REN), 0.25f, 1f, false, "+25% Ten and Ren level" + up));
        addLock("ken_lock", "KEN", "I cannot use Ken anymore, so my Ten grows stronger",
            new Lock("KEN", "KEN_LOCK", List.of(NenSkill.TEN), 0.10f, 1f, false, "+10% Ten level" + up));
        addLock("ko_lock", "KO", "I cannot use Ko anymore, so my Ten grows stronger",
            new Lock("KO", "KO_LOCK", List.of(NenSkill.TEN), 0.10f, 1f, false, "+10% Ten level" + up));

        // ---- Basic attacks (Attack, Strong attack, Barrage attack) ----
        for (String a : ATTACK_IDS) {
            String l = ABILITY_LABEL.get(a);
            add(prayRule(a), a, Kind.CONDITION, "I must pray before every " + l + " (otherwise its damage is halved)", 1.08f, Enforce.CUSTOM, "", 0);
            add(a + "_l1", a, Kind.LIMITATION, l + " can only be used while crouched", 1.04f, Enforce.ONLY_WHEN, "CROUCH", 0);
            add(a + "_l2", a, Kind.LIMITATION, l + " can only be used in daylight", 1.04f, Enforce.ONLY_WHEN, "DAY", 0);
            add(a + "_l3", a, Kind.LIMITATION, l + " can only be used at night", 1.04f, Enforce.ONLY_WHEN, "NIGHT", 0);
            if (!BARRAGE.equals(a)) add(rootLimit(a), a, Kind.LIMITATION, "I cannot move while using " + l, 1.06f, Enforce.CUSTOM, "", 0);
            add(koLimit(a), a, Kind.LIMITATION, "Using " + l + " forces me into Ko", 1.04f, Enforce.CUSTOM, "", 0);
            add(a + "_v1", a, Kind.VOW, "After using " + l + " I am locked in Zetsu for 1 minute", 1.15f, Enforce.FORCED_AFTER, "", ONE_MIN);
            add(prayVow(a), a, Kind.VOW, "I cannot use " + l + " unless I pray first, and the prayer cannot be cut short", 1.15f, Enforce.CUSTOM, "", 0);
            addAbilityExtras(a, l);
        }
        // The generic "if I do (or fail to do) X, I die" Vows ("above 70% health", "if it misses") are gone from every ability: death-Vows now only
        // exist on the Chains (below) and can only be sworn by someone who has chained themselves with the Judgment Chain (Shift+Z, see STAKE_VOWS).
        // Chains: the examples of the Hunter x Hunter rules themselves
        add(JAIL_TROUPE, ChainAbilities.JAIL, Kind.CONDITION, "Chain Jail can only be used on members of the Phantom Troupe", 1.5f, Enforce.CUSTOM, "", 0);
        add(JAIL_TROUPE_VOW, ChainAbilities.JAIL, Kind.VOW, "If I use Chain Jail on anyone but a Phantom Troupe member, I die", 1.8f, Enforce.CUSTOM, "", 0);
        add(HOLY_NO_SELF, ChainAbilities.HOLY, Kind.LIMITATION, "Holy Chain can never be used on myself", 1.10f, Enforce.CUSTOM, "", 0);
        add(HOLY_SELF_VOW, ChainAbilities.HOLY, Kind.VOW, "If I use Holy Chain on myself, I die", 1.3f, Enforce.CUSTOM, "", 0);
        add(SWEEP_MISS_VOW, ChainAbilities.SWEEP, Kind.VOW, "If Dowsing Chain hits no one, I die", 1.3f, Enforce.CUSTOM, "", 0);
        // Jajanken: the vow that opens "I'll use everything." (no stat bonus: mult 1)
        add(EVERYTHING_VOW, Jajanken.ROCK_ID, Kind.VOW, GonVow.PHRASE, 1.0f, Enforce.CUSTOM, "", 0);
    }


    private static final int DAY_TICKS = 24000, WEEK_TICKS = 7 * 24000;

    /** The extra Conditions, Limitations and Vows every Hatsu ability and basic attack can take. */
    private static void addAbilityExtras(String a, String l) {
        // Conditions: small prices, like a toll or a short rest
        add(cd5(a), a, Kind.CONDITION, l + " can only be used once every 5 minutes", 1.04f, Enforce.COOLDOWN, "", FIVE_MIN);
        add(a + "_ctoll", a, Kind.CONDITION, "After using " + l + " I lose 2 hearts", 1.05f, Enforce.HEALTH_COST, "4", 0);
        add(a + "_chunger", a, Kind.CONDITION, "After using " + l + " I lose 3 drumsticks of hunger", 1.04f, Enforce.HUNGER_COST, "6", 0);
        // Limitations: real handicaps
        add(daily(a), a, Kind.LIMITATION, l + " can only be used once per day", 1.12f, Enforce.COOLDOWN, "", DAY_TICKS);
        add(a + "_lrain", a, Kind.LIMITATION, l + " can only be used while it is raining", 1.06f, Enforce.ONLY_WHEN, "RAIN", 0);
        add(a + "_lcave", a, Kind.LIMITATION, l + " can only be used underground", 1.05f, Enforce.ONLY_WHEN, "UNDERGROUND", 0);
        add(a + "_lbare", a, Kind.LIMITATION, l + " can only be used with an empty hand", 1.05f, Enforce.ONLY_WHEN, "EMPTY_HAND", 0);
        add(a + "_larmor", a, Kind.LIMITATION, l + " can only be used while wearing no armor", 1.07f, Enforce.ONLY_WHEN, "NO_ARMOR", 0);
        add(a + "_lwater", a, Kind.LIMITATION, l + " can only be used while in water", 1.05f, Enforce.ONLY_WHEN, "WATER", 0);
        add(a + "_lwound", a, Kind.LIMITATION, l + " can only be used while I am wounded (below 70% health)", 1.07f, Enforce.ONLY_WHEN, "LOW_HP", 0);
        add(a + "_lblind", a, Kind.LIMITATION, "After using " + l + " I am blinded for 10 seconds", 1.08f, Enforce.EFFECT_AFTER, "blindness", 200);
        add(a + "_lslow", a, Kind.LIMITATION, "After using " + l + " I am slowed for 15 seconds", 1.06f, Enforce.EFFECT_AFTER, "slowness", 300);
        add(a + "_lweak", a, Kind.LIMITATION, "After using " + l + " I am weakened for 30 seconds", 1.06f, Enforce.EFFECT_AFTER, "weakness", 600);
        // Vows: contracts with a severe price
        add(weekly(a), a, Kind.VOW, l + " can only be used once every 7 days", 1.30f, Enforce.COOLDOWN, "", WEEK_TICKS);
        add(a + "_vcrit", a, Kind.VOW, l + " can only be used while I am near death (below 30% health)", 1.25f, Enforce.ONLY_WHEN, "CRITICAL_HP", 0);
        add(a + "_vhalf", a, Kind.VOW, "After using " + l + " I lose half of my maximum health", 1.20f, Enforce.HEALTH_COST, "HALF", 0);
        add(a + "_vstarve", a, Kind.VOW, "After using " + l + " my stomach is emptied completely", 1.15f, Enforce.HUNGER_COST, "20", 0);
        add(a + "_vblind", a, Kind.VOW, "After using " + l + " I am blind and slowed for 1 minute", 1.18f, Enforce.EFFECT_AFTER, "blindness,slowness", ONE_MIN);
    }

    /** The extra rules a Nen skill can take. They apply while the skill is switched on (and, for a cooldown, each time it is switched on). */
    private static void addSkillExtras(String id, String k, String l, String subject, NenSkill s) {
        boolean hatsu = s == NenSkill.HATSU;
        // Ten is the basic Nen output and is switched back on automatically, so it takes no cooldowns (they made it flicker on and off,
        // or locked it away for days) and nothing that keeps it off most of the time (rain). Hatsu is every ability at once: a day or a
        // week between ANY two abilities for a few percent of refund is no deal, so it only gets the 5 minute Condition.
        if (s != NenSkill.TEN) add(cd5(id), k, Kind.CONDITION, subject + " can only be used once every 5 minutes", 1.05f, Enforce.COOLDOWN, "", FIVE_MIN);
        if (s != NenSkill.TEN && !hatsu) add(daily(id), k, Kind.LIMITATION, subject + " can only be used once per day", 1.12f, Enforce.COOLDOWN, "", DAY_TICKS);
        if (s != NenSkill.TEN && !hatsu) add(weekly(id), k, Kind.VOW, subject + " can only be used once every 7 days", 1.12f, Enforce.COOLDOWN, "", WEEK_TICKS);
        if (s != NenSkill.TEN) add(id + "_lrain", k, Kind.LIMITATION, subject + " can only be used while it is raining", 1.05f, Enforce.ONLY_WHEN, "RAIN", 0);
        add(id + "_lcave", k, Kind.LIMITATION, subject + " can only be used underground", 1.05f, Enforce.ONLY_WHEN, "UNDERGROUND", 0);
        add(id + "_lbare", k, Kind.LIMITATION, subject + " can only be used with an empty hand", 1.05f, Enforce.ONLY_WHEN, "EMPTY_HAND", 0);
        add(id + "_larmor", k, Kind.LIMITATION, subject + " can only be used while wearing no armor", 1.07f, Enforce.ONLY_WHEN, "NO_ARMOR", 0);
    }


    private static void addLock(String id, String target, String text, Lock lock) {
        LOCKS.put(id, lock);
        RULES.put(id, new Rule(id, target, Kind.VOW, text, 1f, Enforce.LOCK, lock.locked() == null ? "" : lock.locked(), 0));
    }

    private static void add(String id, String target, Kind kind, String text, float mult, Enforce enforce, String arg, int ticks) {
        if (kind == Kind.VOW) mult = 1f + (mult - 1f) * VOW_EFFECTIVENESS; // (Vows keep their catalog numbers; see VOW_EFFECTIVENESS)
        RULES.put(id, new Rule(id, target, kind, text, mult, enforce, arg, ticks));
    }

    // ---------------------------------------------------------------- lookups (shared by server and menu)

    /** Rules that cannot be sworn together: "can only be used while crouched" and "I cannot move while using it". */
    public static boolean conflicts(String ruleId, java.util.Collection<String> chosen) {
        Lock l = LOCKS.get(ruleId);
        if (l != null) {
            // Lockouts: only one alternative per skill, nothing can boost a skill that is locked, and a skill that is already boosted cannot be locked
            for (String id : chosen) {
                Lock o = LOCKS.get(id);
                if (o == null || id.equals(ruleId)) continue;
                if (o.group().equals(l.group())) return true;
                if (l.locked() != null && boosts(o, l.locked())) return true;
                if (o.locked() != null && boosts(l, o.locked())) return true;
            }
            // a skill cannot be given up while a Shu Vow forces it on
            if (("REN".equals(l.locked()) && chosen.contains(SHU_FORCE_REN)) || ("KO".equals(l.locked()) && chosen.contains(SHU_FORCE_KO))) return true;
            return false;
        }
        Rule r = RULES.get(ruleId);
        // Ren and Ko are alternatives, so Shu cannot force both; and it cannot force what is given up for good
        if (ruleId.equals(SHU_FORCE_REN) && (chosen.contains(SHU_FORCE_KO) || isLocked(chosen, "REN"))) return true;
        if (ruleId.equals(SHU_FORCE_KO) && (chosen.contains(SHU_FORCE_REN) || isLocked(chosen, "KO"))) return true;
        // "only in daylight" and "only at night" (or outdoors and underground, bare hand and held item) on the same thing would forbid it for good
        if (r != null && r.enforce() == Enforce.ONLY_WHEN && OPPOSITE.containsKey(r.arg())) {
            String opposite = OPPOSITE.get(r.arg());
            for (String id : chosen) {
                Rule o = RULES.get(id);
                if (o != null && o.target().equals(r.target()) && o.enforce() == Enforce.ONLY_WHEN && o.arg().equals(opposite)) return true;
            }
        }
        // one cooldown, one health price and one hunger price per thing: the stricter one replaces the idea of a second
        if (r != null && (r.enforce() == Enforce.COOLDOWN || r.enforce() == Enforce.HEALTH_COST || r.enforce() == Enforce.HUNGER_COST)) {
            for (String id : chosen) {
                Rule o = RULES.get(id);
                if (o != null && !id.equals(ruleId) && o.target().equals(r.target()) && o.enforce() == r.enforce()) return true;
            }
        }
        if (r == null || !isBoundAbility(r.target())) return false;
        String t = r.target();
        // Prayer: only one prayer restriction per attack. The Vow is the stronger form, so the Condition cannot be sworn once the Vow
        // is held (the other way round is allowed: swearing the Vow replaces the Condition, see choose()).
        if (isAttack(t) && ruleId.equals(prayRule(t)) && chosen.contains(prayVow(t))) return true;
        if (ruleId.equals(rootLimit(t))) return chosen.contains(t + "_l1");
        if (ruleId.equals(t + "_l1")) return chosen.contains(rootLimit(t));
        return false;
    }

    private static boolean boosts(Lock l, String skillKey) {
        for (NenSkill s : l.boosts()) if (s.name().equals(skillKey)) return true;
        return false;
    }

    /** Ken and Ko: aura forms. They take rules but have no skill level of their own. */
    public static boolean isForm(String target) {
        return FORM_KEYS.contains(target);
    }

    public static boolean isSkill(String target) {
        for (NenSkill s : NenSkill.values()) if (s.name().equals(target)) return true;
        return false;
    }

    public static String label(String target) {
        if ("KEN".equals(target)) return "Ken";
        if ("KO".equals(target)) return "Ko";
        for (NenSkill s : NenSkill.values()) if (s.name().equals(target)) return s.label;
        return ABILITY_LABEL.getOrDefault(target, target);
    }

    public static String abilityStat(String id) {
        if (ChainAbilities.JAIL.equals(id)) return "duration";
        if (ChainAbilities.HOLY.equals(id)) return "healing";
        return "damage";
    }

    public static List<Rule> rulesFor(String target, Kind kind) {
        List<Rule> out = new ArrayList<>();
        for (Rule r : RULES.values()) if (r.target().equals(target) && r.kind() == kind) out.add(r);
        return out;
    }

    static int pct(float mult) {
        return Math.round((mult - 1f) * 100f);
    }

    static String fmtMult(float m) {
        return "+" + pct(m) + "%";
    }

    /**
     * The combined buff of everything sworn on one target (all rules multiply together), as text for the menu, or null when none.
     * A skill shows its effect (Conditions and Limitations) and its level (Vows) separately; an ability shows one total.
     */
    public static String combinedText(String target, java.util.Collection<String> sworn) {
        float effect = 1f, level = 1f, all = 1f;
        int n = 0;
        List<String> locks = new ArrayList<>();
        for (String id : sworn) {
            Rule r = RULES.get(id);
            if (r == null || !r.target().equals(target) || r.id().equals(EVERYTHING_VOW)) continue;
            n++;
            if (r.enforce() == Enforce.LOCK) {
                locks.add(r.boostText());
                continue;
            }
            all *= r.mult();
            if (r.kind() == Kind.VOW) level *= r.mult(); else effect *= r.mult();
        }
        if (n == 0) return null;
        float cap = ruleCap(target);
        if (!isSkill(target) && !isForm(target)) return "+" + pct(Math.min(all, cap)) + "% " + abilityStat(target) + (all > cap ? " (max)" : "");
        List<String> parts = new ArrayList<>();
        if (effect != 1f) parts.add("+" + pct(Math.min(effect, cap)) + "% " + EFFECT.getOrDefault(target, "strength") + (effect > cap ? " (max)" : ""));
        if (level != 1f) parts.add("+" + pct(level) + "% " + label(target) + " level");
        parts.addAll(locks);
        return String.join(", ", parts);
    }

    /** Everything sworn removed (the player lost their Nen). */
    public static void clearAll(ServerPlayer sp) {
        NenAddonData d = NenAddonData.get(sp);
        boolean had = !d.vows.isEmpty() || d.prayers != 0;
        d.vows.clear();
        d.prayers = 0;
        Prayer.forget(sp.getUUID());
        if (had) {
            d.markSync();
            d.save();
            sync(sp);
            AddonNetwork.sendToTrackingAndSelf(new net.hxhadventure.addon.network.PacketPrayFx(sp.getId(), 0), sp);
        }
    }

    /**
     * Removes EVERY Condition, Limitation and Vow (and the prayers), then stops everything they had set going (forced Zetsu, locks,
     * prayers, Ko, En / Ren sizes). Used by /hxh remove restrictions and by Hina. Returns how many rules were removed.
     */
    public static int removeAllRestrictions(ServerPlayer sp) {
        NenAddonData d = NenAddonData.get(sp);
        int n = d.vows.size();
        boolean had = n > 0 || d.prayers != 0;
        clearAll(sp);
        if (had) afterLift(sp);
        return had ? Math.max(1, n) : 0;
    }

    // ---------------------------------------------------------------- multipliers

    private static Set<String> chosen(Player p) {
        if (p == null) return Set.of();
        if (p.level().isClientSide) return ClientVows.chosen; // the menus and the aura bar read the local player's mirror
        NenAddonData d = NenAddonData.peek(p);
        return d == null ? Set.of() : d.vows;
    }

    /**
     * The level a skill performs at: its trained level raised by Vows and lockouts, so it can pass 100. In and Gyo work by comparing
     * levels, so their Conditions and Limitations raise it too. Works on both sides (the client reads its mirror of the vows).
     */
    public static int effLevel(Player p, NenSkill s, int trained) {
        float m = levelMult(p, s);
        if (s == NenSkill.IN || s == NenSkill.GYO) m *= power(p, s.name());
        return Math.max(1, Math.round(trained * m));
    }

    /** Has this player sworn never to use this skill or form again (a NenSkill name, KEN or KO)? */
    public static boolean isLocked(Player p, String key) {
        return isLocked(chosen(p), key);
    }

    public static boolean isLocked(java.util.Collection<String> sworn, String key) {
        for (String id : sworn) {
            Lock l = LOCKS.get(id);
            if (l != null && key.equals(l.locked())) return true;
        }
        return false;
    }

    /** True (and tells the player) when a lockout forbids this skill. Used by every way of switching a skill on. */
    public static boolean refuseLocked(ServerPlayer sp, String key) {
        if (!isLocked(sp, key)) return false;
        sp.displayClientMessage(Component.literal("\u00a77You swore never to use " + label(key) + " again"), true);
        return true;
    }

    /** Multiplier on maximum aura from lockouts (1.3 once Ren is given up for aura). */
    public static float maxAuraMult(Player p) {
        float m = 1f;
        for (String id : chosen(p)) {
            Lock l = LOCKS.get(id);
            if (l != null) m *= l.auraMult();
        }
        return m;
    }

    /** The furthest En can reach because of sworn restrictions (blocks), or infinity when none holds. Both En range Vows count; the smaller wins. */
    public static float enRadiusLimit(Player p) {
        float cap = Float.POSITIVE_INFINITY;
        for (String id : chosen(p)) {
            Lock l = LOCKS.get(id);
            if (l != null && l.enRadius() > 0f) cap = Math.min(cap, l.enRadius());
        }
        return cap;
    }

    /** Shu is on and a sworn Vow forces an aura form: "REN" or "KO" (Ren and Ko cannot both be forced); null when nothing is forced. */
    public static String shuForcedForm(Player p, NenAddonData d) {
        if (d == null || !d.shu) return null;
        Set<String> ch = chosen(p);
        if (ch.contains(SHU_FORCE_REN)) return "REN";
        if (ch.contains(SHU_FORCE_KO)) return "KO";
        return null;
    }

    /** Shu is on and a sworn Vow disables this skill ("GYO" or "IN"): it cannot be switched on. */
    public static boolean shuForbids(Player p, NenAddonData d, String key) {
        if (d == null || !d.shu) return false;
        return chosen(p).contains("GYO".equals(key) ? SHU_NO_GYO : SHU_NO_IN);
    }

    /**
     * The Ren key while Shu forces a form: refused when it would break the forced form (Ren switched off under a forced Ren, or switched
     * on under a forced Ko). Tells the player. Called before the "ren_toggle" ability runs.
     */
    public static boolean refuseShuFormToggle(ServerPlayer sp) {
        NenAddonData d = NenAddonData.peek(sp);
        Combat c = Combat.get(sp);
        String f = shuForcedForm(sp, d);
        if (f == null || c == null) return false;
        boolean ren = c.isAuraActive();
        if (!(("REN".equals(f) && ren) || ("KO".equals(f) && !ren))) return false;
        sp.displayClientMessage(Component.literal("\u00a74Vow: \u00a77Shu is on, so you are held in " + label(f)), true);
        return true;
    }

    /** En is restricted to {@link #EN_RESTRICTED_RADIUS} (and gives a dodge chance). */
    public static boolean enRangeLimited(Player p) {
        return chosen(p).contains(EN_RANGE_VOW);
    }

    /** Hatsu abilities hit harder the higher the Hatsu skill is (its effective level, which Vows can lift past 100). */
    public static float hatsuDamageMult(Player p) {
        if (p == null || p.level().isClientSide) return 1f;
        NenAddonData d = NenAddonData.peek(p);
        return 1f + Tuning.hatsuDamageBonus(d == null ? 1 : d.effLevel(NenSkill.HATSU));
    }

    /** The creature behind the Hatsu hit that is being dealt right now (null when none): see {@link #hatsuHurt}. */
    private static Entity hatsuCause;

    /**
     * Every Hatsu ability deals its damage through this. The hit is marked, so that {@link AddonServerEvents} does not multiply it by
     * the Ten / Ren / Ken bonus on top: Hatsu damage scales on the Hatsu level (and Ko), not on Ten.
     */
    public static boolean hatsuHurt(LivingEntity victim, DamageSource src, float amount) {
        Entity prev = hatsuCause;
        hatsuCause = src.getEntity();
        try {
            return victim.hurt(src, amount);
        } finally {
            hatsuCause = prev;
        }
    }

    /** Is this damage a Hatsu ability's hit (dealt through {@link #hatsuHurt})? */
    public static boolean isHatsuHit(DamageSource src) {
        return hatsuCause != null && src.getEntity() == hatsuCause;
    }

    /** Does the Hatsu skill's damage bonus apply to this id? Not to basic attacks, aura forms, or the two chains that heal / imprison. */
    private static boolean usesHatsuDamage(String target) {
        return !isSkill(target) && !isForm(target) && !isAttack(target)
            && !ChainAbilities.JAIL.equals(target) && !ChainAbilities.HOLY.equals(target);
    }

    public static boolean has(Player p, String ruleId) {
        return chosen(p).contains(ruleId);
    }

    /** Level multiplier from the Vows sworn on a Nen skill (1 when none). */
    public static float levelMult(Player p, NenSkill s) {
        float m = 1f;
        for (String id : chosen(p)) {
            Rule r = RULES.get(id);
            if (r != null && r.kind() == Kind.VOW && r.target().equals(s.name())) m *= r.mult();
            Lock l = LOCKS.get(id);
            if (l != null && boosts(l, s.name())) m *= 1f + l.boost();
        }
        return m;
    }

    /**
     * Power multiplier for a target: for a skill, the Conditions and Limitations on it (Vows act through the level instead);
     * for a Hatsu ability, everything sworn on it. 1 for anyone without vows.
     */
    public static float power(Player p, String target) {
        boolean skill = isSkill(target);
        float m = 1f;
        for (String id : chosen(p)) {
            Rule r = RULES.get(id);
            if (r == null || !r.target().equals(target)) continue;
            if (skill && r.kind() == Kind.VOW) continue;
            m *= r.mult();
        }
        m = Math.min(m, ruleCap(target)); // stacked rules are capped; the Hatsu level bonus below is separate
        if (usesHatsuDamage(target)) m *= hatsuDamageMult(p);
        return m;
    }

    // ---------------------------------------------------------------- choosing (server)

    /** A player swore a rule: checked here, then saved for good and synced. */
    public static void choose(ServerPlayer sp, String ruleId) {
        Rule r = RULES.get(ruleId);
        Combat c = Combat.get(sp);
        if (r == null || c == null || !c.hasNenUnlocked()) return;
        NenAddonData d = NenAddonData.get(sp);
        if (d.vows.contains(ruleId)) return;
        if (stakeLocked(ruleId) && !JudgmentChain.hasSelfStake(sp)) {
            sp.displayClientMessage(Component.literal("\u00a7cOnly someone who has chained themselves with the Judgment Chain can swear that"), true);
            return;
        }
        if (!canSwear(c, ruleId)) {
            sp.displayClientMessage(Component.literal("\u00a7cYou need Jajanken at Level " + GonVow.MIN_LEVEL + " to swear that"), true);
            return;
        }
        if (conflicts(ruleId, d.vows)) {
            sp.displayClientMessage(Component.literal("\u00a7cThat cannot be sworn together with a rule you already have"), true);
            return;
        }
        String weaker = weakerPrayer(ruleId);
        boolean replaced = weaker != null && d.vows.remove(weaker); // one prayer restriction at a time: the Vow takes the Condition's place
        d.vows.add(ruleId);
        d.markSync();
        d.save();
        sync(sp);
        if (replaced) {
            Prayer.releaseUnsworn(sp); // the Condition's halved-damage window ends with it
            sp.displayClientMessage(Component.literal("\u00a77The prayer Condition is replaced by the Vow: " + label(r.target()) + " keeps only the stronger rule"), false);
        }
        if (r.enforce() == Enforce.LOCK) applyLock(sp, LOCKS.get(ruleId), d);
        String colour = r.kind() == Kind.VOW ? "\u00a74" : r.kind() == Kind.LIMITATION ? "\u00a76" : "\u00a7e";
        sp.displayClientMessage(Component.literal(colour + r.kind().label + " sworn: \u00a7f" + r.text() + " \u00a77(" + r.boostText() + ")"), false);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 0.8f, r.kind() == Kind.VOW ? 0.6f : 1.0f);
    }

    /** A lockout was just sworn: whatever it forbids is switched off at once and sizes (En radius) are recalculated. */
    private static void applyLock(ServerPlayer sp, Lock l, NenAddonData d) {
        Combat c = Combat.get(sp);
        String k = l.locked();
        if (k != null && c != null) {
            String msg = "\u00a77You swore never to use " + label(k) + " again";
            if (d.vowActive(k, c)) d.vowSwitchOff(sp, k, msg);
            if ("HATSU".equals(k)) { // every Hatsu mode ends with the Hatsu itself
                if (d.emperor) d.setEmperor(sp, false, msg);
                if (LightningAura.isGodspeed(sp)) LightningAura.endGodspeed(sp);
                if (PainPacker.isArmored(sp)) PainPacker.endForZetsu(sp);
                if (d.bookState != 0) SkillHunter.clear(sp);
            }
        }
        d.refreshAfterVowChange(sp);
    }

    public static void sync(ServerPlayer sp) {
        NenAddonData d = NenAddonData.get(sp);
        d.vows.removeIf(id -> !RULES.containsKey(id)); // rules that no longer exist (the retired "I die" Vows) do not linger
        List<String> ids = new ArrayList<>(d.vows);
        if (JudgmentChain.hasSelfStake(sp)) ids.add(STAKE_FLAG);
        AddonNetwork.sendToPlayer(new PacketSyncVows(ids), sp);
    }

    // ---------------------------------------------------------------- enforcement (server)

    public static boolean test(ServerPlayer sp, Pred p) {
        return switch (p) {
            case CROUCH -> sp.isShiftKeyDown();
            case SKY -> sp.level().canSeeSky(sp.blockPosition());
            case DAY -> sp.level().isDay();
            case NIGHT -> !sp.level().isDay();
            case LOW_HP -> sp.getHealth() < sp.getMaxHealth() * 0.7f;
            case HIGH_HP -> sp.getHealth() >= sp.getMaxHealth() * 0.7f;
            case RAIN -> sp.level().isRaining();
            case UNDERGROUND -> !sp.level().canSeeSky(sp.blockPosition());
            case EMPTY_HAND -> sp.getMainHandItem().isEmpty();
            case HOLDING -> !sp.getMainHandItem().isEmpty();
            case NO_ARMOR -> sp.getArmorValue() <= 0;
            case HUNGRY -> sp.getFoodData().getFoodLevel() <= 10;
            case WATER -> sp.isInWater();
            case CRITICAL_HP -> sp.getHealth() < sp.getMaxHealth() * 0.3f;
        };
    }

    private static Pred pred(Rule r) {
        try {
            return Pred.valueOf(r.arg());
        } catch (IllegalArgumentException e) {
            return Pred.CROUCH;
        }
    }

    /** True when a sworn rule on Ten means it has to stay off right now (the automatic Ten checks this before switching it back on). */
    public static boolean tenBlocked(ServerPlayer sp, NenAddonData d) {
        for (String id : d.vows) {
            Rule r = RULES.get(id);
            if (r != null && r.target().equals("TEN") && r.enforce() == Enforce.ONLY_WHEN && !test(sp, pred(r))) return true;
        }
        return false;
    }

    /** Every couple of ticks: the sworn rules on the Nen skills that are switched on right now. */
    public static void tick(ServerPlayer sp, NenAddonData d, Combat c) {
        if (d.vows.isEmpty() || !sp.isAlive()) return;
        skillCooldowns(sp, d, c);
        for (String id : new ArrayList<>(d.vows)) {
            Rule r = RULES.get(id);
            if (r == null || !isSkill(r.target()) || !d.vowActive(r.target(), c)) continue;
            switch (r.enforce()) {
                case ONLY_WHEN -> {
                    if (!test(sp, pred(r))) d.vowSwitchOff(sp, r.target(), "\u00a77" + r.text() + ": " + label(r.target()) + " turned off");
                }
                case EXCLUDES -> {
                    if (d.vowActive(r.arg(), c)) d.vowSwitchOff(sp, r.arg(), "\u00a77" + r.text());
                }
                case BOTH_FORCED -> {
                    if (d.vowActive(r.arg(), c)) forced(sp, r.ticks(), r.text());
                }
                case FORCED_IF -> {
                    if (test(sp, pred(r))) forced(sp, r.ticks(), r.text());
                }
                case DIE_IF -> {
                    if (test(sp, pred(r))) {
                        breakVow(sp, r.text());
                        return;
                    }
                }
                case FORCES -> forceOn(sp, d, c, r.arg());
                default -> { }
            }
        }
    }

    /**
     * A Vow on a skill that is on forces an aura form (REN or KO) on. If it will not come up (no aura left, something seals it), the
     * skill ends instead: the Vow is never a way to keep the skill without paying for it.
     */
    private static void forceOn(ServerPlayer sp, NenAddonData d, Combat c, String key) {
        if (ExtrasHooks.hatsuForced(sp)) return;
        boolean ren = "REN".equals(key);
        if (ren ? c.isAuraActive() : d.ko) return;
        if (c.getCurrentEnergy() >= 5f) {
            if (d.zetsu) d.setZetsu(sp, false, null);
            if (ren) net.hxhadventure.abilities.AbilityRegistry.toggleRen(sp, true);
            else d.enforceKo(sp);
        }
        if (ren ? !c.isAuraActive() : !d.ko) d.vowSwitchOff(sp, "SHU", "\u00a74Vow: \u00a77Shu ends, your aura cannot hold " + label(key));
    }

    private static final Map<Player, Float> ENERGY_BEFORE = new WeakHashMap<>();

    /** Called before any ability runs. Returns true to refuse it (a sworn rule forbids it right now, or a Vow was just broken). */
    public static boolean blocksAbility(ServerPlayer sp, String abilityId) {
        if (JudgmentChain.violatesNoNen(sp, abilityId)) return true; // a Judgment command forbids all Nen: trying is the end
        if (ChainAbilities.JAIL.equals(abilityId) && ChainManager.isJailing(sp)) return false; // pressing it again only releases: always allowed
        // A Hatsu lockout forbids every Hatsu ability (everything except the basic attacks and the Ten / Ren toggles)
        if (!NenAddonData.isBasicAbility(abilityId) && !isAttack(abilityId) && refuseLocked(sp, "HATSU")) return true;
        if (!isBoundAbility(abilityId)) return false;
        NenAddonData d = NenAddonData.peek(sp);
        if (d == null || d.vows.isEmpty()) return false;
        Combat c = Combat.get(sp);
        if (c != null) ENERGY_BEFORE.put(sp, c.getCurrentEnergy());
        boolean attack = isAttack(abilityId);
        for (String id : new ArrayList<>(d.vows)) {
            Rule r = RULES.get(id);
            if (r == null || !(r.target().equals(abilityId) || (!attack && r.target().equals(NenSkill.HATSU.name())))) continue;
            if (r.enforce() == Enforce.ONLY_WHEN && !test(sp, pred(r))) {
                sp.displayClientMessage(Component.literal("\u00a7c" + r.text()), true);
                return true;
            }
            if (r.enforce() == Enforce.DIE_IF && test(sp, pred(r))) {
                breakVow(sp, r.text());
                return true;
            }
            if (r.enforce() == Enforce.COOLDOWN) {
                long left = cooldownLeft(sp, r);
                if (left > 0) {
                    sp.displayClientMessage(Component.literal("\u00a7c" + r.text() + " \u00a77(" + timeLeft(left) + " left)"), true);
                    return true;
                }
            }
        }
        if (Prayer.gate(sp, abilityId, d)) return true;
        payUseCosts(sp, d, abilityId);
        return false;
    }

    // ---- the added rules: cooldowns, tolls and after-effects ----

    private static final String LAST_USE_KEY = "hxh_vow_last_use";

    private static net.minecraft.nbt.CompoundTag lastUseTag(ServerPlayer sp, boolean create) {
        net.minecraft.nbt.CompoundTag pd = sp.getPersistentData();
        net.minecraft.nbt.CompoundTag persisted = pd.getCompound(Player.PERSISTED_NBT_TAG);
        if (!pd.contains(Player.PERSISTED_NBT_TAG)) {
            if (!create) return new net.minecraft.nbt.CompoundTag();
            pd.put(Player.PERSISTED_NBT_TAG, persisted);
        }
        if (!persisted.contains(LAST_USE_KEY)) {
            if (!create) return new net.minecraft.nbt.CompoundTag();
            persisted.put(LAST_USE_KEY, new net.minecraft.nbt.CompoundTag());
        }
        return persisted.getCompound(LAST_USE_KEY);
    }

    /** Game time of the last use of this ability or skill (survives death and logging out), or -1 if never. */
    private static long lastUse(ServerPlayer sp, String key) {
        net.minecraft.nbt.CompoundTag t = lastUseTag(sp, false);
        return t.contains(key) ? t.getLong(key) : -1L;
    }

    private static void markUsed(ServerPlayer sp, String key) {
        net.minecraft.nbt.CompoundTag t = lastUseTag(sp, true);
        t.putLong(key, sp.level().getGameTime());
    }

    /** Ticks still to wait before a cooldown rule allows another use (0 = free to use). */
    private static long cooldownLeft(ServerPlayer sp, Rule r) {
        long last = lastUse(sp, r.target());
        if (last < 0) return 0;
        return Math.max(0L, last + r.ticks() - sp.level().getGameTime());
    }

    private static String timeLeft(long ticks) {
        long min = (ticks + 1199) / 1200;
        if (min >= 60) return (min + 59) / 60 + " h";
        return min + " min";
    }

    private static float healthCost(ServerPlayer sp, Rule r) {
        if ("HALF".equals(r.arg())) return sp.getMaxHealth() * 0.5f;
        try {
            return Float.parseFloat(r.arg());
        } catch (NumberFormatException e) {
            return 4f;
        }
    }

    private static int hungerCost(Rule r) {
        try {
            return Integer.parseInt(r.arg());
        } catch (NumberFormatException e) {
            return 6;
        }
    }

    /** The ability goes ahead: cooldowns start and the health / hunger it was sworn to cost are paid now. */
    private static void payUseCosts(ServerPlayer sp, NenAddonData d, String abilityId) {
        boolean attack = isAttack(abilityId);
        for (String id : d.vows) {
            Rule r = RULES.get(id);
            if (r == null || !(r.target().equals(abilityId) || (!attack && r.target().equals(NenSkill.HATSU.name())))) continue;
            switch (r.enforce()) {
                case COOLDOWN -> markUsed(sp, r.target());
                default -> { }
            }
        }
    }

    private static void applyAfterEffects(ServerPlayer sp, NenAddonData d, String abilityId) {
        boolean attack = isAttack(abilityId);
        for (String id : d.vows) {
            Rule r = RULES.get(id);
            if (r == null || (r.enforce() != Enforce.EFFECT_AFTER && r.enforce() != Enforce.HEALTH_COST && r.enforce() != Enforce.HUNGER_COST)) continue;
            if (!(r.target().equals(abilityId) || (!attack && r.target().equals(NenSkill.HATSU.name())))) continue;
            // The price of a health / hunger rule is paid now, after the ability went out (never while it is being charged), and it can never kill
            if (r.enforce() == Enforce.HEALTH_COST) {
                sp.setHealth(Math.max(1f, sp.getHealth() - healthCost(sp, r)));
                sp.hurtMarked = true;
                sp.displayClientMessage(Component.literal("\u00a74" + r.kind().label + ": \u00a77" + r.text()), true);
                continue;
            }
            if (r.enforce() == Enforce.HUNGER_COST) {
                sp.getFoodData().setFoodLevel(Math.max(0, sp.getFoodData().getFoodLevel() - hungerCost(r)));
                sp.displayClientMessage(Component.literal("\u00a74" + r.kind().label + ": \u00a77" + r.text()), true);
                continue;
            }
            for (String name : r.arg().split(",")) {
                net.minecraft.world.effect.MobEffect e = switch (name.trim()) {
                    case "blindness" -> net.minecraft.world.effect.MobEffects.BLINDNESS;
                    case "slowness" -> net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN;
                    case "weakness" -> net.minecraft.world.effect.MobEffects.WEAKNESS;
                    case "nausea" -> net.minecraft.world.effect.MobEffects.CONFUSION;
                    case "hunger" -> net.minecraft.world.effect.MobEffects.HUNGER;
                    case "fatigue" -> net.minecraft.world.effect.MobEffects.DIG_SLOWDOWN;
                    default -> null;
                };
                if (e != null) sp.addEffect(new net.minecraft.world.effect.MobEffectInstance(e, r.ticks(), name.trim().equals("slowness") ? 1 : 0));
            }
            sp.displayClientMessage(Component.literal("\u00a74" + r.kind().label + ": \u00a77" + r.text()), true);
        }
    }

    /** Skills that were switched on at the last check, so a cooldown rule can tell "just switched on" from "still on". */
    private static final Map<java.util.UUID, Set<String>> SKILL_ON = new java.util.HashMap<>();

    /** Cooldown rules on the Nen skills: a fresh activation inside the cooldown is switched off again, a legal one starts the cooldown. */
    private static void skillCooldowns(ServerPlayer sp, NenAddonData d, Combat c) {
        Set<String> on = SKILL_ON.computeIfAbsent(sp.getUUID(), k -> new java.util.HashSet<>());
        for (String id : new ArrayList<>(d.vows)) {
            Rule r = RULES.get(id);
            if (r == null || r.enforce() != Enforce.COOLDOWN || !isSkill(r.target()) || r.target().equals(NenSkill.HATSU.name())) continue;
            boolean active = d.vowActive(r.target(), c);
            if (!active) {
                on.remove(r.target());
            } else if (on.add(r.target())) {
                long left = cooldownLeft(sp, r);
                if (left > 0) {
                    on.remove(r.target());
                    d.vowSwitchOff(sp, r.target(), "\u00a77" + r.text() + " (" + timeLeft(left) + " left)");
                } else {
                    markUsed(sp, r.target());
                }
            }
        }
    }

    /** Called after an ability ran: "locked in Zetsu afterwards" rules, but only if the ability actually cost aura. */
    public static void afterAbility(ServerPlayer sp, String abilityId) {
        if (!isBoundAbility(abilityId)) return;
        NenAddonData d = NenAddonData.peek(sp);
        Combat c = Combat.get(sp);
        Float before = ENERGY_BEFORE.remove(sp);
        if (d == null || c == null || before == null || d.vows.isEmpty() || c.getCurrentEnergy() >= before) return;
        applyForcedAfter(sp, d, abilityId);
    }

    /** A charge-up's attack went out (its aura was paid on release, not on the press): the "locked in Zetsu afterwards" rules apply now. */
    public static void afterCharge(ServerPlayer sp, String abilityId) {
        NenAddonData d = NenAddonData.peek(sp);
        if (d == null || d.vows.isEmpty()) return;
        applyForcedAfter(sp, d, abilityId);
    }

    private static void applyForcedAfter(ServerPlayer sp, NenAddonData d, String abilityId) {
        applyAfterEffects(sp, d, abilityId);
        for (String id : d.vows) {
            Rule r = RULES.get(id);
            if (r == null || r.enforce() != Enforce.FORCED_AFTER) continue;
            if (r.target().equals(abilityId) || (!isAttack(abilityId) && r.target().equals(NenSkill.HATSU.name()))) forced(sp, r.ticks(), r.text());
        }
    }

    /** When the Forced Zetsu a Vow put on this player ends (game time). Lets Hina lift it together with the Vow. */
    private static final String FORCED_KEY = "HxHCraft_VowForcedUntil";

    /**
     * Hina has just lifted rules: everything those rules had already set going is stopped, so nothing keeps restricting the player.
     * Prayers, movement locks, Ko, "if it misses I die" watches, the Forced Zetsu a Vow caused, and En / Ren sizes.
     */
    public static void afterLift(ServerPlayer sp) {
        NenAddonData d = NenAddonData.get(sp);
        Prayer.releaseUnsworn(sp);

        boolean stillForcing = false;
        for (String id : d.vows) {
            Rule r = RULES.get(id);
            if (r != null && (r.enforce() == Enforce.BOTH_FORCED || r.enforce() == Enforce.FORCED_IF || r.enforce() == Enforce.FORCED_AFTER)) {
                stillForcing = true;
                break;
            }
        }
        net.minecraft.nbt.CompoundTag pd = sp.getPersistentData();
        long until = pd.getLong(FORCED_KEY);
        if (!stillForcing && until > 0) {
            if (until > sp.level().getGameTime()) HatsuEffects.remove(sp);
            pd.remove(FORCED_KEY);
        }
        d.refreshAfterVowChange(sp);
    }

    private static void forced(ServerPlayer sp, int ticks, String why) {
        if (HatsuEffects.has(sp)) return; // already serving it: do not stack or spam
        HatsuEffects.apply(sp, ticks);
        sp.getPersistentData().putLong(FORCED_KEY, sp.level().getGameTime() + ticks);
        sp.displayClientMessage(Component.literal("\u00a74Vow: \u00a77" + why), false);
    }

    /** A Vow was broken: the penalty it named. */
    public static void breakVow(ServerPlayer sp, String why) {
        boolean stake = JudgmentChain.hasSelfStake(sp);
        sp.displayClientMessage(Component.literal("\u00a74Your vow is broken: \u00a77" + why
            + (stake ? "\u00a74. The Stake of Retribution pierces your heart." : "")), false);
        sp.hurt(sp.damageSources().genericKill(), Float.MAX_VALUE);
    }

    /** Is this entity a member of the Phantom Troupe? Give it the scoreboard tag "phantom_troupe" or put it in a team named that. */
    public static boolean isTroupe(Entity e) {
        if (e == null) return false;
        if (e instanceof HisokaEntity || e instanceof ChrolloEntity) return true; // Hisoka and Chrollo are members of the Phantom Troupe
        if (e.getTags().contains("phantom_troupe")) return true;
        if (e.getTeam() != null) {
            String n = e.getTeam().getName().toLowerCase(Locale.ROOT).replace(' ', '_').replace('-', '_');
            return n.contains("phantom_troupe");
        }
        return false;
    }
}
