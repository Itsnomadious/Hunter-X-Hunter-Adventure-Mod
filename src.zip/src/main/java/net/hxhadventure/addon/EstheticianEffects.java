package net.hxhadventure.addon;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/**
 * The two buffs Cookie gives: "Spa Afterglow" (damage and durability) and "Piano Massage" (aura regeneration).
 * The effects only carry the icon and the timer; the numbers are read live by {@link MagicalEsthetician}, so they grow with the Hatsu level.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class EstheticianEffects {
    private EstheticianEffects() {}

    public static MobEffect SPA_AFTERGLOW;
    public static MobEffect PIANO_MASSAGE;

    private static final class Buff extends MobEffect {
        Buff(int colour) {
            super(MobEffectCategory.BENEFICIAL, colour);
        }
    }

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.MOB_EFFECTS, helper -> {
            SPA_AFTERGLOW = new Buff(0xF470A0);
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "spa_afterglow"), SPA_AFTERGLOW);
            PIANO_MASSAGE = new Buff(0xFAFAFA);
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "piano_massage"), PIANO_MASSAGE);
        });
    }

    public static boolean hasSpa(LivingEntity e) {
        return SPA_AFTERGLOW != null && e != null && e.hasEffect(SPA_AFTERGLOW);
    }

    public static boolean hasPiano(LivingEntity e) {
        return PIANO_MASSAGE != null && e != null && e.hasEffect(PIANO_MASSAGE);
    }

    public static void applySpa(LivingEntity e, int ticks) {
        if (SPA_AFTERGLOW != null && e != null) e.addEffect(new MobEffectInstance(SPA_AFTERGLOW, ticks, 0, false, false, true));
    }

    public static void applyPiano(LivingEntity e, int ticks) {
        if (PIANO_MASSAGE != null && e != null) e.addEffect(new MobEffectInstance(PIANO_MASSAGE, ticks, 0, false, false, true));
    }

    public static void removeAll(LivingEntity e) {
        if (e == null) return;
        if (SPA_AFTERGLOW != null) e.removeEffect(SPA_AFTERGLOW);
        if (PIANO_MASSAGE != null) e.removeEffect(PIANO_MASSAGE);
    }
}
