package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.hxhadventure.abilities.Combat;

/**
 * Which Nen type a player is given when their nodes open. Each type has its own chance (Enhancement 27%, Emission 24%,
 * Transmutation 19%, Manipulation 15%, Conjuration 15%, Specialization 0.033%). With the game rule hxhNenTypeChanceEqual
 * on, all six are equally likely instead (1/6 each).
 */
public final class NenTypeRoll {
    private NenTypeRoll() {}

    /** Percent chance of each type, indexed by type id (0 is unused). They are normalised, so they need not add up to exactly 100. */
    private static final double[] PERCENT = new double[7];

    static {
        PERCENT[Combat.NEN_ENHANCEMENT] = 27.0;
        PERCENT[Combat.NEN_EMISSION] = 24.0;
        PERCENT[Combat.NEN_TRANSMUTATION] = 19.0;
        PERCENT[Combat.NEN_MANIPULATION] = 15.0;
        PERCENT[Combat.NEN_CONJURATION] = 15.0;
        PERCENT[Combat.NEN_SPECIALIZATION] = 0.033;
    }

    public static int roll(ServerPlayer sp) {
        boolean equal = sp.getServer() != null && sp.getServer().getGameRules().getBoolean(NenGameRules.EQUAL_TYPE_CHANCE);
        double[] w = new double[7];
        double total = 0;
        for (int t = 1; t <= 6; t++) {
            w[t] = equal ? 1.0 : PERCENT[t];
            total += w[t];
        }
        double r = sp.getRandom().nextDouble() * total;
        for (int t = 1; t <= 6; t++) {
            r -= w[t];
            if (r < 0) return t;
        }
        return Combat.NEN_ENHANCEMENT;
    }
}
