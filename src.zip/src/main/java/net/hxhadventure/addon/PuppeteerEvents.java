package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks for {@link Puppeteer}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PuppeteerEvents {
    private PuppeteerEvents() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) Puppeteer.serverTick(ServerLifecycleHooks.getCurrentServer());
    }

    /** Right-click on an entity with a puppeteer waiting: take control of it. Sneak + right-click on a puppet: release it. */
    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (e.getLevel().isClientSide() || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (Puppeteer.handleRightClick(sp, e.getTarget())) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        Puppeteer.onDeath(e.getEntity());
        if (e.getEntity() instanceof ServerPlayer sp) Puppeteer.onOwnerGone(sp);
    }

    /** Puppets never pick their own user or their fellow puppets as a target. */
    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent e) {
        java.util.UUID owner = Puppeteer.controllerOf(e.getEntity());
        if (owner == null || e.getNewTarget() == null) return;
        Entity t = e.getNewTarget();
        if (owner.equals(t.getUUID()) || owner.equals(Puppeteer.controllerOf(t))) e.setCanceled(true);
    }

    /** No friendly fire between a user, their puppets, and each other. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        Entity victim = e.getEntity();
        Entity attacker = e.getSource().getEntity();
        if (attacker == null) return;
        java.util.UUID vOwner = Puppeteer.controllerOf(victim);
        java.util.UUID aOwner = Puppeteer.controllerOf(attacker);
        if (vOwner != null && (vOwner.equals(attacker.getUUID()) || vOwner.equals(aOwner))) e.setCanceled(true); // owner or sibling hits a puppet
        else if (aOwner != null && aOwner.equals(victim.getUUID())) e.setCanceled(true);                          // a puppet hits its owner
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking e) {
        if (e.getEntity() instanceof ServerPlayer viewer) Puppeteer.sendTo(viewer, e.getTarget());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) Puppeteer.onOwnerGone(sp);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        Puppeteer.reset();
    }
}
