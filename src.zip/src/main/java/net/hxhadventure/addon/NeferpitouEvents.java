package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registers Neferpitou's and Terpsichora's attributes and Neferpitou's spawn egg, and applies Ko's soft body to the damage she takes. */
public final class NeferpitouEvents {
    private NeferpitouEvents() {}

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class PitouModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent e) {
            e.put(HxHEntities.NEFERPITOU.get(), NeferpitouEntity.createAttributes().build());
            e.put(HxHEntities.TERPSICHORA.get(), TerpsichoraEntity.createAttributes().build());
        }

        @SubscribeEvent
        public static void creativeTab(BuildCreativeModeTabContentsEvent e) {
            if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) e.accept(HxHEntities.NEFERPITOU_SPAWN_EGG.get());
        }
    }

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class PitouGame {
        @SubscribeEvent(priority = EventPriority.LOW)
        public static void onHurt(LivingHurtEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide) return;
            DamageSource src = event.getSource();
            if (victim instanceof NeferpitouEntity n) event.setAmount(event.getAmount() * n.incomingMult(src));
        }
    }
}
