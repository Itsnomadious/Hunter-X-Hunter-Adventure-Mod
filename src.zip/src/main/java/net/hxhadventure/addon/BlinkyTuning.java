package net.hxhadventure.addon;

/** Numbers for Shizuku Murasaki's Blinky (Hatsu kit 26, Conjurers). Change them here. */
public final class BlinkyTuning {
    private BlinkyTuning() {}

    // ---- unlocks ----
    /** Hatsu level needed to conjure Blinky (H), swing it and suck blocks up. */
    public static final int MIN_LEVEL = 10;
    /** Hatsu level needed for Exsanguinate. */
    public static final int DRAIN_MIN_LEVEL = 15;

    // ---- conjuring ----
    /** Aura paid to conjure the vacuum cleaner (putting it away is free). */
    public static final float CONJURE_COST = 80f;
    public static final int TOGGLE_COOLDOWN_TICKS = 20;

    // ---- the swing (replaces Attack, Strong attack and Barrage while Blinky is in hand) ----
    /** Base damage of one swing, plus {@link #SWING_DAMAGE_PER_LEVEL} per Hatsu level. */
    public static final float SWING_DAMAGE = 5f;
    public static final float SWING_DAMAGE_PER_LEVEL = 0.12f;
    public static final double SWING_KNOCKBACK = 0.6;
    public static final int SWING_COOLDOWN_TICKS = 12;
    /** How far the head reaches (blocks) and how wide the arc is (half angle, degrees). */
    public static final double SWING_REACH = 3.8;
    public static final double SWING_ARC_DEGREES = 55.0;
    public static final int SWING_MAX_TARGETS = 3;
    /** Strong attack: charge time for the full heavy swing, its damage multiplier at full charge, extra reach and extra targets. */
    public static final int STRONG_CHARGE_TICKS = 40;
    public static final float STRONG_DAMAGE_MULT = 2.4f;
    public static final double STRONG_EXTRA_REACH = 1.0;
    public static final int STRONG_MAX_TARGETS = 6;
    public static final double STRONG_EXTRA_KNOCKBACK = 1.0;
    /** Barrage: quick light swings. */
    public static final int BARRAGE_COOLDOWN_TICKS = 6;
    public static final float BARRAGE_DAMAGE_MULT = 0.55f;

    // ---- suction (hold right-click with Blinky in hand) ----
    /** Blocks are pulled in every this many ticks, up to {@link #SUCK_BLOCKS_PER_PULSE} each time. */
    public static final int SUCK_INTERVAL_TICKS = 4;
    public static final int SUCK_BLOCKS_PER_PULSE = 3;
    public static final double SUCK_RANGE = 6.0;
    /** Half angle of the cone in front of the mouth that is pulled in, degrees. */
    public static final double SUCK_CONE_DEGREES = 30.0;
    /** Aura per block: this plus hardness times the second number (obsidian is 50, stone 1.5, dirt 0.5). */
    public static final float SUCK_BASE_COST = 1.5f;
    public static final float SUCK_COST_PER_HARDNESS = 0.4f;
    /** Hardest block that can be sucked up (bedrock and other unbreakable blocks never can). */
    public static final float SUCK_MAX_HARDNESS = 60f;
    /** Chests, furnaces and the like would lose what is inside them. false = Blinky leaves them alone. */
    public static final boolean SUCK_BLOCK_ENTITIES = false;
    /** Items that fall as a result of a block being sucked up (a torch on it, a flower on it...) are swallowed with it. */
    public static final boolean SWALLOW_DEPENDENT_DROPS = true;

    // ---- Exsanguinate (Z): drains the blood of an enemy the head has bitten ----
    /** How long an enemy stays marked after a swing hit it, ticks (8 s). */
    public static final int MARK_TICKS = 160;
    public static final float DRAIN_COST = 200f;
    public static final int DRAIN_COOLDOWN_TICKS = 200;
    /** The drain lasts this long and bites every {@link #DRAIN_INTERVAL_TICKS}. */
    public static final int DRAIN_TICKS = 60;
    public static final int DRAIN_INTERVAL_TICKS = 6;
    /** Each bite takes this share of the victim's maximum health (blood loss ignores armour) plus the flat amount. */
    public static final float DRAIN_HEALTH_SHARE = 0.04f;
    public static final float DRAIN_FLAT_DAMAGE = 1.0f;
    public static final float DRAIN_DAMAGE_PER_LEVEL = 0.03f;
    /** The head must stay this close (blocks) to the victim, or the drain is torn off. */
    public static final double DRAIN_RANGE = 6.0;
    /** Anaemia: Weakness and Slowness for this long after every bite. */
    public static final int ANAEMIA_TICKS = 100;
    /** The victim is held in place while the head drinks. */
    public static final boolean DRAIN_HOLDS_VICTIM = true;
    /** Undead, constructs and slimes have no blood to take. */
    public static final boolean BLOODLESS_IMMUNE = true;
}
