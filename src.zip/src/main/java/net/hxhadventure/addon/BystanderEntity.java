package net.hxhadventure.addon;

import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * A Bystander: the passer-by Chrollo's Gallery Fake page conjures. As strong as a Minecraft zombie (20 health, 3 damage, the same speed
 * and follow range) and one of five random skins. It always fights whatever its owner Chrollo is fighting, follows him when there is
 * nobody to fight, and fades when he is gone. Chrollo can have {@link ChrolloTuning#MAX_BYSTANDERS} out at a time.
 */
public class BystanderEntity extends PathfinderMob implements GeoEntity {
    public static final int SKINS = 5;

    private static final EntityDataAccessor<Integer> SKIN = SynchedEntityData.defineId(BystanderEntity.class, EntityDataSerializers.INT);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private UUID owner;
    private int orphanTicks;
    private boolean punchOne = true;

    public BystanderEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    /** A Minecraft zombie's numbers. */
    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 20.0)
            .add(Attributes.MOVEMENT_SPEED, 0.23)
            .add(Attributes.ATTACK_DAMAGE, 3.0)
            .add(Attributes.FOLLOW_RANGE, 35.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(SKIN, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.25, false));
        this.goalSelector.addGoal(5, new FollowChrolloGoal(this));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.6));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        // no target goals on purpose: the target is always Chrollo's (see tick())
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    public int skin() {
        return Math.floorMod(this.entityData.get(SKIN), SKINS);
    }

    public void setSkin(int skin) {
        this.entityData.set(SKIN, Math.floorMod(skin, SKINS));
    }

    public void setOwner(ChrolloEntity chrollo) {
        this.owner = chrollo.getUUID();
    }

    private ChrolloEntity owner() {
        if (owner == null || !(level() instanceof ServerLevel sl)) return null;
        return sl.getEntity(owner) instanceof ChrolloEntity c && c.isAlive() ? c : null;
    }

    @Override
    public boolean isAlliedTo(Entity other) {
        return other instanceof ChrolloEntity || other instanceof BystanderEntity || super.isAlliedTo(other);
    }

    /** Hurting a bystander makes Chrollo fight whoever did it. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide && source.getEntity() instanceof LivingEntity attacker) {
            ChrolloEntity o = owner();
            if (o != null) o.provoke(attacker);
        }
        return hit;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        return super.doHurtTarget(target); // the melee goal already swings the arm: drawn with the player model it is a normal punch
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) return;
        boolean run = !getNavigation().isDone() || getTarget() != null; // always sprinting when they go anywhere
        if (isSprinting() != run) setSprinting(run);
        ChrolloEntity o = owner();
        if (o == null) { // Chrollo is gone: they fade
            if (++orphanTicks > 100) fade(sl);
            return;
        }
        orphanTicks = 0;
        if (tickCount % 5 == 0) {
            LivingEntity t = o.getTarget();
            if (t != null && t.isAlive() && t != this && !(t instanceof BystanderEntity)) {
                if (getTarget() != t) setTarget(t);
            } else if (getTarget() != null) {
                setTarget(null);
            }
        }
    }

    /** Disappears in a puff (Chrollo's fight is over, or he is gone). */
    public void fade(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.9, getZ(), 12, 0.3, 0.5, 0.3, 0.02);
        discard();
    }

    // when there is nobody to fight they stay around Chrollo
    private static final class FollowChrolloGoal extends Goal {
        private final BystanderEntity mob;
        private int repath;

        FollowChrolloGoal(BystanderEntity mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            ChrolloEntity o = mob.owner();
            return o != null && mob.getTarget() == null && mob.distanceToSqr(o) > 64.0;
        }

        @Override
        public boolean canContinueToUse() {
            ChrolloEntity o = mob.owner();
            return o != null && mob.getTarget() == null && mob.distanceToSqr(o) > 16.0;
        }

        @Override
        public void tick() {
            ChrolloEntity o = mob.owner();
            if (o != null && --repath <= 0) {
                repath = 10;
                mob.getNavigation().moveTo(o, 1.25);
            }
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement_controller", 1, event -> {
            if (this.isInWater()) {
                return PlayState.STOP;
            } else if (event.isMoving()) {
                event.getController().setAnimationSpeed(this.isSprinting() ? 1.7 : 1.0);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.walk"));
            } else {
                event.getController().setAnimationSpeed(0.5);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.idle"));
            }
        }));
        controllers.add(new AnimationController<>(this, "attack_controller", 1, state -> PlayState.STOP)
            .triggerableAnim("punch1", RawAnimation.begin().thenPlay("punch1"))
            .triggerableAnim("punch2", RawAnimation.begin().thenPlay("punch2")));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
