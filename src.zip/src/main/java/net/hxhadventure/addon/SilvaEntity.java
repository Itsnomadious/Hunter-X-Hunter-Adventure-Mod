package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketOrbFx;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Silva Zoldyck (NPC): Emission, Explosive Orbs. Like the player's Hatsu: he levitates {@link Tuning#ORBS_RISE} blocks up while an orb
 * grows in each hand, then hurls both at what he is looking at; each explodes with the player's blast radius, damage and crater. The orbs
 * hit his enemies (not him). In between he closes in and punches, using Ten / Ren / Ken from {@link NenFighter}.
 */
public class SilvaEntity extends NenFighter {
    public static final NpcStats STATS = new NpcStats("silva", Combat.NEN_EMISSION)
        .levels(100, 97, 99, 97)
        .body(210.0, 0.30, 0.5, 1.0f)
        .melee(1.0f, 2.6)
        .look("dark_blueaura_ten", 0xC9C3B0, 0x1C2447);

    private static final Random RND = new Random();
    /** NPC orbs get negative ids so they never collide with a player's orb ids on the client. */
    private static final AtomicInteger NEXT_ORB_ID = new AtomicInteger(-1);

    private enum Phase { IDLE, CHARGING, FALLING }

    private static final class Orb {
        final int id;
        Vec3 pos;
        final Vec3 vel;
        final float radius;
        int life, age;

        Orb(int id, Vec3 pos, Vec3 vel, float radius, int life) {
            this.id = id;
            this.pos = pos;
            this.vel = vel;
            this.radius = radius;
            this.life = life;
        }
    }

    private Phase phase = Phase.IDLE;
    private int charge, fallTicks;
    private long cooldownUntil;
    private double startX, startY, startZ, fwdX, fwdZ;
    private final List<Orb> orbs = new ArrayList<>();

    public SilvaEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, STATS);
    }

    @Override
    protected boolean hatsuBusy() {
        return phase == Phase.CHARGING;
    }

    @Override
    protected double preferredRange() {
        return 10.0;
    }

    @Override
    protected void onAuraGone() {
        if (phase == Phase.CHARGING) endCharge(Tuning.ORBS_COOLDOWN_TICKS);
    }

    @Override
    protected void onFightEnd() {
        if (phase == Phase.CHARGING) endCharge(Tuning.ORBS_COOLDOWN_TICKS / 2);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        if (!level().isClientSide && level() instanceof ServerLevel sl) { // orbs in the air fade without exploding when he is gone
            for (Orb o : orbs) AddonNetwork.sendToNear(PacketOrbFx.remove(o.id), sl, o.pos, 160);
            orbs.clear();
            if (phase == Phase.CHARGING) AddonNetwork.sendToTrackingAndSelf(PacketOrbFx.end(getId()), this);
        }
        setNoGravity(false);
        super.remove(reason);
    }

    @Override
    protected void tickHatsu(@Nullable LivingEntity target, boolean fighting) {
        if (!(level() instanceof ServerLevel level)) return;
        tickOrbs(level);
        long now = level.getGameTime();

        switch (phase) {
            case FALLING -> { // a soft landing
                fallDistance = 0f;
                if (onGround() || isInWater() || ++fallTicks > 200) phase = Phase.IDLE;
            }
            case CHARGING -> tickCharge(level, target, fighting);
            default -> {
                if (!fighting || target == null || now < cooldownUntil) return;
                double dist = distanceTo(target);
                if (dist < 6.0 || dist > 32.0 || !hasLineOfSight(target) || !canAfford(Tuning.ORBS_COST)) return;
                if (payAura(Tuning.ORBS_COST)) beginCharge(level);
            }
        }
    }

    // =========================================================================================================
    // charging: levitate, the orbs grow in the hands
    // =========================================================================================================

    private void beginCharge(ServerLevel level) {
        phase = Phase.CHARGING;
        charge = 0;
        startX = getX();
        startY = getY();
        startZ = getZ();
        double rad = Math.toRadians(getYRot());
        fwdX = -Math.sin(rad);
        fwdZ = Math.cos(rad);
        setNoGravity(true);
        getNavigation().stop();
        level.playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 1.2f, 0.5f);
        AddonNetwork.sendToTrackingAndSelf(PacketOrbFx.charge(getId(), Tuning.ORBS_CHARGE_TICKS, 0f), this);
    }

    private float fraction() {
        return Math.min(1f, charge / (float) Tuning.ORBS_CHARGE_TICKS);
    }

    private void endCharge(int cooldown) {
        phase = Phase.FALLING;
        fallTicks = 0;
        cooldownUntil = level().getGameTime() + cooldown;
        setNoGravity(false);
        AddonNetwork.sendToTrackingAndSelf(PacketOrbFx.end(getId()), this);
    }

    private void tickCharge(ServerLevel level, @Nullable LivingEntity target, boolean fighting) {
        if (ExtrasHooks.hatsuForced(this) || !canUseNen()) {
            endCharge(Tuning.ORBS_COOLDOWN_TICKS);
            return;
        }
        if (tickCount % 20 == 0) {
            if (!canAfford(Tuning.ORBS_UPKEEP)) {
                endCharge(Tuning.ORBS_COOLDOWN_TICKS);
                return;
            }
            drainAura(Tuning.ORBS_UPKEEP);
        }
        float f = fraction();
        // throw when full; sooner if the target is on top of him or he is being hit hard enough that holding on is a mistake
        boolean tooClose = target != null && distanceTo(target) < 3.0;
        boolean pressed = lastHitAge() < 6 && getHealth() < getMaxHealth() * 0.5f;
        if (target == null || !fighting) {
            endCharge(Tuning.ORBS_COOLDOWN_TICKS / 2);
            return;
        }
        if (f >= 1.0f || (f >= 0.6f && (tooClose || pressed))) {
            if (f < Tuning.ORBS_MIN_THROW) endCharge(Tuning.ORBS_COOLDOWN_TICKS / 2);
            else hurl(level, target, f);
            return;
        }
        // levitate up and a little forward, then hold at that spot
        double vx = Mth.clamp((startX + fwdX * Tuning.ORBS_FORWARD - getX()) * 0.3, -0.35, 0.35);
        double vz = Mth.clamp((startZ + fwdZ * Tuning.ORBS_FORWARD - getZ()) * 0.3, -0.35, 0.35);
        double vy = Mth.clamp((startY + Tuning.ORBS_RISE - getY()) * 0.3, -0.4, 0.4);
        setDeltaMovement(vx, vy, vz);
        fallDistance = 0f;
        getLookControl().setLookAt(target, 60.0f, 60.0f);
        if (charge < Tuning.ORBS_CHARGE_TICKS && ++charge == Tuning.ORBS_CHARGE_TICKS) {
            level.playSound(null, blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 1.5f, 0.6f);
        }
    }

    private void hurl(ServerLevel level, LivingEntity target, float f) {
        Vec3 aim = target.position().add(0, target.getBbHeight() * 0.5, 0);
        float radius = Tuning.ORBS_MAX_RADIUS * ExplosiveOrbs.ease(f);
        AddonNetwork.sendToTrackingAndSelf(PacketOrbFx.end(getId()), this);
        for (int i = 0; i < 2; i++) {
            Vec3 from = ExplosiveOrbs.handCenter(position(), getBbHeight(), yBodyRot, i == 0, radius);
            Vec3 vel = aim.subtract(from).normalize().scale(Tuning.ORBS_SPEED);
            Orb o = new Orb(NEXT_ORB_ID.getAndDecrement(), from, vel, radius, Tuning.ORBS_LIFE_TICKS);
            orbs.add(o);
            AddonNetwork.sendToNear(PacketOrbFx.launch(o.id, from, vel, radius, o.life), level, from, 160);
        }
        phase = Phase.FALLING;
        fallTicks = 0;
        cooldownUntil = level.getGameTime() + Tuning.ORBS_COOLDOWN_TICKS;
        setNoGravity(false);
        swingArm();
        level.playSound(null, blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.HOSTILE, 2.0f, 0.5f);
    }

    // =========================================================================================================
    // orbs in flight (the server moves them as points, clients draw them)
    // =========================================================================================================

    private void tickOrbs(ServerLevel level) {
        if (orbs.isEmpty()) return;
        Iterator<Orb> it = orbs.iterator();
        while (it.hasNext()) {
            Orb o = it.next();
            o.age++;
            Vec3 hit = advance(level, o);
            if (hit != null || --o.life <= 0) {
                it.remove();
                explode(level, o, hit != null ? hit : o.pos);
            }
        }
    }

    @Nullable
    private Vec3 advance(ServerLevel level, Orb o) {
        Vec3 step = o.vel.scale(1.0 / 3.0);
        for (int i = 0; i < 3; i++) {
            Vec3 from = o.pos, to = from.add(step);
            HitResult block = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
            if (block.getType() != HitResult.Type.MISS) return block.getLocation();
            o.pos = to;
            double r = o.radius * 0.6 + 0.3;
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(to, to).inflate(r))) {
                if (e != this && e.isAlive() && !(e instanceof ArmorStand) && !isAlly(e) && e.getType() != getType()
                    && e.getBoundingBox().inflate(o.radius * 0.5).contains(to)) return to;
            }
        }
        return null;
    }

    private void explode(ServerLevel level, Orb o, Vec3 at) {
        float size = Mth.clamp(o.radius / Tuning.ORBS_MAX_RADIUS, 0.05f, 1f);
        float blast = Tuning.ORBS_BLAST_RADIUS * size;
        float base = (Tuning.ORBS_BASE_DAMAGE + stats().hatsu * Tuning.ORBS_DAMAGE_PER_LEVEL) * Affinity.projectile(nenType); // emitters: +15%
        AddonNetwork.sendToNear(PacketOrbFx.boom(o.id, at, blast), level, at, 160);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 6.0f, 0.55f);

        DamageSource src = damageSources().mobAttack(this);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(blast), this::isFoe)) {
            Vec3 mid = e.position().add(0, e.getBbHeight() * 0.5, 0);
            double dist = mid.distanceTo(at);
            if (dist > blast) continue;
            float falloff = (float) (1.0 - 0.75 * dist / blast);
            hatsuHurt(e, src, base * size * falloff);
            Vec3 push = mid.subtract(at).normalize().scale(Tuning.ORBS_KNOCKBACK * size * falloff).add(0, 0.4 * falloff, 0);
            e.push(push.x, push.y, push.z);
            e.hurtMarked = true;
        }
        if (Tuning.ORBS_BREAK_BLOCKS) crater(level, at, blast);
    }

    private static void crater(ServerLevel level, Vec3 at, float radius) {
        int r = (int) Math.ceil(radius);
        BlockPos centre = BlockPos.containing(at);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    double dist = Math.sqrt(x * x + y * y + z * z) * (0.9 + 0.2 * RND.nextDouble());
                    if (dist >= radius) continue;
                    pos.set(centre.getX() + x, centre.getY() + y, centre.getZ() + z);
                    if (!level.isInWorldBounds(pos)) continue;
                    BlockState st = level.getBlockState(pos);
                    if (st.isAir() || !st.getFluidState().isEmpty() || st.getDestroySpeed(level, pos) < 0) continue;
                    float strength = Tuning.ORBS_BLOCK_POWER * (1f - (float) (dist / radius));
                    if (st.getBlock().getExplosionResistance() > strength) continue;
                    if (RND.nextFloat() < 0.04f) net.minecraft.world.level.block.Block.dropResources(st, level, pos);
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
    }
}
