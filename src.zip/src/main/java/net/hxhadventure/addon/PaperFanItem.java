package net.hxhadventure.addon;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * Kalluto's Fan: a white Japanese paper fan. Right-click folds or unfolds it (the state is the "Open" tag on the stack, which the item
 * model reads). Paper Manipulation needs it in a hand to send the paper out; waving it opens it by itself if it is folded.
 */
public class PaperFanItem extends Item {
    public static final String OPEN_TAG = "Open";

    public PaperFanItem(Properties props) {
        super(props);
    }

    public static boolean isOpen(ItemStack stack) {
        return stack != null && stack.getItem() instanceof PaperFanItem && stack.hasTag() && stack.getTag().getBoolean(OPEN_TAG);
    }

    public static void setOpen(ItemStack stack, boolean open) {
        stack.getOrCreateTag().putBoolean(OPEN_TAG, open);
    }

    /** The hand that holds a fan (main hand first), or null. */
    public static @Nullable InteractionHand heldIn(LivingEntity e) {
        if (e.getMainHandItem().getItem() instanceof PaperFanItem) return InteractionHand.MAIN_HAND;
        if (e.getOffhandItem().getItem() instanceof PaperFanItem) return InteractionHand.OFF_HAND;
        return null;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean open = !isOpen(stack);
        setOpen(stack, open);
        if (!level.isClientSide) {
            level.playSound(null, player.blockPosition(), open ? SoundEvents.BOOK_PAGE_TURN : SoundEvents.ARMOR_EQUIP_LEATHER,
                SoundSource.PLAYERS, 0.7f, open ? 1.5f : 1.1f);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** Folding or unfolding must not replay the equip bob: only swapping to a different item does. */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || !oldStack.is(newStack.getItem());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("\u00a77Right-click to fold or unfold"));
        tooltip.add(Component.literal(isOpen(stack) ? "\u00a7fUnfolded" : "\u00a78Folded"));
        tooltip.add(Component.literal("\u00a75Used by Paper Manipulation"));
    }
}
