package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.Tags;
import net.minecraftforge.registries.ForgeRegistries;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketPuppeteerFx;

/**
 * Neferpitou's third Hatsu, Puppeteer (Hatsu kit 10, Specialists).
 *
 * <ol>
 *   <li><b>Conjure:</b> the ability conjures the upper body of a clownish puppeteer that waits beside you.</li>
 *   <li><b>Take control:</b> right-click an undead (or a corpse, see {@link #isValidTarget}) and the puppeteer attaches
 *       to it with puppet strings and hovers behind it from then on. The target follows you, fights what you fight (or
 *       the nearest hostile mob) and will not attack you or your other puppets.</li>
 *   <li><b>End:</b> it lasts until it is dismissed or the target dies. Dismiss a waiting puppeteer by using the ability
 *       again; sneak + right-click a puppet to release that one; sneak + ability releases all of them.</li>
 * </ol>
 * Up to {@link #MAX_PUPPETS} at once (a waiting puppeteer counts). Puppets are tracked by UUID on the server; clients
 * are only told what to draw (PacketPuppeteerFx / PuppeteerFx / PuppeteerRenderer). The Forge event hooks live in
 * {@link PuppeteerEvents} so this feature touches as few existing files as possible.
 */
public final class Puppeteer {
    private Puppeteer() {}

    public static final int KIT = DoctorBlythe.KIT;
    public static final String ID = "puppeteer";

    // ---- tuning ----
    public static final int MIN_LEVEL = 50;
    public static final float CONJURE_COST = 150f;
    public static final int COOLDOWN_TICKS = 40;       // after conjuring or after a puppet is attached
    public static final int MAX_PUPPETS = 10;
    public static final double CONTROL_RANGE = 12.0;   // how far from itself a puppet looks for hostile mobs
    public static final double FOLLOW_DISTANCE = 5.0;  // puppets walk back to you when further than this
    public static final double TELEPORT_DISTANCE = 28.0;

    public static final int OFF = 0, READY = 1, ATTACHED = 2;

    private static final class Owner {
        boolean ready;
        int cooldown;
        final LinkedHashSet<UUID> puppets = new LinkedHashSet<>();
    }

    private static final Map<UUID, Owner> OWNERS = new HashMap<>();      // player uuid -> state
    private static final Map<UUID, UUID> CONTROLLER = new HashMap<>();   // puppet uuid -> owner uuid
    private static final Map<UUID, Integer> IDS = new HashMap<>();       // puppet uuid -> entity id (for packets)
    private static final Map<UUID, Integer> MISSING = new HashMap<>();   // puppet uuid -> ticks it could not be found

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < MIN_LEVEL) return base;
        String[] out = Arrays.copyOf(base, base.length + 1);
        out[base.length] = ID;
        return out;
    }

    public static boolean isPuppet(Entity e) {
        return e != null && CONTROLLER.containsKey(e.getUUID());
    }

    /** The owner's UUID if e is somebody's puppet, else null. */
    public static UUID controllerOf(Entity e) {
        return e == null ? null : CONTROLLER.get(e.getUUID());
    }

    private static int count(Owner o) {
        return o.puppets.size() + (o.ready ? 1 : 0);
    }

    // ---------------- what can be controlled ----------------
    /**
     * Undead mobs (zombies, skeletons, husks, drowned, phantoms, wither skeletons...) except bosses, and "corpses". This
     * mod has no corpse entity of its own, so a corpse is anything whose entity id contains "corpse" (for example the
     * entities added by corpse/death-body mods). Change this one method to widen or narrow it.
     */
    public static boolean isValidTarget(Entity e) {
        if (e == null || e instanceof Player || !e.isAlive()) return false;
        ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        boolean corpseName = key != null && key.getPath().contains("corpse");
        if (e instanceof Mob m) {
            if (m.getType().is(Tags.EntityTypes.BOSSES)) return false;
            return m.getMobType() == MobType.UNDEAD || corpseName;
        }
        if (e instanceof LivingEntity) return false; // armor stands and the like
        return corpseName;
    }

    // ---------------- ability ----------------
    public static void toggle(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Neferpitou's"), true);
            return;
        }
        if (c.getHatsuLevel() < MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cPuppeteer unlocks at Level " + MIN_LEVEL), true);
            return;
        }
        Owner o = OWNERS.computeIfAbsent(sp.getUUID(), k -> new Owner());

        // sneak + ability: let every puppet go
        if (sp.isShiftKeyDown() && (!o.puppets.isEmpty() || o.ready)) {
            int n = o.puppets.size();
            releaseAll(sp);
            sp.displayClientMessage(Component.literal("\u00a77The strings fall slack" + (n > 0 ? " (" + n + " released)" : "")), true);
            return;
        }
        // already waiting: dismiss it
        if (o.ready) {
            o.ready = false;
            send(sp, sp.getId(), OFF);
            playSound(sp, SoundEvents.CHAIN_BREAK, 0.7f, 0.7f);
            sp.displayClientMessage(Component.literal("\u00a77Puppeteer dismissed"), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: the Puppeteer cannot be conjured"), true);
            return;
        }
        if (ChainManager.onCooldown(sp, "Puppeteer", o.cooldown)) return;
        if (count(o) >= MAX_PUPPETS) {
            sp.displayClientMessage(Component.literal("\u00a7cYou cannot work more than " + MAX_PUPPETS + " puppets"), true);
            return;
        }
        if (c.getCurrentEnergy() < CONJURE_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        if (!PitouSkills.clearOthers(sp, PitouSkills.PUPPET)) return;
        c.consumeEnergy(CONJURE_COST);
        o.ready = true;
        o.cooldown = COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, "Puppeteer", COOLDOWN_TICKS);
        send(sp, sp.getId(), READY);
        playSound(sp, SoundEvents.EVOKER_PREPARE_SUMMON, 0.9f, 0.6f);
        sp.displayClientMessage(Component.literal("\u00a7dPuppeteer conjured \u00a77- right-click an undead or a corpse"), true);
    }

    /** Right-click on an entity. Returns true if the click was used (the event should then be cancelled). */
    public static boolean handleRightClick(ServerPlayer sp, Entity target) {
        Owner o = OWNERS.get(sp.getUUID());
        if (o == null || target == null) return false;
        // sneak + right-click on one of your own puppets releases it
        if (sp.isShiftKeyDown() && o.puppets.contains(target.getUUID())) {
            release(sp.server, target.getUUID());
            playSound(sp, SoundEvents.CHAIN_BREAK, 0.7f, 0.9f);
            sp.displayClientMessage(Component.literal("\u00a77Puppet released \u00a78(" + o.puppets.size() + "/" + MAX_PUPPETS + ")"), true);
            return true;
        }
        if (!o.ready) return false;
        if (CONTROLLER.containsKey(target.getUUID())) {
            sp.displayClientMessage(Component.literal("\u00a7cAlready on strings"), true);
            return true;
        }
        if (!isValidTarget(target)) {
            if (target instanceof LivingEntity) sp.displayClientMessage(Component.literal("\u00a7cThe puppeteer only works on the undead and on corpses"), true);
            return false;
        }
        attach(sp, o, target);
        return true;
    }

    private static void attach(ServerPlayer sp, Owner o, Entity target) {
        o.ready = false;
        o.cooldown = COOLDOWN_TICKS;
        o.puppets.add(target.getUUID());
        CONTROLLER.put(target.getUUID(), sp.getUUID());
        IDS.put(target.getUUID(), target.getId());
        MISSING.remove(target.getUUID());
        if (target instanceof Mob m) {
            m.setPersistenceRequired();
            m.setTarget(null);
        }
        send(sp, sp.getId(), OFF);              // the waiting puppeteer leaves your side...
        send(target, target.getId(), ATTACHED); // ...and appears behind the target
        playSound(sp, SoundEvents.WITHER_SPAWN, 0.5f, 1.6f);
        sp.level().playSound(null, target.blockPosition(), SoundEvents.CHAIN_PLACE, SoundSource.HOSTILE, 1.0f, 0.6f);
        sp.displayClientMessage(Component.literal("\u00a7dPuppet taken \u00a78(" + o.puppets.size() + "/" + MAX_PUPPETS + ")"), true);
    }

    // ---------------- ending ----------------
    /** Lets one puppet go (dismissed, or its target died). */
    public static void release(MinecraftServer server, UUID puppet) {
        UUID owner = CONTROLLER.remove(puppet);
        Integer id = IDS.remove(puppet);
        MISSING.remove(puppet);
        if (owner != null) {
            Owner o = OWNERS.get(owner);
            if (o != null) o.puppets.remove(puppet);
        }
        if (server == null) return;
        Entity e = find(server, puppet);
        if (e instanceof Mob m) m.setTarget(null);
        if (id != null) {
            PacketPuppeteerFx off = new PacketPuppeteerFx(id, OFF);
            if (e != null) AddonNetwork.sendToTracking(off, e);
            else for (ServerPlayer p : server.getPlayerList().getPlayers()) AddonNetwork.sendToPlayer(off, p);
        }
    }

    public static void releaseAll(ServerPlayer sp) {
        Owner o = OWNERS.get(sp.getUUID());
        if (o == null) return;
        for (UUID id : new ArrayList<>(o.puppets)) release(sp.server, id);
        if (o.ready) {
            o.ready = false;
            send(sp, sp.getId(), OFF);
        }
    }

    /** The owner died, logged out or lost the Hatsu: everything they controlled is let go. */
    public static void onOwnerGone(ServerPlayer sp) {
        releaseAll(sp);
        OWNERS.remove(sp.getUUID());
    }

    /** Any entity died: if it was a puppet, its puppeteer ends. */
    public static void onDeath(Entity e) {
        if (isPuppet(e)) release(e.getServer(), e.getUUID());
    }

    public static void reset() {
        OWNERS.clear();
        CONTROLLER.clear();
        IDS.clear();
        MISSING.clear();
    }

    // ---------------- per tick ----------------
    public static void serverTick(MinecraftServer server) {
        if (OWNERS.isEmpty()) return;
        boolean think = server.getTickCount() % 10 == 0;
        for (Map.Entry<UUID, Owner> en : new ArrayList<>(OWNERS.entrySet())) {
            Owner o = en.getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null || !sp.isAlive()) {
                if (sp != null) onOwnerGone(sp);
                else {
                    for (UUID id : new ArrayList<>(o.puppets)) release(server, id);
                    OWNERS.remove(en.getKey());
                }
                continue;
            }
            if (o.cooldown > 0) o.cooldown--;
            Combat c = Combat.get(sp);
            if (!canUse(c)) {
                onOwnerGone(sp);
                continue;
            }
            if (!think) continue;
            for (UUID id : new ArrayList<>(o.puppets)) {
                Entity e = find(server, id);
                if (e == null) {
                    // unloaded chunk or another dimension for a while: keep it, but not forever
                    if (MISSING.merge(id, 10, Integer::sum) > 1200) release(server, id);
                    continue;
                }
                MISSING.remove(id);
                if (!e.isAlive()) {
                    release(server, id);
                    continue;
                }
                if (e.level() != sp.level()) continue;
                control(sp, e);
            }
        }
    }

    private static void control(ServerPlayer owner, Entity e) {
        if (e instanceof Mob m) {
            if (m.isOnFire() && !m.isInLava()) m.clearFire(); // the puppeteer keeps its body from burning up in the sun
            LivingEntity tgt = pickTarget(owner, m);
            m.setTarget(tgt);
            if (tgt == null) follow(owner, m);
        } else {
            // a corpse that cannot think: just glide it along behind the owner
            double dx = owner.getX() - e.getX(), dz = owner.getZ() - e.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > FOLLOW_DISTANCE) {
                double step = Math.min(2.5, d - FOLLOW_DISTANCE);
                e.setPos(e.getX() + dx / d * step, e.getY(), e.getZ() + dz / d * step);
            }
        }
    }

    private static void follow(ServerPlayer owner, Mob m) {
        double d = m.distanceTo(owner);
        if (d > TELEPORT_DISTANCE) {
            m.teleportTo(owner.getX() + (m.getRandom().nextDouble() - 0.5) * 3, owner.getY(), owner.getZ() + (m.getRandom().nextDouble() - 0.5) * 3);
            m.getNavigation().stop();
        } else if (d > FOLLOW_DISTANCE) {
            m.getNavigation().moveTo(owner, 1.2);
        } else {
            m.getNavigation().stop();
        }
    }

    private static LivingEntity pickTarget(ServerPlayer owner, Mob m) {
        LivingEntity t = owner.getLastHurtMob();
        if (okTarget(owner, m, t) && owner.tickCount - owner.getLastHurtMobTimestamp() < 200) return t;
        t = owner.getLastHurtByMob();
        if (okTarget(owner, m, t) && owner.tickCount - owner.getLastHurtByMobTimestamp() < 200) return t;
        List<LivingEntity> near = m.level().getEntitiesOfClass(LivingEntity.class, m.getBoundingBox().inflate(CONTROL_RANGE),
            x -> x instanceof Enemy && okTarget(owner, m, x));
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity x : near) {
            double d = x.distanceToSqr(m);
            if (d < bd) {
                bd = d;
                best = x;
            }
        }
        return best;
    }

    private static boolean okTarget(ServerPlayer owner, Mob m, LivingEntity t) {
        if (t == null || !t.isAlive() || t == m || t == owner) return false;
        if (owner.getUUID().equals(controllerOf(t))) return false; // never one of your own puppets
        if (t instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        return m.canAttack(t);
    }

    // ---------------- helpers ----------------
    private static Entity find(MinecraftServer server, UUID id) {
        for (ServerLevel lvl : server.getAllLevels()) {
            Entity e = lvl.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    private static void send(Entity around, int anchor, int mode) {
        AddonNetwork.sendToTrackingAndSelf(new PacketPuppeteerFx(anchor, mode), around);
    }

    /** A player who comes into view of a puppet (or of someone with a waiting puppeteer) sees it straight away. */
    public static void sendTo(ServerPlayer viewer, Entity target) {
        if (target == null) return;
        if (CONTROLLER.containsKey(target.getUUID())) {
            AddonNetwork.sendToPlayer(new PacketPuppeteerFx(target.getId(), ATTACHED), viewer);
        } else if (target instanceof ServerPlayer p) {
            Owner o = OWNERS.get(p.getUUID());
            if (o != null && o.ready) AddonNetwork.sendToPlayer(new PacketPuppeteerFx(p.getId(), READY), viewer);
        }
    }

    private static void playSound(ServerPlayer sp, SoundEvent ev, float vol, float pitch) {
        sp.level().playSound(null, sp.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }
}
