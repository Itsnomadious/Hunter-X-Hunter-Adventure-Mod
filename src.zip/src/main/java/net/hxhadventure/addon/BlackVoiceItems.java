package net.hxhadventure.addon;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/** Registers Shalnark's phone without touching ModItem (same way as the Skill Hunter book). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class BlackVoiceItems {
    private BlackVoiceItems() {}

    public static Item PHONE;
    public static Item NEEDLE;

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.ITEMS, helper -> {
            PHONE = new BlackVoicePhoneItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "shalnark_phone"), PHONE);
            NEEDLE = new Item(new Item.Properties());
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "black_voice_needle"), NEEDLE);
        });
    }

    /** The phone is a crafted item, so it is listed in the creative menu (Tools & Utilities) like Morel's pipe. */
    @SubscribeEvent
    public static void creativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() != CreativeModeTabs.TOOLS_AND_UTILITIES) return;
        if (PHONE != null) e.accept(PHONE);
        if (NEEDLE != null) e.accept(NEEDLE);
    }
}
