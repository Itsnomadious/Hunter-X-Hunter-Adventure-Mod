package net.hxhadventure.addon;

import java.util.List;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.hxhadventure.abilities.Combat;
import org.jetbrains.annotations.Nullable;

/**
 * Knov's Master Key. It belongs to one Hide and Seek user (the "Owner" tag) and does three things:
 * <ul>
 *   <li>Use in the air: select the next of your rooms. Crouch and use: make a new room (as many as your level allows).</li>
 *   <li>Use on a circle: connect that circle to the selected room. On a room's exit circle it shows the room; crouching lets its captives go.</li>
 *   <li>Use on a creature you hold captive with Scream: let it go (it can use the exit again).</li>
 * </ul>
 * The selected room is also where Scream sends what it takes.
 */
public class MasterKeyItem extends Item {
    public static final String OWNER = "Owner";
    public static final String OWNER_NAME = "OwnerName";

    public MasterKeyItem(Properties props) {
        super(props);
    }

    public static ItemStack create(Player owner) {
        ItemStack stack = new ItemStack(HideSeekItems.KEY);
        CompoundTag tag = stack.getOrCreateTag();
        tag.putUUID(OWNER, owner.getUUID());
        tag.putString(OWNER_NAME, owner.getGameProfile().getName());
        return stack;
    }

    public static @Nullable UUID ownerOf(ItemStack stack) {
        return stack != null && stack.getItem() instanceof MasterKeyItem && stack.hasTag() && stack.getTag().hasUUID(OWNER) ? stack.getTag().getUUID(OWNER) : null;
    }

    /** Does this player carry a key that is theirs? */
    public static boolean hasOwnKey(Player p) {
        for (ItemStack s : p.getInventory().items) if (p.getUUID().equals(ownerOf(s))) return true;
        return p.getUUID().equals(ownerOf(p.getOffhandItem()));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp) || sp.getServer() == null) return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        UUID owner = ownerOf(stack);
        if (owner == null) { // a key that was never bound: it becomes the first person's to use it
            CompoundTag tag = stack.getOrCreateTag();
            tag.putUUID(OWNER, sp.getUUID());
            tag.putString(OWNER_NAME, sp.getGameProfile().getName());
            owner = sp.getUUID();
        }
        if (!owner.equals(sp.getUUID())) {
            sp.displayClientMessage(Component.literal("§7This key is not yours"), true);
            return InteractionResultHolder.fail(stack);
        }
        Combat c = Combat.get(sp);
        if (!HideAndSeek.canUse(c)) {
            sp.displayClientMessage(Component.literal("§cYour Hatsu is not Hide and Seek"), true);
            return InteractionResultHolder.fail(stack);
        }
        NenRooms rooms = NenRooms.get(sp.getServer());
        if (sp.isSecondaryUseActive()) {
            NenRooms.Room made = rooms.createRoom(owner, c.getHatsuLevel());
            if (made == null) {
                sp.displayClientMessage(Component.literal("§cYou already have as many rooms as your level allows (" + NenRooms.maxRooms(c.getHatsuLevel()) + ")"), true);
            } else {
                sp.displayClientMessage(Component.literal("§bNew " + rooms.describe(made) + " §7selected"), true);
                level.playSound(null, sp.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 0.7f, 1.4f);
            }
        } else {
            NenRooms.Room next = rooms.cycle(owner);
            if (next == null) {
                sp.displayClientMessage(Component.literal("§7You have no rooms yet. Crouch and use the key to make one"), true);
            } else {
                sp.displayClientMessage(Component.literal("§b" + rooms.describe(next) + " §7selected"), true);
                level.playSound(null, sp.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.6f, 1.6f);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    /** Use on a creature you hold captive: let it go. */
    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer sp) || sp.getServer() == null) return InteractionResult.PASS;
        NenRooms rooms = NenRooms.get(sp.getServer());
        NenRooms.Captive cap = rooms.captiveInfo(target.getUUID());
        if (cap == null) return InteractionResult.PASS;
        if (!cap.owner().equals(sp.getUUID()) || !sp.getUUID().equals(ownerOf(stack))) {
            sp.displayClientMessage(Component.literal("§7This key does not hold them"), true);
            return InteractionResult.CONSUME;
        }
        rooms.release(sp.getServer(), target.getUUID(), false);
        sp.displayClientMessage(Component.literal("§bLet " + target.getName().getString() + " go: they can use the exit now"), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7Use: select your next room. Crouch + use: make a room"));
        tooltip.add(Component.literal("§7Use on a circle: connect it to the selected room (crouch: mark it)"));
        tooltip.add(Component.literal("§7Use on a captive: let them go"));
        if (stack.hasTag() && stack.getTag().contains(OWNER_NAME)) tooltip.add(Component.literal("§8Belongs to " + stack.getTag().getString(OWNER_NAME)));
        tooltip.add(Component.literal("§5Used by Hide and Seek"));
    }
}
