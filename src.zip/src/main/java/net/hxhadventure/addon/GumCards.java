package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketCardFx;
import net.hxhadventure.utils.AllianceUtils;
import org.joml.Vector3f;

/**
 * The Playing Card (an item: 1 paper makes 1 card). It replaces Bungee Gum's old "Cards" move.
 * <ul>
 *   <li>Right click: throws one card straight ahead. 3 base damage, dealt like any other hit the thrower lands, so Ten / Ren / Ken scale it.</li>
 *   <li>In Bungee Gum state (H) the card is gummed to the user's aura: it sticks where it lands (in a block or in the creature it hit) and
 *       <b>Tether Pull</b> (Z) calls every such card back into the inventory.</li>
 *   <li>In Bungee Gum state, <b>Shift + right click</b> throws the card at a tethered target (anything carrying Rubber and Gum): it homes in.</li>
 * </ul>
 * Cards are simulated here and their positions streamed to nearby clients every tick (PacketCardFx), which draw them.
 */
public final class GumCards {
    private GumCards() {}

    /** The old "Cards" move's id. It is no longer in the Z menu; the constant stays because Vow rule ids and the Prayer table still know it. */
    public static final String ID = "gum_cards";

    private static final DustParticleOptions SPARK = new DustParticleOptions(new Vector3f(0.91f, 0.55f, 0.83f), 0.8f);

    private enum Mode { FLY, DART, STUCK, RETURN }

    private static final class Card {
        int id;
        Vec3 pos = Vec3.ZERO;
        Vec3 vel = Vec3.ZERO;
        int age;
        int modeAge;
        Mode mode = Mode.FLY;
        boolean tethered;        // thrown in Bungee Gum state: sticks, and can be called back
        UUID target;             // DART: who it is homing on
        UUID stuckTo;            // STUCK: the creature it is stuck in (null = a block)
        Vec3 stuckOffset = Vec3.ZERO;
    }

    private static final Map<UUID, List<Card>> LIVE = new ConcurrentHashMap<>();
    private static int nextId = 1;
    private static final int MAX_LIVE = 64;

    private static List<Card> cardsOf(UUID id) {
        return LIVE.computeIfAbsent(id, k -> new ArrayList<>());
    }

    // =====================================================================================================
    // throwing (called by PlayingCardItem on the server)
    // =====================================================================================================

    /** Throws one card. Returns false (nothing thrown, nothing used up) if it could not be. */
    public static boolean throwCard(ServerPlayer sp) {
        if (!(sp.level() instanceof ServerLevel level)) return false;
        List<Card> list = cardsOf(sp.getUUID());
        if (list.size() >= MAX_LIVE) return false;
        boolean gumState = BungeeGum.inState(sp);
        LivingEntity target = null;
        if (gumState && sp.isShiftKeyDown()) {
            target = bestTethered(sp);
            if (target == null) sp.displayClientMessage(Component.literal("\u00a77No tethered target: the card goes straight"), true);
        }
        Vec3 look = sp.getLookAngle().normalize();
        Card k = new Card();
        k.id = nextId++;
        k.tethered = gumState;
        k.pos = sp.getEyePosition().add(look.scale(0.9)).add(0, -0.25, 0);
        if (target != null) {
            k.mode = Mode.DART;
            k.target = target.getUUID();
            Vec3 d = BungeeGum.centerOf(target).subtract(k.pos);
            k.vel = d.lengthSqr() < 1.0e-4 ? look.scale(Tuning.PLAYING_CARD_SPEED) : d.normalize().scale(Tuning.PLAYING_CARD_SPEED);
        } else {
            k.vel = look.scale(Tuning.PLAYING_CARD_SPEED);
        }
        list.add(k);
        sp.swing(InteractionHand.MAIN_HAND, true);
        level.playSound(null, sp.blockPosition(), SoundEvents.ARROW_SHOOT, SoundSource.PLAYERS, 0.7f, 1.9f);
        level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.7f, 1.6f);
        return true;
    }

    /** The tethered target the user is looking most nearly towards. */
    private static LivingEntity bestTethered(ServerPlayer sp) {
        List<LivingEntity> list = BungeeGum.tethered(sp);
        Vec3 look = sp.getLookAngle();
        Vec3 eye = sp.getEyePosition();
        LivingEntity best = null;
        double bestDot = -2.0;
        for (LivingEntity e : list) {
            Vec3 to = BungeeGum.centerOf(e).subtract(eye);
            double d = to.length();
            if (d < 1.0e-4) continue;
            double dot = to.scale(1.0 / d).dot(look);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }

    /** Tether Pull: every card thrown in Bungee Gum state flies back to the user. True if there was any (and so the pull is used up on them). */
    public static boolean recall(ServerPlayer sp) {
        List<Card> cards = LIVE.get(sp.getUUID());
        if (cards == null) return false;
        int n = 0;
        for (Card k : cards) {
            if (!k.tethered || k.mode == Mode.RETURN) continue;
            k.mode = Mode.RETURN;
            k.modeAge = 0;
            k.stuckTo = null;
            k.target = null;
            n++;
        }
        if (n == 0) return false;
        if (sp.level() instanceof ServerLevel level) {
            level.playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_STEP, SoundSource.PLAYERS, 1.2f, 1.6f);
            level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0f, 1.8f);
        }
        sp.displayClientMessage(Component.literal("\u00a7dTether Pull: cards recalled (" + n + ")"), true);
        return true;
    }

    // =====================================================================================================
    // per-tick
    // =====================================================================================================

    public static void tick(ServerPlayer sp) {
        UUID id = sp.getUUID();
        List<Card> cards = LIVE.get(id);
        if (cards == null) return;
        if (!sp.isAlive() || !(sp.level() instanceof ServerLevel level)) {
            cards.clear();
        } else {
            Iterator<Card> it = cards.iterator();
            while (it.hasNext()) {
                Card k = it.next();
                k.age++;
                k.modeAge++;
                boolean gone = switch (k.mode) {
                    case FLY -> stepFly(sp, level, k);
                    case DART -> stepDart(sp, level, k);
                    case STUCK -> stepStuck(level, k);
                    case RETURN -> stepReturn(sp, level, k);
                };
                if (gone) it.remove();
            }
        }
        send(sp, cards);
        if (cards.isEmpty()) LIVE.remove(id);
    }

    private static boolean hittable(ServerPlayer sp, Entity t) {
        return t instanceof LivingEntity && t != sp && t.isAlive() && !t.isSpectator() && !(t instanceof ArmorStand)
            && !(t instanceof Player p && p.isCreative()) && !AllianceUtils.isAlly(t, sp);
    }

    /** The card's hit: 3 base damage as a normal hit by the thrower, so Ten / Ren / Ken scale it (see AddonServerEvents.onHurt). */
    private static void hit(ServerPlayer sp, ServerLevel level, LivingEntity victim, Vec3 at, boolean gummed) {
        if (gummed) BungeeGum.cardHit(sp, victim, Tuning.PLAYING_CARD_DAMAGE); // thrown in Bungee Gum state: the same tether a melee hit sticks on
        else victim.hurt(level.damageSources().playerAttack(sp), Tuning.PLAYING_CARD_DAMAGE);
        sparks(level, at);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.ARROW_HIT, SoundSource.PLAYERS, 0.6f, 1.8f);
    }

    private static boolean stick(Card k, Vec3 at, LivingEntity victim) {
        if (!k.tethered) return true; // an ordinary card is used up on impact
        k.mode = Mode.STUCK;
        k.modeAge = 0;
        k.vel = Vec3.ZERO;
        k.pos = at;
        if (victim != null) {
            k.stuckTo = victim.getUUID();
            k.stuckOffset = at.subtract(BungeeGum.centerOf(victim));
        }
        return false;
    }

    private static boolean stepFly(ServerPlayer sp, ServerLevel level, Card k) {
        if (k.age > Tuning.PLAYING_CARD_LIFE) return stick(k, k.pos, null); // fell short: a gummed card hangs where it is
        Vec3 from = k.pos;
        Vec3 to = from.add(k.vel);
        HitResult wall = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        Vec3 end = wall.getType() == HitResult.Type.MISS ? to : wall.getLocation();
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(level, sp, from, end, new AABB(from, end).inflate(0.5), t -> hittable(sp, t));
        if (eh != null && eh.getEntity() instanceof LivingEntity victim) {
            hit(sp, level, victim, eh.getLocation(), k.tethered);
            return stick(k, eh.getLocation(), victim);
        }
        if (wall.getType() == HitResult.Type.BLOCK) {
            sparks(level, wall.getLocation());
            return stick(k, wall.getLocation(), null);
        }
        k.pos = to;
        return false;
    }

    /** Shift + right click in Bungee Gum state: homes in on the tethered target. */
    private static boolean stepDart(ServerPlayer sp, ServerLevel level, Card k) {
        if (k.modeAge > 60) return stick(k, k.pos, null);
        Entity t = k.target == null ? null : level.getEntity(k.target);
        if (!(t instanceof LivingEntity victim) || !victim.isAlive()) {
            k.mode = Mode.FLY; // the target is gone: carries straight on
            k.modeAge = 0;
            return false;
        }
        Vec3 want = BungeeGum.centerOf(victim).subtract(k.pos);
        double dist = want.length();
        if (dist < 0.8 || victim.getBoundingBox().inflate(0.35).contains(k.pos)) {
            hit(sp, level, victim, k.pos, k.tethered);
            return stick(k, k.pos, victim);
        }
        Vec3 desired = want.scale(Tuning.PLAYING_CARD_SPEED / dist);
        k.vel = k.vel.scale(0.55).add(desired.scale(0.45)); // swings round towards it
        k.pos = k.pos.add(k.vel);
        return false;
    }

    /** A gummed card stuck in a block or in a creature, until it is called back or the gum dries. */
    private static boolean stepStuck(ServerLevel level, Card k) {
        if (k.modeAge > Tuning.PLAYING_CARD_STICK_TICKS) return true;
        if (k.stuckTo != null) {
            Entity e = level.getEntity(k.stuckTo);
            if (e == null || !e.isAlive()) { // what it was stuck in is gone: it drops where it was
                k.stuckTo = null;
            } else {
                k.pos = BungeeGum.centerOf(e).add(k.stuckOffset);
            }
        }
        return false;
    }

    private static boolean stepReturn(ServerPlayer sp, ServerLevel level, Card k) {
        Vec3 home = sp.position().add(0, sp.getBbHeight() * 0.7, 0);
        Vec3 want = home.subtract(k.pos);
        double dist = want.length();
        if (dist < 1.3 || k.modeAge > 120) {
            giveBack(sp);
            level.playSound(null, sp.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.4f, 1.6f);
            return true;
        }
        Vec3 desired = want.scale(Tuning.PLAYING_CARD_RETURN_SPEED / dist);
        k.vel = k.vel.scale(0.4).add(desired.scale(0.6));
        k.pos = k.pos.add(k.vel);
        return false;
    }

    private static void giveBack(ServerPlayer sp) {
        ItemStack st = new ItemStack(GumItems.PLAYING_CARD);
        if (!sp.getInventory().add(st)) sp.drop(st, false);
    }

    private static void sparks(ServerLevel level, Vec3 at) {
        level.sendParticles(SPARK, at.x, at.y, at.z, 4, 0.12, 0.12, 0.12, 0.02);
    }

    private static void send(ServerPlayer sp, List<Card> cards) {
        int n = Math.min(cards.size(), 64);
        int[] ids = new int[n];
        float[] d = new float[n * 6];
        for (int i = 0; i < n; i++) {
            Card k = cards.get(i);
            ids[i] = k.id;
            d[i * 6] = (float) k.pos.x;
            d[i * 6 + 1] = (float) k.pos.y;
            d[i * 6 + 2] = (float) k.pos.z;
            d[i * 6 + 3] = (float) k.vel.x;
            d[i * 6 + 4] = (float) k.vel.y;
            d[i * 6 + 5] = (float) k.vel.z;
        }
        AddonNetwork.sendToTrackingAndSelf(new PacketCardFx(sp.getId(), ids, d), sp);
    }

    /** Death / logout / Nen loss: every card goes. */
    public static void clear(Player p) {
        UUID id = p.getUUID();
        if (LIVE.remove(id) != null && p instanceof ServerPlayer sp) {
            AddonNetwork.sendToTrackingAndSelf(new PacketCardFx(sp.getId(), new int[0], new float[0]), sp);
        }
    }
}
