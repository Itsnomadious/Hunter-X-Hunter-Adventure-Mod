package net.hxhadventure.addon;

import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

/** Neferpitou's fighting: pounce from afar, otherwise run the target down and punch once it is in reach. */
final class NeferpitouCombatGoal extends Goal {
    private final NeferpitouEntity npc;
    private int repath;

    NeferpitouCombatGoal(NeferpitouEntity npc) {
        this.npc = npc;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = npc.getTarget();
        return t != null && t.isAlive();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        npc.getNavigation().stop();
    }

    @Override
    public void tick() {
        LivingEntity t = npc.getTarget();
        if (t == null) return;
        if (npc.isPouncing()) { // squatting or in the air: the entity drives itself
            npc.getNavigation().stop();
            return;
        }
        npc.getLookControl().setLookAt(t, 60.0f, 60.0f);
        if (npc.distanceTo(t) > NeferpitouTuning.POUNCE_MIN_DISTANCE && npc.tryPounce(t)) return;
        boolean inReach = npc.inReach(t);
        if (inReach) {
            if (!npc.isAttacking()) npc.getNavigation().stop();
            npc.chooseAttack(t);
        }
        if (!inReach || (npc.isAttacking() && npc.distanceTo(t) > 1.6f)) {
            if (--repath <= 0) {
                repath = 4 + npc.getRandom().nextInt(4);
                npc.getNavigation().moveTo(t, 1.25);
            }
        }
    }
}
