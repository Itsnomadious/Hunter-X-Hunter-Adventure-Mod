package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * The Hunter Exam's second and final test, run by Menchi: a free-for-all. When the player accepts, {@link #TOTAL} test takers (zombie stats, see
 * {@link ExamTakerEntity}) spawn around them and fight each other and the player. Once only {@link #SURVIVORS} of them are left and the player is
 * still alive, Menchi stops the test, congratulates the player and the Hunter licence is granted (see {@link HunterExam#grantLicense}).
 *
 * <p>The player loses the test by dying, logging out, leaving the dimension or wandering off from Menchi; the test takers fade and the player can
 * speak to Menchi again. Battles live only in memory (the test takers are not saved either), so a server restart simply cancels them.
 */
public final class ExamBattle {
    /** How many test takers spawn. */
    public static final int TOTAL = 100;
    /** Menchi stops the test when this many test takers are left (the player is not counted). */
    public static final int SURVIVORS = 30;

    /** How many of the {@link #TOTAL} are Nen users (level 10 in everything). */
    public static final int NEN_USERS = 5;
    /** The test only ends once the player has beaten this many test takers (or none are left). */
    public static final int MIN_KILLS = 3;
    /** Damage multiplier when a contestant hurts another contestant. */
    public static final float CONTESTANT_DAMAGE = 0.5f;

    /** Spawn ring around the player, in blocks. */
    private static final double MIN_RADIUS = 5.0;
    private static final double MAX_RADIUS = 16.0;
    /** Placement tries per test taker. */
    private static final int TRIES = 40;
    /** The test is lost when the player gets further than this from Menchi. */
    private static final double MAX_DISTANCE_SQR = 70.0 * 70.0;

    private static final Map<UUID, Battle> BATTLES = new HashMap<>();

    private static final class Battle {
        final UUID player;
        final ServerLevel level;
        final UUID menchi;
        final Set<UUID> alive = new HashSet<>();
        int kills;

        Battle(UUID player, ServerLevel level, UUID menchi) {
            this.player = player;
            this.level = level;
            this.menchi = menchi;
        }
    }

    private ExamBattle() {}

    public static boolean isActive(UUID player) {
        return BATTLES.containsKey(player);
    }

    /** A test taker died (called by the entity). */
    static void onTakerDown(UUID player, UUID taker) {
        Battle b = BATTLES.get(player);
        if (b != null) b.alive.remove(taker);
    }

    // ------------------------------------------------------------------ start

    /** Menchi starts the test for this player: spawns the test takers. Returns false (with nothing left behind) if there was no room. */
    public static boolean begin(ServerPlayer sp, MenchiEntity menchi) {
        if (!(sp.level() instanceof ServerLevel sl) || BATTLES.containsKey(sp.getUUID())) return false;
        EntityType<ExamTakerEntity> type = HxHEntities.EXAM_TAKER.get();
        EntityType<ExamNenTakerEntity> nenType = HxHEntities.EXAM_NEN_TAKER.get();
        RandomSource rnd = sl.getRandom();
        Battle b = new Battle(sp.getUUID(), sl, menchi.getUUID());

        // every skin is used about the same number of times, in a random order
        List<Integer> skins = new ArrayList<>();
        while (skins.size() < TOTAL) {
            List<Integer> round = new ArrayList<>();
            for (int i = 0; i < ExamTakerEntity.SKINS; i++) round.add(i);
            java.util.Collections.shuffle(round, new java.util.Random(rnd.nextLong()));
            skins.addAll(round);
        }

        List<PathfinderMob> spawned = new ArrayList<>();
        for (int i = 0; i < TOTAL; i++) {
            Vec3 spot = findSpot(sl, sp, rnd, type);
            if (spot == null) continue;
            PathfinderMob t = spawned.size() < NEN_USERS ? nenType.create(sl) : type.create(sl);
            if (t == null) continue;
            t.moveTo(spot.x, spot.y, spot.z, rnd.nextFloat() * 360.0f, 0.0f);
            ExamContestant c = (ExamContestant) t;
            c.setSkin(skins.get(i));
            c.setBattle(sp.getUUID());
            spawned.add(t);
        }
        if (spawned.size() <= SURVIVORS) {
            sayTo(sp, "...There isn't enough room in here for this test. Find somewhere more open and come back to me.");
            return false;
        }
        for (PathfinderMob t : spawned) {
            sl.addFreshEntity(t);
            b.alive.add(t.getUUID());
        }
        BATTLES.put(sp.getUUID(), b);
        sayTo(sp, "Good. Everyone, listen up! Fight! Keep fighting until I say stop!");
        sl.playSound(null, menchi.blockPosition(), SoundEvents.BELL_BLOCK, SoundSource.NEUTRAL, 4.0f, 1.0f);
        return true;
    }

    /** A free spot on the floor around the player, in the same room (nothing solid in between). */
    private static Vec3 findSpot(ServerLevel sl, ServerPlayer sp, RandomSource rnd, EntityType<?> type) {
        Vec3 eye = sp.getEyePosition();
        for (int n = 0; n < TRIES; n++) {
            double ang = rnd.nextDouble() * Math.PI * 2.0;
            double d = MIN_RADIUS + rnd.nextDouble() * (MAX_RADIUS - MIN_RADIUS);
            double x = sp.getX() + Math.cos(ang) * d;
            double z = sp.getZ() + Math.sin(ang) * d;
            int top = sp.getBlockY() + 2;
            for (int y = top; y >= top - 6; y--) {
                BlockPos below = BlockPos.containing(x, y - 1, z);
                BlockPos here = BlockPos.containing(x, y, z);
                if (!sl.getBlockState(below).blocksMotion() || !sl.getFluidState(here).isEmpty()) continue;
                if (!sl.noCollision(type.getAABB(x, y, z))) continue;
                Vec3 spot = new Vec3(x, y, z);
                Vec3 chest = new Vec3(x, y + 1.0, z);
                if (sl.clip(new ClipContext(eye, chest, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp)).getType() != HitResult.Type.MISS) continue;
                return spot;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ running

    public static void serverTick(MinecraftServer server) {
        if (server == null || BATTLES.isEmpty() || server.getTickCount() % 10 != 0) return;
        List<UUID> finished = new ArrayList<>();
        for (Battle b : new ArrayList<>(BATTLES.values())) {
            ServerPlayer sp = server.getPlayerList().getPlayer(b.player);
            Entity m = b.level.getEntity(b.menchi);
            if (sp == null || !sp.isAlive() || sp.level() != b.level || m == null || !m.isAlive() || sp.distanceToSqr(m) > MAX_DISTANCE_SQR) {
                lose(b, sp, sp != null && sp.isAlive() ? "Where do you think you're going?! The test isn't finished. Come back and speak to me if you want another try." : null);
                finished.add(b.player);
                continue;
            }
            int left = b.alive.size();
            if (left == 0 || (left <= SURVIVORS && b.kills >= MIN_KILLS)) {
                win(b, sp);
                finished.add(b.player);
            } else {
                sp.displayClientMessage(Component.literal("Test takers remaining: " + left).withStyle(ChatFormatting.GOLD), true);
            }
        }
        for (UUID id : finished) BATTLES.remove(id);
    }

    private static void win(Battle b, ServerPlayer sp) {
        fadeAll(b);
        sayTo(sp, "That's enough! Stop fighting, all of you!");
        sayTo(sp, "...Hmph. Not bad at all. You're still standing, so you pass. Congratulations!");
        sayTo(sp, "That was the final test. You are a Hunter now. Here is your Hunter card. Don't lose it.");
        HunterExam.grantLicense(sp);
        sp.displayClientMessage(Component.literal("You passed the Hunter Exam!").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), true);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0f, 1.0f);
    }

    /** The player is out (null message = nothing to say, e.g. they died or left). */
    private static void lose(Battle b, ServerPlayer sp, String line) {
        fadeAll(b);
        if (sp != null && line != null) sayTo(sp, line);
    }

    private static void fadeAll(Battle b) {
        for (UUID id : b.alive) {
            if (b.level.getEntity(id) instanceof ExamContestant c) c.fade(b.level);
        }
        b.alive.clear();
    }

    // ------------------------------------------------------------------ events

    /** The player killed a contestant of their own test. */
    public static void onPlayerKill(ServerPlayer sp, UUID battleOwner) {
        Battle b = BATTLES.get(sp.getUUID());
        if (b != null && sp.getUUID().equals(battleOwner)) b.kills++;
    }

    /** The player died: the test is lost and the test takers fade. */
    public static void onPlayerDeath(ServerPlayer sp) {
        Battle b = BATTLES.remove(sp.getUUID());
        if (b == null) return;
        lose(b, sp, "Hmph. Is that all? Pathetic. Come and speak to me again if you want another try.");
    }

    public static void onLogout(ServerPlayer sp) {
        Battle b = BATTLES.remove(sp.getUUID());
        if (b != null) lose(b, null, null);
    }

    public static void reset() {
        BATTLES.clear();
    }

    private static void sayTo(ServerPlayer sp, String text) {
        sp.sendSystemMessage(Component.literal("[Menchi] ").withStyle(ChatFormatting.GOLD).append(Component.literal(text).withStyle(ChatFormatting.WHITE)));
    }
}
