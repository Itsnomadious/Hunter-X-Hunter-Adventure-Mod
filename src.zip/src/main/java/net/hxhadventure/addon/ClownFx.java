package net.hxhadventure.addon;

import com.mojang.logging.LogUtils;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

/**
 * The clown's summon effects, ported from HxH Craft 0.4 (Snebsno): the poof when the clown appears or leaves, the rising sparks while the
 * wheel is landing, and the big burst + sounds when the clown turns into its weapon.
 *
 * HxH Craft uses only vanilla sounds and particles for this (its jar has no sound files). They are ported with the very same constants
 * the original reads (its obfuscated field names, "f_11913_" and so on), looked up once through Forge's {@link ObfuscationReflectionHelper},
 * which understands those names both in the IDE and in a built game. So what you hear and see is exactly the original. The first time each
 * constant is used, the vanilla sound/particle it turned out to be is written to the log ("ClownFx: f_11913_ = minecraft:entity.generic.explode"),
 * so you can replace any line with the readable name (SoundEvents.XXX / ParticleTypes.XXX) whenever you like. If a lookup ever fails, the
 * fallback given next to it is used instead, so nothing can crash.
 */
public final class ClownFx {
    private ClownFx() {}

    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Object MISSING = new Object();
    private static final Map<String, Object> CACHE = new HashMap<>();

    // ---- the original's constants (see the class comment) ----
    /** Poof when the clown appears or leaves. Volume 0.4, pitch 1.8. */
    private static final String SND_POOF = "f_11913_";
    /** The burst when the clown becomes a weapon: three sounds (volume, pitch): 1.5 / 5.0, 0.2 / 0.5, 2.0 / 5.0. */
    private static final String SND_BURST_A = "f_11767_", SND_BURST_B = "f_11668_", SND_BURST_C = "f_11737_";
    /** Particles: A is the main puff, B the accent, RISE the slow sparks over the clown while the wheel lands. */
    private static final String PART_A = "f_123777_", PART_B = "f_123747_", PART_RISE = "f_123762_";

    /** Reads one of the original's constants out of SoundEvents / ParticleTypes by its obfuscated name. Null when it cannot be read. */
    private static Object lookup(Class<?> owner, String name) {
        Object v;
        synchronized (CACHE) {
            v = CACHE.get(name);
            if (v == null) {
                try {
                    Field f = ObfuscationReflectionHelper.findField(owner, name);
                    v = f.get(null);
                } catch (Throwable t) {
                    LOGGER.warn("ClownFx: could not read {}.{}: {}", owner.getSimpleName(), name, t.toString());
                    v = MISSING;
                }
                CACHE.put(name, v);
            }
        }
        return v == MISSING ? null : v;
    }

    private static SoundEvent sound(String name, SoundEvent fallback) {
        Object v = lookup(SoundEvents.class, name);
        SoundEvent s = null;
        if (v instanceof SoundEvent e) s = e;
        else if (v instanceof Holder<?> h && h.value() instanceof SoundEvent e) s = e;
        if (s == null) return fallback;
        logOnce(name, ForgeRegistries.SOUND_EVENTS.getKey(s));
        return s;
    }

    private static SimpleParticleType particle(String name, SimpleParticleType fallback) {
        Object v = lookup(ParticleTypes.class, name);
        if (v instanceof SimpleParticleType p) {
            logOnce(name, ForgeRegistries.PARTICLE_TYPES.getKey(p));
            return p;
        }
        return fallback;
    }

    private static final java.util.Set<String> LOGGED = new java.util.HashSet<>();

    private static void logOnce(String name, Object key) {
        synchronized (LOGGED) {
            if (LOGGED.add(name)) LOGGER.info("ClownFx: {} = {}", name, key);
        }
    }

    // ---- the effects ----

    /** The clown appears or leaves: a pop with a puff of smoke (HxH Craft's spawnPoofEffects). */
    public static void poof(ServerLevel level, double x, double y, double z) {
        level.playSound(null, x, y, z, sound(SND_POOF, SoundEvents.GENERIC_EXPLODE), SoundSource.PLAYERS, 0.4f, 1.8f);
        level.sendParticles(particle(PART_A, ParticleTypes.POOF), x, y, z, 30, 0.25, 0.25, 0.25, 0.15);
        level.sendParticles(particle(PART_B, ParticleTypes.CLOUD), x, y, z, 2, 0, 0, 0, 0);
    }

    /** One spark rising over the clown while the wheel lands (every other tick for the last ten, like the original). */
    public static void rise(ServerLevel level, double x, double y, double z) {
        // count 0: the offsets are the velocity (0, 0.05, 0), exactly like the original's client-side addParticle
        level.sendParticles(particle(PART_RISE, ParticleTypes.ENCHANT), x, y, z, 0, 0, 0.05, 0, 1.0);
    }

    /**
     * The clown turns into its weapon: a ball of 300 + 300 particles, radius 3, around the user, and the three sounds (HxH Craft's
     * transformToScythe / worldSounds). {@code centre} is the user's feet; the ball is 1.2 blocks above them.
     */
    public static void burst(ServerLevel level, Vec3 centre) {
        double cx = centre.x, cy = centre.y + 1.2, cz = centre.z;
        SimpleParticleType a = particle(PART_A, ParticleTypes.POOF);
        SimpleParticleType b = particle(PART_B, ParticleTypes.CLOUD);
        for (int i = 0; i < 300; i++) {
            double u = level.random.nextDouble(), v = level.random.nextDouble();
            double theta = 2 * Math.PI * u;
            double phi = Math.acos(2 * v - 1);
            double px = cx + 3.0 * Math.sin(phi) * Math.cos(theta);
            double py = cy + 3.0 * Math.cos(phi);
            double pz = cz + 3.0 * Math.sin(phi) * Math.sin(theta);
            level.sendParticles(a, px, py, pz, 1, 0, 0, 0, 0.01);
            level.sendParticles(b, px, py, pz, 1, 0, 0, 0, 0.1);
        }
        level.playSound(null, cx, cy, cz, sound(SND_BURST_A, SoundEvents.ENDER_DRAGON_GROWL), SoundSource.PLAYERS, 1.5f, 5.0f);
        level.playSound(null, cx, cy, cz, sound(SND_BURST_B, SoundEvents.GENERIC_EXPLODE), SoundSource.PLAYERS, 0.2f, 0.5f);
        level.playSound(null, cx, cy, cz, sound(SND_BURST_C, SoundEvents.LIGHTNING_BOLT_THUNDER), SoundSource.PLAYERS, 2.0f, 5.0f);
    }
}
