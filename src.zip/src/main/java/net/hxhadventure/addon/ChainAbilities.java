package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.server.level.ServerPlayer;
import net.hxhadventure.abilities.Combat;

/** Glue between the chains and the mod's existing ability cycle (R) / use (Z) system. */
public final class ChainAbilities {
    private ChainAbilities() {}

    public static final String SWEEP = "chain_sweep";
    public static final String HOLY = "holy_chain";
    public static final String JAIL = "chain_jail";
    public static final String EMPEROR = "emperor_time";

    /** Call once from AbilityRegistry's static block. */
    public static void registerAll(Map<String, Consumer<ServerPlayer>> abilities) {
        abilities.put(SWEEP, ChainManager::sweep);
        abilities.put(HOLY, ChainManager::holyChain);
        abilities.put(JAIL, ChainManager::chainJail);
        abilities.put(EMPEROR, ChainManager::emperorTime);
        abilities.put(JudgmentChain.ID, JudgmentChain::use);
        abilities.put(DoctorBlythe.ID, DoctorBlythe::toggle);
        abilities.put(Puppeteer.ID, Puppeteer::toggle);
        abilities.put(Jajanken.ROCK_ID, Jajanken::rock);
        abilities.put(Jajanken.SCISSORS_ID, Jajanken::scissors);
        abilities.put(Jajanken.PAPER_ID, Jajanken::paper);
        abilities.put(GonVow.ID, GonVow::toggle);
        abilities.put(ExplosiveOrbs.ID, ExplosiveOrbs::toggle);
        abilities.put(AuraBlast.ID, AuraBlast::fire);
        abilities.put(DragonHead.ID, DragonHead::begin);
        abilities.put(DragonHead.DIVE_ID, DragonHead::dive);
        abilities.put(BungeeGum.ID, BungeeGum::use);
        abilities.put(BungeeGum.PULL_ID, BungeeGum::pull);
        BungeeBarrier.registerAll(abilities);
        BungeeBind.registerAll(abilities);
        abilities.put(LightningAura.PALM_ID, LightningAura::palm);
        abilities.put(LightningAura.BOLT_ID, LightningAura::thunderbolt);
        HideAndSeek.registerAll(abilities);
        IllumiNeedles.registerAll(abilities);
        PaperManipulation.registerAll(abilities);
        Hakoware.registerAll(abilities);
        SkillHunter.registerAll(abilities);
        Guanyin.registerAll(abilities);
        PainPacker.registerAll(abilities);
        MagicalEsthetician.registerAll(abilities);
        RipperCyclotron.registerAll(abilities);
        BigBangImpact.registerAll(abilities);
        NenStitches.registerAll(abilities);
        Blinky.registerAll(abilities);
        SmokeManipulation.registerAll(abilities);
        CrazySlots.registerAll(abilities);
        LittleFlower.registerAll(abilities);
        BlackVoice.registerAll(abilities);
    }

    /** Returns the base ability list plus whichever chain abilities this player has unlocked. */
    public static String[] extend(String[] base, Combat c) {
        String[] withChains = Guanyin.extend(LightningAura.extend(IllumiNeedles.extend(Jajanken.extend(BungeeGum.extend(DragonHead.extend(AuraBlast.extend(ExplosiveOrbs.extend(Puppeteer.extend(Terpsichora.extend(DoctorBlythe.extend(chainExtend(base, c), c), c), c), c), c), c), c), c), c), c), c);
        withChains = PaperManipulation.extend(withChains, c);
        withChains = Hakoware.extend(withChains, c);
        withChains = HideAndSeek.extend(withChains, c);
        withChains = MagicalEsthetician.extend(withChains, c);
        withChains = PainPacker.extend(withChains, c);
        withChains = RipperCyclotron.extend(withChains, c);
        withChains = BigBangImpact.extend(withChains, c);
        withChains = NenStitches.extend(withChains, c);
        withChains = Blinky.extend(withChains, c);
        withChains = SmokeManipulation.extend(withChains, c);
        withChains = CrazySlots.extend(withChains, c);
        withChains = LittleFlower.extend(withChains, c);
        withChains = BlackVoice.extend(withChains, c);
        if (c != null && (c.getCurrentKit() == SkillHunter.KIT || ClientAddonState.hostKit)) {
            return SkillHunter.extend(withChains, c, ClientAddonState.bookState, ClientAddonState.bookmark,
                ClientAddonState.stolenMask, ClientAddonState.bookHeld);
        }
        return withChains;
    }

    private static String[] chainExtend(String[] base, Combat c) {
        if (c == null || !ChainManager.canUseChains(c)) return base;
        List<String> list = new ArrayList<>(List.of(base));
        int lvl = c.getHatsuLevel();
        if (lvl >= ChainManager.SWEEP_MIN_LEVEL) list.add(SWEEP);
        if (lvl >= ChainManager.HOLY_MIN_LEVEL) list.add(HOLY);
        if (lvl >= ChainManager.JAIL_MIN_LEVEL) list.add(JAIL);
        if (lvl >= JudgmentChain.MIN_LEVEL) list.add(JudgmentChain.ID);
        return list.toArray(new String[0]);
    }

    /** HUD name for the menu, or null if the id is not a chain ability. */
    public static String displayName(String id) {
        String sh = SkillHunter.displayName(id);
        if (sh != null) return sh; // Skill Hunter keeps its "Skill Hunter: " prefix
        String raw = rawDisplayName(id);
        // every other ability is shown by its own name only ("Judgment Chain", not "Chains: Judgment Chain")
        return raw == null ? null : raw.replaceFirst("^((?:\u00a7.)?)\\s*[A-Za-z' ]+:\\s+", "$1 ");
    }

    private static String rawDisplayName(String id) {
        String sh = SkillHunter.displayName(id);
        if (sh != null) return sh;
        String hs = HideAndSeek.displayName(id);
        if (hs != null) return hs;
        String gy = Guanyin.displayName(id);
        if (gy != null) return gy;
        String me = MagicalEsthetician.displayName(id);
        if (me != null) return me;
        String pp = PainPacker.displayName(id);
        if (pp != null) return pp;
        String rc = RipperCyclotron.displayName(id);
        if (rc != null) return rc;
        String bb = BigBangImpact.displayName(id);
        if (bb != null) return bb;
        String bl = Blinky.displayName(id);
        if (bl != null) return bl;
        String ns = NenStitches.displayName(id);
        if (ns != null) return ns;
        String sm = SmokeManipulation.displayName(id);
        if (sm != null) return sm;
        String cs = CrazySlots.displayName(id);
        if (cs != null) return cs;
        String bv = BlackVoice.displayName(id);
        if (bv != null) return bv;
        String lf = LittleFlower.displayName(id);
        if (lf != null) return lf;
        return switch (id) {
            case SWEEP -> "\u00a76 Dowsing Chain";
            case HOLY -> "\u00a76 Chains: Holy Chain";
            case JAIL -> "\u00a76 Chains: Chain Jail";
            case EMPEROR -> "\u00a74 Emperor Time";
            case JudgmentChain.ID -> "\u00a74 Chains: Judgment Chain";
            case DoctorBlythe.ID -> "\u00a7d Doctor Blythe";
            case Puppeteer.ID -> "\u00a7a Puppeteer";
            case Jajanken.ROCK_ID -> "\u00a76 Jajanken: Rock";
            case Jajanken.SCISSORS_ID -> "\u00a76 Jajanken: Scissors";
            case Jajanken.PAPER_ID -> "\u00a76 Jajanken: Paper";
            case GonVow.ID -> "\u00a7c I'll use everything.";
            case ExplosiveOrbs.ID -> "\u00a75 Explosive Orbs";
            case AuraBlast.ID -> "\u00a7f Aura Blast";
            case DragonHead.ID -> "\u00a76 Dragon Head";
            case DragonHead.DIVE_ID -> "\u00a76 Dragon Dive";
            case BungeeGum.ID -> "\u00a7d Bungee Gum";
            case BungeeGum.PULL_ID -> "\u00a7d Tether Pull";
            case BungeeBarrier.ID -> "\u00a7d Bungee Barrier";
            case BungeeBind.ID -> "\u00a7d Bungee Bind";
            case LightningAura.PALM_ID -> "\u00a7b Lightning Palm";
            case LightningAura.BOLT_ID -> "\u00a7b Thunderbolt";
            case IllumiNeedles.BODY_ID -> "\u00a75 Needles: Body Alteration";
            case IllumiNeedles.CORPSE_ID -> "\u00a75 Needles: Corpse Control";
            case IllumiNeedles.PEOPLE_ID -> "\u00a75 Needles: Needle People";
            case Hakoware.ID -> "\u00a76 Hakoware";
            case PaperManipulation.SERPENT_ID -> "\u00a7f Paper: Dance of the Serpent's Bite";
            default -> null;
        };
    }
}
