package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketBookFx;
import net.hxhadventure.addon.network.PacketDisguise;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Chrollo's Skill Hunter (Hatsu kit 9, Specialists).
 * The book must be open to use a stolen page. Bookmarking the page you are on (Double Face) lets it stay active with
 * the book closed, so a bookmarked page and the open page can run together. Page effects that need to be "held"
 * (Black Voice, which is Shalnark's Black Voice run through the page, Order Stamp, Convert Hands) end when their page is no longer active; Gallery Fake copies and
 * Sun/Moon marks persist on their own (Sun/Moon is a post-mortem ability).
 */
public final class SkillHunter {
    private SkillHunter() {}

    public static final int KIT = 9;
    public static final String BOOK_ID = "sh_book";
    public static final String BOOKMARK_ID = "sh_bookmark";
    public static final int BOOK_MIN_LEVEL = 10;
    public static final int BOOKMARK_MIN_LEVEL = 25;
    public static final String ASK_ID = "sh_ask";
    private static final float ASK_COST = 50f;
    private static final int ASK_TICKS = 20 * 30;   // how long a question can be answered
    private static final int SEEN_TICKS = 20 * 60;  // how long after answering the target can touch the book

    public enum Page {
        GALLERY_FAKE("Gallery Fake", 15, "sh_gallery_fake"),
        BLACK_VOICE("Black Voice", 20, "sh_black_voice"),
        ORDER_STAMP("Order Stamp", 25, "sh_order_stamp"),
        SUN_MOON("The Sun and Moon", 30, "sh_sun_moon"),
        CONVERT_HANDS("Convert Hands", 35, "sh_convert_hands"),
        // Hatsu stolen from other players: using the page borrows that kit
        STOLEN_CHAIN("Stolen: Chains", 10, "sh_kit_8", 8);

        public final String label;
        public final int minLevel;
        public final String id;
        public final int kit; // 0 = a native page, otherwise the kit this page borrows

        Page(String label, int minLevel, String id) {
            this(label, minLevel, id, 0);
        }

        Page(String label, int minLevel, String id, int kit) {
            this.label = label;
            this.minLevel = minLevel;
            this.id = id;
            this.kit = kit;
        }

        public static Page ofKit(int kit) {
            for (Page p : values()) if (p.kit == kit) return p;
            return null;
        }

        public static Page byId(String id) {
            for (Page p : values()) if (p.id.equals(id)) return p;
            return null;
        }
    }

    // ---- tuning ----
    private static final float BOOK_COST = 200f, BOOK_UPKEEP = 5f, BOOKMARK_UPKEEP = 10f;
    private static final float FAKE_COST = 125f, STAMP_COST = 75f, MARK_COST = 100f, CONVERT_COST = 250f;
    private static final int PUPPET_TICKS = 20 * 60;
    private static final int FAKE_TICKS = 20 * 60;
    private static final int MARK_TICKS = 20 * 120;
    private static final int DISGUISE_TICKS = 20 * 60;
    private static final int MAX_MARKS = 8;
    /** Explosion power with no charge (the original, uncharged Sun/Moon blast). */
    private static final float EXPLOSION_POWER = 3.5f;
    /** Explosion power once fully charged. Size and damage both scale with power. */
    private static final float MAX_EXPLOSION_POWER = 9.0f;
    /** Charge builds one step per second while Z is held on the mark, and stops at this many seconds. */
    private static final int MAX_CHARGE_SECONDS = 5;
    /** Ticks after placing a mark in which a not-yet-arrived "Z held" packet is forgiven. */
    private static final int HOLD_GRACE_TICKS = 6;
    /** How far the user can be from the mark's target and still count as touching it. */
    private static final double CONTACT_RANGE = 8.0;
    /** Guaranteed self-damage at full charge (scaled by charge) in case the user was outside the blast radius. */
    private static final float MAX_SELF_DAMAGE = 12.0f;
    /** Extra flat damage (HP) dealt to every creature in the blast, per charge step, on top of the explosion itself. */
    private static final float BONUS_DAMAGE_PER_CHARGE = 4.0f;
    /** true = explosions break blocks (and drop them like TNT) as well as hurting creatures. */
    private static final boolean MARKS_BREAK_BLOCKS = true;
    private static final String FAKE_TAG = "hxh_gallery_fake";

    // ---- state ----
    private static final class Puppet {
        final UUID id;
        final Page page;
        final long expiry;

        Puppet(UUID id, Page page, long expiry) {
            this.id = id;
            this.page = page;
            this.expiry = expiry;
        }
    }

    private static final class Disguise {
        final int displayed, as;
        final long expiry;

        Disguise(int displayed, int as, long expiry) {
            this.displayed = displayed;
            this.as = as;
            this.expiry = expiry;
        }
    }

    private static final class State {
        final List<Puppet> puppets = new ArrayList<>();
        final List<Disguise> disguises = new ArrayList<>();
        boolean nextSun = true;
        final Map<UUID, Long> asked = new java.util.HashMap<>();
        final Map<UUID, Seen> seen = new java.util.HashMap<>();
        int lostTicks;
        int lastFx = -1;
        int lastPage = -2;
        int lastMark = -2;
    }

    private static final class Seen {
        final int kit;
        final long expiry;

        Seen(int kit, long expiry) {
            this.kit = kit;
            this.expiry = expiry;
        }
    }

    private static final class Mark {
        boolean sun;
        UUID owner, entity;
        ResourceKey<Level> dim;
        Vec3 fixed;
        long expiry;
        long placed; // game time the mark was placed
        int chargeTicks; // ticks of held, in-contact charge so far
        boolean charging = true; // false once Z is released or contact is lost: the charge is then locked
    }

    private static final class EntityFake {
        UUID id, owner;
        ResourceKey<Level> dim;
        long expiry;
    }

    private static final class BlockFake {
        ResourceKey<Level> dim;
        BlockPos pos;
        BlockState state;
        long expiry;
    }

    private static final Map<Player, State> STATES = new WeakHashMap<>();
    /** puppet UUID -> controlling player UUID */
    private static final Map<UUID, UUID> CONTROLLED = new ConcurrentHashMap<>();
    private static final List<Mark> MARKS = new ArrayList<>();
    /** player UUID -> is the Z key currently held (reported by the client). */
    private static final Map<UUID, Boolean> Z_HELD = new ConcurrentHashMap<>();
    private static final List<EntityFake> ENTITY_FAKES = new ArrayList<>();
    private static final List<BlockFake> BLOCK_FAKES = new ArrayList<>();

    private static State st(Player p) {
        return STATES.computeIfAbsent(p, k -> new State());
    }

    public static UUID controllerOf(UUID entity) {
        return CONTROLLED.get(entity);
    }

    public static boolean isFake(Entity e) {
        return e.getPersistentData().getBoolean(FAKE_TAG);
    }

    // ================= menu glue =================
    /** Client-side: which entries appear in the R/Z menu. */
    public static String[] extend(String[] base, Combat c, int bookState, int bookmark, int stolenMask, boolean held) {
        if (c == null) return base;
        List<String> list = new ArrayList<>(List.of(base));
        int lvl = c.getHatsuLevel();
        // no Book entry: the Hatsu key conjures/opens/closes it, and nothing of his shows in the menu until then
        if (!held) return list.toArray(new String[0]);
        if (bookState == 2 && lvl >= BOOK_MIN_LEVEL) list.add(ASK_ID);
        for (Page p : Page.values()) {
            if (p.kit > 0 && (stolenMask & (1 << p.kit)) == 0) continue;
            boolean usable = bookState == 2 || (bookState != 0 && bookmark == p.ordinal());
            if (lvl >= p.minLevel && usable) list.add(p.id);
        }
        if (bookState != 0 && lvl >= BOOKMARK_MIN_LEVEL) list.add(BOOKMARK_ID);
        return list.toArray(new String[0]);
    }

    public static String displayName(String id) {
        if (BOOK_ID.equals(id)) return "\u00a75 Skill Hunter: Book";
        if (BOOKMARK_ID.equals(id)) return "\u00a75 Double Face: Bookmark";
        if (ASK_ID.equals(id)) return "\u00a75 Skill Hunter: Ask";
        Page p = Page.byId(id);
        return p != null ? "\u00a75 Page: " + p.label : null;
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(BOOK_ID, SkillHunter::toggleBook);
        m.put(BOOKMARK_ID, SkillHunter::bookmark);
        m.put(ASK_ID, SkillHunter::ask);
        for (Page p : Page.values()) m.put(p.id, sp -> usePage(sp, p));
    }

    // ================= helpers =================
    private static boolean ready(ServerPlayer sp, Combat c, int minLevel, String what) {
        if (c == null || !isHunter(sp, c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Skill Hunter"), true);
            return false;
        }
        if (c.getHatsuLevel() < minLevel) {
            sp.displayClientMessage(Component.literal("\u00a7c" + what + " unlocks at Level " + minLevel), true);
            return false;
        }
        return !ChainManager.isJailed(sp);
    }

    private static boolean pay(ServerPlayer sp, Combat c, float cost) {
        if (c.getCurrentEnergy() < cost) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return false;
        }
        c.consumeEnergy(cost);
        return true;
    }

    private static void say(ServerPlayer sp, String msg) {
        sp.displayClientMessage(Component.literal(msg), true);
    }

    private static void sound(ServerPlayer sp, SoundEvent ev, float vol, float pitch) {
        sp.level().playSound(null, sp.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }

    private static void setBook(ServerPlayer sp, NenAddonData d, int state) {
        d.bookState = state;
        if (state == 0) {
            if (d.stolenKit > 0) restoreKit(sp, Combat.get(sp), d);
            d.bookmark = -1;
            d.activePage = -1;
            d.bookHeld = false;
            removeBooks(sp);
        }
        d.markSync();
        syncFx(sp, d);
    }

    /** Is this hunter's Black Voice page running right now (open page or bookmarked, book in hand)? Black Voice itself then works for them. */
    public static boolean blackVoicePageActive(Player p, Combat c) {
        if (c == null || !isHunter(p, c) || c.getHatsuLevel() < Page.BLACK_VOICE.minLevel) return false;
        NenAddonData d = NenAddonData.peek(p);
        return d != null && pageActive(d, Page.BLACK_VOICE);
    }

    private static boolean pageActive(NenAddonData d, Page p) {
        if (!d.bookHeld) return false;
        return (d.bookState == 2 && d.activePage == p.ordinal()) || (d.bookState != 0 && d.bookmark == p.ordinal());
    }

    public static boolean isHunter(Player p, Combat c) {
        if (c.getCurrentKit() == KIT) return true;
        NenAddonData d = NenAddonData.peek(p);
        return d != null && d.hostKit;
    }

    // ================= book / bookmark =================
    public static void toggleBook(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (!ready(sp, c, BOOK_MIN_LEVEL, "Skill Hunter")) return;
        NenAddonData d = NenAddonData.get(sp);
        switch (d.bookState) {
            case 0 -> {
                if (!pay(sp, c, BOOK_COST)) return;
                giveBook(sp);
                d.bookHeld = true;
                setBook(sp, d, 2);
                say(sp, "\u00a75Skill Hunter: book opened");
                sound(sp, SoundEvents.BOOK_PAGE_TURN, 1.0f, 0.8f);
            }
            case 2 -> {
                setBook(sp, d, d.bookmark >= 0 ? 1 : 0);
                say(sp, d.bookmark >= 0 ? "\u00a75Book closed - bookmarked page stays active" : "\u00a77Book closed");
                sound(sp, SoundEvents.BOOK_PUT, 1.0f, 1.0f);
            }
            default -> {
                if (!d.bookHeld) {
                    say(sp, "\u00a7cYou are not holding your book");
                    return;
                }
                setBook(sp, d, 2);
                say(sp, "\u00a75Skill Hunter: book opened");
                sound(sp, SoundEvents.BOOK_PAGE_TURN, 1.0f, 0.8f);
            }
        }
    }

    public static void bookmark(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (!ready(sp, c, BOOKMARK_MIN_LEVEL, "Double Face")) return;
        NenAddonData d = NenAddonData.get(sp);
        if (d.bookState == 0) {
            say(sp, "\u00a7cConjure the book first");
        } else if (d.bookState == 1) { // closed with a bookmark: remove it and put the book away
            setBook(sp, d, 0);
            say(sp, "\u00a77Bookmark removed");
        } else if (d.activePage < 0) {
            say(sp, "\u00a7cUse a page first, then bookmark it");
        } else if (d.bookmark == d.activePage) {
            d.bookmark = -1;
            d.markSync();
            say(sp, "\u00a77Bookmark removed");
        } else {
            d.bookmark = d.activePage;
            d.markSync();
            say(sp, "\u00a75Double Face: " + Page.values()[d.bookmark].label + " bookmarked");
            sound(sp, SoundEvents.BOOK_PAGE_TURN, 1.0f, 1.4f);
        }
    }

    public static void usePage(ServerPlayer sp, Page p) {
        Combat c = Combat.get(sp);
        if (!ready(sp, c, Math.max(BOOK_MIN_LEVEL, p.minLevel), p.label)) return;
        NenAddonData d = NenAddonData.get(sp);
        if (!d.bookHeld) {
            say(sp, "\u00a7cYou are not holding your book");
            return;
        }
        boolean viaBookmark = d.bookState != 0 && d.bookmark == p.ordinal();
        if (d.bookState != 2 && !viaBookmark) {
            say(sp, "\u00a7cThe book must be open to use another page");
            return;
        }
        if (d.bookState == 2 && d.activePage != p.ordinal()) {
            d.activePage = p.ordinal();
            d.markSync();
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        if (p.kit > 0) {
            activateStolen(sp, c, d, p);
            return;
        }
        switch (p) {
            case GALLERY_FAKE -> galleryFake(sp, c, level);
            case BLACK_VOICE -> blackVoice(sp, c, level);
            case ORDER_STAMP -> orderStamp(sp, c, level);
            case SUN_MOON -> placeMark(sp, c, level);
            case CONVERT_HANDS -> convertHands(sp, c, level);
            default -> { }
        }
    }

    // ================= Black Voice =================
    /** Black Voice is now Shalnark's: the same antennas and body swap (see {@link BlackVoice}). Z on the page plants one, Shift+Z takes the body. */
    private static void blackVoice(ServerPlayer sp, Combat c, ServerLevel level) {
        BlackVoice.hunterImplant(sp, c);
    }

    private static void bind(ServerPlayer sp, State s, Mob m, Page page, long expiry) {
        m.setPersistenceRequired();
        CONTROLLED.put(m.getUUID(), sp.getUUID());
        s.puppets.add(new Puppet(m.getUUID(), page, expiry));
    }

    private static void release(ServerPlayer sp, State s, Puppet pu) {
        s.puppets.remove(pu);
        CONTROLLED.remove(pu.id);
        if (sp.level() instanceof ServerLevel level && level.getEntity(pu.id) instanceof Mob m) {
            m.setTarget(null);
            if (isFake(m)) m.setNoAi(true); // stamped copies go inert again
        }
    }

    private static void releasePage(ServerPlayer sp, State s, Page page) {
        for (Puppet pu : new ArrayList<>(s.puppets)) if (pu.page == page) release(sp, s, pu);
    }

    // ================= Gallery Fake =================
    private static void galleryFake(ServerPlayer sp, Combat c, ServerLevel level) {
        Entity src = ChainManager.rayEntity(sp, 5.0, e -> !(e instanceof Player) && e.isAlive() && !isFake(e));
        if (src != null) {
            if (src.getType().is(Tags.EntityTypes.BOSSES)) {
                say(sp, "\u00a7cToo powerful to copy");
                return;
            }
            if (!pay(sp, c, FAKE_COST)) return;
            if (!copyEntity(sp, c, level, src)) say(sp, "\u00a7cThat cannot be copied");
            return;
        }
        HitResult hit = sp.pick(5.0, 0f, false);
        if (hit instanceof BlockHitResult bhr && hit.getType() == HitResult.Type.BLOCK) {
            BlockState state = level.getBlockState(bhr.getBlockPos());
            BlockPos at = bhr.getBlockPos().relative(bhr.getDirection());
            if (state.isAir() || state.hasBlockEntity() || !level.getBlockState(at).canBeReplaced()) {
                say(sp, "\u00a7cNo room to copy that");
                return;
            }
            if (!pay(sp, c, FAKE_COST)) return;
            level.setBlock(at, state, 3);
            BlockFake bf = new BlockFake();
            bf.dim = level.dimension();
            bf.pos = at;
            bf.state = state;
            bf.expiry = level.getGameTime() + FAKE_TICKS;
            BLOCK_FAKES.add(bf);
            level.sendParticles(ParticleTypes.ENCHANT, at.getX() + 0.5, at.getY() + 0.8, at.getZ() + 0.5, 20, 0.4, 0.4, 0.4, 0.5);
            sound(sp, SoundEvents.ENCHANTMENT_TABLE_USE, 0.8f, 1.5f);
            return;
        }
        say(sp, "\u00a7cTouch something to copy it");
    }

    private static boolean copyEntity(ServerPlayer sp, Combat c, ServerLevel level, Entity src) {
        Entity copy = src.getType().create(level);
        if (copy == null) return false;
        CompoundTag tag = src.saveWithoutId(new CompoundTag());
        tag.remove("UUID");
        tag.remove("Passengers");
        tag.remove("Leash");
        copy.load(tag);
        copy.setUUID(UUID.randomUUID());
        Vec3 side = sp.getLookAngle().cross(new Vec3(0, 1, 0));
        side = side.lengthSqr() < 1e-4 ? new Vec3(1, 0, 0) : side.normalize().scale(1.3);
        copy.moveTo(src.getX() + side.x, src.getY(), src.getZ() + side.z, src.getYRot(), src.getXRot());
        copy.getPersistentData().putBoolean(FAKE_TAG, true);
        if (copy instanceof Mob m) {
            m.setNoAi(true);
            m.setSilent(true);
            m.setPersistenceRequired();
            m.setTarget(null);
        }
        level.addFreshEntity(copy);
        EntityFake f = new EntityFake();
        f.id = copy.getUUID();
        f.owner = sp.getUUID();
        f.dim = level.dimension();
        f.expiry = level.getGameTime() + FAKE_TICKS;
        ENTITY_FAKES.add(f);
        // enforce the per-player cap, oldest first
        int cap = Math.min(20, 6 + c.getHatsuLevel() / 10);
        int mine = 0;
        for (EntityFake o : ENTITY_FAKES) if (o.owner.equals(sp.getUUID())) mine++;
        for (Iterator<EntityFake> it = ENTITY_FAKES.iterator(); it.hasNext() && mine > cap; ) {
            EntityFake o = it.next();
            if (!o.owner.equals(sp.getUUID())) continue;
            Entity old = level.getEntity(o.id);
            if (old != null) old.discard();
            it.remove();
            mine--;
        }
        level.sendParticles(ParticleTypes.ENCHANT, copy.getX(), copy.getY() + 1.0, copy.getZ(), 25, 0.4, 0.6, 0.4, 0.5);
        sound(sp, SoundEvents.ENCHANTMENT_TABLE_USE, 0.8f, 1.5f);
        return true;
    }

    // ================= Order Stamp =================
    private static void orderStamp(ServerPlayer sp, Combat c, ServerLevel level) {
        Entity t = ChainManager.rayEntity(sp, 8.0, e -> e instanceof Mob m && !CONTROLLED.containsKey(e.getUUID())
            && (isFake(e) || m.getMobType() == MobType.UNDEAD));
        if (!(t instanceof Mob m)) {
            say(sp, "\u00a7cStamp a mindless thing: a Gallery Fake copy or an undead");
            return;
        }
        if (!pay(sp, c, STAMP_COST)) return;
        level.sendParticles(ParticleTypes.CRIT, m.getX(), m.getY() + m.getBbHeight() * 0.6, m.getZ(), 12, 0.3, 0.3, 0.3, 0.2);
        sound(sp, SoundEvents.ANVIL_PLACE, 0.6f, 1.8f);
        if (sp.isShiftKeyDown()) { // "break"
            AABB box = m.getBoundingBox().inflate(3.0);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box)) {
                if (e == m || e == sp || AllianceUtils.isAlly(e, sp)) continue;
                e.hurt(level.damageSources().playerAttack(sp), 8.0f);
            }
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState()),
                m.getX(), m.getY() + 0.8, m.getZ(), 40, 0.5, 0.6, 0.5, 0.1);
            m.discard();
            say(sp, "\u00a75Order Stamp: BREAK");
        } else { // "attack"
            m.setNoAi(false);
            m.setSilent(false);
            bind(sp, st(sp), m, Page.ORDER_STAMP, level.getGameTime() + PUPPET_TICKS / 2);
            say(sp, "\u00a75Order Stamp: ATTACK");
        }
    }

    // ================= The Sun and Moon =================
    private static void placeMark(ServerPlayer sp, Combat c, ServerLevel level) {
        State s = st(sp);
        Mark mk = new Mark();
        mk.owner = sp.getUUID();
        mk.dim = level.dimension();
        mk.placed = level.getGameTime();
        mk.expiry = mk.placed + MARK_TICKS;
        Entity e = aimedEntity(sp, CONTACT_RANGE, x -> x.isAlive() && x != sp && !(x instanceof net.minecraft.world.entity.item.ItemEntity));
        if (e != null) {
            mk.entity = e.getUUID();
        } else {
            mk.fixed = lookedAtBlockPoint(sp);
            if (mk.fixed == null) {
                say(sp, "\u00a7cMark something");
                return;
            }
        }
        if (!pay(sp, c, MARK_COST)) return;
        mk.sun = s.nextSun;
        s.nextSun = !s.nextSun;
        MARKS.add(mk);
        org.slf4j.Logger log = com.mojang.logging.LogUtils.getLogger();
        log.info("[hxh] Sun/Moon mark placed ({}) entity={} fixed={}", mk.sun ? "sun" : "moon", mk.entity, mk.fixed);
        int mine = 0;
        for (Mark o : MARKS) if (o.owner.equals(sp.getUUID())) mine++;
        for (Iterator<Mark> it = MARKS.iterator(); it.hasNext() && mine > MAX_MARKS; ) {
            Mark o = it.next();
            if (o.owner.equals(sp.getUUID())) {
                it.remove();
                mine--;
            }
        }
        sound(sp, SoundEvents.FIRECHARGE_USE, 0.8f, mk.sun ? 1.0f : 0.6f);
        say(sp, (mk.sun ? "\u00a76Sun mark placed" : "\u00a79Moon mark placed") + " - hold Z on it to charge");
    }

    /**
     * What the player is looking at: the exact ray first, and failing that the creature closest to the crosshair within a narrow cone
     * (fast, small or far NPCs are easy to miss by a hair, and a mark that will not stick is just frustrating).
     */
    private static Entity aimedEntity(ServerPlayer sp, double range, java.util.function.Predicate<Entity> filter) {
        Entity exact = ChainManager.rayEntity(sp, range, filter);
        if (exact != null) return exact;
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle();
        Entity best = null;
        double bestDot = 0.96; // about 16 degrees
        for (Entity c : sp.level().getEntities(sp, sp.getBoundingBox().inflate(range), filter)) {
            if (!(c instanceof LivingEntity)) continue;
            Vec3 to = c.position().add(0, c.getBbHeight() * 0.5, 0).subtract(eye);
            double dist = to.length();
            if (dist < 0.5 || dist > range) continue;
            double dot = to.scale(1.0 / dist).dot(look);
            if (dot > bestDot && sp.hasLineOfSight(c)) {
                bestDot = dot;
                best = c;
            }
        }
        return best;
    }

    /** The point a block-mark sits at for the block the player is looking at, or null if none within range. */
    private static Vec3 lookedAtBlockPoint(ServerPlayer sp) {
        HitResult hit = sp.pick(CONTACT_RANGE, 0f, false);
        if (!(hit instanceof BlockHitResult bhr) || hit.getType() != HitResult.Type.BLOCK) return null;
        return Vec3.atCenterOf(bhr.getBlockPos()).add(Vec3.atLowerCornerOf(bhr.getDirection().getNormal()).scale(0.6));
    }

    /** Is the owner still looking at (touching) what this mark is stuck to? */
    private static boolean inContact(ServerPlayer owner, ServerLevel level, Mark m) {
        if (owner.level() != level) return false;
        if (m.entity != null) {
            Entity hit = aimedEntity(owner, CONTACT_RANGE, x -> x.isAlive() && x.getUUID().equals(m.entity));
            return hit != null && hit.getUUID().equals(m.entity);
        }
        Vec3 now = lookedAtBlockPoint(owner);
        return now != null && now.distanceToSqr(m.fixed) < 0.01;
    }

    /** Called by the client's Z-held packet. */
    public static void setZHeld(ServerPlayer sp, boolean held) {
        if (held) Z_HELD.put(sp.getUUID(), Boolean.TRUE);
        else Z_HELD.remove(sp.getUUID());
    }

    /** Whole seconds of charge a mark has built, 0..MAX_CHARGE_SECONDS. */
    private static int chargeSeconds(ServerLevel level, Mark m) {
        return Math.min(MAX_CHARGE_SECONDS, m.chargeTicks / 20);
    }

    private static Vec3 markPos(ServerLevel level, Mark m) {
        if (m.entity == null) return m.fixed;
        Entity e = level.getEntity(m.entity);
        return e == null || !e.isAlive() ? null : e.position().add(0, e.getBbHeight() * 0.5, 0);
    }

    // ================= Convert Hands =================
    private static void convertHands(ServerPlayer sp, Combat c, ServerLevel level) {
        Entity t = ChainManager.rayEntity(sp, 5.0, e -> e instanceof LivingEntity && e != sp);
        if (!(t instanceof LivingEntity target)) {
            say(sp, "\u00a7cTouch someone to convert");
            return;
        }
        if (!pay(sp, c, CONVERT_COST)) return;
        State s = st(sp);
        boolean left = sp.isShiftKeyDown();
        long expiry = level.getGameTime() + DISGUISE_TICKS;
        // right hand: they look like Chrollo; left hand: Chrollo takes their appearance
        Disguise dg = left ? new Disguise(sp.getId(), target.getId(), expiry) : new Disguise(target.getId(), sp.getId(), expiry);
        s.disguises.removeIf(o -> {
            if (o.displayed == dg.displayed) {
                sendDisguise(sp, o, false);
                return true;
            }
            return false;
        });
        s.disguises.add(dg);
        sendDisguise(sp, dg, true);
        sound(sp, SoundEvents.ILLUSIONER_MIRROR_MOVE, 1.0f, 1.0f);
        say(sp, left ? "\u00a75Convert Hands (left): you take on " + target.getName().getString() : "\u00a75Convert Hands (right): " + target.getName().getString() + " now looks like you");
    }

    private static void sendDisguise(ServerPlayer sp, Disguise d, boolean on) {
        PacketDisguise pkt = new PacketDisguise(d.displayed, d.as, on);
        AddonNetwork.sendToTrackingAndSelf(pkt, sp);
        if (sp.level() instanceof ServerLevel level) {
            Entity other = level.getEntity(d.displayed == sp.getId() ? d.as : d.displayed);
            if (other != null && other != sp) AddonNetwork.sendToTracking(pkt, other);
        }
    }

    private static void releaseDisguises(ServerPlayer sp, State s) {
        for (Disguise d : s.disguises) sendDisguise(sp, d, false);
        s.disguises.clear();
    }

    // ================= per-tick =================
    public static void tick(ServerPlayer sp, Combat c, NenAddonData d) {
        State s = st(sp);
        // a relog (or crash) while wearing a stolen kit: put the real kit back
        if (d.hostKit && d.stolenKit == 0 && c.getCurrentKit() != KIT) restoreKit(sp, c, d);
        if (!isHunter(sp, c) || ChainManager.isJailed(sp)) {
            if (d.bookState != 0 || !s.puppets.isEmpty() || !s.disguises.isEmpty() || d.stolenKit > 0) clear(sp);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        int t = sp.tickCount;

        // is the book still in the owner's inventory? (it can be dropped on purpose to be "touched")
        if (t % 5 == 0) {
            boolean held = hasBook(sp);
            if (held != d.bookHeld) {
                d.bookHeld = held;
                d.markSync();
            }
            syncFx(sp, d);
        }
        if (d.bookState != 0 && !d.bookHeld) {
            if (++s.lostTicks % 20 == 0 && s.lostTicks > 20 * 120) { // abandoned for two minutes: it fades
                clear(sp);
                return;
            }
        } else {
            s.lostTicks = 0;
        }
        if (d.stolenKit > 0 && !pageActive(d, Page.ofKit(d.stolenKit))) restoreKit(sp, c, d);

        if (d.bookState != 0 && d.bookHeld && t % 20 == 0) {
            float up = d.bookmark >= 0 ? BOOKMARK_UPKEEP : BOOK_UPKEEP;
            if (c.getCurrentEnergy() < up) {
                clear(sp);
                say(sp, "\u00a7cEnergy depleted! The book fades.");
                return;
            }
            c.consumeEnergy(up);
        }

        // page effects that are no longer active are dropped
        if (!pageActive(d, Page.BLACK_VOICE)) releasePage(sp, s, Page.BLACK_VOICE);
        if (!pageActive(d, Page.ORDER_STAMP)) releasePage(sp, s, Page.ORDER_STAMP);
        if (!pageActive(d, Page.CONVERT_HANDS) && !s.disguises.isEmpty()) releaseDisguises(sp, s);
        s.disguises.removeIf(dg -> {
            if (now >= dg.expiry) {
                sendDisguise(sp, dg, false);
                return true;
            }
            return false;
        });

        // puppets
        for (Puppet pu : new ArrayList<>(s.puppets)) {
            Entity e = level.getEntity(pu.id);
            if (!(e instanceof Mob m) || !m.isAlive() || now >= pu.expiry) {
                release(sp, s, pu);
                if (e instanceof Mob mm && now >= pu.expiry && isFake(mm)) mm.discard();
                continue;
            }
            if (t % 10 == 0) steer(sp, level, m);
        }
    }

    /** Puppets fight the caster's enemies, otherwise follow the caster. */
    private static void steer(ServerPlayer owner, ServerLevel level, Mob m) {
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, owner.getBoundingBox().inflate(16))) {
            if (e == owner || e == m || !e.isAlive() || CONTROLLED.containsKey(e.getUUID()) || AllianceUtils.isAlly(e, owner) || isFake(e)) continue;
            boolean hostile = e instanceof Enemy || (e instanceof Mob em && em.getTarget() == owner)
                || e == owner.getLastHurtByMob() || e == owner.getLastHurtMob();
            if (!hostile) continue;
            double d2 = e.distanceToSqr(m);
            if (d2 < bestD) {
                bestD = d2;
                best = e;
            }
        }
        m.setTarget(best);
        if (best == null && m.distanceToSqr(owner) > 25.0) m.getNavigation().moveTo(owner, 1.1);
    }

    /** Global per-tick work: Sun/Moon marks and Gallery Fake expiry. */
    public static void tickGlobal(MinecraftServer server) {
        if (MARKS.isEmpty() && ENTITY_FAKES.isEmpty() && BLOCK_FAKES.isEmpty()) return;
        long tick = server.getTickCount();

        for (Iterator<EntityFake> it = ENTITY_FAKES.iterator(); it.hasNext(); ) {
            EntityFake f = it.next();
            ServerLevel l = server.getLevel(f.dim);
            if (l == null) { it.remove(); continue; }
            Entity e = l.getEntity(f.id);
            if (e == null || !e.isAlive()) { it.remove(); continue; }
            if (l.getGameTime() >= f.expiry) {
                l.sendParticles(ParticleTypes.POOF, e.getX(), e.getY() + 0.8, e.getZ(), 10, 0.3, 0.4, 0.3, 0.02);
                e.discard();
                it.remove();
            }
        }
        for (Iterator<BlockFake> it = BLOCK_FAKES.iterator(); it.hasNext(); ) {
            BlockFake b = it.next();
            ServerLevel l = server.getLevel(b.dim);
            if (l == null) { it.remove(); continue; }
            if (l.getGameTime() >= b.expiry) {
                if (l.getBlockState(b.pos) == b.state) l.setBlock(b.pos, Blocks.AIR.defaultBlockState(), 3);
                it.remove();
            }
        }

        List<Mark> dead = new ArrayList<>();
        List<Mark> live = new ArrayList<>();
        for (Mark m : MARKS) {
            ServerLevel l = server.getLevel(m.dim);
            if (l == null || l.getGameTime() >= m.expiry || markPos(l, m) == null) {
                com.mojang.logging.LogUtils.getLogger().info("[hxh] Sun/Moon mark expired/removed: level={} time={} expiry={} pos={}", l, l == null ? -1 : l.getGameTime(), m.expiry, l == null ? null : markPos(l, m));
                dead.add(m);
                continue;
            }
            live.add(m);
            if (tick % 4 == 0) {
                Vec3 p = markPos(l, m);
                int steps = chargeSeconds(l, m);
                l.sendParticles(m.sun ? ParticleTypes.FLAME : ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y, p.z, 3 + steps * 2, 0.3 + steps * 0.05, 0.4, 0.3 + steps * 0.05, 0.01);
            }
            // charge only while the owner keeps holding Z AND keeps touching the target
            if (m.charging) {
                ServerPlayer osp = server.getPlayerList().getPlayer(m.owner);
                long age = l.getGameTime() - m.placed;
                boolean held = osp != null && (Z_HELD.containsKey(m.owner) || age < HOLD_GRACE_TICKS);
                if (osp == null || !held) {
                    m.charging = false;
                    if (osp != null && m.chargeTicks >= 20) say(osp, "\u00a77Charge locked at " + chargeSeconds(l, m) + "/" + MAX_CHARGE_SECONDS);
                } else if (!inContact(osp, l, m)) {
                    m.charging = false;
                    if (m.chargeTicks > 0) say(osp, "\u00a7cContact lost - charge locked at " + chargeSeconds(l, m) + "/" + MAX_CHARGE_SECONDS);
                } else if (m.chargeTicks < MAX_CHARGE_SECONDS * 20) {
                    m.chargeTicks++;
                    if (m.chargeTicks % 20 == 0) {
                        int secs = m.chargeTicks / 20;
                        say(osp, (m.sun ? "\u00a76Sun" : "\u00a79Moon") + " charge: " + secs + "/" + MAX_CHARGE_SECONDS
                            + (secs >= MAX_CHARGE_SECONDS ? " (MAX)" : ""));
                    }
                } else {
                    m.charging = false;
                }
            }
        }
        MARKS.removeAll(dead);
        // a sun and a moon that touch detonate together
        for (Mark sun : live) {
            if (!sun.sun || !MARKS.contains(sun)) continue;
            for (Mark moon : live) {
                if (moon.sun || !MARKS.contains(moon) || !moon.dim.equals(sun.dim)) continue;
                ServerLevel l = server.getLevel(sun.dim);
                if (l == null) continue;
                Vec3 a = markPos(l, sun), b = markPos(l, moon);
                if (a == null || b == null || a.distanceToSqr(b) > 2.25) continue;
                Vec3 mid = a.add(b).scale(0.5);
                Player owner = server.getPlayerList().getPlayer(sun.owner);
                // the pair detonates with the stronger of the two locked-in charges
                int steps = Math.max(chargeSeconds(l, sun), chargeSeconds(l, moon));
                float frac = steps / (float) MAX_CHARGE_SECONDS;
                float power = EXPLOSION_POWER + (MAX_EXPLOSION_POWER - EXPLOSION_POWER) * frac;
                float hpBefore = owner != null ? owner.getHealth() : 0f;
                l.explode(owner, mid.x, mid.y, mid.z, power,
                    MARKS_BREAK_BLOCKS ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE);
                // flat bonus per charge step to everything caught in the blast (the user is handled below)
                float bonus = BONUS_DAMAGE_PER_CHARGE * steps;
                if (bonus > 0f) {
                    double reach = power * 2.0;
                    for (LivingEntity v : l.getEntitiesOfClass(LivingEntity.class, new AABB(mid, mid).inflate(reach),
                        x -> x != owner && x.isAlive() && x.position().add(0, x.getBbHeight() * 0.5, 0).distanceToSqr(mid) <= reach * reach)) {
                        v.hurt(l.damageSources().explosion(owner, owner), bonus);
                    }
                }
                // the blast always hurts the user: if it did not reach them, they still take a charge-scaled hit
                if (owner != null && owner.isAlive() && owner.getHealth() >= hpBefore) {
                    owner.hurt(l.damageSources().explosion(owner, owner), 2.0f + (MAX_SELF_DAMAGE - 2.0f) * frac);
                }
                if (owner instanceof ServerPlayer osp) {
                    say(osp, "\u00a7cSun and Moon detonated (charge " + steps + "/" + MAX_CHARGE_SECONDS + ")");
                }
                MARKS.remove(sun);
                MARKS.remove(moon);
                break;
            }
        }
    }

    /** Release everything this player holds (death, logout, kit change, out of energy). Marks and copies persist. */
    public static void clear(Player p) {
        State s = STATES.get(p);
        if (s != null && p instanceof ServerPlayer sp) {
            for (Puppet pu : new ArrayList<>(s.puppets)) release(sp, s, pu);
            releaseDisguises(sp, s);
            NenAddonData d = NenAddonData.peek(p);
            if (d != null) {
                if (d.stolenKit > 0) restoreKit(sp, Combat.get(sp), d);
                if (d.bookState != 0) setBook(sp, d, 0);
            }
        }
    }

    // ================= the book as an item =================
    public static boolean isBook(ItemStack st) {
        return !st.isEmpty() && SkillHunterItems.BOOK != null && st.is(SkillHunterItems.BOOK);
    }

    public static UUID bookOwner(ItemStack st) {
        return isBook(st) && st.hasTag() && st.getTag().hasUUID("Owner") ? st.getTag().getUUID("Owner") : null;
    }

    public static boolean isOwnerBook(ItemStack st, Player p) {
        return p.getUUID().equals(bookOwner(st));
    }

    private static boolean hasBook(Player p) {
        for (ItemStack st : p.getInventory().items) if (isOwnerBook(st, p)) return true;
        for (ItemStack st : p.getInventory().offhand) if (isOwnerBook(st, p)) return true;
        return false;
    }

    private static void giveBook(ServerPlayer sp) {
        if (hasBook(sp)) return;
        ItemStack st = new ItemStack(SkillHunterItems.BOOK);
        st.getOrCreateTag().putUUID("Owner", sp.getUUID());
        st.getOrCreateTag().putString("OwnerName", sp.getName().getString());
        // the book is a held object: main hand if free, else off hand if free, else the inventory
        if (sp.getMainHandItem().isEmpty()) sp.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, st);
        else if (sp.getOffhandItem().isEmpty()) sp.setItemInHand(net.minecraft.world.InteractionHand.OFF_HAND, st);
        else if (!sp.getInventory().add(st)) sp.drop(st, false);
    }

    private static void removeBooks(ServerPlayer sp) {
        for (int i = 0; i < sp.getInventory().items.size(); i++) {
            if (isOwnerBook(sp.getInventory().items.get(i), sp)) sp.getInventory().items.set(i, ItemStack.EMPTY);
        }
        for (int i = 0; i < sp.getInventory().offhand.size(); i++) {
            if (isOwnerBook(sp.getInventory().offhand.get(i), sp)) sp.getInventory().offhand.set(i, ItemStack.EMPTY);
        }
    }

    /** The held book animates (open/closed, page turn, ribbon) while it is in the owner's possession (open, or closed with a bookmark). Also drives the page-turn and bookmark animations. */
    private static void syncFx(ServerPlayer sp, NenAddonData d) {
        int want = d.bookHeld ? d.bookState : 0;
        int page = want == 2 ? d.activePage : -1;
        int mark = want != 0 ? d.bookmark : -1;
        State s = st(sp);
        if (s.lastFx == want && s.lastPage == page && s.lastMark == mark) return;
        int flags = 0;
        if (s.lastFx == 2 && want == 2 && s.lastPage != page && page >= 0) flags |= 1; // page turn
        if (mark >= 0 && s.lastMark != mark) flags |= 2; // bookmark placed
        s.lastFx = want;
        s.lastPage = page;
        s.lastMark = mark;
        AddonNetwork.sendToTrackingAndSelf(new PacketBookFx(sp.getId(), want, page, mark, flags), sp);
    }

    /** Called when the owner dies: the conjured book does not drop. */
    public static void stripBookDrops(java.util.Collection<net.minecraft.world.entity.item.ItemEntity> drops) {
        drops.removeIf(ie -> isBook(ie.getItem()));
    }

    // ================= stealing: ask -> answer -> touch the book =================
    private static String kitName(int kit) {
        return switch (kit) {
            case 8 -> "Chains";
            default -> "an unknown Hatsu";
        };
    }

    public static void ask(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (!ready(sp, c, BOOK_MIN_LEVEL, "Skill Hunter")) return;
        NenAddonData d = NenAddonData.get(sp);
        if (d.bookState != 2 || !d.bookHeld) {
            say(sp, "\u00a7cOpen the book first");
            return;
        }
        Entity t = ChainManager.rayEntity(sp, 8.0, e -> e instanceof ServerPlayer && e != sp);
        if (!(t instanceof ServerPlayer tp)) {
            say(sp, "\u00a7cLook at a person to question");
            return;
        }
        int kit = Combat.get(tp).getCurrentKit();
        if (kit != 8) {
            say(sp, "\u00a77" + tp.getName().getString() + " has no Hatsu worth stealing");
            return;
        }
        if ((d.stolenMask & (1 << kit)) != 0) {
            say(sp, "\u00a77You already hold that Hatsu");
            return;
        }
        if (!pay(sp, c, ASK_COST)) return;
        State s = st(sp);
        s.asked.put(tp.getUUID(), sp.level().getGameTime() + ASK_TICKS);
        net.minecraft.network.chat.MutableComponent msg = Component.literal("\u00a75" + sp.getName().getString() + " asks about your Hatsu...  ")
            .append(Component.literal("[Answer]").withStyle(style -> style
                .withColor(net.minecraft.ChatFormatting.GREEN)
                .withClickEvent(new net.minecraft.network.chat.ClickEvent(net.minecraft.network.chat.ClickEvent.Action.RUN_COMMAND,
                    "/hxh skillhunter answer " + sp.getUUID()))));
        tp.sendSystemMessage(msg);
        say(sp, "\u00a75Question posed to " + tp.getName().getString());
    }

    private static void answer(ServerPlayer target, UUID askerId) {
        ServerPlayer asker = target.getServer().getPlayerList().getPlayer(askerId);
        if (asker == null) {
            target.sendSystemMessage(Component.literal("\u00a77Nobody is waiting for your answer"));
            return;
        }
        State s = st(asker);
        Long exp = s.asked.get(target.getUUID());
        long now = asker.level().getGameTime();
        if (exp == null || now > exp) {
            target.sendSystemMessage(Component.literal("\u00a77Nobody is waiting for your answer"));
            return;
        }
        s.asked.remove(target.getUUID());
        int kit = Combat.get(target).getCurrentKit();
        if (kit != 8) return;
        s.seen.put(target.getUUID(), new Seen(kit, now + SEEN_TICKS));
        asker.sendSystemMessage(Component.literal("\u00a75" + target.getName().getString() + " answers. You see their Hatsu: "
            + kitName(kit) + ". Drop the book and have them touch it."));
        target.sendSystemMessage(Component.literal("\u00a77You answered " + asker.getName().getString() + "'s question."));
    }

    /**
     * A player is about to pick up a dropped book. If it is a Skill Hunter's book and that player has just answered
     * his question, the touch completes the theft and the book stays on the ground. Returns true to cancel the pickup.
     */
    public static boolean onBookTouched(Player picker, net.minecraft.world.entity.item.ItemEntity ie) {
        ItemStack stack = ie.getItem();
        UUID ownerId = bookOwner(stack);
        if (ownerId == null || ownerId.equals(picker.getUUID()) || picker.getServer() == null) return false;
        ServerPlayer owner = picker.getServer().getPlayerList().getPlayer(ownerId);
        if (owner == null) return false;
        State s = st(owner);
        Seen seen = s.seen.get(picker.getUUID());
        if (seen == null || owner.level().getGameTime() > seen.expiry) return false;
        s.seen.remove(picker.getUUID());
        NenAddonData d = NenAddonData.get(owner);
        int bit = 1 << seen.kit;
        if ((d.stolenMask & bit) != 0) return false;
        d.stolenMask |= bit;
        d.markSync();
        d.save();
        if (ie.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.ENCHANT, ie.getX(), ie.getY() + 0.5, ie.getZ(), 40, 0.4, 0.5, 0.4, 0.8);
            level.playSound(null, ie.blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 1.0f, 0.6f);
        }
        owner.sendSystemMessage(Component.literal("\u00a75Skill Hunter: " + kitName(seen.kit) + " is now in your book!"));
        picker.sendSystemMessage(Component.literal("\u00a77Your Hatsu is copied into the book."));
        return true;
    }

    private static void activateStolen(ServerPlayer sp, Combat c, NenAddonData d, Page p) {
        if ((d.stolenMask & (1 << p.kit)) == 0) {
            say(sp, "\u00a7cYou have not stolen that Hatsu");
            return;
        }
        if (d.stolenKit == p.kit) return;
        d.hostKit = true;
        d.stolenKit = p.kit;
        c.syncKit(p.kit);
        net.hxhadventure.networking.ModMessages.sendToPlayer(new net.hxhadventure.networking.PacketSyncKit(p.kit), sp);
        d.markSync();
        d.save();
        say(sp, "\u00a75Skill Hunter: wielding " + kitName(p.kit));
        sound(sp, SoundEvents.BOOK_PAGE_TURN, 1.0f, 0.7f);
    }

    private static void restoreKit(ServerPlayer sp, Combat c, NenAddonData d) {
        d.stolenKit = 0;
        d.hostKit = false;
        if (c != null) {
            c.syncKit(KIT);
            net.hxhadventure.networking.ModMessages.sendToPlayer(new net.hxhadventure.networking.PacketSyncKit(KIT), sp);
        }
        d.markSync();
        d.save();
    }

    public static com.mojang.brigadier.builder.LiteralArgumentBuilder<net.minecraft.commands.CommandSourceStack> commandNode() {
        return net.minecraft.commands.Commands.literal("skillhunter")
            .then(net.minecraft.commands.Commands.literal("answer")
                .then(net.minecraft.commands.Commands.argument("asker", net.minecraft.commands.arguments.UuidArgument.uuid())
                    .executes(ctx -> {
                        answer(ctx.getSource().getPlayerOrException(), net.minecraft.commands.arguments.UuidArgument.getUuid(ctx, "asker"));
                        return 1;
                    })));
    }
}
