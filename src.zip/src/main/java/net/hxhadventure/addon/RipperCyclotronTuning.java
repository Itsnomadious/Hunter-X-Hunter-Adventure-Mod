package net.hxhadventure.addon;

/** Numbers for Phinks's Ripper Cyclotron (Hatsu kit 22, Enhancers). Change them here; nothing else needs to change to rebalance. */
public final class RipperCyclotronTuning {
    private RipperCyclotronTuning() {}

    // ---- unlocks ----
    /** Hatsu level needed to use it. */
    public static final int MIN_LEVEL = 5;

    // ---- the spin ----
    /** One rotation of the arm: 10 ticks = 0.5 s. */
    public static final int ROTATION_TICKS = 10;
    /** Damage added by every finished rotation: 0.05 = +5%. No cap. */
    public static final double DAMAGE_PER_ROTATION = 0.05;
    /** false: +5% of the base per rotation (20 rotations = x2.0). true: x1.05 on top of the last one. */
    public static final boolean COMPOUND = false;
    /** true: the arm turns clockwise as seen from the player's right-hand side (forward, down, back, up). false: the other way. */
    public static final boolean CLOCKWISE = true;

    // ---- the aura around the fist (diameter in blocks) ----
    public static final double AURA_MIN_DIAMETER = 0.5;
    /** The aura never gets wider than this, however long the spin goes on (damage keeps climbing). */
    public static final double AURA_MAX_DIAMETER = 3.0;
    /** The aura reaches its maximum width after this many rotations. */
    public static final double ROTATIONS_TO_MAX_SIZE = 8.0;

    // ---- the punch (thrown when Z is released) ----
    // It is exactly a fully charged Jajanken Rock (damage, reach, shock, knockback, block breaking: see Jajanken.strike and the ROCK_* numbers),
    // multiplied by the rotations above.
    /** Aura paid when the punch is thrown. */
    public static final float COST = 250f;
    public static final int COOLDOWN_TICKS = 60;
}
