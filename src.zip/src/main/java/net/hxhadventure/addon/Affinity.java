package net.hxhadventure.addon;

import net.hxhadventure.abilities.Combat;

/** Passive bonuses for each Nen category. Values are fractions (0.15 = 15%). */
public final class Affinity {
    private Affinity() {}

    /** Pseudo-type used by Emperor Time: every category's passive at once (100% efficiency in all types). */
    public static final int ALL = 99;
    private static final int[] TYPES = {1, 2, 3, 4, 5, 6};

    public static String name(int t) {
        return switch (t) {
            case Combat.NEN_ENHANCEMENT -> "Enhancer";
            case Combat.NEN_TRANSMUTATION -> "Transmuter";
            case Combat.NEN_EMISSION -> "Emitter";
            case Combat.NEN_CONJURATION -> "Conjurer";
            case Combat.NEN_MANIPULATION -> "Manipulator";
            case Combat.NEN_SPECIALIZATION -> "Specialist";
            case ALL -> "Emperor Time";
            default -> "Unknown";
        };
    }

    public static String describe(int t) {
        return switch (t) {
            case Combat.NEN_ENHANCEMENT -> "+20% damage dealt, -10% damage taken, knockback resistance";
            case Combat.NEN_TRANSMUTATION -> "-30% damage from all status effects, half fall damage, +10% aura regeneration speed";
            case Combat.NEN_EMISSION -> "+15% projectile damage, +25% En radius";
            case Combat.NEN_CONJURATION -> "+20% XP gain for Gyo and In";
            case Combat.NEN_MANIPULATION -> "+20% summon damage and durability, En detection threshold 10% lower: with In active you are immune to En when your In level is at least 90% of the user's En level";
            case Combat.NEN_SPECIALIZATION -> "+5% damage dealt, -5% damage taken, +25% skill XP";
            case ALL -> "all six passives at once: +26% damage dealt, -14.5% taken, all the regeneration, status, fall, knockback, En, summon and XP bonuses";
            default -> "No affinity yet";
        };
    }

    private static float dealtRaw(int t) {
        return switch (t) {
            case Combat.NEN_ENHANCEMENT -> 1.20f;
            case Combat.NEN_SPECIALIZATION -> 1.05f;
            default -> 1.0f;
        };
    }

    private static float takenRaw(int t) {
        return switch (t) {
            case Combat.NEN_ENHANCEMENT -> 0.90f;
            case Combat.NEN_SPECIALIZATION -> 0.95f;
            default -> 1.0f;
        };
    }

    private static float projectileRaw(int t) { return t == Combat.NEN_EMISSION ? 1.15f : 1.0f; }
    private static float summonRaw(int t) { return t == Combat.NEN_MANIPULATION ? 1.20f : 1.0f; }
    /** Transmuter passive: damage from status effects (poison, wither, ...) is reduced by this much. */
    public static final float TRANSMUTER_STATUS_REDUCTION = 0.30f;
    /** Conjurer passive: Gyo and In skill XP is multiplied by this. */
    public static final float CONJURER_GYO_IN_XP = 1.20f;
    /** With In active: En only senses you when the detector's En level is higher than your In level. */
    public static final float BASE_EN_THRESHOLD = 1.0f;
    /** Manipulator passive: En is blocked when the target's In level >= the detector's En level * this. */
    public static final float MANIPULATOR_EN_THRESHOLD = 0.90f;

    private static float efficiencyRaw(int t) { return 0.0f; }
    private static float abilityRefundRaw(int t) { return 0.0f; }
    private static float renRefundRaw(int t) { return 0.0f; }
    private static float manipulatorEnImmuneRaw(int t) { return t == Combat.NEN_MANIPULATION ? 1.0f : 0.0f; }
    private static float regenBonusRaw(int t) { return t == Combat.NEN_TRANSMUTATION ? 0.10f : 0.0f; }
    private static float enRadiusMultRaw(int t) { return t == Combat.NEN_EMISSION ? 1.25f : 1.0f; }
    private static float skillXpMultRaw(int t) { return t == Combat.NEN_SPECIALIZATION ? 1.25f : 1.0f; }
    private static double speedBonusRaw(int t) { return 0.0; }
    private static double knockbackResistRaw(int t) { return t == Combat.NEN_ENHANCEMENT ? 0.2 : 0.0; }
    private static float lightningReductionRaw(int t) { return 0.0f; }
    private static float fallReductionRaw(int t) { return t == Combat.NEN_TRANSMUTATION ? 0.50f : 0.0f; }
    private static float statusReductionRaw(int t) { return t == Combat.NEN_TRANSMUTATION ? TRANSMUTER_STATUS_REDUCTION : 0.0f; }
    private static float gyoInXpRaw(int t) { return t == Combat.NEN_CONJURATION ? CONJURER_GYO_IN_XP : 1.0f; }

    public static float statusReduction(int t) { if (t != ALL) return statusReductionRaw(t); float r = 0f; for (int x : TYPES) r = Math.max(r, statusReductionRaw(x)); return r; }
    public static float gyoInXpMult(int t) { if (t != ALL) return gyoInXpRaw(t); float r = 1f; for (int x : TYPES) r *= gyoInXpRaw(x); return r; }

    /** Damage that comes from a status effect: poison and instant harming (magic), and wither. */
    public static boolean isStatusDamage(net.minecraft.world.damagesource.DamageSource src) {
        return src.is(net.minecraft.world.damagesource.DamageTypes.MAGIC)
            || src.is(net.minecraft.world.damagesource.DamageTypes.INDIRECT_MAGIC)
            || src.is(net.minecraft.world.damagesource.DamageTypes.WITHER);
    }

    public static float dealt(int t) { if (t != ALL) return dealtRaw(t); float r = 1f; for (int x : TYPES) r *= dealtRaw(x); return r; }
    public static float taken(int t) { if (t != ALL) return takenRaw(t); float r = 1f; for (int x : TYPES) r *= takenRaw(x); return r; }
    public static float projectile(int t) { if (t != ALL) return projectileRaw(t); float r = 1f; for (int x : TYPES) r *= projectileRaw(x); return r; }
    public static float summon(int t) { if (t != ALL) return summonRaw(t); float r = 1f; for (int x : TYPES) r *= summonRaw(x); return r; }
    public static float enRadiusMult(int t) { if (t != ALL) return enRadiusMultRaw(t); float r = 1f; for (int x : TYPES) r *= enRadiusMultRaw(x); return r; }
    public static float skillXpMult(int t) { if (t != ALL) return skillXpMultRaw(t); float r = 1f; for (int x : TYPES) r *= skillXpMultRaw(x); return r; }
    public static float abilityRefund(int t) { if (t != ALL) return abilityRefundRaw(t); float r = 0f; for (int x : TYPES) r += abilityRefundRaw(x); return r; }
    public static float renRefund(int t) { if (t != ALL) return renRefundRaw(t); float r = 0f; for (int x : TYPES) r += renRefundRaw(x); return r; }
    public static float regenBonus(int t) { if (t != ALL) return regenBonusRaw(t); float r = 0f; for (int x : TYPES) r += regenBonusRaw(x); return r; }
    public static double speedBonus(int t) { if (t != ALL) return speedBonusRaw(t); double r = 0; for (int x : TYPES) r += speedBonusRaw(x); return r; }
    public static double knockbackResist(int t) { if (t != ALL) return knockbackResistRaw(t); double r = 0; for (int x : TYPES) r += knockbackResistRaw(x); return r; }
    public static float lightningReduction(int t) { if (t != ALL) return lightningReductionRaw(t); float r = 0f; for (int x : TYPES) r = Math.max(r, lightningReductionRaw(x)); return r; }
    public static float fallReduction(int t) { if (t != ALL) return fallReductionRaw(t); float r = 0f; for (int x : TYPES) r = Math.max(r, fallReductionRaw(x)); return r; }

    public static float efficiency(int t) { if (t != ALL) return efficiencyRaw(t); float r = 0f; for (int x : TYPES) r += efficiencyRaw(x); return r; }
    public static boolean enImmune(int t) { if (t != ALL) return manipulatorEnImmuneRaw(t) > 0f; for (int x : TYPES) if (manipulatorEnImmuneRaw(x) > 0f) return true; return false; }
}
