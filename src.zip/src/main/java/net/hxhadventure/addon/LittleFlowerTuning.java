package net.hxhadventure.addon;

/** Numbers for Genthru's Little Flower and Countdown (Hatsu kit 30, Conjurers). Change them here; nothing else needs to change to rebalance. */
public final class LittleFlowerTuning {
    private LittleFlowerTuning() {}

    // ---- unlocks (Hatsu level) ----
    public static final int LITTLE_FLOWER_MIN_LEVEL = 1;
    public static final int COUNTDOWN_MIN_LEVEL = 20;

    // ---- Little Flower (H mode: left click = left palm, right click = right palm, both = both palms) ----
    /** Damage of one detonation to the target (before the Hatsu bonuses). */
    public static final float LF_DAMAGE = 48f;
    public static final float LF_COST = 30f;
    /** How far the palm reaches. */
    public static final double LF_REACH = 3.2;
    /** Ticks the palm has to stay on the target before it goes off. The user is slowed the whole time, as if holding the target. */
    public static final int LF_CONTACT_TICKS = 14;
    /** Slowness level (0 = I) while touching. */
    public static final int LF_SLOW_AMPLIFIER = 4;
    public static final int LF_COOLDOWN_TICKS = 20;
    /** Pressing the second mouse button within this many ticks of the first counts as using both hands. */
    public static final int LF_BOTH_GRACE_TICKS = 4;
    /** What the user takes of their own blast. Halved in Ken. */
    public static final float SELF_FRACTION = 0.30f;
    public static final float KEN_SELF_MULT = 0.5f;
    /** Both palms at once: the blast is this share of normal, for the target and for the user alike. */
    public static final float BOTH_HANDS_DAMAGE_MULT = 0.2f;
    /** The one being held presses the button opposite to the palm (left palm: right click; right palm: left click; both palms: both) and takes this share. */
    public static final float BRACE_MULT = 0.2f;

    // ---- Countdown (Z) ----
    public static final float COUNTDOWN_COST = 250f;
    public static final int MAX_BOMBS = 100;
    /** Touch (Z) and say "Bomber" within this many ticks of each other, in either order. */
    public static final int TOUCH_WINDOW_TICKS = 120;
    /** After the touch, the explanations have to be complete within this long (or the explanations first, then the touch). */
    public static final int TOUCH_VALID_TICKS = 1200;
    /** How long a target remembers what it was told or shown. */
    public static final int KNOWLEDGE_TICKS = 24000;
    /** Who hears an explanation, and who counts as having seen Little Flower go off. */
    public static final double HEAR_RANGE = 20.0;
    public static final double WITNESS_RANGE = 24.0;

    /** The timer starts here and counts heartbeats: at 60 bpm that is one a second (100 minutes). */
    public static final float COUNTDOWN_START = 6000f;
    public static final float BASE_BPM = 60f;
    /** In a fight (hit someone, got hit, or has a target) the heart rate is multiplied by this. */
    public static final float AGGRO_BPM_MULT = 2f;
    public static final float SPRINT_BPM_BONUS = 30f;
    public static final float LOW_HEALTH_BPM_BONUS = 20f;
    public static final float MAX_BPM = 240f;
    /** 1 = real time. Raise it to make every bomb tick faster. */
    public static final float TIME_SCALE = 1f;
    /** The blast is this many times Little Flower's damage, and goes through armour. */
    public static final float BLAST_MULT = 10f;
    /** The bomb also tears blocks out of the world within this many blocks of where it goes off (unbreakable blocks stay). */
    public static final int BLAST_BLOCK_RADIUS = 6;

    // ---- Release (Genthru, Sub and Bara: thumbs together) ----
    /** Three players this close to each other (each to both others), each typing "Release"... */
    public static final double RELEASE_RANGE = 3.0;
    /** ...within this many ticks of each other, set off the bombs of ONE of them. */
    public static final int RELEASE_WINDOW_TICKS = 200;
}
