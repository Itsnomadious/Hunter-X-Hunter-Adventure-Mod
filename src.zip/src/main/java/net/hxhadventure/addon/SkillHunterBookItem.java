package net.hxhadventure.addon;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.hxhadventure.addon.client.BookItemRenderer;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import org.jetbrains.annotations.Nullable;

/**
 * The conjured Skill Hunter book, shown as a real held model (see BookItemRenderer). A normal item: it can be dropped, picked up by players (and by mobs that pick up
 * items), and it is what a target must touch to have their Hatsu stolen. Right-click as its owner to open/close it.
 */
public class SkillHunterBookItem extends Item {
    public SkillHunterBookItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp && SkillHunter.isOwnerBook(stack, sp)) {
            SkillHunter.toggleBook(sp);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** Hand-held 3D model only; the open/close animation does not need the item to be re-equipped. */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || !oldStack.is(newStack.getItem());
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private BlockEntityWithoutLevelRenderer renderer;

            @Override
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (renderer == null) {
                    Minecraft mc = Minecraft.getInstance();
                    renderer = new BookItemRenderer(mc.getBlockEntityRenderDispatcher(), mc.getEntityModels());
                }
                return renderer;
            }
        });
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        if (stack.hasTag() && stack.getTag().contains("OwnerName")) {
            tip.add(Component.literal("§7Skill Hunter of " + stack.getTag().getString("OwnerName")));
        }
        tip.add(Component.literal("§8Right-click to open or close"));
    }
}
