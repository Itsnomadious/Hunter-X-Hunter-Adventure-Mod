package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Forge event hooks for {@link Jajanken}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class JajankenEvents {
    private JajankenEvents() {}

    @SubscribeEvent
    public static void onJajankenTick(TickEvent.PlayerTickEvent e) {
        if (e.phase == TickEvent.Phase.START && e.player instanceof ServerPlayer sp) {
            GonVow.tick(sp);
            Jajanken.tick(sp);
        }
    }

    /** While the aura is all in the fist, the body has no defence (Ko's incoming multiplier). Runs after the other hurt handlers. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onHurt(LivingHurtEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            float m = Jajanken.incomingMult(sp);
            if (m != 1.0f) e.setAmount(e.getAmount() * m);
        }
    }

    /** Scissors: remembers the damage once every other handler has had its say, and gives back a share of what armor then takes off. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onHurtRecord(LivingHurtEvent e) {
        Jajanken.pierceBefore(e.getEntity(), e.getAmount());
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onDamage(LivingDamageEvent e) {
        float out = Jajanken.pierceAfter(e.getEntity(), e.getAmount());
        if (out != e.getAmount()) e.setAmount(out);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            Jajanken.clear(sp);
            GonVow.clear(sp, false);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            Jajanken.clear(sp);
            GonVow.clear(sp, true);
        }
    }

    /** Someone who starts tracking a player mid-charge sees the aura at once. */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking e) {
        if (e.getEntity() instanceof ServerPlayer viewer && e.getTarget() instanceof ServerPlayer owner) {
            Jajanken.sendTo(owner, viewer);
            GonVow.sendTo(owner, viewer);
        }
    }
}
