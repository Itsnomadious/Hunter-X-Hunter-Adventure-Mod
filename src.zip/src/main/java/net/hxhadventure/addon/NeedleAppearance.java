package net.hxhadventure.addon;

import com.mojang.authlib.properties.Property;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * A look saved by Body Alteration: which entity type to draw and, for a player, whose skin. Plain data with no client
 * classes, so the server can keep it, save it in NBT and send it to clients, which build the actual model from it
 * ({@code client.NeedleDisguise}).
 */
public final class NeedleAppearance {
    private static final ResourceLocation PLAYER = ResourceLocation.fromNamespaceAndPath("minecraft", "player");

    public final ResourceLocation type;
    /** The player's UUID, or null when the saved look is not a player. */
    public final UUID uuid;
    public final String name;
    /** Base64 "textures" profile property of the player (the skin), or "" when unknown. */
    public final String skin;

    public NeedleAppearance(ResourceLocation type, UUID uuid, String name, String skin) {
        this.type = type;
        this.uuid = uuid;
        this.name = name == null ? "" : name;
        this.skin = skin == null ? "" : skin;
    }

    public boolean isPlayer() {
        return uuid != null;
    }

    /** What somebody (or something) looks like right now. */
    public static NeedleAppearance of(LivingEntity e) {
        if (e instanceof Player p) {
            String skin = "";
            for (Property prop : p.getGameProfile().getProperties().get("textures")) {
                skin = prop.getValue();
                break;
            }
            return new NeedleAppearance(PLAYER, p.getGameProfile().getId(), p.getGameProfile().getName(), skin);
        }
        ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        return new NeedleAppearance(key == null ? PLAYER : key, null, e.getName().getString(), "");
    }

    // ---- NBT (kept across logins and deaths) ----
    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("type", type.toString());
        if (uuid != null) t.putUUID("uuid", uuid);
        t.putString("name", name);
        t.putString("skin", skin);
        return t;
    }

    public static NeedleAppearance load(CompoundTag t) {
        ResourceLocation type = ResourceLocation.tryParse(t.getString("type"));
        if (type == null) return null;
        return new NeedleAppearance(type, t.hasUUID("uuid") ? t.getUUID("uuid") : null, t.getString("name"), t.getString("skin"));
    }

    // ---- network ----
    public void write(FriendlyByteBuf b) {
        b.writeResourceLocation(type);
        b.writeBoolean(uuid != null);
        if (uuid != null) b.writeUUID(uuid);
        b.writeUtf(name, 128);
        b.writeUtf(skin, 32767);
    }

    public static NeedleAppearance read(FriendlyByteBuf b) {
        ResourceLocation type = b.readResourceLocation();
        UUID uuid = b.readBoolean() ? b.readUUID() : null;
        String name = b.readUtf(128);
        String skin = b.readUtf(32767);
        return new NeedleAppearance(type, uuid, name, skin);
    }

    /** Same look? (Used by the client to decide whether its cached model is still right.) */
    public boolean sameAs(NeedleAppearance o) {
        return o != null && type.equals(o.type) && java.util.Objects.equals(uuid, o.uuid) && name.equals(o.name) && skin.equals(o.skin);
    }
}
