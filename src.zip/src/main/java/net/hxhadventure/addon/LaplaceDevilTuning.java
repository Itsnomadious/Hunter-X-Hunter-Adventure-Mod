package net.hxhadventure.addon;

/** Numbers for Tserriednich Hui Guo Rou's Laplace Devil (Hatsu kit 24, Specialists). Change them here. */
public final class LaplaceDevilTuning {
    private LaplaceDevilTuning() {}

    /** Chance that a Specialist's random Hatsu roll becomes Laplace Devil (checked before the Chains / Skill Hunter / Doctor Blythe roll). */
    public static final double SPECIALIST_CHANCE = 0.25;

    // ---- activation (entering Zetsu with this Hatsu) ----
    public static final int MIN_LEVEL = 10;
    public static final float ACTIVATE_COST = 200f;
    /** Nen drained per second while the domain is up (Zetsu regenerates far more than this). 0 = none. */
    public static final float UPKEEP_PER_SECOND = 4f;
    /** After the domain ends (you leave Zetsu), before Zetsu can open another one. */
    public static final int COOLDOWN_TICKS = 600;

    // ---- the domain ----
    /** Radius of the dome around the user, blocks. Whoever is inside it at the moment of activation is affected, for as long as it lasts. */
    public static final double RADIUS = 36.0;
    /** The Devil appears this far straight above the user and never moves, blocks. */
    public static final double DEVIL_HEIGHT = 41.0;
    /** true = the user's allies (Black Voice antennas, tamed pets, teammates) are affected too. false = they still see the real user. */
    public static final boolean AFFECT_ALLIES = false;

    // ---- the double (the "fake" user the affected see) ----
    /** true = affected hostile mobs that have no target are drawn to the double when it is this close, blocks. */
    public static final boolean DOUBLE_DRAWS_HOSTILES = true;
    public static final double DOUBLE_DRAW_RANGE = 16.0;
    /** How far from where it appeared the double wanders when nothing is fighting it, blocks. */
    public static final double DOUBLE_WANDER = 6.0;
    /**
     * The double is made in Ten with the user's own Ten buffs (damage, durability, speed, Jump Boost II), worked out from their Ten level
     * even though the user is in Zetsu. When it gets a target it enters Ren (Ten's buffs x Ren's multiplier, plus the user's Ren Vows,
     * exactly like a player's Ren) and drops back to Ten after it has had no target for this long, ticks.
     */
    public static final int REN_LINGER_TICKS = 100;
    /** Its Attack: the same single punch a Ren user's Attack makes (base damage x spirit bonus x Ten/Ren bonus x affinity). */
    public static final float ATTACK_DAMAGE = 5.0f;
    public static final float ATTACK_RANGE = 1.5f;
    public static final double ATTACK_KNOCKBACK = 0.5;
    /** Ticks between two Attacks while its target is in reach. */
    public static final int ATTACK_GAP_TICKS = 10;
    /** Chase speed of its melee goal (1.0 = a walk). */
    public static final double DOUBLE_CHASE_SPEED = 1.5;
    /** true = the whole domain collapses when the double is killed. false = the user stays hidden, the affected just have nothing left to fight. */
    public static final boolean ENDS_WHEN_DOUBLE_DIES = false;

    // ---- the real user while hidden ----
    /** true = affected creatures can never land a hit on the real user (a backstop: they cannot target them anyway). */
    public static final boolean AFFECTED_CANNOT_HIT_USER = true;
}
