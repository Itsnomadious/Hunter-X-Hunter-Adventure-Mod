package net.hxhadventure.addon;

import java.util.UUID;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Crazy Slots' clown, the mascot of Kite's Hatsu. It floats around beside its user, near their right shoulder and facing them, with the
 * roulette on its tongue: idle it shows a "?", while the wheel spins it flickers through the numbers, and when the wheel stops it shows
 * the number that was drawn. All the rules live in {@link CrazySlots}; this is only the body (it cannot be hit, pushed or collided with).
 */
public class CrazySlotsEntity extends MascotEntity {
    public static final int PHASE_IDLE = 0, PHASE_ROLLING = 1, PHASE_LANDED = 2;

    /** What the roulette is doing. */
    private static final EntityDataAccessor<Integer> PHASE = SynchedEntityData.defineId(CrazySlotsEntity.class, EntityDataSerializers.INT);
    /** The number the wheel stopped on (1-9), 0 while there is none. */
    private static final EntityDataAccessor<Integer> NUMBER = SynchedEntityData.defineId(CrazySlotsEntity.class, EntityDataSerializers.INT);

    /** The owner's entity id, so the client can keep the clown locked to their shoulder every frame (-1 until bound). */
    private static final EntityDataAccessor<Integer> OWNER_ID = SynchedEntityData.defineId(CrazySlotsEntity.class, EntityDataSerializers.INT);

    private UUID ownerId;
    private boolean placed;

    public CrazySlotsEntity(EntityType<? extends CrazySlotsEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(PHASE, PHASE_IDLE);
        this.entityData.define(NUMBER, 0);
        this.entityData.define(OWNER_ID, -1);
    }

    public void bind(Player owner) {
        this.ownerId = owner.getUUID();
        this.entityData.set(OWNER_ID, owner.getId());
    }

    public int ownerEntityId() { return this.entityData.get(OWNER_ID); }

    /**
     * Where the clown's feet hover for this owner: around their right shoulder, drifting a little ({@code CLOWN_DRIFT_*}). It follows the
     * owner's BODY (not where they look), so it stays by the shoulder instead of swinging round when the head turns. Same on both sides:
     * {@code pt} is the partial tick (1 on the server), {@code time} drives the bob and the drift.
     */
    public static Vec3 hoverPoint(LivingEntity owner, float pt, double time) {
        float yaw = Mth.rotLerp(pt, owner.yBodyRotO, owner.yBodyRot) * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x); // the user's right hand (facing +Z, the right is -X)
        Vec3 base = owner.getPosition(pt);
        double shoulderY = base.y + owner.getEyeHeight() - 0.24; // the shoulder line: a little under the eyes
        double bob = Math.sin(time * 0.14) * 0.06;
        // a slow wander around the shoulder spot: each axis has its own two slow waves so the path never settles into an obvious circle
        double side = CrazySlotsTuning.CLOWN_SIDE
            + CrazySlotsTuning.CLOWN_DRIFT_SIDE * (Math.sin(time * 0.037 + 1.3) * 0.7 + Math.sin(time * 0.091) * 0.3);
        double ahead = CrazySlotsTuning.CLOWN_FORWARD
            + CrazySlotsTuning.CLOWN_DRIFT_FORWARD * (Math.sin(time * 0.029) * 0.7 + Math.cos(time * 0.073 + 0.4) * 0.3);
        double lift = CrazySlotsTuning.CLOWN_DRIFT_UP * (Math.sin(time * 0.053 + 0.7) * 0.7 + Math.sin(time * 0.117) * 0.3);
        return new Vec3(
            base.x + right.x * side + fwd.x * ahead,
            shoulderY + CrazySlotsTuning.CLOWN_RAISE + bob + lift,
            base.z + right.z * side + fwd.z * ahead);
    }

    public UUID ownerId() { return ownerId; }

    public int phase() { return this.entityData.get(PHASE); }

    public int number() { return this.entityData.get(NUMBER); }

    public void startRolling() {
        this.entityData.set(NUMBER, 0);
        this.entityData.set(PHASE, PHASE_ROLLING);
    }

    public void land(int number) {
        this.entityData.set(NUMBER, Mth.clamp(number, 0, 9));
        this.entityData.set(PHASE, PHASE_LANDED);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        float h = CrazySlotsTuning.CLOWN_HEIGHT;
        return EntityDimensions.fixed(h * 0.7f, h);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) return;

        Player owner = ownerId == null ? null : sl.getPlayerByUUID(ownerId);
        if (owner == null || !owner.isAlive() || !CrazySlots.isTrackedClown(getUUID())) {
            discard(); // the owner is gone, or the Hatsu is (death, restart, another Hatsu): nothing to hover beside
            return;
        }
        // hover beside the user, above their right shoulder, turned toward them (the client also re-locks it to the shoulder every frame)
        Vec3 hover = hoverPoint(owner, 1f, tickCount);
        double wantX = hover.x, wantY = hover.y, wantZ = hover.z;
        if (!placed) {
            placed = true;
            this.setPos(wantX, wantY, wantZ);
        } else {
            this.setPos(getX() + (wantX - getX()) * 0.6, getY() + (wantY - getY()) * 0.6, getZ() + (wantZ - getZ()) * 0.6);
        }
        float want = (float) (Mth.atan2(-(owner.getX() - getX()), owner.getZ() - getZ()) * (180.0 / Math.PI));
        this.setYRot(Mth.rotLerp(0.3f, getYRot(), want));
    }
}
