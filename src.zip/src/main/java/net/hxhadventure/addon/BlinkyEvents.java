package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks for {@link Blinky}. Self-registering, so no existing event class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class BlinkyEvents {
    private BlinkyEvents() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) Blinky.serverTick(ServerLifecycleHooks.getCurrentServer());
    }

    /** A left-click on a creature with Blinky in hand is a swing of the head, not a punch. */
    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent e) {
        if (e.getEntity().level().isClientSide() || !(e.getEntity() instanceof ServerPlayer sp)) return;
        if (!Blinky.holdingHead(sp)) return;
        e.setCanceled(true);
        Blinky.swingLight(sp);
    }

    /**
     * The head is a mouth, not a pickaxe: it does not break blocks by being hit against them (it sucks them, with right-click).
     * Cancelled on both sides, so the client does not start a crack animation the server would only refuse.
     */
    @SubscribeEvent
    public static void onPunchBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (Blinky.holdingHead(e.getEntity())) e.setCanceled(true);
    }

    /** Putting the head down is putting it away: it is conjured, so it never lands on the ground. */
    @SubscribeEvent
    public static void onToss(ItemTossEvent e) {
        if (Blinky.isHead(e.getEntity().getItem())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent e) {
        Blinky.stripHeadDrops(e.getDrops());
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) Blinky.clear(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) Blinky.clear(sp);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) Blinky.onLogin(sp);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        Blinky.reset();
    }
}
