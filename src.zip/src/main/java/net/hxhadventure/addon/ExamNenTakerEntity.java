package net.hxhadventure.addon;

import java.util.UUID;
import net.hxhadventure.abilities.Combat;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * A Nen user among the test takers of Menchi's test (see {@link ExamBattle}): level 10 in everything, with Ten / Ren / Ken like the other Nen
 * fighters. Unlike them it fights its own kind, attacks the nearest contestant or player, and has no Hatsu. It wears the same skins as the
 * other test takers, drops nothing, is not saved, and fades if its test is no longer running.
 */
public class ExamNenTakerEntity extends NenFighter implements ExamContestant {
    public static final NpcStats STATS = new NpcStats("exam_nen_taker", Combat.NEN_ENHANCEMENT)
        .levels(10, 10, 10, 10)
        .body(40.0, 0.26, 0.1, 0.5f)
        .melee(1.0f, 2.4)
        .look("whiteaura_ten", 0xC9C3B0, 0x1C2447);

    static {
        STATS.xp = 0;
    }

    /** Aura colours, picked by skin so the Nen users do not all glow the same. */
    public static final String[] AURAS = {"whiteaura_ten", "redaura_ten", "light_blueaura_ten", "greenaura_ten", "yellowaura_ten", "purpleaura_ten", "pinkaura_ten", "tealaura_ten"};

    private static final EntityDataAccessor<Integer> SKIN = SynchedEntityData.defineId(ExamNenTakerEntity.class, EntityDataSerializers.INT);

    private UUID battle;
    private int orphanTicks;

    public ExamNenTakerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, STATS);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(SKIN, 0);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.targetSelector.addGoal(2, new ExamFightGoal(this));
    }

    @Override
    protected void tickHatsu(@Nullable LivingEntity target, boolean fighting) {
        // no Hatsu: Ten, Ren, Ken and their fists
    }

    /** They fight their own kind too, so only the dead, armour stands and players who are not playing are left out. */
    @Override
    protected boolean validTarget(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof ArmorStand) return false;
        return !(e instanceof Player p && (p.isCreative() || p.isSpectator()));
    }

    // ------------------------------------------------------------------ skin

    public int skin() {
        return Math.floorMod(this.entityData.get(SKIN), ExamTakerEntity.SKINS);
    }

    @Override
    public void setSkin(int skin) {
        this.entityData.set(SKIN, Math.floorMod(skin, ExamTakerEntity.SKINS));
    }

    // ------------------------------------------------------------------ battle

    @Override
    public void setBattle(UUID player) {
        this.battle = player;
    }

    @Override
    public UUID battleId() {
        return battle;
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && battle != null && isDeadOrDying()) ExamBattle.onTakerDown(battle, getUUID());
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) return;
        if (battle != null && !ExamBattle.isActive(battle) && ++orphanTicks > 40) fade(sl);
    }

    @Override
    public void fade(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.9, getZ(), 12, 0.3, 0.5, 0.3, 0.02);
        discard();
    }

    @Override
    protected boolean shouldDropLoot() {
        return false;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }
}
