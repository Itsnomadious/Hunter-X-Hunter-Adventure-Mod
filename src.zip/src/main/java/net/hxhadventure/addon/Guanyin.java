package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketGuanyinFx;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Isaac Netero's 100-Type Guanyin Bodhisattva (Hatsu kit 17, Enhancers). Numbers are all in {@link GuanyinTuning}.
 *
 * <p><b>Praying (H).</b> Pressing H prays (clasped hands, as long as the user's prayers have made a prayer take). It is optional and there is
 * no Vow: the user can simply attack. An attack made after a finished prayer counts as one prayer followed by an attack; after
 * {@link GuanyinTuning#GRATITUDE_NEEDED} of them the user is <b>enlightened</b> (the Guanyin Netero uses).
 *
 * <p><b>Before enlightenment</b> the statue is manifested from the Z menu skill "100-Type Guanyin Bodhisattva", and only while it stands can the
 * Guanyin's attacks, the four hands and the Aspect be used. Every move is {@link GuanyinTuning#SLOW_SPEED} as fast as its base speed.
 *
 * <p><b>Enlightened:</b> every move works without the statue (it shows for the length of the move), H now manifests the statue fully instead of
 * praying, Attack / Strong attack / Barrage have no cooldown, the hands are {@link GuanyinTuning#TRUE_SPEED} x the base speed, all other cooldowns are
 * 30% shorter, damage is +10%, and the manifested statue costs as much aura as Ren at the user's level. Moves:
 * <ol>
 *   <li><b>Aspect of Guanyin</b> (Z): a flash of the golden hand to the user's left, then an Aura Blast leaves it: golden, 50 blocks longer
 *       and 3 blocks wider than the normal one ({@link AuraBlast#beam}).</li>
 *   <li><b>100-Type Guanyin Bodhisattva</b> (Z, toggle): a giant golden statue stands behind the user. While it stands the user's Attack,
 *       Strong attack and Barrage are done by the statue instead, in a 6 x 6 area starting at the user. It costs aura every second, and
 *       only while it stands can the next moves be used:</li>
 *   <li><b>First Hand</b>: the statue chops one hand down.</li>
 *   <li><b>Third Hand</b>: the statue claps, trapping everything caught between its hands and dealing massive damage.</li>
 *   <li><b>Ninety-ninth Hand</b>: a barrage of palm strikes from every arm.</li>
 *   <li><b>Zero Hand</b>: the statue grasps the target from behind, then ALL the user's Nen goes into one beam from its mouth; +1% damage
 *       for every 1000 Nen spent.</li>
 * </ol>
 * The statue itself is drawn on the client (GuanyinRenderer); the server keeps the state and does the damage.
 */
public final class Guanyin {
    private Guanyin() {}

    public static final int KIT = 17;
    public static final String ASPECT_ID = "guanyin_aspect";
    public static final String SUMMON_ID = "guanyin_summon";
    public static final String FIRST_ID = "guanyin_first_hand";
    public static final String THIRD_ID = "guanyin_third_hand";
    public static final String NINETY_ID = "guanyin_ninety_ninth_hand";
    public static final String ZERO_ID = "guanyin_zero_hand";

    private static final String N_ASPECT = "Aspect of Guanyin", N_SUMMON = "100-Type Guanyin Bodhisattva", N_FIRST = "First Hand",
        N_THIRD = "Third Hand", N_NINETY = "Ninety-ninth Hand", N_ZERO = "Zero Hand";

    private enum Kind { ASPECT, FIRST, THIRD, NINETY, ZERO }

    /** The one move being carried out (they never overlap). */
    private static final class Act {
        final Kind kind;
        int ticks;
        Vec3 pos = Vec3.ZERO, dir = Vec3.ZERO;
        UUID target;
        float used;
        int windup;      // ticks of wind-up / charge, already scaled by the speed of the move
        float acc;       // hits owed (the Ninety-ninth Hand's rate follows the speed)
        Vec3 base = Vec3.ZERO;   // Zero Hand: where the statue stands (behind the target)
        Vec3 facing = Vec3.ZERO; // Zero Hand: the way it faces (toward the user, flat)
        final List<UUID> held = new ArrayList<>();

        Act(Kind kind) { this.kind = kind; }
    }

    private static final Set<UUID> SUMMONED = ConcurrentHashMap.newKeySet();
    /** Prayers in progress (owner -> gameTime it finishes), and finished prayers still waiting for an attack to count. */
    private static final Map<UUID, Long> PRAYING = new ConcurrentHashMap<>();
    private static final Set<UUID> PRAYED = ConcurrentHashMap.newKeySet();
    /** Enlightened users without the full manifestation: gameTime until which the statue stays in view for a move. */
    private static final Map<UUID, Long> SHOWN_UNTIL = new ConcurrentHashMap<>();
    private static final Map<UUID, Float> PALM_ACC = new ConcurrentHashMap<>();
    /** Client side: entity ids of the players with the statue out (kept up to date by PacketGuanyinFx). */
    private static final Set<Integer> CLIENT = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Act> ACTS = new ConcurrentHashMap<>();
    private static final Map<String, Long> READY = new ConcurrentHashMap<>();
    private static final Map<UUID, Boolean> PALM_LEFT = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> PALM_READY = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> STRONG_START = new ConcurrentHashMap<>(), STRONG_LAST = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> BARRAGE_LAST = new ConcurrentHashMap<>(), BARRAGE_TICKS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> BARRAGE_COOL = new ConcurrentHashMap<>();

    // ---------------------------------------------------------------- state (both sides)

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    public static boolean isSummoned(Player p) {
        if (p == null) return false;
        return p.level().isClientSide ? CLIENT.contains(p.getId()) : SUMMONED.contains(p.getUUID());
    }

    public static boolean clientHas(int entityId) { return CLIENT.contains(entityId); }

    public static void setClient(int entityId, boolean on) {
        if (on) CLIENT.add(entityId);
        else CLIENT.remove(entityId);
    }

    public static void clearClient() {
        CLIENT.clear();
        CLIENT_AWAKE = false;
    }

    /** Client side: whether the local player is enlightened (the server tells it, see {@link #tick}). */
    private static volatile boolean CLIENT_AWAKE = false;
    /** Server side: what each player's client was last told about their enlightenment. */
    private static final Map<UUID, Boolean> AWAKE_SENT = new ConcurrentHashMap<>();

    public static void setClientEnlightened(boolean on) { CLIENT_AWAKE = on; }

    private static boolean awakeFor(Player p) {
        if (p == null) return false;
        return p.level().isClientSide ? CLIENT_AWAKE : p instanceof ServerPlayer sp && enlightened(sp);
    }

    /** The Z / R menu: every Guanyin skill from its level. (Whether the statue has to be out is checked when the move is used.) */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c)) return base;
        int lvl = c.getHatsuLevel();
        List<String> out = new ArrayList<>(Arrays.asList(base));
        // gone once enlightened: from then on H manifests the statue, and the moves need no statue
        if (lvl >= GuanyinTuning.SUMMON_MIN_LEVEL && !awakeFor(c.getPlayer())) out.add(SUMMON_ID);
        if (lvl >= GuanyinTuning.ASPECT_MIN_LEVEL) out.add(ASPECT_ID);
        if (lvl >= GuanyinTuning.FIRST_MIN_LEVEL) out.add(FIRST_ID);
        if (lvl >= GuanyinTuning.THIRD_MIN_LEVEL) out.add(THIRD_ID);
        if (lvl >= GuanyinTuning.NINETY_NINTH_MIN_LEVEL) out.add(NINETY_ID);
        if (lvl >= GuanyinTuning.ZERO_MIN_LEVEL) out.add(ZERO_ID);
        return out.toArray(new String[0]);
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> abilities) {
        abilities.put(ASPECT_ID, Guanyin::aspect);
        abilities.put(SUMMON_ID, Guanyin::summon);
        abilities.put(FIRST_ID, Guanyin::firstHand);
        abilities.put(THIRD_ID, Guanyin::thirdHand);
        abilities.put(NINETY_ID, Guanyin::ninetyNinthHand);
        abilities.put(ZERO_ID, Guanyin::zeroHand);
    }

    public static String displayName(String id) {
        return switch (id) {
            case ASPECT_ID -> "§6 " + N_ASPECT;
            case SUMMON_ID -> "§6 " + N_SUMMON;
            case FIRST_ID -> "§6 Guanyin: " + N_FIRST;
            case THIRD_ID -> "§6 Guanyin: " + N_THIRD;
            case NINETY_ID -> "§6 Guanyin: " + N_NINETY;
            case ZERO_ID -> "§6 Guanyin: " + N_ZERO;
            default -> null;
        };
    }

    // ---------------------------------------------------------------- the gate

    /** The gamerule "hxhgrateful": neither the prayer Vow nor the gratitude is needed. */
    private static boolean vowWaived(ServerPlayer sp) {
        return sp.level().getGameRules().getBoolean(NenGameRules.GRATEFUL);
    }

    /**
     * Enlightened: 10000 prayers followed by an attack (or the gamerule "hxhgrateful"). Only for a Guanyin user. This is the "true" Guanyin:
     * no statue needed for any move, no cooldown on the basic attacks, faster hands, shorter cooldowns, more damage.
     */
    public static boolean enlightened(ServerPlayer sp) {
        if (!canUse(Combat.get(sp))) return false;
        if (vowWaived(sp)) return true;
        NenAddonData d = NenAddonData.peek(sp);
        return d != null && d.prayers >= GuanyinTuning.GRATITUDE_NEEDED;
    }

    /** The speed of the statue's moves for this user: slow before enlightenment, fast after. */
    private static float speed(ServerPlayer sp) {
        return enlightened(sp) ? GuanyinTuning.TRUE_SPEED : GuanyinTuning.SLOW_SPEED;
    }

    /** Base ticks of a wind-up / charge, stretched or shrunk by the speed of the move. */
    private static int ticks(ServerPlayer sp, int base) {
        return Math.max(1, Math.round(base / speed(sp)));
    }

    private static float damageMult(ServerPlayer sp) {
        return enlightened(sp) ? GuanyinTuning.TRUE_DAMAGE_MULT : 1f;
    }

    private static Combat gate(ServerPlayer sp, int minLevel, String name, boolean needStatue) {
        Combat c = Combat.get(sp);
        if (c == null) return null;
        if (!canUse(c)) {
            say(sp, "§cYour Hatsu is not the 100-Type Guanyin Bodhisattva");
            return null;
        }
        if (c.getHatsuLevel() < minLevel) {
            say(sp, "§c" + name + " unlocks at Level " + minLevel);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            say(sp, "§5Forced Zetsu: your aura will not answer");
            return null;
        }
        if (needStatue && !SUMMONED.contains(sp.getUUID()) && !enlightened(sp)) {
            say(sp, "§cManifest the 100-Type Guanyin Bodhisattva first (Z menu)");
            return null;
        }
        if (ACTS.containsKey(sp.getUUID())) return null; // one move at a time
        return c;
    }

    private static void say(ServerPlayer sp, String msg) {
        sp.displayClientMessage(Component.literal(msg), true);
    }

    private static boolean ready(ServerPlayer sp, String name) {
        long at = READY.getOrDefault(sp.getUUID() + name, 0L);
        return !ChainManager.onCooldown(sp, name, (int) Math.max(0, at - sp.level().getGameTime()));
    }

    private static void cooldown(ServerPlayer sp, String name, int ticks) {
        if (enlightened(sp)) ticks = Math.round(ticks * GuanyinTuning.TRUE_COOLDOWN_MULT);
        READY.put(sp.getUUID() + name, sp.level().getGameTime() + ticks);
        ChainManager.startCooldown(sp, name, ticks);
    }

    private static boolean pay(ServerPlayer sp, Combat c, float cost) {
        if (c.getCurrentEnergy() < cost) {
            say(sp, "§cNot enough energy");
            return false;
        }
        c.consumeEnergy(cost);
        return true;
    }

    private static boolean hostile(ServerPlayer sp, LivingEntity e) {
        return e != sp && e.isAlive() && !(e instanceof ArmorStand) && !AllianceUtils.isAlly(e, sp);
    }

    private static void hurt(ServerPlayer sp, LivingEntity e, float amount) {
        e.invulnerableTime = 0;
        Vows.hatsuHurt(e, sp.level().damageSources().playerAttack(sp), amount * Vows.hatsuDamageMult(sp) * damageMult(sp)); // the Hatsu skill: more damage
    }

    private static void fx(ServerPlayer sp, int type, Vec3 pos, Vec3 dir, int extra) {
        AddonNetwork.sendToTrackingAndSelf(new PacketGuanyinFx(sp.getId(), type, pos, dir, extra), sp);
    }

    // ---------------------------------------------------------------- geometry (the client draws the statue at the same place)

    /** The way the user's body faces, flat. */
    private static Vec3 forward(ServerPlayer sp) {
        double yaw = Math.toRadians(sp.yBodyRot);
        return new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
    }

    private static Vec3 flatLook(ServerPlayer sp) {
        double yaw = Math.toRadians(sp.getYRot());
        return new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
    }

    private static Vec3 statueBase(ServerPlayer sp) {
        return sp.position().subtract(forward(sp).scale(GuanyinTuning.STATUE_BACK));
    }

    /** Zero Hand: the way the statue faces, flat: from where it stands (behind the target, on the far side from the user) back toward the user. */
    private static Vec3 zeroFacing(ServerPlayer sp, LivingEntity target) {
        Vec3 d = sp.position().subtract(target.position());
        double len = Math.hypot(d.x, d.z);
        return len < 1.0e-4 ? flatLook(sp).scale(-1) : new Vec3(d.x / len, 0, d.z / len);
    }

    /** Zero Hand: where the statue's lotus is: ZERO_BEHIND blocks behind the target, on the far side from the user (facing points at the user, so subtracting it moves away from them), on the ground below if there is any. */
    private static Vec3 zeroBase(ServerLevel level, LivingEntity target, Vec3 facing) {
        Vec3 p = target.position().subtract(facing.scale(GuanyinTuning.ZERO_BEHIND));
        BlockHitResult down = level.clip(new ClipContext(p.add(0, 3, 0), p.add(0, -24, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, target));
        return down.getType() == HitResult.Type.MISS ? p : new Vec3(p.x, down.getLocation().y, p.z);
    }

    /** Zero Hand: the statue's mouth, wherever the statue stands for this act. */
    private static Vec3 zeroMouth(Vec3 base, Vec3 facing) {
        return base.add(0, GuanyinTuning.STATUE_MOUTH_HEIGHT, 0).add(facing.scale(GuanyinTuning.STATUE_MOUTH_FORWARD));
    }

    /** The hostile creature the user is looking at, or null. */
    private static LivingEntity findTarget(ServerPlayer sp, double range) {
        return findTarget(sp, range, 0.0);
    }

    /** Same, but the aiming tolerance also grows by this many blocks per block of distance, so far targets are as easy to pick as near ones. */
    private static LivingEntity findTarget(ServerPlayer sp, double range, double tolPerBlock) {
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle().normalize();
        AABB box = new AABB(eye, eye.add(look.scale(range))).inflate(3.0 + range * tolPerBlock);
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : sp.level().getEntitiesOfClass(LivingEntity.class, box, e -> hostile(sp, e))) {
            Vec3 v = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(eye);
            double proj = v.dot(look);
            if (proj < 0 || proj > range) continue;
            double perp = v.subtract(look.scale(proj)).length();
            if (perp > 2.0 + e.getBbWidth() + proj * tolPerBlock) continue;
            double score = proj + perp * 3.0;
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    /** Where a hand comes down: on the target if there is one, otherwise where the user is looking (ground level). */
    private static Vec3 aimPoint(ServerPlayer sp, double range) {
        LivingEntity t = findTarget(sp, range);
        if (t != null) return t.position();
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle().normalize();
        HitResult hit = sp.level().clip(new ClipContext(eye, eye.add(look.scale(range)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        Vec3 p = hit.getType() == HitResult.Type.MISS ? eye.add(look.scale(Math.min(range, 16.0))) : hit.getLocation();
        HitResult down = sp.level().clip(new ClipContext(p.add(0, 3, 0), p.add(0, -14, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        return down.getType() == HitResult.Type.MISS ? p : down.getLocation();
    }

    // ---------------------------------------------------------------- Aspect of Guanyin

    public static void aspect(ServerPlayer sp) {
        Combat c = gate(sp, GuanyinTuning.ASPECT_MIN_LEVEL, N_ASPECT, true); // only the enlightened can use it without the statue
        if (c == null || !ready(sp, N_ASPECT) || !pay(sp, c, GuanyinTuning.ASPECT_COST)) return;
        cooldown(sp, N_ASPECT, GuanyinTuning.ASPECT_COOLDOWN_TICKS);
        Vec3 dir = sp.getLookAngle().normalize();
        double rad = Math.toRadians(sp.getYRot());
        Vec3 left = new Vec3(Math.cos(rad), 0, Math.sin(rad)); // the opposite of AuraBlast's "right"
        Vec3 origin = sp.getEyePosition().add(left.scale(GuanyinTuning.ASPECT_SIDE)).add(dir.scale(1.5)).add(0, -0.3, 0);
        Act a = new Act(Kind.ASPECT);
        a.pos = origin;
        a.dir = dir;
        a.windup = ticks(sp, GuanyinTuning.ASPECT_FLASH_TICKS);
        ACTS.put(sp.getUUID(), a);
        showFor(sp, Math.max(3, a.windup) + 2 + GuanyinTuning.TEMP_SHOW_AFTER_TICKS); // the flash's own length on the client
        fx(sp, PacketGuanyinFx.FLASH, origin, dir, a.windup);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.2f, 0.5f);
    }

    // ---------------------------------------------------------------- the statue

    public static void summon(ServerPlayer sp) {
        if (SUMMONED.contains(sp.getUUID())) {
            dismiss(sp, true);
            return;
        }
        Combat c = gate(sp, GuanyinTuning.SUMMON_MIN_LEVEL, N_SUMMON, false);
        if (c == null || !ready(sp, N_SUMMON) || !pay(sp, c, GuanyinTuning.SUMMON_COST)) return;
        SUMMONED.add(sp.getUUID());
        SHOWN_UNTIL.remove(sp.getUUID());
        fx(sp, PacketGuanyinFx.ON, Vec3.ZERO, Vec3.ZERO, 0);
        say(sp, "§6☯ 100-Type Guanyin Bodhisattva §7(your attacks are now the statue's)");
        if (sp.level() instanceof ServerLevel level) {
            Vec3 b = statueBase(sp);
            level.playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.5f);
            level.playSound(null, sp.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.PLAYERS, 0.6f, 1.6f);
            level.sendParticles(ParticleTypes.END_ROD, b.x, b.y + 3, b.z, 80, 1.5, 3.0, 1.5, 0.15);
            level.sendParticles(ParticleTypes.FLASH, b.x, b.y + 4, b.z, 1, 0, 0, 0, 0);
        }
    }

    /** Enlightened users: the statue shows for at least this many more ticks, even though it is not fully manifested. */
    private static void showFor(ServerPlayer sp, int ticks) {
        UUID u = sp.getUUID();
        if (SUMMONED.contains(u)) return;
        long until = sp.level().getGameTime() + ticks;
        Long was = SHOWN_UNTIL.get(u);
        if (was != null && was >= until) return;
        SHOWN_UNTIL.put(u, until);
        if (was == null) fx(sp, PacketGuanyinFx.ON, Vec3.ZERO, Vec3.ZERO, 0);
    }

    /** The statue goes away (toggled off, no aura left, Zetsu, death, a lost Hatsu). Whatever it was doing stops. */
    public static void dismiss(ServerPlayer sp, boolean message) {
        if (!SUMMONED.remove(sp.getUUID())) return;
        endActs(sp);
        STRONG_START.remove(sp.getUUID());
        STRONG_LAST.remove(sp.getUUID());
        BARRAGE_LAST.remove(sp.getUUID());
        BARRAGE_TICKS.remove(sp.getUUID());
        fx(sp, PacketGuanyinFx.OFF, Vec3.ZERO, Vec3.ZERO, 0);
        cooldown(sp, N_SUMMON, GuanyinTuning.SUMMON_COOLDOWN_TICKS);
        if (message) say(sp, "§7The Guanyin fades");
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.0f, 0.6f);
    }

    private static void endActs(ServerPlayer sp) {
        Act a = ACTS.remove(sp.getUUID());
        if (a != null) release(sp, a);
    }

    /** Anyone still held by a Third Hand is let go. */
    private static void release(ServerPlayer sp, Act a) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        for (UUID id : a.held) {
            if (level.getEntity(id) instanceof LivingEntity e) HatsuEffects.removeStun(e);
        }
        a.held.clear();
    }

    // ---------------------------------------------------------------- H: pray (before enlightenment) / manifest (after)

    /** H. Before enlightenment it prays (optional, no Vow); once enlightened it manifests or puts away the statue. */
    public static void hPressed(ServerPlayer sp) {
        if (enlightened(sp)) {
            summon(sp);
            return;
        }
        pray(sp);
    }

    private static void pray(ServerPlayer sp) {
        UUID u = sp.getUUID();
        if (PRAYING.containsKey(u)) return; // a prayer is not cut short
        if (PRAYED.contains(u)) {
            say(sp, "§6Your prayer is ready §7(attack to complete it)");
            return;
        }
        NenAddonData d = NenAddonData.get(sp);
        int ticks = Prayer.prayerTicks(d.prayers);
        PRAYING.put(u, sp.level().getGameTime() + ticks);
        AddonNetwork.sendToTrackingAndSelf(new net.hxhadventure.addon.network.PacketPrayFx(sp.getId(), ticks, 0), sp);
    }

    private static void finishPrayer(ServerPlayer sp) {
        UUID u = sp.getUUID();
        PRAYING.remove(u);
        AddonNetwork.sendToTrackingAndSelf(new net.hxhadventure.addon.network.PacketPrayFx(sp.getId(), 0), sp);
        if (!sp.isAlive()) return;
        PRAYED.add(u);
        say(sp, "§6Prayer ready §7(your next attack counts)");
        if (sp.level() instanceof ServerLevel level) {
            Vec3 look = sp.getLookAngle();
            level.sendParticles(ParticleTypes.END_ROD, sp.getX() + look.x * 0.5, sp.getY() + 1.2, sp.getZ() + look.z * 0.5, 4, 0.12, 0.1, 0.12, 0.01);
        }
    }

    /** An attack made after a finished prayer: one prayer followed by an attack. The 10000th makes the user enlightened. */
    private static void noteAttack(String id, ServerPlayer sp) {
        if (!"nen_attack".equals(id) && !"nen_strong_release".equals(id) && !"nen_barrage".equals(id)) return;
        UUID u = sp.getUUID();
        if (!PRAYED.contains(u)) return;
        Combat c = Combat.get(sp);
        if (!canUse(c)) return;
        PRAYED.remove(u);
        NenAddonData d = NenAddonData.get(sp);
        if (d.prayers >= GuanyinTuning.GRATITUDE_NEEDED) return;
        d.prayers++;
        d.markSave();
        if (d.prayers >= GuanyinTuning.GRATITUDE_NEEDED && sp.level() instanceof ServerLevel level) {
            say(sp, "§6You are enlightened: the 100-Type Guanyin Bodhisattva answers without its statue");
            level.playSound(null, sp.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.8f);
            level.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1, sp.getZ(), 80, 1.0, 1.5, 1.0, 0.1);
        }
    }

    // ---------------------------------------------------------------- Attack / Strong attack / Barrage become the statue's

    /**
     * Called before every ability runs (AbilityRegistryMixin), after the Vow's prayer gate. While the statue stands, the user's three basic
     * attacks are carried out by it instead and this returns true (the normal attack is cancelled).
     */
    public static boolean interceptBasic(String id, ServerPlayer sp) {
        UUID u = sp.getUUID();
        noteAttack(id, sp);
        if (!SUMMONED.contains(u)) return false;
        if (!"nen_attack".equals(id) && !"nen_strong".equals(id) && !"nen_strong_release".equals(id) && !"nen_barrage".equals(id)) return false;
        Combat c = Combat.get(sp);
        if (c == null || ACTS.containsKey(u)) return true; // mid-move: the statue is busy
        long now = sp.level().getGameTime();
        switch (id) {
            case "nen_attack" -> {
                if (now < PALM_READY.getOrDefault(u, 0L)) return true;
                PALM_READY.put(u, now + attackGap(sp));
                palm(sp, c, GuanyinTuning.ATTACK_DAMAGE, GuanyinTuning.ATTACK_KNOCKBACK, 0);
            }
            case "nen_strong" -> {
                STRONG_LAST.put(u, sp.tickCount);
                STRONG_START.putIfAbsent(u, sp.tickCount);
            }
            case "nen_strong_release" -> {
                Integer start = STRONG_START.remove(u);
                STRONG_LAST.remove(u);
                if (start == null || now < PALM_READY.getOrDefault(u, 0L)) return true;
                PALM_READY.put(u, now + attackGap(sp));
                float progress = Math.min(1f, (sp.tickCount - start) / (float) ticks(sp, GuanyinTuning.STRONG_CHARGE_TICKS));
                float dmg = GuanyinTuning.ATTACK_DAMAGE + (GuanyinTuning.STRONG_DAMAGE - GuanyinTuning.ATTACK_DAMAGE) * progress;
                double kb = GuanyinTuning.ATTACK_KNOCKBACK + (GuanyinTuning.STRONG_KNOCKBACK - GuanyinTuning.ATTACK_KNOCKBACK) * progress;
                palm(sp, c, dmg, kb, progress >= 1f ? 1 : 0);
            }
            case "nen_barrage" -> {
                if (now < BARRAGE_COOL.getOrDefault(u, 0L)) return true;
                BARRAGE_LAST.put(u, sp.tickCount);
                BARRAGE_TICKS.putIfAbsent(u, 0);
            }
            default -> { }
        }
        return true;
    }

    /** Ticks between the statue's single strikes: none once enlightened, and slower than the base before. */
    private static int attackGap(ServerPlayer sp) {
        return enlightened(sp) ? 0 : Math.round(GuanyinTuning.ATTACK_COOLDOWN_TICKS / GuanyinTuning.SLOW_SPEED);
    }

    private static int barrageGap(ServerPlayer sp) {
        return enlightened(sp) ? 0 : Math.round(GuanyinTuning.BARRAGE_COOLDOWN_TICKS / GuanyinTuning.SLOW_SPEED);
    }

    /** One strike of the statue's palm: everything hostile in the 6 x 6 area that starts at the user and runs 6 blocks ahead. */
    private static void palm(ServerPlayer sp, Combat c, float damage, double knockback, int strength) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        Vec3 f = flatLook(sp);
        double half = GuanyinTuning.ATTACK_REACH * 0.5;
        Vec3 centre = sp.position().add(f.scale(half));
        AABB box = new AABB(centre.x - half, sp.getY() - 1.0, centre.z - half, centre.x + half, sp.getY() + GuanyinTuning.ATTACK_REACH - 1.0, centre.z + half);
        float total = damage * c.getSpiritBonus();
        boolean any = false;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> hostile(sp, e))) {
            hurt(sp, e, total);
            e.knockback(knockback, sp.getX() - e.getX(), sp.getZ() - e.getZ());
            e.hurtMarked = true;
            any = true;
        }
        boolean left = PALM_LEFT.merge(sp.getUUID(), true, (was, x) -> !was); // alternate hands, offset to the side so the view stays clear
        fx(sp, PacketGuanyinFx.PALM, centre.add(0, 1.5, 0), f, strength | (left ? 2 : 0) | (Math.round(speed(sp) * 100f) << 2)); // bits 2+: the speed in percent, for the client's animation
        level.playSound(null, sp.blockPosition(), strength > 0 ? SoundEvents.GENERIC_EXPLODE : SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, strength > 0 ? 1.0f : 0.8f, 0.7f);
        if (any) level.sendParticles(ParticleTypes.CRIT, centre.x, centre.y + 1.2, centre.z, 12, half * 0.5, 0.8, half * 0.5, 0.2);
    }

    // ---------------------------------------------------------------- First Hand: the chop

    public static void firstHand(ServerPlayer sp) {
        Combat c = gate(sp, GuanyinTuning.FIRST_MIN_LEVEL, N_FIRST, true);
        if (c == null || !ready(sp, N_FIRST) || !pay(sp, c, GuanyinTuning.FIRST_COST)) return;
        cooldown(sp, N_FIRST, GuanyinTuning.FIRST_COOLDOWN_TICKS);
        Act a = new Act(Kind.FIRST);
        a.pos = aimPoint(sp, GuanyinTuning.FIRST_THIRD_RANGE);
        a.dir = flatLook(sp);
        a.windup = ticks(sp, GuanyinTuning.FIRST_WINDUP_TICKS);
        ACTS.put(sp.getUUID(), a);
        showFor(sp, a.windup + 16 + GuanyinTuning.TEMP_SHOW_AFTER_TICKS);
        fx(sp, PacketGuanyinFx.FIRST, a.pos, a.dir, a.windup);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.2f, 0.7f);
    }

    private static void landFirst(ServerPlayer sp, ServerLevel level, Combat c, Act a) {
        float dmg = GuanyinTuning.FIRST_BASE_DAMAGE + c.getHatsuLevel() * GuanyinTuning.FIRST_DAMAGE_PER_LEVEL;
        AABB box = new AABB(a.pos, a.pos).inflate(GuanyinTuning.FIRST_RADIUS, 3.0, GuanyinTuning.FIRST_RADIUS);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> hostile(sp, e))) {
            double d = e.position().distanceTo(a.pos);
            if (d > GuanyinTuning.FIRST_RADIUS + e.getBbWidth()) continue;
            hurt(sp, e, dmg);
            e.setDeltaMovement(e.getDeltaMovement().add((e.getX() - a.pos.x) * 0.15, 0.6, (e.getZ() - a.pos.z) * 0.15));
            e.hurtMarked = true;
        }
        impact(level, a.pos, GuanyinTuning.FIRST_RADIUS);
    }

    private static void impact(ServerLevel level, Vec3 p, double radius) {
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.x, p.y + 0.5, p.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.END_ROD, p.x, p.y + 1.0, p.z, 60, radius * 0.4, 0.6, radius * 0.4, 0.35);
        level.sendParticles(ParticleTypes.CLOUD, p.x, p.y + 0.3, p.z, 40, radius * 0.5, 0.2, radius * 0.5, 0.2);
        level.playSound(null, net.minecraft.core.BlockPos.containing(p), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 2.0f, 0.6f);
        level.playSound(null, net.minecraft.core.BlockPos.containing(p), SoundEvents.IRON_GOLEM_DAMAGE, SoundSource.PLAYERS, 2.0f, 0.5f);
    }

    // ---------------------------------------------------------------- Third Hand: the clap

    public static void thirdHand(ServerPlayer sp) {
        Combat c = gate(sp, GuanyinTuning.THIRD_MIN_LEVEL, N_THIRD, true);
        if (c == null || !ready(sp, N_THIRD) || !pay(sp, c, GuanyinTuning.THIRD_COST)) return;
        cooldown(sp, N_THIRD, GuanyinTuning.THIRD_COOLDOWN_TICKS);
        Act a = new Act(Kind.THIRD);
        a.pos = aimPoint(sp, GuanyinTuning.FIRST_THIRD_RANGE);
        a.dir = flatLook(sp);
        a.windup = ticks(sp, GuanyinTuning.THIRD_WINDUP_TICKS);
        ACTS.put(sp.getUUID(), a);
        showFor(sp, a.windup + GuanyinTuning.THIRD_HOLD_TICKS + 8 + GuanyinTuning.TEMP_SHOW_AFTER_TICKS);
        // the client takes the wind-up from the direction's y (it is flat otherwise), so its animation follows the speed
        fx(sp, PacketGuanyinFx.THIRD, a.pos, new Vec3(a.dir.x, a.windup, a.dir.z), a.windup + GuanyinTuning.THIRD_HOLD_TICKS);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.2f, 0.6f);
    }

    private static void clap(ServerPlayer sp, ServerLevel level, Combat c, Act a) {
        float dmg = GuanyinTuning.THIRD_BASE_DAMAGE + c.getHatsuLevel() * GuanyinTuning.THIRD_DAMAGE_PER_LEVEL;
        AABB box = new AABB(a.pos, a.pos).inflate(GuanyinTuning.THIRD_RADIUS, 4.0, GuanyinTuning.THIRD_RADIUS);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> hostile(sp, e))) {
            if (e.position().distanceTo(a.pos) > GuanyinTuning.THIRD_RADIUS + e.getBbWidth()) continue;
            hurt(sp, e, dmg);
            a.held.add(e.getUUID());
            HatsuEffects.stun(e, GuanyinTuning.THIRD_HOLD_TICKS);
        }
        impact(level, a.pos, GuanyinTuning.THIRD_RADIUS);
    }

    // ---------------------------------------------------------------- Ninety-ninth Hand: the barrage

    public static void ninetyNinthHand(ServerPlayer sp) {
        Combat c = gate(sp, GuanyinTuning.NINETY_NINTH_MIN_LEVEL, N_NINETY, true);
        if (c == null || !ready(sp, N_NINETY) || !pay(sp, c, GuanyinTuning.NINETY_COST)) return;
        cooldown(sp, N_NINETY, GuanyinTuning.NINETY_COOLDOWN_TICKS);
        Act a = new Act(Kind.NINETY);
        a.pos = sp.position();
        a.dir = flatLook(sp);
        ACTS.put(sp.getUUID(), a);
        showFor(sp, GuanyinTuning.NINETY_DURATION_TICKS + 6 + GuanyinTuning.TEMP_SHOW_AFTER_TICKS);
        fx(sp, PacketGuanyinFx.NINETY, a.pos, a.dir, GuanyinTuning.NINETY_DURATION_TICKS);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.2f, 0.9f);
    }

    private static void barrageHit(ServerPlayer sp, ServerLevel level, Combat c, Act a) {
        float dmg = GuanyinTuning.NINETY_HIT_DAMAGE + c.getHatsuLevel() * GuanyinTuning.NINETY_DAMAGE_PER_LEVEL;
        Vec3 f = a.dir;
        double half = GuanyinTuning.NINETY_HALF_WIDTH;
        Vec3 side = new Vec3(-f.z, 0, f.x);
        Vec3 centre = sp.position().add(f.scale(GuanyinTuning.NINETY_REACH * 0.5));
        AABB box = new AABB(centre, centre).inflate(GuanyinTuning.NINETY_REACH * 0.5 + 1, 5.0, GuanyinTuning.NINETY_REACH * 0.5 + 1);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> hostile(sp, e))) {
            Vec3 v = e.position().subtract(sp.position());
            double along = v.dot(f), across = Math.abs(v.dot(side));
            if (along < -0.5 || along > GuanyinTuning.NINETY_REACH || across > half + e.getBbWidth() * 0.5) continue;
            hurt(sp, e, dmg);
            e.setDeltaMovement(f.x * 0.12, Math.max(e.getDeltaMovement().y, 0.04), f.z * 0.12);
            e.hurtMarked = true;
        }
        Vec3 p = sp.position().add(f.scale(2 + level.random.nextDouble() * (GuanyinTuning.NINETY_REACH - 2))).add(side.scale((level.random.nextDouble() - 0.5) * 2 * half)).add(0, 0.5 + level.random.nextDouble() * 2.5, 0);
        level.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 4, 0.3, 0.3, 0.3, 0.05);
        if (a.ticks % 6 == 0) level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.PLAYERS, 1.0f, 0.6f + level.random.nextFloat() * 0.4f);
    }

    // ---------------------------------------------------------------- Zero Hand

    public static void zeroHand(ServerPlayer sp) {
        Combat c = gate(sp, GuanyinTuning.ZERO_MIN_LEVEL, N_ZERO, true);
        if (c == null || !ready(sp, N_ZERO)) return;
        LivingEntity target = findTarget(sp, GuanyinTuning.ZERO_TARGET_RANGE, GuanyinTuning.ZERO_AIM_TOLERANCE);
        if (target == null) {
            say(sp, "§cZero Hand needs a target in sight");
            return;
        }
        float used = c.getCurrentEnergy();
        if (used < GuanyinTuning.ZERO_MIN_ENERGY) {
            say(sp, "§cNot enough energy: Zero Hand spends ALL of it, and needs at least " + (int) GuanyinTuning.ZERO_MIN_ENERGY);
            return;
        }
        c.consumeEnergy(used); // ALL of it
        cooldown(sp, N_ZERO, GuanyinTuning.ZERO_COOLDOWN_TICKS);
        Act a = new Act(Kind.ZERO);
        a.target = target.getUUID();
        a.pos = target.position();
        a.facing = zeroFacing(sp, target);
        a.base = sp.level() instanceof ServerLevel zl ? zeroBase(zl, target, a.facing) : a.pos.subtract(a.facing.scale(GuanyinTuning.ZERO_BEHIND));
        a.dir = a.facing;
        a.used = used;
        a.windup = ticks(sp, GuanyinTuning.ZERO_CHARGE_TICKS);
        ACTS.put(sp.getUUID(), a);
        showFor(sp, a.windup + 18 + GuanyinTuning.TEMP_SHOW_AFTER_TICKS);
        // pos = the target's feet, dir.xz = the way the statue faces (toward the user), dir.y = the ground the statue stands on (the client works out the rest)
        fx(sp, PacketGuanyinFx.ZERO, a.pos, new Vec3(a.facing.x, a.base.y, a.facing.z), a.windup);
        say(sp, "§6Zero Hand: " + (int) used + " Nen");
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.WARDEN_SONIC_CHARGE, SoundSource.PLAYERS, 2.0f, 0.5f);
    }

    /** Damage of the Zero Hand beam for this much Nen: +1% of the base for every 1000 Nen. */
    public static float zeroDamage(float nenUsed) {
        return GuanyinTuning.ZERO_BASE_DAMAGE * (1f + GuanyinTuning.ZERO_DAMAGE_PER_NEN_BLOCK * (nenUsed / GuanyinTuning.ZERO_NEN_BLOCK));
    }

    private static void fireZero(ServerPlayer sp, ServerLevel level, Act a) {
        Vec3 from = zeroMouth(a.base, a.facing);
        Vec3 aim = a.pos.add(0, 1.0, 0);
        if (level.getEntity(a.target) instanceof LivingEntity t && t.isAlive()) aim = t.position().add(0, t.getBbHeight() * 0.5, 0);
        Vec3 dir = aim.subtract(from);
        dir = dir.lengthSqr() < 1.0e-4 ? sp.getLookAngle() : dir.normalize();
        float dmg = zeroDamage(a.used) * Vows.power(sp, ZERO_ID) * damageMult(sp);
        AuraBlast.beam(sp, from, dir, GuanyinTuning.ZERO_RANGE, GuanyinTuning.ZERO_EXTRA_RADIUS, dmg, 0, 0.0, true);
        sp.displayClientMessage(Component.literal("§6Zero Hand: +" + Math.round(GuanyinTuning.ZERO_DAMAGE_PER_NEN_BLOCK * 100f * a.used / GuanyinTuning.ZERO_NEN_BLOCK) + "% damage"), true);
    }

    // ---------------------------------------------------------------- per tick

    public static void tick(ServerPlayer sp) {
        UUID u = sp.getUUID();
        if (!(sp.level() instanceof ServerLevel level)) return;
        Combat c = Combat.get(sp);
        Act a = ACTS.get(u);
        if (a != null) tickAct(sp, level, c, a);

        if (sp.tickCount % 20 == 0 || !AWAKE_SENT.containsKey(u)) {
            boolean awake = enlightened(sp);
            Boolean sent = AWAKE_SENT.get(u);
            if (sent == null && !awake) {
                AWAKE_SENT.put(u, false); // the client already assumes "not enlightened": nothing to say
            } else if (sent == null || sent != awake) {
                AWAKE_SENT.put(u, awake);
                AddonNetwork.sendToPlayer(new PacketGuanyinFx(sp.getId(), awake ? PacketGuanyinFx.AWAKE : PacketGuanyinFx.ASLEEP), sp);
            }
        }
        Long prayEnd = PRAYING.get(u);
        if (prayEnd != null && (!sp.isAlive() || !canUse(c) || level.getGameTime() >= prayEnd)) finishPrayer(sp);
        Long shownUntil = SHOWN_UNTIL.get(u);
        if (shownUntil != null && !SUMMONED.contains(u) && (level.getGameTime() >= shownUntil || !sp.isAlive())) {
            SHOWN_UNTIL.remove(u);
            fx(sp, PacketGuanyinFx.OFF, Vec3.ZERO, Vec3.ZERO, 0);
        }

        if (!SUMMONED.contains(u)) return;
        NenAddonData d = NenAddonData.peek(sp);
        if (c == null || !sp.isAlive() || !canUse(c) || ExtrasHooks.hatsuForced(sp) || (d != null && d.zetsu)) {
            dismiss(sp, sp.isAlive());
            return;
        }
        if (sp.tickCount % 20 == 0) { // the statue is paid for by the second
            float upkeep = enlightened(sp) ? Tuning.renUpkeep(c.getMaxEnergy()) : GuanyinTuning.SUMMON_UPKEEP; // enlightened: as much as Ren at this level
            if (c.getCurrentEnergy() < upkeep) {
                say(sp, "§cThe Guanyin fades: your aura is spent");
                dismiss(sp, false);
                return;
            }
            c.consumeEnergy(upkeep);
        }
        if (sp.tickCount % 4 == 0) {
            Vec3 b = statueBase(sp);
            level.sendParticles(ParticleTypes.END_ROD, b.x + (level.random.nextDouble() - 0.5) * 5, b.y + level.random.nextDouble() * 9, b.z + (level.random.nextDouble() - 0.5) * 3, 1, 0, 0.05, 0, 0.01);
        }
        tickBasics(sp, level, c);
    }

    private static void tickBasics(ServerPlayer sp, ServerLevel level, Combat c) {
        UUID u = sp.getUUID();
        Integer lastStrong = STRONG_LAST.get(u);
        if (lastStrong != null && sp.tickCount - lastStrong > 5) { // the key-up got lost: drop the charge
            STRONG_LAST.remove(u);
            STRONG_START.remove(u);
        }
        Integer lastB = BARRAGE_LAST.get(u);
        if (lastB == null) return;
        int n = BARRAGE_TICKS.getOrDefault(u, 0);
        if (sp.tickCount - lastB > 5 || n >= GuanyinTuning.BARRAGE_MAX_TICKS) {
            BARRAGE_LAST.remove(u);
            BARRAGE_TICKS.remove(u);
            BARRAGE_COOL.put(u, level.getGameTime() + barrageGap(sp));
            return;
        }
        BARRAGE_TICKS.put(u, n + 1);
        // the barrage lands a palm for every whole hit it is owed: fewer than one a tick while slow, more than one when enlightened
        float acc = PALM_ACC.getOrDefault(u, 0f) + speed(sp);
        for (int i = 0; i < 2 && acc >= 1f; i++, acc -= 1f) {
            if (!ACTS.containsKey(u)) palm(sp, c, GuanyinTuning.BARRAGE_HIT_DAMAGE, GuanyinTuning.BARRAGE_KNOCKBACK, 0);
        }
        PALM_ACC.put(u, Math.min(acc, 1f));
    }

    private static void tickAct(ServerPlayer sp, ServerLevel level, Combat c, Act a) {
        UUID u = sp.getUUID();
        if (!sp.isAlive() || c == null) {
            endActs(sp);
            return;
        }
        a.ticks++;
        switch (a.kind) {
            case ASPECT -> {
                if (a.ticks >= a.windup) {
                    float base = GuanyinTuning.ASPECT_BASE_DAMAGE + c.getHatsuLevel() * GuanyinTuning.ASPECT_DAMAGE_PER_LEVEL;
                    base *= Vows.power(sp, ASPECT_ID) * damageMult(sp);
                    AuraBlast.beam(sp, a.pos, a.dir, Tuning.BLAST_RANGE + GuanyinTuning.ASPECT_EXTRA_RANGE, GuanyinTuning.ASPECT_EXTRA_RADIUS, base, 0, 0.4, true, GuanyinTuning.ASPECT_KNOCKBACK_MULT);
                    ACTS.remove(u);
                }
            }
            case FIRST -> {
                if (a.ticks >= a.windup) {
                    landFirst(sp, level, c, a);
                    ACTS.remove(u);
                }
            }
            case THIRD -> {
                if (a.ticks == a.windup) clap(sp, level, c, a);
                if (a.ticks > a.windup) {
                    for (UUID id : a.held) { // trapped in the grasp: they cannot move
                        if (level.getEntity(id) instanceof LivingEntity e && e.isAlive()) {
                            e.setDeltaMovement(0, Math.min(0, e.getDeltaMovement().y), 0);
                            e.hurtMarked = true;
                        }
                    }
                }
                if (a.ticks >= a.windup + GuanyinTuning.THIRD_HOLD_TICKS) {
                    release(sp, a);
                    ACTS.remove(u);
                }
            }
            case NINETY -> {
                a.acc += speed(sp) / GuanyinTuning.NINETY_HIT_EVERY_TICKS; // hits per tick follow the speed of the hands
                for (int i = 0; i < 2 && a.acc >= 1f; i++, a.acc -= 1f) barrageHit(sp, level, c, a);
                if (a.ticks % 5 == 0) sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 3, false, false, false));
                if (a.ticks >= GuanyinTuning.NINETY_DURATION_TICKS) ACTS.remove(u);
            }
            case ZERO -> {
                if (a.ticks < a.windup) {
                    if (a.ticks == 1) { // the statue appears behind the target
                        level.sendParticles(ParticleTypes.END_ROD, a.base.x, a.base.y + 3, a.base.z, 60, 1.5, 3.0, 1.5, 0.12);
                        level.sendParticles(ParticleTypes.FLASH, a.base.x, a.base.y + 4, a.base.z, 1, 0, 0, 0, 0);
                        level.playSound(null, BlockPos.containing(a.base), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.5f);
                    }
                    if (level.getEntity(a.target) instanceof LivingEntity t && t.isAlive()) { // held, tenderly, from behind
                        a.pos = t.position();
                        t.setDeltaMovement(0, Math.min(0, t.getDeltaMovement().y), 0);
                        t.hurtMarked = true;
                        if (a.ticks % 10 == 1) HatsuEffects.stun(t, 20);
                    }
                    sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 4, false, false, false));
                    Vec3 m = zeroMouth(a.base, a.facing);
                    float p = a.ticks / (float) a.windup;
                    level.sendParticles(ParticleTypes.END_ROD, m.x, m.y, m.z, 2 + (int) (p * 8), 0.8 * (1 - p) + 0.1, 0.8 * (1 - p) + 0.1, 0.8 * (1 - p) + 0.1, 0.02);
                } else if (a.ticks == a.windup) {
                    fireZero(sp, level, a);
                } else if (a.ticks >= a.windup + 15) {
                    ACTS.remove(u);
                }
            }
        }
    }

    // ---------------------------------------------------------------- housekeeping

    /** A player who comes into view of someone with the statue out sees it at once. */
    public static void sendTo(ServerPlayer owner, ServerPlayer viewer) {
        if (SUMMONED.contains(owner.getUUID()) || SHOWN_UNTIL.containsKey(owner.getUUID())) AddonNetwork.sendToPlayer(new PacketGuanyinFx(owner.getId(), PacketGuanyinFx.ON), viewer);
    }

    /** Death, logout, a new Hatsu or lost Nen: everything is put away. */
    public static void clear(Player p) {
        UUID u = p.getUUID();
        if (p instanceof ServerPlayer sp) {
            endActs(sp);
            if (SUMMONED.remove(u)) fx(sp, PacketGuanyinFx.OFF, Vec3.ZERO, Vec3.ZERO, 0);
        } else {
            SUMMONED.remove(u);
            ACTS.remove(u);
        }
        PALM_READY.remove(u);
        PALM_ACC.remove(u);
        AWAKE_SENT.remove(u);
        PRAYING.remove(u);
        PRAYED.remove(u);
        if (SHOWN_UNTIL.remove(u) != null && p instanceof ServerPlayer sp2) fx(sp2, PacketGuanyinFx.OFF, Vec3.ZERO, Vec3.ZERO, 0);
        STRONG_START.remove(u);
        STRONG_LAST.remove(u);
        BARRAGE_LAST.remove(u);
        BARRAGE_TICKS.remove(u);
        BARRAGE_COOL.remove(u);
        READY.keySet().removeIf(k -> k.startsWith(u.toString()));
    }
}
