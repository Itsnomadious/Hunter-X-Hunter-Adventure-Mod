package net.hxhadventure.addon;

/** Numbers for the Hunter Exam guide NPC (see {@link ExamGuideEntity}, {@link VillageGuides}, {@link ExamGuide}). */
public final class ExamGuideTuning {
    private ExamGuideTuning() {}

    /** Master switch: false stops new guides from appearing in villages (existing ones stay). */
    public static final boolean ENABLED = true;

    /** How often (ticks) the loaded villages are checked for a missing guide. 40 = every 2 seconds. */
    public static final int CHECK_INTERVAL_TICKS = 40;

    /** Most guides created per check, so a burst of freshly loaded villages never causes a lag spike. */
    public static final int MAX_SPAWNS_PER_CHECK = 2;

    /** How far (blocks) from the village centre the guide may be placed. */
    public static final int SPAWN_RADIUS = 8;

    /** How many "regions" around the player the exam hall search covers (1 region = the structure's spacing, 100 chunks = 1600 blocks). 12 = about 19,000 blocks. */
    public static final int SEARCH_RINGS = 12;

    /** A known hall closer than this (blocks) is answered straight away, without searching. */
    public static final int QUICK_ANSWER_DISTANCE = 400;

    /** Closer than this (blocks) the guide says the hall is right here instead of giving a direction. */
    public static final int HERE_DISTANCE = 120;

    /** Ticks a player must wait between questions. 60 = 3 seconds. */
    public static final int ASK_COOLDOWN_TICKS = 60;

    /** Whether the guide also gives x / z coordinates (rounded to {@link #COORD_ROUNDING}) next to the distance and direction. */
    public static final boolean SHOW_COORDINATES = true;
    public static final int COORD_ROUNDING = 10;
}
