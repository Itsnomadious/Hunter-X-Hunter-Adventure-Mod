package net.hxhadventure.addon;

import java.util.EnumSet;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.entity.custom.KiteEntity;

/**
 * How Kite fights: with his own Crazy Slots weapons. The carbine (a burst of bullets, with the same spread and distance falloff a player's has)
 * while the target is away, the scythe up close. The staff is only ever in his hand against Neferpitou, where he uses it for quick hits and
 * its sweep. The numbers are in {@link CrazySlotsTuning} (KITE_*), next to the weapons' own.
 */
public class KiteCrazyGoal extends Goal {
    private enum Gun { CARBINE, SCYTHE, STAFF }

    private final KiteEntity kite;
    private Gun gun;
    private int switchLock, burstLeft, pause, fireGap, meleeGap, sweepCooldown, shotsInRow, repath;

    public KiteCrazyGoal(KiteEntity kite) {
        this.kite = kite;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = kite.getTarget();
        return t != null && t.isAlive() && !kite.isAwakening();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void start() {
        kite.setAggressive(true);
        gun = null;
        burstLeft = CrazySlotsTuning.KITE_BURST_SHOTS;
        pause = fireGap = meleeGap = shotsInRow = 0;
    }

    @Override
    public void stop() {
        kite.setAggressive(false);
        kite.getNavigation().stop();
        kite.weaponDamageMult = 1f;
        kite.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY); // the weapon is put away when the fight is over
        gun = null;
    }

    @Override
    public void tick() {
        LivingEntity t = kite.getTarget();
        if (t == null || !(kite.level() instanceof ServerLevel level)) return;
        double dist = Math.sqrt(kite.distanceToSqr(t));
        kite.getLookControl().setLookAt(t, 40f, 40f);
        if (switchLock > 0) switchLock--;
        if (meleeGap > 0) meleeGap--;
        if (sweepCooldown > 0) sweepCooldown--;
        choose(t, dist);
        switch (gun) {
            case CARBINE -> carbine(level, t, dist);
            case SCYTHE -> melee(level, t, dist, false);
            case STAFF -> melee(level, t, dist, true);
        }
    }

    /** The staff only against Neferpitou; otherwise the carbine from range and the scythe up close (with a gap between the two distances, so he does not flicker between them). */
    private void choose(LivingEntity t, double dist) {
        Gun want;
        if (t instanceof NeferpitouEntity) want = Gun.STAFF;
        else if (gun == Gun.CARBINE) want = dist < CrazySlotsTuning.KITE_SCYTHE_DISTANCE ? Gun.SCYTHE : Gun.CARBINE;
        else if (gun == Gun.SCYTHE) want = dist > CrazySlotsTuning.KITE_CARBINE_DISTANCE ? Gun.CARBINE : Gun.SCYTHE;
        else want = dist > CrazySlotsTuning.KITE_SCYTHE_DISTANCE ? Gun.CARBINE : Gun.SCYTHE; // first pick, or the staff after Neferpitou is gone
        if (want == gun || (gun != null && switchLock > 0 && want != Gun.STAFF)) return;
        gun = want;
        switchLock = CrazySlotsTuning.KITE_SWITCH_LOCK_TICKS;
        Item item = switch (gun) {
            case CARBINE -> CrazySlotsItems.CARBINE;
            case SCYTHE -> CrazySlotsItems.SCYTHE;
            case STAFF -> CrazySlotsItems.STAFF;
        };
        kite.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(item));
        kite.setDropChance(EquipmentSlot.MAINHAND, 0f);
        kite.getNavigation().stop();
        burstLeft = CrazySlotsTuning.KITE_BURST_SHOTS;
        pause = 0;
    }

    // ---------------------------------------------------------------- carbine

    private void carbine(ServerLevel level, LivingEntity t, double dist) {
        boolean sees = kite.getSensing().hasLineOfSight(t);
        if (!sees || dist > CrazySlotsTuning.KITE_FIRE_RANGE) {
            if (--repath <= 0) { kite.getNavigation().moveTo(t, 1.25); repath = 10; }
            return;
        }
        kite.getNavigation().stop(); // he plants his feet to shoot
        if (pause > 0) {
            if (--pause == 0) shotsInRow = 0; // the spread settles during the pause
            return;
        }
        if (--fireGap > 0) return;
        fireGap = CrazySlotsTuning.CARBINE_FIRE_INTERVAL_TICKS;
        shoot(level, t);
        if (--burstLeft <= 0) {
            burstLeft = CrazySlotsTuning.KITE_BURST_SHOTS;
            pause = CrazySlotsTuning.KITE_BURST_PAUSE_TICKS;
        }
    }

    /** The same bullet as a player's: hitscan with spread (and bloom in a long burst), and damage that falls off with the distance it travelled. */
    private void shoot(ServerLevel level, LivingEntity target) {
        Vec3 eye = kite.getEyePosition();
        Vec3 aim = target.position().add(0, target.getBbHeight() * 0.6, 0);
        double sp = CrazySlotsTuning.CARBINE_SPREAD + Math.min(CrazySlotsTuning.CARBINE_SPREAD_BLOOM_MAX, shotsInRow * CrazySlotsTuning.CARBINE_SPREAD_BLOOM_PER_SHOT);
        shotsInRow++;
        Vec3 dir = aim.subtract(eye).normalize();
        dir = dir.add(level.random.nextGaussian() * sp, level.random.nextGaussian() * sp, level.random.nextGaussian() * sp).normalize();
        double range = CrazySlotsTuning.CARBINE_RANGE;
        Vec3 end = eye.add(dir.scale(range));
        BlockHitResult bh = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, kite));
        Vec3 stop = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
        AABB box = kite.getBoundingBox().expandTowards(dir.scale(range)).inflate(1.0);
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(level, kite, eye, stop, box,
            e -> e instanceof LivingEntity le && le.isAlive() && (le == target || le instanceof Enemy || le instanceof NeferpitouEntity));
        if (eh != null) stop = eh.getLocation();

        Vec3 from = eye.add(dir.scale(1.2)).add(0, -0.25, 0);
        double len = from.distanceTo(stop);
        for (double d = 1.0; d < len; d += 3.0) {
            Vec3 at = from.add(dir.scale(d));
            level.sendParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 1, 0, 0, 0, 0);
        }
        level.playSound(null, kite.blockPosition(), SoundEvents.ARROW_SHOOT, SoundSource.NEUTRAL, CrazySlotsTuning.CARBINE_SOUND_VOLUME, 1.9f);
        SwingUtil.forceSwing(kite, InteractionHand.MAIN_HAND);

        if (eh != null && eh.getEntity() instanceof LivingEntity hit) {
            float dmg = (CrazySlotsTuning.CARBINE_DAMAGE + CrazySlotsTuning.KITE_HATSU_LEVEL * CrazySlotsTuning.CARBINE_DAMAGE_PER_LEVEL)
                * CrazySlotsTuning.carbineFalloff(eye.distanceTo(stop));
            hit.invulnerableTime = 0;
            hit.hurt(level.damageSources().mobAttack(kite), dmg);
            level.sendParticles(ParticleTypes.CRIT, stop.x, stop.y, stop.z, 3, 0.1, 0.1, 0.1, 0.2);
        }
    }

    // ---------------------------------------------------------------- scythe and staff

    private void melee(ServerLevel level, LivingEntity t, double dist, boolean staff) {
        double edge = dist - t.getBbWidth() * 0.5;
        if (edge > CrazySlotsTuning.KITE_REACH) {
            if (--repath <= 0) { kite.getNavigation().moveTo(t, 1.25); repath = 8; }
            return;
        }
        kite.getNavigation().stop();
        if (staff && sweepCooldown <= 0 && edge <= CrazySlotsTuning.SWEEP_RANGE) {
            sweepCooldown = CrazySlotsTuning.SWEEP_COOLDOWN_TICKS;
            sweep(level, t);
            meleeGap = CrazySlotsTuning.KITE_MELEE_GAP_TICKS;
            return;
        }
        if (meleeGap > 0) return;
        meleeGap = CrazySlotsTuning.KITE_MELEE_GAP_TICKS;
        kite.weaponDamageMult = staff ? 1f : CrazySlotsTuning.SCYTHE_ATTACK_MULT; // the scythe's Attack multiplier
        kite.doHurtTarget(t);
        kite.weaponDamageMult = 1f;
    }

    /** The staff's sweep, the same as a player's (50% more than his Attack, an arc in front of him); here it is used on Neferpitou. */
    private void sweep(ServerLevel level, LivingEntity target) {
        Vec3 f = kite.getLookAngle().multiply(1, 0, 1);
        f = f.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : f.normalize();
        double range = CrazySlotsTuning.SWEEP_RANGE;
        double minDot = Math.cos(Math.toRadians(CrazySlotsTuning.SWEEP_ARC_DEGREES * 0.5));
        float dmg = (float) kite.getAttributeValue(Attributes.ATTACK_DAMAGE) * CrazySlotsTuning.SWEEP_DAMAGE_MULT;
        AABB box = kite.getBoundingBox().inflate(range, 1.0, range);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> e == target || e instanceof Enemy || e instanceof NeferpitouEntity)) {
            double dx = e.getX() - kite.getX(), dz = e.getZ() - kite.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > range + e.getBbWidth() * 0.5) continue;
            if (d > 0.6 && (dx * f.x + dz * f.z) / d < minDot) continue;
            e.invulnerableTime = 0;
            e.hurt(level.damageSources().mobAttack(kite), dmg);
            e.knockback(CrazySlotsTuning.SWEEP_KNOCKBACK, -dx, -dz);
        }
        Vec3 right = new Vec3(-f.z, 0, f.x);
        for (int i = -2; i <= 2; i++) {
            double a = Math.toRadians(i * CrazySlotsTuning.SWEEP_ARC_DEGREES / 5.0);
            Vec3 d = f.scale(Math.cos(a)).add(right.scale(Math.sin(a)));
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, kite.getX() + d.x * range * 0.7, kite.getY() + 1.1, kite.getZ() + d.z * range * 0.7, 1, 0, 0, 0, 0);
        }
        level.playSound(null, kite.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.NEUTRAL, 1.2f, 0.9f);
        SwingUtil.forceSwing(kite, InteractionHand.MAIN_HAND);
    }
}
