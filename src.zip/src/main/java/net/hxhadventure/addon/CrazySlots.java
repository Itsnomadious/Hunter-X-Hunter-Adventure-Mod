package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetCarriedItemPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.level.BlockEvent;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketCrazySlotsFx;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Kite's Crazy Slots (Hatsu kit 29, Conjurers): a clown whose tongue is a roulette, and a different weapon behind every number.
 *
 * <ol>
 *   <li><b>H</b> summons the clown ({@link CrazySlotsEntity}); H again sends it away (unless a weapon is out).</li>
 *   <li><b>Z</b> rolls the roulette. The number is random: you cannot choose the weapon. The clown turns into that weapon in your hand.
 *       The scythe <b>is gone after one use</b>; the staff and the carbine <b>stay for as long as you want</b> and go when you press
 *       <b>H</b> (put away) or die.</li>
 *   <li><b>2: Scythe.</b> Z = <b>Silent Waltz</b>, the only way it can be used: the blade grows, Kite spins once (fast), and a circular slash goes
 *       out at the height of the blade (chest to shoulder) that bisects everything it touches within {@link CrazySlotsTuning#WALTZ_RADIUS} blocks and cuts away the blocks at that height only.
 *       The slash's particles and sounds only play when it actually hits something (a creature, a projectile or a block). One use, then the scythe is gone.</li>
 *   <li><b>3: Staff.</b> Z = a fast sweep attack (50% more than the basic Attack, 2 second cooldown). Die while holding it and you are reborn as a Chimera Ant (see {@link #onDeath}, {@link #onRespawn}).</li>
 *   <li><b>4: Carbine.</b> A suppressed carbine: hold right-click to fire bullets in quick succession (no burst mode).
 *       It holds {@link CrazySlotsTuning#CARBINE_MAGAZINE} rounds and is gone when they are used up (or put away with H).</li>
 * </ol>
 * Numbers 1 and 5-9 have no weapon yet: add one to {@link Weapon} and the wheel draws it. Everything is decided on the server; clients only
 * draw ({@link PacketCrazySlotsFx}, {@code client.CrazySlotsFx}, {@code client.CrazySlotsRenderer}). Forge hooks: {@link CrazySlotsEvents}.
 */
public final class CrazySlots {
    private CrazySlots() {}

    public static final int KIT = 29;
    public static final String ID = "crazy_slots";
    private static final String NAME = "Crazy Slots";

    private static final String OWNER_TAG = "Owner";
    private static final String AMMO_TAG = "Ammo";

    /** The weapons behind the numbers. Add a constant for another number and it is drawn (and conjured by its own item) automatically. */
    public enum Weapon {
        SCYTHE(2, "Scythe"),
        STAFF(3, "Staff"),
        CARBINE(4, "Carbine");

        public final int slot;
        public final String label;

        Weapon(int slot, String label) {
            this.slot = slot;
            this.label = label;
        }

        public static Weapon bySlot(int n) {
            for (Weapon w : values()) if (w.slot == n) return w;
            return null;
        }
    }

    private static final class State {
        UUID clown;
        int toggleCd;
        long readyAt;                 // game time the clown may be summoned again after a weapon was used up
        int rollTicks;                // > 0 while the wheel spins
        int rollSlot;                 // the number that was drawn
        int landTicks;                // > 0 while the number is shown, before the clown becomes the weapon
        int waltzStage;               // 0 none, 1 the blade grows, 2 the spin, 3 the blocks are cut away
        int waltzTicks;
        ResourceKey<Level> waveDim;
        BlockPos waveCenter;
        int[] wave;
        int waveIndex;
        Vec3 slashCentre;             // where the slash's particles and sounds go off (once something is hit)
        boolean slashFxDone;          // they have gone off already
        int sweepTicks;
        long sweepReadyAt;            // game time the staff may sweep again
        long nextShot;
        long lastShotTick;            // for the spread bloom
        int shotsInRow;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();
    /** Clowns that are alive and wanted (the entity checks this: after a restart or a lost Hatsu it removes itself). */
    private static final Set<UUID> CLOWNS = new HashSet<>();

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    private static State state(ServerPlayer sp) {
        return STATES.computeIfAbsent(sp.getUUID(), k -> new State());
    }

    public static boolean isTrackedClown(UUID id) {
        return CLOWNS.contains(id);
    }

    private static void msg(ServerPlayer sp, String text) {
        sp.displayClientMessage(Component.literal(text), true);
    }

    private static void sound(ServerLevel level, Entity at, SoundEvent ev, float vol, float pitch) {
        level.playSound(null, at.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }

    private static boolean hostile(ServerPlayer sp, Entity e) {
        if (!(e instanceof LivingEntity le) || le == sp || !le.isAlive() || e instanceof ArmorStand) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        return !AllianceUtils.isAlly(e, sp);
    }

    /** Common checks for everything the Hatsu does. Returns the player's Combat, or null (after telling them why). */
    private static Combat gate(ServerPlayer sp, int minLevel, String what) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return null;
        if (!canUse(c)) {
            msg(sp, "§cYour Hatsu is not Crazy Slots");
            return null;
        }
        if (c.getHatsuLevel() < minLevel) {
            msg(sp, "§c" + what + " unlocks at Level " + minLevel);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            msg(sp, "§5Forced Zetsu: Crazy Slots will not answer");
            return null;
        }
        if (HatsuEffects.isStunned(sp)) return null;
        return c;
    }

    private static boolean pay(ServerPlayer sp, Combat c, float cost) {
        if (c.getCurrentEnergy() < cost) {
            msg(sp, "§cNot enough energy");
            return false;
        }
        c.consumeEnergy(cost);
        return true;
    }

    private static void hurt(ServerPlayer sp, LivingEntity e, float amount, DamageSource src) {
        e.invulnerableTime = 0;
        Vows.hatsuHurt(e, src, amount * Vows.hatsuDamageMult(sp)); // the Hatsu skill: more damage
    }

    // ---------------------------------------------------------------- the weapons (held items that belong to you)

    private static Item itemOf(Weapon w, boolean big) {
        return switch (w) {
            case SCYTHE -> big ? CrazySlotsItems.SCYTHE_BIG : CrazySlotsItems.SCYTHE;
            case STAFF -> CrazySlotsItems.STAFF;
            case CARBINE -> CrazySlotsItems.CARBINE;
        };
    }

    /** Which weapon this stack is (any owner), or null. */
    public static Weapon weaponOf(ItemStack st) {
        if (st == null || st.isEmpty() || !(st.getItem() instanceof CrazyWeaponItem w)) return null;
        return w.weapon();
    }

    public static boolean isWeapon(ItemStack st) {
        return weaponOf(st) != null;
    }

    public static UUID ownerOf(ItemStack st) {
        return isWeapon(st) && st.hasTag() && st.getTag().hasUUID(OWNER_TAG) ? st.getTag().getUUID(OWNER_TAG) : null;
    }

    public static boolean isOwnWeapon(ItemStack st, Player p) {
        return p.getUUID().equals(ownerOf(st));
    }

    /** The hand that holds this player's weapon (main hand first), or null. */
    public static InteractionHand heldHand(Player p) {
        if (isOwnWeapon(p.getMainHandItem(), p)) return InteractionHand.MAIN_HAND;
        if (isOwnWeapon(p.getOffhandItem(), p)) return InteractionHand.OFF_HAND;
        return null;
    }

    public static Weapon heldWeapon(Player p) {
        InteractionHand h = heldHand(p);
        return h == null ? null : weaponOf(p.getItemInHand(h));
    }

    /** The weapon this player has been given and not yet used, wherever it is in their inventory, or null. */
    public static Weapon pendingWeapon(Player p) {
        for (ItemStack st : p.getInventory().items) if (isOwnWeapon(st, p)) return weaponOf(st);
        for (ItemStack st : p.getInventory().offhand) if (isOwnWeapon(st, p)) return weaponOf(st);
        return null;
    }

    /** Takes every weapon belonging to this player out of their inventory. */
    public static void removeWeapons(ServerPlayer sp) {
        Inventory inv = sp.getInventory();
        for (int i = 0; i < inv.items.size(); i++) if (isOwnWeapon(inv.items.get(i), sp)) inv.items.set(i, ItemStack.EMPTY);
        for (int i = 0; i < inv.offhand.size(); i++) if (isOwnWeapon(inv.offhand.get(i), sp)) inv.offhand.set(i, ItemStack.EMPTY);
    }

    /** The owner died or the weapon was dropped: conjured weapons never lie on the ground. */
    public static void stripWeaponDrops(java.util.Collection<net.minecraft.world.entity.item.ItemEntity> drops) {
        drops.removeIf(ie -> isWeapon(ie.getItem()));
    }

    private static void reform(NonNullList<ItemStack> list, ServerPlayer sp, Item to) {
        for (int i = 0; i < list.size(); i++) {
            ItemStack st = list.get(i);
            if (isOwnWeapon(st, sp) && weaponOf(st) == Weapon.SCYTHE && !st.is(to)) {
                ItemStack n = new ItemStack(to);
                if (st.hasTag()) n.setTag(st.getTag().copy());
                list.set(i, n);
            }
        }
    }

    /** The scythe is the small one until Silent Waltz grows its blade (same item, bigger model). */
    private static void setScytheForm(ServerPlayer sp, boolean big) {
        Item to = itemOf(Weapon.SCYTHE, big);
        if (to == null) return;
        reform(sp.getInventory().items, sp, to);
        reform(sp.getInventory().offhand, sp, to);
    }

    /** Puts the new weapon in the user's hand: the selected hotbar slot if it is free, else any free hotbar slot, else the off hand. */
    private static void giveWeapon(ServerPlayer sp, ItemStack st) {
        Inventory inv = sp.getInventory();
        int slot = -1;
        if (inv.items.get(inv.selected).isEmpty()) slot = inv.selected;
        else for (int i = 0; i < 9; i++) if (inv.items.get(i).isEmpty()) { slot = i; break; }
        if (slot >= 0) {
            inv.items.set(slot, st);
            if (slot != inv.selected) {
                inv.selected = slot;
                sp.connection.send(new ClientboundSetCarriedItemPacket(slot));
            }
        } else if (sp.getOffhandItem().isEmpty()) {
            sp.setItemInHand(InteractionHand.OFF_HAND, st);
        } else { // everything is full: it takes the place of the item in hand, which goes into the inventory (or the floor)
            ItemStack old = inv.items.get(inv.selected);
            inv.items.set(inv.selected, st);
            if (!inv.add(old)) sp.drop(old, false);
        }
    }

    private static ItemStack newWeapon(ServerPlayer sp, Weapon w) {
        ItemStack st = new ItemStack(itemOf(w, false));
        st.getOrCreateTag().putUUID(OWNER_TAG, sp.getUUID());
        st.getOrCreateTag().putString("OwnerName", sp.getName().getString());
        if (w == Weapon.CARBINE && CrazySlotsTuning.CARBINE_USES_AMMO) st.getOrCreateTag().putInt(AMMO_TAG, CrazySlotsTuning.CARBINE_MAGAZINE);
        return st;
    }

    // ---------------------------------------------------------------- list entries

    /** Adds Crazy Slots to the Z scroll once the Hatsu level allows it (H summons the clown; Z rolls, or uses the weapon in hand). */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < CrazySlotsTuning.MIN_LEVEL) return base;
        String[] out = Arrays.copyOf(base, base.length + 1);
        out[base.length] = ID;
        return out;
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(ID, CrazySlots::use);
    }

    public static String displayName(String id) {
        return ID.equals(id) ? "§d Crazy Slots" : null;
    }

    // ---------------------------------------------------------------- the fx packet

    private static boolean armIsLeft(ServerPlayer sp) {
        InteractionHand hand = heldHand(sp);
        boolean mainIsLeft = sp.getMainArm() == HumanoidArm.LEFT;
        return hand == InteractionHand.OFF_HAND ? !mainIsLeft : mainIsLeft;
    }

    private static void fx(ServerPlayer sp, int kind, int ticks) {
        AddonNetwork.sendToTrackingAndSelf(new PacketCrazySlotsFx(sp.getId(), kind, armIsLeft(sp), ticks), sp);
    }

    // ---------------------------------------------------------------- H: summon the clown / send it away

    private static CrazySlotsEntity clownOf(ServerPlayer sp, State s) {
        if (s.clown == null || !(sp.level() instanceof ServerLevel level)) return null;
        return level.getEntity(s.clown) instanceof CrazySlotsEntity e && e.isAlive() ? e : null;
    }

    public static void toggle(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        if (!canUse(c)) {
            msg(sp, "§cYour Hatsu is not Crazy Slots");
            return;
        }
        if (c.getHatsuLevel() < CrazySlotsTuning.MIN_LEVEL) {
            msg(sp, "§c" + NAME + " unlocks at Level " + CrazySlotsTuning.MIN_LEVEL);
            return;
        }
        State s = state(sp);
        Weapon pending = pendingWeapon(sp);
        if (pending == Weapon.SCYTHE) {
            msg(sp, "§7The scythe stays until it has been used");
            return;
        }
        if (pending != null) { // the staff and the carbine stay for as long as the user wants: H puts them away
            putAway(sp, s, pending);
            return;
        }
        CrazySlotsEntity clown = clownOf(sp, s);
        if (clown != null) {
            if (s.rollTicks > 0 || s.landTicks > 0) {
                msg(sp, "§7The wheel is still turning");
                return;
            }
            dismissClown(sp, s, true);
            evoke(sp);
            msg(sp, "§7The clown leaves");
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            msg(sp, "§5Forced Zetsu: Crazy Slots will not answer");
            return;
        }
        if (HatsuEffects.isStunned(sp)) return;
        if (ChainManager.onCooldown(sp, NAME, s.toggleCd)) return;
        long left = s.readyAt - sp.level().getGameTime();
        if (ChainManager.onCooldown(sp, NAME, (int) left)) return;
        if (!(sp.level() instanceof ServerLevel level)) return;
        if (!pay(sp, c, CrazySlotsTuning.CLOWN_COST)) return;
        s.toggleCd = CrazySlotsTuning.TOGGLE_COOLDOWN_TICKS;

        CrazySlotsEntity e = new CrazySlotsEntity(HxHEntities.CRAZY_SLOTS.get(), level);
        e.bind(sp);
        Vec3 at = CrazySlotsEntity.hoverPoint(sp, 1f, 0); // above the user's right shoulder
        e.moveTo(at.x, at.y, at.z, sp.yBodyRot - 90f, 0f); // turned toward the user (they are to its left)
        s.rollTicks = 0;
        s.landTicks = 0;
        if (level.addFreshEntity(e)) {
            s.clown = e.getUUID();
            CLOWNS.add(s.clown);
            // HxH Craft's summon: the pop and puff where the clown appears, and the user's arm sweeps up ("evoke")
            ClownFx.poof(level, at.x, at.y + e.getBbHeight() * 0.5, at.z);
            evoke(sp);
            msg(sp, "§dCrazy Slots: §fZ to roll the wheel");
        }
    }

    /** H with the staff or the carbine out: the weapon goes (the clown can be summoned again after the usual pause). */
    private static void putAway(ServerPlayer sp, State s, Weapon w) {
        sp.stopUsingItem();
        s.sweepTicks = 0;
        removeWeapons(sp);
        weaponSpent(sp, s);
        if (sp.level() instanceof ServerLevel level) ClownFx.poof(level, sp.getX(), sp.getY() + 1.0, sp.getZ());
        evoke(sp);
        msg(sp, "§7The " + w.label.toLowerCase(java.util.Locale.ROOT) + " is put away");
    }

    /** The user's arm sweeps up: HxH Craft's "evoke" pose, played when the clown is summoned or sent away (for everyone who can see). */
    private static void evoke(ServerPlayer sp) {
        ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(sp.getUUID(), "evoke", false), sp);
    }

    /** {@code poof}: the clown leaves with a pop (sent away); false when it is about to burst into a weapon instead. */
    private static void dismissClown(ServerPlayer sp, State s, boolean poof) {
        CrazySlotsEntity e = clownOf(sp, s);
        if (e != null && sp.level() instanceof ServerLevel level) {
            if (poof) ClownFx.poof(level, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ());
            e.discard();
        }
        if (s.clown != null) CLOWNS.remove(s.clown);
        s.clown = null;
        s.rollTicks = 0;
        s.landTicks = 0;
    }

    // ---------------------------------------------------------------- Z: roll the wheel, or use the weapon in hand

    public static void use(ServerPlayer sp) {
        Combat c = gate(sp, CrazySlotsTuning.MIN_LEVEL, NAME);
        if (c == null) return;
        State s = state(sp);
        if (s.waltzStage != 0 || s.sweepTicks > 0) return; // a move is under way
        Weapon held = heldWeapon(sp);
        if (held == null) {
            Weapon pending = pendingWeapon(sp);
            if (pending != null) {
                msg(sp, pending == Weapon.SCYTHE
                    ? "§7Hold the scythe: it stays until it has been used"
                    : "§7Hold the " + pending.label.toLowerCase(java.util.Locale.ROOT) + ", or press H to put it away");
                return;
            }
            roll(sp, c, s);
            return;
        }
        switch (held) {
            case SCYTHE -> silentWaltz(sp, s);
            case STAFF -> sweep(sp, s);
            case CARBINE -> msg(sp, "§8Carbine: hold right-click to fire");
        }
    }

    private static int drawSlot(ServerPlayer sp) {
        if (CrazySlotsTuning.UNASSIGNED_SLOTS_ARE_DUDS) return 1 + sp.getRandom().nextInt(9);
        Weapon[] all = Weapon.values();
        return all[sp.getRandom().nextInt(all.length)].slot;
    }

    private static void roll(ServerPlayer sp, Combat c, State s) {
        CrazySlotsEntity clown = clownOf(sp, s);
        if (clown == null) {
            msg(sp, "§cPress H to summon the clown first");
            return;
        }
        if (s.rollTicks > 0 || s.landTicks > 0) return;
        if (!pay(sp, c, CrazySlotsTuning.ROLL_COST)) return;
        s.rollSlot = drawSlot(sp);
        s.rollTicks = CrazySlotsTuning.ROLL_TICKS;
        clown.startRolling();
        if (sp.level() instanceof ServerLevel level) sound(level, sp, SoundEvents.NOTE_BLOCK_PLING.get(), 0.8f, 0.7f);
        msg(sp, "§dThe wheel spins...");
    }

    /** The number is on the tongue: the clown becomes the weapon (or leaves, for a number that has none). */
    private static void finishRoll(ServerPlayer sp, State s) {
        Weapon w = Weapon.bySlot(s.rollSlot);
        dismissClown(sp, s, w == null || itemOf(w, false) == null); // a weapon comes with the burst below, a dud just pops away
        if (!(sp.level() instanceof ServerLevel level)) return;
        if (w == null || itemOf(w, false) == null) {
            msg(sp, "§7Slot " + s.rollSlot + ": nothing");
            sound(level, sp, SoundEvents.NOTE_BLOCK_BASS.get(), 1.0f, 0.5f);
            return;
        }
        giveWeapon(sp, newWeapon(sp, w));
        ClownFx.burst(level, sp.position()); // HxH Craft's transformation: the ball of particles around the user and its three sounds
        msg(sp, "§d" + s.rollSlot + ": §f" + w.label);
    }

    // ---------------------------------------------------------------- 2: Scythe, Silent Waltz

    private static void silentWaltz(ServerPlayer sp, State s) {
        if (s.waltzStage != 0) return;
        s.waltzStage = 1;
        s.waltzTicks = CrazySlotsTuning.WALTZ_ENLARGE_TICKS;
        fx(sp, PacketCrazySlotsFx.WALTZ, CrazySlotsTuning.WALTZ_ENLARGE_TICKS + CrazySlotsTuning.WALTZ_SPIN_TICKS);
        setScytheForm(sp, true);
        if (sp.level() instanceof ServerLevel level) {
            sound(level, sp, SoundEvents.BEACON_ACTIVATE, 1.0f, 0.5f);
            sound(level, sp, SoundEvents.WARDEN_HEARTBEAT, 1.0f, 0.6f);
        }
        msg(sp, "§5Silent Waltz");
    }

    private static void abortWaltz(ServerPlayer sp, State s) {
        s.waltzStage = 0;
        s.waltzTicks = 0;
        s.wave = null;
        fx(sp, PacketCrazySlotsFx.STOP, 0);
        setScytheForm(sp, false);
    }

    private static void waltzTick(ServerPlayer sp, State s, ServerLevel level, Combat c) {
        if (s.waltzStage == 3) {
            waveTick(sp, s, level);
            return;
        }
        if (pendingWeapon(sp) != Weapon.SCYTHE) { // the scythe is gone: nothing to swing
            abortWaltz(sp, s);
            return;
        }
        // the user is rooted to the spot while the blade grows and turns
        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, 9, false, false, false));
        Vec3 p = sp.position();
        if (s.waltzStage == 1) {
            int total = CrazySlotsTuning.WALTZ_ENLARGE_TICKS;
            double grow = 1.0 - (double) s.waltzTicks / Math.max(1, total);
            if (s.waltzTicks % 2 == 0) {
                double r = 0.6 + grow * 2.6;
                double a = level.random.nextDouble() * Math.PI * 2.0;
                level.sendParticles(ParticleTypes.ENCHANT, p.x + Math.cos(a) * r, p.y + 1.0 + level.random.nextDouble(), p.z + Math.sin(a) * r, 2, 0.1, 0.1, 0.1, 0.0);
            }
            if (s.waltzTicks % 10 == 0) sound(level, sp, SoundEvents.AMETHYST_BLOCK_RESONATE, 0.8f, 0.5f + (float) grow * 0.8f);
            if (--s.waltzTicks <= 0) {
                s.waltzStage = 2;
                s.waltzTicks = CrazySlotsTuning.WALTZ_SPIN_TICKS;
            }
            return;
        }
        // the spin
        if (s.waltzTicks % 3 == 0) sound(level, sp, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.45f);
        double ang = (1.0 - (double) s.waltzTicks / Math.max(1, CrazySlotsTuning.WALTZ_SPIN_TICKS)) * Math.PI * 2.0;
        for (int i = 0; i < 3; i++) {
            double r = 2.0 + i * 1.1;
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, p.x + Math.cos(ang) * r, p.y + 1.1, p.z + Math.sin(ang) * r, 1, 0, 0, 0, 0);
        }
        if (--s.waltzTicks <= 0) slash(sp, s, level, c);
    }

    /** The block rows (offsets from the user's feet block) the blade's band fills at least half of; always at least the row at its middle. */
    private static int[] bladeRows(double feetY) {
        double lo = feetY + CrazySlotsTuning.WALTZ_BLADE_BOTTOM, hi = feetY + CrazySlotsTuning.WALTZ_BLADE_TOP;
        int base = (int) Math.floor(feetY);
        java.util.ArrayList<Integer> rows = new java.util.ArrayList<>();
        for (int k = (int) Math.floor(lo) - base; k <= (int) Math.floor(hi) - base; k++) {
            double overlap = Math.min(base + k + 1, hi) - Math.max(base + k, lo);
            if (overlap >= 0.5) rows.add(k);
        }
        if (rows.isEmpty()) rows.add((int) Math.floor((lo + hi) * 0.5) - base);
        return rows.stream().mapToInt(Integer::intValue).toArray();
    }

    /** The end of the spin: one flat circular slash at the height of the blade. Creatures reaching into that band are bisected, then the blocks in it are cut away. */
    private static void slash(ServerPlayer sp, State s, ServerLevel level, Combat c) {
        Vec3 feet = sp.position();
        double bandLo = feet.y + CrazySlotsTuning.WALTZ_BLADE_BOTTOM, bandHi = feet.y + CrazySlotsTuning.WALTZ_BLADE_TOP;
        Vec3 centre = new Vec3(feet.x, (bandLo + bandHi) * 0.5, feet.z);
        double radius = CrazySlotsTuning.WALTZ_RADIUS;
        float dmg = CrazySlotsTuning.WALTZ_DAMAGE + c.getHatsuLevel() * CrazySlotsTuning.WALTZ_DAMAGE_PER_LEVEL;
        AABB box = new AABB(feet.x - radius, bandLo, feet.z - radius, feet.x + radius, bandHi, feet.z + radius); // only what reaches into the blade's band
        DamageSource src = CrazySlotsTuning.WALTZ_IGNORES_ARMOUR ? level.damageSources().indirectMagic(sp, sp) : level.damageSources().playerAttack(sp);

        int hits = 0;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> hostile(sp, e))) {
            double dx = e.getX() - feet.x, dz = e.getZ() - feet.z;
            if (Math.sqrt(dx * dx + dz * dz) > radius + e.getBbWidth() * 0.5) continue; // a circle, not the square of the box
            hits++;
            hurt(sp, e, dmg, src);
            Vec3 at = new Vec3(e.getX(), Mth.clamp(centre.y, e.getY(), e.getY() + e.getBbHeight()), e.getZ());
            level.sendParticles(ParticleTypes.DAMAGE_INDICATOR, at.x, at.y, at.z, 6, 0.25, 0.3, 0.25, 0.1);
            level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 10, 0.3, 0.3, 0.3, 0.3);
        }
        if (CrazySlotsTuning.WALTZ_CUTS_PROJECTILES) {
            for (Projectile p : level.getEntitiesOfClass(Projectile.class, box, p -> Math.hypot(p.getX() - feet.x, p.getZ() - feet.z) <= radius)) {
                hits++;
                p.discard();
            }
        }

        // the slash's ring and deep sounds only go off if it hits something: now for a creature or a projectile, or (see waveTick) as soon as the first block is cut
        s.slashCentre = centre;
        s.slashFxDone = false;
        if (hits > 0) {
            slashFx(level, sp, centre);
            s.slashFxDone = true;
        }
        InteractionHand hand = heldHand(sp);
        sp.swing(hand == null ? InteractionHand.MAIN_HAND : hand, true);
        if (CrazySlotsTuning.WALTZ_SLOW_FALL_TICKS > 0) {
            sp.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, CrazySlotsTuning.WALTZ_SLOW_FALL_TICKS, 0, false, false, true));
        }

        // the scythe is spent
        fx(sp, PacketCrazySlotsFx.STOP, 0);
        removeWeapons(sp);
        weaponSpent(sp, s);
        s.waltzStage = 3;
        s.waveDim = level.dimension();
        s.waveCenter = BlockPos.containing(feet.x, Math.floor(feet.y), feet.z); // the feet block: the rows are offsets from it
        s.wave = disc(radius, bladeRows(feet.y));
        s.waveIndex = 0;
    }

    /** The circle itself is thin and fast: a ring of sweeps along the blade's path at the blade's height, and a very deep sound. */
    private static void slashFx(ServerLevel level, ServerPlayer sp, Vec3 centre) {
        for (int ring = 1; ring <= 3; ring++) {
            double rr = ring * 2.4;
            for (int i = 0; i < 16 + ring * 4; i++) {
                double a = i / (16.0 + ring * 4) * Math.PI * 2.0;
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, centre.x + Math.cos(a) * rr, centre.y, centre.z + Math.sin(a) * rr, 1, 0, 0, 0, 0);
            }
        }
        sound(level, sp, SoundEvents.PLAYER_ATTACK_SWEEP, 2.0f, 0.4f);
        sound(level, sp, SoundEvents.WARDEN_SONIC_BOOM, 1.2f, 0.6f);
        sound(level, sp, SoundEvents.ENDER_DRAGON_GROWL, 0.8f, 0.5f);
    }

    /** One tick of the blocks being cut away, from the middle outwards, a few hundred at a time. */
    private static void waveTick(ServerPlayer sp, State s, ServerLevel level) {
        if (s.wave == null || s.waveCenter == null || !level.dimension().equals(s.waveDim)) {
            s.waltzStage = 0;
            s.wave = null;
            return;
        }
        int r = (int) Math.ceil(CrazySlotsTuning.WALTZ_RADIUS); // the same r as disc() packed the offsets with
        int[] off = s.wave;
        int perTick = Math.min(CrazySlotsTuning.WALTZ_BLOCKS_PER_TICK, (int) Math.ceil(off.length / (double) Math.max(1, CrazySlotsTuning.WALTZ_WAVE_TICKS)));
        int end = Math.min(off.length, s.waveIndex + Math.max(1, perTick));
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (; s.waveIndex < end; s.waveIndex++) {
            int p = off[s.waveIndex];
            m.set(s.waveCenter.getX() + ((p >> 16) & 0xFF) - r, s.waveCenter.getY() + ((p >> 8) & 0xFF) - r, s.waveCenter.getZ() + (p & 0xFF) - r);
            if (!level.isInWorldBounds(m)) continue;
            BlockState st = level.getBlockState(m);
            if (st.isAir() || st.getBlock() instanceof LiquidBlock) continue;
            if (st.getDestroySpeed(level, m) < 0f) continue;                       // bedrock and the like
            if (st.hasBlockEntity() && !CrazySlotsTuning.WALTZ_CUTS_BLOCK_ENTITIES) continue;
            BlockPos pos = m.immutable();
            if (!level.mayInteract(sp, pos)) continue;                              // spawn protection, claims
            if (MinecraftForge.EVENT_BUS.post(new BlockEvent.BreakEvent(level, pos, st, sp))) continue; // other mods' protection
            if ((s.waveIndex & 31) == 0) level.levelEvent(2001, pos, Block.getId(st)); // a few crumbs, not thousands of packets
            level.removeBlock(pos, false); // no drops: nothing here goes through the loot table
            if (!s.slashFxDone && s.slashCentre != null) { // the slash cut its first block: now it can be seen and heard
                slashFx(level, sp, s.slashCentre);
                s.slashFxDone = true;
            }
        }
        if (s.waveIndex >= off.length) {
            s.waltzStage = 0;
            s.wave = null;
        }
    }

    /** Offsets (packed as three bytes: x + r, row + r, z + r) of every block in the given rows whose centre is within the radius of the middle column, nearest first. */
    private static int[] disc(double radius, int[] rows) {
        int r = (int) Math.ceil(radius);
        int side = 2 * r + 1;
        long[] keys = new long[side * side * rows.length];
        int n = 0;
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                int d2 = x * x + z * z;
                if (d2 > radius * radius) continue;
                for (int row : rows) {
                    long packed = ((long) (x + r) << 16) | ((long) (row + r) << 8) | (long) (z + r);
                    keys[n++] = ((long) d2 << 24) | packed;
                }
            }
        }
        Arrays.sort(keys, 0, n);
        int[] out = new int[n];
        for (int i = 0; i < n; i++) out[i] = (int) (keys[i] & 0xFFFFFFL);
        return out;
    }

    // ---------------------------------------------------------------- 3: Staff, sweep

    private static final String SWEEP_NAME = "Staff Sweep";

    /** Z with the staff: a fast sideways sweep. It lands after {@link CrazySlotsTuning#SWEEP_WINDUP_TICKS} ticks and then needs {@link CrazySlotsTuning#SWEEP_COOLDOWN_TICKS} to recover. */
    private static void sweep(ServerPlayer sp, State s) {
        long left = s.sweepReadyAt - sp.level().getGameTime();
        if (ChainManager.onCooldown(sp, SWEEP_NAME, (int) left)) return;
        s.sweepTicks = CrazySlotsTuning.SWEEP_WINDUP_TICKS;
        s.sweepReadyAt = sp.level().getGameTime() + CrazySlotsTuning.SWEEP_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, SWEEP_NAME, CrazySlotsTuning.SWEEP_COOLDOWN_TICKS);
        ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(sp.getUUID(), "staff_sweep", false), sp);
        if (sp.level() instanceof ServerLevel level) sound(level, sp, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.8f);
    }

    /** The sweep lands: everyone hostile in a wide arc in front of the user takes 50% more than the basic Attack (it is an Attack-type hit, so Spirit and the Chimera Ant bonus apply as they do to the Attack). */
    private static void doSweep(ServerPlayer sp, State s, ServerLevel level, Combat c) {
        if (heldWeapon(sp) != Weapon.STAFF) return;
        Vec3 f = sp.getLookAngle().multiply(1, 0, 1);
        f = f.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : f.normalize();
        double range = CrazySlotsTuning.SWEEP_RANGE;
        double minDot = Math.cos(Math.toRadians(CrazySlotsTuning.SWEEP_ARC_DEGREES * 0.5));
        float dmg = CrazySlotsTuning.SWEEP_ATTACK_BASE_DAMAGE * CrazySlotsTuning.SWEEP_DAMAGE_MULT * c.getSpiritBonus();
        AABB box = sp.getBoundingBox().inflate(range, 1.0, range);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> hostile(sp, e))) {
            double dx = e.getX() - sp.getX(), dz = e.getZ() - sp.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > range + e.getBbWidth() * 0.5) continue;
            if (dist > 0.6 && (dx * f.x + dz * f.z) / dist < minDot) continue; // outside the arc (very close targets always count)
            e.invulnerableTime = 0;
            e.hurt(level.damageSources().mobAttack(sp), dmg);
            e.knockback(CrazySlotsTuning.SWEEP_KNOCKBACK, -dx, -dz);
            level.sendParticles(ParticleTypes.CRIT, e.getX(), e.getY() + e.getBbHeight() * 0.6, e.getZ(), 6, 0.25, 0.25, 0.25, 0.2);
        }
        // the sweep itself: a fan of sweep particles across the arc at chest height
        Vec3 right = new Vec3(-f.z, 0, f.x);
        for (int i = -2; i <= 2; i++) {
            double a = Math.toRadians(i * CrazySlotsTuning.SWEEP_ARC_DEGREES / 5.0);
            Vec3 d = f.scale(Math.cos(a)).add(right.scale(Math.sin(a)));
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, sp.getX() + d.x * range * 0.7, sp.getY() + 1.1, sp.getZ() + d.z * range * 0.7, 1, 0, 0, 0, 0);
        }
        sound(level, sp, SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 0.9f);
        sound(level, sp, SoundEvents.PLAYER_ATTACK_STRONG, 0.8f, 0.8f);
        InteractionHand hand = heldHand(sp);
        sp.swing(hand == null ? InteractionHand.MAIN_HAND : hand, true);
        // the staff is not spent: it stays in hand for more sweeps until the user puts it away (H) or dies
    }

    // ---------------------------------------------------------------- 4: Carbine

    /** Every tick the right button is held with the carbine in hand (server, driven by CrazyWeaponItem). */
    public static void carbineHold(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (!canUse(c) || ExtrasHooks.hatsuForced(sp) || HatsuEffects.isStunned(sp) || sp.isSpectator() || heldWeapon(sp) != Weapon.CARBINE) {
            sp.stopUsingItem();
            return;
        }
        State s = state(sp);
        long now = sp.level().getGameTime();
        if (now < s.nextShot) return;
        fire(sp, c, s, now);
    }

    private static void fire(ServerPlayer sp, Combat c, State s, long now) {
        InteractionHand hand = heldHand(sp);
        if (hand == null || !(sp.level() instanceof ServerLevel level)) return;
        ItemStack st = sp.getItemInHand(hand);
        if (weaponOf(st) != Weapon.CARBINE) return;
        int ammo = -1; // -1 = no magazine: the carbine does not run dry
        if (CrazySlotsTuning.CARBINE_USES_AMMO) {
            if (!st.getOrCreateTag().contains(AMMO_TAG)) st.getTag().putInt(AMMO_TAG, CrazySlotsTuning.CARBINE_MAGAZINE);
            ammo = st.getTag().getInt(AMMO_TAG);
            if (ammo <= 0) {
                carbineSpent(sp, s);
                return;
            }
            ammo--;
            st.getTag().putInt(AMMO_TAG, ammo);
        }
        s.nextShot = now + CrazySlotsTuning.CARBINE_FIRE_INTERVAL_TICKS;

        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle();
        if (now - s.lastShotTick > CrazySlotsTuning.CARBINE_BLOOM_RESET_TICKS) s.shotsInRow = 0;
        s.lastShotTick = now;
        double sp2 = CrazySlotsTuning.CARBINE_SPREAD
            + Math.min(CrazySlotsTuning.CARBINE_SPREAD_BLOOM_MAX, s.shotsInRow * CrazySlotsTuning.CARBINE_SPREAD_BLOOM_PER_SHOT);
        s.shotsInRow++;
        Vec3 dir = look.add(level.random.nextGaussian() * sp2, level.random.nextGaussian() * sp2, level.random.nextGaussian() * sp2).normalize();
        double range = CrazySlotsTuning.CARBINE_RANGE;
        Vec3 end = eye.add(dir.scale(range));
        BlockHitResult bh = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        Vec3 stop = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
        AABB box = sp.getBoundingBox().expandTowards(dir.scale(range)).inflate(1.0);
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(level, sp, eye, stop, box, e -> hostile(sp, e));
        if (eh != null) stop = eh.getLocation();

        // a faint streak: the bullets are quiet and nearly invisible
        Vec3 from = eye.add(dir.scale(1.2)).add(0, -0.25, 0);
        double len = from.distanceTo(stop);
        for (double t = 1.0; t < len; t += 3.0) {
            Vec3 at = from.add(dir.scale(t));
            level.sendParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 1, 0, 0, 0, 0);
        }
        level.playSound(null, sp.blockPosition(), SoundEvents.ARROW_SHOOT, SoundSource.PLAYERS, CrazySlotsTuning.CARBINE_SOUND_VOLUME, 1.9f);

        if (eh != null && eh.getEntity() instanceof LivingEntity target) {
            float dmg = (CrazySlotsTuning.CARBINE_DAMAGE + c.getHatsuLevel() * CrazySlotsTuning.CARBINE_DAMAGE_PER_LEVEL)
                * CrazySlotsTuning.carbineFalloff(eye.distanceTo(stop)); // weaker the further the shot travelled
            hurt(sp, target, dmg, level.damageSources().playerAttack(sp));
            level.sendParticles(ParticleTypes.CRIT, stop.x, stop.y, stop.z, 3, 0.1, 0.1, 0.1, 0.2);
        } else if (bh.getType() == HitResult.Type.BLOCK) {
            BlockState hit = level.getBlockState(bh.getBlockPos());
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, hit), stop.x, stop.y, stop.z, 4, 0.05, 0.05, 0.05, 0.1);
        }
        if (CrazySlotsTuning.CARBINE_USES_AMMO) {
            if (ammo <= 0) carbineSpent(sp, s);
            else if (ammo % 10 == 0) msg(sp, "§8Carbine: " + ammo + " rounds left");
        }
    }

    private static void carbineSpent(ServerPlayer sp, State s) {
        sp.stopUsingItem();
        removeWeapons(sp);
        weaponSpent(sp, s);
        msg(sp, "§7The carbine is spent");
    }

    // ---------------------------------------------------------------- a weapon was used up

    private static void weaponSpent(ServerPlayer sp, State s) {
        s.readyAt = sp.level().getGameTime() + CrazySlotsTuning.AFTER_USE_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, NAME, CrazySlotsTuning.AFTER_USE_COOLDOWN_TICKS);
    }

    // ---------------------------------------------------------------- per tick

    public static void serverTick(MinecraftServer server) {
        if (server == null) return;
        if (server.getTickCount() % 20 == 7) sweepStrays(server);
        if (STATES.isEmpty()) return;
        for (Map.Entry<UUID, State> en : new ArrayList<>(STATES.entrySet())) {
            State s = en.getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null) {
                STATES.remove(en.getKey()); // the clown removes itself: its owner is gone
                continue;
            }
            Combat c = Combat.get(sp);
            if (!sp.isAlive() || !canUse(c) || ExtrasHooks.hatsuForced(sp)) {
                clear(sp);
                continue;
            }
            if (!(sp.level() instanceof ServerLevel level)) continue;
            if (s.toggleCd > 0) s.toggleCd--;

            // the roulette
            if (s.clown != null && clownOf(sp, s) == null) { // the clown was lost (another dimension, a command): forget it
                CLOWNS.remove(s.clown);
                s.clown = null;
                s.rollTicks = 0;
                s.landTicks = 0;
            }
            if (s.rollTicks > 0) {
                s.rollTicks--;
                if (s.rollTicks % 2 == 0) {
                    float rise = 0.6f + (1f - s.rollTicks / (float) Math.max(1, CrazySlotsTuning.ROLL_TICKS)) * 1.2f;
                    sound(level, sp, SoundEvents.NOTE_BLOCK_HAT.get(), 0.7f, rise);
                }
                if (s.rollTicks == 0) {
                    CrazySlotsEntity clown = clownOf(sp, s);
                    if (clown != null) clown.land(s.rollSlot);
                    s.landTicks = CrazySlotsTuning.LAND_TICKS;
                    sound(level, sp, SoundEvents.NOTE_BLOCK_PLING.get(), 1.0f, 1.4f);
                    sound(level, sp, SoundEvents.PLAYER_LEVELUP, 0.5f, 1.6f);
                    msg(sp, "§e§l" + s.rollSlot);
                }
            } else if (s.landTicks > 0) {
                if (s.landTicks <= 10 && s.landTicks % 2 == 0) { // the last ten ticks before the clown changes: sparks rise over it
                    CrazySlotsEntity clown = clownOf(sp, s);
                    if (clown != null) ClownFx.rise(level, clown.getX(), clown.getY() + clown.getBbHeight() + 0.2, clown.getZ());
                }
                if (--s.landTicks == 0) finishRoll(sp, s);
            }

            // the weapons
            if (s.sweepTicks > 0 && --s.sweepTicks == 0) doSweep(sp, s, level, c);
            if (s.waltzStage != 0) waltzTick(sp, s, level, c);
        }
    }

    /** Once a second: a weapon of a Hatsu the player no longer has goes, and a scythe left big by an interrupted Silent Waltz shrinks. */
    private static void sweepStrays(MinecraftServer server) {
        for (ServerPlayer sp : server.getPlayerList().getPlayers()) {
            if (pendingWeapon(sp) == null) continue;
            Combat c = Combat.get(sp);
            if (c != null && c.hasNenUnlocked() && !canUse(c)) {
                removeWeapons(sp);
                continue;
            }
            State s = STATES.get(sp.getUUID());
            if (s == null || s.waltzStage == 0) setScytheForm(sp, false);
        }
    }

    // ---------------------------------------------------------------- the staff's curse: the Chimera Ant

    public static boolean isChimeraAnt(Player p) {
        return p != null && !p.level().isClientSide && NenAddonData.get(p).chimera;
    }

    /** Multiplier for the damage of Attack, Strong attack and Barrage by a Chimera Ant (the basic attacks are the mob-attack hits of a player; Hatsu hits are not). */
    public static float chimeraDamageMult(ServerPlayer attacker, DamageSource src) {
        if (!isChimeraAnt(attacker)) return 1f;
        if (!src.is(DamageTypes.MOB_ATTACK) || src.getDirectEntity() != attacker) return 1f;
        if (Vows.isHatsuHit(src)) return 1f;
        return CrazySlotsTuning.CHIMERA_ATTACK_MULT;
    }

    public static void applyChimeraTags(ServerPlayer sp) {
        sp.addTag(CrazySlotsTuning.CHIMERA_TAG);
        sp.addTag(CrazySlotsTuning.CHIMERA_TAG_2);
    }

    /**
     * A player died (the event was not cancelled). Killed by Neferpitou (much stronger than them) with the staff in hand, they will be reborn as a Chimera Ant: it is noted now and
     * carried out when they respawn ({@link #onRespawn}). Either way, everything Crazy Slots had out goes.
     */
    public static void onDeath(ServerPlayer sp, DamageSource source) {
        InteractionHand hand = heldHand(sp);
        boolean holdingStaff = hand != null && weaponOf(sp.getItemInHand(hand)) == Weapon.STAFF
            && killedByMuchStrongerPitou(sp, source);
        NenAddonData d = NenAddonData.get(sp);
        if (d.chimeraPending != holdingStaff) { // set or cleared on every death: only dying with the staff in hand brings the rebirth
            d.chimeraPending = holdingStaff;
            d.save();
        }
        clear(sp);
    }

    /** The rebirth needs the killer to be Neferpitou, and far above the user: her level must be at least {@link CrazySlotsTuning#CHIMERA_KILLER_MIN_LEVEL_RATIO} times the user's. */
    private static boolean killedByMuchStrongerPitou(ServerPlayer sp, DamageSource source) {
        if (source == null || !(source.getEntity() instanceof NeferpitouEntity)) return false;
        Combat c = Combat.get(sp);
        int userLevel = c == null ? 1 : Math.max(1, c.getHatsuLevel());
        return NeferpitouTuning.LEVEL >= userLevel * CrazySlotsTuning.CHIMERA_KILLER_MIN_LEVEL_RATIO;
    }

    /** After respawning: a pending rebirth is carried out, and a Chimera Ant always wears the tags. */
    public static void onRespawn(ServerPlayer sp) {
        NenAddonData d = NenAddonData.get(sp);
        if (d.chimeraPending) {
            d.chimeraPending = false;
            d.chimera = true;
            d.save();
            NenLoss.rebirth(sp); // an unawakened player again: no Nen until it is awakened anew
            Combat c = Combat.get(sp);
            if (c != null) c.updatePlayerMaxHealth(); // 40 health
            sp.setHealth(sp.getMaxHealth());
            sp.sendSystemMessage(Component.literal("§5You have been reborn as a Chimera ant."));
        }
        if (d.chimera) applyChimeraTags(sp);
    }

    // ---------------------------------------------------------------- ending

    /** Death, losing the Hatsu, Forced Zetsu: the clown and every weapon go, and a Silent Waltz in progress stops. */
    public static void clear(ServerPlayer sp) {
        State s = STATES.remove(sp.getUUID());
        if (s != null) {
            CrazySlotsEntity e = clownOf(sp, s);
            if (e != null) e.discard();
            if (s.clown != null) CLOWNS.remove(s.clown);
            if (s.waltzStage != 0 || s.sweepTicks > 0) fx(sp, PacketCrazySlotsFx.STOP, 0);
        }
        removeWeapons(sp);
    }

    /** Logging out: the clown goes, but a weapon that has not been used yet stays in the inventory (it is only gone when it has been used). */
    public static void onLogout(ServerPlayer sp) {
        State s = STATES.remove(sp.getUUID());
        if (s != null) {
            CrazySlotsEntity e = clownOf(sp, s);
            if (e != null) e.discard();
            if (s.clown != null) CLOWNS.remove(s.clown);
        }
        setScytheForm(sp, false);
    }

    public static void reset() {
        STATES.clear();
        CLOWNS.clear();
    }
}
