package net.hxhadventure.addon;

import java.util.EnumSet;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.tags.DamageTypeTags;
import net.hxhadventure.abilities.Combat;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.GameRules;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.entity.ModEntities;
import net.hxhadventure.entity.custom.AuraEntity;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * The user's double: what everybody caught inside the Laplace Devil's dome sees instead of the real user. It wears the user's skin,
 * name, armour and held items, and has the user's health, armour and knockback resistance, and is made in Ten with the user's Ten buffs (it enters Ren when it has a target). It hits with Attack.
 * It fights whatever was hunting the user (the targets are handed to it by {@link LaplaceDevil}), strikes back at whoever hits it,
 * and otherwise wanders about the spot where it appeared. It is drawn only for the people the domain affects (see LaplaceFx).
 */
public class LaplaceDoubleEntity extends PathfinderMob {
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(LaplaceDoubleEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    /** Player base speed (0.1) is a walk; a zombie's 0.23 feels like the same walk on a mob, so speed is scaled, not copied. */
    private static final double PLAYER_BASE_SPEED = 0.1, MOB_WALK_SPEED = 0.23;

    private Vec3 anchor;
    private int orphanTicks;
    private int attackCooldown;
    private boolean announcedDeath;
    /** The double's Ren: the same aura entity a Ren user gets, following this mob. */
    private AuraEntity ren;

    // ---- the user's Nen numbers, worked out when the double is made (the user is in Zetsu then, so their live state is not copied) ----
    private static final UUID MOD_TEN_SPEED = UUID.fromString("c7a91000-0000-4000-8000-000000000001");
    private float tenBonus;        // Ten's damage / durability bonus (0.2 = +20%), Vows included
    private float tenSpeed;        // Ten's speed bonus
    private float renMult = 1f;    // what Ren multiplies Ten by (Tuning.REN_TEN_MULT x the user's Ren Vows)
    private float spirit = 1f;     // HxHAdventure's spirit bonus for the user's Hatsu level: 1 + 0.1 sqrt(L)
    private float affDealt = 1f, affTaken = 1f;
    private int auraColor;
    private float auraScale = 1f;
    private boolean inRen;
    private int noTargetTicks;

    public LaplaceDoubleEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        this.setPersistenceRequired();
        this.setCanPickUpLoot(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 20.0)
            .add(Attributes.MOVEMENT_SPEED, MOB_WALK_SPEED)
            .add(Attributes.ATTACK_DAMAGE, 1.0)
            .add(Attributes.ATTACK_KNOCKBACK, 0.0)
            .add(Attributes.ARMOR, 0.0)
            .add(Attributes.ARMOR_TOUGHNESS, 0.0)
            .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OWNER, Optional.empty());
    }

    public UUID ownerId() {
        return this.entityData.get(OWNER).orElse(null);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, LaplaceDevilTuning.DOUBLE_CHASE_SPEED, true) {
            @Override
            protected void checkAndPerformAttack(LivingEntity target, double distToTargetSqr) { } // it chases like a mob, but hits with Attack (attackTick)
        });
        this.goalSelector.addGoal(5, new WanderNearAnchorGoal(this));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this)); // it hits back at whoever hits it; everything else is handed to it by the domain
        // aggressive: it also goes for any hostile mob that comes within range
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, 10, true, false,
            m -> !(m instanceof LaplaceDoubleEntity) && m.distanceToSqr(this) <= LaplaceDevilTuning.DOUBLE_DRAW_RANGE * LaplaceDevilTuning.DOUBLE_DRAW_RANGE));
    }

    // ---------------- becoming the user ----------------

    /** Copies the user's look and numbers. Call once, before the double is added to the level. */
    public void copyFrom(ServerPlayer sp) {
        this.entityData.set(OWNER, Optional.of(sp.getUUID()));
        this.anchor = sp.position();
        this.setCustomName(sp.getName());
        this.setCustomNameVisible(true);
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            this.setItemSlot(slot, sp.getItemBySlot(slot).copy());
            this.setDropChance(slot, 0f);
        }
        // equipment adds its own attribute modifiers to a mob, so they are taken out of the numbers copied from the user
        double speed = sp.getAttributeValue(Attributes.MOVEMENT_SPEED) / (sp.isSprinting() ? 1.3 : 1.0);
        set(Attributes.MAX_HEALTH, sp.getMaxHealth());
        set(Attributes.ARMOR, sp.getAttributeValue(Attributes.ARMOR) - itemBonus(sp, Attributes.ARMOR));
        set(Attributes.ARMOR_TOUGHNESS, sp.getAttributeValue(Attributes.ARMOR_TOUGHNESS) - itemBonus(sp, Attributes.ARMOR_TOUGHNESS));
        set(Attributes.ATTACK_DAMAGE, Math.max(1.0, sp.getAttributeValue(Attributes.ATTACK_DAMAGE) - itemBonus(sp, Attributes.ATTACK_DAMAGE)));
        set(Attributes.KNOCKBACK_RESISTANCE, sp.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE));
        set(Attributes.MOVEMENT_SPEED, Math.max(0.05, speed / PLAYER_BASE_SPEED * MOB_WALK_SPEED));

        // the user's Nen: Ten's buffs (from their Ten level, not from the Zetsu they are in), Ren's multiplier, affinity, spirit bonus
        NenAddonData d = NenAddonData.get(sp);
        Combat c = Combat.get(sp);
        this.tenBonus = d.tenBonus();
        this.tenSpeed = d.tenSpeedBonus();
        this.renMult = Tuning.REN_TEN_MULT * Vows.power(sp, "REN");
        if (c != null) {
            this.spirit = 1.0f + (float) Math.sqrt(Math.max(0, c.getHatsuLevel())) * 0.1f;
            int type = d.effType(c);
            this.affDealt = Affinity.dealt(type);
            this.affTaken = Affinity.taken(type);
        }
        this.auraColor = AbilityRegistry.getOrCreatePlayerAuraColor(sp) - 1;
        this.auraScale = d.renScale();
        this.inRen = false;
        applyAuraState(); // it is made in Ten, with all of Ten's buffs
        this.setHealth(Math.min(sp.getHealth(), this.getMaxHealth()));
    }

    private void set(Attribute attr, double value) {
        AttributeInstance a = this.getAttribute(attr);
        if (a != null) a.setBaseValue(Math.max(0.0, value));
    }

    /** What the user's worn / held items add (flat) to an attribute. */
    private static double itemBonus(ServerPlayer sp, Attribute attr) {
        double sum = 0;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack st = sp.getItemBySlot(slot);
            if (st.isEmpty()) continue;
            for (AttributeModifier m : st.getAttributeModifiers(slot).get(attr)) {
                if (m.getOperation() == AttributeModifier.Operation.ADDITION) sum += m.getAmount();
            }
        }
        return sum;
    }

    // ---------------- Ren ----------------

    /** Damage / durability / speed bonus of the current form: Ten, or Ten x Ren's multiplier once it is fighting. */
    private float formBonus() {
        return tenBonus * (inRen ? renMult : 1f);
    }

    /** Puts Ten's or Ren's speed and Jump Boost on the double (the damage and durability parts are applied when it hits / is hit). */
    private void applyAuraState() {
        AttributeInstance sp = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (sp != null) {
            sp.removeModifier(MOD_TEN_SPEED);
            sp.addTransientModifier(new AttributeModifier(MOD_TEN_SPEED, "Laplace double Nen", tenSpeed * (inRen ? renMult : 1f), AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
        if (tenSpeed > 0f) {
            addEffect(new MobEffectInstance(MobEffects.JUMP, MobEffectInstance.INFINITE_DURATION, Tuning.TEN_JUMP_BOOST_LEVEL - 1, false, false));
        }
    }

    /** It has a target: Ten becomes Ren (the user's own aura colour and size). */
    private void enterRen() {
        if (inRen) return;
        inRen = true;
        applyAuraState();
        if (!(level() instanceof ServerLevel sl) || ren != null) return;
        AuraEntity a = new AuraEntity(ModEntities.AURA_ENTITY.get(), sl);
        a.setOwner(this);
        a.setAuraColorIndex(auraColor);
        a.setAuraType(0);
        a.setAuraScale(auraScale);
        a.setPos(getX(), getY() + 0.1, getZ());
        sl.addFreshEntity(a);
        ren = a;
    }

    /** Nothing left to fight: Ren drops back to Ten. */
    private void leaveRen() {
        if (!inRen) return;
        inRen = false;
        applyAuraState();
        dropRen();
    }

    private void dropRen() {
        if (ren != null && !ren.isRemoved()) ren.discard();
        ren = null;
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        dropRen();
        super.remove(reason);
    }

    // ---------------- aggression ----------------

    /** Whoever hurts the double is its target at once, not at the next goal check. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        // durability: the user's Ten (or Ren) bonus divides the damage it takes, plus the user's affinity
        if (!source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) amount *= affTaken / (1f + formBonus());
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide && source.getEntity() instanceof LivingEntity attacker
            && attacker != this && attacker.isAlive() && !isAlliedTo(attacker)) {
            setTarget(attacker);
        }
        return hit;
    }

    /**
     * Its Attack: the single punch a Ren user's Attack makes (an area hit just in front of it), with the user's spirit bonus, Ten / Ren
     * damage bonus and affinity. Used whenever its target is in reach.
     */
    private void attackTick() {
        if (attackCooldown > 0) attackCooldown--;
        LivingEntity t = getTarget();
        if (t == null || !t.isAlive() || attackCooldown > 0) return;
        if (distanceTo(t) - t.getBbWidth() * 0.5 > LaplaceDevilTuning.ATTACK_RANGE + 0.5 || Math.abs(t.getY() - getY()) > 2.5) return;
        getLookControl().setLookAt(t, 60f, 60f);
        attackCooldown = LaplaceDevilTuning.ATTACK_GAP_TICKS;
        swing(InteractionHand.MAIN_HAND);
        float range = LaplaceDevilTuning.ATTACK_RANGE;
        float total = LaplaceDevilTuning.ATTACK_DAMAGE * spirit * affDealt * (1f + formBonus());
        Vec3 dir = new Vec3(t.getX() - getX(), 0, t.getZ() - getZ());
        dir = dir.lengthSqr() < 1.0E-4 ? getLookAngle() : dir.normalize();
        Vec3 hit = position().add(dir.x * range, 1.5, dir.z * range);
        AABB box = new AABB(hit.x - range, hit.y - range, hit.z - range, hit.x + range, hit.y + range, hit.z + range);
        UUID o = ownerId();
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, box, x -> isAttackable(x, t, o))) {
            e.hurt(damageSources().mobAttack(this), total);
            e.knockback(LaplaceDevilTuning.ATTACK_KNOCKBACK, -(e.getX() - getX()), -(e.getZ() - getZ()));
            e.hurtMarked = true;
        }
        level().playSound(null, blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, 1.0f, 1.0f);
    }

    /** What its Attack may touch: its target and hostile mobs. Never its owner, itself or other doubles. */
    private boolean isAttackable(LivingEntity e, LivingEntity target, UUID owner) {
        if (e == this || !e.isAlive() || e instanceof LaplaceDoubleEntity || e instanceof net.minecraft.world.entity.decoration.ArmorStand) return false;
        if (owner != null && e.getUUID().equals(owner)) return false;
        if (e == target) return true;
        return e instanceof Enemy && !(e instanceof Player);
    }

    // ---------------- death ----------------

    /** The double's name is the user's own display name (team colour, hover and click included), so its death message reads like theirs. */
    @Override
    public Component getDisplayName() {
        UUID o = ownerId();
        if (o != null && level().getServer() != null) {
            ServerPlayer owner = level().getServer().getPlayerList().getPlayer(o);
            if (owner != null) return owner.getDisplayName();
        }
        return super.getDisplayName();
    }

    /** Dying announces the same chat message a player's death does (when the showDeathMessages rule is on). */
    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level().isClientSide || announcedDeath || !this.dead) return;
        announcedDeath = true;
        if (level().getGameRules().getBoolean(GameRules.RULE_SHOWDEATHMESSAGES) && level().getServer() != null) {
            level().getServer().getPlayerList().broadcastSystemMessage(getCombatTracker().getDeathMessage(), false);
        }
    }

    // ---------------- behaviour ----------------

    @Override
    public boolean isAlliedTo(Entity other) {
        UUID o = ownerId();
        return (o != null && other.getUUID().equals(o)) || super.isAlliedTo(other);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        attackTick();
        if (getTarget() != null && getTarget().isAlive()) { // agro: Ten -> Ren
            noTargetTicks = 0;
            enterRen();
        } else if (inRen && ++noTargetTicks > LaplaceDevilTuning.REN_LINGER_TICKS) {
            noTargetTicks = 0;
            leaveRen();
        }
        UUID o = ownerId();
        if (o == null || !LaplaceDevil.owns(o, getUUID())) { // the domain is gone (server restarted, user left): so is the double
            if (++orphanTicks > 20 && level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.9, getZ(), 12, 0.3, 0.5, 0.3, 0.02);
                discard();
            }
        } else {
            orphanTicks = 0;
        }
    }

    /** Standing around near the spot it appeared, like a person who is not doing much. */
    private static final class WanderNearAnchorGoal extends Goal {
        private final LaplaceDoubleEntity mob;
        private int wait;

        WanderNearAnchorGoal(LaplaceDoubleEntity mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return mob.anchor != null && mob.getTarget() == null && --wait <= 0 && mob.getNavigation().isDone();
        }

        @Override
        public boolean canContinueToUse() {
            return mob.getTarget() == null && !mob.getNavigation().isDone();
        }

        @Override
        public void start() {
            wait = 40 + mob.getRandom().nextInt(80);
            double r = LaplaceDevilTuning.DOUBLE_WANDER;
            Vec3 pos = mob.distanceToSqr(mob.anchor) > r * r
                ? mob.anchor
                : DefaultRandomPos.getPos(mob, 5, 3);
            if (pos != null && pos.distanceToSqr(mob.anchor) <= (r + 2) * (r + 2)) mob.getNavigation().moveTo(pos.x, pos.y, pos.z, 1.0);
            else mob.getNavigation().moveTo(mob.anchor.x, mob.anchor.y, mob.anchor.z, 1.0);
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
        }
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }
}
