package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registers the Nen-fighter NPCs' attributes and spawn eggs, and applies their Nen to the damage they deal and take. */
public final class NenFighterEvents {
    private static final org.slf4j.Logger LOGGER = com.mojang.logging.LogUtils.getLogger();

    private NenFighterEvents() {}

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class NenFighterModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent e) {
            putSafe(e, HxHEntities.NETERO.get(), NeteroEntity.STATS);
            putSafe(e, HxHEntities.ZENO.get(), ZenoEntity.STATS);
            putSafe(e, HxHEntities.SILVA.get(), SilvaEntity.STATS);
            putSafe(e, HxHEntities.BISKY.get(), BiskyEntity.STATS);
            putSafe(e, HxHEntities.ILLUMI.get(), IllumiEntity.STATS);
            putSafe(e, HxHEntities.KURAPIKA.get(), KurapikaEntity.STATS);
            putSafe(e, HxHEntities.KILLUA.get(), KilluaEntity.STATS);
        }

        /** One NPC at a time, so a problem with one never stops the others; a second delivery of the event (already registered) is ignored. */
        private static void putSafe(EntityAttributeCreationEvent e, net.minecraft.world.entity.EntityType<? extends net.minecraft.world.entity.LivingEntity> type, NpcStats stats) {
            try {
                e.put(type, NenFighter.createAttributes(stats).build());
                LOGGER.info("Registered attributes for {}", stats.id);
            } catch (IllegalStateException alreadyThere) {
                // already registered
            } catch (Throwable t) {
                LOGGER.error("Could not register attributes for {}", stats.id, t);
            }
        }

        @SubscribeEvent
        public static void creativeTab(BuildCreativeModeTabContentsEvent e) {
            if (e.getTabKey() != CreativeModeTabs.SPAWN_EGGS) return;
            e.accept(HxHEntities.NETERO_SPAWN_EGG.get());
            e.accept(HxHEntities.ZENO_SPAWN_EGG.get());
            e.accept(HxHEntities.SILVA_SPAWN_EGG.get());
            e.accept(HxHEntities.BISKY_SPAWN_EGG.get());
            e.accept(HxHEntities.ILLUMI_SPAWN_EGG.get());
            e.accept(HxHEntities.KURAPIKA_SPAWN_EGG.get());
            e.accept(HxHEntities.KILLUA_SPAWN_EGG.get());
        }
    }

    @Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class NenFighterGame {
        /** A dodge (Killua's Whirlwind / Godspeed) cancels the hit before it lands. */
        @SubscribeEvent(priority = EventPriority.HIGH)
        public static void onAttack(LivingAttackEvent event) {
            if (event.getEntity().level().isClientSide) return;
            if (event.getEntity() instanceof NenFighter n && n.negatesHit(event.getSource(), event.getAmount())) event.setCanceled(true);
        }

        /** Same slot as the players' handler (AddonServerEvents.onHurt), run after it. */
        /**
         * Last word on an NPC's melee blow against a player: no single blow takes more than NpcFeelTuning.MELEE_HIT_CAP of the player's maximum health,
         * after Ten / Ren / Ken durability and every other multiplier, so a full-health player can never be one-shot by a punch (armour still helps on top).
         */
        @SubscribeEvent(priority = EventPriority.LOWEST)
        public static void capMeleeBlow(LivingHurtEvent event) {
            if (event.getEntity().level().isClientSide || !(event.getEntity() instanceof Player p)) return;
            Entity cause = event.getSource().getEntity();
            if (!(cause instanceof NpcMelee.Host) || event.getSource().getDirectEntity() != cause) return;
            float cap = (float) (p.getMaxHealth() * NpcFeelTuning.MELEE_HIT_CAP);
            if (event.getAmount() > cap) event.setAmount(cap);
        }

        @SubscribeEvent(priority = EventPriority.LOW)
        public static void onHurt(LivingHurtEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide) return;
            DamageSource src = event.getSource();
            float amount = event.getAmount();
            Entity cause = src.getEntity();
            if (cause instanceof NenFighter h && h != victim) amount *= h.outgoingMult(src);
            if (victim instanceof NenFighter h) amount *= h.incomingMult(src);
            event.setAmount(amount);
        }
    }
}
