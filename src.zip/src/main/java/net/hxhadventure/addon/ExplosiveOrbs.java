package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketOrbFx;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Silva's Explosive Orbs (Hatsu kit 11, Emitters).
 *
 * Press and HOLD Z: you levitate {@link Tuning#ORBS_RISE} blocks up and {@link Tuning#ORBS_FORWARD} forward, arms out to the
 * sides, while an orb of aura grows in each hand until it reaches full size (it stays full while you keep holding).
 * Release Z: both orbs are hurled at what you are looking at (a creature, or the block you point at). Each explodes on
 * impact: heavy damage that falls off with distance, to everyone in the blast INCLUDING you and your allies, and a crater.
 * Releasing early throws smaller orbs; below {@link Tuning#ORBS_MIN_THROW} of a charge, they just disperse.
 *
 * Orbs are not entities: the server moves them as points and clients draw them (PacketOrbFx / OrbFx / OrbRenderer).
 */
public final class ExplosiveOrbs {
    private ExplosiveOrbs() {}

    public static final int KIT = 11;
    public static final String ID = "explosive_orbs";

    private enum Phase { IDLE, CHARGING, FALLING }

    private static final class State {
        Phase phase = Phase.IDLE;
        double startX, startY, startZ;
        double fwdX, fwdZ;
        boolean releaseRequested;
        int charge, fallTicks, cooldown;
        ResourceKey<Level> dim;
    }

    private static final class Orb {
        final int id;
        final UUID owner;
        final ResourceKey<Level> dim;
        Vec3 pos;
        final Vec3 vel;
        final float radius;
        int life, age;
        final Vec3 start;
        String cause = "lifetime";

        Orb(int id, UUID owner, ResourceKey<Level> dim, Vec3 pos, Vec3 vel, float radius, int life) {
            this.id = id;
            this.owner = owner;
            this.dim = dim;
            this.pos = pos;
            this.vel = vel;
            this.radius = radius;
            this.life = life;
            this.start = pos;
        }
    }

    private static final org.slf4j.Logger LOG = com.mojang.logging.LogUtils.getLogger();
    private static final Map<Player, State> STATES = new WeakHashMap<>();
    private static final List<Orb> ORBS = new ArrayList<>();
    private static int nextOrbId = 1;
    private static final Random RND = new Random();
    private static final java.util.Set<UUID> Z_HELD = new java.util.HashSet<>();

    /** Called by the client's Z-held packet. Letting go while charging is what throws the orbs. */
    public static void setZHeld(ServerPlayer sp, boolean held) {
        if (held) {
            Z_HELD.add(sp.getUUID());
            return;
        }
        Z_HELD.remove(sp.getUUID());
        State s = STATES.get(sp);
        if (s != null && s.phase == Phase.CHARGING) s.releaseRequested = true;
    }

    private static State state(Player p) {
        return STATES.computeIfAbsent(p, k -> new State());
    }

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < Tuning.ORBS_MIN_LEVEL) return base;
        String[] out = Arrays.copyOf(base, base.length + 1);
        out[base.length] = ID;
        return out;
    }

    /** Where a hand-held orb's centre is: out to the side of the shoulder, past the hand. Shared by server and client. */
    public static Vec3 handCenter(Vec3 feet, float bbHeight, float bodyYawDeg, boolean left, double orbRadius) {
        double rad = Math.toRadians(bodyYawDeg);
        Vec3 right = new Vec3(-Math.cos(rad), 0, -Math.sin(rad));
        double side = (0.98 + 0.25 * orbRadius) * (left ? -1 : 1);
        return feet.add(0, bbHeight * 0.77, 0).add(right.scale(side));
    }

    private static float fraction(State s) {
        return Math.min(1f, s.charge / (float) Tuning.ORBS_CHARGE_TICKS);
    }

    // ---------------- Z ----------------
    public static void toggle(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Explosive Orbs"), true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.ORBS_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cExplosive Orbs unlocks at Level " + Tuning.ORBS_MIN_LEVEL), true);
            return;
        }
        State s = state(sp);
        if (s.phase != Phase.IDLE) return; // already charging (release Z to throw) or still coming down
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: Explosive Orbs cannot be formed"), true);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        if (ChainManager.onCooldown(sp, "Explosive Orbs", s.cooldown)) return;
        if (c.getCurrentEnergy() < Tuning.ORBS_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.ORBS_COST);
        s.phase = Phase.CHARGING;
        s.startX = sp.getX();
        s.startY = sp.getY();
        s.startZ = sp.getZ();
        double rad = Math.toRadians(sp.getYRot());
        s.fwdX = -Math.sin(rad);
        s.fwdZ = Math.cos(rad);
        s.charge = 0;
        s.releaseRequested = false;
        s.dim = level.dimension();
        sp.setNoGravity(true);
        playSound(sp, SoundEvents.BEACON_ACTIVATE, 1.2f, 0.5f);
        send(sp, PacketOrbFx.charge(sp.getId(), Tuning.ORBS_CHARGE_TICKS, 0f));
    }

    /** Stops the charge: orbs vanish, you drift down without fall damage. */
    private static void end(ServerPlayer sp, State s, String msg, int cooldown) {
        s.phase = Phase.FALLING;
        s.fallTicks = 0;
        s.cooldown = cooldown;
        ChainManager.startCooldown(sp, "Explosive Orbs", cooldown);
        sp.setNoGravity(false);
        send(sp, PacketOrbFx.end(sp.getId()));
        if (msg != null) sp.displayClientMessage(Component.literal(msg), true);
    }

    private static void hurl(ServerPlayer sp, Combat c, State s, float f) {
        if (!(sp.level() instanceof ServerLevel level)) return;
        // aim: the creature or block under the crosshair, else a point far ahead
        Vec3 eye = sp.getEyePosition();
        Vec3 aim = eye.add(sp.getLookAngle().scale(80));
        HitResult block = level.clip(new ClipContext(eye, aim, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        if (block.getType() != HitResult.Type.MISS) aim = block.getLocation();
        Entity looked = ChainManager.rayEntity(sp, 80.0, e -> e instanceof LivingEntity le && le != sp && !AllianceUtils.isAlly(le, sp));
        if (looked != null) aim = looked.position().add(0, looked.getBbHeight() * 0.5, 0);

        float radius = Tuning.ORBS_MAX_RADIUS * ease(f);
        send(sp, PacketOrbFx.end(sp.getId()));
        for (int i = 0; i < 2; i++) {
            Vec3 from = handCenter(sp.position(), sp.getBbHeight(), sp.yBodyRot, i == 0, radius);
            Vec3 vel = aim.subtract(from).normalize().scale(Tuning.ORBS_SPEED);
            Orb o = new Orb(nextOrbId++, sp.getUUID(), level.dimension(), from, vel, radius, Tuning.ORBS_LIFE_TICKS);
            ORBS.add(o);
            AddonNetwork.sendToNear(PacketOrbFx.launch(o.id, from, vel, radius, o.life), level, from, 160);
        }
        s.phase = Phase.FALLING;
        s.fallTicks = 0;
        s.cooldown = Tuning.ORBS_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, "Explosive Orbs", Tuning.ORBS_COOLDOWN_TICKS);
        sp.setNoGravity(false);
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        playSound(sp, SoundEvents.FIRECHARGE_USE, 2.0f, 0.5f);
    }

    /** Easing so a half charge is clearly smaller than a full one (matches the client's drawn size). */
    public static float ease(float f) {
        f = Mth.clamp(f, 0f, 1f);
        return f * f * (3f - 2f * f);
    }

    // ---------------- per player tick ----------------
    public static void tick(ServerPlayer sp) {
        State s = STATES.get(sp);
        if (s == null) return;
        if (s.cooldown > 0) s.cooldown--;
        if (s.phase == Phase.IDLE) return;
        if (s.phase == Phase.FALLING) { // a soft landing: no fall damage while coming down
            sp.fallDistance = 0f;
            if (sp.onGround() || sp.isInWater() || ++s.fallTicks > 200) s.phase = Phase.IDLE;
            return;
        }
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || !sp.isAlive() || !(sp.level() instanceof ServerLevel level) || level.dimension() != s.dim) {
            end(sp, s, null, Tuning.ORBS_COOLDOWN_TICKS);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            end(sp, s, "\u00a75Forced Zetsu: the orbs collapse", Tuning.ORBS_COOLDOWN_TICKS);
            return;
        }
        if (sp.tickCount % 20 == 0) {
            if (c.getCurrentEnergy() < Tuning.ORBS_UPKEEP) {
                end(sp, s, "\u00a7cEnergy depleted! The orbs collapse.", Tuning.ORBS_COOLDOWN_TICKS);
                return;
            }
            c.consumeEnergy(Tuning.ORBS_UPKEEP);
        }
        if (s.releaseRequested) { // Z let go: throw what has been built
            float f = fraction(s);
            if (f < Tuning.ORBS_MIN_THROW) end(sp, s, "\u00a77Explosive Orbs dispersed", Tuning.ORBS_COOLDOWN_TICKS / 2);
            else hurl(sp, c, s, f);
            return;
        }
        // levitate up and a little forward, then hold at that spot
        double vx = Mth.clamp((s.startX + s.fwdX * Tuning.ORBS_FORWARD - sp.getX()) * 0.3, -0.35, 0.35);
        double vz = Mth.clamp((s.startZ + s.fwdZ * Tuning.ORBS_FORWARD - sp.getZ()) * 0.3, -0.35, 0.35);
        double vy = Mth.clamp((s.startY + Tuning.ORBS_RISE - sp.getY()) * 0.3, -0.4, 0.4);
        sp.setDeltaMovement(vx, vy, vz);
        sp.fallDistance = 0f;
        sp.connection.send(new ClientboundSetEntityMotionPacket(sp));

        if (s.charge < Tuning.ORBS_CHARGE_TICKS && ++s.charge == Tuning.ORBS_CHARGE_TICKS) {
            playSound(sp, SoundEvents.BEACON_POWER_SELECT, 1.5f, 0.6f);
            sp.displayClientMessage(Component.literal("\u00a75Explosive Orbs: ready, release Z to throw"), true);
        }
    }

    // ---------------- orbs in flight ----------------
    public static void tickGlobal(MinecraftServer server) {
        if (ORBS.isEmpty()) return;
        Iterator<Orb> it = ORBS.iterator();
        while (it.hasNext()) {
            Orb o = it.next();
            ServerLevel level = server.getLevel(o.dim);
            ServerPlayer owner = server.getPlayerList().getPlayer(o.owner);
            if (level == null || owner == null) { // the thrower is gone: the orb fades without exploding
                LOG.warn("[hxh] Explosive orb {} removed: level={} owner={}", o.id, level, owner);
                if (level != null) AddonNetwork.sendToNear(PacketOrbFx.remove(o.id), level, o.pos, 160);
                it.remove();
                continue;
            }
            o.age++;
            Vec3 hit = advance(level, owner, o);
            if (hit != null || --o.life <= 0) {
                it.remove();
                if (o.age <= 5) LOG.warn("[hxh] Explosive orb {} exploded after only {} ticks at {} (start {}): {}", o.id, o.age, hit != null ? hit : o.pos, o.start, o.cause);
                explode(level, owner, o, hit != null ? hit : o.pos);
            }
        }
    }

    /** Moves the orb one tick in three sub-steps; returns where it struck something, or null. */
    private static Vec3 advance(ServerLevel level, ServerPlayer owner, Orb o) {
        Vec3 step = o.vel.scale(1.0 / 3.0);
        for (int i = 0; i < 3; i++) {
            Vec3 from = o.pos, to = from.add(step);
            // just out of the hands nothing counts: the orb starts beside the thrower and must clear them first
            boolean grace = from.distanceToSqr(o.start) < 1.5 * 1.5;
            HitResult block = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, owner));
            if (!grace && block.getType() != HitResult.Type.MISS) {
                o.cause = "block " + level.getBlockState(((net.minecraft.world.phys.BlockHitResult) block).getBlockPos());
                return block.getLocation();
            }
            o.pos = to;
            if (grace) continue;
            double r = o.radius * 0.6 + 0.3;
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(to, to).inflate(r))) {
                // anything in its path sets it off; the thrower only once it is well clear of their hands
                if ((e != owner || o.age > 8) && e.isAlive() && !(e instanceof ArmorStand)
                    && e.getBoundingBox().inflate(o.radius * 0.5).contains(to)) {
                    o.cause = "entity " + e.getName().getString();
                    return to;
                }
            }
        }
        return null;
    }

    private static void explode(ServerLevel level, ServerPlayer owner, Orb o, Vec3 at) {
        float size = Mth.clamp(o.radius / Tuning.ORBS_MAX_RADIUS, 0.05f, 1f);
        float blast = Tuning.ORBS_BLAST_RADIUS * size;
        Combat c = Combat.get(owner);
        float base = Tuning.ORBS_BASE_DAMAGE + (c == null ? 0 : c.getHatsuLevel() * Tuning.ORBS_DAMAGE_PER_LEVEL);
        NenAddonData d = c == null ? null : NenAddonData.peek(owner);
        if (c != null && d != null) base *= Affinity.projectile(d.effType(c)); // emitters: +15% projectile damage
        base *= Vows.hatsuDamageMult(owner); // the Hatsu skill: more damage

        AddonNetwork.sendToNear(PacketOrbFx.boom(o.id, at, blast), level, at, 160);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 6.0f, 0.55f);

        // creatures: heavy damage that fades toward the edge, thrown outward. Nobody is spared: the thrower and allies too.
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(blast))) {
            if (!e.isAlive() || e instanceof ArmorStand) continue;
            Vec3 mid = e.position().add(0, e.getBbHeight() * 0.5, 0);
            double dist = mid.distanceTo(at);
            if (dist > blast) continue;
            float falloff = (float) (1.0 - 0.75 * dist / blast);
            boolean friendly = e == owner || AllianceUtils.isAlly(e, owner);
            Vows.hatsuHurt(e, friendly ? level.damageSources().explosion(owner, owner) : level.damageSources().playerAttack(owner), base * size * falloff);
            Vec3 push = mid.subtract(at).normalize().scale(Tuning.ORBS_KNOCKBACK * size * falloff).add(0, 0.4 * falloff, 0);
            e.push(push.x, push.y, push.z);
            e.hurtMarked = true;
        }
        if (Tuning.ORBS_BREAK_BLOCKS) crater(level, at, blast);
    }

    /** Removes every block the blast is strong enough for; ragged at the edge, and a few blocks drop as items. */
    private static void crater(ServerLevel level, Vec3 at, float radius) {
        int r = (int) Math.ceil(radius);
        BlockPos centre = BlockPos.containing(at);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    double dist = Math.sqrt(x * x + y * y + z * z) * (0.9 + 0.2 * RND.nextDouble());
                    if (dist >= radius) continue;
                    pos.set(centre.getX() + x, centre.getY() + y, centre.getZ() + z);
                    if (!level.isInWorldBounds(pos)) continue;
                    BlockState st = level.getBlockState(pos);
                    if (st.isAir() || !st.getFluidState().isEmpty() || st.getDestroySpeed(level, pos) < 0) continue;
                    float strength = Tuning.ORBS_BLOCK_POWER * (1f - (float) (dist / radius));
                    if (st.getBlock().getExplosionResistance() > strength) continue;
                    if (RND.nextFloat() < 0.04f) net.minecraft.world.level.block.Block.dropResources(st, level, pos);
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
    }

    // ---------------- lifecycle / networking ----------------
    /** Death / logout: the orbs are gone and gravity is back. */
    public static void clear(Player p) {
        State s = STATES.remove(p);
        Z_HELD.remove(p.getUUID());
        if (p instanceof ServerPlayer sp) {
            if (s != null && s.phase == Phase.CHARGING) send(sp, PacketOrbFx.end(sp.getId()));
            if (s != null && s.phase != Phase.IDLE) sp.setNoGravity(false);
        }
    }

    /** A player coming into view of someone mid-charge sees the orbs straight away, at the right size. */
    public static void sendTo(ServerPlayer owner, ServerPlayer viewer) {
        State s = STATES.get(owner);
        if (s == null || s.phase != Phase.CHARGING) return;
        AddonNetwork.sendToPlayer(PacketOrbFx.charge(owner.getId(), Tuning.ORBS_CHARGE_TICKS, fraction(s)), viewer);
    }

    private static void send(ServerPlayer sp, PacketOrbFx pkt) {
        AddonNetwork.sendToTrackingAndSelf(pkt, sp);
    }

    private static void playSound(ServerPlayer sp, SoundEvent ev, float vol, float pitch) {
        sp.level().playSound(null, sp.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }
}
