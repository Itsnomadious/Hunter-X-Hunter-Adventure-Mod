package net.hxhadventure.addon;

import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

/**
 * The fighting of every Nen-fighter NPC: face the target, run it down (or hold the distance a caster likes), and punch once it is in
 * reach. Hatsu that hold the NPC in place ({@link NenFighter#hatsuBusy}) stop the walking. The Hatsu and the punches live in the entity.
 */
final class NenFighterGoal extends Goal {
    private final NenFighter npc;
    private int repath;

    NenFighterGoal(NenFighter npc) {
        this.npc = npc;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = npc.getTarget();
        return t != null && t.isAlive();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        npc.getNavigation().stop();
    }

    @Override
    public void tick() {
        LivingEntity t = npc.getTarget();
        if (t == null) return;
        npc.getLookControl().setLookAt(t, 60.0f, 60.0f);
        if (npc.hatsuBusy()) { // channelling: stands where it is
            npc.getNavigation().stop();
            return;
        }
        double want = npc.preferredRange();
        double dist = npc.distanceTo(t);
        boolean inReach = npc.inReach(t);
        if (inReach) {
            if (!npc.isAttacking()) npc.getNavigation().stop();
            npc.chooseAttack(t);
        }
        if (want > 0.0 && !npc.isAttacking()) {
            // a caster: close in to its range, back off when the target is on top of it (it still punches while cornered)
            if (dist > want + 2.0) {
                if (--repath <= 0) {
                    repath = 4 + npc.getRandom().nextInt(4);
                    npc.getNavigation().moveTo(t, 1.2);
                }
            } else if (dist < want * 0.45 && !inReach) {
                if (--repath <= 0) {
                    repath = 10;
                    Vec3 away = DefaultRandomPos.getPosAway(npc, 10, 4, t.position());
                    if (away != null) npc.getNavigation().moveTo(away.x, away.y, away.z, 1.2);
                }
            } else if (!inReach) {
                npc.getNavigation().stop();
            }
            return;
        }
        if (!inReach || (npc.isAttacking() && dist > 1.6f)) {
            if (--repath <= 0) {
                repath = 4 + npc.getRandom().nextInt(4);
                npc.getNavigation().moveTo(t, 1.25);
            }
        }
    }
}
