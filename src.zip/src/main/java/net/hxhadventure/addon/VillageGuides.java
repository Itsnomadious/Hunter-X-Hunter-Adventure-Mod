package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.hxhadventure.HxHAdventure;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.StructureTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Puts exactly one {@link ExamGuideEntity} in every village.
 *
 * <p>How: when a chunk loads, any village that starts in it is written down (the chunk it starts in is its key, its first piece is its centre).
 * That is a map lookup, nothing is scanned. Every {@link ExamGuideTuning#CHECK_INTERVAL_TICKS} the written-down villages that are currently
 * loaded are checked: if a village has no living guide, one is created next to its centre. Because the check is always "does this village have
 * a guide", a guide that was killed (creative / /kill) is replaced, a village is never given two, and villages generated before this existed
 * get theirs the first time their chunks load. Guides made some other way (spawn egg) carry no village key and are ignored.
 *
 * <p>Also records the Hunter Exam halls the world already has, which {@link ExamGuide} uses as extra answers.
 */
@Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class VillageGuides {
    private static final String DATA_NAME = "hxh_village_guides";

    /**
     * A village must have been fully loaded for this many checks in a row (3 x 2 seconds) before it is judged to be missing its guide: chunk
     * entities load a moment after the chunk does, and a guide that simply has not loaded yet must not be replaced.
     */
    private static final int SETTLE_CHECKS = 3;

    private VillageGuides() {}

    // ------------------------------------------------------------------ saved data

    public static final class Data extends SavedData {
        static final class Village {
            final BlockPos pos;
            UUID guide;

            Village(BlockPos pos, UUID guide) {
                this.pos = pos;
                this.guide = guide;
            }
        }

        final Map<Long, Village> villages = new HashMap<>();
        final Map<Long, BlockPos> halls = new HashMap<>();
        /** Not saved: for how many checks in a row each village has been fully loaded (see {@link VillageGuides#SETTLE_CHECKS}). */
        final Map<Long, Integer> settledFor = new HashMap<>();

        public Data() {}

        public static Data load(CompoundTag tag) {
            Data d = new Data();
            ListTag vs = tag.getList("Villages", Tag.TAG_COMPOUND);
            for (int i = 0; i < vs.size(); i++) {
                CompoundTag t = vs.getCompound(i);
                d.villages.put(t.getLong("Key"), new Village(new BlockPos(t.getInt("X"), t.getInt("Y"), t.getInt("Z")),
                    t.hasUUID("Guide") ? t.getUUID("Guide") : null));
            }
            ListTag hs = tag.getList("Halls", Tag.TAG_COMPOUND);
            for (int i = 0; i < hs.size(); i++) {
                CompoundTag t = hs.getCompound(i);
                d.halls.put(t.getLong("Key"), new BlockPos(t.getInt("X"), t.getInt("Y"), t.getInt("Z")));
            }
            return d;
        }

        @Override
        public CompoundTag save(CompoundTag tag) {
            ListTag vs = new ListTag();
            for (Map.Entry<Long, Village> en : villages.entrySet()) {
                CompoundTag t = new CompoundTag();
                t.putLong("Key", en.getKey());
                t.putInt("X", en.getValue().pos.getX());
                t.putInt("Y", en.getValue().pos.getY());
                t.putInt("Z", en.getValue().pos.getZ());
                if (en.getValue().guide != null) t.putUUID("Guide", en.getValue().guide);
                vs.add(t);
            }
            tag.put("Villages", vs);
            ListTag hs = new ListTag();
            for (Map.Entry<Long, BlockPos> en : halls.entrySet()) {
                CompoundTag t = new CompoundTag();
                t.putLong("Key", en.getKey());
                t.putInt("X", en.getValue().getX());
                t.putInt("Y", en.getValue().getY());
                t.putInt("Z", en.getValue().getZ());
                hs.add(t);
            }
            tag.put("Halls", hs);
            return tag;
        }

        /** Copy of the exam halls this world is known to have (safe to hand to another thread). */
        public List<BlockPos> knownHalls() {
            return new ArrayList<>(halls.values());
        }
    }

    public static Data data(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(Data::load, Data::new, DATA_NAME);
    }

    // ------------------------------------------------------------------ recording villages and halls

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load e) {
        if (!(e.getLevel() instanceof ServerLevel level)) return;
        ChunkAccess chunk = e.getChunk();
        Map<Structure, StructureStart> starts = chunk.getAllStarts();
        if (starts.isEmpty()) return;

        Registry<Structure> reg = level.registryAccess().registryOrThrow(Registries.STRUCTURE);
        Data data = null;
        for (Map.Entry<Structure, StructureStart> en : starts.entrySet()) {
            StructureStart start = en.getValue();
            if (start == null || !start.isValid() || start.getPieces().isEmpty()) continue;
            Structure structure = en.getKey();
            boolean village = ExamGuideTuning.ENABLED && reg.wrapAsHolder(structure).is(StructureTags.VILLAGE);
            boolean hall = structure.type() == HunterExamHQ.TYPE.get();
            if (!village && !hall) continue;

            long key = chunk.getPos().toLong();
            BlockPos centre = start.getPieces().get(0).getBoundingBox().getCenter();
            if (data == null) data = data(level);
            if (village && !data.villages.containsKey(key)) {
                data.villages.put(key, new Data.Village(centre.immutable(), null));
                data.setDirty();
            }
            if (hall && !data.halls.containsKey(key)) {
                BlockPos c = start.getBoundingBox().getCenter();
                data.halls.put(key, new BlockPos(c.getX(), c.getY(), c.getZ()));
                data.setDirty();
            }
        }
    }

    // ------------------------------------------------------------------ keeping one guide per village

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent e) {
        if (!ExamGuideTuning.ENABLED || e.phase != TickEvent.Phase.END || !(e.level instanceof ServerLevel level)) return;
        if (level.getGameTime() % ExamGuideTuning.CHECK_INTERVAL_TICKS != 0 || level.players().isEmpty()) return;

        Data data = data(level);
        if (data.villages.isEmpty()) return;

        int spawned = 0;
        for (Map.Entry<Long, Data.Village> en : data.villages.entrySet()) {
            Data.Village v = en.getValue();
            // only act while the village centre and everything around it (where the guide can stand) is fully loaded and ticking:
            // an unloaded guide must not be mistaken for a missing one
            long key = en.getKey();
            if (!settled(level, v.pos)) {
                data.settledFor.remove(key);
                continue;
            }
            int calm = data.settledFor.merge(key, 1, Integer::sum);
            if (calm < SETTLE_CHECKS) continue;

            Entity current = v.guide == null ? null : level.getEntity(v.guide);
            if (current instanceof ExamGuideEntity g && g.isAlive()) continue;

            List<ExamGuideEntity> near = level.getEntitiesOfClass(ExamGuideEntity.class, new AABB(v.pos).inflate(64.0),
                g -> g.isAlive() && g.getVillageKey() == key);
            if (!near.isEmpty()) {
                v.guide = near.get(0).getUUID();
                for (int i = 1; i < near.size(); i++) near.get(i).discard(); // never two in one village
                data.setDirty();
                continue;
            }

            if (spawned >= ExamGuideTuning.MAX_SPAWNS_PER_CHECK) break;
            ExamGuideEntity g = spawn(level, key, v.pos);
            if (g != null) {
                v.guide = g.getUUID();
                data.setDirty();
                spawned++;
            }
        }
    }

    /** The village centre and the spots a guide can stand on around it are all in entity ticking chunks. */
    private static boolean settled(ServerLevel level, BlockPos c) {
        int r = ExamGuideTuning.SPAWN_RADIUS + 1;
        return level.isPositionEntityTicking(c)
            && level.isPositionEntityTicking(c.offset(r, 0, r))
            && level.isPositionEntityTicking(c.offset(-r, 0, r))
            && level.isPositionEntityTicking(c.offset(r, 0, -r))
            && level.isPositionEntityTicking(c.offset(-r, 0, -r));
    }

    private static ExamGuideEntity spawn(ServerLevel level, long key, BlockPos centre) {
        EntityType<ExamGuideEntity> type = HxHEntities.EXAM_GUIDE.get();
        BlockPos at = findSpot(level, type, centre);
        if (at == null) return null;
        ExamGuideEntity guide = type.create(level);
        if (guide == null) return null;
        guide.setVillageKey(key);
        guide.moveTo(at.getX() + 0.5, at.getY(), at.getZ() + 0.5, level.random.nextFloat() * 360.0f, 0.0f);
        guide.setYHeadRot(guide.getYRot());
        guide.finalizeSpawn(level, level.getCurrentDifficultyAt(at), MobSpawnType.STRUCTURE, null, null);
        level.addFreshEntityWithPassengers(guide);
        return guide;
    }

    /**
     * Open ground close to the village centre. Roofs are avoided by only accepting spots at most one block above the lowest valid spot
     * found around the centre (the square and the paths are the lowest walkable ground in a village).
     */
    private static BlockPos findSpot(ServerLevel level, EntityType<?> type, BlockPos centre) {
        int radius = ExamGuideTuning.SPAWN_RADIUS;
        List<BlockPos> valid = new ArrayList<>();
        int minY = Integer.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                int x = centre.getX() + dx;
                int z = centre.getZ() + dz;
                if (!level.hasChunkAt(new BlockPos(x, 0, z))) continue;
                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                BlockPos feet = new BlockPos(x, y, z);
                BlockPos floor = feet.below();
                if (!level.getFluidState(floor).isEmpty() || !level.getFluidState(feet).isEmpty()) continue;
                if (!level.getBlockState(floor).isFaceSturdy(level, floor, net.minecraft.core.Direction.UP)) continue;
                if (!level.noCollision(type.getAABB(x + 0.5, y, z + 0.5))) continue;
                valid.add(feet);
                minY = Math.min(minY, y);
            }
        }
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos p : valid) {
            if (p.getY() > minY + 1) continue;
            double d = p.distSqr(new BlockPos(centre.getX(), p.getY(), centre.getZ()));
            if (d < bestD) {
                bestD = d;
                best = p;
            }
        }
        return best;
    }
}
