package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.hxhadventure.addon.GonEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.GonVow;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Gon's adult form: black aura rises from the top of the head, straight up, about {@link #HEIGHT} blocks, as ONE thick strand of hair
 * (a single tapering, jagged lock) that wiggles a little all the time and trails behind the player when they move. Drawn as a flat
 * ribbon that always faces the camera, in an opaque (not additive) render type so black actually shows as black.
 *
 * The root sits exactly on the top of the head: {@link GonHairLayer} reads the real head model part while the player is drawn (so it
 * follows the 1.5x growth, the crouch, the Jajanken charge pose and where the head is looking) and hands the point over through
 * {@link #recordHead}. If a player is not drawn this frame (the local player in first person), a calculated spot is used instead.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class GonHairRenderer {
    private GonHairRenderer() {}

    /** How tall the aura is, in blocks. */
    public static final double HEIGHT = 10.0;
    /** How wide the strand is where it leaves the head, in blocks (a little wider than the head, which is 0.47 across at 1x). */
    private static final double BASE_WIDTH = 0.62;
    private static final int SEGS = 36;
    private static final double CULL_DISTANCE = 128.0;
    /** How far the strand's tip can swing sideways just standing still, and extra per unit of speed (blocks, at the tip). */
    private static final double IDLE_SWAY = 0.35, MOVE_SWAY = 1.6, MAX_TRAIL = 3.5;

    /** Smoothed horizontal velocity (blocks per tick) per player, so the strand drags behind and settles gently. */
    private static final Map<Integer, double[]> VEL = new HashMap<>();
    /** This frame's top-of-head per player, in view space, as measured by {@link GonHairLayer}. Emptied after every frame. */
    private static final Map<Integer, float[]> HEAD = new HashMap<>();

    /** Called by {@link GonHairLayer} while a player is drawn: the top-centre of their head, in view space. */
    static void recordHead(int entityId, float x, float y, float z) {
        HEAD.put(entityId, new float[] {x, y, z});
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            VEL.clear();
            HEAD.clear();
            return;
        }
        for (Entity p : level.entitiesForRendering()) { // players, and the Gon NPC
            if (!(p instanceof Player || p instanceof GonEntity)) continue;
            if (!GonVow.clientHas(p.getId())) {
                VEL.remove(p.getId());
                continue;
            }
            double[] v = VEL.computeIfAbsent(p.getId(), k -> new double[2]);
            v[0] += ((p.getX() - p.xo) - v[0]) * 0.25;
            v[1] += ((p.getZ() - p.zo) - v[1]) * 0.25;
        }
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            HEAD.clear();
            return;
        }
        boolean any = false;
        for (Entity p : level.entitiesForRendering()) {
            if ((p instanceof Player || p instanceof GonEntity) && GonVow.clientHas(p.getId())) {
                any = true;
                break;
            }
        }
        if (!any) {
            HEAD.clear();
            return;
        }

        float pt = e.getPartialTick();
        double time = level.getGameTime() + pt;
        Vec3 cam = e.getCamera().getPosition();
        Matrix4f m = e.getPoseStack().last().pose();
        Matrix4f inv = new Matrix4f(m).invert(); // view space (what the layer measured) -> camera-relative world space (what is drawn here)
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.debugQuads(); // translucent blending, no texture, both faces
        VertexConsumer vc = buf.getBuffer(type);

        for (Entity en : level.entitiesForRendering()) {
            if (!(en instanceof LivingEntity p) || !(p instanceof Player || p instanceof GonEntity)) continue;
            if (!GonVow.clientHas(p.getId()) || !p.isAlive() || p.isInvisible() || p.isSpectator()) continue;
            double x = Mth.lerp(pt, p.xo, p.getX()), y = Mth.lerp(pt, p.yo, p.getY()), z = Mth.lerp(pt, p.zo, p.getZ());
            if (cam.distanceToSqr(x, y, z) > CULL_DISTANCE * CULL_DISTANCE) continue;
            float grow = GonVowClient.scale(p, pt);

            Vec3 root; // where the strand starts, relative to the camera
            float[] h = HEAD.get(p.getId());
            if (h != null) {
                Vector3f w = inv.transformPosition(new Vector3f(h[0], h[1], h[2]));
                root = new Vec3(w.x, w.y, w.z);
            } else {
                // not drawn this frame: the head top is a little above the (scaled) eye height; a crouched charge leans the head forward
                double headY = y + (p.getEyeHeight() / GonVow.HEIGHT_MULT + 0.22) * grow;
                double headX = x, headZ = z;
                if (p.isCrouching()) {
                    Vec3 f = JajankenFx.facing(p, pt);
                    headX += f.x * 0.35 * grow;
                    headZ += f.z * 0.35 * grow;
                }
                root = new Vec3(headX - cam.x, headY - cam.y, headZ - cam.z);
            }
            double[] v = VEL.get(p.getId());
            double vx = v == null ? 0 : v[0], vz = v == null ? 0 : v[1];
            hair(m, vc, root, vx, vz, grow, time, p.getId());
        }
        buf.endBatch(type);
        HEAD.clear();
    }

    private static double hash(int a, int b) {
        double h = Math.sin(a * 12.9898 + b * 78.233) * 43758.5453;
        return (h - Math.floor(h)) * 2.0 - 1.0; // -1..1
    }

    /** The one strand. {@code root} is the top of the head, relative to the camera. */
    private static void hair(Matrix4f m, VertexConsumer vc, Vec3 root, double vx, double vz, double grow, double time, int seed) {
        double speed = Math.sqrt(vx * vx + vz * vz);
        double moving = Math.min(1.0, speed * 8.0);
        // the drag: opposite to the way the player is going, capped so a fast run does not fling it across the sky
        double tx = -vx * 14.0, tz = -vz * 14.0;
        double tl = Math.sqrt(tx * tx + tz * tz);
        if (tl > MAX_TRAIL) {
            tx *= MAX_TRAIL / tl;
            tz *= MAX_TRAIL / tl;
        }
        double amp = IDLE_SWAY + MOVE_SWAY * moving;
        double baseW = BASE_WIDTH * grow;

        Vec3[] p = new Vec3[SEGS + 1];
        double[] w = new double[SEGS + 1];
        for (int j = 0; j <= SEGS; j++) {
            double t = (double) j / SEGS;
            double k = Math.pow(t, 1.4);                                       // the root stays put, the tip swings most
            double sx = Math.sin(time * 0.13 + seed * 0.7 + t * 5.0) * amp * k;
            double sz = Math.cos(time * 0.11 + seed * 0.9 + t * 4.3) * amp * k;
            double drag = t * t;
            double jag = 0.08 * t * hash(j, 7 + seed) * grow;                  // rough, hairlike edges (none at the root, so it sits flush on the head)
            double jag2 = 0.08 * t * hash(j, 11 + seed) * grow;
            p[j] = new Vec3(root.x + sx + tx * drag + jag, root.y + HEIGHT * t, root.z + sz + tz * drag + jag2);
            w[j] = Mth.lerp(Math.pow(t, 0.75), baseW, 0.03) * (0.92 + 0.16 * (0.5 + 0.5 * hash(j * 13, 9)));
        }
        strand(m, vc, p, w, 1.5, 24, 0, 36, 70);   // faint dark halo
        strand(m, vc, p, w, 1.0, 4, 4, 8, 245);     // the black core
    }

    /** The strand as a ribbon: each node gets a sideways offset perpendicular to both the strand and the line of sight. */
    private static void strand(Matrix4f m, VertexConsumer vc, Vec3[] p, double[] w, double widen, int r, int g, int b, int a) {
        int n = p.length;
        Vec3[] side = new Vec3[n];
        for (int j = 0; j < n; j++) {
            Vec3 dir = p[Math.min(n - 1, j + 1)].subtract(p[Math.max(0, j - 1)]);
            Vec3 s = dir.cross(p[j]);
            side[j] = s.lengthSqr() < 1e-10 ? new Vec3(1, 0, 0) : s.normalize().scale(w[j] * widen * 0.5);
        }
        for (int j = 0; j < n - 1; j++) {
            int fade = j > n - 7 ? (int) (a * (n - 1 - j) / 6.0) : a; // the last bit of the tip thins out to nothing
            vtx(m, vc, p[j].add(side[j]), r, g, b, a);
            vtx(m, vc, p[j].subtract(side[j]), r, g, b, a);
            vtx(m, vc, p[j + 1].subtract(side[j + 1]), r, g, b, fade);
            vtx(m, vc, p[j + 1].add(side[j + 1]), r, g, b, fade);
        }
    }

    private static void vtx(Matrix4f m, VertexConsumer vc, Vec3 v, int r, int g, int b, int a) {
        vc.vertex(m, (float) v.x, (float) v.y, (float) v.z).color(r, g, b, Math.max(0, Math.min(255, a))).endVertex();
    }
}
