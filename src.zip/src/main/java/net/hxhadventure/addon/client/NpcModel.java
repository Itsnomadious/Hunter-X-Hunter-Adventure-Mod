package net.hxhadventure.addon.client;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;
import net.hxhadventure.addon.NpcPose;

/** The vanilla player model for an NPC, plus the "hand held out" pose Kite and Hina use during their rituals. */
public class NpcModel<T extends Mob> extends PlayerModel<T> {
    public NpcModel(ModelPart root, boolean slim) {
        super(root, slim);
    }

    @Override
    public void setupAnim(T mob, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(mob, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (mob instanceof NpcPose tp && tp.tPose()) {
            this.rightArm.xRot = 0f;
            this.rightArm.yRot = 0f;
            this.rightArm.zRot = (float) (Math.PI / 2);
            this.leftArm.xRot = 0f;
            this.leftArm.yRot = 0f;
            this.leftArm.zRot = (float) (-Math.PI / 2);
            this.rightSleeve.copyFrom(this.rightArm);
            this.leftSleeve.copyFrom(this.leftArm);
        } else if (mob instanceof NpcPose pose && pose.armsOut()) {
            this.rightArm.xRot = -1.45f;
            this.rightArm.yRot = 0f;
            this.rightArm.zRot = 0f;
            this.rightSleeve.copyFrom(this.rightArm);
        }

        int stance = mob instanceof NpcPose sp ? sp.stance() : 0;
        if (stance != 0) kneel(stance, ageInTicks);
    }

    /**
     * Cookie at work. The legs fold back behind her (the renderer sinks her onto her knees), and the arms work in time:
     * stance 1 strokes the hair of the person in front of her, stance 2 presses down and up on their back, one hand after the other.
     */
    private void kneel(int stance, float t) {
        this.rightLeg.xRot = 1.35f;
        this.rightLeg.yRot = 0.12f;
        this.rightLeg.zRot = 0f;
        this.leftLeg.xRot = 1.35f;
        this.leftLeg.yRot = -0.12f;
        this.leftLeg.zRot = 0f;
        float a = Mth.sin(t * 0.32f);
        if (stance == 1) {
            this.rightArm.xRot = -1.8f + a * 0.2f;
            this.leftArm.xRot = -1.8f - a * 0.2f;
            this.rightArm.yRot = -0.12f;
            this.leftArm.yRot = 0.12f;
            this.head.xRot = 0.15f;
        } else {
            this.rightArm.xRot = -0.85f + a * 0.28f;
            this.leftArm.xRot = -0.85f - a * 0.28f;
            this.rightArm.yRot = 0.1f;
            this.leftArm.yRot = -0.1f;
            this.head.xRot = 0.5f;
        }
        this.rightArm.zRot = 0f;
        this.leftArm.zRot = 0f;
        this.rightSleeve.copyFrom(this.rightArm);
        this.leftSleeve.copyFrom(this.leftArm);
        this.rightPants.copyFrom(this.rightLeg);
        this.leftPants.copyFrom(this.leftLeg);
        this.hat.copyFrom(this.head);
    }
}
