package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;

/** Client-side list of running ability cooldowns. Entries are timed off the level clock and drop out when they end. */
public final class ClientCooldowns {
    private ClientCooldowns() {}

    public record Entry(String name, long end, int total) {
        public int remaining(long now) { return (int) Math.max(0, end - now); }
    }

    private static final Map<String, Entry> ACTIVE = new LinkedHashMap<>();

    private static long now() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? 0L : mc.level.getGameTime();
    }

    public static void set(String name, int ticks) {
        if (ticks <= 0) {
            ACTIVE.remove(name);
            return;
        }
        ACTIVE.put(name, new Entry(name, now() + ticks, ticks));
    }

    public static void clear() {
        ACTIVE.clear();
    }

    /** Cooldowns still running, oldest first. Finished ones are removed here. */
    public static List<Entry> active() {
        long now = now();
        for (Iterator<Entry> it = ACTIVE.values().iterator(); it.hasNext(); ) {
            if (it.next().remaining(now) <= 0) it.remove();
        }
        return new ArrayList<>(ACTIVE.values());
    }
}
