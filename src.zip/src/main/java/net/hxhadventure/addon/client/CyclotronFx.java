package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.RipperCyclotronTuning;

/** Client-side record of every Ripper Cyclotron in view (fed by PacketCyclotronFx), keyed by the player's entity id: the arm's spin and the aura. */
public final class CyclotronFx {
    private CyclotronFx() {}

    public static final int SPIN = 1, PUNCH = 2;
    /** How long the punch pose and burst are shown, in ticks. */
    public static final double PUNCH_TICKS = 8;

    public static final class Rec {
        public final int owner;
        public int mode;
        /** Game time the spin started, and the game time the punch was thrown. */
        public double t0, punchAt = -1;
        public double px, py, pz;
        /** The aura's width in blocks when the punch was thrown. */
        public double diameter;

        Rec(int owner, double t0) {
            this.owner = owner;
            this.t0 = t0;
        }
    }

    private static final Map<Integer, Rec> ACTIVE = new HashMap<>();

    public static Map<Integer, Rec> all() { return ACTIVE; }

    public static boolean isEmpty() { return ACTIVE.isEmpty(); }

    public static void clear() { ACTIVE.clear(); }

    public static void set(int owner, int mode, double x, double y, double z, double a) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        double now = level.getGameTime();
        if (mode == SPIN) {
            Rec r = new Rec(owner, now - a); // a = how many ticks ago the spin started
            r.mode = SPIN;
            ACTIVE.put(owner, r);
        } else if (mode == PUNCH) {
            Rec r = ACTIVE.get(owner);
            if (r == null) {
                r = new Rec(owner, now);
                ACTIVE.put(owner, r);
            }
            r.mode = PUNCH;
            r.punchAt = now;
            r.px = x;
            r.py = y;
            r.pz = z;
            r.diameter = a;
        } else {
            ACTIVE.remove(owner);
        }
    }

    /** How many rotations the arm has made (continuous: 0.5 = half a turn). */
    public static double rotations(Rec r, double time) {
        return Math.max(0, time - r.t0) / RipperCyclotronTuning.ROTATION_TICKS;
    }

    /** The arm's angle in radians: increases without end, in the direction the tuning asks for. */
    public static double angle(double rotations) {
        double a = rotations * Math.PI * 2.0;
        return RipperCyclotronTuning.CLOCKWISE ? a : -a;
    }

    // Model pixels (16 = 1 block): the right shoulder pivot is 22 px above the feet and 5 px out to the side; the fist is 10.5 px along the arm.
    private static final float SHOULDER_UP = 22f, SHOULDER_RIGHT = 5f, ARM = 10.5f;

    /**
     * Where the fist is when the right arm is at {@code angle} (the model's xRot: 0 = hanging down, -pi/2 = straight ahead, +pi/2 = straight
     * back). The angle grows with time, so the fist goes ahead, down, back and up: clockwise as seen from the player's right side.
     */
    public static Vec3 fistPos(LivingEntity p, float pt, double angle) {
        double up = (SHOULDER_UP - ARM * Mth.cos((float) angle)) / 16.0;
        double fwd = -ARM * Mth.sin((float) angle) / 16.0;
        double right = SHOULDER_RIGHT / 16.0;
        Vec3 face = JajankenFx.facing(p, pt);
        double x = Mth.lerp(pt, p.xo, p.getX()), y = Mth.lerp(pt, p.yo, p.getY()), z = Mth.lerp(pt, p.zo, p.getZ());
        return new Vec3(x + face.x * fwd - face.z * right, y + up, z + face.z * fwd + face.x * right);
    }

    /**
     * The pose, done on the model parts (called from PlayerModelMixin after the game has posed the player): the right arm turns round the
     * shoulder like a windmill while the left arm is held up as a guard. On the punch the right arm drives straight ahead.
     */
    public static void applyArm(PlayerModel<?> model, LivingEntity entity) {
        if (ACTIVE.isEmpty() || !(entity instanceof AbstractClientPlayer p)) return;
        Rec r = ACTIVE.get(p.getId());
        if (r == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || (p == mc.player && mc.options.getCameraType().isFirstPerson())) return;
        double now = mc.level.getGameTime() + mc.getFrameTime();
        if (r.mode == SPIN) {
            float in = (float) Mth.clamp((now - r.t0) / 2.0, 0, 1); // settles into the spin over two ticks
            model.rightArm.xRot = Mth.lerp(in, model.rightArm.xRot, (float) angle(rotations(r, now)));
            model.rightArm.yRot = Mth.lerp(in, model.rightArm.yRot, 0f);
            model.rightArm.zRot = Mth.lerp(in, model.rightArm.zRot, 0f);
            model.leftArm.xRot = Mth.lerp(in, model.leftArm.xRot, -0.9f);
            model.leftArm.yRot = Mth.lerp(in, model.leftArm.yRot, 0.35f);
            model.leftArm.zRot = Mth.lerp(in, model.leftArm.zRot, 0f);
        } else if (r.mode == PUNCH) {
            double age = now - r.punchAt;
            if (age < 0 || age > PUNCH_TICKS) return;
            float snap = (float) Mth.clamp(age / 1.5, 0, 1);
            float w = Math.min(snap, (float) Mth.clamp((PUNCH_TICKS - age) / 3.0, 0, 1));
            model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, -Mth.HALF_PI);
            model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, -0.1f);
            model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, 0f);
        } else {
            return;
        }
        model.rightSleeve.copyFrom(model.rightArm); // the mixin runs after the game copied each part onto its overlay layer
        model.leftSleeve.copyFrom(model.leftArm);
    }

    /** Self-registering client hooks, so no existing client event class needs editing. */
    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class CyclotronHooks {
        private CyclotronHooks() {}

        /** Drops finished punches, and spins whose owner has gone out of view or left the world. */
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END || ACTIVE.isEmpty()) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) {
                ACTIVE.clear();
                return;
            }
            double now = mc.level.getGameTime();
            Iterator<Rec> it = ACTIVE.values().iterator();
            while (it.hasNext()) {
                Rec r = it.next();
                if (r.mode == PUNCH && now - r.punchAt > PUNCH_TICKS + 2) it.remove();
                else if (r.mode == SPIN && mc.level.getEntity(r.owner) == null) it.remove();
            }
        }

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
            clear();
        }
    }
}
