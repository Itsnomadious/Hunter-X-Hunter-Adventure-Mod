package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.PlayerModelPart;
import org.joml.Matrix3f;
import org.joml.Quaternionf;
import net.hxhadventure.addon.ClientAddonState;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Draws the chain abilities as real 3D link models (see ChainModel) after entities are rendered.
 * Links are fine like the anime's (40% of the old size), the chains leave the caster's right hand,
 * and a ripple runs down them so they whip instead of snapping straight.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ChainRenderer {
    private ChainRenderer() {}

    private static final ResourceLocation STEEL = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/nen_chain.png");
    /** The Holy Chain's cross (green). */
    private static final ResourceLocation GREEN = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/nen_chain_holy.png");
    /** Plain white: tinted with the Ten colour and drawn glowing, it is the Ten that covers the Holy Chain and the green glow round its cross. */
    private static final ResourceLocation AURA = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/nen_aura_white.png");
    /** The green Ten colour (the same green as the green aura). */
    private static final int HOLY_GREEN = 0x28E646;
    /** How long the Holy Chain takes to wind on when you use it on yourself / to fly out to an ally, ticks. */
    private static final double HOLY_WIND_TICKS = 5.0, HOLY_CAST_TICKS = 3.5;
    /** Size of a link relative to the model (the model link is 4px = 0.25 block long). */
    private static final float SCALE = 0.4f;
    /** Opacity of the two Ten shells over the chains (90% more transparent than before: 0.40 and 0.17). */
    private static final float TEN_A1 = 0.04f, TEN_A2 = 0.017f;
    /** Link spacing: the old 0.17 scaled down with the links. */
    private static final double SPACING = 0.17 * SCALE;
    private static final int MAX_LINKS = 400;
    private static final int LIGHT = LightTexture.FULL_BRIGHT;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || (ChainFx.ACTIVE.isEmpty() && ChainMarks.isEmpty())) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        long now = level.getGameTime();
        double time = now + pt;
        PoseStack ps = e.getPoseStack();
        Camera camera = e.getCamera();
        Vec3 cam = camera.getPosition();
        ChainModel.Parts parts = ChainModel.parts(mc);
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType steelType = RenderType.entityCutoutNoCull(STEEL);

        Iterator<ChainFx.Fx> it = ChainFx.ACTIVE.iterator();
        while (it.hasNext()) {
            ChainFx.Fx fx = it.next();
            float age = (now - fx.start) + pt;
            if (age > fx.duration) {
                it.remove();
                continue;
            }
            Entity caster = level.getEntity(fx.caster);
            // In hides the chains from anyone without Gyo; a Chain Jail started from a mark (side = 2) is always secret
            boolean secret = fx.kind == ChainFx.Kind.JAIL && fx.side > 1.5f;
            if (caster == null || (secret ? secretHidden(fx.caster) : InFx.hiddenFrom(fx.caster))) continue;
            Vec3 hand = handPos(mc, camera, caster, pt);
            // Each effect takes its own buffer and ends it again: the buffer source only writes one render type at a time.
            switch (fx.kind) {
                case SWEEP -> {
                    coated(buf, steelType, caster, (pv, sc, lr, lg, lb, la) -> drawSweep(ps, pv, parts, cam, hand, fx, caster, pt, age, time, sc, lr, lg, lb, la));
                }
                case HOLY -> {
                    Entity t = level.getEntity(fx.target);
                    if (t != null) drawHoly(ps, buf, parts, mc, camera, cam, fx, caster, t, hand, pt, age, time);
                }
                case JAIL -> {
                    Entity t = level.getEntity(fx.target);
                    if (t != null) {
                        coated(buf, steelType, caster, (pv, sc, lr, lg, lb, la) -> drawJail(ps, pv, parts, cam, hand, t, pt, time, sc, lr, lg, lb, la));
                    }
                }
                case JUDGMENT -> {
                    Entity t = level.getEntity(fx.target);
                    if (t != null) {
                        coated(buf, steelType, caster, (pv, sc, lr, lg, lb, la) -> drawJudgment(ps, pv, parts, cam, hand, t, pt, age, time, sc, lr, lg, lb, la));
                    }
                }
                default -> { }
            }
        }
        if (!ChainMarks.isEmpty()) drawMarks(ps, buf, parts, mc, level, cam, pt, time, steelType);
    }

    /** True when something secret owned by this entity must not be drawn for the local player: only someone with Gyo active (the owner too) see it. */
    private static boolean secretHidden(int owner) {
        return !ClientAddonState.gyo; // not even their owner sees them without Gyo
    }

    /** One drawing of a chain: into this consumer, links at this size and tint. */
    private interface Pass {
        void draw(VertexConsumer vc, float scale, float r, float g, float b, float a);
    }

    /** Draws a chain in steel, then covers it in its caster's Ten (two glowing shells, as on the Holy Chain). */
    private static void coated(MultiBufferSource.BufferSource buf, RenderType steelType, Entity caster, Pass pass) {
        pass.draw(buf.getBuffer(steelType), SCALE, 1f, 1f, 1f, 1f);
        buf.endBatch(steelType);
        float[] t = tenOf(caster);
        RenderType glowType = RenderType.entityTranslucentEmissive(AURA);
        VertexConsumer glow = buf.getBuffer(glowType);
        pass.draw(glow, SCALE * 1.7f, t[0], t[1], t[2], TEN_A1);
        pass.draw(glow, SCALE * 2.6f, t[0], t[1], t[2], TEN_A2);
        buf.endBatch(glowType);
    }

    /** The caster's Ten colour as r, g, b (gold if they are not a player). */
    private static float[] tenOf(Entity caster) {
        int ten = caster instanceof Player pl ? AuraColours.rgb(pl) : 0xFFBF00;
        return new float[] {(ten >> 16 & 255) / 255f, (ten >> 8 & 255) / 255f, (ten & 255) / 255f};
    }

    /** Where the chains leave the caster: their right hand (for your own first-person view, the lower right of the screen). */
    private static Vec3 handPos(Minecraft mc, Camera camera, Entity caster, float pt) {
        if (caster == mc.player && mc.options.getCameraType().isFirstPerson()) {
            Vec3 c = camera.getPosition();
            var look = camera.getLookVector();
            var left = camera.getLeftVector();
            var up = camera.getUpVector();
            return c.add(look.x() * 0.6 - left.x() * 0.34 - up.x() * 0.30,
                         look.y() * 0.6 - left.y() * 0.34 - up.y() * 0.30,
                         look.z() * 0.6 - left.z() * 0.34 - up.z() * 0.30);
        }
        float yaw = caster instanceof LivingEntity le ? Mth.lerp(pt, le.yBodyRotO, le.yBodyRot) : caster.getYRot();
        ChainArm.Pose pose = ChainArm.of(caster, pt);
        double rad = Math.toRadians(yaw);
        Vec3 forward = new Vec3(-Math.sin(rad), 0, Math.cos(rad));
        Vec3 right = new Vec3(-Math.cos(rad), 0, -Math.sin(rad));
        Vec3 rest = caster.getPosition(pt).add(right.scale(0.38)).add(forward.scale(0.3)).add(0, caster.getBbHeight() * 0.58, 0);
        // the chains leave the fingertips of the arm that is moving with the ability
        return pose == null ? rest : rest.add(pose.hand().subtract(rest).scale(pose.weight));
    }

    /**
     * The Holy Chain. It runs on the same rope simulation as the Dowsing Chain (ChainRope: gravity, drag, the heavy tip, the rope's
     * own constraints, a spring that lags behind the guide path) with a cross where the Dowsing Chain has its ball.
     *  - On yourself: from the right hand's thumb, in under the left arm, round its left side and over the top, with the cross lying
     *    on top of the left forearm (see HolyWrap).
     *  - On an ally: cast out from the right hand to them, the cross landing on them.
     * The links are covered in the caster's Ten (their aura colour, glowing); the cross and the aura round it are green.
     */
    private static void drawHoly(PoseStack ps, MultiBufferSource.BufferSource buf, ChainModel.Parts parts, Minecraft mc, Camera camera, Vec3 cam,
                                 ChainFx.Fx fx, Entity caster, Entity target, Vec3 hand, float pt, float age, double time) {
        boolean self = target == caster;
        ChainArm.Pose hp = self ? ChainArm.holySelf(caster, pt) : null;
        if (self && hp == null) return;
        boolean firstPerson = caster == mc.player && mc.options.getCameraType().isFirstPerson();
        // first person: both of your arms are drawn here, before the chain (even on the first tick, before the rope has links)
        if (firstPerson && self) drawOwnArms(ps, buf, mc, cam, (AbstractClientPlayer) caster, hp, pt);

        HolyPath path;
        Vec3 start;
        HolyWrap.Frame fr = null;
        if (self) {
            fr = HolyWrap.frame(hp.leftShoulder, hp.leftDir, hp.bodyYawDeg);
            // your own arms are drawn here in the world in first person, so the chain starts from that right hand
            Vec3 h = firstPerson ? hp.hand() : hand;
            Vec3 under = HolyWrap.ring(fr, HolyWrap.U_START, -Math.PI / 2, HolyWrap.RADIUS);
            start = h.add(under.subtract(h).normalize().scale(0.04)).add(fr.up.scale(0.02)); // the thumb side of the hand
            List<Vec3> pts = new ArrayList<>();
            // thumb to the underside of the arm: a short sagging drape, fixed to both hands every frame
            double sag = Math.max(0.03, start.distanceTo(under) * 0.2);
            Vec3 ctl = start.add(under).scale(0.5).add(0, -2 * sag, 0);
            int drape = 6;
            for (int i = 0; i < drape; i++) {
                double t = i / (double) drape, a = (1 - t) * (1 - t), b = 2 * (1 - t) * t, c = t * t;
                pts.add(start.scale(a).add(ctl.scale(b)).add(under.scale(c)));
            }
            // then once round its underside, left side and top
            int arc = 14;
            for (int i = 0; i <= arc; i++) {
                double f = i / (double) arc;
                pts.add(HolyWrap.ring(fr, HolyWrap.U_START + (HolyWrap.U_END - HolyWrap.U_START) * f, -Math.PI / 2 + Math.PI * f, HolyWrap.RADIUS));
            }
            path = new HolyPath(pts, fx.duration, HOLY_WIND_TICKS, drape - 1);
        } else {
            start = hand;
            Vec3 to = target.getPosition(pt).add(0, target.getBbHeight() * 0.5, 0);
            List<Vec3> pts = new ArrayList<>();
            pts.add(start);
            pts.add(to);
            path = new HolyPath(pts, fx.duration, HOLY_CAST_TICKS, Integer.MAX_VALUE);
        }
        if (path.total < 0.05) return;

        List<Vec3> pts;
        if (self) {
            // On yourself the chain is NOT simulated: a rope with gravity and a lagging spring trails behind the arm and slides off it as
            // soon as you move. It is laid along the path instead, which is rebuilt from the arms every frame, so it is locked to them.
            pts = lockedPoints(path, age);
        } else {
            if (fx.rope == null) fx.rope = new ChainRope(16.0, 0.25, 1.0);
            fx.rope.advance(age, start.x, start.y, start.z, path);
            pts = ropePoints(fx.rope);
        }
        if (pts == null || pts.size() < 2) return;

        Vec3 tip = pts.get(pts.size() - 1), before = pts.get(pts.size() - 2);
        Vec3 endDir = tip.subtract(before);
        if (endDir.lengthSqr() < 1e-10) endDir = new Vec3(0, -1, 0);
        endDir = endDir.normalize();
        // the cross: lying flat on the forearm on yourself, hanging by its top from the chain's end on an ally
        Vec3 cd, cb, attach;
        if (self) {
            cd = fr.ax;
            cb = fr.left;
            attach = tip.add(fr.up.scale(0.025));
        } else {
            cd = endDir.scale(0.3).add(0, -0.7, 0).normalize();
            Vec3 side = new Vec3(0, 1, 0).cross(endDir);
            cb = side.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : side.normalize();
            double roll = time * 0.06;
            cb = cb.scale(Math.cos(roll)).add(cd.cross(cb).scale(Math.sin(roll)));
            attach = tip;
        }

        // 1. the links
        RenderType steelType = RenderType.entityCutoutNoCull(STEEL);
        walk(ps, buf.getBuffer(steelType), parts, cam, pts, SCALE, 1f, 1f, 1f, 1f);
        buf.endBatch(steelType);
        // 2. the green cross
        RenderType greenType = RenderType.entityCutoutNoCull(GREEN);
        crossAt(ps, buf.getBuffer(greenType), parts, cam, attach, cd, cb, 1f, 1f, 1f, 1f, 1f);
        buf.endBatch(greenType);
        // 3. glow: the caster's Ten over every link, green over the cross (a few thin shells, brightest nearest)
        float[] tc = tenOf(caster);
        float tr = tc[0], tg = tc[1], tb = tc[2];
        float gr = (HOLY_GREEN >> 16 & 255) / 255f, gg = (HOLY_GREEN >> 8 & 255) / 255f, gb = (HOLY_GREEN & 255) / 255f;
        float pulse = 0.85f + 0.15f * (float) Math.sin(time * 0.35);
        RenderType glowType = RenderType.entityTranslucentEmissive(AURA);
        VertexConsumer glow = buf.getBuffer(glowType);
        walk(ps, glow, parts, cam, pts, SCALE * 1.7f, tr, tg, tb, TEN_A1);
        walk(ps, glow, parts, cam, pts, SCALE * 2.6f, tr, tg, tb, TEN_A2);
        crossAt(ps, glow, parts, cam, attach, cd, cb, 1.4f, gr, gg, gb, 0.55f * pulse);
        crossAt(ps, glow, parts, cam, attach, cd, cb, 1.9f, gr, gg, gb, 0.30f * pulse);
        crossAt(ps, glow, parts, cam, attach, cd, cb, 2.5f, gr, gg, gb, 0.14f * pulse);
        buf.endBatch(glowType);
    }

    /**
     * The Holy Chain on yourself, rigid: the path itself from the hand out to as much chain as is paid out right now (it winds on, holds,
     * then is hauled in, exactly as the rope used to). Being a pure function of this frame's arm pose it cannot lag, sag or drift.
     */
    private static List<Vec3> lockedPoints(HolyPath path, double age) {
        double len = path.reel(age);
        if (len < 0.02) return null;
        int n = Math.max(2, (int) Math.ceil(len / 0.03));
        List<Vec3> pts = new ArrayList<>(n + 1);
        double[] o = new double[3];
        for (int i = 0; i <= n; i++) {
            path.point(age, len * i / n, o);
            pts.add(new Vec3(o[0], o[1], o[2]));
        }
        return pts;
    }

    /** What the Holy Chain's rope is steered along: a polyline in the world, rebuilt every frame from the arms' current pose. */
    private static final class HolyPath implements ChainRope.Path {
        private final Vec3[] p;
        private final double[] cum;
        final double total;
        private final double windTicks, inEnd;
        /** Arc length from which the chain is wrapped round the arm and held tight against it. */
        private final double gripFrom;

        HolyPath(List<Vec3> pts, int duration, double windTicks, int gripIndex) {
            p = pts.toArray(new Vec3[0]);
            cum = new double[p.length];
            for (int i = 1; i < p.length; i++) cum[i] = cum[i - 1] + p[i].distanceTo(p[i - 1]);
            total = cum[p.length - 1];
            this.windTicks = windTicks;
            this.inEnd = Math.max(1, duration - ChainRope.RETRACT_TICKS);
            this.gripFrom = gripIndex >= p.length ? Double.MAX_VALUE : cum[gripIndex];
        }

        /** Fraction of the path paid out: winds on quickly, holds, then is hauled in faster and faster (the same curves as the Dowsing Chain). */
        private double out(double age) {
            if (age < inEnd) {
                double x = Math.min(1.0, 0.15 + age / windTicks);
                return 1 - (1 - x) * (1 - x);
            }
            double r = clamp(((age - inEnd) / ChainRope.RETRACT_TICKS));
            return 1 - Math.pow(r, 1.25);
        }

        @Override
        public double reel(double age) {
            return total * out(age);
        }

        @Override
        public double guide(double age) {
            if (age < inEnd) return 1.0;
            double r = clamp((age - inEnd) / ChainRope.RETRACT_TICKS);
            return 1.0 - 0.5 * r * r * (3 - 2 * r); // looser as it is hauled in
        }

        @Override
        public double grip(double age, double s) {
            if (gripFrom == Double.MAX_VALUE) return 0.0;
            double r = clamp((s - gripFrom) / 0.1);
            return 3.0 * r * r * (3 - 2 * r);
        }

        @Override
        public void point(double age, double s, double[] out) {
            s = Math.max(0.0, Math.min(total, s));
            int i = 1;
            while (i < p.length - 1 && cum[i] < s) i++;
            double span = cum[i] - cum[i - 1];
            double f = span < 1e-9 ? 0.0 : (s - cum[i - 1]) / span;
            out[0] = p[i - 1].x + (p[i].x - p[i - 1].x) * f;
            out[1] = p[i - 1].y + (p[i].y - p[i - 1].y) * f;
            out[2] = p[i - 1].z + (p[i].z - p[i - 1].z) * f;
        }

        private static double clamp(double v) {
            return v < 0 ? 0 : Math.min(v, 1);
        }
    }

    /**
     * First person, Holy Chain on yourself: the game draws neither of your arms in this pose (and only the main hand at all), so both
     * are drawn here, in the world, the way the game draws a player's model, and the finger chains go on the right hand.
     */
    private static void drawOwnArms(PoseStack ps, MultiBufferSource.BufferSource buf, Minecraft mc, Vec3 cam, AbstractClientPlayer p,
                                    ChainArm.Pose pose, float pt) {
        if (!(mc.getEntityRenderDispatcher().getRenderer(p) instanceof PlayerRenderer pr)) return;
        PlayerModel<AbstractClientPlayer> m = pr.getModel();
        boolean slim = "slim".equals(p.getModelName());
        boolean crouch = p.isCrouching();
        float armY = crouch ? 5.2f : 2.0f;
        float extra = crouch ? 0.4f : 0f;
        m.rightArm.setPos(-5.0f, armY, 0.0f);
        m.leftArm.setPos(5.0f, armY, 0.0f);
        m.rightArm.xRot = -Mth.HALF_PI + pose.pitchRad + extra;
        m.rightArm.yRot = Mth.wrapDegrees(pose.yawDeg - pose.bodyYawDeg) * Mth.DEG_TO_RAD;
        m.rightArm.zRot = 0f;
        m.leftArm.xRot = -Mth.HALF_PI + pose.leftPitchRad + extra;
        m.leftArm.yRot = Mth.wrapDegrees(pose.leftYawDeg - pose.bodyYawDeg) * Mth.DEG_TO_RAD;
        m.leftArm.zRot = 0f;
        m.rightSleeve.copyFrom(m.rightArm);
        m.leftSleeve.copyFrom(m.leftArm);
        m.rightArm.visible = true;
        m.leftArm.visible = true;
        m.rightSleeve.visible = p.isModelPartShown(PlayerModelPart.RIGHT_SLEEVE);
        m.leftSleeve.visible = p.isModelPartShown(PlayerModelPart.LEFT_SLEEVE);

        ResourceLocation skin = p.getSkinTextureLocation();
        int light = mc.getEntityRenderDispatcher().getPackedLightCoords(p, pt);
        Vec3 pos = p.getPosition(pt);
        ps.pushPose();
        // the same steps the game takes before it draws a living entity's model
        ps.translate(pos.x - cam.x, pos.y - cam.y, pos.z - cam.z);
        ps.mulPose(Axis.YP.rotationDegrees(180.0f - pose.bodyYawDeg));
        ps.scale(-1.0f, -1.0f, 1.0f);
        ps.scale(0.9375f, 0.9375f, 0.9375f);
        ps.translate(0.0f, -1.501f, 0.0f);
        RenderType solid = RenderType.entitySolid(skin);
        VertexConsumer sv = buf.getBuffer(solid);
        m.rightArm.render(ps, sv, light, OverlayTexture.NO_OVERLAY);
        m.leftArm.render(ps, sv, light, OverlayTexture.NO_OVERLAY);
        buf.endBatch(solid);
        RenderType trans = RenderType.entityTranslucent(skin);
        VertexConsumer tv = buf.getBuffer(trans);
        m.rightSleeve.render(ps, tv, light, OverlayTexture.NO_OVERLAY);
        m.leftSleeve.render(ps, tv, light, OverlayTexture.NO_OVERLAY);
        buf.endBatch(trans);
        ps.pushPose();
        m.rightArm.translateAndRotate(ps);
        HandChains.render(ps, buf, light, slim, p);
        ps.popPose();
        buf.endBatch(HandChains.renderType());
        buf.endBatch(RenderType.entityTranslucentEmissive(AURA));
        ps.popPose();
    }

    /** The links of a rope: smoothed a little (the simulation steps are coarser than the links), then a curve through them. Null if too short to draw. */
    private static List<Vec3> ropePoints(ChainRope rope) {
        int n = rope.count();
        if (n < 2) return null;
        double[] px = new double[n], py = new double[n], pz = new double[n];
        for (int i = 0; i < n; i++) { px[i] = rope.x(i); py[i] = rope.y(i); pz[i] = rope.z(i); }
        for (int pass = 0; pass < 2; pass++) {
            double[] qx = px.clone(), qy = py.clone(), qz = pz.clone();
            for (int i = 1; i + 1 < n; i++) {
                px[i] = qx[i] * 0.5 + (qx[i - 1] + qx[i + 1]) * 0.25;
                py[i] = qy[i] * 0.5 + (qy[i - 1] + qy[i + 1]) * 0.25;
                pz[i] = qz[i] * 0.5 + (qz[i - 1] + qz[i + 1]) * 0.25;
            }
        }
        List<Vec3> pts = new ArrayList<>();
        for (int i = 0; i + 1 < n; i++) {
            int a0 = Math.max(0, i - 1), a3 = Math.min(n - 1, i + 2);
            for (int k = 0; k < 4; k++) {
                double t = k / 4.0, t2 = t * t, t3 = t2 * t;
                pts.add(new Vec3(
                    cr(px[a0], px[i], px[i + 1], px[a3], t, t2, t3),
                    cr(py[a0], py[i], py[i + 1], py[a3], t, t2, t3),
                    cr(pz[a0], pz[i], pz[i + 1], pz[a3], t, t2, t3)));
            }
        }
        pts.add(new Vec3(px[n - 1], py[n - 1], pz[n - 1]));
        return pts;
    }

    /** Interlocking links at even spacing along a polyline (world coordinates). */
    private static void walk(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, Vec3 cam, List<Vec3> pts) {
        walk(ps, vc, parts, cam, pts, SCALE, 1f, 1f, 1f, 1f);
    }

    /** Same, with the links at another size and tinted: the Ten that covers the Holy Chain is these, bigger, glowing and translucent. */
    private static void walk(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, Vec3 cam, List<Vec3> pts,
                             float scale, float r, float g, float b, float a) {
        boolean flat = true;
        double carry = 0;
        for (int i = 0; i + 1 < pts.size(); i++) {
            Vec3 p0 = pts.get(i), p1 = pts.get(i + 1);
            Vec3 d = p1.subtract(p0);
            double seg = d.length();
            if (seg < 1e-6) continue;
            Vec3 dir = d.scale(1.0 / seg);
            double t = carry;
            while (t < seg) {
                Vec3 p = p0.add(dir.scale(t));
                ChainDraw.piece(ps, vc, flat ? parts.flat() : parts.vertical(),
                    p.x - cam.x, p.y - cam.y, p.z - cam.z, dir.x, dir.y, dir.z, scale, LIGHT, r, g, b, a);
                flat = !flat;
                t += SPACING;
            }
            carry = t - seg;
        }
    }

    /**
     * The Holy Chain's cross, a Latin cross (long bar with a shorter bar across it near the top) hung by its top at `attach`.
     * d = direction of the long bar from the top toward the foot, b = direction of the cross bar; the face of the cross is perpendicular to both.
     * grow > 1 draws the same cross bigger about its middle (the glow shells round it).
     */
    private static void crossAt(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, Vec3 cam, Vec3 attach, Vec3 d, Vec3 b,
                                float grow, float r, float g, float bl, float a) {
        d = d.normalize();
        b = b.subtract(d.scale(b.dot(d)));
        if (b.lengthSqr() < 1e-8) b = Math.abs(d.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0).cross(d);
        b = b.normalize();
        Vec3 n = d.cross(b);   // the cross's face normal: b x n = d, so (b, n, d) is a right-handed frame
        Matrix3f basis = new Matrix3f(
            (float) b.x, (float) b.y, (float) b.z,
            (float) n.x, (float) n.y, (float) n.z,
            (float) d.x, (float) d.y, (float) d.z);
        final float len = (float) HolyWrap.CROSS_LEN;
        final float bar = len * 0.34f, thick = 0.6f, arm = len * 0.66f; // crossbar sits a third of the way down, and is about two thirds as long
        ps.pushPose();
        ps.translate(attach.x - cam.x, attach.y - cam.y, attach.z - cam.z);
        ps.mulPose(new Quaternionf().setFromNormalized(basis));
        ps.translate(0f, 0f, len * 0.5f);   // grow about the middle of the cross
        ps.scale(grow, grow, grow);
        ps.translate(0f, 0f, -len * 0.5f);
        // long bar
        piece(ps, vc, parts, 0f, 0f, len * 0.5f, 0.6f, thick, len * 16f, r, g, bl, a);
        // cross bar
        piece(ps, vc, parts, 0f, 0f, bar, arm * 16f, thick, 0.6f, r, g, bl, a);
        // collar where they cross, and a ring where the chain hangs from the top
        piece(ps, vc, parts, 0f, 0f, bar, 1.1f, 0.9f, 1.1f, r, g, bl, a);
        piece(ps, vc, parts, 0f, 0f, 0f, 1.0f, 1.0f, 0.8f, r, g, bl, a);
        ps.popPose();
    }

    /** One 1px cube stretched to (sx, sy, sz) px, centred at (x, y, z) blocks in the current frame. */
    private static void piece(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, float x, float y, float z,
                              float sx, float sy, float sz, float r, float g, float b, float a) {
        ps.pushPose();
        ps.translate(x, y, z);
        ps.scale(sx, sy, sz);
        parts.unit().render(ps, vc, LIGHT, OverlayTexture.NO_OVERLAY, r, g, b, a);
        ps.popPose();
    }

    /**
     * Chains wrapped round enemies that a Dowsing Chain hit while In was on. They are always hidden: only their owner and anyone
     * with Gyo can see them (see ChainMarks).
     */
    private static void drawMarks(PoseStack ps, MultiBufferSource.BufferSource buf, ChainModel.Parts parts, Minecraft mc, ClientLevel level,
                                  Vec3 cam, float pt, double time, RenderType steelType) {
        for (Map.Entry<Integer, Integer> en : ChainMarks.all().entrySet()) {
            Entity v = level.getEntity(en.getKey());
            if (v == null || !v.isAlive() || v == mc.player) continue;
            if (!ClientAddonState.gyo) continue; // marks are secret: Gyo only, the owner included
            Vec3 c = v.getPosition(pt);
            double h = v.getBbHeight(), r = Math.max(0.35, v.getBbWidth() * 0.5 + 0.12);
            List<Vec3> pts = new ArrayList<>();
            int n = 72;
            for (int i = 0; i <= n; i++) {
                double t = i / (double) n;
                double a = t * 3.0 * Math.PI * 2 + time * 0.03;
                pts.add(new Vec3(c.x + Math.cos(a) * r, c.y + h * (0.08 + 0.84 * t), c.z + Math.sin(a) * r));
            }
            coated(buf, steelType, level.getEntity(en.getValue()), (pv, sc, lr, lg, lb, la) -> walk(ps, pv, parts, cam, pts, sc, lr, lg, lb, la));
        }
    }

    /**
     * Dowsing Chain: swung from the left of the caster to the right, then left to curl up and reeled back into the hand.
     * The chain is a small rope simulation (ChainRope): it sags, whips and lags behind the hand, the heavy steel ball on the
     * end drags it, and it winds into a coil before it is hauled in.
     */
    private static void drawSweep(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, Vec3 cam, Vec3 origin, ChainFx.Fx fx, Entity caster, float pt, float age, double time,
                                  float scale, float cr, float cg, float cb, float ca) {
        double swing = ChainFx.sweepSwing(fx);
        if (fx.rope == null) fx.rope = new ChainRope(fx.range);
        ChainRope rope = fx.rope;
        double[] fwd = ChainFx.liveForward(fx, caster, pt);
        rope.advance(age, origin.x, origin.y, origin.z, fwd, ChainFx.sweepSide(fx, fwd), swing);
        List<Vec3> pts = ropePoints(rope);
        if (pts == null) return;
        walk(ps, vc, parts, cam, pts, scale, cr, cg, cb, ca);

        // the ball hangs just past the last link (its radius is about 1.1px at this scale)
        Vec3 last = pts.get(pts.size() - 1), before = pts.get(pts.size() - 2);
        Vec3 ld = last.subtract(before);
        if (ld.lengthSqr() < 1e-10) ld = new Vec3(0, -1, 0);
        ld = ld.normalize();
        Vec3 ball = last.add(ld.scale(0.07));
        ChainDraw.piece(ps, vc, parts.ball(), ball.x - cam.x, ball.y - cam.y, ball.z - cam.z, ld.x, ld.y, ld.z, scale, LIGHT, cr, cg, cb, ca);
    }

    /** Catmull-Rom spline point between p1 and p2. */
    private static double cr(double p0, double p1, double p2, double p3, double t, double t2, double t3) {
        return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
    }

    private static void drawJail(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, Vec3 cam, Vec3 hand, Entity victim, float pt, double time,
                                 float scale, float cr, float cg, float cb, float ca) {
        Vec3 center = victim.getPosition(pt);
        drawChain(ps, vc, parts, cam, hand, center.add(0, victim.getBbHeight() * 0.5, 0), true, time, 0.04, scale, cr, cg, cb, ca);
        double r = Math.max(0.7, victim.getBbWidth() * 0.9);
        int links = (int) Math.max(16, Math.min(160, Math.PI * 2 * r / SPACING));
        for (int ring = 0; ring < 3; ring++) {
            double y = victim.getBbHeight() * (0.15 + 0.35 * ring);
            double spin = time * 0.05 * (ring % 2 == 0 ? 1 : -1);
            for (int i = 0; i < links; i++) {
                double a = (Math.PI * 2 / links) * i + spin;
                // +Z follows the circle tangent
                ChainDraw.piece(ps, vc, i % 2 == 0 ? parts.flat() : parts.vertical(),
                    center.x + Math.cos(a) * r - cam.x, center.y + y - cam.y, center.z + Math.sin(a) * r - cam.z,
                    -Math.sin(a), 0, Math.cos(a), scale, LIGHT, cr, cg, cb, ca);
            }
        }
    }

    private static double unit01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }

    /**
     * The Judgment Chain: the chain shoots from the hand to the target's heart, ending in the Stake of Retribution (the pointed head,
     * ChainModel's "stake"). The stake drives in and vanishes, the chain reels back into the heart, and a double ring of links is left
     * spinning round it. Ticks: 0-5 flight, 6-9 the stake sinks in, 12-20 the chain reels in, the ring grows from tick 8. ChainFx
     * lasts JudgmentChain.FX_TICKS.
     */
    private static void drawJudgment(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, Vec3 cam, Vec3 hand, Entity victim, float pt, float age,
                                     double time, float scale, float cr, float cg, float cb, float ca) {
        Vec3 heart = victim.getPosition(pt).add(0, victim.getBbHeight() * 0.7, 0);
        Vec3 dir = heart.subtract(hand);
        double dist = dir.length();
        if (dist > 0.6) {
            Vec3 fwd = dir.scale(1.0 / dist);
            double stakeLen = 18.0 * SCALE * 2.25 / 16.0; // the stake is drawn 2.25x the link size: a little under a block long
            double fly = unit01(age / 5.0);
            fly = 1.0 - (1.0 - fly) * (1.0 - fly);
            Vec3 headEnd = heart.subtract(fwd.scale(stakeLen));       // where its origin is when the point touches the heart
            Vec3 origin = hand.add(headEnd.subtract(hand).scale(fly));
            double sink = unit01((age - 6.0) / 4.0);
            if (age >= 5.0) origin = headEnd.add(fwd.scale(stakeLen * sink));
            double reel = unit01((age - 12.0) / 8.0);
            Vec3 start = hand.add(heart.subtract(hand).scale(reel));
            drawChain(ps, vc, parts, cam, start, origin, false, time, 0.03 * (1.0 - reel), scale, cr, cg, cb, ca);
            float st = (float) (1.0 - sink);
            if (st > 0.03f) {
                ChainDraw.piece(ps, vc, parts.stake(), origin.x - cam.x, origin.y - cam.y, origin.z - cam.z, fwd.x, fwd.y, fwd.z,
                    scale * 2.25f * st, LIGHT, cr, cg, cb, ca);
            }
        }
        if (age >= 8.0) {
            double grow = unit01((age - 8.0) / 4.0);
            double r = 0.18 + 0.12 * grow;
            int links = (int) Math.max(10, Math.min(60, Math.PI * 2 * r / SPACING));
            for (int ring = 0; ring < 2; ring++) {
                double y = (ring == 0 ? -0.07 : 0.07) * grow;
                double spin = time * 0.12 * (ring == 0 ? 1 : -1);
                for (int i = 0; i < links; i++) {
                    double a = (Math.PI * 2 / links) * i + spin;
                    ChainDraw.piece(ps, vc, i % 2 == 0 ? parts.flat() : parts.vertical(),
                        heart.x + Math.cos(a) * r - cam.x, heart.y + y - cam.y, heart.z + Math.sin(a) * r - cam.z,
                        -Math.sin(a), 0, Math.cos(a), scale, LIGHT, cr, cg, cb, ca);
                }
            }
        }
    }

    /**
     * A chain of interlocking links from a to b with a travelling ripple (amp in blocks, zero at both ends),
     * optionally ending in the dagger.
     */
    private static void drawChain(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, Vec3 cam, Vec3 a, Vec3 b, boolean tip, double time, double amp,
                                  float scale, float cr, float cg, float cb, float ca) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 0.05) return;
        Vec3 dir = d.scale(1.0 / len);
        Vec3 side = Math.abs(dir.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(-dir.z, 0, dir.x).normalize();
        Vec3 up = dir.cross(side);
        int n = (int) Math.min(MAX_LINKS, len / SPACING);
        if (n < 1) return;
        double step = len / n;

        Vec3 prev = a.add(wobble(side, up, 0, n, time, amp));
        Vec3 lastDir = dir;
        for (int i = 0; i < n; i++) {
            Vec3 next = a.add(dir.scale((i + 1) * step)).add(wobble(side, up, i + 1, n, time, amp));
            Vec3 seg = next.subtract(prev);
            if (seg.lengthSqr() > 1e-10) lastDir = seg;
            Vec3 mid = prev.add(seg.scale(0.5));
            ChainDraw.piece(ps, vc, i % 2 == 0 ? parts.flat() : parts.vertical(),
                mid.x - cam.x, mid.y - cam.y, mid.z - cam.z, lastDir.x, lastDir.y, lastDir.z, scale, LIGHT, cr, cg, cb, ca);
            prev = next;
        }
        if (tip) {
            ChainDraw.piece(ps, vc, parts.tip(), b.x - cam.x, b.y - cam.y, b.z - cam.z, lastDir.x, lastDir.y, lastDir.z, scale, LIGHT, cr, cg, cb, ca);
        }
    }

    /** Sideways offset of link i: a wave that travels toward the tip and is pinned at both ends. */
    private static Vec3 wobble(Vec3 side, Vec3 up, int i, int n, double time, double amp) {
        if (amp <= 0) return Vec3.ZERO;
        double u = i / (double) n;
        double env = Math.sin(Math.PI * u);
        double ph = i * 0.38 - time * 0.9;
        return side.scale(Math.sin(ph) * amp * env).add(up.scale(Math.cos(ph) * amp * 0.6 * env));
    }
}
