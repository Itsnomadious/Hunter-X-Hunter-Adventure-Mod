package net.hxhadventure.addon.client;

import net.minecraft.world.entity.player.Player;

/** Maps a player's permanent aura colour (1-9, as stored by HxHAdventure) to a readable RGB value for the UI. */
public final class AuraColours {
    private AuraColours() {}

    /** Ids 1-9: gold, light blue, red, dark blue, green, purple, pink, white, black (exactly the Ten aura colours; dark blue is the blue Ren uses).
     *  Ids 10-21: yellow, silver, lime, cyan, coral, teal, grey, forest, maroon, indigo, midnight. */
    private static final int[] RGB = {0xFFBF00, 0x00AFFF, 0xC40C00, 0x5A46EB, 0x28E646, 0xA03CFF, 0xFF5ABE, 0xF5F5FF, 0x0C0C10,
        0xFFEC46, 0xC8CDD7, 0xAAFF3C, 0x00E6E6, 0xFF7050, 0x009688, 0x64646E, 0x00602C, 0x8C0022, 0x3E2096, 0x1A0E42};

    public static int rgb(Player p) {
        int id = p == null ? 0 : p.getPersistentData().getInt("HxHCraft_PermanentAuraColor");
        int i = id > 0 ? id - 1 : 0;
        return RGB[Math.min(i, RGB.length - 1)];
    }
}
