package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.hxhadventure.addon.Terpsichora;

/** Client-side record of every Terpsichora in view (fed by PacketTerpsichoraFx), keyed by its owner's entity id. */
public final class TerpsichoraFx {
    private TerpsichoraFx() {}

    /** Ticks for it to appear / vanish. */
    public static final double BORN_TICKS = 14, DIE_TICKS = 12;

    public static final class Rec {
        public final int owner;
        public int mode;
        public double born, ended = -1, deadSince = -1;
        /** Smoothed anchor (where its feet are) and facing: it trails the user a little, as if hanging from the strings. */
        public double sx, sy, sz;
        public float yaw;
        public boolean placed;
        public double last = Double.NaN;
        public long lastParticleTick = Long.MIN_VALUE;

        Rec(int owner, double born) {
            this.owner = owner;
            this.born = born;
        }
    }

    private static final Map<Integer, Rec> ACTIVE = new HashMap<>();

    public static Map<Integer, Rec> all() {
        return ACTIVE;
    }

    public static boolean isEmpty() {
        return ACTIVE.isEmpty();
    }

    public static void set(int owner, int mode) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        double now = level.getGameTime();
        Rec r = ACTIVE.get(owner);
        if (mode != Terpsichora.OFF) {
            if (r == null || r.ended >= 0) {
                r = new Rec(owner, now);
                ACTIVE.put(owner, r);
            }
            if (mode == Terpsichora.DEAD && r.mode != Terpsichora.DEAD) r.deadSince = now;
            r.mode = mode;
        } else if (r != null && r.ended < 0) {
            r.ended = now;
        }
    }

    /** The local player's Terpsichora mode (0 gone, 1 buffs on, 2 post-mortem, 3 figure out). Drives the red screen. */
    public static int localMode() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || ACTIVE.isEmpty()) return Terpsichora.OFF;
        Rec r = ACTIVE.get(mc.player.getId());
        return r == null || r.ended >= 0 ? Terpsichora.OFF : r.mode;
    }

    /** Ticks since the local player's corpse was raised, with partial tick (0 if not post-mortem). */
    public static double localDeadAge(float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return 0;
        Rec r = ACTIVE.get(mc.player.getId());
        if (r == null || r.deadSince < 0) return 0;
        return Math.max(0, mc.level.getGameTime() + partialTick - r.deadSince);
    }

    /**
     * True while this entity's Terpsichora figure is out and working their arms: its first second (MANIFEST) or the post-mortem dance
     * (DEAD). While only the buffs are on (ACTIVE) the figure has gone and the arms are normal.
     */
    public static boolean isActive(int entityId) {
        if (ACTIVE.isEmpty()) return false;
        Rec r = ACTIVE.get(entityId);
        return r != null && r.ended < 0 && (r.mode == Terpsichora.MANIFEST || r.mode == Terpsichora.DEAD);
    }

    /** The marionette pose: both arms straight out to the sides, hanging from the strings. Called from PlayerModelMixin. */
    public static void applyArms(net.minecraft.client.model.PlayerModel<?> model, net.minecraft.world.entity.LivingEntity entity) {
        if (ACTIVE.isEmpty() || !(entity instanceof net.minecraft.client.player.AbstractClientPlayer p) || !isActive(p.getId())) return;
        Minecraft mc = Minecraft.getInstance();
        if (p == mc.player && mc.options.getCameraType().isFirstPerson()) return; // first person draws its own hand
        model.rightArm.xRot = 0f;
        model.rightArm.yRot = 0f;
        model.rightArm.zRot = (float) (Math.PI / 2);
        model.leftArm.xRot = 0f;
        model.leftArm.yRot = 0f;
        model.leftArm.zRot = (float) (-Math.PI / 2);
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
