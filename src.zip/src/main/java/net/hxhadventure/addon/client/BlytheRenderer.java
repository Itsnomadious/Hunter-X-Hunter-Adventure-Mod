package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.Tuning;
import net.hxhadventure.addon.client.BlythePose.V;

/**
 * Draws Doctor Blythe: the hunched doll with its big head, skeletal arms and fingers, the tail cord that runs from the
 * user's lower back to its right wrist, and a glowing tendril from every finger that is touching something.
 *
 * Solid parts (torso, head, hair, shoulder puffs, collar) are model boxes; everything that bends (arms, fingers, wings,
 * rods, cord, tendrils) is a 1px "stick" part stretched between two points of the skeleton from {@link BlythePose}.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class BlytheRenderer {
    private BlytheRenderer() {}

    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/doctor_blythe.png");
    private static final int GLOW = LightTexture.FULL_BRIGHT;
    private static final double CULL_DISTANCE = 96.0;
    /** The model's boxes are authored in px; drawn at 2x so the head is 1.75 blocks wide. */
    private static final float BOX = 2f;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || BlytheFx.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        double time = level.getGameTime() + pt;
        Vec3 cam = e.getCamera().getPosition();
        BlytheModel.Parts parts = BlytheModel.parts(mc);
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.entityCutoutNoCull(TEX);
        VertexConsumer vc = buf.getBuffer(type);

        Iterator<BlytheFx.Rec> it = BlytheFx.all().values().iterator();
        while (it.hasNext()) {
            BlytheFx.Rec r = it.next();
            if (r.ended >= 0 && time - r.ended > BlytheFx.DIE_TICKS) {
                it.remove();
                continue;
            }
            if (cam.distanceToSqr(r.x, r.y, r.z) > CULL_DISTANCE * CULL_DISTANCE) continue;
            r.step(time, level);
            new Scene(e.getPoseStack(), vc, parts, cam, level, r, time, pt).draw();
        }
        buf.endBatch(type);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Everything needed to draw one doll this frame. */
    private static final class Scene {
        final PoseStack ps;
        final VertexConsumer vc;
        final BlytheModel.Parts parts;
        final Vec3 cam;
        final ClientLevel level;
        final BlytheFx.Rec r;
        final double time;
        final float pt;
        /** Appear/vanish scale, and the doll's yaw as a rotation about Y (+Z in doll space = the way it faces). */
        final double g, phi, cos, sin;
        final int light;

        Scene(PoseStack ps, VertexConsumer vc, BlytheModel.Parts parts, Vec3 cam, ClientLevel level,
              BlytheFx.Rec r, double time, float pt) {
            this.ps = ps;
            this.vc = vc;
            this.parts = parts;
            this.cam = cam;
            this.level = level;
            this.r = r;
            this.time = time;
            this.pt = pt;
            double born = clamp((time - r.born) / BlytheFx.BORN_TICKS, 0, 1);
            double grow = 1 - Math.pow(1 - born, 3);
            double die = r.ended >= 0 ? clamp((time - r.ended) / BlytheFx.DIE_TICKS, 0, 1) : 0;
            this.g = Math.max(0.001, grow * (1 - die));
            this.phi = -Math.toRadians(r.yawDeg); // forward = (-sin yaw, cos yaw) = (sin phi, cos phi)
            this.cos = Math.cos(phi);
            this.sin = Math.sin(phi);
            this.light = LevelRenderer.getLightColor(level, BlockPos.containing(r.x, r.y + 2.0, r.z));
        }

        // ---------- space conversion ----------
        /** Doll space (blocks) to world. */
        Vec3 w(V l) {
            double x = l.x() * g, y = l.y() * g, z = l.z() * g;
            return new Vec3(r.x + x * cos + z * sin, r.y + y, r.z - x * sin + z * cos);
        }

        /** World to doll space. */
        V local(Vec3 world) {
            double s = Math.max(g, 0.05);
            double dx = world.x - r.x, dy = world.y - r.y, dz = world.z - r.z;
            return new V((dx * cos - dz * sin) / s, dy / s, (dx * sin + dz * cos) / s);
        }

        // ---------- drawing helpers ----------
        /** Opens a frame at a doll-space point, turned by yaw/pitch/roll (radians) in doll space. Close with ps.popPose(). */
        void frame(V at, double yaw, double pitch, double roll) {
            Vec3 p = w(at);
            ps.pushPose();
            ps.translate(p.x - cam.x, p.y - cam.y, p.z - cam.z);
            ps.mulPose(Axis.YP.rotation((float) phi));
            ps.mulPose(Axis.YP.rotation((float) yaw));
            ps.mulPose(Axis.XP.rotation((float) pitch));
            ps.mulPose(Axis.ZP.rotation((float) roll));
            ps.scale((float) g, (float) g, (float) g);
        }

        /** Draws a model box inside the open frame, its bottom centre offset (blocks) from the frame's origin. */
        void child(ModelPart part, double ox, double oy, double oz) {
            ps.pushPose();
            ps.translate(ox, oy, oz);
            ps.scale(BOX, BOX, BOX);
            ps.mulPose(Axis.XP.rotation((float) Math.PI)); // vanilla's model convention: y down, front at -Z
            part.render(ps, vc, light, OverlayTexture.NO_OVERLAY);
            ps.popPose();
        }

        /** A square stick of the given thickness (blocks, before the appear scale) from world point a to b. */
        void bone(ModelPart part, Vec3 a, Vec3 b, double thick, int lt) {
            double dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1e-5) return;
            ps.pushPose();
            ps.translate(a.x - cam.x, a.y - cam.y, a.z - cam.z);
            ps.mulPose(Axis.YP.rotation((float) Math.atan2(dx, dz)));
            ps.mulPose(Axis.XP.rotation((float) -Math.asin(clamp(dy / len, -1, 1))));
            float t = (float) (thick * g * 16.0), l = (float) (len * 16.0);
            ps.scale(t, t, l);
            part.render(ps, vc, lt, OverlayTexture.NO_OVERLAY);
            ps.popPose();
        }

        void bone(ModelPart part, V a, V b, double thick) {
            bone(part, w(a), w(b), thick, light);
        }

        /** A short fat stick centred on a joint, running along dir: the knobbly joints of the skeleton. */
        void knob(ModelPart part, V at, V dir, double half, double thick) {
            V d = dir.mul(half);
            bone(part, at.sub(d), at.add(d), thick);
        }

        // ---------- the whole doll ----------
        void draw() {
            // what each finger is touching, in the world and in doll space
            V[] contact = new V[BlytheFx.FINGERS];
            Vec3[] contactW = new Vec3[BlytheFx.FINGERS];
            for (int f = 0; f < BlytheFx.FINGERS; f++) {
                if (r.fTarget[f] < 0 || r.ext[f] <= 0.001f) continue;
                Entity t = level.getEntity(r.fTarget[f]);
                if (t == null) continue;
                contactW[f] = contactPoint(t, f);
                contact[f] = local(contactW[f]);
            }
            BlythePose.Pose p = BlythePose.compute(time, contact, r.ext);
            body(p);
            arms(p);
            cord(p);
            tendrils(p, contactW);
        }

        /** Where on the body a finger's tendril lands: spread up the body, on the side facing the doll. */
        Vec3 contactPoint(Entity t, int f) {
            Vec3 pos = t.getPosition(pt);
            double yf = 0.3 + 0.12 * ((f * 3) % 5);
            Vec3 c = pos.add(0, t.getBbHeight() * yf, 0);
            Vec3 toDoll = new Vec3(r.x - pos.x, 0, r.z - pos.z);
            if (toDoll.lengthSqr() > 1e-4) c = c.add(toDoll.normalize().scale(Math.min(0.45, t.getBbWidth() * 0.45)));
            return c;
        }

        void body(BlythePose.Pose p) {
            // torso with its riveted collar
            frame(p.hip, 0, p.torsoPitch, 0);
            child(parts.torso(), 0, 0, 0);
            child(parts.collar(), 0, BlythePose.TORSO_LEN - 0.3, 0);
            ps.popPose();

            // the head hangs forward and low, in a bob of plum hair with a fringe
            frame(p.chin, p.headYaw, p.headPitch, 0);
            child(parts.head(), 0, 0, 0);
            child(parts.hairBack(), 0, -0.125, -0.9375);
            child(parts.hairTop(), 0, 1.75, 0);
            child(parts.hairSide(), 1.0, 0.125, -0.0625);
            child(parts.hairSide(), -1.0, 0.125, -0.0625);
            child(parts.bangs(), 0, 1.375, 0.875);
            ps.popPose();

            for (int h = 0; h < 2; h++) {
                double sx = h == 0 ? 1 : -1;
                V sh = p.shoulder[h];
                // big cream shoulder puffs, tilted out
                frame(sh.add(new V(sx * 0.2, -0.65, 0)), 0, p.torsoPitch * 0.8, -sx * 0.3);
                child(parts.puff(), 0, 0, 0);
                ps.popPose();
                // a little fan of plum feathers on top of each puff
                V base = sh.add(new V(sx * 0.15, 0.55, -0.1));
                bone(parts.plum(), base, base.add(new V(sx * 0.10, 0.50, -0.25)), 0.10);
                bone(parts.plum(), base, base.add(new V(sx * 0.32, 0.42, -0.22)), 0.10);
                bone(parts.plum(), base, base.add(new V(sx * 0.52, 0.22, -0.16)), 0.10);
            }

            // the exposed rods and pistons in the chest under the chin
            for (double x : new double[]{-0.35, 0, 0.35}) {
                V off = p.torsoNormal.mul(0.6).add(new V(x, 0, 0));
                V a = p.hip.add(p.torsoAxis.mul(0.7)).add(off);
                V b = p.hip.add(p.torsoAxis.mul(1.45)).add(off);
                bone(parts.metal(), a, b, 0.05);
                bone(parts.bone(), a, a.add(p.torsoAxis.mul(0.25)), 0.09);
            }
        }

        void arms(BlythePose.Pose p) {
            for (int h = 0; h < 2; h++) {
                V sh = p.shoulder[h], el = p.elbow[h], wr = p.wrist[h];
                V uDir = el.sub(sh).norm(), fDir = wr.sub(el).norm();

                bone(parts.bone(), sh, el, 0.11);                         // upper arm
                knob(parts.bone(), el, uDir, 0.08, 0.17);                 // elbow
                V off = p.across[h].mul(0.05);                            // forearm: two thin bones side by side
                bone(parts.bone(), el.add(off), wr.add(off), 0.055);
                bone(parts.bone(), el.sub(off), wr.sub(off), 0.055);
                bone(parts.metal(), wr.sub(fDir.mul(0.14)), wr.add(fDir.mul(0.06)), 0.15); // wrist cuff (the tail ties to the right one)

                V pd = p.handDir[h];
                V palm = wr.add(pd.mul(0.22));
                bone(parts.bone(), wr.add(pd.mul(0.04)), palm, 0.13);
                for (int k = 0; k < 5; k++) {
                    int f = h * 5 + k;
                    V[] fg = p.finger[f];
                    bone(parts.bone(), wr.add(pd.mul(0.08)), fg[0], 0.045);          // metacarpal
                    double th = k == 0 ? 0.05 : 0.04;
                    for (int j = 0; j < 3; j++) {
                        bone(parts.bone(), fg[j], fg[j + 1], th);
                        if (j > 0) knob(parts.bone(), fg[j], fg[j + 1].sub(fg[j]).norm(), 0.03, th * 1.8);
                    }
                    V d = fg[3].sub(fg[2]).norm();
                    boolean live = r.ext[f] > 0.3f;                                   // the tip lights up while it heals
                    bone(live ? parts.glow() : parts.metal(), w(fg[3].sub(d.mul(0.07))), w(fg[3].add(d.mul(0.05))), 0.075, live ? GLOW : light);
                }
            }
        }

        /** The user's tail: a cord from their lower back to the doll's right wrist, slack until it is pulled tight. */
        void cord(BlythePose.Pose p) {
            Entity owner = level.getEntity(r.owner);
            if (owner == null) return;
            Vec3 a = tailPoint(owner);
            Vec3 b = w(p.wrist[1]);
            Vec3 d = b.subtract(a);
            double len = d.length();
            if (len < 0.05) return;
            double slack = Math.max(0, 1 - len / Tuning.BLYTHE_TETHER_RANGE);
            double sag = 0.2 + 0.2 * len * slack;               // hangs lower with more slack, taut at full stretch
            int n = (int) clamp(len / 0.22, 6, 90);
            Vec3 prev = a;
            for (int i = 1; i <= n; i++) {
                double u = i / (double) n;
                Vec3 q = a.add(d.scale(u)).add(0, -4 * sag * u * (1 - u), 0);
                bone(parts.cord(), prev, q, 0.035, light);
                prev = q;
            }
            Vec3 dir = d.scale(1.0 / len);
            bone(parts.metal(), a.subtract(dir.scale(0.03)), a.add(dir.scale(0.06)), 0.11, light); // ring where it leaves the user
        }

        /** Where the tail grows out of the user: the small of the back, a little behind them. */
        Vec3 tailPoint(Entity owner) {
            float yaw = owner instanceof LivingEntity le ? Mth.rotLerp(pt, le.yBodyRotO, le.yBodyRot) : owner.getYRot();
            double rad = Math.toRadians(yaw);
            Vec3 forward = new Vec3(-Math.sin(rad), 0, Math.cos(rad));
            return owner.getPosition(pt).subtract(forward.scale(0.24))
                .add(0, owner.getBbHeight() * (owner.isCrouching() ? 0.38 : 0.44), 0);
        }

        void tendrils(BlythePose.Pose p, Vec3[] contactW) {
            for (int f = 0; f < BlytheFx.FINGERS; f++) {
                float e = r.ext[f];
                if (e <= 0.01f || contactW[f] == null) continue;
                Vec3 from = w(p.finger[f][3]);
                double eased = 1 - Math.pow(1 - e, 3);
                Vec3 end = from.add(contactW[f].subtract(from).scale(eased));
                tendril(from, end, f, e);
            }
        }

        /** One healing tendril: a curling strand with a bright pulse running down it to the thing being healed. */
        void tendril(Vec3 a, Vec3 b, int f, float e) {
            Vec3 d = b.subtract(a);
            double len = d.length();
            if (len < 0.05) return;
            Vec3 dir = d.scale(1.0 / len);
            Vec3 side = Math.abs(dir.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(-dir.z, 0, dir.x).normalize();
            Vec3 up = dir.cross(side);
            int n = (int) clamp(len / 0.14, 4, 44);
            double curve = Math.min(0.45, len * 0.14);
            double ph = f * 1.3;
            Vec3 prev = a;
            for (int i = 1; i <= n; i++) {
                double u = i / (double) n;
                double env = Math.sin(Math.PI * u);                       // pinned at both ends
                double w1 = Math.sin(u * 9 - time * 0.35 + f) * 0.05 * env;
                double w2 = Math.cos(u * 7 - time * 0.30 + f) * 0.04 * env;
                Vec3 q = a.add(d.scale(u))
                    .add(side.scale(Math.cos(ph) * curve * env + w1))
                    .add(up.scale(Math.sin(ph) * curve * env + w2));
                double pulse = Math.pow(Math.max(0, Math.cos(2 * Math.PI * (u * 1.1 - time * 0.045 - f * 0.13))), 8);
                double thick = (0.05 - 0.028 * u) * (1 + 0.9 * pulse);
                bone(pulse > 0.45 ? parts.glow() : parts.tendril(), prev, q, thick, GLOW);
                prev = q;
            }
            bone(parts.glow(), b.subtract(dir.scale(0.05)), b.add(dir.scale(0.05)), 0.09, GLOW); // where it touches
        }
    }
}
