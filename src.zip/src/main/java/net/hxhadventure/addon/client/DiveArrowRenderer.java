package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * Draws the golden arrows of Dragon Dive: a bright shaft with a pointed head and fletching, wrapped in a soft glow and
 * trailing a streak of light up the sky. Pure additive geometry like the rest of the dragon's effects.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class DiveArrowRenderer {
    private DiveArrowRenderer() {}

    private static final double LEN = 5.0;        // shaft length
    private static final double TRAIL = 14.0;     // streak above the arrow
    private static final double MAX_DIST_SQ = 300.0 * 300.0;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || DiveArrowFx.ACTIVE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        double time = level.getGameTime() + e.getPartialTick();
        Vec3 cam = e.getCamera().getPosition();
        Matrix4f m = e.getPoseStack().last().pose();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.lightning();
        VertexConsumer vc = buf.getBuffer(type);

        Iterator<DiveArrowFx.Arrow> it = DiveArrowFx.ACTIVE.iterator();
        while (it.hasNext()) {
            DiveArrowFx.Arrow a = it.next();
            double y = a.startY - a.speed * (time - a.t0);   // the arrow's tip
            if (y <= a.impactY || time - a.t0 > 400) {
                it.remove();
                continue;
            }
            double dx = a.x - cam.x, dz = a.z - cam.z;
            if (dx * dx + dz * dz > MAX_DIST_SQ) continue;
            arrow(m, vc, dx, y - cam.y, dz, Math.min(1.0, (a.startY - y) / 6.0));
        }
        buf.endBatch(type);
    }

    /** One arrow pointing straight down with its tip at (x, y, z) (camera relative). `fade` ramps it in just after it appears. */
    private static void arrow(Matrix4f m, VertexConsumer vc, double x, double y, double z, double fade) {
        double tipY = y, headTop = y + 1.1, tail = y + LEN;
        for (int k = 0; k < 2; k++) {
            double ox = k == 0 ? 1 : 0, oz = k == 0 ? 0 : 1;
            // glowing streak: bright at the arrow, fading away up the sky
            double sw = 0.28;
            v(m, vc, x - ox * sw, tipY + 0.2, z - oz * sw, 255, 230, 120, (int) (150 * fade));
            v(m, vc, x + ox * sw, tipY + 0.2, z + oz * sw, 255, 230, 120, (int) (150 * fade));
            v(m, vc, x + ox * sw, tail + TRAIL, z + oz * sw, 255, 200, 60, 0);
            v(m, vc, x - ox * sw, tail + TRAIL, z - oz * sw, 255, 200, 60, 0);
            // soft glow around the shaft, then the bright shaft itself
            quadV(m, vc, x, z, ox, oz, headTop, tail, 0.22, 255, 190, 40, (int) (70 * fade));
            quadV(m, vc, x, z, ox, oz, headTop, tail, 0.07, 255, 245, 190, (int) (235 * fade));
            // arrowhead: a diamond tapering to the tip
            v(m, vc, x - ox * 0.22, headTop, z - oz * 0.22, 255, 230, 110, (int) (235 * fade));
            v(m, vc, x + ox * 0.22, headTop, z + oz * 0.22, 255, 230, 110, (int) (235 * fade));
            v(m, vc, x, tipY, z, 255, 255, 230, (int) (255 * fade));
            v(m, vc, x, tipY, z, 255, 255, 230, (int) (255 * fade));
            // fletching: two swept feathers at the top
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                v(m, vc, x, tail - 1.2, z, 255, 215, 90, (int) (220 * fade));
                v(m, vc, x, tail, z, 255, 215, 90, (int) (220 * fade));
                v(m, vc, x + sgn * ox * 0.55, tail + 0.6, z + sgn * oz * 0.55, 255, 215, 90, (int) (160 * fade));
                v(m, vc, x + sgn * ox * 0.55, tail - 0.6, z + sgn * oz * 0.55, 255, 215, 90, (int) (160 * fade));
            }
        }
    }

    /** A vertical quad in the plane through (x, z) along (ox, oz), from y0 to y1, half-width w. */
    private static void quadV(Matrix4f m, VertexConsumer vc, double x, double z, double ox, double oz, double y0, double y1, double w,
                              int r, int g, int b, int a) {
        v(m, vc, x - ox * w, y0, z - oz * w, r, g, b, a);
        v(m, vc, x + ox * w, y0, z + oz * w, r, g, b, a);
        v(m, vc, x + ox * w, y1, z + oz * w, r, g, b, a);
        v(m, vc, x - ox * w, y1, z - oz * w, r, g, b, a);
    }

    private static void v(Matrix4f m, VertexConsumer vc, double x, double y, double z, int r, int g, int b, int a) {
        vc.vertex(m, (float) x, (float) y, (float) z).color(r, g, b, Math.max(0, Math.min(255, a))).endVertex();
    }
}
