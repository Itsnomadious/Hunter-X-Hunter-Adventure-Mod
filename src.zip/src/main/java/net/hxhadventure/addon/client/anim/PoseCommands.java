package net.hxhadventure.addon.client.anim;

import net.hxhadventure.HxHAdventure;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/**
 * /pose - client-side tools for building poses. Typical loop:
 *   /pose show demo_guard        show a pose on yourself (hold a sword to see the armed arm bones)
 *   /pose nudge main_arm x -10    tweak live; /pose set bone x y z sets all three
 *   /pose info                   hand height, blade pitch and tip clearance of what you see
 *   /pose dump                   print + copy the edited pose as json, ready to paste into a pose file
 *   /pose anim demo_punch   play an animation (then /pose freeze 8 to hold tick 8)
 *   /pose reload                 reload the json files (same as F3+T)   /pose clear   back to normal
 */
@Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, value = Dist.CLIENT)
public final class PoseCommands {
    private PoseCommands() {}

    private static final SuggestionProvider<CommandSourceStack> POSES =
            (c, b) -> SharedSuggestionProvider.suggest(PoseLibrary.poseNames(), b);
    private static final SuggestionProvider<CommandSourceStack> ANIMS =
            (c, b) -> SharedSuggestionProvider.suggest(PoseLibrary.animationNames(), b);
    private static final SuggestionProvider<CommandSourceStack> BONES =
            (c, b) -> SharedSuggestionProvider.suggest(Pose.BONES, b);
    private static final SuggestionProvider<CommandSourceStack> AXES =
            (c, b) -> SharedSuggestionProvider.suggest(new String[]{"x", "y", "z"}, b);
    private static final SuggestionProvider<CommandSourceStack> HANDS =
            (c, b) -> SharedSuggestionProvider.suggest(new String[]{"main", "off"}, b);

    @SubscribeEvent
    public static void register(RegisterClientCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("pose")
                .then(Commands.literal("list").executes(PoseCommands::list))
                .then(Commands.literal("show").then(Commands.argument("name", StringArgumentType.word())
                        .suggests(POSES).executes(PoseCommands::show)))
                .then(Commands.literal("anim").then(Commands.argument("name", StringArgumentType.word())
                        .suggests(ANIMS).executes(c -> anim(c, true))
                        .then(Commands.argument("loop", BoolArgumentType.bool()).executes(c -> anim(c, BoolArgumentType.getBool(c, "loop"))))))
                .then(Commands.literal("freeze").then(Commands.argument("tick", FloatArgumentType.floatArg(0F)).executes(PoseCommands::freeze)))
                .then(Commands.literal("play").executes(c -> {
                    PoseDebug.resume();
                    return msg(c, "animation running");
                }))
                .then(Commands.literal("clear").executes(c -> {
                    PoseDebug.clear();
                    return msg(c, "back to the normal pose");
                }))
                .then(Commands.literal("set").then(Commands.argument("bone", StringArgumentType.word()).suggests(BONES)
                        .then(Commands.argument("x", FloatArgumentType.floatArg())
                                .then(Commands.argument("y", FloatArgumentType.floatArg())
                                        .then(Commands.argument("z", FloatArgumentType.floatArg()).executes(PoseCommands::set))))))
                .then(Commands.literal("nudge").then(Commands.argument("bone", StringArgumentType.word()).suggests(BONES)
                        .then(Commands.argument("axis", StringArgumentType.word()).suggests(AXES)
                                .then(Commands.argument("deg", FloatArgumentType.floatArg()).executes(PoseCommands::nudge)))))
                .then(Commands.literal("turn").then(Commands.argument("deg", FloatArgumentType.floatArg()).executes(c -> {
                    PoseDebug.edit().turn = FloatArgumentType.getFloat(c, "deg");
                    return done(c);
                })))
                .then(Commands.literal("lean").then(Commands.argument("deg", FloatArgumentType.floatArg()).executes(c -> {
                    PoseDebug.edit().lean = FloatArgumentType.getFloat(c, "deg");
                    return done(c);
                })))
                .then(Commands.literal("wrist").then(Commands.argument("hand", StringArgumentType.word()).suggests(HANDS)
                        .then(Commands.argument("deg", FloatArgumentType.floatArg()).executes(c -> item(c, false)))))
                .then(Commands.literal("pitch").then(Commands.argument("hand", StringArgumentType.word()).suggests(HANDS)
                        .then(Commands.argument("deg", FloatArgumentType.floatArg()).executes(c -> item(c, true)))))
                .then(Commands.literal("info").executes(PoseCommands::info))
                .then(Commands.literal("dump").executes(PoseCommands::dump))
                .then(Commands.literal("reload").executes(c -> {
                    Minecraft.getInstance().reloadResourcePacks();
                    return msg(c, "reloading resources (poses included)");
                })));
    }

    private static int msg(CommandContext<CommandSourceStack> c, String text) {
        c.getSource().sendSuccess(() -> Component.literal(text), false);
        return Command.SINGLE_SUCCESS;
    }

    private static int fail(CommandContext<CommandSourceStack> c, String text) {
        c.getSource().sendFailure(Component.literal(text));
        return 0;
    }

    private static int done(CommandContext<CommandSourceStack> c) {
        PoseDebug.rebake();
        return msg(c, "ok");
    }

    private static int list(CommandContext<CommandSourceStack> c) {
        msg(c, "poses: " + String.join(", ", PoseLibrary.poseNames()));
        msg(c, "animations: " + String.join(", ", PoseLibrary.animationNames()));
        for (String e : PoseLibrary.errors()) fail(c, e);
        return Command.SINGLE_SUCCESS;
    }

    private static int show(CommandContext<CommandSourceStack> c) {
        String name = StringArgumentType.getString(c, "name");
        Pose p = PoseLibrary.rawPose(name);
        if (p == null) return fail(c, "no pose named '" + name + "' (see /pose list)");
        Pose copy = p.copy();
        PoseRig.bake(copy);
        PoseDebug.show(copy);
        return msg(c, "showing '" + name + "' (it is a copy: edits never touch the file until you paste /pose dump)");
    }

    private static int anim(CommandContext<CommandSourceStack> c, boolean loop) {
        String name = StringArgumentType.getString(c, "name");
        if (PoseLibrary.animation(name) == null) return fail(c, "no animation named '" + name + "' (see /pose list)");
        PoseDebug.play(name, loop);
        return msg(c, "playing '" + name + "'" + (loop ? " (looping)" : "") + " - /pose freeze <tick> to hold a frame");
    }

    private static int freeze(CommandContext<CommandSourceStack> c) {
        PoseDebug.freeze(FloatArgumentType.getFloat(c, "tick"));
        return msg(c, "frozen (the animation must be playing: /pose anim <name>)");
    }

    private static int set(CommandContext<CommandSourceStack> c) {
        int i = Pose.boneIndex(StringArgumentType.getString(c, "bone"));
        if (i < 0) return fail(c, "bones: " + String.join(", ", Pose.BONES));
        Pose p = PoseDebug.edit();
        p.rot[i][0] = FloatArgumentType.getFloat(c, "x");
        p.rot[i][1] = FloatArgumentType.getFloat(c, "y");
        p.rot[i][2] = FloatArgumentType.getFloat(c, "z");
        return done(c);
    }

    private static int nudge(CommandContext<CommandSourceStack> c) {
        int i = Pose.boneIndex(StringArgumentType.getString(c, "bone"));
        if (i < 0) return fail(c, "bones: " + String.join(", ", Pose.BONES));
        int axis = "xyz".indexOf(StringArgumentType.getString(c, "axis"));
        if (axis < 0) return fail(c, "axis must be x, y or z");
        Pose p = PoseDebug.edit();
        p.rot[i][axis] = Pose.or0(p.rot[i][axis]) + FloatArgumentType.getFloat(c, "deg");
        return done(c);
    }

    private static int item(CommandContext<CommandSourceStack> c, boolean pitch) {
        String hand = StringArgumentType.getString(c, "hand");
        int h = "main".equals(hand) ? 0 : "off".equals(hand) ? 1 : -1;
        if (h < 0) return fail(c, "hand must be main or off");
        float v = FloatArgumentType.getFloat(c, "deg");
        Pose p = PoseDebug.edit();
        p.wrist[h] = pitch ? Float.NaN : v;
        p.pitchDown[h] = pitch ? v : Float.NaN;
        return done(c);
    }

    private static int info(CommandContext<CommandSourceStack> c) {
        List<String> lines = PoseRig.lastInfo;
        if (lines.isEmpty()) return fail(c, "nothing yet: hold a sword, /pose show <name> and look at yourself in third person (F5), then run it again");
        for (String l : lines) msg(c, l);
        return Command.SINGLE_SUCCESS;
    }

    private static int dump(CommandContext<CommandSourceStack> c) {
        if (!PoseDebug.anyActive()) return fail(c, "no debug pose: /pose show <name> first");
        String json = new GsonBuilder().setPrettyPrinting().create().toJson(PoseDebug.edit().toJson());
        Minecraft.getInstance().keyboardHandler.setClipboard(json);
        LogUtils.getLogger().info("/pose dump:\n{}", json);
        for (String line : json.split("\n")) msg(c, line);
        return msg(c, "copied to the clipboard and written to the log");
    }
}
