package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.network.PacketBvAuto;

/**
 * Client half of Black Voice's Auto Pilot (the body swap needs nothing here any more: it is a disguise plus a clone, all on the server).
 * While the server says a needle is driving you (see PacketBvAuto):
 * <ul>
 *   <li>nothing you press moves you: WASD, jump, sneak, attack, use and the inventory are dead;</li>
 *   <li>the view is turned to where the NPC brain wants to look, and the keys it wants (forward, jump, sprint) are pressed for you.</li>
 * </ul>
 * Self-registering.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class BlackVoiceClient {
    private BlackVoiceClient() {}

    private static boolean on;
    private static float wantYaw, wantPitch;
    private static boolean forward, jump, sprint;

    /** From PacketBvAuto. */
    public static void setAuto(boolean active, float yaw, float pitch, int flags) {
        boolean was = on;
        on = active;
        wantYaw = yaw;
        wantPitch = pitch;
        forward = (flags & PacketBvAuto.FORWARD) != 0;
        jump = (flags & PacketBvAuto.JUMP) != 0;
        sprint = (flags & PacketBvAuto.SPRINT) != 0;
        if (!on && was) release();
    }

    public static boolean active() {
        return on;
    }

    private static void release() {
        forward = false;
        jump = false;
        sprint = false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options != null) mc.options.keySprint.setDown(false);
    }

    /** What you press is thrown away; what the needle wants is pressed instead. */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent e) {
        if (!on) return;
        Input in = e.getInput();
        in.up = forward;
        in.down = false;
        in.left = false;
        in.right = false;
        in.forwardImpulse = forward ? 1f : 0f;
        in.leftImpulse = 0f;
        in.jumping = jump;
        in.shiftKeyDown = false;
    }

    /** Attack, use and pick-block do nothing (the server's brain does the attacking). */
    @SubscribeEvent
    public static void onClick(InputEvent.InteractionKeyMappingTriggered e) {
        if (!on) return;
        e.setCanceled(true);
        e.setSwingHand(false);
    }

    /** No opening the inventory or a chest while the needle drives. */
    @SubscribeEvent
    public static void onScreen(ScreenEvent.Opening e) {
        if (on && e.getNewScreen() instanceof net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?>) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.START || !on) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.options.keySprint.setDown(sprint && forward);
        // the view goes where the brain looks (a fast turn, not a snap, so it reads as a person turning); your mouse is overruled every tick
        float yaw = mc.player.getYRot();
        float pitch = mc.player.getXRot();
        float dYaw = Mth.wrapDegrees(wantYaw - yaw);
        float dPitch = wantPitch - pitch;
        float step = 0.55f;
        mc.player.setYRot(yaw + dYaw * step);
        mc.player.setXRot(Mth.clamp(pitch + dPitch * step, -90f, 90f));
        mc.player.yRotO = mc.player.getYRot();
        mc.player.xRotO = mc.player.getXRot();
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        on = false;
        release();
    }
}
