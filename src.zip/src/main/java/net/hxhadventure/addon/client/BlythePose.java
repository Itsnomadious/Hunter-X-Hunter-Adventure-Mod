package net.hxhadventure.addon.client;

/**
 * Doctor Blythe's skeleton, as pure maths (no Minecraft imports) so it is easy to test on its own.
 *
 * Everything is in Blythe's own space, in blocks: +Y up, +Z the way it faces (the way its user was facing when it was
 * summoned), +X its left, origin on the ground at the anchor. The renderer turns these points into world positions.
 *
 * The doll: a hunched torso leaning forward over its user, a huge head hanging in front of the chest, and two long
 * skeletal arms (two-bone IK) ending in five-fingered hands. Each finger has three bones. While a finger is touching
 * something it straightens and points at the contact point, and the hand drifts toward what it is healing.
 * Hand 0 is the left (+X) hand, hand 1 the right (-X) hand, which stays near the user's back because it holds the tail.
 */
public final class BlythePose {
    private BlythePose() {}

    public record V(double x, double y, double z) {
        public static final V ZERO = new V(0, 0, 0);

        public V add(V o) { return new V(x + o.x, y + o.y, z + o.z); }
        public V sub(V o) { return new V(x - o.x, y - o.y, z - o.z); }
        public V mul(double s) { return new V(x * s, y * s, z * s); }
        public double dot(V o) { return x * o.x + y * o.y + z * o.z; }
        public V cross(V o) { return new V(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x); }
        public double len() { return Math.sqrt(x * x + y * y + z * z); }

        public V norm() {
            double l = len();
            return l < 1e-9 ? ZERO : mul(1.0 / l);
        }

        public V lerp(V o, double t) { return add(o.sub(this).mul(t)); }

        /** This vector turned about the unit axis k by angle a (Rodrigues). */
        public V rot(V k, double a) {
            double c = Math.cos(a), s = Math.sin(a);
            return mul(c).add(k.cross(this).mul(s)).add(k.mul(k.dot(this) * (1 - c)));
        }
    }

    public static final int FINGERS = 10;
    public static final double TORSO_LEN = 2.25;
    public static final V HIP = new V(0, 1.9, -0.3);
    public static final double UPPER_ARM = 1.55, FOREARM = 1.65;

    /** Bone lengths per finger (thumb, index, middle, ring, little), blocks. */
    private static final double[][] FINGER_LEN = {
        {0.30, 0.24, 0.20}, {0.40, 0.28, 0.22}, {0.46, 0.32, 0.25}, {0.42, 0.29, 0.22}, {0.32, 0.22, 0.18}};
    /** Where each finger starts across the palm, from the inner edge (thumb) to the outer edge. */
    private static final double[] FINGER_OFF = {-0.17, -0.09, -0.01, 0.07, 0.14};

    public static final class Pose {
        public double torsoPitch, headPitch, headYaw;
        /** hip: bottom of the torso. neck: top of the torso. chin: the head's pivot (bottom centre of the head box). */
        public V hip, neck, chin;
        /** Unit vectors along the torso (hip to neck) and out of its front. */
        public V torsoAxis, torsoNormal;
        public final V[] shoulder = new V[2], elbow = new V[2], wrist = new V[2];
        /** Per hand: across the palm pointing outward, and the way the palm faces (unit). */
        public final V[] across = new V[2], palmFace = new V[2];
        /** Per hand: the way the hand points (unit). The palm's centre is wrist + handDir * 0.22. */
        public final V[] handDir = new V[2];
        /** finger[f][0] = knuckle, [1], [2] = joints, [3] = tip. f = hand * 5 + (0 thumb .. 4 little). */
        public final V[][] finger = new V[FINGERS][4];
    }

    /**
     * @param t       time in ticks (animation)
     * @param contact for each finger, the point it is touching in Blythe's space, or null
     * @param ext     for each finger, how far its tendril has grown (0..1)
     */
    public static Pose compute(double t, V[] contact, float[] ext) {
        Pose p = new Pose();
        double breath = Math.sin(t * 0.07);

        p.torsoPitch = 0.87 + 0.03 * breath; // about 50 degrees forward
        p.torsoAxis = new V(0, Math.cos(p.torsoPitch), Math.sin(p.torsoPitch));
        p.torsoNormal = new V(0, -Math.sin(p.torsoPitch), Math.cos(p.torsoPitch));
        p.hip = HIP;
        p.neck = p.hip.add(p.torsoAxis.mul(TORSO_LEN));

        // the head hangs low and forward, and turns toward what is being healed
        V look = centroid(contact, ext, 0.2);
        double yaw = look == null ? 0 : clamp(Math.atan2(look.x - p.neck.x, look.z - p.neck.z), -0.7, 0.7);
        p.headYaw = yaw * 0.8 + 0.07 * Math.sin(t * 0.031);
        p.headPitch = 0.45 + 0.04 * Math.sin(t * 0.047 + 1.0) + 0.02 * breath;
        p.chin = p.neck.add(new V(0, -0.65, 0.55));

        for (int h = 0; h < 2; h++) {
            double sx = h == 0 ? 1 : -1;
            V sh = p.neck.add(new V(sx * 0.95, -0.2, -0.05));
            p.shoulder[h] = sh;

            V rest = h == 0
                ? new V(1.25 + 0.08 * Math.sin(t * 0.045), 1.05 + 0.06 * Math.sin(t * 0.06), 2.55 + 0.08 * Math.cos(t * 0.05))
                : new V(-1.05, 1.1 + 0.03 * Math.sin(t * 0.06 + 2.0), 1.15); // holds the tail near the user's back

            // the hand drifts toward what its fingers are touching
            V sum = V.ZERO;
            double w = 0;
            for (int k = 0; k < 5; k++) {
                int f = h * 5 + k;
                if (contact[f] != null && ext[f] > 0.01f) {
                    sum = sum.add(contact[f].mul(ext[f]));
                    w += ext[f];
                }
            }
            V goal = rest;
            if (w > 0.01) {
                V d = sum.mul(1.0 / w).sub(rest);
                double dl = d.len();
                if (dl > 1.8) d = d.mul(1.8 / dl);
                goal = rest.add(d.mul((h == 0 ? 0.6 : 0.25) * Math.min(1.0, w / 3.0)));
            }

            V[] arm = ik(sh, goal, new V(sx * 0.7, 0.45, -0.5));
            p.elbow[h] = arm[0];
            p.wrist[h] = arm[1];

            // hand frame
            V fd = p.wrist[h].sub(p.elbow[h]).norm();
            V pd = fd.lerp(new V(0, -0.55, 0.83).norm(), 0.35).norm();                 // the way the hand points
            V pf = new V(0, -1, 0).add(new V(-sx, 0, 0).mul(0.35));                     // palm faces down and a little inward
            pf = pf.sub(pd.mul(pf.dot(pd))).norm();
            V curlAxis = pd.cross(pf).norm();                                           // turning pd about this bends toward the palm
            V across = curlAxis.mul(sx);
            p.across[h] = across;
            p.handDir[h] = pd;
            p.palmFace[h] = pf;
            V palm = p.wrist[h].add(pd.mul(0.22));

            for (int k = 0; k < 5; k++) {
                int f = h * 5 + k;
                V base = k == 0
                    ? palm.add(across.mul(FINGER_OFF[0])).sub(pd.mul(0.10))
                    : palm.add(across.mul(FINGER_OFF[k])).add(pd.mul(0.14));
                p.finger[f][0] = base;
                V tdir = contact[f] != null && ext[f] > 0.001f ? contact[f].sub(base).norm() : null;
                double sway = Math.sin(t * 0.05 + f * 0.9);
                double cum = 0;
                V pos = base;
                for (int j = 0; j < 3; j++) {
                    cum += (j == 0 ? 0.3 : j == 1 ? 0.65 : 0.6) + 0.04 * sway * (j + 1);
                    V d = pd.rot(curlAxis, cum).add(across.mul(FINGER_OFF[k] * 1.6)).norm(); // curled, with the fingers fanned
                    if (tdir != null) d = d.lerp(tdir, Math.min(1.0, ext[f])).norm();         // straightens at its target
                    pos = pos.add(d.mul(FINGER_LEN[k][j]));
                    p.finger[f][j + 1] = pos;
                }
            }
        }
        return p;
    }

    /** Two-bone IK: elbow and wrist for a shoulder reaching a goal; the elbow bends toward the pole. */
    static V[] ik(V s, V goal, V pole) {
        V d = goal.sub(s);
        double dist = Math.min(Math.max(d.len(), 0.2), UPPER_ARM + FOREARM - 0.02);
        V dn = d.norm();
        double a = (UPPER_ARM * UPPER_ARM - FOREARM * FOREARM + dist * dist) / (2 * dist);
        double hgt = Math.sqrt(Math.max(0, UPPER_ARM * UPPER_ARM - a * a));
        V pp = pole.sub(dn.mul(pole.dot(dn)));
        pp = pp.len() < 1e-6 ? new V(0, 1, 0) : pp.norm();
        return new V[]{s.add(dn.mul(a)).add(pp.mul(hgt)), s.add(dn.mul(dist))};
    }

    private static V centroid(V[] contact, float[] ext, double minExt) {
        V sum = V.ZERO;
        double w = 0;
        for (int f = 0; f < FINGERS; f++) {
            if (contact[f] != null && ext[f] > minExt) {
                sum = sum.add(contact[f].mul(ext[f]));
                w += ext[f];
            }
        }
        return w > 1e-6 ? sum.mul(1.0 / w) : null;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
