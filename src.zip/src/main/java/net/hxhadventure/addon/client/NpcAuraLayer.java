package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

/**
 * An NPC's Ten / Ken glow: the model drawn again in the Ten aura texture, the same way players' auras are drawn. Like every Nen sight in this mod it only shows to players who have unlocked Nen.
 */
public class NpcAuraLayer<T extends Mob> extends RenderLayer<T, NpcModel<T>> {
    /** How the glow looks right now: {width, depth, alpha, green, blue}, or null for no glow. */
    public interface Style<T> {
        float[] look(T npc);
    }

    private final ResourceLocation tex;
    private final Style<T> style;

    public NpcAuraLayer(RenderLayerParent<T, NpcModel<T>> parent, ResourceLocation tex, Style<T> style) {
        super(parent);
        this.tex = tex;
        this.style = style;
    }

    /** The common look: Ten is a plain glow, Ken fuller and more opaque. Flags: 1 Ten, 4 Ken. */
    public static <T extends Mob> Style<T> standard(java.util.function.ToIntFunction<T> flags) {
        return npc -> {
            int f = flags.applyAsInt(npc);
            if ((f & 1) == 0) return null;
            boolean form = (f & 4) != 0;
            return new float[] {form ? 1.2f : 1.1f, form ? 1.3f : 1.2f, form ? 0.85f : 0.6f, 1f, 1f};
        };
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, T npc, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (npc.isInvisible()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !mc.player.getPersistentData().getBoolean("HxHCraft_NenUnlocked")) return;
        float[] s = style.look(npc);
        if (s == null) return;
        RenderType type = RenderType.entityTranslucentEmissive(tex);
        pose.pushPose();
        pose.scale(s[0], 1.0f, s[1]);
        getParentModel().renderToBuffer(pose, buffers.getBuffer(type), 15728880, OverlayTexture.NO_OVERLAY, 1f, s[3], s[4], s[2]);
        pose.popPose();
    }
}
