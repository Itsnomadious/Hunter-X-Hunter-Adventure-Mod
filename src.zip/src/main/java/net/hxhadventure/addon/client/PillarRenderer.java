package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * The golden pillar of aura that shoots into the sky when Dragon Head is summoned: three nested cylinders (white-gold core,
 * gold body, orange halo) that swell out fast, hold, then thin away. Brightest at the ground and fading toward the top.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class PillarRenderer {
    private PillarRenderer() {}

    private static final int SIDES = 20;
    private static final double HEIGHT = 90;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || PillarFx.ACTIVE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        double time = level.getGameTime() + e.getPartialTick();
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        Matrix4f m = ps.last().pose();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.lightning();
        VertexConsumer vc = buf.getBuffer(type);

        Iterator<PillarFx.Pillar> it = PillarFx.ACTIVE.iterator();
        while (it.hasNext()) {
            PillarFx.Pillar p = it.next();
            double t = (time - p.t0) / p.ticks;
            if (t >= 1) {
                it.remove();
                continue;
            }
            if (t < 0) continue;
            double swell = 1 - Math.pow(1 - Math.min(1, t / 0.15), 3);          // bursts out in the first 15%
            double thin = t < 0.6 ? 1 : 1 - (t - 0.6) / 0.4;                    // then thins away over the last 40%
            double w = swell * thin * (1 + 0.06 * Math.sin(time * 1.7));
            Vec3 base = new Vec3(p.x - cam.x, p.y - cam.y, p.z - cam.z);
            cylinder(m, vc, base, 0.8 * w, 255, 245, 200, 230, 40);
            cylinder(m, vc, base, 1.5 * w, 255, 205, 70, 150, 20);
            cylinder(m, vc, base, 2.3 * w, 255, 150, 30, 80, 0);
            // a flash of light on the ground where it starts
            double flash = Math.max(0, 1 - t / 0.25);
            if (flash > 0) disc(m, vc, base.add(0, 0.05, 0), 5.0 * swell, 255, 220, 120, (int) (170 * flash));
        }
        buf.endBatch(type);
    }

    /** A cylinder from the ground up, opaque-ish at the bottom and fading to `topAlpha` at the top. */
    private static void cylinder(Matrix4f m, VertexConsumer vc, Vec3 base, double r, int cr, int cg, int cb, int bottomAlpha, int topAlpha) {
        if (r < 0.01) return;
        for (int s = 0; s < SIDES; s++) {
            double a0 = 2 * Math.PI * s / SIDES, a1 = 2 * Math.PI * (s + 1) / SIDES;
            double x0 = base.x + Math.cos(a0) * r, z0 = base.z + Math.sin(a0) * r;
            double x1 = base.x + Math.cos(a1) * r, z1 = base.z + Math.sin(a1) * r;
            double yb = base.y, yt = base.y + HEIGHT;
            v(m, vc, x0, yb, z0, cr, cg, cb, bottomAlpha);
            v(m, vc, x1, yb, z1, cr, cg, cb, bottomAlpha);
            v(m, vc, x1, yt, z1, cr, cg, cb, topAlpha);
            v(m, vc, x0, yt, z0, cr, cg, cb, topAlpha);
        }
    }

    private static void disc(Matrix4f m, VertexConsumer vc, Vec3 c, double r, int cr, int cg, int cb, int alpha) {
        for (int s = 0; s < SIDES; s++) {
            double a0 = 2 * Math.PI * s / SIDES, a1 = 2 * Math.PI * (s + 1) / SIDES;
            v(m, vc, c.x, c.y, c.z, cr, cg, cb, alpha);
            v(m, vc, c.x + Math.cos(a0) * r, c.y, c.z + Math.sin(a0) * r, cr, cg, cb, 0);
            v(m, vc, c.x + Math.cos(a1) * r, c.y, c.z + Math.sin(a1) * r, cr, cg, cb, 0);
            v(m, vc, c.x, c.y, c.z, cr, cg, cb, alpha);
        }
    }

    private static void v(Matrix4f m, VertexConsumer vc, double x, double y, double z, int r, int g, int b, int a) {
        vc.vertex(m, (float) x, (float) y, (float) z).color(r, g, b, a).endVertex();
    }
}
