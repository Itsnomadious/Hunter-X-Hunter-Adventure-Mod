package net.hxhadventure.addon.client;

import java.util.HashSet;
import java.util.Set;

/** Client-side set of entity ids whose Hatsu is the Chains (fed by PacketChainHand). */
public final class ChainHand {
    private ChainHand() {}

    private static final Set<Integer> ACTIVE = new HashSet<>();

    public static void set(int entityId, boolean on) {
        if (on) ACTIVE.add(entityId);
        else ACTIVE.remove(entityId);
    }

    public static boolean has(int entityId) {
        return !ACTIVE.isEmpty() && ACTIVE.contains(entityId);
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
