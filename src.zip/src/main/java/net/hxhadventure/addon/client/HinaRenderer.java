package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.hxhadventure.addon.HinaEntity;

public class HinaRenderer extends NpcPlayerRenderer<HinaEntity> {
    public HinaRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, h -> tex("hina"), h -> false);
    }
}
