package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterDimensionSpecialEffectsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The look of the Nen dimension: no sky, plain white fog. It lives here (a client-side effects id named in the dimension's inline type)
 * instead of in a custom biome, so the saved world refers to nothing of this mod's registries and still opens without it.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class NenVoidEffects extends DimensionSpecialEffects {
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("hxhadventure", "nen_void");

    private NenVoidEffects() {
        super(Float.NaN, false, SkyType.NONE, false, true);
    }

    @Override
    public Vec3 getBrightnessDependentFogColor(Vec3 color, float brightness) {
        return new Vec3(1.0, 1.0, 1.0);
    }

    @Override
    public boolean isFoggyAt(int x, int z) {
        return false;
    }

    @SubscribeEvent
    public static void register(RegisterDimensionSpecialEffectsEvent e) {
        e.register(ID, new NenVoidEffects());
    }
}
