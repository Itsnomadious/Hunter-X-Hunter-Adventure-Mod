package net.hxhadventure.addon.client;

import net.minecraft.resources.ResourceLocation;
import net.hxhadventure.HxHAdventure;
import net.hxhadventure.addon.TerpsichoraEntity;
import software.bernie.geckolib.model.GeoModel;

public class TerpsichoraModel extends GeoModel<TerpsichoraEntity> {
    @Override public ResourceLocation getModelResource(TerpsichoraEntity a)     { return ResourceLocation.fromNamespaceAndPath(HxHAdventure.MOD_ID, "geo/terpsichora.geo.json"); }
    @Override public ResourceLocation getTextureResource(TerpsichoraEntity a)   { return ResourceLocation.fromNamespaceAndPath(HxHAdventure.MOD_ID, "textures/entity/terpsichora.png"); }
    @Override public ResourceLocation getAnimationResource(TerpsichoraEntity a) { return ResourceLocation.fromNamespaceAndPath(HxHAdventure.MOD_ID, "animations/terpsichora.animation.json"); }
}
