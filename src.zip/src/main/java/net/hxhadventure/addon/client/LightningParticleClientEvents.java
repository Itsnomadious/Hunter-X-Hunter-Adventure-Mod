package net.hxhadventure.addon.client;

import net.hxhadventure.addon.HxHParticles;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Hooks the Lightning Aura particle up to its sprites on the client. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class LightningParticleClientEvents {
    private LightningParticleClientEvents() {}

    @SubscribeEvent
    public static void onRegisterParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(HxHParticles.KILLUA_LIGHTNING.get(), LightningAuraParticle.Provider::new);
    }
}
