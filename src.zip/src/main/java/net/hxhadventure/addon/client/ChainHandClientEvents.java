package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderArmEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * First person: while the Chains are on, the game's right arm is drawn here instead of by the game, and the chains are
 * drawn straight after it with the very same pose stack and arm part. Because the arm and the chains are one draw,
 * they can never drift apart when you attack, run, bob or switch items.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ChainHandClientEvents {
    private ChainHandClientEvents() {}

    @SubscribeEvent
    public static void onArm(RenderArmEvent e) {
        AbstractClientPlayer p = e.getPlayer();
        if (e.getArm() != HumanoidArm.RIGHT || p.isInvisible() || !ChainHand.has(p.getId())) return;
        // Holy Chain wrapped round your own arm: both arms are drawn in the world with the chain (ChainRenderer), not here
        if (ChainArm.holySelf(p, Minecraft.getInstance().getFrameTime()) != null) {
            e.setCanceled(true);
            return;
        }
        EntityRenderer<?> r = Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(p);
        if (!(r instanceof PlayerRenderer pr)) return;

        // Pose the model the way PlayerRenderer.renderHand does for the first-person hand.
        PlayerModel<AbstractClientPlayer> m = pr.getModel();
        m.attackTime = 0f;
        m.crouching = false;
        m.swimAmount = 0f;
        m.rightArmPose = HumanoidModel.ArmPose.EMPTY;
        m.leftArmPose = HumanoidModel.ArmPose.EMPTY;
        m.setupAnim(p, 0f, 0f, 0f, 0f, 0f);
        // The attack's older keyframe clip (punch / kick, from the player animation layer) is applied to the model by that setupAnim call and
        // is not meant for the first-person hand: on top of the game's own swing (which is already in the pose stack) it made the arm move twice.
        // Put the arm back to its plain first-person rest pose, exactly what the game's hand has (the idle sway at time 0), so only the swing plays.
        m.rightArm.resetPose();
        AnimationUtils.bobModelPart(m.rightArm, 0f, 1f);
        m.rightArm.xRot = 0f;
        m.rightSleeve.copyFrom(m.rightArm);
        m.rightSleeve.xRot = 0f;
        m.rightArm.visible = true;
        m.rightSleeve.visible = p.isModelPartShown(PlayerModelPart.RIGHT_SLEEVE);

        PoseStack ps = e.getPoseStack();
        ResourceLocation skin = p.getSkinTextureLocation();
        VertexConsumer solid = e.getMultiBufferSource().getBuffer(RenderType.entitySolid(skin));
        m.rightArm.render(ps, solid, e.getPackedLight(), OverlayTexture.NO_OVERLAY);
        m.rightSleeve.render(ps, e.getMultiBufferSource().getBuffer(RenderType.entityTranslucent(skin)),
            e.getPackedLight(), OverlayTexture.NO_OVERLAY);

        ps.pushPose();
        m.rightArm.translateAndRotate(ps);
        HandChains.render(ps, e.getMultiBufferSource(), e.getPackedLight(), "slim".equals(p.getModelName()), p);
        ps.popPose();

        e.setCanceled(true); // the arm has been drawn above
    }
}
