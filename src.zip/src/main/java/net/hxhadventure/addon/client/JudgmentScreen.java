package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.hxhadventure.addon.JudgmentChain;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketJudgmentApply;
import net.hxhadventure.entity.client.gui.HxhUi;

/**
 * The Judgment Chain's menu: the Stake of Retribution is in the target's heart, pick the commands they must follow
 * (up to {@link JudgmentChain#MAX_COMMANDS}). The target is then asked to accept; refusing or breaking one kills them.
 */
public class JudgmentScreen extends Screen {
    private static final int HALF_W = 172;
    private static final int ROW_H = 26;

    private final int victimId;
    private final String victimName;
    private final int max;
    private final Set<String> picked = new LinkedHashSet<>();
    private final List<HxhUi.HxhButton> rows = new ArrayList<>();
    private HxhUi.HxhButton bind;

    public JudgmentScreen(int victimId, String victimName, int max) {
        super(Component.literal("Judgment Chain"));
        this.victimId = victimId;
        this.victimName = victimName;
        this.max = Math.max(1, max);
    }

    private int panelH() {
        return 78 + JudgmentChain.COMMANDS.size() * ROW_H + 40;
    }

    private int top() {
        return Math.max(12, this.height / 2 - panelH() / 2);
    }

    private String label(JudgmentChain.Command c) {
        return (picked.contains(c.id()) ? "[x] " : "[  ] ") + c.text();
    }

    @Override
    protected void init() {
        rows.clear();
        int cx = this.width / 2;
        int y = top() + 62;
        for (JudgmentChain.Command c : JudgmentChain.COMMANDS) {
            HxhUi.HxhButton b = HxhUi.button(cx - 160, y, 320, ROW_H - 3, label(c), btn -> {
                if (!picked.remove(c.id()) && picked.size() < max) picked.add(c.id());
                refresh();
            }, false);
            rows.add(b);
            addRenderableWidget(b);
            y += ROW_H;
        }
        int by = top() + panelH() - 32;
        bind = HxhUi.button(cx - 160, by, 156, 20, "Bind them", b -> {
            AddonNetwork.sendToServer(new PacketJudgmentApply(victimId, new ArrayList<>(picked)));
            onClose();
        }, true);
        addRenderableWidget(bind);
        addRenderableWidget(HxhUi.button(cx + 4, by, 156, 20, "Let them go", b -> onClose(), false));
        refresh();
    }

    private void refresh() {
        for (int i = 0; i < rows.size(); i++) rows.get(i).setMessage(Component.literal(label(JudgmentChain.COMMANDS.get(i))));
        bind.active = !picked.isEmpty();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        HxhUi.backdrop(g, this.width, this.height);
        int cx = this.width / 2;
        int top = top();
        HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, panelH() + 8);
        HxhUi.title(g, this.font, "STAKE OF RETRIBUTION", cx, top);
        HxhUi.subtitle(g, this.font, victimName, cx, top + 14);
        HxhUi.wrap(g, this.font, "The Stake is in their heart. Choose up to " + max + " commands (" + picked.size() + " chosen). "
            + "If they refuse, or ever break one, the Stake kills them.", cx - 156, top + 30, 312, HxhUi.TEXT_DIM);
        super.render(g, mouseX, mouseY, partial);
    }
}
