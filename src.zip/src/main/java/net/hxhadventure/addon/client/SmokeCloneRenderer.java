package net.hxhadventure.addon.client;

import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.hxhadventure.addon.SmokeCloneEntity;

/** A Deep Purple clone, drawn as a player wearing the user's own skin (and arm model), like the Laplace double. */
public class SmokeCloneRenderer extends NpcPlayerRenderer<SmokeCloneEntity> {
    public SmokeCloneRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, SmokeCloneRenderer::skin, SmokeCloneRenderer::slim);
    }

    private static PlayerInfo info(SmokeCloneEntity e) {
        UUID id = e.ownerId();
        var conn = Minecraft.getInstance().getConnection();
        return id == null || conn == null ? null : conn.getPlayerInfo(id);
    }

    private static ResourceLocation skin(SmokeCloneEntity e) {
        PlayerInfo pi = info(e);
        UUID id = e.ownerId();
        return pi != null ? pi.getSkinLocation() : DefaultPlayerSkin.getDefaultSkin(id == null ? new UUID(0L, 0L) : id);
    }

    private static boolean slim(SmokeCloneEntity e) {
        PlayerInfo pi = info(e);
        UUID id = e.ownerId();
        String model = pi != null ? pi.getModelName() : DefaultPlayerSkin.getSkinModelName(id == null ? new UUID(0L, 0L) : id);
        return "slim".equals(model);
    }
}
