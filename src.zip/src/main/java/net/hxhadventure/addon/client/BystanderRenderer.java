package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.hxhadventure.addon.BystanderEntity;

/** A Bystander with the player model and one of the five skins (bystander_2 to bystander_4 have slim arms). */
public class BystanderRenderer extends NpcPlayerRenderer<BystanderEntity> {
    public BystanderRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, b -> tex("bystander_" + b.skin()), b -> b.skin() >= 2);
    }
}
