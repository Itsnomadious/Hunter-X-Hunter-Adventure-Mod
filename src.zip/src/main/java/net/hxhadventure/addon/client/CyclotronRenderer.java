package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.RipperCyclotron;
import org.joml.Matrix4f;

/**
 * Draws Ripper Cyclotron like the reference art: a yellow, jagged ball of aura on the fist, with white swirls trailing round the arm as it
 * turns. The ball's width follows {@link RipperCyclotron#auraDiameter} (never wider than the tuning's maximum, 3 blocks, spikes included). On
 * the punch, a burst where it lands. Built from glowing translucent shells and spikes, so there is no model or texture.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class CyclotronRenderer {
    private CyclotronRenderer() {}

    private static final int LAT = 8, LON = 14, SPIKES = 26, TRAIL = 14;
    private static final double CULL_DISTANCE = 96.0;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || CyclotronFx.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        double time = level.getGameTime() + pt;
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        Matrix4f m = ps.last().pose();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.lightning();
        VertexConsumer vc = buf.getBuffer(type);

        for (CyclotronFx.Rec r : CyclotronFx.all().values()) {
            if (r.mode == CyclotronFx.SPIN) {
                Entity owner = level.getEntity(r.owner);
                if (!(owner instanceof LivingEntity le)) continue;
                if (cam.distanceToSqr(owner.getX(), owner.getY(), owner.getZ()) > CULL_DISTANCE * CULL_DISTANCE) continue;
                double rot = CyclotronFx.rotations(r, time);
                double R = RipperCyclotron.auraDiameter(rot) * 0.5;
                if (le == mc.player && mc.options.getCameraType().isFirstPerson()) {
                    // first person: the big aura would swallow the camera, so only a small glow is drawn out in front of the hand
                    handGlow(m, vc, cam, e.getCamera(), R, time, r.owner);
                    continue;
                }
                double ang = CyclotronFx.angle(rot);
                Vec3 fist = CyclotronFx.fistPos(le, pt, ang);
                swirls(m, vc, cam, le, pt, ang, R, rot);
                ball(m, vc, cam, fist, R, time, r.owner);
            } else if (r.mode == CyclotronFx.PUNCH) {
                double age = (time - r.punchAt) / CyclotronFx.PUNCH_TICKS;
                if (age < 0 || age > 1) continue;
                burst(m, vc, cam, new Vec3(r.px, r.py, r.pz), age, r.diameter * 0.5, r.owner);
            }
        }
        buf.endBatch(type);
    }

    /** First person: a small ball low and to the right in front of the camera, which grows a little with the aura but never reaches the view. */
    private static void handGlow(Matrix4f m, VertexConsumer vc, Vec3 cam, net.minecraft.client.Camera camera, double R, double time, int seed) {
        org.joml.Vector3f look = camera.getLookVector(), left = camera.getLeftVector(), up = camera.getUpVector();
        Vec3 c = new Vec3(look.x() * 1.0 - left.x() * 0.5 - up.x() * 0.45,
            look.y() * 1.0 - left.y() * 0.5 - up.y() * 0.45, look.z() * 1.0 - left.z() * 0.5 - up.z() * 0.45);
        double r = 0.1 + 0.1 * Mth.clamp(R / 1.5, 0, 1);
        sphere(m, vc, c, r, 255, 190, 25, 90);
        sphere(m, vc, c, r * 0.6, 255, 235, 120, 150);
        sphere(m, vc, c, r * 0.3, 255, 255, 220, 220);
    }

    /** The ball: orange outside, gold in the middle, a near-white core, and a flame-edged rim. Nothing goes past radius {@code R}. */
    private static void ball(Matrix4f m, VertexConsumer vc, Vec3 cam, Vec3 fist, double R, double time, int seed) {
        Vec3 c = fist.subtract(cam);
        double pulse = 1.0 - 0.05 * (0.5 + 0.5 * Math.sin(time * 1.1)); // only ever shrinks a little: the 3 block limit holds
        double grow = Mth.clamp(R / 1.5, 0, 1);
        sphere(m, vc, c, R * pulse, 255, 190, 25, (int) (70 + 40 * grow));
        sphere(m, vc, c, R * 0.78 * pulse, 255, 225, 70, (int) (110 + 50 * grow));
        sphere(m, vc, c, R * 0.42, 255, 255, 215, (int) (170 + 70 * grow));
        for (int i = 0; i < SPIKES; i++) {
            Vec3 d = fib(i, SPIKES);
            double flick = 0.5 + 0.5 * Math.sin(time * 0.9 + i * 1.7 + seed);
            spike(m, vc, c, d, R * 0.80 * pulse, R * (0.08 + 0.12 * flick), 0.28 * R + 0.03, 255, 205, 40, (int) (190 * (0.6 + 0.4 * flick)));
        }
    }

    /** White swirls trailing behind the fist round the arm's circle, like the streaks in the art. They fade the further back they are. */
    private static void swirls(Matrix4f m, VertexConsumer vc, Vec3 cam, LivingEntity le, float pt, double ang, double R, double rot) {
        double dir = Math.signum(ang == 0 ? 1 : ang);
        Vec3 prev = CyclotronFx.fistPos(le, pt, ang).subtract(cam);
        for (int k = 1; k <= TRAIL; k++) {
            double back = ang - dir * k * 0.28;                 // further back along the circle
            Vec3 p = CyclotronFx.fistPos(le, pt, back).subtract(cam);
            double fade = 1.0 - k / (double) (TRAIL + 1), fadePrev = 1.0 - (k - 1) / (double) (TRAIL + 1);
            double width = (0.05 + 0.10 * Math.min(1.0, R / 1.5)) * (0.4 + 0.6 * fade);
            double on = Math.min(1.0, rot * 2); // no trail at the very first moment of the spin
            ribbon(m, vc, prev, p, width, 255, 255, 255, (int) (220 * fadePrev * on), (int) (220 * fade * on));
            prev = p;
        }
    }

    private static void burst(Matrix4f m, VertexConsumer vc, Vec3 cam, Vec3 at, double age, double R, int seed) {
        double a = Mth.clamp(age, 0, 1);
        double out = 1 - Math.pow(1 - a, 3);
        Vec3 c = at.subtract(cam);
        double size = 0.4 + (R + 0.6) * out;
        sphere(m, vc, c, size, 255, 190, 25, (int) (150 * (1 - a)));
        sphere(m, vc, c, size * 0.7, 255, 230, 80, (int) (200 * (1 - a)));
        sphere(m, vc, c, size * 0.4, 255, 255, 230, (int) (255 * (1 - a)));
        for (int i = 0; i < 22; i++) {
            Vec3 d = fib(i, 22);
            double len = (0.4 + 0.6 * ((i * 37 + seed) % 7) / 7.0) * (0.5 + R) * out;
            spike(m, vc, c, d, size * 0.9, len, 0.12 + 0.2 * (1 - a), 255, 215, 60, (int) (220 * (1 - a)));
        }
    }

    // ---------------- drawing helpers (the same shapes JajankenRenderer uses) ----------------
    private static Vec3 fib(int i, int n) {
        double y = 1 - 2.0 * (i + 0.5) / n;
        double r = Math.sqrt(Math.max(0, 1 - y * y));
        double th = i * 2.399963;
        return new Vec3(Math.cos(th) * r, y, Math.sin(th) * r);
    }

    private static void sphere(Matrix4f m, VertexConsumer vc, Vec3 c, double r, int cr, int cg, int cb, int ca) {
        if (ca <= 0 || r < 0.01) return;
        double dist = c.length();
        if (dist < r + 1.0) ca = (int) (ca * Mth.clamp((dist - r) / 1.0, 0.0, 1.0)); // the camera is in or at the shell: fade it out
        if (ca <= 0) return;
        ca = Math.min(255, ca);
        for (int i = 0; i < LAT; i++) {
            double t0 = Math.PI * i / LAT, t1 = Math.PI * (i + 1) / LAT;
            for (int j = 0; j < LON; j++) {
                double p0 = 2 * Math.PI * j / LON, p1 = 2 * Math.PI * (j + 1) / LON;
                vtx(m, vc, pt(c, r, t0, p0), cr, cg, cb, ca);
                vtx(m, vc, pt(c, r, t1, p0), cr, cg, cb, ca);
                vtx(m, vc, pt(c, r, t1, p1), cr, cg, cb, ca);
                vtx(m, vc, pt(c, r, t0, p1), cr, cg, cb, ca);
            }
        }
    }

    private static Vec3 pt(Vec3 c, double r, double theta, double phi) {
        return c.add(r * Math.sin(theta) * Math.cos(phi), r * Math.cos(theta), r * Math.sin(theta) * Math.sin(phi));
    }

    /** A flame-tongue spike standing on a sphere of radius {@code base} around c, pointing along d. */
    private static void spike(Matrix4f m, VertexConsumer vc, Vec3 c, Vec3 d, double base, double len, double width, int cr, int cg, int cb, int ca) {
        if (ca <= 0 || c.add(d.scale(base)).length() < 0.6 || c.length() < base + len + 0.6) return;
        Vec3 b = c.add(d.scale(base));
        Vec3 tip = c.add(d.scale(base + len));
        Vec3 side = d.cross(b).lengthSqr() < 1e-8 ? new Vec3(1, 0, 0) : d.cross(b).normalize();
        side = side.scale(width * 0.5);
        vtx(m, vc, b.add(side), cr, cg, cb, ca);
        vtx(m, vc, b.subtract(side), cr, cg, cb, ca);
        vtx(m, vc, tip, cr, cg, cb, 0);
        vtx(m, vc, tip, cr, cg, cb, 0);
    }

    /** A camera-facing ribbon from a to b (both already relative to the camera), with its own alpha at each end. */
    private static void ribbon(Matrix4f m, VertexConsumer vc, Vec3 a, Vec3 b, double width, int cr, int cg, int cb, int ca, int cb2) {
        if (ca <= 0 && cb2 <= 0) return;
        Vec3 d = b.subtract(a);
        Vec3 side = d.cross(a.add(b).scale(0.5));
        if (side.lengthSqr() < 1e-10) return;
        side = side.normalize().scale(width * 0.5);
        vtx(m, vc, a.add(side), cr, cg, cb, ca);
        vtx(m, vc, a.subtract(side), cr, cg, cb, ca);
        vtx(m, vc, b.subtract(side), cr, cg, cb, cb2);
        vtx(m, vc, b.add(side), cr, cg, cb, cb2);
    }

    private static void vtx(Matrix4f m, VertexConsumer vc, Vec3 p, int r, int g, int b, int a) {
        vc.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, a).endVertex();
    }
}
