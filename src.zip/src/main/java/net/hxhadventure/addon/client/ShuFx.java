package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.addon.ClientAddonState;
import org.joml.Vector3f;

/** Shu visual: while Shu is on, the item in the main hand is wrapped in a shimmer of golden aura running along its length. */
public final class ShuFx {
    private ShuFx() {}

    private static final DustParticleOptions AURA = new DustParticleOptions(new Vector3f(1.0f, 0.67f, 0.1f), 0.7f); // matches the 0xFFAA00 of the HUD line

    public static void tick(Minecraft mc) {
        Player p = mc.player;
        if (p == null || mc.level == null || mc.isPaused() || !ClientAddonState.shu || p.getMainHandItem().isEmpty()) return;
        float yaw = p.getYRot() * Mth.DEG_TO_RAD;
        double side = p.getMainArm() == HumanoidArm.RIGHT ? 1 : -1;
        Vec3 fwd = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        Vec3 right = new Vec3(-Mth.cos(yaw), 0, -Mth.sin(yaw)).scale(side);
        Vec3 hand = p.getEyePosition().add(0, -0.35, 0).add(right.scale(0.4)).add(fwd.scale(0.45));
        Vec3 look = p.getLookAngle();
        var rnd = mc.level.random;
        for (int i = 0; i < 3; i++) {
            double t = rnd.nextDouble() * 0.9; // along the item
            Vec3 at = hand.add(look.scale(t)).add((rnd.nextDouble() - 0.5) * 0.14, (rnd.nextDouble() - 0.5) * 0.14, (rnd.nextDouble() - 0.5) * 0.14);
            mc.level.addParticle(AURA, at.x, at.y, at.z, 0, 0.01, 0);
        }
        if (rnd.nextInt(6) == 0) {
            Vec3 at = hand.add(look.scale(rnd.nextDouble() * 0.9));
            mc.level.addParticle(ParticleTypes.END_ROD, at.x, at.y, at.z, 0, 0.02, 0);
        }
    }
}
