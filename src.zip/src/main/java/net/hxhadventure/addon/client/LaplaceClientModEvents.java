package net.hxhadventure.addon.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.HxHEntities;

/** Laplace Devil renderers and model layer (mod event bus, client only). Top level on purpose, like HinaClientEvents. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class LaplaceClientModEvents {
    private LaplaceClientModEvents() {}

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(LaplaceDevilModel.LAYER, LaplaceDevilModel::createLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(HxHEntities.LAPLACE_DEVIL.get(), LaplaceDevilRenderer::new);
        e.registerEntityRenderer(HxHEntities.LAPLACE_DOUBLE.get(), LaplaceDoubleRenderer::new);
    }
}
