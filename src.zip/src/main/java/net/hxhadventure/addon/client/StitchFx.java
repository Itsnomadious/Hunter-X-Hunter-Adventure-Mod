package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.network.PacketStitchFx;

/**
 * Client-side record of everything Nen Stitches has in view (fed by PacketStitchFx): the trap threads, the slashes, the people tied up
 * and the Wound Sewing hands. {@link StitchRenderer} draws it; the hands' pose is done here ({@link #applyArm}).
 */
public final class StitchFx {
    private StitchFx() {}

    public static final class Trap {
        public final int id, owner;
        public final Vec3 a, b;

        Trap(int id, int owner, Vec3 a, Vec3 b) {
            this.id = id;
            this.owner = owner;
            this.a = a;
            this.b = b;
        }
    }

    public static final class Slash {
        public final int owner, kind;
        public final boolean left;
        public final double t0, fx, fz, length, width;
        public final Vec3 origin;

        Slash(int owner, int kind, boolean left, double t0, Vec3 origin, double fx, double fz, double length, double width) {
            this.owner = owner;
            this.kind = kind;
            this.left = left;
            this.t0 = t0;
            this.origin = origin;
            this.fx = fx;
            this.fz = fz;
            this.length = length;
            this.width = width;
        }

        /** How long the slash is on screen, in ticks. */
        public double life() { return kind == 1 ? 11 : kind == 2 ? 6 : 8; }
    }

    public static final class Bind {
        public final int owner, target;
        public final double t0;
        /** The last time the server said the bind still holds (it says so every two seconds). */
        public double seen;

        Bind(int owner, int target, double t0) {
            this.owner = owner;
            this.target = target;
            this.t0 = t0;
            this.seen = t0;
        }
    }

    public static final class Sew {
        public final int owner;
        public int target;
        public final double t0;
        public double seen;

        Sew(int owner, int target, double t0) {
            this.owner = owner;
            this.target = target;
            this.t0 = t0;
            this.seen = t0;
        }
    }

    public static final class Snap {
        public final Vec3 at;
        public final double t0;

        Snap(Vec3 at, double t0) {
            this.at = at;
            this.t0 = t0;
        }
    }

    public static final double SNAP_TICKS = 8;

    private static final Map<Integer, Trap> TRAPS = new HashMap<>();
    private static final List<Slash> SLASHES = new ArrayList<>();
    private static final Map<Integer, Bind> BINDS = new HashMap<>(); // keyed by the tied-up creature
    private static final Map<Integer, Sew> SEWS = new HashMap<>();   // keyed by the sewing player
    private static final List<Snap> SNAPS = new ArrayList<>();
    private static Vec3 pending;
    private static ClientLevel levelOf;

    public static Map<Integer, Trap> traps() { return TRAPS; }

    public static List<Slash> slashes() { return SLASHES; }

    public static Map<Integer, Bind> binds() { return BINDS; }

    public static Map<Integer, Sew> sews() { return SEWS; }

    public static List<Snap> snaps() { return SNAPS; }

    public static Vec3 pending() { return pending; }

    public static boolean isEmpty() {
        return TRAPS.isEmpty() && SLASHES.isEmpty() && BINDS.isEmpty() && SEWS.isEmpty() && SNAPS.isEmpty() && pending == null;
    }

    public static void clear() {
        TRAPS.clear();
        SLASHES.clear();
        BINDS.clear();
        SEWS.clear();
        SNAPS.clear();
        pending = null;
        levelOf = null;
    }

    /** From PacketStitchFx. */
    public static void receive(int mode, int i1, int i2, int i3, double[] d, List<PacketStitchFx.TrapData> traps) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        if (level != levelOf) { // a new world or dimension: nothing from the old one carries over
            clear();
            levelOf = level;
        }
        double now = level.getGameTime();
        switch (mode) {
            case PacketStitchFx.TRAP_SYNC -> {
                TRAPS.clear();
                for (PacketStitchFx.TrapData t : traps) TRAPS.put(t.id(), new Trap(t.id(), t.owner(), t.a(), t.b()));
            }
            case PacketStitchFx.TRAP_ADD -> {
                for (PacketStitchFx.TrapData t : traps) TRAPS.put(t.id(), new Trap(t.id(), t.owner(), t.a(), t.b()));
            }
            case PacketStitchFx.TRAP_BREAK -> {
                Trap t = TRAPS.remove(i1);
                if (d.length >= 3 && t != null) SNAPS.add(new Snap(new Vec3(d[0], d[1], d[2]), now));
            }
            case PacketStitchFx.PENDING -> pending = new Vec3(d[0], d[1], d[2]);
            case PacketStitchFx.PENDING_CLEAR -> pending = null;
            case PacketStitchFx.SLASH -> SLASHES.add(new Slash(i1, i2, i3 == 1, now, new Vec3(d[0], d[1], d[2]), d[3], d[4], d[5], d[6]));
            case PacketStitchFx.BIND -> {
                Bind old = BINDS.get(i2);
                if (old != null && old.owner == i1) old.seen = now; // a refresh: the threads do not grow in again
                else BINDS.put(i2, new Bind(i1, i2, now));
            }
            case PacketStitchFx.BIND_END -> BINDS.remove(i2);
            case PacketStitchFx.SEW -> {
                Sew s = SEWS.get(i1);
                if (s == null) SEWS.put(i1, new Sew(i1, i2, now));
                else {
                    s.target = i2;
                    s.seen = now;
                }
            }
            case PacketStitchFx.SEW_END -> SEWS.remove(i1);
            default -> { }
        }
    }

    /**
     * Wound Sewing's pose, done on the model parts (called from PlayerModelMixin after the game has posed the player): both hands are held up in
     * front of the chest with the fingers flickering, like the anime. Not in first person, where the arms are not the model's.
     */
    public static void applyArm(PlayerModel<?> model, LivingEntity entity) {
        if (SEWS.isEmpty() || !(entity instanceof AbstractClientPlayer p)) return;
        Sew r = SEWS.get(p.getId());
        if (r == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || (p == mc.player && mc.options.getCameraType().isFirstPerson())) return;
        double t = mc.level.getGameTime() + mc.getFrameTime() - r.t0;
        float in = (float) Mth.clamp(t / 3.0, 0, 1); // settles into the pose over three ticks
        float a = (float) Math.sin(t * 2.3) * 0.10f;
        float b = (float) Math.sin(t * 2.9 + 1.3) * 0.10f;
        float c = (float) Math.sin(t * 3.7 + 2.1) * 0.06f;
        model.rightArm.xRot = Mth.lerp(in, model.rightArm.xRot, -1.15f + a);
        model.rightArm.yRot = Mth.lerp(in, model.rightArm.yRot, 0.55f + b * 0.6f);
        model.rightArm.zRot = Mth.lerp(in, model.rightArm.zRot, c);
        model.leftArm.xRot = Mth.lerp(in, model.leftArm.xRot, -1.2f + b);
        model.leftArm.yRot = Mth.lerp(in, model.leftArm.yRot, -0.55f - a * 0.6f);
        model.leftArm.zRot = Mth.lerp(in, model.leftArm.zRot, -c);
        model.rightSleeve.copyFrom(model.rightArm); // the mixin runs after the game copied each part onto its overlay layer
        model.leftSleeve.copyFrom(model.leftArm);
    }

    /** Self-registering client hooks, so no existing client event class needs editing. */
    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class StitchHooks {
        private StitchHooks() {}

        /** Drops what has finished: old slashes and snaps, sewing whose end signal never came, a bind whose creature is gone. */
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END || isEmpty()) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.level != levelOf) {
                clear();
                return;
            }
            double now = mc.level.getGameTime();
            SLASHES.removeIf(s -> now - s.t0 > s.life() + 2);
            SNAPS.removeIf(s -> now - s.t0 > SNAP_TICKS + 2);
            SEWS.values().removeIf(s -> now - s.seen > 25 || mc.level.getEntity(s.owner) == null);
            Iterator<Bind> it = BINDS.values().iterator();
            while (it.hasNext()) {
                Bind b = it.next();
                if (now - b.seen > 70 || mc.level.getEntity(b.target) == null) it.remove(); // the server re-sends every two seconds while it holds
            }
        }

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
            clear();
        }
    }
}
