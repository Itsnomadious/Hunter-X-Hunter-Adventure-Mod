package net.hxhadventure.addon.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import net.hxhadventure.addon.network.PacketZHold;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.ClientAddonState;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketAddonAction;
import net.hxhadventure.addon.network.PacketAddonAction.Action;

@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class AddonClientEvents {
    private AddonClientEvents() {}

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            EnGlowHandler.clearAll();
            return;
        }
        while (AddonKeys.ZETSU.consumeClick()) send(Action.TOGGLE_ZETSU);
        while (AddonKeys.REN.consumeClick()) send(Action.TOGGLE_REN);
        while (AddonKeys.EN.consumeClick()) send(Action.TOGGLE_EN);
        while (AddonKeys.IN.consumeClick()) send(Action.TOGGLE_IN);
        while (AddonKeys.GYO.consumeClick()) send(Action.TOGGLE_GYO);
        while (AddonKeys.SHU.consumeClick()) send(Action.TOGGLE_SHU);
        while (AddonKeys.KEN.consumeClick()) send(Action.TOGGLE_KEN);
        while (AddonKeys.KO.consumeClick()) send(Action.TOGGLE_KO);
        while (AddonKeys.RESET_SCROLL.consumeClick()) net.hxhadventure.event.ClientAbilityHandler.resetSelection();
        while (AddonKeys.SKILLS.consumeClick()) mc.setScreen(OMenu.mastery());
        while (AddonKeys.HUD_EDIT.consumeClick()) mc.setScreen(new HudEditScreen());
        EnGlowHandler.tick(mc);
        GumFx.tick(mc);
        CardFx.tick(mc);

        // Z is HxHAdventure's "use ability" key. A tap uses the ability; Sun and Moon charges while it stays held.
        boolean down = mc.screen == null
            && InputConstants.isKeyDown(mc.getWindow().getWindow(), GLFW.GLFW_KEY_Z);
        if (down != zHeld) {
            zHeld = down;
            AddonNetwork.sendToServer(new PacketZHold(down));
        }
    }

    private static boolean zHeld;

    private static void send(Action a) {
        AddonNetwork.sendToServer(new PacketAddonAction(a));
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        EnGlowHandler.clearAll();
        ChainFx.clear();
        ChainMarks.clear();
        BlytheFx.clear();
        TerpsichoraFx.clear();
        OrbFx.clear();
        BlastFx.clear();
        PrayFx.clear();
        PillarFx.clear();
        DiveArrowFx.clear();
        GumFx.clear();
        CardFx.clear();
        InFx.clear();
        PaperFx.clear();
        SmokeFx.clear();
        PainFx.clear();
        BlinkyFx.clear();
        CrazySlotsFx.clear();
        BlinkyRenderer.clear();
        GyoInfoHud.clear();
        BookRenderer.clear();
        DisguiseHandler.clear();
        EmperorEyes.clear();
        ChainHand.clear();
        AuraForms.clear();
        ClientQuests.clear();
        ClientAddonState.reset();
        ClientCooldowns.clear();
        zHeld = false;
    }
}
