package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.hxhadventure.addon.ExamNpcEntity;

/** Draws a Hunter Exam NPC with its own player skin (textures/entity/&lt;skin&gt;.png, wide arms). */
public class ExamNpcRenderer<T extends ExamNpcEntity> extends NpcPlayerRenderer<T> {
    public ExamNpcRenderer(EntityRendererProvider.Context ctx, String skin) {
        super(ctx, m -> tex(skin), m -> false);
    }
}
