package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.Guanyin;
import net.hxhadventure.addon.network.PacketGuanyinFx;

/**
 * Client-side list of the Guanyin's moves being drawn (fed by PacketGuanyinFx). Whether a player has the statue out lives in
 * {@link Guanyin#clientHas}; this keeps the moves in progress: the golden hand flash, the palm strikes, the four hands.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class GuanyinFx {
    private GuanyinFx() {}

    public static final class Effect {
        public final int owner, type, extra;
        public final double x, y, z, t0;
        public final float dx, dy, dz;

        Effect(int owner, int type, double x, double y, double z, float dx, float dy, float dz, int extra, double t0) {
            this.owner = owner;
            this.type = type;
            this.x = x;
            this.y = y;
            this.z = z;
            this.dx = dx;
            this.dy = dy;
            this.dz = dz;
            this.extra = extra;
            this.t0 = t0;
        }

        /** A palm's speed (1 = the base speed), sent by the server in extra's bits 2+ as a percentage. */
        public float speed() {
            int pct = (extra >> 2) & 0x3FF;
            return type == PacketGuanyinFx.PALM && pct > 0 ? pct / 100f : 1f;
        }

        /** Ticks the effect stays on screen. */
        public int life() {
            return switch (type) {
                case PacketGuanyinFx.PALM -> (int) Math.ceil(14 / speed());
                case PacketGuanyinFx.FLASH -> Math.max(3, extra) + 2;
                case PacketGuanyinFx.FIRST -> extra + 16;
                case PacketGuanyinFx.THIRD -> extra + 8;
                case PacketGuanyinFx.NINETY -> extra + 6;
                case PacketGuanyinFx.ZERO -> extra + 18;
                default -> 0;
            };
        }
    }

    public static final List<Effect> ACTIVE = new ArrayList<>();

    public static void receive(int owner, int type, double x, double y, double z, float dx, float dy, float dz, int extra) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        if (type == PacketGuanyinFx.AWAKE || type == PacketGuanyinFx.ASLEEP) {
            Guanyin.setClientEnlightened(type == PacketGuanyinFx.AWAKE);
            return;
        }
        if (type == PacketGuanyinFx.OFF || type == PacketGuanyinFx.ON) {
            Guanyin.setClient(owner, type == PacketGuanyinFx.ON);
            if (type == PacketGuanyinFx.OFF) ACTIVE.removeIf(e -> e.owner == owner);
            return;
        }
        if (type != PacketGuanyinFx.PALM) ACTIVE.removeIf(e -> e.owner == owner && e.type == type);
        if (type == PacketGuanyinFx.PALM) PrayFx.push(owner, (extra & 2) != 0); // the user pushes with one hand as the statue strikes
        ACTIVE.add(new Effect(owner, type, x, y, z, dx, dy, dz, extra, level.getGameTime()));
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        Guanyin.clearClient();
        ACTIVE.clear();
    }
}
