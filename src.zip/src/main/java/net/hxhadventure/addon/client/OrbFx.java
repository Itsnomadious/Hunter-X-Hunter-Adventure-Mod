package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.LivingEntity;
import net.hxhadventure.addon.network.PacketOrbFx;

/**
 * Client-side state for Explosive Orbs (fed by PacketOrbFx): who is holding orbs and how far the charge has got, orbs in flight,
 * and blast flashes. Also poses the holder's arms straight out to the sides.
 */
public final class OrbFx {
    private OrbFx() {}

    public static final class Held {
        public double start, duration;
    }

    public static final class Flying {
        public double x, y, z, t0;
        public float vx, vy, vz, radius;
        public int life;
    }

    public static final class Boom {
        public double x, y, z, t0;
        public float radius;
    }

    public static final Map<Integer, Held> HELD = new HashMap<>();
    public static final Map<Integer, Flying> FLYING = new HashMap<>();
    public static final List<Boom> BOOMS = new ArrayList<>();

    public static boolean isEmpty() {
        return HELD.isEmpty() && FLYING.isEmpty() && BOOMS.isEmpty();
    }

    /** 0..1 charge of this entity's hand orbs, or -1 if it is not holding any. */
    public static float charge(int owner, double time) {
        Held h = HELD.get(owner);
        if (h == null) return -1f;
        return (float) Math.max(0, Math.min(1, (time - h.start) / h.duration));
    }

    public static void handle(byte kind, int id, double x, double y, double z, float vx, float vy, float vz, float size, int ticks) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        double now = level.getGameTime();
        switch (kind) {
            case PacketOrbFx.CHARGE -> {
                Held h = new Held();
                h.duration = Math.max(1, ticks);
                h.start = now - size * h.duration; // size = how much was already built
                HELD.put(id, h);
            }
            case PacketOrbFx.END -> HELD.remove(id);
            case PacketOrbFx.LAUNCH -> {
                Flying f = new Flying();
                f.x = x; f.y = y; f.z = z;
                f.vx = vx; f.vy = vy; f.vz = vz;
                f.radius = size;
                f.life = ticks;
                f.t0 = now;
                FLYING.put(id, f);
            }
            case PacketOrbFx.BOOM -> {
                FLYING.remove(id);
                Boom b = new Boom();
                b.x = x; b.y = y; b.z = z;
                b.radius = size;
                b.t0 = now;
                BOOMS.add(b);
                for (int i = 0; i < 4; i++) {
                    level.addParticle(ParticleTypes.EXPLOSION_EMITTER,
                        x + (level.random.nextDouble() - 0.5) * size * 0.8, y + (level.random.nextDouble() - 0.3) * size * 0.5,
                        z + (level.random.nextDouble() - 0.5) * size * 0.8, 1.0, 0, 0);
                }
            }
            case PacketOrbFx.REMOVE -> FLYING.remove(id);
            default -> { }
        }
    }

    /** Arms out to the sides while holding orbs. Called from PlayerModelMixin after the game has posed the player. */
    public static void applyArms(PlayerModel<?> model, LivingEntity entity) {
        if (HELD.isEmpty() || !(entity instanceof AbstractClientPlayer p) || !HELD.containsKey(p.getId())) return;
        Minecraft mc = Minecraft.getInstance();
        if (p == mc.player && mc.options.getCameraType().isFirstPerson()) return; // first person draws its own hand
        model.rightArm.xRot = 0f;
        model.rightArm.yRot = 0f;
        model.rightArm.zRot = (float) (Math.PI / 2);
        model.leftArm.xRot = 0f;
        model.leftArm.yRot = 0f;
        model.leftArm.zRot = (float) (-Math.PI / 2);
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);
    }

    public static void clear() {
        HELD.clear();
        FLYING.clear();
        BOOMS.clear();
    }
}
