package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * A.P.R.'s body, built in code at 2x detail (1px = 1/16 block of a 2 block tall figure; the renderer scales it down to the real size).
 * Feet at y=24, top of the antenna at y=-8; the front is -Z. A big white egg of a head with a counter on the forehead (the number
 * itself is drawn by the renderer), black panda ears, a teal onesie, a yellow neckerchief with a knot, little white wings and brown shoes.
 * Texture: textures/entity/apr.png, drawn by tools/make_hakoware_textures.py (offsets in {@link HakowareUv}).
 */
public final class AprModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("hxhadventure", "apr"), "main");
    public static final float MODEL_HEIGHT = 2.0f;                 // blocks, antenna to sole
    /** The counter glass on the forehead, in model px: x from -4 to 4, y from -4 to 0, on the face at z = -9. */
    public static final float SCREEN_X = 0f, SCREEN_Y = -2f, SCREEN_W = 8f, SCREEN_H = 4f, SCREEN_Z = -9.06f;

    private final ModelPart root, head, antenna, armL, armR, wingL, wingR;

    public AprModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.antenna = root.getChild("antenna");
        this.armL = root.getChild("arm_l");
        this.armR = root.getChild("arm_r");
        this.wingL = root.getChild("wing_l");
        this.wingR = root.getChild("wing_r");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(HakowareUv.APR_BODY_U, HakowareUv.APR_BODY_V)
            .addBox(-8f, 10f, -6f, 16f, 11f, 12f), PartPose.ZERO);
        root.addOrReplaceChild("scarf", CubeListBuilder.create().texOffs(HakowareUv.APR_SCARF_U, HakowareUv.APR_SCARF_V)
            .addBox(-9f, 9f, -7f, 18f, 2f, 14f), PartPose.ZERO);
        PartDefinition knot = root.addOrReplaceChild("knot", CubeListBuilder.create().texOffs(HakowareUv.APR_KNOT_U, HakowareUv.APR_KNOT_V)
            .addBox(-2f, -2f, -1f, 4f, 4f, 2f), PartPose.offset(3f, 11f, -7.5f));
        knot.addOrReplaceChild("tail_a", CubeListBuilder.create().texOffs(HakowareUv.APR_TAIL_U, HakowareUv.APR_TAIL_V)
            .addBox(-1.5f, 0f, -0.5f, 3f, 5f, 1f), PartPose.offsetAndRotation(-1f, 1.5f, -0.4f, 0f, 0f, 0.45f));
        knot.addOrReplaceChild("tail_b", CubeListBuilder.create().texOffs(HakowareUv.APR_TAIL_U, HakowareUv.APR_TAIL_V)
            .addBox(-1.5f, 0f, -0.5f, 3f, 5f, 1f), PartPose.offsetAndRotation(1f, 1.5f, -0.4f, 0f, 0f, -0.45f));

        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(HakowareUv.APR_HEAD_U, HakowareUv.APR_HEAD_V)
            .addBox(-11f, -6f, -9f, 22f, 16f, 18f), PartPose.ZERO);
        root.addOrReplaceChild("antenna", CubeListBuilder.create().texOffs(HakowareUv.APR_ANTENNA_U, HakowareUv.APR_ANTENNA_V)
            .addBox(-1f, -3f, -1f, 2f, 3f, 2f), PartPose.offset(0f, -5f, 0f));
        root.addOrReplaceChild("ear_l", CubeListBuilder.create().texOffs(HakowareUv.APR_EAR_U, HakowareUv.APR_EAR_V)
            .addBox(-4f, -4f, -3f, 8f, 8f, 6f), PartPose.offsetAndRotation(8f, -3f, 0f, 0f, 0f, 0.35f));
        root.addOrReplaceChild("ear_r", CubeListBuilder.create().texOffs(HakowareUv.APR_EAR_U, HakowareUv.APR_EAR_V).mirror()
            .addBox(-4f, -4f, -3f, 8f, 8f, 6f), PartPose.offsetAndRotation(-8f, -3f, 0f, 0f, 0f, -0.35f));

        for (int side = 0; side < 2; side++) {
            boolean left = side == 0;
            float sx = left ? 1f : -1f;
            // arm: blue sleeve, white forearm, a flat hand with finger lines; raised up and out
            PartDefinition arm = root.addOrReplaceChild(left ? "arm_l" : "arm_r",
                CubeListBuilder.create().texOffs(HakowareUv.APR_SLEEVE_U, HakowareUv.APR_SLEEVE_V).addBox(-2.5f, -2f, -2.5f, 5f, 4f, 5f)
                    .texOffs(HakowareUv.APR_FOREARM_U, HakowareUv.APR_FOREARM_V).addBox(-2f, 2f, -2f, 4f, 7f, 4f),
                PartPose.offsetAndRotation(sx * 8.5f, 12f, 0f, 0f, 0f, sx * -2.2f));
            arm.addOrReplaceChild("hand", CubeListBuilder.create().texOffs(HakowareUv.APR_HAND_U, HakowareUv.APR_HAND_V)
                .addBox(-2.5f, 0f, -1.5f, 5f, 3f, 3f), PartPose.offset(0f, 9f, 0f));

            // wing: three feathers fanned behind the head
            PartDefinition wing = root.addOrReplaceChild(left ? "wing_l" : "wing_r", CubeListBuilder.create(), PartPose.offset(sx * 9f, 3f, 10f));
            float[] fan = {0.25f, 0.65f, 1.05f};
            for (int i = 0; i < fan.length; i++) {
                CubeListBuilder feather = CubeListBuilder.create().texOffs(HakowareUv.APR_FEATHER_U, HakowareUv.APR_FEATHER_V);
                feather.addBox(left ? 0f : -9f, -1f, -0.5f, 9f, 2f, 1f);
                wing.addOrReplaceChild("feather" + i, feather, PartPose.offsetAndRotation(0f, 0f, 0f, 0f, 0f, sx * -fan[i]));
            }

            root.addOrReplaceChild(left ? "foot_l" : "foot_r", CubeListBuilder.create().texOffs(HakowareUv.APR_FOOT_U, HakowareUv.APR_FOOT_V)
                .addBox(-3.5f, 0f, -6f, 7f, 3f, 8f), PartPose.offset(sx * 4.5f, 21f, 0f));
        }
        return LayerDefinition.create(mesh, 128, 128);
    }

    /** Draws the figure with its idle animation (arms waving, wings flapping, antenna and head swaying). */
    public void render(PoseStack ps, VertexConsumer vc, int light, int overlay, float time) {
        head.zRot = 0.04f * (float) Math.sin(time * 0.09);
        antenna.xRot = 0.25f * (float) Math.sin(time * 0.21);
        antenna.zRot = 0.15f * (float) Math.sin(time * 0.17 + 1.0);
        armL.zRot = -2.2f + 0.2f * (float) Math.sin(time * 0.26);
        armR.zRot = 2.2f - 0.2f * (float) Math.sin(time * 0.26 + 0.8);
        float flap = (float) Math.sin(time * 0.55);
        wingL.yRot = -0.15f - 0.4f * flap;
        wingR.yRot = 0.15f + 0.4f * flap;
        root.render(ps, vc, light, overlay);
    }
}
