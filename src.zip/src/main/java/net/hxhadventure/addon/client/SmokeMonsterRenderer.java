package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.hxhadventure.addon.SmokeMonsterEntity;

/** Draws a smoke monster slightly see-through (the texture carries the alpha). */
public class SmokeMonsterRenderer extends MobRenderer<SmokeMonsterEntity, SmokeMonsterModel<SmokeMonsterEntity>> {
    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/smoke_monster.png");

    public SmokeMonsterRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new SmokeMonsterModel<>(ctx.bakeLayer(SmokeMonsterModel.LAYER)), 0.45f);
    }

    @Override
    public ResourceLocation getTextureLocation(SmokeMonsterEntity e) {
        return TEX;
    }

    @Override
    protected RenderType getRenderType(SmokeMonsterEntity e, boolean visible, boolean invisibleToPlayer, boolean glowing) {
        return RenderType.entityTranslucent(TEX);
    }

    /** The model is 32 px = 2 blocks tall (a player is 1.8), so it is drawn at its own size. */
    @Override
    protected void scale(SmokeMonsterEntity e, PoseStack pose, float partialTick) {
        pose.scale(1.0f, 1.0f, 1.0f);
    }
}
