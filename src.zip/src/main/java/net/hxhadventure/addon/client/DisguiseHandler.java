package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderNameTagEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.BystanderEntity;

/**
 * Convert Hands: when an entity is marked as "displayed as" another, its own render is cancelled and a stand-in of the other entity is
 * drawn in its place (players take on skins, mobs take on models). The stand-in is a throwaway copy that is never added to the world, and it
 * is given the shown entity's live state every frame (position, rotation, walk cycle, sprint, sneak, swing, pose, hurt flash) so it moves
 * exactly like the entity it replaces. Before, the other entity itself was drawn with its own state, so the disguised player looked stiff.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class DisguiseHandler {
    private DisguiseHandler() {}

    private static final Map<Integer, Integer> MAP = new HashMap<>();
    private static final Map<Integer, Stand> STANDS = new HashMap<>(); // shown entity id -> its stand-in
    /** Black Voice: player id -> id of the creature whose hitbox and eye height the player has taken. */
    private static final Map<Integer, Integer> RESIZE = new HashMap<>();
    private static boolean rendering;
    private static LivingEntity renderingFor;

    private static final class Stand {
        final LivingEntity entity;
        final int asId;
        final ClientLevel level;
        int lastTick = Integer.MIN_VALUE;

        Stand(LivingEntity entity, int asId, ClientLevel level) {
            this.entity = entity;
            this.asId = asId;
            this.level = level;
        }
    }

    public static void set(int displayed, int as, boolean on) {
        set(displayed, as, on, false);
    }

    public static void set(int displayed, int as, boolean on, boolean resize) {
        STANDS.remove(displayed);
        if (on) MAP.put(displayed, as);
        else MAP.remove(displayed);
        boolean had = RESIZE.containsKey(displayed);
        if (on && resize) RESIZE.put(displayed, as);
        else RESIZE.remove(displayed);
        if (had || (on && resize)) { // the camera and hitbox follow at once
            Minecraft mc = Minecraft.getInstance();
            if (mc.level != null && mc.level.getEntity(displayed) instanceof net.minecraft.world.entity.player.Player p) p.refreshDimensions();
        }
    }

    public static void clear() {
        MAP.clear();
        STANDS.clear();
        RESIZE.clear();
    }

    private static final java.util.Set<Integer> INTANGIBLE = new java.util.HashSet<>();

    /**
     * Black Voice: the worn creature is intangible, but noPhysics is not synced, so on the client its copy still pushes the local player
     * (the "constantly being moved"). Every tick the copy is made intangible here too, and solid again once the body is given back.
     */
    @SubscribeEvent
    public static void tickIntangible(net.minecraftforge.event.TickEvent.ClientTickEvent e) {
        if (e.phase != net.minecraftforge.event.TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            INTANGIBLE.clear();
            return;
        }
        java.util.Iterator<Integer> it = INTANGIBLE.iterator();
        while (it.hasNext()) {
            int id = it.next();
            if (!RESIZE.containsValue(id)) {
                Entity en = mc.level.getEntity(id);
                if (en != null) en.noPhysics = false;
                it.remove();
            }
        }
        for (int id : RESIZE.values()) {
            Entity en = mc.level.getEntity(id);
            if (en == null) continue;
            en.noPhysics = true;
            INTANGIBLE.add(id);
        }
    }

    /** The creature this player has the hitbox of (Black Voice), or null. */
    public static LivingEntity resizeBody(net.minecraft.world.entity.player.Player p) {
        Integer as = RESIZE.get(p.getId());
        return as != null && p.level().getEntity(as) instanceof LivingEntity le ? le : null;
    }

    /** The player-shaped stand-in drawn instead of this entity, or null. */
    static AbstractClientPlayer standInFor(int entityId) {
        Stand st = STANDS.get(entityId);
        return st != null && st.entity instanceof AbstractClientPlayer p ? p : null;
    }

    private static LivingEntity build(ClientLevel level, LivingEntity as) {
        if (as instanceof AbstractClientPlayer ap) {
            return new NeedleDisguise.SkinDummy(level, ap.getGameProfile(), ap.getSkinTextureLocation(), ap.getModelName());
        }
        Entity e = as.getType().create(level);
        return e instanceof LivingEntity le ? le : null;
    }

    private static Stand standFor(int shownId, int asId, LivingEntity as, ClientLevel level) {
        Stand s = STANDS.get(shownId);
        if (s != null && s.asId == asId && s.level == level) return s;
        LivingEntity built;
        try {
            built = build(level, as);
        } catch (Throwable t) {
            built = null;
        }
        if (built == null) {
            STANDS.remove(shownId);
            return null;
        }
        s = new Stand(built, asId, level);
        STANDS.put(shownId, s);
        return s;
    }

    private static void copyState(Stand st, LivingEntity from, LivingEntity as) {
        LivingEntity to = st.entity;
        to.setPos(from.getX(), from.getY(), from.getZ());
        to.xo = from.xo;
        to.yo = from.yo;
        to.zo = from.zo;
        to.yBodyRot = from.yBodyRot;
        to.yBodyRotO = from.yBodyRotO;
        to.yHeadRot = from.yHeadRot;
        to.yHeadRotO = from.yHeadRotO;
        to.setXRot(from.getXRot());
        to.xRotO = from.xRotO;
        to.setYRot(from.getYRot());
        to.yRotO = from.yRotO;
        to.tickCount = from.tickCount;
        to.setPose(from.getPose());
        to.setShiftKeyDown(from.isShiftKeyDown());
        to.setSprinting(from.isSprinting());
        to.setOnGround(from.onGround());
        to.swinging = from.swinging;
        to.swingTime = from.swingTime;
        to.swingingArm = from.swingingArm;
        to.attackAnim = from.attackAnim;
        to.oAttackAnim = from.oAttackAnim;
        to.hurtTime = from.hurtTime;
        to.deathTime = from.deathTime;
        // the walk cycle advances once per game tick, like LivingEntity.calculateEntityAnimation
        if (from.tickCount != st.lastTick) {
            st.lastTick = from.tickCount;
            float moved = (float) Mth.length(from.getX() - from.xo, 0.0, from.getZ() - from.zo);
            to.walkAnimation.update(Math.min(moved * 4.0F, 1.0F), 0.4F);
        }
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack want = as.getItemBySlot(slot);
            if (!ItemStack.matches(to.getItemBySlot(slot), want)) to.setItemSlot(slot, want.copy());
        }
        if (as instanceof BystanderEntity b && to instanceof BystanderEntity tb) tb.setSkin(b.skin());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @SubscribeEvent
    public static void onPre(RenderLivingEvent.Pre<?, ?> e) {
        if (rendering || MAP.isEmpty()) return;
        LivingEntity shown = e.getEntity();
        Integer asId = MAP.get(shown.getId());
        if (asId == null) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        Entity as = level.getEntity(asId);
        if (!(as instanceof LivingEntity repl) || repl == shown) return;
        Stand st = standFor(shown.getId(), asId, repl, level);
        if (st == null) return;

        copyState(st, shown, repl);
        EntityRenderer renderer = mc.getEntityRenderDispatcher().getRenderer(st.entity);
        e.setCanceled(true);
        rendering = true;
        renderingFor = shown;
        try {
            renderer.render(st.entity, Mth.lerp(e.getPartialTick(), shown.yRotO, shown.getYRot()), e.getPartialTick(),
                e.getPoseStack(), e.getMultiBufferSource(), e.getPackedLight());
        } catch (Throwable t) {
            // a model that cannot be drawn this way: show the real one from now on
            MAP.remove(shown.getId());
            STANDS.remove(shown.getId());
        } finally {
            rendering = false;
            renderingFor = null;
        }
    }

    /** The stand-in carries a copied name; hide it over your own head like vanilla does. */
    @SubscribeEvent
    public static void onNameTag(RenderNameTagEvent e) {
        if (rendering && renderingFor != null && renderingFor == Minecraft.getInstance().getCameraEntity()) {
            e.setResult(Event.Result.DENY);
        }
    }
}
