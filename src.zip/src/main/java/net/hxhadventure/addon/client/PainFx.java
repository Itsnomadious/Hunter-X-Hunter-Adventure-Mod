package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.hxhadventure.addon.network.PacketPainFx;

/** Client-side state for Pain Packer (fed by PacketPainFx): who wears the armour, and the suns in the sky. */
public final class PainFx {
    private PainFx() {}

    public static final class Sun {
        public double fromX, fromY, fromZ, toX, toY, toZ;
        public float diameter, range;
        public int deploy, life;
        public double t0;
        public long lastTick = -1;
    }

    private static final Set<Integer> ARMORED = new HashSet<>();
    private static final Set<Integer> HEATED = new HashSet<>();
    public static final Map<Integer, Sun> SUNS = new HashMap<>();

    public static boolean hasArmor(int entityId) {
        return !ARMORED.isEmpty() && ARMORED.contains(entityId);
    }

    /** True while the wearer's sun burns: the armour glows white-hot. */
    public static boolean isHeated(int entityId) {
        return !HEATED.isEmpty() && HEATED.contains(entityId);
    }

    public static boolean hasSuns() {
        return !SUNS.isEmpty();
    }

    public static void handle(byte kind, int id, boolean flag, double fx, double fy, double fz, double tx, double ty, double tz,
                              float size, float range, int deploy, int life) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        switch (kind) {
            case PacketPainFx.ARMOR -> {
                if (flag) ARMORED.add(id);
                else ARMORED.remove(id);
            }
            case PacketPainFx.HEAT -> {
                if (flag) HEATED.add(id);
                else HEATED.remove(id);
            }
            case PacketPainFx.SUN -> {
                Sun s = new Sun();
                s.fromX = fx; s.fromY = fy; s.fromZ = fz;
                s.toX = tx; s.toY = ty; s.toZ = tz;
                s.diameter = size;
                s.range = range;
                s.deploy = Math.max(1, deploy);
                s.life = Math.max(s.deploy + 1, life);
                s.t0 = level.getGameTime();
                SUNS.put(id, s);
            }
            case PacketPainFx.SUN_END -> SUNS.remove(id);
            default -> { }
        }
    }

    public static void clear() {
        ARMORED.clear();
        HEATED.clear();
        SUNS.clear();
    }
}
