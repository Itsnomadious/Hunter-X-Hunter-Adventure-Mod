package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.util.FormattedCharSequence;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.ChainAbilities;
import net.hxhadventure.addon.ClientVows;
import net.hxhadventure.addon.NenSkill;
import net.hxhadventure.addon.Vows;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketChooseVow;
import net.hxhadventure.entity.client.gui.HxhUi;

/**
 * Page 2 of the O menu: Nen Vows and Limitations. Explains Conditions, Limitations, Vows and the Rule of Equivalent Exchange,
 * then lists every Nen skill (and the Hatsu abilities you have) to bind a rule to. Picking a rule asks "are you sure?":
 * once confirmed it can never be removed. The menu can be closed at any time. Drawn with HxhUi like the Mastery page.
 */
public class VowsScreen extends Screen {
    private static final int HALF_W = 172;
    private static final int MIN_PANEL_H = 276;
    private static final int MAX_PANEL_H = 420;
    private static final int TEXT_W = 304;
    private static final int ROW_H = 17;
    private static final int MAX_DEF_LINES = 6;
    private static final int OPT_H = 36;

    private enum Mode { LIST, KINDS, OPTIONS, CONFIRM }

    private Mode mode = Mode.LIST;
    private String target;
    private Vows.Kind kind;
    private Vows.Rule pending;
    private int scroll;
    private int optPage;
    private List<String> targets;
    private List<FormattedCharSequence> defLines;
    private List<Vows.Rule> options = List.of();

    public VowsScreen() {
        super(Component.literal("Vows and Limitations"));
    }

    private static List<String> buildTargets() {
        List<String> out = new ArrayList<>();
        for (NenSkill s : NenSkill.values()) out.add(s.name());
        out.addAll(Vows.FORM_KEYS); // Ken and Ko
        out.addAll(Vows.ATTACK_IDS);
        Minecraft mc = Minecraft.getInstance();
        Combat c = mc.player != null ? Combat.get(mc.player) : null;
        if (c != null) {
            for (String id : ChainAbilities.extend(new String[0], c)) {
                if (Vows.HATSU_IDS.contains(id) && !out.contains(id)) out.add(id);
            }
        }
        return out;
    }

    private List<FormattedCharSequence> buildDefLines() {
        String[][] defs = {
            {"Condition: ", "a small restriction. Weak boost."},
            {"Limitation: ", "a real handicap. Stronger boost."},
            {"Vow: ", "a contract with a severe penalty if broken. Strongest boost."},
            {"Equivalent Exchange: ", "power costs something. Rules stack and can never be removed."},
        };
        List<FormattedCharSequence> out = new ArrayList<>();
        for (String[] d : defs) {
            MutableComponent line = Component.literal(d[0]).withStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xD4AF37)))
                .append(Component.literal(d[1]).withStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xE8E4D8))));
            out.addAll(this.font.split(line, TEXT_W));
        }
        return out;
    }

    /** The panel uses as much of the screen as it can, so the skill list gets the room. */
    private int panelH() {
        return Math.max(MIN_PANEL_H, Math.min(this.height - 16, MAX_PANEL_H));
    }

    private int top() {
        return Math.max(12, this.height / 2 - panelH() / 2 + 8);
    }

    private int defN() {
        return defLines == null ? 0 : Math.min(MAX_DEF_LINES, defLines.size());
    }

    /** Where the "Pick a skill" label sits, below the short definitions box. */
    private int labelY() {
        return 14 + 10 * defN() + 8 + 6;
    }

    private int listY() {
        return labelY() + 12;
    }

    private int visibleRows() {
        return Math.max(3, (panelH() - 44 - 6 - listY()) / ROW_H);
    }

    private int maxScroll() {
        return Math.max(0, targets.size() - visibleRows());
    }

    @Override
    protected void init() {
        if (targets == null) targets = buildTargets();
        if (defLines == null) defLines = buildDefLines();
        int cx = this.width / 2;
        int top = top();
        int by = top + panelH() - 44;
        int rows = visibleRows();
        int listY = listY();
        switch (mode) {
            case LIST -> {
                scroll = Math.max(0, Math.min(scroll, maxScroll()));
                for (int i = 0; i < rows && scroll + i < targets.size(); i++) {
                    String t = targets.get(scroll + i);
                    addRenderableWidget(HxhUi.button(cx - 160, top + listY + i * ROW_H, 290, ROW_H - 1, rowLabel(t), b -> {
                        target = t;
                        mode = Mode.KINDS;
                        rebuildWidgets();
                    }, false));
                }
                HxhUi.HxhButton up = HxhUi.button(cx + 134, top + listY, 26, ROW_H - 1, "^", b -> {
                    scroll = Math.max(0, scroll - 1);
                    rebuildWidgets();
                }, false);
                up.active = scroll > 0;
                addRenderableWidget(up);
                HxhUi.HxhButton down = HxhUi.button(cx + 134, top + listY + (rows - 1) * ROW_H, 26, ROW_H - 1, "v", b -> {
                    scroll = Math.min(maxScroll(), scroll + 1);
                    rebuildWidgets();
                }, false);
                down.active = scroll < maxScroll();
                addRenderableWidget(down);
                addRenderableWidget(HxhUi.button(cx - 160, by, 80, 20, "< Page 1", b -> Minecraft.getInstance().setScreen(new NenSkillsScreen()), false));
                addRenderableWidget(HxhUi.button(cx - 40, by, 80, 20, "Close", b -> onClose(), true));
                addRenderableWidget(HxhUi.button(cx + 44, by, 116, 20, "Page 3: Active >", b -> Minecraft.getInstance().setScreen(new ActiveVowsScreen()), false));
            }
            case KINDS -> {
                int y = top + 60;
                for (Vows.Kind k : Vows.Kind.values()) {
                    List<Vows.Rule> avail = available(target, k);
                    String hint = switch (k) {
                        case CONDITION -> "small restriction, weak boost";
                        case LIMITATION -> "real handicap, better boost";
                        case VOW -> "severe penalty, the strongest boost";
                    };
                    HxhUi.HxhButton kb = HxhUi.button(cx - 160, y, 320, 30,
                        k.label + "  -  " + hint + "  (" + avail.size() + " left)", b -> {
                            kind = k;
                            options = available(target, k);
                            optPage = 0;
                            mode = Mode.OPTIONS;
                            rebuildWidgets();
                        }, k == Vows.Kind.VOW);
                    kb.active = !avail.isEmpty();
                    addRenderableWidget(kb);
                    y += 36;
                }
                addRenderableWidget(HxhUi.button(cx - 160, by, 80, 20, "< Back", b -> {
                    mode = Mode.LIST;
                    rebuildWidgets();
                }, false));
                addRenderableWidget(HxhUi.button(cx - 40, by, 80, 20, "Close", b -> onClose(), true));
            }
            case OPTIONS -> {
                optPage = Math.max(0, Math.min(optPage, optPages() - 1));
                for (int n = 0; n < perPage() && optPage * perPage() + n < options.size(); n++) {
                    Vows.Rule r = options.get(optPage * perPage() + n);
                    addRenderableWidget(HxhUi.button(cx - 160, top + 22 + n * (OPT_H + 2), 320, OPT_H, "", b -> {
                        pending = r;
                        mode = Mode.CONFIRM;
                        rebuildWidgets();
                    }, false));
                }
                addRenderableWidget(HxhUi.button(cx - 160, by, 80, 20, "< Back", b -> {
                    mode = Mode.KINDS;
                    rebuildWidgets();
                }, false));
                addRenderableWidget(HxhUi.button(cx - 40, by, 80, 20, "Close", b -> onClose(), true));
                HxhUi.HxhButton prev = HxhUi.button(cx + 44, by, 56, 20, "< Prev", b -> {
                    optPage--;
                    rebuildWidgets();
                }, false);
                prev.active = optPage > 0;
                addRenderableWidget(prev);
                HxhUi.HxhButton next = HxhUi.button(cx + 104, by, 56, 20, "Next >", b -> {
                    optPage++;
                    rebuildWidgets();
                }, false);
                next.active = optPage < optPages() - 1;
                addRenderableWidget(next);
            }
            case CONFIRM -> {
                addRenderableWidget(HxhUi.button(cx - 160, top + 196, 156, 24, "Yes, I swear it", b -> {
                    if (pending != null) {
                        AddonNetwork.sendToServer(new PacketChooseVow(pending.id()));
                        String weaker = Vows.weakerPrayer(pending.id());
                        if (weaker != null) ClientVows.chosen.remove(weaker); // the Vow replaces the prayer Condition
                        ClientVows.chosen.add(pending.id()); // the server confirms with a sync; this just updates the list at once
                    }
                    pending = null;
                    target = null;
                    mode = Mode.LIST;
                    rebuildWidgets();
                }, true));
                addRenderableWidget(HxhUi.button(cx + 4, top + 196, 156, 24, "No", b -> {
                    pending = null;
                    mode = Mode.OPTIONS;
                    options = available(target, kind);
                    rebuildWidgets();
                }, false));
            }
        }
        OMenu.addSide(this::addRenderableWidget, this.width, top() - 8, false, OMenu.Page.VOWS);
}

    /** As many rules per page as the panel has room for (the list used to stop at 5 and push the rest to a second page). */
    private int perPage() {
        return Math.max(3, (panelH() - 44 - 4 - 22) / (OPT_H + 2));
    }

    private int optPages() {
        return Math.max(1, (options.size() + perPage() - 1) / perPage());
    }

    private static List<Vows.Rule> available(String target, Vows.Kind kind) {
        List<Vows.Rule> out = new ArrayList<>();
        Minecraft mc = Minecraft.getInstance();
        Combat c = mc.player != null ? Combat.get(mc.player) : null;
        for (Vows.Rule r : Vows.rulesFor(target, kind)) {
            if (!ClientVows.chosen.contains(r.id()) && !Vows.conflicts(r.id(), ClientVows.chosen) && Vows.canSwear(c, r.id())
                && (!Vows.stakeLocked(r.id()) || ClientVows.selfStake)) out.add(r);
        }
        return out;
    }

    private static String rowLabel(String t) {
        String name = Vows.isSkill(t) || Vows.isForm(t) || Vows.isAttack(t) ? Vows.label(t) : "Hatsu: " + Vows.label(t);
        return name + "   [" + ClientVows.count(t, Vows.Kind.CONDITION) + "C  "
            + ClientVows.count(t, Vows.Kind.LIMITATION) + "L  " + ClientVows.count(t, Vows.Kind.VOW) + "V]";
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (mode == Mode.LIST && maxScroll() > 0) {
            int next = Math.max(0, Math.min(maxScroll(), scroll + (delta < 0 ? 1 : -1)));
            if (next != scroll) {
                scroll = next;
                rebuildWidgets();
            }
            return true;
        }
        return super.mouseScrolled(mx, my, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        HxhUi.backdrop(g, this.width, this.height);
        int cx = this.width / 2;
        int top = top();
        HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, panelH());
        switch (mode) {
            case LIST -> {
                HxhUi.title(g, this.font, "VOWS & LIMITATIONS", cx, top);
                int defN = defN();
                HxhUi.inset(g, cx - 160, top + 14, 320, 10 * defN + 8);
                for (int i = 0; i < defN; i++) {
                    FormattedCharSequence line = defLines.get(i);
                    g.drawString(this.font, line, cx - 156, top + 19 + i * 10, 0xFFFFFFFF, false);
                }
                g.drawString(this.font, "Pick a skill, attack or Hatsu to bind a rule to:", cx - 160, top + labelY(), HxhUi.TEXT_DIM, false);
                if (maxScroll() > 0) {
                    String pos = (scroll + 1) + "-" + Math.min(targets.size(), scroll + visibleRows()) + " / " + targets.size();
                    g.drawString(this.font, pos, cx + 160 - this.font.width(pos), top + labelY(), HxhUi.TEXT_DIM, false);
                }
            }
            case KINDS -> {
                HxhUi.title(g, this.font, "BIND: " + Vows.label(target).toUpperCase(java.util.Locale.ROOT), cx, top);
                int sworn = 0;
                for (Vows.Kind k : Vows.Kind.values()) sworn += ClientVows.count(target, k);
                HxhUi.subtitle(g, this.font, sworn == 0 ? "Nothing sworn on this yet." : sworn + " rule(s) already sworn on this.", cx, top + 18);
                HxhUi.subtitle(g, this.font, "What do you want to add?", cx, top + 40);
            }
            case OPTIONS -> {
                HxhUi.title(g, this.font, kind.label.toUpperCase(java.util.Locale.ROOT) + "S: " + Vows.label(target).toUpperCase(java.util.Locale.ROOT), cx, top);
                if (optPages() > 1) {
                    String pg = (optPage + 1) + " / " + optPages();
                    g.drawString(this.font, pg, cx + 160 - this.font.width(pg), top + 12, HxhUi.TEXT_DIM, false);
                }
            }
            case CONFIRM -> {
                HxhUi.title(g, this.font, "ARE YOU SURE?", cx, top);
            }
        }
        super.render(g, mouseX, mouseY, partial);
        if (mode == Mode.OPTIONS) {
            for (int n = 0; n < perPage() && optPage * perPage() + n < options.size(); n++) {
                Vows.Rule r = options.get(optPage * perPage() + n);
                int y = top + 22 + n * (OPT_H + 2);
                int rc = r.id().equals(Vows.EVERYTHING_VOW) ? HxhUi.RED : HxhUi.TEXT;
                List<FormattedCharSequence> lines = UiText.wrapFit(this.font, r.text(), 306, 2);
                for (int l = 0; l < lines.size(); l++) g.drawString(this.font, lines.get(l), cx - 154, y + 5 + l * 10, rc, false);
                UiText.drawFit(g, this.font, "Reward: " + r.boostText(), cx - 154, y + 25, 306, HxhUi.GREEN, false);
            }
        } else if (mode == Mode.CONFIRM && pending != null) {
            HxhUi.inset(g, cx - 160, top + 18, 320, 172);
            UiText.drawFit(g, this.font, pending.kind().label + " on " + Vows.label(pending.target()), cx - 150, top + 26, 300, HxhUi.GOLD, true);
            java.util.List<UiText.Para> paras = new java.util.ArrayList<>();
            paras.add(new UiText.Para("\"" + pending.text() + "\"", pending.id().equals(Vows.EVERYTHING_VOW) ? HxhUi.RED : HxhUi.TEXT, 0));
            paras.add(new UiText.Para("Reward: " + pending.boostText(), HxhUi.GREEN, 6));
            paras.add(new UiText.Para("This can never be removed. Not by dying, not by choice.", HxhUi.RED, 6));
            if (Vows.weakerPrayer(pending.id()) != null && ClientVows.chosen.contains(Vows.weakerPrayer(pending.id()))) {
                paras.add(new UiText.Para("Only one prayer rule can stand on an attack: this Vow replaces the prayer Condition you already swore.", HxhUi.GOLD, 4));
            }
            if (pending.enforce() == Vows.Enforce.LOCK) {
                Vows.Lock lk = Vows.LOCKS.get(pending.id());
                paras.add(new UiText.Para(lk != null && lk.enRadius() > 0f
                    ? "A lockout: your En will never reach further than " + Math.round(lk.enRadius()) + " meter" + (lk.enRadius() > 1f ? "s" : "") + " again."
                    : "A lockout: you will never be able to use it again. Nothing can undo it.", HxhUi.RED, 4));
            } else if (pending.kind() == Vows.Kind.VOW) {
                paras.add(new UiText.Para("A Vow is a contract: if you break it, the penalty is carried out in full.", HxhUi.RED, 4));
            }
            UiText.drawBlock(g, this.font, paras, cx - 150, top + 42, 300, 144);
        }
    }
}
