package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;

/**
 * The 100-Type Guanyin Bodhisattva as a skeleton: a tree of bones, each carrying a few boxes, that is posed every frame and then drawn
 * by {@link GuanyinRenderer}. Nothing here touches Minecraft (it is plain maths), so it can be tested on its own.
 *
 * <p>The statue has a spine and chest (so it can lean over), a head, a spinning halo, and {@link #N_ARMS} arms: two big "main" arms (the
 * ones that slap, chop and clap; at rest they hold the prayer pose) and twenty decorative ones fanned out behind. Every arm is upper arm,
 * forearm and a hand, and is placed by a two-bone IK solver from a wrist target (it stretches when the target is out of reach, so a hand
 * can land anywhere). Every hand has a palm, four fingers of two joints and a two-joint thumb.
 *
 * <p>The hands are built by {@link #buildHand}, once per arm, from a single description with every x multiplied by {@code side}
 * (+1 = the statue's left hand, which is on the user's left = +X; -1 = the right hand). So a left hand is the exact mirror image of a right
 * hand, thumb and all. The thumb, the finger lengths and the knuckle line all lean to one side, so you can tell them apart.
 *
 * <p>Frame: statue-local, +Y up, +Z the way the statue faces, +X the statue's left, origin at the centre of the lotus on the ground.
 * A bone's own frame has its children hanging down -Y (arms and fingers point along -Y); a hand's palm faces +Z.
 */
public final class GuanyinRig {
    public static final double UPPER = 2.8, FORE = 2.5;
    public static final int ARMS_PER_SIDE = 10;
    /** Arm indices: 0 = main right, 1 = main left, then the fan arms: 2.. right side (low to high), 12.. left side. */
    public static final int MAIN_RIGHT = 0, MAIN_LEFT = 1;
    public static final int N_ARMS = 2 + 2 * ARMS_PER_SIDE;
    /** Size of a hand relative to the "unit hand" it is described in (a palm about 0.9 wide). */
    private static final double HS = 1.35;

    public static int fanArm(int side, int i) { return 2 + (side > 0 ? ARMS_PER_SIDE : 0) + i; }
    public static int sideOf(int arm) { return arm == MAIN_RIGHT ? -1 : arm == MAIN_LEFT ? 1 : (arm - 2) < ARMS_PER_SIDE ? -1 : 1; }

    // ------------------------------------------------------------------ small vector helpers (double[3])

    public static double[] v(double x, double y, double z) { return new double[] {x, y, z}; }
    public static double[] add(double[] a, double[] b) { return v(a[0] + b[0], a[1] + b[1], a[2] + b[2]); }
    public static double[] sub(double[] a, double[] b) { return v(a[0] - b[0], a[1] - b[1], a[2] - b[2]); }
    public static double[] mul(double[] a, double s) { return v(a[0] * s, a[1] * s, a[2] * s); }
    public static double dot(double[] a, double[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
    public static double len(double[] a) { return Math.sqrt(dot(a, a)); }
    public static double[] cross(double[] a, double[] b) { return v(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]); }
    public static double[] norm(double[] a) {
        double l = len(a);
        return l < 1.0e-9 ? v(0, 1, 0) : mul(a, 1.0 / l);
    }
    public static double[] lerp(double[] a, double[] b, double t) { return v(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t); }

    // ------------------------------------------------------------------ definition

    /** One box of the statue, in the frame of its bone: centre, size, brightness of the gold, opacity, and its own turn (row-major 3x3). */
    public static final class Cube {
        public final int bone;
        public final double cx, cy, cz, sx, sy, sz, bright;
        public final int alpha;
        final double[] rot; // null = axis aligned
        final boolean fixed; // joints: not lengthened when the arm stretches

        Cube(int bone, double cx, double cy, double cz, double sx, double sy, double sz, double bright, int alpha, double[] rot, boolean fixed) {
            this.fixed = fixed;
            this.bone = bone;
            this.cx = cx; this.cy = cy; this.cz = cz;
            this.sx = sx; this.sy = sy; this.sz = sz;
            this.bright = bright;
            this.alpha = alpha;
            this.rot = rot;
        }
    }

    private final List<String> boneName = new ArrayList<>();
    private final List<Integer> boneParent = new ArrayList<>();
    private final List<double[]> boneOff = new ArrayList<>();   // rest offset from the parent's pivot, in the parent's frame
    private final List<double[]> boneRest = new ArrayList<>();  // rest turn, degrees: pitch (x), yaw (y), roll (z)
    private final List<double[]> boneAbs = new ArrayList<>();   // rest pivot in the statue frame (only meaningful for bones with no rest turn above them)
    private final List<Cube> cubeList = new ArrayList<>();

    // frozen after construction
    private int nb;
    private int[] parent;
    private double[] off, rest;
    public Cube[] cubes;

    // bones the animator talks to
    private int spine, chest, head, halo;
    private final int[] armUpper = new int[N_ARMS], armFore = new int[N_ARMS], armHand = new int[N_ARMS];
    /** Per arm: the 4 proximal finger bones, the 4 distal ones, then the 2 thumb bones. */
    private final int[][] armFinger = new int[N_ARMS][10];
    private int bodyBones; // bones [0, bodyBones) are the body; arm bones come after
    private boolean bareHand;

    /** Shoulder pivots at rest, statue frame. */
    private final double[][] shoulderAbs = new double[N_ARMS][];
    private static final double[] SPINE_AT = {0, 1.7, 0}, CHEST_AT = {0, 4.4, 0}, HEAD_AT = {0, 7.2, 0}, HALO_AT = {0, 8.6, -1.4};

    public GuanyinRig() {
        buildBody();
        buildArms();
        freeze();
    }

    /** A rig with a single bare hand ({@code side} +1 left, -1 right), for the detached hand of Aspect of Guanyin. */
    public static GuanyinRig handOnly(int side) {
        GuanyinRig r = new GuanyinRig(side);
        return r;
    }

    private GuanyinRig(int handSide) {
        bareHand = true;
        int root = bone("root", -1, 0, 0, 0);
        int hand = bone("hand", root, 0, 0, 0);
        armHand[0] = hand;
        buildHand(0, hand, handSide, 205, 1.0);
        bodyBones = nb = boneName.size();
        freeze();
    }

    private int bone(String name, int par, double x, double y, double z) {
        boneName.add(name);
        boneParent.add(par);
        boneOff.add(new double[] {x, y, z});
        boneRest.add(new double[] {0, 0, 0});
        double[] pa = par < 0 ? new double[] {0, 0, 0} : boneAbs.get(par);
        boneAbs.add(new double[] {pa[0] + x, pa[1] + y, pa[2] + z});
        return boneName.size() - 1;
    }

    private int boneAt(String name, int par, double[] abs) {
        double[] pa = boneAbs.get(par);
        return bone(name, par, abs[0] - pa[0], abs[1] - pa[1], abs[2] - pa[2]);
    }

    /** A box given in the statue frame at rest (bone must have no turn above it). */
    private void cubeAbs(int b, double cx, double cy, double cz, double sx, double sy, double sz, double bright, int alpha) {
        double[] a = boneAbs.get(b);
        cubeList.add(new Cube(b, cx - a[0], cy - a[1], cz - a[2], sx, sy, sz, bright, alpha, null, false));
    }

    /** A box given in the bone's own frame. */
    private void cubeLocal(int b, double cx, double cy, double cz, double sx, double sy, double sz, double bright, int alpha) {
        cubeList.add(new Cube(b, cx, cy, cz, sx, sy, sz, bright, alpha, null, false));
    }

    /** A box that keeps its size when the arm it sits on stretches (a joint). */
    private void cubeJoint(int b, double size, double bright, int alpha) {
        cubeList.add(new Cube(b, 0, 0, 0, size, size, size, bright, alpha, null, true));
    }

    private void cubeTurned(int b, double[] centreLocal, double[] size, double bright, int alpha, double[] rot) {
        cubeList.add(new Cube(b, centreLocal[0], centreLocal[1], centreLocal[2], size[0], size[1], size[2], bright, alpha, rot, false));
    }

    // ---- rotation matrices (row-major 3x3), R = Ry * Rx * Rz, degrees

    static double[] euler(double pitch, double yaw, double roll) {
        double px = Math.toRadians(pitch), py = Math.toRadians(yaw), pz = Math.toRadians(roll);
        double cx = Math.cos(px), sx = Math.sin(px), cy = Math.cos(py), sy = Math.sin(py), cz = Math.cos(pz), sz = Math.sin(pz);
        // Rx * Rz
        double[] xz = {
            cz, -sz, 0,
            cx * sz, cx * cz, -sx,
            sx * sz, sx * cz, cx};
        // Ry * (Rx Rz)
        return new double[] {
            cy * xz[0] + sy * xz[6], cy * xz[1] + sy * xz[7], cy * xz[2] + sy * xz[8],
            xz[3], xz[4], xz[5],
            -sy * xz[0] + cy * xz[6], -sy * xz[1] + cy * xz[7], -sy * xz[2] + cy * xz[8]};
    }

    static double[] mm(double[] a, double[] b) {
        double[] o = new double[9];
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) o[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c];
        }
        return o;
    }

    static double[] mv(double[] m, double[] x) {
        return v(m[0] * x[0] + m[1] * x[1] + m[2] * x[2], m[3] * x[0] + m[4] * x[1] + m[5] * x[2], m[6] * x[0] + m[7] * x[1] + m[8] * x[2]);
    }

    // ------------------------------------------------------------------ the body

    private void buildBody() {
        int root = bone("root", -1, 0, 0, 0);
        spine = boneAt("spine", root, SPINE_AT);
        chest = boneAt("chest", spine, CHEST_AT);
        head = boneAt("head", chest, HEAD_AT);
        halo = boneAt("halo", chest, HALO_AT);

        // the lotus: two square slabs turned 45 degrees to each other, and two rings of petals
        cubeAbs(root, 0, 0.25, 0, 6.0, 0.5, 6.0, 1.0, 215);
        cubeTurned(root, new double[] {0, 0.3, 0}, new double[] {6.0, 0.5, 6.0}, 0.9, 215, euler(0, 45, 0));
        for (int ring = 0; ring < 2; ring++) {
            for (int k = 0; k < 12; k++) {
                double yaw = k * 30.0 + ring * 15.0;
                double tilt = ring == 0 ? -35 : -58;
                double radius = ring == 0 ? 3.0 : 3.5;
                double[] tilted = euler(tilt, 0, 0), turn = euler(0, yaw, 0);
                double[] c = mv(turn, add(v(0, ring == 0 ? 0.55 : 0.4, radius), mv(tilted, v(0, 0, 0.6))));
                cubeTurned(root, c, v(1.3, 0.2, 1.7), ring == 0 ? 1.1 : 1.0, ring == 0 ? 205 : 185, mm(turn, tilted));
            }
        }
        // crossed legs, knees, feet
        cubeAbs(root, 0, 1.4, 0, 5.4, 1.3, 3.6, 1.0, 215);
        cubeAbs(root, 2.5, 1.6, 1.4, 1.8, 1.0, 2.2, 1.0, 215);
        cubeAbs(root, -2.5, 1.6, 1.4, 1.8, 1.0, 2.2, 1.0, 215);
        cubeAbs(root, 1.2, 1.4, 2.2, 1.2, 0.5, 1.3, 1.1, 215);
        cubeAbs(root, -1.2, 1.4, 2.2, 1.2, 0.5, 1.3, 1.1, 215);

        // the robe and belly (spine) and the chest
        cubeAbs(spine, 0, 3.3, 0, 3.8, 2.4, 2.6, 0.95, 215);
        cubeAbs(spine, 0, 3.0, 1.3, 2.4, 3.0, 0.2, 1.1, 190);          // the sash down the front
        cubeAbs(chest, 0, 5.2, 0, 3.0, 2.2, 2.0, 1.0, 215);
        cubeAbs(chest, 0, 6.35, 0, 4.4, 0.8, 1.9, 1.05, 215);          // shoulders
        cubeAbs(chest, 0, 5.75, 1.05, 2.0, 0.45, 0.15, 1.25, 230);     // a necklace
        cubeAbs(chest, 0, 5.15, 1.05, 0.5, 0.5, 0.15, 1.3, 235);       // its jewel

        // the head
        cubeAbs(head, 0, 7.0, 0, 0.9, 0.5, 0.9, 0.9, 215);             // neck
        cubeAbs(head, 0, 7.9, 0.1, 1.7, 1.9, 1.6, 1.15, 225);          // face
        cubeAbs(head, 0, 8.95, -0.1, 2.7, 1.2, 2.5, 1.0, 215);         // hair
        cubeAbs(head, 0, 9.9, -0.1, 1.1, 0.9, 1.0, 1.1, 215);          // the small face on top
        cubeAbs(head, 0, 8.05, 0.95, 1.1, 0.12, 0.1, 0.5, 235);        // closed eyes, a thin dark line
        cubeAbs(head, 0.45, 7.55, 0.95, 0.1, 0.8, 0.1, 0.55, 225);     // a tear
        cubeAbs(head, 0, 7.75, 0.95, 0.2, 0.5, 0.25, 1.1, 225);        // nose
        cubeAbs(head, 0, 7.35, 0.92, 0.5, 0.08, 0.1, 0.6, 230);        // mouth
        cubeAbs(head, 0, 8.45, 0.88, 0.14, 0.14, 0.1, 1.4, 240);       // the urna
        for (int s = -1; s <= 1; s += 2) {
            cubeAbs(head, s * 0.95, 7.8, 0.0, 0.2, 1.0, 0.4, 1.1, 225);   // ear
            cubeAbs(head, s * 0.95, 7.1, 0.0, 0.17, 0.7, 0.28, 1.1, 225); // its long lobe
        }
        // the halo: twenty rays and a ring, behind the head, turning
        for (int k = 0; k < 20; k++) {
            double[] rz = euler(0, 0, k * 18.0);
            cubeTurned(halo, mv(rz, v(0, 3.4, 0)), v(0.8, 0.5, 0.3), 1.2, 150, rz);
        }
        for (int k = 0; k < 24; k++) {
            double[] rz = euler(0, 0, k * 15.0);
            cubeTurned(halo, mv(rz, v(0, 2.6, 0)), v(0.45, 0.3, 0.2), 1.3, 170, rz);
        }
        bodyBones = boneName.size();
    }

    // ------------------------------------------------------------------ arms and hands

    private void buildArms() {
        for (int arm = 0; arm < N_ARMS; arm++) {
            int side = sideOf(arm);
            boolean main = arm < 2;
            double[] sh;
            if (main) {
                sh = v(side * 1.5, 6.0, 0.15);
            } else {
                int i = (arm - 2) % ARMS_PER_SIDE;
                sh = v(side * 1.55, 6.0 - (i % 3) * 0.12, -0.2 - (i % 3) * 0.45);
            }
            shoulderAbs[arm] = sh;
            double w = main ? 0.8 : 0.6;
            double bright = main ? 1.05 : 1.0;
            int alpha = main ? 215 : 195;
            String n = "arm" + arm;
            int upper = boneAt(n + "u", chest, sh);
            cubeJoint(upper, w * 1.5, bright * 1.05, alpha);                                              // shoulder ball
            cubeLocal(upper, 0, -UPPER / 2, 0, w, UPPER, w, bright, alpha);
            int fore = bone(n + "f", upper, 0, -UPPER, 0);
            cubeJoint(fore, w * 1.2, bright * 1.05, alpha);                                               // elbow
            cubeLocal(fore, 0, -FORE / 2, 0, w * 0.85, FORE, w * 0.85, bright, alpha);
            int hand = bone(n + "h", fore, 0, -FORE, 0);
            armUpper[arm] = upper;
            armFore[arm] = fore;
            armHand[arm] = hand;
            buildHand(arm, hand, side, 205, main ? 1.1 : 1.0);
        }
    }

    /**
     * One hand, {@code side} +1 = left, -1 = right (the left is the right with every x multiplied by -1 and every roll negated).
     * The hand's origin is the wrist; the fingers run down -Y and the palm faces +Z. Seen from the palm side, a right hand has its thumb
     * on the -X side, a left hand on the +X side.
     */
    private void buildHand(int arm, int hand, int side, int alpha, double bright) {
        double hs = HS;
        // cuff and palm
        cubeLocal(hand, 0, 0.05 * hs, 0, 0.62 * hs, 0.3 * hs, 0.4 * hs, bright * 0.95, alpha);
        cubeLocal(hand, 0, -0.52 * hs, 0, 0.92 * hs, 0.82 * hs, 0.28 * hs, bright, alpha);
        cubeLocal(hand, side * 0.3 * hs, -0.45 * hs, 0.17 * hs, 0.32 * hs, 0.34 * hs, 0.08 * hs, bright * 1.15, alpha);   // the heel of the thumb, a raised pad on the palm
        int[] f = armFinger[arm];
        // index, middle, ring, little: the index is on the thumb side
        double[] prox = {0.46, 0.52, 0.48, 0.38}, dist = {0.34, 0.38, 0.35, 0.28};
        for (int k = 0; k < 4; k++) {
            double x = side * (0.31 - 0.205 * k) * hs;
            int p = bone("fp" + arm + k, hand, x, -0.93 * hs, 0);
            boneRest.get(p)[0] = -6;
            cubeLocal(p, 0, -prox[k] * hs / 2, 0, 0.17 * hs, prox[k] * hs, 0.2 * hs, bright * 1.05, alpha);
            int d = bone("fd" + arm + k, p, 0, -prox[k] * hs, 0);
            boneRest.get(d)[0] = -9;
            cubeLocal(d, 0, -dist[k] * hs / 2, 0, 0.15 * hs, dist[k] * hs, 0.17 * hs, bright * 1.12, alpha);
            f[k] = p;
            f[4 + k] = d;
        }
        // the thumb: starts low on the thumb side of the palm, points down and outward, turned a little toward the palm
        int t0 = bone("tb" + arm, hand, side * 0.46 * hs, -0.42 * hs, 0.04 * hs);
        double[] r0 = boneRest.get(t0);
        r0[0] = -14;
        r0[2] = side * 40;
        cubeLocal(t0, 0, -0.27 * hs, 0, 0.23 * hs, 0.54 * hs, 0.24 * hs, bright * 1.05, alpha);
        int t1 = bone("tt" + arm, t0, 0, -0.54 * hs, 0);
        double[] r1 = boneRest.get(t1);
        r1[0] = -8;
        r1[2] = side * 8;
        cubeLocal(t1, 0, -0.21 * hs, 0, 0.2 * hs, 0.42 * hs, 0.21 * hs, bright * 1.12, alpha);
        f[8] = t0;
        f[9] = t1;
    }

    private void freeze() {
        nb = boneName.size();
        parent = new int[nb];
        off = new double[nb * 3];
        rest = new double[nb * 3];
        for (int i = 0; i < nb; i++) {
            parent[i] = boneParent.get(i);
            System.arraycopy(boneOff.get(i), 0, off, i * 3, 3);
            System.arraycopy(boneRest.get(i), 0, rest, i * 3, 3);
        }
        cubes = cubeList.toArray(new Cube[0]);
        // solve state
        R = new double[nb * 9];
        T = new double[nb * 3];
        acc = new double[nb];
        sy = new double[nb];
        sc = new double[nb];
        ex = new double[nb];
        ey = new double[nb];
        ez = new double[nb];
        tr = new double[nb * 3];
        aim = new double[nb * 9];
        aimed = new boolean[nb];
    }

    public int cubeCount() { return cubes.length; }

    // ------------------------------------------------------------------ the pose

    /** What one arm is told to do: put the wrist here, point the fingers this way with the palm facing that way, bend the elbow toward the pole. */
    public static final class ArmCmd {
        public final double[] wrist = new double[3], dir = {0, -1, 0}, palm = {0, 0, 1}, pole = {0, 0, -1};
        public double curl, scale = 1.0;

        public void set(double[] w, double[] d, double[] p, double[] po, double curl, double scale) {
            System.arraycopy(w, 0, wrist, 0, 3);
            System.arraycopy(norm(d), 0, dir, 0, 3);
            System.arraycopy(norm(p), 0, palm, 0, 3);
            System.arraycopy(po, 0, pole, 0, 3);
            this.curl = curl;
            this.scale = scale;
        }

        /** Move this command toward another by {@code t} (0 = unchanged, 1 = fully the other). */
        public void blend(double[] w, double[] d, double[] p, double[] po, double curl, double scale, double t) {
            if (t <= 0) return;
            if (t >= 1) {
                set(w, d, p, po, curl, scale);
                return;
            }
            set(lerp(wrist, w, t), lerp(dir, norm(d), t), lerp(palm, norm(p), t), lerp(pole, po, t), this.curl + (curl - this.curl) * t, this.scale + (scale - this.scale) * t);
        }
    }

    public static final class Pose {
        /** Degrees: forward lean of the whole upper body, turn toward the target, head nod (+ = down) and turn, halo spin. */
        public double lean, twist, headPitch, headYaw, haloSpin;
        /** The upper body shifts this far forward / drops this far (blocks) when it lunges. */
        public double shift, drop;
        public final ArmCmd[] arms = new ArmCmd[N_ARMS];

        public Pose() {
            for (int i = 0; i < N_ARMS; i++) arms[i] = new ArmCmd();
        }
    }

    // ------------------------------------------------------------------ solving

    private double[] R, T, acc, sy, sc, ex, ey, ez, tr, aim;
    private boolean[] aimed;

    /** Where a shoulder pivot ends up for this lean, twist and shift, without disturbing the solved pose. */
    public double[] shoulderFor(int arm, double lean, double twist, double shift, double drop) {
        double[] rs = euler(lean * 0.55, twist * 0.5, 0), rc = euler(lean * 0.45, twist * 0.5, 0);
        double[] spinePos = add(SPINE_AT, v(0, -drop, shift));
        double[] chestPos = add(spinePos, mv(rs, sub(CHEST_AT, SPINE_AT)));
        double[] rch = mm(rs, rc);
        return add(chestPos, mv(rch, sub(shoulderAbs[arm], CHEST_AT)));
    }

    public double[] restShoulder(int arm) { return shoulderAbs[arm].clone(); }

    private void place(int i) {
        int p = parent[i];
        double[] pr, pt;
        double k = 1, ky = 1;
        if (p < 0) {
            pr = new double[] {1, 0, 0, 0, 1, 0, 0, 0, 1};
            pt = new double[] {0, 0, 0};
        } else {
            pr = new double[] {R[p * 9], R[p * 9 + 1], R[p * 9 + 2], R[p * 9 + 3], R[p * 9 + 4], R[p * 9 + 5], R[p * 9 + 6], R[p * 9 + 7], R[p * 9 + 8]};
            pt = new double[] {T[p * 3], T[p * 3 + 1], T[p * 3 + 2]};
            k = acc[p];
            ky = acc[p] * sy[p];
        }
        double[] o = v(off[i * 3] * k + tr[i * 3], off[i * 3 + 1] * ky + tr[i * 3 + 1], off[i * 3 + 2] * k + tr[i * 3 + 2]);
        double[] w = add(pt, mv(pr, o));
        T[i * 3] = w[0]; T[i * 3 + 1] = w[1]; T[i * 3 + 2] = w[2];
        double[] r;
        if (aimed[i]) {
            r = new double[9];
            System.arraycopy(aim, i * 9, r, 0, 9);
        } else {
            r = mm(pr, euler(rest[i * 3] + ex[i], rest[i * 3 + 1] + ey[i], rest[i * 3 + 2] + ez[i]));
        }
        System.arraycopy(r, 0, R, i * 9, 9);
        acc[i] = k * sc[i];
    }

    /** World rotation whose -Y axis points along {@code dir} and whose +Z axis is as close to {@code zHint} as it can be. */
    static double[] aimMatrix(double[] dir, double[] zHint) {
        double[] y = mul(norm(dir), -1);
        double[] z = sub(zHint, mul(y, dot(zHint, y)));
        if (len(z) < 1.0e-6) {
            z = Math.abs(y[2]) < 0.9 ? v(0, 0, 1) : v(1, 0, 0);
            z = sub(z, mul(y, dot(z, y)));
        }
        z = norm(z);
        double[] x = cross(y, z);
        return new double[] {x[0], y[0], z[0], x[1], y[1], z[1], x[2], y[2], z[2]};
    }

    private void setAim(int bone, double[] dir, double[] zHint) {
        System.arraycopy(aimMatrix(dir, zHint), 0, aim, bone * 9, 9);
        aimed[bone] = true;
    }

    /** Pose the whole skeleton. */
    public void solve(Pose p) {
        for (int i = 0; i < nb; i++) {
            ex[i] = ey[i] = ez[i] = 0;
            tr[i * 3] = tr[i * 3 + 1] = tr[i * 3 + 2] = 0;
            sy[i] = 1;
            sc[i] = 1;
            aimed[i] = false;
        }
        if (bareHand) {
            ArmCmd c = p.arms[0];
            sc[armHand[0]] = c.scale;
            aimedHandOnly(c);
            return;
        }
        ex[spine] = p.lean * 0.55;
        ey[spine] = p.twist * 0.5;
        ex[chest] = p.lean * 0.45;
        ey[chest] = p.twist * 0.5;
        ty(spine, -p.drop);
        tz(spine, p.shift);
        ex[head] = p.headPitch;
        ey[head] = p.headYaw;
        ez[halo] = p.haloSpin;
        for (int i = 0; i < bodyBones; i++) place(i);

        for (int arm = 0; arm < N_ARMS; arm++) {
            ArmCmd c = p.arms[arm];
            int up = armUpper[arm], fo = armFore[arm], ha = armHand[arm];
            place(up); // (the upper arm's position is the shoulder; its turn is set just below, so place again afterwards)
            double[] s = v(T[up * 3], T[up * 3 + 1], T[up * 3 + 2]);
            double[] d = sub(c.wrist, s);
            double l = Math.max(1.0e-4, len(d));
            double k = Math.max(1.0, Math.min(8.0, l / ((UPPER + FORE) * 0.999)));
            double a = UPPER * k, b = FORE * k;
            if (l > a + b) l = a + b;
            double[] dn = norm(d);
            double cosS = (a * a + l * l - b * b) / (2 * a * l);
            cosS = Math.max(-1, Math.min(1, cosS));
            double proj = a * cosS, h = a * Math.sqrt(Math.max(0, 1 - cosS * cosS));
            double[] pole = sub(c.pole, mul(dn, dot(c.pole, dn)));
            if (len(pole) < 1.0e-4) pole = sub(Math.abs(dn[1]) < 0.9 ? v(0, 1, 0) : v(1, 0, 0), mul(dn, dn[1]));
            pole = norm(pole);
            double[] elbow = add(add(s, mul(dn, proj)), mul(pole, h));
            double[] upDir = norm(sub(elbow, s)), foDir = norm(sub(add(s, mul(dn, l)), elbow));
            sy[up] = k;
            sy[fo] = k;
            setAim(up, upDir, pole);
            setAim(fo, foDir, pole);
            setAim(ha, c.dir, c.palm);
            sc[ha] = c.scale;
            place(up);
            place(fo);
            place(ha);
            // fingers curl toward the palm
            int[] f = armFinger[arm];
            for (int j = 0; j < 4; j++) {
                ex[f[j]] = -c.curl * 78;
                ex[f[4 + j]] = -c.curl * 72;
            }
            int side = sideOf(arm);
            ez[f[8]] = -side * c.curl * 62;
            ex[f[8]] = -c.curl * 28;
            ex[f[9]] = -c.curl * 55;
            for (int j = 0; j < 10; j++) place(f[j]);
        }
    }

    private void aimedHandOnly(ArmCmd c) {
        int ha = armHand[0];
        tr[ha * 3] = c.wrist[0];
        tr[ha * 3 + 1] = c.wrist[1];
        tr[ha * 3 + 2] = c.wrist[2];
        setAim(ha, c.dir, c.palm);
        // the root is bone 0 at the origin; the hand hangs off it
        place(0);
        place(ha);
        int[] f = armFinger[0];
        for (int j = 0; j < 4; j++) {
            ex[f[j]] = -c.curl * 78;
            ex[f[4 + j]] = -c.curl * 72;
        }
        for (int j = 0; j < 10; j++) place(f[j]);
    }

    private void ty(int b, double y) { tr[b * 3 + 1] = y; }
    private void tz(int b, double z) { tr[b * 3 + 2] = z; }

    // ------------------------------------------------------------------ reading the solved pose

    /** Statue-frame position of a bone's pivot after {@link #solve}. */
    public double[] headPos() { return v(T[head * 3], T[head * 3 + 1], T[head * 3 + 2]); }

    /** The 8 corners of a cube, statue frame: corner index = ix + 2 * iy + 4 * iz, i = 0 for the low side of that axis. */
    public void corners(int ci, float[] out) {
        Cube c = cubes[ci];
        int b = c.bone;
        double k = acc[b], ky = c.fixed ? acc[b] : acc[b] * sy[b];
        double[] r = new double[] {R[b * 9], R[b * 9 + 1], R[b * 9 + 2], R[b * 9 + 3], R[b * 9 + 4], R[b * 9 + 5], R[b * 9 + 6], R[b * 9 + 7], R[b * 9 + 8]};
        for (int n = 0; n < 8; n++) {
            double sxn = (n & 1) == 0 ? -0.5 : 0.5, syn = (n & 2) == 0 ? -0.5 : 0.5, szn = (n & 4) == 0 ? -0.5 : 0.5;
            double[] q = v(sxn * c.sx, syn * c.sy, szn * c.sz);
            if (c.rot != null) q = mv(c.rot, q);
            q = v((q[0] + c.cx) * k, (q[1] + c.cy) * ky, (q[2] + c.cz) * k);
            double[] w = mv(r, q);
            out[n * 3] = (float) (w[0] + T[b * 3]);
            out[n * 3 + 1] = (float) (w[1] + T[b * 3 + 1]);
            out[n * 3 + 2] = (float) (w[2] + T[b * 3 + 2]);
        }
    }

    private static final double[] LIGHT = norm(v(0.3, 0.85, 0.45));

    /** Shading of the 6 faces (top, bottom, +Z, -Z, +X, -X of the cube), from where they point in the statue frame. */
    public void shades(int ci, float[] out) {
        Cube c = cubes[ci];
        int b = c.bone;
        double[] r = new double[] {R[b * 9], R[b * 9 + 1], R[b * 9 + 2], R[b * 9 + 3], R[b * 9 + 4], R[b * 9 + 5], R[b * 9 + 6], R[b * 9 + 7], R[b * 9 + 8]};
        double[][] axes = {v(0, 1, 0), v(0, -1, 0), v(0, 0, 1), v(0, 0, -1), v(1, 0, 0), v(-1, 0, 0)};
        for (int f = 0; f < 6; f++) {
            double[] n = axes[f];
            if (c.rot != null) n = mv(c.rot, n);
            n = mv(r, n);
            double s = 0.74 + 0.26 * dot(n, LIGHT);
            out[f] = (float) Math.max(0.42, Math.min(1.0, s));
        }
    }
}
