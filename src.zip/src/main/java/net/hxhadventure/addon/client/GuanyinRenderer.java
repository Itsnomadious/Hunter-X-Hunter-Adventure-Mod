package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.Guanyin;
import net.hxhadventure.addon.GuanyinTuning;
import net.hxhadventure.addon.network.PacketGuanyinFx;
import org.joml.Matrix4f;

/**
 * Draws the 100-Type Guanyin Bodhisattva and its hands: a giant golden statue behind the user, seated on a lotus, hands pressed together
 * in prayer, a halo behind its head and rings of arms fanned out around it; and the golden hands of every move. Nothing is a model or a
 * texture: everything is translucent golden boxes (each face shaded a little differently so the shapes read), like the Nen aura effects.
 *
 * <p>Local frame of everything drawn here: +Y up, +Z the way the user faces, +X the user's left.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class GuanyinRenderer {
    private GuanyinRenderer() {}

    private static final int GR = 255, GG = 196, GB = 48;   // the gold
    private static final int ARMS_PER_SIDE = 10;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        boolean anyStatue = false;
        for (net.minecraft.world.entity.Entity p : level.entitiesForRendering()) { // players and Netero (any living owner of a statue)
            if (p instanceof LivingEntity && Guanyin.clientHas(p.getId())) {
                anyStatue = true;
                break;
            }
        }
        if (!anyStatue && GuanyinFx.ACTIVE.isEmpty()) return;

        float partial = e.getPartialTick();
        double time = level.getGameTime() + partial;
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.lightning();
        VertexConsumer vc = buf.getBuffer(type);

        for (net.minecraft.world.entity.Entity p : level.entitiesForRendering()) {
            if (p instanceof LivingEntity le && Guanyin.clientHas(le.getId())) statue(ps, vc, cam, le, partial, time);
        }

        Iterator<GuanyinFx.Effect> it = GuanyinFx.ACTIVE.iterator();
        while (it.hasNext()) {
            GuanyinFx.Effect fx = it.next();
            double age = time - fx.t0;
            if (age > fx.life()) {
                it.remove();
                continue;
            }
            if (age < 0) continue;
            switch (fx.type) {
                case PacketGuanyinFx.FLASH -> flash(ps, vc, cam, fx, age);
                case PacketGuanyinFx.FIRST -> impactRing(ps, vc, cam, fx, age, fx.extra, 6.0, 10.0);
                case PacketGuanyinFx.THIRD -> impactRing(ps, vc, cam, fx, age, GuanyinTuning.THIRD_WINDUP_TICKS, 1.5, 4.0);
                case PacketGuanyinFx.ZERO -> zeroHand(ps, vc, cam, fx, age, level);
                default -> { }
            }
        }
        buf.endBatch(type);
    }

    // ------------------------------------------------------------------ the statue (a posed skeleton, see GuanyinRig / GuanyinAnimator)

    private static final GuanyinRig RIG = new GuanyinRig();
    private static final GuanyinAnimator ANIM = new GuanyinAnimator(RIG);
    private static final GuanyinRig.Pose POSE = new GuanyinRig.Pose();
    private static final GuanyinRig HAND_LEFT = GuanyinRig.handOnly(1); // the flash is a left hand: the mirror of the right
    private static final GuanyinRig.Pose HAND_POSE = new GuanyinRig.Pose();

    /** Where the statue's base is, and which way it faces (the user's body), for this frame. */
    private static Vec3 statueBase(LivingEntity p, float partial) {
        double yaw = Math.toRadians(Mth.rotLerp(partial, p.yBodyRotO, p.yBodyRot));
        Vec3 fwd = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
        return p.getPosition(partial).subtract(fwd.scale(GuanyinTuning.STATUE_BACK));
    }

    /** World offset from the statue's base -> statue frame (the statue is turned by -yaw about Y). */
    private static double[] local(double dx, double dy, double dz, double yawRad) {
        double c = Math.cos(yawRad), s = Math.sin(yawRad);
        return new double[] {dx * c + dz * s, dy, -dx * s + dz * c};
    }

    /** Zero Hand: the statue's lotus, ZERO_BEHIND blocks behind the target. The server sends the target's feet in x/y/z, the way the statue faces in dx/dz and the ground it stands on in dy. */
    private static Vec3 zeroBase(GuanyinFx.Effect fx) {
        double len = Math.hypot(fx.dx, fx.dz);
        double fx0 = len < 1.0e-6 ? 0 : fx.dx / len, fz0 = len < 1.0e-6 ? 1 : fx.dz / len;
        return new Vec3(fx.x - fx0 * GuanyinTuning.ZERO_BEHIND, fx.dy, fx.z - fz0 * GuanyinTuning.ZERO_BEHIND);
    }

    /** Zero Hand: the body yaw (degrees) that makes the statue face the way the server said (the same convention as a player's yBodyRot). */
    private static float zeroYaw(GuanyinFx.Effect fx) {
        double len = Math.hypot(fx.dx, fx.dz);
        double fx0 = len < 1.0e-6 ? 0 : fx.dx / len, fz0 = len < 1.0e-6 ? 1 : fx.dz / len;
        return (float) Math.toDegrees(Math.atan2(-fx0, fz0));
    }

    /** Owner entity id -> game time its Zero Hand ended: the statue comes back to the user's back with a short fade. */
    private static final java.util.Map<Integer, Double> ZERO_END = new java.util.HashMap<>();

    private static void statue(PoseStack ps, VertexConsumer vc, Vec3 cam, LivingEntity p, float partial, double time) {
        Vec3 base = statueBase(p, partial);
        float yaw = Mth.rotLerp(partial, p.yBodyRotO, p.yBodyRot);
        double alphaMul = 1.0;
        double fadeLen = GuanyinTuning.ZERO_FADE_TICKS;
        GuanyinFx.Effect zero = null;
        for (GuanyinFx.Effect fx : GuanyinFx.ACTIVE) {
            double age = time - fx.t0;
            if (fx.owner == p.getId() && fx.type == PacketGuanyinFx.ZERO && age >= 0 && age <= fx.life()) zero = fx;
        }
        if (zero != null) { // the statue is not at the user's back for the Zero Hand: it appears behind the target and grabs them
            base = zeroBase(zero);
            yaw = zeroYaw(zero);
            double age = time - zero.t0;
            alphaMul = Mth.clamp(age / fadeLen, 0, 1) * Mth.clamp((zero.life() - age) / fadeLen, 0, 1);
            alphaMul = alphaMul * alphaMul * (3 - 2 * alphaMul);
            ZERO_END.put(p.getId(), zero.t0 + zero.life());
        } else {
            Double end = ZERO_END.get(p.getId());
            if (end != null) {
                double t = (time - end) / fadeLen;
                if (t >= 1) ZERO_END.remove(p.getId());
                else alphaMul = Math.max(0, t * t * (3 - 2 * Math.max(0, t)));
            }
        }
        double yr = Math.toRadians(yaw);

        List<GuanyinAnimator.Move> moves = new ArrayList<>();
        for (GuanyinFx.Effect fx : GuanyinFx.ACTIVE) {
            if (fx.owner != p.getId()) continue;
            if (zero != null && fx.type != PacketGuanyinFx.ZERO) continue; // nothing else is drawn while the statue is away at the target
            double age = time - fx.t0;
            if (age < 0 || age > fx.life()) continue;
            GuanyinAnimator.Move m = new GuanyinAnimator.Move();
            m.age = fx.type == PacketGuanyinFx.PALM ? age * fx.speed() : age; // a slower / faster Guanyin plays the palm's animation slower / faster
            m.seed = (long) fx.t0;
            m.extra = fx.extra;
            double[] pos = local(fx.x - base.x, fx.y - base.y, fx.z - base.z, yr);
            double[] dir = local(fx.dx, 0, fx.dz, yr);
            m.pos = pos;
            m.dir = dir;
            switch (fx.type) {
                case PacketGuanyinFx.PALM -> {
                    m.kind = GuanyinAnimator.Kind.PALM;
                    m.pos = new double[] {pos[0], pos[1] - 1.5, pos[2]}; // the server sends the middle of the area, 1.5 up
                    m.strong = (fx.extra & 1) != 0;
                    m.left = (fx.extra & 2) != 0;
                }
                case PacketGuanyinFx.FIRST -> m.kind = GuanyinAnimator.Kind.FIRST;
                case PacketGuanyinFx.THIRD -> {
                    m.kind = GuanyinAnimator.Kind.THIRD;
                    m.windup = fx.dy > 0f ? Math.round(fx.dy) : GuanyinTuning.THIRD_WINDUP_TICKS; // the server sends its (speed-scaled) wind-up in dy
                }
                case PacketGuanyinFx.NINETY -> m.kind = GuanyinAnimator.Kind.NINETY;
                case PacketGuanyinFx.ZERO -> m.kind = GuanyinAnimator.Kind.ZERO;
                default -> { continue; }
            }
            moves.add(m);
        }
        ANIM.animate(POSE, time, moves);
        RIG.solve(POSE);

        ps.pushPose();
        ps.translate(base.x - cam.x, base.y - cam.y, base.z - cam.z);
        ps.mulPose(Axis.YP.rotationDegrees(-yaw));
        drawRig(ps.last().pose(), vc, RIG, alphaMul);
        ps.popPose();
    }

    private static final float[] CORNERS = new float[24], SHADES = new float[6];
    private static final int[][] FACE_CORNERS = {{2, 3, 7, 6}, {0, 1, 5, 4}, {4, 5, 7, 6}, {0, 1, 3, 2}, {1, 3, 7, 5}, {0, 2, 6, 4}};

    /** Draw every box of a solved rig; coordinates are in the frame {@code m} places. */
    private static void drawRig(Matrix4f m, VertexConsumer vc, GuanyinRig rig, double alphaMul) {
        for (int i = 0; i < rig.cubeCount(); i++) {
            GuanyinRig.Cube c = rig.cubes[i];
            int a = (int) (c.alpha * alphaMul);
            if (a <= 0) continue;
            rig.corners(i, CORNERS);
            rig.shades(i, SHADES);
            double bright = c.bright;
            int r = (int) Math.min(255, GR * bright), g = (int) Math.min(255, GG * bright), b = (int) Math.min(255, GB * bright + (bright > 1 ? (bright - 1) * 300 : 0));
            for (int f = 0; f < 6; f++) {
                int[] q = FACE_CORNERS[f];
                face(m, vc, CORNERS[q[0] * 3], CORNERS[q[0] * 3 + 1], CORNERS[q[0] * 3 + 2], CORNERS[q[1] * 3], CORNERS[q[1] * 3 + 1], CORNERS[q[1] * 3 + 2],
                    CORNERS[q[2] * 3], CORNERS[q[2] * 3 + 1], CORNERS[q[2] * 3 + 2], CORNERS[q[3] * 3], CORNERS[q[3] * 3 + 1], CORNERS[q[3] * 3 + 2], r, g, b, a, SHADES[f]);
            }
        }
    }

    // ------------------------------------------------------------------ the moves that are not the statue's own body

    /** Aspect of Guanyin: a flash of a golden LEFT hand (palm forward, thumb toward the user) to the user's left; the beam leaves it. */
    private static void flash(PoseStack ps, VertexConsumer vc, Vec3 cam, GuanyinFx.Effect fx, double age) {
        double life = fx.life();
        double alpha = Math.sin(Math.PI * Mth.clamp(age / life, 0, 1));
        if (alpha <= 0.01) return;
        double len = Math.hypot(fx.dx, fx.dz);
        double fx0 = len < 1e-6 ? 0 : fx.dx / len, fz0 = len < 1e-6 ? 1 : fx.dz / len;
        GuanyinRig.ArmCmd c = HAND_POSE.arms[0];
        c.set(new double[] {0, 0, 0}, new double[] {0, 1, 0}, new double[] {fx0, 0, fz0}, new double[] {0, 0, -1}, 0.0, 1.9);
        HAND_LEFT.solve(HAND_POSE);
        ps.pushPose();
        ps.translate(fx.x - cam.x, fx.y - cam.y - 1.5, fx.z - cam.z);
        drawRig(ps.last().pose(), vc, HAND_LEFT, alpha);
        ps.popPose();
    }

    /** The ring of force that spreads where a First or Third Hand lands. */
    private static void impactRing(PoseStack ps, VertexConsumer vc, Vec3 cam, GuanyinFx.Effect fx, double age, double windup, double r0, double grow) {
        if (age < windup) return;
        double rt = Mth.clamp((age - windup) / 10.0, 0, 1);
        ring(ps, vc, cam, fx.x, fx.y + 0.1, fx.z, r0 + grow * rt, (int) (190 * (1 - rt)));
    }

    /** Zero Hand: the light gathering at the statue's mouth while the hand closes (the hand itself is the statue's right arm). */
    private static void zeroHand(PoseStack ps, VertexConsumer vc, Vec3 cam, GuanyinFx.Effect fx, double age, ClientLevel level) {
        double charge = Math.max(1, fx.extra);
        double fade = age < charge + 4 ? 1.0 : Math.max(0, 1 - (age - charge - 4) / 14.0);
        LivingEntity owner = level.getEntity(fx.owner) instanceof LivingEntity pl ? pl : null;
        if (owner != null && age < charge + 6) {
            Vec3 base = zeroBase(fx); // the statue stands behind the target
            double flen = Math.hypot(fx.dx, fx.dz);
            Vec3 f = flen < 1.0e-6 ? new Vec3(0, 0, 1) : new Vec3(fx.dx / flen, 0, fx.dz / flen);
            Vec3 mouth = base.add(0, GuanyinTuning.STATUE_MOUTH_HEIGHT, 0).add(f.scale(GuanyinTuning.STATUE_MOUTH_FORWARD));
            double p = Mth.clamp(age / charge, 0, 1);
            ps.pushPose();
            ps.translate(mouth.x - cam.x, mouth.y - cam.y, mouth.z - cam.z);
            for (int k = 0; k < 3; k++) {
                ps.pushPose();
                ps.mulPose(Axis.YP.rotationDegrees((float) (age * (14 + k * 9) + k * 30)));
                ps.mulPose(Axis.XP.rotationDegrees((float) (age * 11 + k * 50)));
                double s = (0.3 + 2.4 * p) * (1 - k * 0.25);
                box(ps, vc, 0, 0, 0, s, s, s, 255, 235 - k * 30, 120 - k * 30, (int) ((120 + 60 * p) * fade));
                ps.popPose();
            }
            ps.popPose();
        }
    }

    /** A flat ring of force on the ground. */
    private static void ring(PoseStack ps, VertexConsumer vc, Vec3 cam, double x, double y, double z, double radius, int alpha) {
        if (alpha <= 0) return;
        int sides = 28;
        Matrix4f m = ps.last().pose();
        double inner = radius * 0.82;
        for (int s = 0; s < sides; s++) {
            double a0 = 2 * Math.PI * s / sides, a1 = 2 * Math.PI * (s + 1) / sides;
            float ox = (float) (x - cam.x), oy = (float) (y - cam.y), oz = (float) (z - cam.z);
            float[] p = {
                ox + (float) (Math.cos(a0) * inner), oz + (float) (Math.sin(a0) * inner),
                ox + (float) (Math.cos(a0) * radius), oz + (float) (Math.sin(a0) * radius),
                ox + (float) (Math.cos(a1) * radius), oz + (float) (Math.sin(a1) * radius),
                ox + (float) (Math.cos(a1) * inner), oz + (float) (Math.sin(a1) * inner)};
            for (int pass = 0; pass < 2; pass++) {
                for (int k = 0; k < 4; k++) {
                    int idx = pass == 0 ? k : 3 - k;
                    vc.vertex(m, p[idx * 2], oy, p[idx * 2 + 1]).color(255, 215, 90, alpha).endVertex();
                }
            }
        }
    }

    private static float yawOf(float dx, float dz) {
        return (float) (Mth.atan2(dx, dz) * (180.0 / Math.PI));
    }

    /** A box in the gold, {@code bright} scaling its colour (above 1 whitens it a little). */
    private static void gold(PoseStack ps, VertexConsumer vc, double cx, double cy, double cz, double sx, double sy, double sz, double bright, int alpha) {
        int r = (int) Math.min(255, GR * bright), g = (int) Math.min(255, GG * bright), b = (int) Math.min(255, GB * bright + (bright > 1 ? (bright - 1) * 300 : 0));
        box(ps, vc, cx, cy, cz, sx, sy, sz, r, g, b, alpha);
    }

    /** An axis-aligned box centred at (cx, cy, cz) in the current pose, every face shaded by its direction, each face drawn from both sides. */
    private static void box(PoseStack ps, VertexConsumer vc, double cx, double cy, double cz, double sx, double sy, double sz, int r, int g, int b, int a) {
        if (a <= 0) return;
        Matrix4f m = ps.last().pose();
        float x0 = (float) (cx - sx / 2), x1 = (float) (cx + sx / 2);
        float y0 = (float) (cy - sy / 2), y1 = (float) (cy + sy / 2);
        float z0 = (float) (cz - sz / 2), z1 = (float) (cz + sz / 2);
        face(m, vc, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, r, g, b, a, 1.00f); // top
        face(m, vc, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, r, g, b, a, 0.50f); // bottom
        face(m, vc, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, b, a, 0.88f); // front (+Z)
        face(m, vc, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, r, g, b, a, 0.72f); // back
        face(m, vc, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, r, g, b, a, 0.66f); // +X
        face(m, vc, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, r, g, b, a, 0.62f); // -X
    }

    private static void face(Matrix4f m, VertexConsumer vc, float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz, int r, int g, int b, int a, float shade) {
        int rr = (int) (r * shade), gg = (int) (g * shade), bb = (int) (b * shade);
        vc.vertex(m, ax, ay, az).color(rr, gg, bb, a).endVertex();
        vc.vertex(m, bx, by, bz).color(rr, gg, bb, a).endVertex();
        vc.vertex(m, cx, cy, cz).color(rr, gg, bb, a).endVertex();
        vc.vertex(m, dx, dy, dz).color(rr, gg, bb, a).endVertex();
        // and the other way round, so the face is visible whichever side the camera is on
        vc.vertex(m, dx, dy, dz).color(rr, gg, bb, a).endVertex();
        vc.vertex(m, cx, cy, cz).color(rr, gg, bb, a).endVertex();
        vc.vertex(m, bx, by, bz).color(rr, gg, bb, a).endVertex();
        vc.vertex(m, ax, ay, az).color(rr, gg, bb, a).endVertex();
    }
}
