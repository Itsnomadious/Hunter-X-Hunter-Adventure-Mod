package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.ExplosiveOrbs;
import net.hxhadventure.addon.Tuning;
import org.joml.Matrix4f;

/**
 * Draws Explosive Orbs: no model or texture, just layered translucent spheres (white-hot core, violet body, faint halo) that
 * pulse, with short crackling arcs of aura around them. Held orbs sit at the user's outstretched hands and swell with the
 * charge; thrown orbs fly straight along their launch velocity until the server says they blew up; the blast is a fast
 * expanding flash.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class OrbRenderer {
    private OrbRenderer() {}

    private static final int LAT = 12, LON = 20;
    private static final double BOOM_TICKS = 12;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || OrbFx.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        double time = level.getGameTime() + pt;
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        Matrix4f m = ps.last().pose();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.lightning();
        VertexConsumer vc = buf.getBuffer(type);

        // orbs in the user's hands
        for (Map.Entry<Integer, OrbFx.Held> en : OrbFx.HELD.entrySet()) {
            Entity owner = level.getEntity(en.getKey());
            if (owner == null) continue;
            float f = OrbFx.charge(en.getKey(), time);
            double r = Tuning.ORBS_MAX_RADIUS * ExplosiveOrbs.ease(f);
            if (r < 0.05) continue;
            float yaw = owner instanceof net.minecraft.world.entity.LivingEntity le
                ? net.minecraft.util.Mth.rotLerp(pt, le.yBodyRotO, le.yBodyRot) : owner.getYRot();
            for (int i = 0; i < 2; i++) {
                Vec3 c = ExplosiveOrbs.handCenter(owner.getPosition(pt), owner.getBbHeight(), yaw, i == 0, r);
                orb(m, vc, c.subtract(cam), r, time, en.getKey() * 7 + i, f >= 1f ? 1.15 : 1.0);
            }
        }

        // orbs in flight
        Iterator<OrbFx.Flying> fi = OrbFx.FLYING.values().iterator();
        while (fi.hasNext()) {
            OrbFx.Flying o = fi.next();
            double age = time - o.t0;
            if (age > o.life + 6) {
                fi.remove();
                continue;
            }
            Vec3 c = new Vec3(o.x + o.vx * age - cam.x, o.y + o.vy * age - cam.y, o.z + o.vz * age - cam.z);
            orb(m, vc, c, o.radius, time, (int) (o.x * 13 + o.z * 7), 1.2);
        }

        // blasts
        Iterator<OrbFx.Boom> bi = OrbFx.BOOMS.iterator();
        while (bi.hasNext()) {
            OrbFx.Boom b = bi.next();
            double t = (time - b.t0) / BOOM_TICKS;
            if (t >= 1) {
                bi.remove();
                continue;
            }
            double grow = 1 - Math.pow(1 - t, 3);
            double rad = b.radius * (0.2 + 0.85 * grow);
            Vec3 c = new Vec3(b.x - cam.x, b.y - cam.y, b.z - cam.z);
            float fade = (float) (1 - t);
            sphere(m, vc, c, rad * 0.55, 255, 240, 255, (int) (230 * fade));
            sphere(m, vc, c, rad * 0.8, 210, 120, 255, (int) (150 * fade));
            sphere(m, vc, c, rad, 150, 60, 235, (int) (90 * fade));
        }
        buf.endBatch(type);
    }

    /** One orb: core, body, halo (drawn inside-out so the translucent layers show through each other), and arcs. */
    private static void orb(Matrix4f m, VertexConsumer vc, Vec3 c, double r, double time, int seed, double glow) {
        double pulse = 1 + 0.05 * Math.sin(time * 0.6 + seed);
        r *= pulse;
        int a = (int) Math.min(255, 235 * glow);
        sphere(m, vc, c, r * 0.45, 255, 245, 255, a);
        sphere(m, vc, c, r * 0.75, 200, 110, 255, (int) (a * 0.65));
        sphere(m, vc, c, r, 140, 55, 230, (int) (a * 0.35));
        sphere(m, vc, c, r * 1.12, 120, 40, 210, (int) (a * 0.14));

        Random rnd = new Random((long) Math.floor(time * 0.5) * 7919L + seed * 104729L);
        int arcs = 4 + (int) Math.min(5, r * 3);
        for (int k = 0; k < arcs; k++) {
            Vec3 dir = new Vec3(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian()).normalize();
            Vec3 p = c.add(dir.scale(r * 0.95));
            int segs = 5;
            for (int s = 0; s < segs; s++) {
                Vec3 jitter = new Vec3(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian()).scale(r * 0.12);
                Vec3 q = p.add(dir.scale(r * 0.12)).add(jitter);
                strip(m, vc, p, q, 0.02 + 0.015 * r, 235, 200, 255, 235);
                p = q;
            }
        }
    }

    /** A UV sphere drawn from both sides (the lightning render type does not cull, but this keeps either winding visible). */
    private static void sphere(Matrix4f m, VertexConsumer vc, Vec3 c, double r, int red, int green, int blue, int alpha) {
        if (alpha <= 0) return;
        for (int i = 0; i < LAT; i++) {
            double p0 = Math.PI * i / LAT - Math.PI / 2, p1 = Math.PI * (i + 1) / LAT - Math.PI / 2;
            for (int j = 0; j < LON; j++) {
                double t0 = 2 * Math.PI * j / LON, t1 = 2 * Math.PI * (j + 1) / LON;
                Vec3 a = pt(c, r, p0, t0), b = pt(c, r, p1, t0), d = pt(c, r, p1, t1), e = pt(c, r, p0, t1);
                quad(m, vc, a, b, d, e, red, green, blue, alpha);
                quad(m, vc, e, d, b, a, red, green, blue, alpha);
            }
        }
    }

    private static Vec3 pt(Vec3 c, double r, double phi, double theta) {
        double cp = Math.cos(phi);
        return new Vec3(c.x + r * cp * Math.cos(theta), c.y + r * Math.sin(phi), c.z + r * cp * Math.sin(theta));
    }

    /** A thin crossed-quad strip between two points: a bolt segment visible from any angle. */
    private static void strip(Matrix4f m, VertexConsumer vc, Vec3 a, Vec3 b, double w, int red, int green, int blue, int alpha) {
        Vec3 d = b.subtract(a);
        if (d.lengthSqr() < 1e-8) return;
        Vec3 n = d.normalize();
        Vec3 p1 = n.cross(Math.abs(n.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0)).normalize().scale(w);
        Vec3 p2 = n.cross(p1).normalize().scale(w);
        for (Vec3 p : new Vec3[]{p1, p2}) {
            quad(m, vc, a.add(p), a.subtract(p), b.subtract(p), b.add(p), red, green, blue, alpha);
        }
    }

    private static void quad(Matrix4f m, VertexConsumer vc, Vec3 a, Vec3 b, Vec3 c, Vec3 d, int r, int g, int bl, int al) {
        v(m, vc, a, r, g, bl, al);
        v(m, vc, b, r, g, bl, al);
        v(m, vc, c, r, g, bl, al);
        v(m, vc, d, r, g, bl, al);
    }

    private static void v(Matrix4f m, VertexConsumer vc, Vec3 p, int r, int g, int b, int a) {
        vc.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, a).endVertex();
    }
}
