package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.hxhadventure.addon.GuanyinTuning;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-side record of who is praying (fed by PacketPrayFx) and the pose: both hands clasped together in front of the chest. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class PrayFx {
    private PrayFx() {}

    /** owner entity id -> {start time, length in ticks, style (0 = hands clasped, 1 = the Guanyin lotus)}. */
    private static final Map<Integer, double[]> ACTIVE = new HashMap<>();

    public static void set(int owner, int ticks, int style) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        if (ticks <= 0) {
            // ease out from where the pose is now instead of snapping
            double[] cur = ACTIVE.get(owner);
            if (cur != null) {
                double now = level.getGameTime();
                cur[1] = Math.min(cur[1], now - cur[0] + 3);
            }
            return;
        }
        if (style >= 2) { // the visual-only lotus (instant prayers at 10000): do not restart it while it is still playing, or spamming Attack would bob the user up and down
            double[] cur = ACTIVE.get(owner);
            if (cur != null && cur[2] >= 2 && level.getGameTime() - cur[0] < cur[1] - 4) return;
        }
        ACTIVE.put(owner, new double[] {level.getGameTime(), ticks, style});
    }

    public static void applyArms(PlayerModel<?> model, LivingEntity entity) {
        applyPose(model, entity);
        applyPush(model, entity);
    }

    // ---------------------------------------------------------------- the push after the prayer

    /** owner entity id -> {start time, 1 if the left hand}. */
    private static final Map<Integer, double[]> PUSH = new HashMap<>();
    private static final double PUSH_TICKS = 8.0;

    /** How long the lotus's hand motion takes (the legs are already in place): much quicker than the old whole-body sequence. */
    private static double armTicks(double length) {
        return Math.max(4.0, (length - 6.0) * 0.4);
    }

    /** The statue is striking (called for each palm): once the prayer's hand motion is over, the user pushes with one hand. */
    public static void push(int owner, boolean left) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        double t0 = mc.level.getGameTime();
        double[] a = ACTIVE.get(owner);
        if (a != null && a[2] >= 2 && t0 < a[0] + a[1]) t0 = Math.max(t0, a[0] + armTicks(a[1])); // the instant lotus: push when its hands are done
        double[] cur = PUSH.get(owner);
        if (cur != null && t0 - cur[0] < PUSH_TICKS) t0 = cur[0]; // a barrage keeps the arm out instead of restarting it
        PUSH.put(owner, new double[] {t0, left ? 1 : 0});
    }

    private static void applyPush(PlayerModel<?> model, LivingEntity entity) {
        if (PUSH.isEmpty() || !(entity instanceof AbstractClientPlayer p)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || (p == mc.player && mc.options.getCameraType().isFirstPerson())) return;
        double[] u = PUSH.get(p.getId());
        if (u == null) return;
        double age = mc.level.getGameTime() + mc.getFrameTime() - u[0];
        if (age > PUSH_TICKS) {
            PUSH.remove(p.getId());
            return;
        }
        if (age < 0) return;
        float w = (float) Mth.clamp(Math.min(age / 1.5, (PUSH_TICKS - age) / 4.0), 0, 1); // thrust out fast, draw back slower
        w = w * w * (3f - 2f * w);
        net.minecraft.client.model.geom.ModelPart arm = u[1] > 0 ? model.leftArm : model.rightArm;
        arm.xRot = Mth.lerp(w, arm.xRot, -Mth.HALF_PI);          // straight out in front, like pushing with the palm
        arm.yRot = Mth.lerp(w, arm.yRot, 0f);
        arm.zRot = Mth.lerp(w, arm.zRot, 0f);
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);
    }

    private static void applyPose(PlayerModel<?> model, LivingEntity entity) {
        if (!(entity instanceof AbstractClientPlayer p)) return;
        if (ACTIVE.isEmpty() && HELD.isEmpty() && !net.hxhadventure.addon.Guanyin.clientHas(p.getId())) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        if (p == mc.player && mc.options.getCameraType().isFirstPerson()) {
            // first person: the body drawn by renderFirstPersonBody sits in the lotus too, head hidden so it never fills the view
            double h = heldAge(p.getId(), mc.level.getGameTime() + mc.getFrameTime());
            if (h >= 0 && !handsBusy(p.getId())) {
                lotus(model, h < 20 ? h * 5.0 : 80.0 + h, 106.0, (float) Mth.clamp(h / 6.0, 0, 1), false);
                model.head.visible = false;
                model.hat.visible = false;
            }
            return;
        }
        double[] a = ACTIVE.get(p.getId());
        if (a == null) {
            double h = heldAge(p.getId(), mc.level.getGameTime() + mc.getFrameTime());
            if (h >= 0) lotus(model, h < 20 ? h * 5.0 : 80.0 + h, 106.0, (float) Mth.clamp(h / 6.0, 0, 1), false); // held: the full lotus
            return;
        }
        double age = mc.level.getGameTime() + mc.getFrameTime() - a[0];
        if (age > a[1]) {
            ACTIVE.remove(p.getId());
            return;
        }
        float w = (float) Mth.clamp(Math.min(age / 4.0, (a[1] - age) / 3.0), 0, 1);
        if (a[2] >= 1) {
            lotus(model, age, a[1], w, net.hxhadventure.addon.Guanyin.clientHas(p.getId()));
            return;
        }
        float sway = Mth.sin((float) age * 0.15f) * 0.02f; // a very slight breathing motion
        // arms raised in front of the chest and turned inward so the palms meet
        model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, -1.05f + sway);
        model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, -0.55f);
        model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, 0f);
        model.leftArm.xRot = Mth.lerp(w, model.leftArm.xRot, -1.05f + sway);
        model.leftArm.yRot = Mth.lerp(w, model.leftArm.yRot, 0.55f);
        model.leftArm.zRot = Mth.lerp(w, model.leftArm.zRot, 0f);
        model.head.xRot = Mth.lerp(w * 0.5f, model.head.xRot, 0.35f); // head bowed a little
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);
        model.hat.copyFrom(model.head);
    }

    // ---------------------------------------------------------------- first person: both hands clasped in front of you

    /**
     * First person: while you pray, the game's own hands (and whatever you hold) are replaced by two arms that rise from the bottom of the
     * screen and meet in the middle, palms together. The placement is the vanilla first-person arm transform
     * (ItemInHandRenderer.renderPlayerArm) with its numbers moved from "resting at the side" to "meeting at the centre".
     */
    @SubscribeEvent
    public static void onHand(RenderHandEvent e) {
        Minecraft mc = Minecraft.getInstance();
        AbstractClientPlayer p = mc.player;
        if (p == null || mc.level == null || p.isInvisible()) return;
        double[] a = ACTIVE.get(p.getId());
        if (a == null) return;
        double age = mc.level.getGameTime() + e.getPartialTick() - a[0];
        if (age > a[1]) return; // the prayer is over
        if (a[2] >= 2) return; // the visual-only lotus: the attack is already being thrown, so the normal hands and swing stay
        if (p.swinging && a[1] - age < 4) return; // the prayer has ended and the attack is being thrown: the default punch swing shows at once
        e.setCanceled(true); // neither hand is drawn the normal way, and the held item is put away while you pray
        if (e.getHand() != InteractionHand.MAIN_HAND) return; // both arms are drawn once, with the main hand
        EntityRenderer<?> r = mc.getEntityRenderDispatcher().getRenderer(p);
        if (!(r instanceof PlayerRenderer pr)) return;

        float w = (float) Mth.clamp(Math.min(age / 6.0, (a[1] - age) / 4.0), 0, 1); // rises in 6 ticks, lowers in 4
        w = w * w * (3f - 2f * w);                                                    // smoothstep
        float sway = Mth.sin((float) age * 0.15f) * 0.012f;                           // a very slight breathing motion
        PoseStack ps = e.getPoseStack();
        for (int side = 1; side >= -1; side -= 2) {
            float f = side;
            ps.pushPose();
            // resting values: the vanilla ones, lowered; clasped values: found so both wrists meet at the centre of the view
            ps.translate(f * lerp(w, 0.64, 0.362), lerp(w, -1.0, -0.616) + sway, lerp(w, -0.72, -0.703));
            ps.mulPose(Axis.YP.rotationDegrees(f * lerp(w, 45.0, 117.2)));
            ps.mulPose(Axis.XP.rotationDegrees(lerp(w, 0.0, 21.7)));
            ps.translate(f * -1.0F, 3.6F, 3.5F);
            ps.mulPose(Axis.ZP.rotationDegrees(f * 120.0F));
            ps.mulPose(Axis.XP.rotationDegrees(200.0F));
            ps.mulPose(Axis.YP.rotationDegrees(f * -135.0F));
            ps.translate(f * 5.6F, 0.0F, 0.0F);
            if (side == 1) pr.renderRightHand(ps, e.getMultiBufferSource(), e.getPackedLight(), p);
            else pr.renderLeftHand(ps, e.getMultiBufferSource(), e.getPackedLight(), p);
            ps.popPose();
        }
    }

    private static float lerp(double t, double a, double b) {
        return (float) (a + (b - a) * Mth.clamp(t, 0, 1));
    }

    /** 0..1 over [from, to] of the lotus sequence. */
    private static double seg(double t, double from, double to) {
        return Mth.clamp((t - from) / (to - from), 0, 1);
    }

    /**
     * The 100-Type Guanyin user's prayer. The hands come round from the sides, down and out and then up in a wide arc, and clasp in front
     * of the chest; meanwhile one leg is lifted and crossed over the other, the user rising off the ground into a lotus (see {@link #hover}).
     * Plays out over the prayer's length and then holds until it ends.
     */
    private static void lotus(PlayerModel<?> model, double age, double length, float w, boolean handsOnly) {
        double t = Mth.clamp(age / Math.max(1.0, length - 6.0), 0, 1);
        if (handsOnly) t = Mth.clamp(age / armTicks(length), 0, 1); // statue out: just the hands, and quicker
        // arms (right arm values; the left arm mirrors yRot and zRot)
        double a1 = seg(t, 0.0, 0.25), a2 = seg(t, 0.25, 0.6), a3 = seg(t, 0.6, 1.0);
        float armX, armY, armZ;
        if (t < 0.25) { // down and back, away from the body
            armX = lerp(a1, 0.0, 0.45);
            armZ = lerp(a1, 0.1, 0.7);
            armY = 0f;
        } else if (t < 0.6) { // swept up in a wide side arc
            armX = lerp(a2, 0.45, 0.0);
            armZ = lerp(a2, 0.7, 1.55);
            armY = 0f;
        } else { // brought in to clasp in front of the chest
            armX = lerp(a3, 0.0, -1.05);
            armZ = lerp(a3, 1.55, 0.0);
            armY = lerp(a3, 0.0, -0.55);
        }
        if (handsOnly) { // start from the clasped hands the user is already holding, and leave the legs and the body exactly as the held lotus has them
            float b = (float) Mth.clamp(age / 2.0, 0, 1);
            armX = Mth.lerp(b, -1.05f, armX);
            armY = Mth.lerp(b, -0.55f, armY);
            armZ = Mth.lerp(b, 0f, armZ);
            w = 1f;
        }
        model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, armX);
        model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, armY);
        model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, armZ);
        model.leftArm.xRot = Mth.lerp(w, model.leftArm.xRot, armX);
        model.leftArm.yRot = Mth.lerp(w, model.leftArm.yRot, -armY);
        model.leftArm.zRot = Mth.lerp(w, model.leftArm.zRot, -armZ);
        if (handsOnly) { // the legs are already perfect (the held lotus): only the hands move
            model.rightSleeve.copyFrom(model.rightArm);
            model.leftSleeve.copyFrom(model.leftArm);
            return;
        }
        // legs: the right leg lifts first, then the left, then they cross
        float rightLift = lerp(seg(t, 0.10, 0.40), 0.0, -1.45), leftLift = lerp(seg(t, 0.30, 0.60), 0.0, -1.45);
        float cross = lerp(seg(t, 0.45, 0.85), 0.0, 0.85);
        model.rightLeg.xRot = Mth.lerp(w, model.rightLeg.xRot, rightLift);
        model.rightLeg.yRot = Mth.lerp(w, model.rightLeg.yRot, -cross);
        model.rightLeg.zRot = Mth.lerp(w, model.rightLeg.zRot, 0f);
        model.leftLeg.xRot = Mth.lerp(w, model.leftLeg.xRot, leftLift);
        model.leftLeg.yRot = Mth.lerp(w, model.leftLeg.yRot, cross);
        model.leftLeg.zRot = Mth.lerp(w, model.leftLeg.zRot, 0f);
        float sway = Mth.sin((float) age * 0.12f) * 0.02f;
        model.head.xRot = Mth.lerp(w * 0.5f, model.head.xRot, 0.3f + sway);
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);
        model.rightPants.copyFrom(model.rightLeg);
        model.leftPants.copyFrom(model.leftLeg);
        model.hat.copyFrom(model.head);
    }

    /** True while this player's clasped-hands prayer (not the visual-only instant one) is playing. */
    private static boolean handsBusy(int owner) {
        double[] a = ACTIVE.get(owner);
        Minecraft mc = Minecraft.getInstance();
        return a != null && a[2] < 2 && mc.level != null && mc.level.getGameTime() - a[0] <= a[1];
    }

    /** owner entity id -> game time the statue appeared: while it stands its user stays in the lotus. */
    private static final Map<Integer, Double> HELD = new HashMap<>();

    /** Ticks since this player's statue appeared, or -1 if they have none. */
    private static double heldAge(int owner, double time) {
        if (!net.hxhadventure.addon.Guanyin.clientHas(owner)) {
            HELD.remove(owner);
            return -1;
        }
        return time - HELD.computeIfAbsent(owner, k -> time);
    }

    /** How far (blocks) the user is lifted: the prayer's own rise, or, with the statue out, hovering just above its base. */
    public static float hover(int owner, float partial) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return 0f;
        float prayer = prayerHover(owner, partial);
        double h = heldAge(owner, mc.level.getGameTime() + partial);
        if (h < 0) return prayer;
        double up = Mth.clamp(h / 12.0, 0, 1);
        return Math.max(prayer, (float) (GuanyinTuning.LOTUS_HEIGHT * up + 0.04 * Math.sin(h * 0.15) * up));
    }

    private static float prayerHover(int owner, float partial) {
        double[] a = ACTIVE.get(owner);
        Minecraft mc = Minecraft.getInstance();
        if (a == null || a[2] < 1 || mc.level == null) return 0f;
        if (net.hxhadventure.addon.Guanyin.clientHas(owner)) return 0f; // the statue is out: the held lotus already floats the user, the prayer only moves the hands
        double age = mc.level.getGameTime() + partial - a[0];
        if (age > a[1]) return 0f;
        double t = Mth.clamp(age / Math.max(1.0, a[1] - 6.0), 0, 1);
        double up = seg(t, 0.1, 0.6), down = Mth.clamp((a[1] - age) / 3.0, 0, 1);
        return (float) (GuanyinTuning.LOTUS_HEIGHT * up * down + 0.04 * Math.sin(age * 0.15) * up);
    }

    @SubscribeEvent
    public static void onPre(RenderPlayerEvent.Pre e) {
        float h = hover(e.getEntity().getId(), e.getPartialTick());
        if (h <= 0f) return;
        e.getPoseStack().pushPose();
        e.getPoseStack().translate(0, h, 0);
        HOVERING.add(e.getEntity().getId());
    }

    @SubscribeEvent
    public static void onPost(RenderPlayerEvent.Post e) {
        if (HOVERING.remove(e.getEntity().getId())) e.getPoseStack().popPose();
    }

    private static final java.util.Set<Integer> HOVERING = new java.util.HashSet<>();

    // ---------------------------------------------------------------- first person: float up, and see your own lotus

    private static java.lang.reflect.Method SET_POS;
    private static boolean camBroken;

    /** Raises the first-person camera to the floating user's eyes (Camera.setPosition, found by reflection; if it can't be, nothing happens). */
    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
        Minecraft mc = Minecraft.getInstance();
        if (camBroken || mc.player == null || mc.level == null || !mc.options.getCameraType().isFirstPerson()) return;
        float h = hover(mc.player.getId(), (float) e.getPartialTick());
        if (h <= 0.01f) return;
        Camera cam = e.getCamera();
        net.minecraft.world.phys.Vec3 at = cam.getPosition();
        try {
            if (SET_POS == null) {
                for (String n : new String[] {"m_90584_", "setPosition"}) {
                    try {
                        SET_POS = net.minecraftforge.fml.util.ObfuscationReflectionHelper.findMethod(Camera.class, n, double.class, double.class, double.class);
                        break;
                    } catch (RuntimeException ignored) { }
                }
                if (SET_POS == null) {
                    camBroken = true;
                    return;
                }
            }
            SET_POS.invoke(cam, at.x, at.y + h, at.z);
            if (Math.abs(cam.getPosition().y - (at.y + h)) > 1.0E-3) { // it was not the method we thought: put it back and give up
                SET_POS.invoke(cam, at.x, at.y, at.z);
                camBroken = true;
            }
        } catch (Throwable t) {
            camBroken = true;
        }
    }

    /** First person: the game never draws your own body, so draw it (head hidden) hovering in the lotus where the camera now is. */
    @SubscribeEvent
    public static void renderFirstPersonBody(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !mc.options.getCameraType().isFirstPerson()) return;
        float partial = e.getPartialTick();
        if (heldAge(mc.player.getId(), mc.level.getGameTime() + partial) < 0 || handsBusy(mc.player.getId())) return;
        net.minecraft.world.phys.Vec3 cam = e.getCamera().getPosition();
        net.minecraft.world.phys.Vec3 pos = mc.player.getPosition(partial);
        PoseStack ps = e.getPoseStack();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        var dispatcher = mc.getEntityRenderDispatcher();
        dispatcher.render(mc.player, pos.x - cam.x, pos.y - cam.y, pos.z - cam.z, Mth.lerp(partial, mc.player.yRotO, mc.player.getYRot()),
            partial, ps, buf, dispatcher.getPackedLightCoords(mc.player, partial));
        buf.endBatch();
    }

    public static void clear() {
        ACTIVE.clear();
        HELD.clear();
        PUSH.clear();
    }
}
