package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/** Client-side list of Aura Blasts being drawn (fed by PacketBlastFx), and the open-palm arm pose of whoever fired one. */
public final class BlastFx {
    private BlastFx() {}

    /** Ticks the cone takes to shoot out, and the total ticks it is visible. */
    public static final double SHOOT_TICKS = 2.5, LIFE_TICKS = 10;

    public static final class Blast {
        public final int owner;
        public final double ox, oy, oz, t0;
        public final float dx, dy, dz, length, extra;
        public final boolean golden;

        Blast(int owner, double ox, double oy, double oz, float dx, float dy, float dz, float length, float extra, boolean golden, double t0) {
            this.extra = extra;
            this.golden = golden;
            this.owner = owner;
            this.ox = ox;
            this.oy = oy;
            this.oz = oz;
            this.dx = dx;
            this.dy = dy;
            this.dz = dz;
            this.length = length;
            this.t0 = t0;
        }
    }

    public static final List<Blast> ACTIVE = new ArrayList<>();

    public static void add(int owner, double ox, double oy, double oz, float dx, float dy, float dz, float length, float extra, boolean golden) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        ACTIVE.removeIf(b -> b.owner == owner);
        ACTIVE.add(new Blast(owner, ox, oy, oz, dx, dy, dz, length, extra, golden, level.getGameTime()));
    }

    /** The right arm held straight out along the blast, palm open, easing in and out. */
    public static void applyArm(PlayerModel<?> model, LivingEntity entity) {
        if (ACTIVE.isEmpty() || !(entity instanceof AbstractClientPlayer p)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || (p == mc.player && mc.options.getCameraType().isFirstPerson())) return;
        for (Blast b : ACTIVE) {
            if (b.owner != p.getId() || b.golden) continue; // a golden beam comes from Guanyin's hand, not the user's
            double age = mc.level.getGameTime() + mc.getFrameTime() - b.t0;
            if (age < 0 || age > LIFE_TICKS) return;
            float w = (float) Mth.clamp(Math.min(age / 1.5, (LIFE_TICKS - age) / 3.0), 0, 1);
            float bodyYaw = Mth.rotLerp(mc.getFrameTime(), p.yBodyRotO, p.yBodyRot);
            float yaw = (float) (Mth.atan2(-b.dx, b.dz) * (180.0 / Math.PI));
            float pitch = (float) -Math.asin(Mth.clamp(b.dy, -1f, 1f));
            model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, -Mth.HALF_PI + pitch);
            model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, Mth.wrapDegrees(yaw - bodyYaw) * Mth.DEG_TO_RAD);
            model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, 0f);
            model.rightSleeve.copyFrom(model.rightArm);
            return;
        }
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
