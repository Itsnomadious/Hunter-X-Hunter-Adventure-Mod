package net.hxhadventure.addon.client;

import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.hxhadventure.addon.JudgmentChain;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketJudgmentAnswer;
import net.hxhadventure.entity.client.gui.HxhUi;

/**
 * The bound player's side: a Stake of Retribution is in their heart and these are the commands they must follow.
 * Accepting binds them; refusing (or giving no answer in time) kills them. It cannot be closed with Escape.
 */
public class JudgmentAcceptScreen extends Screen {
    private static final int HALF_W = 172;

    private final String caster;
    private final List<String> ids;
    private int ticksLeft;

    public JudgmentAcceptScreen(String caster, List<String> ids, int ticksLeft) {
        super(Component.literal("Stake of Retribution"));
        this.caster = caster;
        this.ids = ids;
        this.ticksLeft = ticksLeft;
    }

    private int panelH() {
        return 120 + ids.size() * 24;
    }

    private int top() {
        return Math.max(12, this.height / 2 - panelH() / 2);
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int by = top() + panelH() - 32;
        addRenderableWidget(HxhUi.button(cx - 160, by, 156, 20, "I accept", b -> answer(true), true));
        addRenderableWidget(HxhUi.button(cx + 4, by, 156, 20, "I refuse (die)", b -> answer(false), false));
    }

    private void answer(boolean accept) {
        AddonNetwork.sendToServer(new PacketJudgmentAnswer(accept));
        onClose();
    }

    @Override
    public void tick() {
        if (ticksLeft > 0) ticksLeft--;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        HxhUi.backdrop(g, this.width, this.height);
        int cx = this.width / 2;
        int top = top();
        HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, panelH() + 8);
        HxhUi.title(g, this.font, "STAKE OF RETRIBUTION", cx, top);
        HxhUi.subtitle(g, this.font, caster + " has pierced your heart", cx, top + 14);
        int y = HxhUi.wrap(g, this.font, "You are commanded:", cx - 156, top + 34, 312, HxhUi.TEXT_DIM);
        for (String id : ids) y = HxhUi.wrap(g, this.font, "- " + JudgmentChain.text(id), cx - 150, y + 4, 300, HxhUi.TEXT);
        HxhUi.wrap(g, this.font, "Refusing, or breaking a command later, means the Stake kills you. Answer within "
            + (ticksLeft / 20 + 1) + " seconds.", cx - 156, y + 10, 312, HxhUi.RED);
        super.render(g, mouseX, mouseY, partial);
    }
}
