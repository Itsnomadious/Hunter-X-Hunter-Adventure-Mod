package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;

/** Third person (and other players): the chains on the right arm, riding the arm model through every animation. */
public class ChainHandLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public ChainHandLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffer, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (!ChainHand.has(player.getId()) || player.isInvisible() || player.isSpectator() || InFx.hiddenFrom(player.getId())) return;
        pose.pushPose();
        getParentModel().rightArm.translateAndRotate(pose);
        HandChains.render(pose, buffer, light, "slim".equals(player.getModelName()), player);
        pose.popPose();
    }
}
