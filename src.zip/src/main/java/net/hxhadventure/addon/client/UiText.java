package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

/** Text that stays inside its box: wrap to a width, cut with an ellipsis, or shrink a single line to fit. */
public final class UiText {
    private UiText() {}

    /** Wraps text to the width and returns the lines, keeping at most maxLines (the last one gets an ellipsis if text was dropped). */
    public static List<FormattedCharSequence> wrapFit(Font font, String text, int width, int maxLines) {
        List<FormattedCharSequence> all = font.split(Component.literal(text), Math.max(8, width));
        if (all.size() <= maxLines) return all;
        List<FormattedCharSequence> out = new ArrayList<>(all.subList(0, maxLines));
        String last = plain(all.get(maxLines - 1));
        out.set(maxLines - 1, Component.literal(ellipsis(font, last + "...", width)).getVisualOrderText());
        return out;
    }

    private static String plain(FormattedCharSequence seq) {
        StringBuilder sb = new StringBuilder();
        seq.accept((i, style, cp) -> { sb.appendCodePoint(cp); return true; });
        return sb.toString();
    }

    /** One line cut to the width, ending in "..." when something was dropped. */
    public static String ellipsis(Font font, String text, int width) {
        if (font.width(text) <= width) return text;
        return font.plainSubstrByWidth(text, Math.max(0, width - font.width("..."))) + "...";
    }

    /** Draws a single line, shrinking it (down to 60%) to fit the width, and cutting it with an ellipsis only if still too long. */
    public static void drawFit(GuiGraphics g, Font font, String text, int x, int y, int width, int color, boolean centred) {
        int w = font.width(text);
        float scale = 1f;
        if (w > width) scale = Math.max(0.6f, width / (float) w);
        String s = scale * w > width ? ellipsis(font, text, (int) (width / scale)) : text;
        int sw = (int) (font.width(s) * scale);
        int dx = centred ? x + (width - sw) / 2 : x;
        if (scale == 1f) {
            g.drawString(font, s, dx, y, color, false);
        } else {
            g.pose().pushPose();
            g.pose().translate(dx, y + (1 - scale) * 4f, 0);
            g.pose().scale(scale, scale, 1f);
            g.drawString(font, s, 0, 0, color, false);
            g.pose().popPose();
        }
    }

    /** Draws wrapped lines inside a box and returns the y just below them. */
    public static int drawWrapped(GuiGraphics g, Font font, String text, int x, int y, int width, int lineH, int maxLines, int color) {
        for (FormattedCharSequence line : wrapFit(font, text, width, maxLines)) {
            g.drawString(font, line, x, y, color, false);
            y += lineH;
        }
        return y;
    }

    /** Number of lines the text takes at the width (capped). */
    public static int lines(Font font, String text, int width, int maxLines) {
        return wrapFit(font, text, width, maxLines).size();
    }

    /** A paragraph in a stacked text block: gap above it, colour, and the words. */
    public record Para(String text, int color, int gapBefore) {}

    /** Draws paragraphs one under another, wrapped to the width. If they would be taller than maxH the whole block is scaled down to fit. Returns the height used. */
    public static int drawBlock(GuiGraphics g, Font font, List<Para> paras, int x, int y, int width, int maxH) {
        float scale = 1f;
        for (int pass = 0; pass < 3; pass++) {
            int innerW = (int) (width / scale);
            int h = 0;
            for (Para p : paras) h += p.gapBefore() + font.split(Component.literal(p.text()), innerW).size() * 10;
            float need = h * scale;
            if (need <= maxH || scale <= 0.6f) break;
            scale = Math.max(0.6f, scale * maxH / need);
        }
        int innerW = (int) (width / scale);
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1f);
        int yy = 0;
        for (Para p : paras) {
            yy += p.gapBefore();
            for (FormattedCharSequence line : font.split(Component.literal(p.text()), innerW)) {
                g.drawString(font, line, 0, yy, p.color(), false);
                yy += 10;
            }
        }
        g.pose().popPose();
        return (int) (yy * scale);
    }
}
