package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.hxhadventure.addon.ClientAddonState;

/**
 * En visualisation: entities the server reports are given the vanilla glow outline locally (only the En user sees it),
 * coloured by category through client-side scoreboard teams.
 * 0 passive = green, 1 hostile = red, 2 regular player = aqua, 3 Nen user / construct = light purple.
 * Entities that are targets of one of your active quest Defeat objectives glow gold instead.
 */
public final class EnGlowHandler {
    private static final String PREFIX = "hxh_en_";
    private static final ChatFormatting[] COLORS = {
        ChatFormatting.GREEN, ChatFormatting.RED, ChatFormatting.AQUA, ChatFormatting.LIGHT_PURPLE
    };
    private static final String QUEST_TEAM = PREFIX + "quest";
    private static final int TTL = 30;
    private static final Map<Integer, Tracked> TRACKED = new HashMap<>();

    private static final class Tracked {
        int category;
        int ttl = TTL;
        boolean hadGlow;
        String prevTeam;
        boolean fresh = true;
    }

    private EnGlowHandler() {}

    /**
     * Entity#setSharedFlag(int, boolean) is protected. Entity#setGlowingTag does NOT work on the client in 1.20.1:
     * it re-reads the glow flag from the (unchanged) synched data, so the outline never appears. Flag 6 is "glowing".
     */
    private static final java.lang.reflect.Method SET_FLAG = findSetFlag();

    private static java.lang.reflect.Method findSetFlag() {
        try {
            return net.minecraftforge.fml.util.ObfuscationReflectionHelper.findMethod(Entity.class, "m_20115_", int.class, boolean.class);
        } catch (Throwable first) {
            try {
                java.lang.reflect.Method m = Entity.class.getDeclaredMethod("setSharedFlag", int.class, boolean.class);
                m.setAccessible(true);
                return m;
            } catch (Throwable second) {
                return null;
            }
        }
    }

    private static void setGlow(Entity e, boolean on) {
        if (SET_FLAG != null) {
            try {
                SET_FLAG.invoke(e, 6, on);
                return;
            } catch (Throwable ignored) {
                // fall through to the vanilla call
            }
        }
        e.setGlowingTag(on);
    }

    public static void onPulse(int[] ids, byte[] cats) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        Set<Integer> present = new HashSet<>();
        for (int i = 0; i < ids.length; i++) {
            Entity e = level.getEntity(ids[i]);
            if (!(e instanceof LivingEntity)) continue;
            present.add(ids[i]);
            Tracked t = TRACKED.get(ids[i]);
            if (t == null) {
                t = new Tracked();
                TRACKED.put(ids[i], t);
            }
            t.category = Math.max(0, Math.min(COLORS.length - 1, cats[i]));
            t.ttl = TTL;
            apply(e, t);
        }
        Iterator<Map.Entry<Integer, Tracked>> it = TRACKED.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Tracked> en = it.next();
            if (!present.contains(en.getKey())) {
                release(level, en.getKey(), en.getValue());
                it.remove();
            }
        }
    }

    public static void tick(Minecraft mc) {
        if (TRACKED.isEmpty()) return;
        ClientLevel level = mc.level;
        if (level == null || !ClientAddonState.en) {
            clearAll();
            return;
        }
        Iterator<Map.Entry<Integer, Tracked>> it = TRACKED.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Tracked> en = it.next();
            Tracked t = en.getValue();
            Entity e = level.getEntity(en.getKey());
            if (e == null || --t.ttl <= 0) {
                release(level, en.getKey(), t);
                it.remove();
            } else if (!e.isCurrentlyGlowing()) {
                setGlow(e, true);
            }
        }
    }

    /** True if this entity is a target of an unfinished Defeat objective of one of the player's active quests. */
    private static boolean isQuestTarget(Entity e) {
        if (ClientQuests.active().isEmpty()) return false;
        net.minecraft.resources.ResourceLocation key = net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        return key != null && ClientQuests.isKillTarget(key.toString());
    }

    public static void clearAll() {
        if (TRACKED.isEmpty()) return;
        ClientLevel level = Minecraft.getInstance().level;
        if (level != null) {
            for (Map.Entry<Integer, Tracked> en : TRACKED.entrySet()) release(level, en.getKey(), en.getValue());
        }
        TRACKED.clear();
    }

    private static void apply(Entity e, Tracked t) {
        Scoreboard sb = e.level().getScoreboard();
        String name = e.getScoreboardName();
        if (t.fresh) {
            t.fresh = false;
            t.hadGlow = e.isCurrentlyGlowing();
            PlayerTeam cur = sb.getPlayersTeam(name);
            t.prevTeam = cur != null && !cur.getName().startsWith(PREFIX) ? cur.getName() : null;
        }
        boolean quest = isQuestTarget(e);
        String teamName = quest ? QUEST_TEAM : PREFIX + t.category;
        PlayerTeam team = sb.getPlayerTeam(teamName);
        if (team == null) {
            team = sb.addPlayerTeam(teamName);
            team.setColor(quest ? ChatFormatting.GOLD : COLORS[t.category]);
        }
        PlayerTeam cur = sb.getPlayersTeam(name);
        if (cur != team) sb.addPlayerToTeam(name, team);
        setGlow(e, true);
    }

    private static void release(ClientLevel level, int id, Tracked t) {
        Entity e = level.getEntity(id);
        if (e == null) return;
        Scoreboard sb = level.getScoreboard();
        String name = e.getScoreboardName();
        PlayerTeam cur = sb.getPlayersTeam(name);
        if (cur != null && cur.getName().startsWith(PREFIX)) sb.removePlayerFromTeam(name, cur);
        if (t.prevTeam != null) {
            PlayerTeam prev = sb.getPlayerTeam(t.prevTeam);
            if (prev != null) sb.addPlayerToTeam(name, prev);
        }
        if (!t.hadGlow) setGlow(e, false);
    }
}
