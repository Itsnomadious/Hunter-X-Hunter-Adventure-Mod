package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.TickEvent;
import net.hxhadventure.addon.GonVow;
import net.hxhadventure.addon.HxHSounds;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.Jajanken;

/** Client-side record of every Jajanken move (Rock / Scissors) in view (fed by PacketRockFx), keyed by the player's entity id. */
public final class JajankenFx {
    private JajankenFx() {}

    public static final int CHARGING = 1, PUNCH = 2, SLASH = 3, FIRE = 4, IMPACT = 5;
    /** How long the punch pose and burst are shown, in ticks. */
    public static final double PUNCH_TICKS = 10;
    /** How long the Scissors slash pose and arc are shown. */
    public static final double SLASH_TICKS = 5;   // was 12: the slash sweeps more than twice as fast
    /** How long the Paper throwing pose is held. */
    public static final double FIRE_TICKS = 12;

    /** A Paper ball in flight: where it started, which way it flies, and how big it is. Its position is worked out from the age. */
    public static final class Shot {
        public final double x, y, z, dx, dy, dz, t0, radius;

        Shot(double x, double y, double z, double dx, double dy, double dz, double t0, double radius) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.dx = dx;
            this.dy = dy;
            this.dz = dz;
            this.t0 = t0;
            this.radius = radius;
        }
    }

    private static final Map<Integer, Shot> SHOTS = new HashMap<>();
    /** Bursts of Paper balls: {x, y, z, start time}. */
    private static final java.util.List<double[]> BURSTS = new java.util.ArrayList<>();

    public static Map<Integer, Shot> shots() {
        return SHOTS;
    }

    public static java.util.List<double[]> bursts() {
        return BURSTS;
    }

    public static final class Rec {
        public final int owner;
        public int mode;
        /** 0 = Rock, 1 = Scissors. */
        public int move;
        public double t0, punchAt = -1;
        public double px, py, pz;
        /** Scissors slash: how far the dash went and the yaw (degrees) it went in; (px, py, pz) is where it started. */
        public double dist;
        public float yaw;
        /** Gon's adult form: this Rock is the cycling orb. */
        public boolean vow;
        /** How far charged (0..1) the Rock was when it was thrown: the strike starts from that wind-up. */
        public double charge = 1.0;
        /** The last orb cycle whose sound was started, and the sound that is playing (so a release can cut it off). */
        public int lastCycle = -1;
        public SoundInstance snd;

        Rec(int owner, double t0) {
            this.owner = owner;
            this.t0 = t0;
        }
    }

    private static final Map<Integer, Rec> ACTIVE = new HashMap<>();

    public static Map<Integer, Rec> all() {
        return ACTIVE;
    }

    public static boolean isEmpty() {
        return ACTIVE.isEmpty() && SHOTS.isEmpty() && BURSTS.isEmpty();
    }

    public static void set(int owner, int mode, int move, double x, double y, double z, double a, float b, float c) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        double now = level.getGameTime();
        Rec r = ACTIVE.get(owner);
        if (mode == CHARGING) {
            // x = how many ticks ago the press was; the Ko charge (and the aura converging on the fist) starts once the flare is over
            if (r != null) stopSound(r);
            Rec fresh = new Rec(owner, now - x + Jajanken.ROCK_FLARE_TICKS);
            fresh.mode = CHARGING;
            fresh.move = move;
            fresh.vow = move == Jajanken.ROCK && GonVow.clientHas(owner);
            ACTIVE.put(owner, fresh);
        } else if (mode == FIRE) {
            // the throwing pose, and the ball itself (it flies on its own from here until the burst packet)
            if (r == null) {
                r = new Rec(owner, now);
                ACTIVE.put(owner, r);
            }
            if (r.mode == CHARGING) r.charge = chargeFraction(r, now);
            stopSound(r);
            r.mode = FIRE;
            r.move = move;
            r.punchAt = now;
            double yr = Math.toRadians(b), pr = Math.toRadians(c);
            double radius = Jajanken.PAPER_RADIUS_MIN + (Jajanken.PAPER_RADIUS_MAX - Jajanken.PAPER_RADIUS_MIN) * Mth.clamp(a, 0, 1);
            SHOTS.put(owner, new Shot(x, y, z, -Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr), now, radius));
        } else if (mode == IMPACT) {
            SHOTS.remove(owner);
            BURSTS.add(new double[] {x, y, z, now});
        } else if (mode == SLASH) {
            if (r == null) {
                r = new Rec(owner, now);
                ACTIVE.put(owner, r);
            }
            if (r.mode == CHARGING) r.charge = chargeFraction(r, now);
            stopSound(r);
            r.mode = SLASH;
            r.move = move;
            r.punchAt = now;
            r.px = x;
            r.py = y;
            r.pz = z;
            r.dist = a;
            r.yaw = b;
        } else if (mode == PUNCH) {
            if (r == null) {
                r = new Rec(owner, now);
                ACTIVE.put(owner, r);
            } else if (r.mode == CHARGING) {
                r.charge = chargeFraction(r, now); // the strike starts from the wind-up the charge had reached
            }
            stopSound(r);
            r.move = move;
            r.mode = PUNCH;
            r.punchAt = now;
            r.px = x;
            r.py = y;
            r.pz = z;
            r.dist = a > 0 ? a : 1; // the blast's size relative to a normal Rock (20 in Gon's adult form)
        } else {
            if (r != null) stopSound(r);
            ACTIVE.remove(owner);
        }
    }

    private static void stopSound(Rec r) {
        if (r != null && r.snd != null) {
            Minecraft.getInstance().getSoundManager().stop(r.snd);
            r.snd = null;
        }
    }

    /** The local player is charging the vow's Rock: they may not move at all. */
    public static boolean localVowCharging() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || ACTIVE.isEmpty()) return false;
        Rec r = ACTIVE.get(mc.player.getId());
        return r != null && r.mode == CHARGING && r.vow;
    }

    public static boolean localCharging() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || ACTIVE.isEmpty()) return false;
        Rec r = ACTIVE.get(mc.player.getId());
        return r != null && r.mode == CHARGING;
    }

    /** 0..1: how far along the charge is (1 = the aura is a tight ball). */
    public static double chargeFraction(Rec r, double time) {
        return Mth.clamp((time - r.t0) / Jajanken.ROCK_CHARGE_TICKS, 0.0, 1.0);
    }

    /**
     * 0..1: how far the aura has contracted into the fist. A straight line over {@link Jajanken#AURA_CONTRACT_TICKS}, the original
     * Jajanken's timing (the burst at full size is the start, 0; it keeps drawing in for as long as the charge is held).
     */
    public static double auraFraction(Rec r, double time) {
        return Mth.clamp((time - r.t0) / Jajanken.AURA_CONTRACT_TICKS, 0.0, 1.0);
    }

    // ---- the crouch's geometry, shared by the pose and by where the ball / blade is drawn (model pixels; 16 px = 1 block) ----
    private static final float FOOT_Y = 24.2f;         // where vanilla's own crouch puts the feet, so they stay on the ground
    private static final float BACK = 3.0f;            // everything is shifted back a little so the weight sits over the feet


    /** Where the joined hands are in the charge pose (Scissors / Paper). */
    public static Vec3 handPos(LivingEntity p, float pt, double charge) {
        return handPos(p, pt, charge, Jajanken.SCISSORS);
    }

    /**
     * Where the aura is held in the charge pose: the right fist, drawn back by the hip, with the left hand over it (the same for every move).
     */
    public static Vec3 handPos(LivingEntity p, float pt, double charge, int move) {
        // every move uses Rock's wind-up now, so the aura is always held at the right fist (the left hand is over it)
        return rockFist(p, pt, (float) Mth.clamp(charge, 0, 1));
    }

    /** The way the body faces, flat on the ground (unit length). */
    public static Vec3 facing(LivingEntity p, float pt) {
        double rad = Math.toRadians(Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot));
        return new Vec3(-Math.sin(rad), 0, Math.cos(rad));
    }

    /**
     * The charge pose, done on the model parts (called from PlayerModelMixin after the game has posed the player; the crouch
     * itself is forced in the movement input below). A deep, forward-leaning squat: the torso tips forward over bent legs
     * (thighs forward, hips pushed back, a wide stance) and both hands are held low in front, the left hand over the right.
     * It settles in over a few ticks and sinks a little deeper and starts to tremble as the charge builds.
     * On the punch the right arm drives straight forward.
     */
    public static void applyArm(PlayerModel<?> model, LivingEntity entity) {
        if (ACTIVE.isEmpty() || !(entity instanceof AbstractClientPlayer p)) return;
        Rec r = ACTIVE.get(p.getId());
        if (r == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || (p == mc.player && mc.options.getCameraType().isFirstPerson())) return;
        double now = mc.level.getGameTime() + mc.getFrameTime();
        if (r.mode == CHARGING) {
            chargePose(model, r, now);
        } else if (r.mode == SLASH) {
            double age = now - r.punchAt;
            if (age < 0 || age > SLASH_TICKS) return;
            strikePose(model, r, age, SLASH_TICKS);
        } else if (r.mode == FIRE) {
            double age = now - r.punchAt;
            if (age < 0 || age > FIRE_TICKS) return;
            strikePose(model, r, age, FIRE_TICKS);
        } else if (r.mode == PUNCH) {
            double age = now - r.punchAt;
            if (age < 0 || age > PUNCH_TICKS) return;
            // the strike: out of the wind-up the charge had reached, the torso unwinds and the fist whips out in about 2 ticks (fast, then
            // it lands), holds, then lets go over the last 4 ticks
            strikePose(model, r, age, PUNCH_TICKS);
        } else {
            return;
        }
        syncOverlays(model);
    }

    // ---- Rock: a charged-up punch ----
    // A wide, low stance (left foot forward, right foot back), the torso wound round so the right shoulder is pulled away from the target,
    // the right fist drawn all the way back by the hip and the left hand reaching out to aim. The wind-up deepens and the fist is pulled
    // further back as the charge builds; on release the torso unwinds the other way and the right arm whips out straight at the target.

    /** Every number of Rock's pose at charge {@code f} (0..1) and strike {@code s} (0 = wound up, 1 = fist out). Model pixels and radians. */
    private static final class RockPose {
        float lean, thigh, twist, back, hipY, hipZ, bodyY, shoulderY;
        float rx, rz, lx, lz;                    // shoulder positions
        float rArmX, rArmY, rArmZ, lArmX, lArmY; // arm angles
    }

    private static RockPose rockPose(float f, float s) {
        RockPose p = new RockPose();
        p.lean = Mth.lerp(s, 0.42f + 0.14f * f, 0.58f);          // torso pitch forward (rad)
        p.thigh = Mth.lerp(s, 0.66f + 0.10f * f, 0.82f);         // legs spread this far either side of straight down: deeper as it charges
        p.twist = Mth.lerp(s, 0.85f, -0.5f);                     // torso yaw: + = right side back (wound up), - = right side forward (the strike)
        p.back = 1f - 12f * Mth.sin(p.lean);                     // the hips sit over the middle of the stance
        p.hipY = FOOT_Y - 12f * Mth.cos(p.thigh);                // both feet stay on the ground
        p.hipZ = 12f * Mth.sin(p.lean) + p.back;
        p.bodyY = p.hipY - 12f * Mth.cos(p.lean);
        p.shoulderY = p.bodyY + 2f * Mth.cos(p.lean);
        float sz = p.back + 2f * Mth.sin(p.lean);
        p.rx = -5f * Mth.cos(p.twist);                           // vanilla's own swing formula: the twist carries the shoulders round
        p.rz = sz + 5f * Mth.sin(p.twist);
        p.lx = 5f * Mth.cos(p.twist);
        p.lz = sz - 5f * Mth.sin(p.twist);
        p.rArmX = Mth.lerp(s, -0.45f + 0.25f * f, -1.62f);       // + = swung back behind the body, -1.57 = straight out in front (wound up: well forward of the hip)
        p.rArmY = Mth.lerp(s, -0.6f, -0.10f);                    // drawn in towards the middle so the left hand can cover it
        p.rArmZ = Mth.lerp(s, 0.10f, 0f);
        // the left hand is laid over the right fist: aim the left arm at a point just above and in front of it (vanilla's arm direction
        // for angles x, y is (sin x sin y, cos x, sin x cos y); model z is negative in front)
        float aimX, aimY;
        if (s == 0f) {
            float arm = 10.5f;
            float fx = p.rx + arm * Mth.sin(p.rArmX) * Mth.sin(p.rArmY);
            float fy = arm * Mth.cos(p.rArmX);
            float fz = p.rz + arm * Mth.sin(p.rArmX) * Mth.cos(p.rArmY);
            float vx = fx - p.lx, vy = fy - 1.5f, vz = fz - 1.0f - p.lz;
            float h = Mth.sqrt(vx * vx + vz * vz), len = Mth.sqrt(h * h + vy * vy);
            aimX = -(float) Math.acos(Mth.clamp(vy / len, -1f, 1f));
            aimY = h < 1e-3f ? 0f : (float) Math.atan2(-vx, -vz);
        } else {
            RockPose wound = rockPose(f, 0f);
            aimX = wound.lArmX;
            aimY = wound.lArmY;
        }
        p.lArmX = Mth.lerp(s, aimX, 0.55f);                      // over the right fist, then snapped back to the hip
        p.lArmY = Mth.lerp(s, aimY, 0f);
        return p;
    }

    /** Puts the model into a Rock pose, blended in by {@code w} (0 = the game's own pose, 1 = all Rock). */
    private static void applyRock(PlayerModel<?> model, float w, RockPose p, float shake) {
        model.body.xRot = Mth.lerp(w, model.body.xRot, p.lean);
        model.body.yRot = Mth.lerp(w, model.body.yRot, p.twist + shake);
        model.body.zRot = Mth.lerp(w, model.body.zRot, 0f);
        model.body.y = Mth.lerp(w, model.body.y, p.bodyY);
        model.body.z = Mth.lerp(w, model.body.z, p.back);
        model.head.y = Mth.lerp(w, model.head.y, p.bodyY + 1f);
        model.head.z = Mth.lerp(w, model.head.z, p.back);

        model.rightLeg.xRot = Mth.lerp(w, model.rightLeg.xRot, p.thigh);   // right foot back,
        model.leftLeg.xRot = Mth.lerp(w, model.leftLeg.xRot, -p.thigh);    // left foot forward
        model.rightLeg.yRot = Mth.lerp(w, model.rightLeg.yRot, 0f);
        model.leftLeg.yRot = Mth.lerp(w, model.leftLeg.yRot, 0f);
        model.rightLeg.zRot = Mth.lerp(w, model.rightLeg.zRot, 0f);
        model.leftLeg.zRot = Mth.lerp(w, model.leftLeg.zRot, 0f);
        model.rightLeg.x = Mth.lerp(w, model.rightLeg.x, -3.4f);
        model.leftLeg.x = Mth.lerp(w, model.leftLeg.x, 3.4f);
        model.rightLeg.y = Mth.lerp(w, model.rightLeg.y, p.hipY);
        model.leftLeg.y = Mth.lerp(w, model.leftLeg.y, p.hipY);
        model.rightLeg.z = Mth.lerp(w, model.rightLeg.z, p.hipZ);
        model.leftLeg.z = Mth.lerp(w, model.leftLeg.z, p.hipZ);

        model.rightArm.x = Mth.lerp(w, model.rightArm.x, p.rx);
        model.rightArm.y = Mth.lerp(w, model.rightArm.y, p.shoulderY);
        model.rightArm.z = Mth.lerp(w, model.rightArm.z, p.rz);
        model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, p.rArmX + shake);
        model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, p.rArmY);
        model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, p.rArmZ);
        model.leftArm.x = Mth.lerp(w, model.leftArm.x, p.lx);
        model.leftArm.y = Mth.lerp(w, model.leftArm.y, p.shoulderY);
        model.leftArm.z = Mth.lerp(w, model.leftArm.z, p.lz);
        model.leftArm.xRot = Mth.lerp(w, model.leftArm.xRot, p.lArmX - shake);
        model.leftArm.yRot = Mth.lerp(w, model.leftArm.yRot, p.lArmY);
        model.leftArm.zRot = Mth.lerp(w, model.leftArm.zRot, 0f);
    }

    /** The right fist in the wind-up, in the world: back by the hip, where Rock's aura is held. */
    private static Vec3 rockFist(LivingEntity e, float pt, float f) {
        RockPose p = rockPose(f, 0f);
        float arm = 10.5f; // from the shoulder to the middle of the fist
        float fx = p.rx + arm * Mth.sin(p.rArmX) * Mth.sin(p.rArmY);
        float fy = p.shoulderY + arm * Mth.cos(p.rArmX);
        float fz = p.rz + arm * Mth.sin(p.rArmX) * Mth.cos(p.rArmY);
        double grow = GonVowClient.scale(e, pt);
        double up = grow * (FOOT_Y - fy) / 16.0;           // above the feet
        double fwd = grow * -fz / 16.0;                    // in front of the body's centre (negative = behind it)
        double right = grow * -fx / 16.0;                  // to the player's right (model -x is the right-hand side)
        Vec3 face = facing(e, pt);
        double x = Mth.lerp(pt, e.xo, e.getX()), y = Mth.lerp(pt, e.yo, e.getY()), z = Mth.lerp(pt, e.zo, e.getZ());
        return new Vec3(x + face.x * fwd - face.z * right, y + up, z + face.z * fwd + face.x * right);
    }

    /** The way the right arm points in the charge pose, in the world (unit length): from the shoulder out through the fist. */
    public static Vec3 handDir(LivingEntity e, float pt, double charge) {
        RockPose p = rockPose((float) Mth.clamp(charge, 0, 1), 0f);
        // vanilla's arm direction for angles x, y is (sin x sin y, cos x, sin x cos y) in model space (-x = right, +y = down, -z = front)
        float mx = Mth.sin(p.rArmX) * Mth.sin(p.rArmY), my = Mth.cos(p.rArmX), mz = Mth.sin(p.rArmX) * Mth.cos(p.rArmY);
        double right = -mx, fwd = -mz, up = -my;
        Vec3 face = facing(e, pt);
        return new Vec3(face.x * fwd - face.z * right, up, face.z * fwd + face.x * right).normalize();
    }

    private static void chargePose(PlayerModel<?> model, Rec r, double now) {
        // settle in over 8 ticks from the press (the flare), smoothly
        float in = (float) Mth.clamp((now - (r.t0 - Jajanken.ROCK_FLARE_TICKS)) / 8.0, 0, 1);
        float w = in * in * (3 - 2 * in);
        float f = (float) chargeFraction(r, now);
        // every move (Rock, Scissors, Paper) uses the charged-up Rock wind-up
        applyRock(model, w, rockPose(f, 0f), (float) Math.sin(now * 2.3) * 0.03f * f); // trembles as the charge builds
    }

    /** The strike out of the wind-up the charge had reached (used by Rock's punch, and by Scissors' slash and Paper's throw too). */
    private static void strikePose(PlayerModel<?> model, Rec r, double age, double duration) {
        float snap = (float) Mth.clamp(age / 2.5, 0, 1);
        float s = 1f - (1f - snap) * (1f - snap) * (1f - snap);
        float w = (float) Mth.clamp((duration - age) / 4.0, 0, 1);
        applyRock(model, w, rockPose((float) Mth.clamp(r.charge, 0, 1), s), 0f);
    }

    /**
     * (No longer used: Scissors now uses Rock's strike.) Scissors' slash: the right arm held out flat sweeps across the body from the right to the left (the blade), the left arm
     * trails back, and the legs are in a running stride. Eases in fast, holds, then relaxes.
     */
    private static void slashPose(PlayerModel<?> model, double age) {
        float p = (float) Mth.clamp(age / SLASH_TICKS, 0, 1);
        float w = (float) Mth.clamp(Math.min(age / 1.0, (SLASH_TICKS - age) / 4.0), 0, 1);
        float sweep = 1.0f - (1.0f - Mth.clamp(p / 0.55f, 0f, 1f)) * (1.0f - Mth.clamp(p / 0.55f, 0f, 1f)); // ease-out over the first half
        model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, -Mth.HALF_PI);
        model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, Mth.lerp(sweep, 0.95f, -1.0f));
        model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, 0f);
        model.leftArm.xRot = Mth.lerp(w, model.leftArm.xRot, 0.6f);
        model.leftArm.zRot = Mth.lerp(w, model.leftArm.zRot, -0.35f);
        model.rightLeg.xRot = Mth.lerp(w, model.rightLeg.xRot, -0.7f);
        model.leftLeg.xRot = Mth.lerp(w, model.leftLeg.xRot, 0.7f);
    }

    /**
     * (No longer used: Paper now uses Rock's strike.) Paper's throw, like the reference art: the right arm straight out in front with the palm open, the left forearm
     * brought across to brace it. Snaps out fast, holds, then relaxes.
     */
    private static void firePose(PlayerModel<?> model, double age) {
        float w = (float) Mth.clamp(Math.min(age / 1.0, (FIRE_TICKS - age) / 4.0), 0, 1);
        model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, -Mth.HALF_PI);
        model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, -0.1f);
        model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, 0f);
        model.leftArm.xRot = Mth.lerp(w, model.leftArm.xRot, -1.45f);
        model.leftArm.yRot = Mth.lerp(w, model.leftArm.yRot, 0.85f);
        model.leftArm.zRot = Mth.lerp(w, model.leftArm.zRot, 0f);
    }

    /** The mixin runs after the game has copied each part onto its overlay layer, so the layers are copied again here. */
    private static void syncOverlays(PlayerModel<?> model) {
        model.hat.copyFrom(model.head);
        model.jacket.copyFrom(model.body);
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);
        model.rightPants.copyFrom(model.rightLeg);
        model.leftPants.copyFrom(model.leftLeg);
    }

    public static void clear() {
        for (Rec r : ACTIVE.values()) stopSound(r);
        ACTIVE.clear();
        SHOTS.clear();
        BURSTS.clear();
    }

    /** Self-registering client hooks, so no existing client event class needs editing. */
    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class JajankenClientHooks {
        private JajankenClientHooks() {}

        /** The crouch is only drawn on the model now: the player is no longer held in a sneak, so charging does not slow their walking. */
        @SubscribeEvent
        public static void onInput(MovementInputUpdateEvent e) {
            if (!localCharging()) return;
            e.getInput().jumping = false;
            if (localVowCharging()) { // Gon's adult form: rooted to the spot, no walking at all
                e.getInput().forwardImpulse = 0f;
                e.getInput().leftImpulse = 0f;
                e.getInput().up = false;
                e.getInput().down = false;
                e.getInput().left = false;
                e.getInput().right = false;
            }
        }

        /** Each orb cycle starts the sound clip again: the orb's size is read from the same clip, so they stay together. */
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END || ACTIVE.isEmpty()) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) return;
            long now = mc.level.getGameTime();
            for (Rec r : ACTIVE.values()) {
                if (!r.vow || r.mode != CHARGING || now < r.t0) continue;
                int cycle = (int) Math.floor((now - r.t0) / (double) GonVow.CYCLE_PERIOD_TICKS); // the clip restarts after each pulse and its 1 s rest
                if (cycle <= r.lastCycle) continue;
                r.lastCycle = cycle;
                Entity owner = mc.level.getEntity(r.owner);
                if (owner == null) continue;
                stopSound(r);
                r.snd = new SimpleSoundInstance(HxHSounds.GON_VOW_ORB.get(), SoundSource.PLAYERS, 2.0f, 1.0f,
                    RandomSource.create(), owner.getX(), owner.getY() + 1.0, owner.getZ());
                mc.getSoundManager().play(r.snd);
            }
        }

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
            clear();
        }
    }
}
