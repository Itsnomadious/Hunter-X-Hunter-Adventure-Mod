package net.hxhadventure.addon.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.minecraft.client.Minecraft;

/**
 * Where the HUD panel sits. Stored as a fraction (0-1) of the free screen area so it stays put when the window or
 * GUI scale changes. Saved to config/hxhadventure_hud.properties.
 */
public final class HudLayout {
    private HudLayout() {}

    public static final int MARGIN = 4;
    /** 0 = left edge, 1 = right edge / top edge, bottom edge. Defaults to the left side, mid-height (the Nen bar owns the bottom left). */
    public static final float DEFAULT_FX = 0f, DEFAULT_FY = 0.5f;
    public static float fx = DEFAULT_FX;
    public static float fy = DEFAULT_FY;
    /** Panel size multiplier (0.5-2.0) and overall opacity (0-1, 1 = normal look, 0 = invisible). */
    public static final float DEFAULT_SCALE = 1f, DEFAULT_OPACITY = 1f;
    public static float scale = DEFAULT_SCALE;
    public static float opacity = DEFAULT_OPACITY;
    private static boolean loaded;

    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config").resolve("hxhadventure_hud.properties");
    }

    public static void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        Path f = file();
        if (!Files.exists(f)) return;
        try (InputStream in = Files.newInputStream(f)) {
            Properties pr = new Properties();
            pr.load(in);
            fx = clamp01(Float.parseFloat(pr.getProperty("x", "0")));
            fy = clamp01(Float.parseFloat(pr.getProperty("y", Float.toString(DEFAULT_FY))));
            scale = Math.max(0.5f, Math.min(2f, Float.parseFloat(pr.getProperty("scale", "1"))));
            opacity = clamp01(Float.parseFloat(pr.getProperty("hudalpha", Float.toString(DEFAULT_OPACITY))));
        } catch (IOException | NumberFormatException ignored) {
        }
    }

    public static void save() {
        Path f = file();
        try {
            Files.createDirectories(f.getParent());
            Properties pr = new Properties();
            pr.setProperty("x", Float.toString(fx));
            pr.setProperty("y", Float.toString(fy));
            pr.setProperty("scale", Float.toString(scale));
            pr.setProperty("hudalpha", Float.toString(opacity));
            try (OutputStream out = Files.newOutputStream(f)) {
                pr.store(out, "HxHAdventure HUD panel position");
            }
        } catch (IOException ignored) {
        }
    }

    public static void reset() {
        fx = DEFAULT_FX;
        fy = DEFAULT_FY;
        scale = DEFAULT_SCALE;
        opacity = DEFAULT_OPACITY;
        save();
    }

    public static float scale() { ensureLoaded(); return scale; }
    public static float opacity() { ensureLoaded(); return opacity; }

    public static int x(int screenW, int w) {
        ensureLoaded();
        return MARGIN + Math.round(fx * Math.max(0, screenW - w - 2 * MARGIN));
    }

    public static int y(int screenH, int h) {
        ensureLoaded();
        return MARGIN + Math.round(fy * Math.max(0, screenH - h - 2 * MARGIN));
    }

    /** Move the panel so its top-left corner is at (px, py), kept fully on screen. */
    public static void setPos(int px, int py, int screenW, int screenH, int w, int h) {
        fx = clamp01((px - MARGIN) / (float) Math.max(1, screenW - w - 2 * MARGIN));
        fy = clamp01((py - MARGIN) / (float) Math.max(1, screenH - h - 2 * MARGIN));
    }

    private static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }
}
