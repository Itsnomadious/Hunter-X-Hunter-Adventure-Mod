package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.addon.DragonHeadEntity;
import net.hxhadventure.addon.Tuning;
import org.joml.Matrix4f;

/**
 * Draws Zeno's dragon: a glowing golden tube (violet core, orange body, bright gold shell) laid along the path the head has
 * flown, rippled by a travelling wave so it slithers whether it is flying or hovering, with an Eastern-dragon head (skull,
 * snout, jaw, eyes, swept-back horns, long whiskers) and a row of spines down its back. It grows out of the ground beam when
 * summoned. Like the aura effects there is no model or texture: everything is additive translucent geometry.
 */
public class DragonHeadRenderer extends EntityRenderer<DragonHeadEntity> {
    private static final double STEP = 0.5;
    private static final int SIDES = 10;
    /** Head size multiplier: the head grows with the body's thickness so it never looks smaller than the neck. */
    private static final double HEAD_SCALE = Tuning.DRAGON_THICKNESS;
    // Body layers, inside out. The shells are kept faint so the violet core shows through them: the render type adds
    // colours together, so strong shells wash the core out to pink. Raise a shell alpha for a more golden body, lower it
    // for a more violet one.
    private static final int CORE_ALPHA = 200, ORANGE_ALPHA = 38, GOLD_ALPHA = 30;
    private static final double CORE_SCALE = 0.55;
    private static final ResourceLocation UNUSED = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/nen_chain.png");

    public DragonHeadRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public ResourceLocation getTextureLocation(DragonHeadEntity entity) {
        return UNUSED;
    }

    /** The hitbox is only the head, but the body is 20 blocks long: never cull it while it is anywhere near. */
    @Override
    public boolean shouldRender(DragonHeadEntity e, Frustum frustum, double x, double y, double z) {
        return true;
    }

    private static double clamp01(double v) {
        return Math.max(0, Math.min(1, v));
    }

    private static double ease(double v) {
        v = clamp01(v);
        return v * v * (3 - 2 * v);
    }

    @Override
    public void render(DragonHeadEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        Vec3 pos = e.getPosition(pt);                       // the pose stack is already translated to here
        Vec3 headW = pos.add(0, DragonHeadEntity.CENTRE_HEIGHT, 0);
        double time = e.tickCount + pt;

        // Dragon Dive: coil into concentric rings (ringT), then burst apart and fade (disT)
        int dt = e.diveTicks();
        boolean diving = dt >= 0;
        double ringT = diving ? clamp01((dt + pt) / Tuning.DIVE_RING_TICKS) : 0;
        double disT = diving ? clamp01((dt + pt - Tuning.DIVE_RING_TICKS) / Tuning.DIVE_DISSIPATE_TICKS) : 0;
        double coil = ease(ringT);
        double fade = 1 - disT;
        if (fade <= 0.01) return;

        double grow = Math.min(1.0, time / 40.0);
        double visible = diving ? Tuning.DRAGON_LENGTH : Tuning.DRAGON_LENGTH * (1 - Math.pow(1 - grow, 3)); // it pours out of the beam over 2 seconds
        int n = Math.max(2, (int) (visible / STEP) + 1);

        Vec3[] raw = e.resample(headW, STEP, n);
        Vec3[] p = new Vec3[n], side = new Vec3[n], up = new Vec3[n];
        double[] rad = new double[n];
        double speedFrac = Math.min(1.0, e.speed() / Tuning.DRAGON_SPEED);
        double amp = 0.95 - 0.45 * speedFrac;               // bigger coils when idle, a tighter ripple at speed
        for (int i = 0; i < n; i++) {
            Vec3 a = raw[Math.max(0, i - 1)], b = raw[Math.min(n - 1, i + 1)];
            Vec3 t = a.subtract(b);
            t = t.lengthSqr() < 1e-8 ? new Vec3(0, 0, 1) : t.normalize();
            Vec3 sd = t.cross(new Vec3(0, 1, 0));
            sd = sd.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : sd.normalize();
            Vec3 u = sd.cross(t).normalize();
            double s = i * STEP;
            double env = Math.min(1.0, s / 3.0) * (0.35 + 0.65 * Math.min(1.0, visible / 8.0));
            double ph = 0.5 * s - 0.28 * time;
            p[i] = raw[i].add(sd.scale(amp * env * Math.sin(ph))).add(u.scale(amp * 0.45 * env * Math.cos(ph)));
            rad[i] = DragonHeadEntity.bodyRadius(s) * (1 + 0.35 * disT);
        }
        if (coil > 0) { // wind the body into a flat spiral around where the head was
            Vec3[] spiral = spiral(headW, n, time);
            for (int i = 0; i < n; i++) p[i] = p[i].lerp(spiral[i], coil);
        }
        for (int i = 0; i < n; i++) { // tube orientation follows the final path
            Vec3 a = p[Math.max(0, i - 1)], b = p[Math.min(n - 1, i + 1)];
            Vec3 t = a.subtract(b);
            t = t.lengthSqr() < 1e-8 ? new Vec3(0, 0, 1) : t.normalize();
            Vec3 sd = t.cross(new Vec3(0, 1, 0));
            sd = sd.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : sd.normalize();
            side[i] = sd;
            up[i] = sd.cross(t).normalize();
        }

        Matrix4f m = ps.last().pose();
        VertexConsumer vc = buf.getBuffer(RenderType.lightning());
        // body, inside out: violet core, orange body, golden shell
        tube(m, vc, pos, p, side, up, rad, CORE_SCALE, 10, 0, 255, (int) (CORE_ALPHA * fade));
        tube(m, vc, pos, p, side, up, rad, 0.82, 255, 150, 30, (int) (ORANGE_ALPHA * fade));
        tube(m, vc, pos, p, side, up, rad, 1.0, 255, 205, 60, (int) (GOLD_ALPHA * fade));

        // spines down the back, swept toward the tail
        if (coil < 0.9) {
            for (int i = 3; i < n - 2; i += 2) {
                Vec3 base = p[i].add(up[i].scale(rad[i] * 0.85));
                Vec3 tip = base.add(up[i].scale(0.35 + rad[i] * 0.7)).add(p[i + 1].subtract(p[i]).scale(0.9));
                strip(m, vc, pos, base, tip, 0.05 + rad[i] * 0.08, 255, 225, 110, (int) (210 * fade * (1 - coil)));
            }
        }

        double hs = 1 - coil;                                // the head melts into the ring
        if (hs > 0.05) head(m, vc, pos, e.getViewVector(pt), headW, time, HEAD_SCALE * hs, fade);

        if (diving) rings(m, vc, pos, headW, time, ease((ringT - 0.3) / 0.7), disT);
    }

    /** A flat spiral of the body's arc length, head at the centre, turn spacing a little over the body's neck width. */
    private static Vec3[] spiral(Vec3 c, int n, double time) {
        Vec3[] out = new Vec3[n];
        final double k = SPIRAL_GAP / (2 * Math.PI);
        double th = 0, spin = time * 0.12;
        for (int i = 0; i < n; i++) {
            double r = SPIRAL_R0 + k * th;
            out[i] = c.add(Math.cos(th + spin) * r, 0, Math.sin(th + spin) * r);
            th += STEP / Math.sqrt(r * r + k * k);
        }
        return out;
    }

    private static final double SPIRAL_GAP = 2.4, SPIRAL_R0 = 1.8;

    /** The concentric rings the dragon turns into: flat golden tori with a violet core, spaced like the spiral's turns. */
    private void rings(Matrix4f m, VertexConsumer vc, Vec3 pos, Vec3 c, double time, double appear, double disT) {
        if (appear < 0.01) return;
        final int N = 56;
        double burst = 1 + 1.6 * ease(disT);
        double alpha = appear * (1 - disT);
        for (int j = 0; j < 4; j++) {
            double R = (SPIRAL_R0 + SPIRAL_GAP * j) * appear * burst * (1 + 0.025 * Math.sin(time * 0.5 + j));
            double tubeR = (0.28 + 0.06 * (3 - j)) * (1 + 0.3 * disT);
            Vec3[] p = new Vec3[N + 1], side = new Vec3[N + 1], up = new Vec3[N + 1];
            double[] rad = new double[N + 1];
            for (int i = 0; i <= N; i++) {
                double th = 2 * Math.PI * i / N;
                double cs = Math.cos(th), sn = Math.sin(th);
                p[i] = c.add(cs * R, 0, sn * R);
                side[i] = new Vec3(cs, 0, sn);
                up[i] = new Vec3(0, 1, 0);
                rad[i] = tubeR;
            }
            tube(m, vc, pos, p, side, up, rad, CORE_SCALE, 10, 0, 255, (int) (CORE_ALPHA * alpha));
            tube(m, vc, pos, p, side, up, rad, 1.0, 255, 205, 60, (int) (70 * alpha));
        }
        // a bright disc of light at the heart of the rings
        double glow = appear * (1 - disT);
        ellipsoid(m, vc, pos, c, new Vec3(1, 0, 0), new Vec3(0, 0, 1), new Vec3(0, 1, 0), 1.1 * glow, 1.1 * glow, 0.5 * glow, 255, 230, 140, (int) (110 * glow));
    }

    /** The head: skull, snout and jaw as ellipsoids, glowing eyes, two swept-back horns and two long wavy whiskers. All sizes scale with k. */
    private void head(Matrix4f m, VertexConsumer vc, Vec3 pos, Vec3 fwd, Vec3 h, double time, double k, double fade) {
        Vec3 right = fwd.cross(new Vec3(0, 1, 0));
        right = right.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : right.normalize();
        Vec3 up = right.cross(fwd).normalize();
        int f1 = (int) (255 * fade);

        ellipsoid(m, vc, pos, h.add(fwd.scale(0.15 * k)), fwd, right, up, 1.0 * k, 0.78 * k, 0.72 * k, 255, 205, 60, (int) (70 * fade));
        ellipsoid(m, vc, pos, h.add(fwd.scale(0.15 * k)), fwd, right, up, 0.8 * k, 0.58 * k, 0.54 * k, 10, 0, 255, (int) (200 * fade)); // the violet core, clearly visible in the skull
        ellipsoid(m, vc, pos, h.add(fwd.scale(1.3 * k)).add(up.scale(-0.1 * k)), fwd, right, up, 0.9 * k, 0.5 * k, 0.38 * k, 255, 215, 80, (int) (135 * fade));   // snout
        ellipsoid(m, vc, pos, h.add(fwd.scale(1.1 * k)).add(up.scale(-0.5 * k)), fwd, right, up, 0.8 * k, 0.36 * k, 0.17 * k, 255, 190, 50, (int) (125 * fade));  // lower jaw
        for (double sgn : new double[]{-1, 1}) {
            Vec3 eye = h.add(fwd.scale(0.6 * k)).add(right.scale(sgn * 0.5 * k)).add(up.scale(0.28 * k));
            ellipsoid(m, vc, pos, eye, fwd, right, up, 0.16 * k, 0.16 * k, 0.16 * k, 255, 255, 235, f1);
            // horns sweep back and up
            Vec3 hb = h.add(fwd.scale(-0.05 * k)).add(right.scale(sgn * 0.4 * k)).add(up.scale(0.6 * k));
            Vec3 hm = hb.add(fwd.scale(-0.7 * k)).add(right.scale(sgn * 0.25 * k)).add(up.scale(0.55 * k));
            Vec3 ht = hm.add(fwd.scale(-0.8 * k)).add(right.scale(sgn * 0.2 * k)).add(up.scale(0.15 * k));
            strip(m, vc, pos, hb, hm, 0.1 * k, 255, 235, 150, (int) (235 * fade));
            strip(m, vc, pos, hm, ht, 0.06 * k, 255, 245, 190, (int) (235 * fade));
            // whiskers trail from the snout, rippling
            Vec3 prev = h.add(fwd.scale(1.8 * k)).add(right.scale(sgn * 0.35 * k)).add(up.scale(-0.15 * k));
            for (int j = 1; j <= 10; j++) {
                double wv = Math.sin(time * 0.3 + j * 0.7) * 0.05 * j;
                Vec3 q = h.add(fwd.scale((1.8 - 0.55 * j) * k)).add(right.scale((sgn * (0.35 + 0.16 * j) + wv) * k)).add(up.scale((-0.15 - 0.05 * j + Math.cos(time * 0.27 + j * 0.6) * 0.04 * j) * k));
                strip(m, vc, pos, prev, q, 0.035 * k, 255, 235, 160, (int) (220 * fade));
                prev = q;
            }
        }
    }

    // ---------------- geometry helpers (all coordinates world, drawn relative to the entity's pose-stack origin) ----------------
    private static void tube(Matrix4f m, VertexConsumer vc, Vec3 o, Vec3[] p, Vec3[] side, Vec3[] up, double[] rad, double scale,
                             int r, int g, int b, int a) {
        Vec3[] prev = null;
        for (int i = 0; i < p.length; i++) {
            Vec3[] ring = new Vec3[SIDES];
            double rr = rad[i] * scale;
            for (int s = 0; s < SIDES; s++) {
                double th = 2 * Math.PI * s / SIDES;
                ring[s] = p[i].add(side[i].scale(Math.cos(th) * rr)).add(up[i].scale(Math.sin(th) * rr));
            }
            if (prev != null) {
                for (int s = 0; s < SIDES; s++) {
                    int nx = (s + 1) % SIDES;
                    quad(m, vc, o, prev[s], ring[s], ring[nx], prev[nx], r, g, b, a);
                    quad(m, vc, o, prev[nx], ring[nx], ring[s], prev[s], r, g, b, a);
                }
            }
            prev = ring;
        }
    }

    private static void ellipsoid(Matrix4f m, VertexConsumer vc, Vec3 o, Vec3 c, Vec3 fwd, Vec3 right, Vec3 up,
                                  double a, double b, double cc, int r, int g, int bl, int al) {
        final int lat = 8, lon = 12;
        for (int i = 0; i < lat; i++) {
            double p0 = Math.PI * i / lat - Math.PI / 2, p1 = Math.PI * (i + 1) / lat - Math.PI / 2;
            for (int j = 0; j < lon; j++) {
                double t0 = 2 * Math.PI * j / lon, t1 = 2 * Math.PI * (j + 1) / lon;
                Vec3 v00 = ell(c, fwd, right, up, a, b, cc, p0, t0), v10 = ell(c, fwd, right, up, a, b, cc, p1, t0);
                Vec3 v11 = ell(c, fwd, right, up, a, b, cc, p1, t1), v01 = ell(c, fwd, right, up, a, b, cc, p0, t1);
                quad(m, vc, o, v00, v10, v11, v01, r, g, bl, al);
                quad(m, vc, o, v01, v11, v10, v00, r, g, bl, al);
            }
        }
    }

    private static Vec3 ell(Vec3 c, Vec3 fwd, Vec3 right, Vec3 up, double a, double b, double cc, double phi, double th) {
        double cp = Math.cos(phi);
        return c.add(fwd.scale(a * cp * Math.cos(th))).add(right.scale(b * cp * Math.sin(th))).add(up.scale(cc * Math.sin(phi)));
    }

    /** A thin crossed-quad strip between two points: a spine, horn or whisker visible from any angle. */
    private static void strip(Matrix4f m, VertexConsumer vc, Vec3 o, Vec3 a, Vec3 b, double w, int r, int g, int bl, int al) {
        Vec3 d = b.subtract(a);
        if (d.lengthSqr() < 1e-8) return;
        Vec3 n = d.normalize();
        Vec3 p1 = n.cross(Math.abs(n.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0)).normalize().scale(w);
        Vec3 p2 = n.cross(p1).normalize().scale(w);
        for (Vec3 p : new Vec3[]{p1, p2}) quad(m, vc, o, a.add(p), a.subtract(p), b.subtract(p), b.add(p), r, g, bl, al);
    }

    private static void quad(Matrix4f m, VertexConsumer vc, Vec3 o, Vec3 a, Vec3 b, Vec3 c, Vec3 d, int r, int g, int bl, int al) {
        for (Vec3 p : new Vec3[]{a, b, c, d}) {
            vc.vertex(m, (float) (p.x - o.x), (float) (p.y - o.y), (float) (p.z - o.z)).color(r, g, bl, al).endVertex();
        }
    }
}
