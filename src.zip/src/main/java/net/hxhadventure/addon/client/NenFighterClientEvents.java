package net.hxhadventure.addon.client;

import net.hxhadventure.addon.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registers the Nen-fighter NPC renderers (mod event bus, client only). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class NenFighterClientEvents {
    private NenFighterClientEvents() {}

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(HxHEntities.NETERO.get(), c -> new NenFighterRenderer<NeteroEntity>(c, NeteroEntity.STATS));
        e.registerEntityRenderer(HxHEntities.ZENO.get(), c -> new NenFighterRenderer<ZenoEntity>(c, ZenoEntity.STATS));
        e.registerEntityRenderer(HxHEntities.SILVA.get(), c -> new NenFighterRenderer<SilvaEntity>(c, SilvaEntity.STATS));
        e.registerEntityRenderer(HxHEntities.BISKY.get(), c -> new NenFighterRenderer<BiskyEntity>(c, BiskyEntity.STATS));
        e.registerEntityRenderer(HxHEntities.ILLUMI.get(), c -> new NenFighterRenderer<IllumiEntity>(c, IllumiEntity.STATS));
        e.registerEntityRenderer(HxHEntities.KURAPIKA.get(), c -> new NenFighterRenderer<KurapikaEntity>(c, KurapikaEntity.STATS));
        e.registerEntityRenderer(HxHEntities.KILLUA.get(), c -> new NenFighterRenderer<KilluaEntity>(c, KilluaEntity.STATS));
    }
}
