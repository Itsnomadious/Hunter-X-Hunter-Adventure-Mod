package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.hxhadventure.addon.HakowareTuning;
import net.hxhadventure.addon.IrsEntity;

/** Draws I.R.S.: the {@link IrsModel} at slime size. */
public class IrsRenderer extends EntityRenderer<IrsEntity> {
    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/irs.png");
    private final IrsModel model;

    public IrsRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.model = new IrsModel(ctx.bakeLayer(IrsModel.LAYER));
        this.shadowRadius = 0f;
    }

    @Override
    public ResourceLocation getTextureLocation(IrsEntity e) {
        return TEX;
    }

    @Override
    public void render(IrsEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float s = HakowareTuning.IRS_HEIGHT / IrsModel.MODEL_HEIGHT;
        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180f - Mth.rotLerp(pt, e.yRotO, e.getYRot())));
        ps.scale(-s, -s, s);
        ps.translate(0f, -1.501f, 0f);
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEX));
        model.render(ps, vc, light, OverlayTexture.NO_OVERLAY, e.tickCount + pt);
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }
}
