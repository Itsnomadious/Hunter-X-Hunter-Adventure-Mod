package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

/**
 * Kurapika's chains as worn: four finger bands, a chain from each band over the back of the hand to the wrist,
 * then two thin strands winding up the forearm. Drawn in the right arm's own space (pixel units, +Y toward the
 * fingertips, the outside of the arm at -X), so it follows every arm animation, in first and third person alike.
 * Link size is tiny on purpose (about 0.9px) so it reads like the anime's fine chain.
 */
public final class HandChains {
    private HandChains() {}

    private static final ResourceLocation STEEL = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/nen_chain.png");
    /** The link model is 4px long; this makes it about 0.9px. */
    private static final float LINK_SCALE = 0.22f;
    /** Distance between link centres in px: a bit under one link length, so neighbours interlock. */
    private static final float LINK_STEP = 0.6f;
    /** Clearance above the skin and sleeve layer, px. */
    private static final float OUT = 0.55f;

    // finger columns across the hand (front to back) and how far down each band sits
    private static final float[] FINGER_Z = {-1.5f, -0.5f, 0.5f, 1.5f};
    private static final float[] FINGER_Y = {8.9f, 8.3f, 8.2f, 8.8f};
    private static final float WRIST_Y = 5.6f;
    private static final float ARM_TOP_WRAP_Y = 0.8f;

    /** The render type the finger bands and chains are drawn with (so a caller drawing them by hand can end that batch). */
    static RenderType renderType() {
        return RenderType.entityCutoutNoCull(STEEL);
    }

    /** Call with the pose stack already moved into the right arm's space (ModelPart.translateAndRotate). */
    public static void render(PoseStack ps, MultiBufferSource buf, int light, boolean slim, Player owner) {
        ChainModel.Parts parts = ChainModel.parts(Minecraft.getInstance());
        mul = 1f; cr = cg = cb = ca = 1f; withPlates = true;
        draw(ps, buf.getBuffer(RenderType.entityCutoutNoCull(STEEL)), parts, light, slim);
        // covered in the wearer's Ten: the links again, bigger, glowing and translucent
        int ten = AuraColours.rgb(owner);
        withPlates = false;
        cr = (ten >> 16 & 255) / 255f; cg = (ten >> 8 & 255) / 255f; cb = (ten & 255) / 255f;
        VertexConsumer glow = buf.getBuffer(RenderType.entityTranslucentEmissive(AURA));
        mul = 1.7f; ca = 0.04f;
        draw(ps, glow, parts, light, slim);
        mul = 2.6f; ca = 0.017f;
        draw(ps, glow, parts, light, slim);
        mul = 1f; cr = cg = cb = ca = 1f; withPlates = true;
    }

    /** Style of the pass being drawn (the game renders on one thread): link size multiplier, tint, and whether the finger bands are included. */
    private static float mul = 1f, cr = 1f, cg = 1f, cb = 1f, ca = 1f;
    private static boolean withPlates = true;
    private static final ResourceLocation AURA = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/nen_aura_white.png");

    private static void draw(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, int light, boolean slim) {

        float xMin = slim ? -2f : -3f, xMax = 1f;
        float cx = (xMin + xMax) / 2f;
        float hx = (xMax - xMin) / 2f + OUT; // half width of the wrapped shape
        float hz = 2f + OUT;
        float back = xMin - OUT;             // the back of the hand
        float inner = xMax + OUT;

        // finger bands
        for (int k = 0; k < FINGER_Z.length; k++) {
            float y = FINGER_Y[k], z = FINGER_Z[k];
            if (!withPlates) break;
            plate(ps, vc, parts, back, y, z, 0.5f, 0.9f, 0.9f, light);
            plate(ps, vc, parts, inner, y, z, 0.5f, 0.9f, 0.9f, light);
            if (k == 0) plate(ps, vc, parts, cx, y, z - 0.5f - OUT / 2f, xMax - xMin + 2 * OUT, 0.9f, 0.5f, light);
            if (k == FINGER_Z.length - 1) plate(ps, vc, parts, cx, y, z + 0.5f + OUT / 2f, xMax - xMin + 2 * OUT, 0.9f, 0.5f, light);
        }

        // one chain per band, over the back of the hand, gathering at the wrist
        for (int k = 0; k < FINGER_Z.length; k++) {
            List<float[]> path = new ArrayList<>();
            path.add(new float[]{back, FINGER_Y[k] - 0.6f, FINGER_Z[k]});
            path.add(new float[]{back, (FINGER_Y[k] + WRIST_Y) / 2f, FINGER_Z[k] * 0.55f});
            path.add(new float[]{back, WRIST_Y, FINGER_Z[k] * 0.12f});
            walk(ps, vc, parts, path, light);
        }

        // two strands winding up the forearm in opposite directions
        walk(ps, vc, parts, helix(cx, hx, hz, WRIST_Y, ARM_TOP_WRAP_Y, (float) Math.PI, 1.25f), light);
        walk(ps, vc, parts, helix(cx, hx, hz, WRIST_Y - 0.2f, ARM_TOP_WRAP_Y + 1.6f, (float) Math.PI, -1.25f), light);
    }

    /** A rounded-rectangle spiral hugging the arm, starting on the back of the hand. */
    private static List<float[]> helix(float cx, float hx, float hz, float y0, float y1, float phase, float turns) {
        List<float[]> pts = new ArrayList<>();
        int n = 64;
        for (int i = 0; i <= n; i++) {
            float t = i / (float) n;
            double a = phase + t * turns * Math.PI * 2;
            double c = Math.cos(a), s = Math.sin(a);
            float x = cx + hx * (float) (Math.signum(c) * Math.pow(Math.abs(c), 0.45));
            float z = hz * (float) (Math.signum(s) * Math.pow(Math.abs(s), 0.45));
            pts.add(new float[]{x, y0 + (y1 - y0) * t, z});
        }
        return pts;
    }

    /** Lays interlocking links at even spacing along a polyline. */
    private static void walk(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, List<float[]> pts, int light) {
        boolean flat = true;
        double carry = 0;
        for (int i = 0; i + 1 < pts.size(); i++) {
            float[] a = pts.get(i), b = pts.get(i + 1);
            double dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
            double seg = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (seg < 1e-6) continue;
            double ux = dx / seg, uy = dy / seg, uz = dz / seg;
            double t = carry;
            while (t < seg) {
                link(ps, vc, parts, a[0] + ux * t, a[1] + uy * t, a[2] + uz * t, ux, uy, uz, flat, light);
                flat = !flat;
                t += LINK_STEP;
            }
            carry = t - seg;
        }
    }

    private static void link(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, double x, double y, double z,
                             double dx, double dy, double dz, boolean flat, int light) {
        ChainDraw.piece(ps, vc, flat ? parts.flat() : parts.vertical(), x / 16.0, y / 16.0, z / 16.0, dx, dy, dz, LINK_SCALE * mul, light, cr, cg, cb, ca);
    }

    /** A thin steel plate: the unit cube stretched to (sx, sy, sz) px, centred at (x, y, z) px. */
    private static void plate(PoseStack ps, VertexConsumer vc, ChainModel.Parts parts, float x, float y, float z,
                              float sx, float sy, float sz, int light) {
        ps.pushPose();
        ps.translate(x / 16.0, y / 16.0, z / 16.0);
        ps.scale(sx, sy, sz);
        parts.unit().render(ps, vc, light, OverlayTexture.NO_OVERLAY);
        ps.popPose();
    }
}
