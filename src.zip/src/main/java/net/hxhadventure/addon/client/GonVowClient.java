package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.GonVow;

/**
 * Client side of Gon's adult form ({@link GonVow}): the visible growth. The hitbox and eye height are changed by an EntityEvent.Size hook
 * (so the camera is right); this draws the model that much bigger, easing in and out over about half a second.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class GonVowClient {
    private GonVowClient() {}

    /** Per entity id: {previous tick's scale, this tick's scale}. Only players that are, or are still shrinking back from, the form. */
    private static final Map<Integer, float[]> SCALE = new HashMap<>();
    private static final Set<Integer> PUSHED = new HashSet<>();
    private static final float GROW_PER_TICK = 0.05f;

    /** PacketVowFx: a player entered or left the form. */
    public static void set(int owner, boolean on) {
        GonVow.setClient(owner, on);
        SCALE.computeIfAbsent(owner, k -> new float[] {1f, 1f});
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity e = mc.level.getEntity(owner);
        if (e instanceof Player p) p.refreshDimensions();
    }

    /** The scale this entity is drawn at (1 for everyone not in the form). */
    public static float scale(Entity e, float partialTick) {
        if (e == null) return 1f;
        float[] s = SCALE.get(e.getId());
        return s == null ? 1f : Mth.lerp(partialTick, s[0], s[1]);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || SCALE.isEmpty()) return;
        Iterator<Map.Entry<Integer, float[]>> it = SCALE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, float[]> en = it.next();
            float target = GonVow.clientHas(en.getKey()) ? GonVow.HEIGHT_MULT : 1f;
            float[] s = en.getValue();
            s[0] = s[1];
            s[1] = s[1] < target ? Math.min(target, s[1] + GROW_PER_TICK) : Math.max(target, s[1] - GROW_PER_TICK);
            if (s[0] == 1f && s[1] == 1f && target == 1f) it.remove();
        }
    }

    @SubscribeEvent
    public static void onPre(RenderPlayerEvent.Pre e) {
        float s = scale(e.getEntity(), e.getPartialTick());
        if (s == 1f) return;
        e.getPoseStack().pushPose();
        e.getPoseStack().scale(s, s, s); // the pose stack is at the player's feet here, so this grows them upwards
        PUSHED.add(e.getEntity().getId());
    }

    @SubscribeEvent
    public static void onPost(RenderPlayerEvent.Post e) {
        if (PUSHED.remove(e.getEntity().getId())) e.getPoseStack().popPose();
    }

    /** Ten times the movement speed would stretch the field of view to nonsense: keep it near a normal sprint. */
    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent e) {
        if (GonVow.isActive(e.getPlayer())) e.setNewFovModifier(Math.min(e.getNewFovModifier(), 1.25f));
    }

    @SubscribeEvent
    public static void onClone(ClientPlayerNetworkEvent.Clone e) {
        e.getNewPlayer().refreshDimensions();
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        GonVow.clearClient();
        SCALE.clear();
        PUSHED.clear();
    }
}
