package net.hxhadventure.addon.client;

import static net.hxhadventure.addon.client.GuanyinRig.UPPER;
import static net.hxhadventure.addon.client.GuanyinRig.FORE;
import static net.hxhadventure.addon.client.GuanyinRig.MAIN_LEFT;
import static net.hxhadventure.addon.client.GuanyinRig.MAIN_RIGHT;
import static net.hxhadventure.addon.client.GuanyinRig.add;
import static net.hxhadventure.addon.client.GuanyinRig.len;
import static net.hxhadventure.addon.client.GuanyinRig.mul;
import static net.hxhadventure.addon.client.GuanyinRig.sub;
import static net.hxhadventure.addon.client.GuanyinRig.v;

import java.util.Comparator;
import java.util.List;

/**
 * Poses the Guanyin for the moves being drawn. Plain maths (no Minecraft), everything in the statue frame: +Y up, +Z the way the statue
 * faces, +X its left, origin on the ground at the centre of the lotus. Every move is a function of its age in ticks.
 *
 * <ul>
 *   <li><b>Palm</b> (Attack / Strong / Barrage): the statue leans in and one main arm slaps across the area in front of the user; the
 *       hands alternate, left hand sweeping left-to-right, right hand right-to-left. Held down (a barrage), both main arms and the lower
 *       fan arms slap one after the other.</li>
 *   <li><b>First Hand</b>: the statue rears back, right hand high over its head, then lunges forward and slaps the point flat.</li>
 *   <li><b>Third Hand</b>: both hands swing wide, then clap together on the point and hold.</li>
 *   <li><b>Ninety-ninth Hand</b>: the statue leans in and all twenty-two arms stretch out and slap at scattered spots, each on its own beat.</li>
 *   <li><b>Zero Hand</b>: the right hand reaches over, round behind the target, and closes.</li>
 * </ul>
 */
public final class GuanyinAnimator {
    public enum Kind { PALM, FIRST, THIRD, NINETY, ZERO }

    /** One move in progress. Positions and directions are in the statue frame; {@code u} is derived from them. */
    public static final class Move {
        public Kind kind;
        public double age;
        /** First: ticks of wind-up. Third: wind-up, then the hold counts to {@code extra}. Ninety / Zero: duration / charge. */
        public int extra;
        public int windup;
        /** The point on the ground (First, Third, Palm), the user's feet (Ninety) or the target's feet (Zero). */
        public double[] pos = new double[3];
        /** The way the user looks, flat (used by Ninety, which is aimed that way). */
        public double[] dir = {0, 0, 1};
        public boolean left, strong;
        public long seed;
    }

    private final GuanyinRig rig;

    public GuanyinAnimator(GuanyinRig rig) { this.rig = rig; }

    // ------------------------------------------------------------------ envelopes

    static double clamp(double x, double lo, double hi) { return x < lo ? lo : Math.min(x, hi); }
    static double smooth(double x) {
        x = clamp(x, 0, 1);
        return x * x * (3 - 2 * x);
    }
    static double easeIn(double x) { x = clamp(x, 0, 1); return x * x * x; }
    static double easeOut(double x) { x = clamp(x, 0, 1); return 1 - (1 - x) * (1 - x) * (1 - x); }
    static double mix(double a, double b, double t) { return a + (b - a) * t; }

    /** A repeatable number in [0, 1) from a seed and a salt. */
    static double rnd(long seed, long salt) {
        long h = seed * 0x9E3779B97F4A7C15L + salt * 0xBF58476D1CE4E5B9L + 0x632BE59BD9B4E019L;
        h ^= h >>> 30;
        h *= 0xBF58476D1CE4E5B9L;
        h ^= h >>> 27;
        h *= 0x94D049BB133111EBL;
        h ^= h >>> 31;
        return (h >>> 11) * (1.0 / (1L << 53));
    }

    private static final double[] UP = {0, 1, 0};

    // ------------------------------------------------------------------ entry point

    public void animate(GuanyinRig.Pose p, double time, List<Move> moves) {
        idle(p, time);
        if (moves.isEmpty()) return;
        moves.sort(Comparator.comparingDouble((Move m) -> m.age).reversed()); // the oldest first, so the newest has the last word

        // held-down Attack (a barrage) is many palms close together: it gets its own flurry instead of one slap each
        int recent = 0;
        double sx = 0, sz = 0;
        for (Move m : moves) {
            if (m.kind == Kind.PALM && m.age < 9) {
                recent++;
                sx += m.pos[0];
                sz += m.pos[2];
            }
        }
        boolean barrage = recent >= 5;
        if (barrage) barrage(p, time, new double[] {sx / recent, 0, sz / recent}, Math.min(1.0, recent / 8.0), moves);
        for (Move m : moves) {
            switch (m.kind) {
                case PALM -> { if (!barrage) palm(p, m); }
                case FIRST -> first(p, m);
                case THIRD -> third(p, m);
                case NINETY -> ninety(p, time, m);
                case ZERO -> zero(p, m);
            }
        }
    }

    // ------------------------------------------------------------------ idle: seated, hands in prayer, the other arms fanned out and swaying

    private void idle(GuanyinRig.Pose p, double time) {
        p.lean = Math.sin(time * 0.05) * 1.2;
        p.twist = 0;
        p.shift = 0;
        p.drop = 0;
        p.headPitch = Math.sin(time * 0.05 + 0.6) * 1.0;
        p.headYaw = 0;
        p.haloSpin = time * 0.9;
        for (int side = -1; side <= 1; side += 2) {
            int main = side < 0 ? MAIN_RIGHT : MAIN_LEFT;
            // gassho: palms pressed together in front of the chest, fingers up, thumbs toward the body
            p.arms[main].set(v(side * 0.2, 4.7, 1.6), UP, v(-side, 0, 0), v(side * 0.9, -0.7, -0.2), 0.05, 1.0);
            for (int i = 0; i < GuanyinRig.ARMS_PER_SIDE; i++) {
                double f = i / (double) (GuanyinRig.ARMS_PER_SIDE - 1);
                double sway = Math.sin(time * 0.07 + i * 0.9 + side) * 4.0;
                double theta = Math.toRadians(mix(38, 172, f) + sway);
                double[] dir = v(side * Math.sin(theta), -Math.cos(theta), 0);
                double[] s = rig.restShoulder(GuanyinRig.fanArm(side, i));
                double[] wrist = add(s, mul(dir, (UPPER + FORE) * 0.9));
                p.arms[GuanyinRig.fanArm(side, i)].set(wrist, dir, v(0, 0, 1), v(side * 0.5, 0, -0.8), 0.12 + 0.05 * Math.sin(time * 0.1 + i), 1.0);
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private static double heading(double x, double z) { return Math.toDegrees(Math.atan2(x, z)); }

    /** Where the hand points (fingers) and where the palm faces for a hand held at angle alpha above flat, palm on the underside / far side. */
    private static double[] fingers(double[] u, double alphaDeg) {
        double a = Math.toRadians(alphaDeg);
        return add(mul(u, Math.cos(a)), mul(UP, Math.sin(a)));
    }

    /** A palm-strike hand: the fingers point up (leaning {@code tiltDeg} toward {@code u}), so the palm faces forward. */
    private static double[] fingersUp(double[] u, double tiltDeg) {
        double a = Math.toRadians(tiltDeg);
        return add(mul(UP, Math.cos(a)), mul(u, Math.sin(a)));
    }

    /** Where the palm faces for {@link #fingersUp}: forward, a little down. Always at right angles to the fingers. */
    private static double[] palmFwd(double[] u, double tiltDeg) {
        double a = Math.toRadians(tiltDeg);
        return add(mul(u, Math.cos(a)), mul(UP, -Math.sin(a)));
    }

    private static double[] palmOf(double[] u, double alphaDeg) {
        double a = Math.toRadians(alphaDeg);
        return add(mul(u, Math.sin(a)), mul(UP, -Math.cos(a)));
    }

    /** Smallest lean (degrees) from which this arm reaches the wrist target without stretching more than {@code maxK}. */
    private double leanToReach(int arm, double[] wrist, double min, double max, double twist, double maxK) {
        for (double lean = min; lean <= max; lean += 2) {
            double[] s = rig.shoulderFor(arm, lean, twist, lean * 0.012, lean * 0.004);
            if (len(sub(wrist, s)) <= (UPPER + FORE) * maxK) return lean;
        }
        return max;
    }

    private static double[] flat(double[] p) {
        double d = Math.hypot(p[0], p[2]);
        return d < 1.0e-6 ? v(0, 0, 1) : v(p[0] / d, 0, p[2] / d);
    }

    private static double[] leftOf(double[] u) { return v(u[2], 0, -u[0]); }

    /** Blend the body toward a lean, twist and head nod by w. */
    private void body(GuanyinRig.Pose p, double w, double lean, double twist, double headPitch) {
        p.lean = mix(p.lean, lean, w);
        p.twist = mix(p.twist, twist, w);
        p.headPitch = mix(p.headPitch, headPitch, w);
        p.shift = mix(p.shift, Math.max(0, lean) * 0.012, w);
        p.drop = mix(p.drop, Math.max(0, lean) * 0.004, w);
    }

    private void arm(GuanyinRig.Pose p, int idx, double w, double[] wrist, double[] dir, double[] palm, double[] pole, double curl, double scale) {
        p.arms[idx].blend(wrist, dir, palm, pole, curl, scale, w);
    }

    /** The wrist that puts the middle of the palm at {@code palmCentre}. */
    private static double[] wristFor(double[] palmCentre, double[] fingerDir, double scale) {
        return sub(palmCentre, mul(fingerDir, 0.72 * scale));
    }

    // ------------------------------------------------------------------ Palm: Attack / Strong attack

    private void palm(GuanyinRig.Pose p, Move m) {
        double a = m.age;
        double contact = m.strong ? 3.4 : 2.4, life = m.strong ? 13 : 10;
        double sig = m.left ? 1 : -1;
        int arm = m.left ? MAIN_LEFT : MAIN_RIGHT;
        double[] c = add(v(m.pos[0], m.pos[1], m.pos[2]), v(0, 1.3, 0)); // chest height on the target, not the ground
        double[] u = flat(c), l = leftOf(u);
        double psi = heading(u[0], u[2]);
        double scale = m.strong ? 1.45 : 1.15;
        // a palm strike: the hand is drawn back beside the shoulder with the fingers up, then thrown straight forward, palm first
        double q = clamp(a / (contact * 1.6), 0, 1);
        double qe = 1 - Math.pow(1 - q, 2.2);
        double[] from = add(add(add(c, mul(l, sig * (m.strong ? 3.2 : 2.4))), mul(u, m.strong ? -3.4 : -2.4)), v(0, m.strong ? 1.6 : 1.0, 0));
        double[] to = add(c, mul(l, sig * 0.35)); // never past the middle: the arm must not cross the body
        double[] centre = add(mul(from, 1 - qe), mul(to, qe));
        double tilt = mix(38, 12, qe); // the fingers start leaning back and end near vertical
        double[] dir = fingersUp(u, tilt);
        double[] palm = palmFwd(u, tilt);
        double[] wrist = wristFor(centre, dir, scale);
        double wIn = smooth(a / 1.4), wOut = 1 - smooth((a - contact - 2.5) / Math.max(1, life - contact - 2.5));
        double w = wIn * wOut;
        double[] contactWrist = wristFor(c, fingersUp(u, 12), scale);
        double lean = leanToReach(arm, contactWrist, m.strong ? 26 : 16, 60, psi * 0.6, 1.15);
        // a little recoil on the hit
        double recoil = a > contact ? 3.0 * Math.exp(-(a - contact) * 0.6) * (m.strong ? 1.6 : 1.0) : 0;
        body(p, w, lean + recoil, psi * 0.6, -lean * 0.55);
        arm(p, arm, w, wrist, dir, palm, v(sig * 0.9, -0.1, -0.6), 0.05, scale);
    }

    // ------------------------------------------------------------------ the barrage: both main arms and the lower fan arms slapping in turn

    private void barrage(GuanyinRig.Pose p, double time, double[] centre, double intensity, List<Move> moves) {
        double[] c = add(centre, v(0, 1.3, 0)); // chest height on the target, not the ground
        double[] u = flat(c), l = leftOf(u);
        double psi = heading(u[0], u[2]);
        double lean = 34 + 3 * Math.sin(time * 0.9);
        body(p, intensity, lean, psi * 0.6, -lean * 0.55);
        int[] who = new int[10];
        who[0] = MAIN_RIGHT;
        who[1] = MAIN_LEFT;
        for (int i = 0; i < 4; i++) {
            who[2 + i] = GuanyinRig.fanArm(-1, i);
            who[6 + i] = GuanyinRig.fanArm(1, i);
        }
        for (int j = 0; j < who.length; j++) {
            int arm = who[j];
            int side = GuanyinRig.sideOf(arm);
            double period = 5.5;
            double cyc = time / period + j * 0.5 / 1.0 * 0.5;
            if (j >= 2) cyc += j * 0.173;
            if (arm == MAIN_LEFT) cyc += 0.5;
            long n = (long) Math.floor(cyc);
            double f = cyc - n;
            long seed = n * 31L + j * 977L;
            double e = f < 0.3 ? smooth(f / 0.3) : smooth((1 - f) / 0.7);
            double across = side * (0.4 + rnd(seed, 1) * 2.6);
            double along = (rnd(seed, 2) - 0.5) * 3.0;
            double up = rnd(seed, 3) * 1.6;
            double[] t = add(add(add(c, mul(l, across)), mul(u, along)), v(0, up, 0));
            double[] dir = fingersUp(u, 18); // palm strikes: fingers up, palm forward
            double scale = 1.1 + 0.25 * rnd(seed, 4);
            arm(p, arm, e * intensity, wristFor(t, dir, scale), dir, palmFwd(u, 18), v(side * 0.8, 0.1, -0.5), 0.0, scale);
        }
    }

    // ------------------------------------------------------------------ First Hand: rear back, lunge, slap

    private void first(GuanyinRig.Pose p, Move m) {
        double a = m.age;
        double W = Math.max(2, m.extra);
        double[] g = v(m.pos[0], m.pos[1], m.pos[2]);
        double[] u = flat(g), l = leftOf(u);
        double psi = heading(u[0], u[2]);
        double sig = g[0] >= 0 ? 1 : -1; // the hand on the target's side
        int arm = sig > 0 ? MAIN_LEFT : MAIN_RIGHT;
        double scale = 1.9;
        double[] palmAt = add(g, v(0, 0.55, 0));
        double[] dirDown = fingers(u, 0);
        double[] wristHit = wristFor(palmAt, dirDown, scale);
        double lean = leanToReach(arm, wristHit, 30, 62, psi * 0.8, 1.2);

        double raise = smooth(a / (0.5 * W));
        double s = clamp((a - 0.5 * W) / (0.5 * W), 0, 1);
        double drive = easeIn(s);
        double recover = smooth((a - (W + 7)) / 9);
        double w = (a < 0.5 * W ? raise : 1.0) * (1 - recover);

        // overhead: above and a little behind the right shoulder, palm toward the target
        double[] overhead = add(add(v(0, 10.4, 0), mul(l, 1.7 * sig)), mul(u, -0.3));
        double alpha = mix(100, 0, Math.pow(s, 0.6));
        double[] dir = fingers(u, alpha), palm = palmOf(u, alpha);
        double[] wrist = a < 0.5 * W ? overhead : add(mul(overhead, 1 - drive), mul(wristFor(palmAt, dir, scale), drive));
        double jolt = a > W ? 4.0 * Math.exp(-(a - W) / 1.6) * Math.cos((a - W) * 1.7) : 0;
        double leanNow = a < 0.5 * W ? mix(0, -9, raise) : mix(-9, lean, drive);
        body(p, w, leanNow + jolt, psi * 0.8, -leanNow * 0.5);
        arm(p, arm, w, wrist, dir, palm, v(sig, 0.5, -0.6), 0.0, scale);
        // the left hand lifts a little for balance
        arm(p, sig > 0 ? MAIN_RIGHT : MAIN_LEFT, w * smooth(a / W), add(v(-sig * 1.6, 6.3, 2.2), mul(u, 0.4)), v(-sig * 0.3, 1, 0.3), v(sig * 0.7, 0, 0.3), v(-sig * 0.9, 0.3, -0.2), 0.1, 1.2);
    }

    // ------------------------------------------------------------------ Third Hand: wide, then clap, hold

    private void third(GuanyinRig.Pose p, Move m) {
        double a = m.age;
        double W = Math.max(2, m.windup);
        double[] g = v(m.pos[0], m.pos[1], m.pos[2]);
        double[] u = flat(g), l = leftOf(u);
        double psi = heading(u[0], u[2]);
        double scale = 2.3;
        double[] mid = add(g, v(0, 2.5, 0));
        double s = clamp((a - 0.45 * W) / (0.55 * W), 0, 1);
        double drive = easeIn(s);
        double gap = a < W ? mix(8.5, 1.5, drive) : 1.5 - 0.12 * Math.abs(Math.sin((a - W) * 1.5));
        double h = mix(4.8, 0.0, drive);
        double raise = smooth(a / (0.45 * W));
        double recover = smooth((a - m.extra) / 8.0);
        double w = (a < 0.45 * W ? raise : 1.0) * (1 - recover);
        double[] dir = fingers(u, mix(48, 24, drive));
        double lean = leanToReach(MAIN_LEFT, wristFor(add(mid, mul(l, 1.5)), dir, scale), 26, 60, psi * 0.8, 1.2);
        double leanNow = a < 0.45 * W ? mix(0, -7, raise) : mix(-7, lean, drive);
        body(p, w, leanNow, psi * 0.8, -leanNow * 0.5);
        for (int side = -1; side <= 1; side += 2) {
            double[] wr = wristFor(add(add(mid, mul(l, side * gap)), v(0, h, 0)), dir, scale);
            arm(p, side < 0 ? MAIN_RIGHT : MAIN_LEFT, w, wr, dir, mul(l, -side), v(side * 1.0, 0.4, -0.5), 0.0, scale);
        }
    }

    // ------------------------------------------------------------------ Ninety-ninth Hand: every arm slapping, each on its own beat

    private void ninety(GuanyinRig.Pose p, double time, Move m) {
        double a = m.age;
        double D = m.extra;
        double env = smooth(a / 5) * (1 - smooth((a - D) / 6));
        double[] u = flat(m.dir), l = leftOf(u);
        double[] user = v(m.pos[0], m.pos[1], m.pos[2]);
        double[] centre = add(user, mul(u, 8.5));
        double psi = heading(u[0], u[2]);
        double lean = 27 + 5 * Math.sin(a * 0.45);
        body(p, env, lean, 0, -lean * 0.5);
        p.haloSpin += a * 3 * env;
        for (int arm = 0; arm < GuanyinRig.N_ARMS; arm++) {
            int side = GuanyinRig.sideOf(arm);
            double period = 4.0;
            double cyc = a / period + (arm * 0.381966) % 1.0;
            long n = (long) Math.floor(cyc);
            double f = cyc - n;
            long seed = n * 7919L + arm * 104729L + m.seed;
            double e = f < 0.3 ? smooth(f / 0.3) : smooth((1 - f) / 0.7);
            double along = 3.0 + rnd(seed, 1) * 11.0;
            double across = side * (2.5 + rnd(seed, 2) * 2.5);
            double up = 0.6 + rnd(seed, 3) * 3.0;
            double[] t = add(add(add(user, mul(u, along)), mul(l, across)), v(0, up, 0));
            double scale = 1.15 + 0.5 * rnd(seed, 4);
            double alpha = 40 + rnd(seed, 5) * 40;
            double[] dir = fingers(u, alpha);
            arm(p, arm, e * env, wristFor(t, dir, scale), dir, palmOf(u, alpha), v(side * 0.9, 0.7, -0.3), 0.0, scale);
        }
    }

    // ------------------------------------------------------------------ Zero Hand: the statue stands behind the target, reaches over and closes its hand round them

    private void zero(GuanyinRig.Pose p, Move m) {
        double a = m.age;
        double C = Math.max(2, m.extra);
        double[] g = v(m.pos[0], m.pos[1], m.pos[2]); // the target's feet; the statue stands behind them, looking at their back
        double[] u = flat(g), l = leftOf(u);
        double psi = heading(u[0], u[2]);
        double sig = -1; // always the statue's right hand: the target is straight ahead, so the side only needs to stay the same every frame
        double reach = easeOut(a / (0.45 * C));
        double curl = smooth((a - 0.45 * C) / (0.45 * C));
        double fade = 1 - smooth((a - (C + 6)) / 12.0);
        double open = smooth((a - (C + 4)) / 10.0);
        double w = smooth(a / Math.max(2.0, 0.2 * C)) * fade;
        double scale = 2.1;
        double[] chest = add(g, v(0, 1.3, 0));
        // the hand starts high and wide, near the statue, and comes down onto the target's back: palm to the back, fingers up
        double[] from = add(add(add(chest, mul(u, -3.0)), mul(l, sig * 2.4)), v(0, 3.2, 0));
        double[] to = add(chest, mul(u, -0.85));
        double[] centre = add(mul(from, 1 - reach), mul(to, reach));
        double tilt = mix(30, 12, reach);
        double[] dir = fingersUp(u, tilt);
        double[] palm = palmFwd(u, tilt);
        double[] wrist = wristFor(centre, dir, scale);
        double lean = leanToReach(MAIN_RIGHT, wristFor(to, fingersUp(u, 12), scale), 8, 60, psi * 0.9, 1.15);
        body(p, w, lean * reach, psi * 0.9, -14 * Math.max(curl, 0.3));
        arm(p, MAIN_RIGHT, w, wrist, dir, palm, v(sig, 0.6, -0.4), curl * (1 - open), scale);
    }
}
