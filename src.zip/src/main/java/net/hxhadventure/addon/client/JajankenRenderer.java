package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.addon.GonVow;
import net.hxhadventure.addon.Jajanken;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * Draws Jajanken (Rock and Scissors) like the reference art: a big, smooth, golden-orange ball of aura around the fist that starts wide and
 * slowly converges on the fist into a tight glowing ball, and on release a burst
 * where the punch lands. For Scissors the ball turns into a blade at a full charge, and the release is a horizontal slash arc
 * with a streak along the dash. Built from glowing translucent shells and spikes, so there is no model or texture.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class JajankenRenderer {
    private JajankenRenderer() {}

    /** Aura radius when the charge starts, and when it has fully converged on the fist. */
    private static final double R_START = 1.9, R_END = 0.38;
    private static final int LAT = 12, LON = 20;
    private static final double CULL_DISTANCE = 96.0;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || JajankenFx.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        double time = level.getGameTime() + pt;
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        Matrix4f m = ps.last().pose();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.lightning();
        VertexConsumer vc = buf.getBuffer(type);

        Iterator<JajankenFx.Rec> it = JajankenFx.all().values().iterator();
        while (it.hasNext()) {
            JajankenFx.Rec r = it.next();
            if (r.mode == JajankenFx.PUNCH && time - r.punchAt > punchLife(r)) {
                it.remove();
                continue;
            }
            if (r.mode == JajankenFx.SLASH && time - r.punchAt > JajankenFx.SLASH_TICKS) {
                it.remove();
                continue;
            }
            if (r.mode == JajankenFx.FIRE && time - r.punchAt > JajankenFx.FIRE_TICKS) {
                it.remove();
                continue;
            }
            if (r.mode == JajankenFx.CHARGING) {
                Entity owner = level.getEntity(r.owner);
                if (!(owner instanceof LivingEntity le)) continue;
                if (time < r.t0) continue; // still in the flare: the fist aura only starts once Ko is enforced
                if (cam.distanceToSqr(owner.getX(), owner.getY(), owner.getZ()) > CULL_DISTANCE * CULL_DISTANCE) continue;
                double f = JajankenFx.chargeFraction(r, time);   // damage / pose: a full charge is ROCK_CHARGE_TICKS
                double af = JajankenFx.auraFraction(r, time);    // the aura's own clock: the original's linear AURA_CONTRACT_TICKS
                Vec3 hand = JajankenFx.handPos(le, pt, f, r.move);
                if (r.vow && r.move == Jajanken.ROCK) {
                    vowOrb(m, vc, cam, le, r, time, pt); // Gon's adult form: the cycling orb
                } else if (r.move == Jajanken.SCISSORS && f >= 1.0) {
                    // a full charge: the ball shrinks away while a blade grows out of the joined hands
                    double morph = Mth.clamp((time - (r.t0 + Jajanken.ROCK_CHARGE_TICKS)) / 6.0, 0, 1);
                    if (morph < 1.0) charge(m, vc, cam, hand, af, time, r.owner, 1.0 - morph);
                    blade(m, vc, cam, hand, JajankenFx.handDir(le, pt, f), morph, time, r.owner);
                } else {
                    charge(m, vc, cam, hand, af, time, r.owner, 1.0);
                }
            } else if (r.mode == JajankenFx.SLASH) {
                slash(m, vc, cam, r, (time - r.punchAt) / JajankenFx.SLASH_TICKS);
            } else if (r.mode == JajankenFx.FIRE) {
                // nothing to draw on the thrower: the ball is drawn below, from its own record
            } else {
                burst(m, vc, cam, new Vec3(r.px, r.py, r.pz), (time - r.punchAt) / punchLife(r), r.owner, Math.max(1.0, r.dist));
            }
        }

        // Paper balls in flight, and their bursts
        Iterator<JajankenFx.Shot> sit = JajankenFx.shots().values().iterator();
        while (sit.hasNext()) {
            JajankenFx.Shot s = sit.next();
            double age = Math.max(0, time - s.t0);
            double dist = age * Jajanken.PAPER_SPEED;
            if (dist > Jajanken.PAPER_RANGE + 6) { // the burst packet never came (the owner left): drop it
                sit.remove();
                continue;
            }
            Vec3 dir = new Vec3(s.dx, s.dy, s.dz);
            Vec3 pos = new Vec3(s.x, s.y, s.z).add(dir.scale(Math.min(dist, Jajanken.PAPER_RANGE)));
            if (cam.distanceToSqr(pos) > CULL_DISTANCE * CULL_DISTANCE) continue;
            paperBall(m, vc, cam, pos, dir, s.radius, time, (int) s.t0);
        }
        Iterator<double[]> bit = JajankenFx.bursts().iterator();
        int bi = 0;
        while (bit.hasNext()) {
            double[] b = bit.next();
            double age = time - b[3];
            if (age > JajankenFx.PUNCH_TICKS) {
                bit.remove();
                continue;
            }
            burst(m, vc, cam, new Vec3(b[0], b[1], b[2]), age / JajankenFx.PUNCH_TICKS, bi++, 1.0);
        }
        buf.endBatch(type);
    }

    // ---------------- the charge ----------------
    /** {@code f}: how far the aura has contracted (0 = the full burst, 1 = a tight ball), a straight line over AURA_CONTRACT_TICKS like the original. */
    private static void charge(Matrix4f m, VertexConsumer vc, Vec3 cam, Vec3 fist, double f, double time, int seed, double size) {
        double ease = f;                                             // linear, as in the original (no easing)
        double R = Mth.lerp(ease, R_START, R_END) * size;
        double pulse = 1 + (f >= 1 ? 0.07 : 0.03) * Math.sin(time * (f >= 1 ? 1.4 : 0.6));
        Vec3 c = fist.subtract(cam);
        double brightness = 0.55 + 0.45 * ease;

        // The camera is at the origin here. Close to (or inside) the ball it fades away, so the wide early aura never blocks the
        // view in first person; from outside it is drawn at full strength.
        double fade = smooth((c.length() - R * 0.5) / (R * 0.9 + 0.3));
        if (fade <= 0.01) return;

        // a smooth, soft ball like the reference art: orange outside, yellow-orange in the middle, a hot yellow core. No spikes.
        sphere(m, vc, c, R * pulse, 255, 105, 15, (int) ((55 + 35 * brightness) * fade));
        sphere(m, vc, c, R * 0.88 * pulse, 255, 135, 20, (int) ((70 + 40 * brightness) * fade));
        sphere(m, vc, c, R * 0.70 * pulse, 255, 170, 30, (int) ((85 + 50 * brightness) * fade));
        sphere(m, vc, c, R * (0.28 + 0.26 * ease), 255, 215, 90, (int) ((120 + 90 * brightness) * fade));
    }

    // ---------------- the punch ----------------
    /** How long a punch's burst is drawn: a normal Rock's blast is quick, the vow's (20x the radius) lingers twice as long. */
    private static double punchLife(JajankenFx.Rec r) {
        return JajankenFx.PUNCH_TICKS * (r.dist > 1.0 ? 2.0 : 1.0);
    }

    /** {@code scale}: 1 for a normal burst, 20 for Gon's adult form (the blast then fills the whole damage radius). */
    private static void burst(Matrix4f m, VertexConsumer vc, Vec3 cam, Vec3 at, double age, int seed, double scale) {
        double a = Mth.clamp(age, 0, 1);
        double out = 1 - Math.pow(1 - a, 3);
        Vec3 c = at.subtract(cam);
        int fade = (int) (255 * (1 - a));
        sphere(m, vc, c, (0.35 + 2.0 * out) * scale, 255, 120, 30, (int) (150 * (1 - a)));
        sphere(m, vc, c, (0.25 + 1.2 * out) * scale, 255, 215, 70, (int) (200 * (1 - a)));
        sphere(m, vc, c, (0.2 + 0.7 * out) * scale, 255, 255, 230, fade);
        for (int i = 0; i < 26; i++) {
            Vec3 d = fib(i, 26);
            double len = (0.6 + 0.9 * ((i * 37 + seed) % 7) / 7.0) * (0.4 + 2.2 * out);
            spike(m, vc, cam, c, d, (0.3 + 1.6 * out) * scale, len * scale, (0.28 * (1 - a) + 0.05) * Math.min(scale, 6.0), 255, 200, 60, (int) (220 * (1 - a)));
        }
    }

    // ---------------- Gon's adult form: the cycling orb ----------------
    private static double smooth(double t) {
        t = Mth.clamp(t, 0, 1);
        return t * t * (3 - 2 * t);
    }

    /**
     * Rock in the vow. The size follows {@link GonVow#envelope} (measured from the sound clip that starts every cycle): a small red orb in
     * the hand, the high-pitched surge throws it out to {@link GonVow#ORB_MAX_RADIUS} blocks around the user, then it falls back as the
     * clip fades, to a normal Rock's size, but denser (more opaque) and brighter (white-hot core). It is a little denser every cycle.
     */
    private static void vowOrb(Matrix4f m, VertexConsumer vc, Vec3 cam, LivingEntity le, JajankenFx.Rec r, double time, float pt) {
        double since = Math.max(0, time - r.t0);
        int cycle = (int) (since / GonVow.CYCLE_PERIOD_TICKS);       // each cycle: the pulse (the sound clip), then a 1 s rest as a charged fist
        double phase = since - cycle * (double) GonVow.CYCLE_PERIOD_TICKS;
        double e = GonVow.envelope(phase);              // 0 = smallest, 1 = full size
        double k = 1 - e;                               // 1 = compact
        double rock = GonVow.ORB_ROCK_RADIUS;
        double base = cycle == 0 ? Mth.lerp(smooth(phase / GonVow.CYCLE_TICKS), GonVow.ORB_START_RADIUS, rock) : rock;
        double R = base + (GonVow.ORB_MAX_RADIUS - base) * e;
        double dens = 1.0 + 0.12 * Math.min(cycle, 8);

        // the orb starts in the hand and, as it grows, centres itself on the user's body
        double grow = GonVowClient.scale(le, pt);
        Vec3 hand = JajankenFx.handPos(le, pt, 1.0, Jajanken.ROCK);
        Vec3 body = new Vec3(Mth.lerp(pt, le.xo, le.getX()), Mth.lerp(pt, le.yo, le.getY()) + 0.9 * grow, Mth.lerp(pt, le.zo, le.getZ()));
        Vec3 c = hand.lerp(body, smooth((R - rock) / 3.0)).subtract(cam);

        double pulse = 1 + 0.03 * Math.sin(time * 1.1);
        double kk = k * k;
        // red when it is out, orange-white when it is packed tight
        sphere(m, vc, c, R * pulse, 255, (int) (25 + 70 * k), (int) (10 + 15 * k), (int) Math.min(255, 36 + (150 * dens - 36) * kk));
        sphere(m, vc, c, R * 0.82 * pulse, 255, (int) (60 + 130 * k), (int) (15 + 55 * k), (int) Math.min(255, 26 + (190 * dens - 26) * k));
        if (k > 0.35) sphere(m, vc, c, R * 0.6, 255, 205, 100, (int) Math.min(255, 235 * dens * (k - 0.35) / 0.65));
        double coreR = Math.min(R * 0.8, rock * 0.7 + 1.1 * e);
        sphere(m, vc, c, coreR, 255, 245, 215, 255);

    }

    // ---------------- Paper: the thrown ball ----------------
    /** A big glowing ball with a tail streaming back along its flight path, like the reference art. */
    private static void paperBall(Matrix4f m, VertexConsumer vc, Vec3 cam, Vec3 pos, Vec3 dir, double R, double time, int seed) {
        Vec3 c = pos.subtract(cam);
        double pulse = 1 + 0.05 * Math.sin(time * 1.1 + seed);
        // the tail: the same shells, shrinking and fading, strung out behind
        for (int i = 6; i >= 1; i--) {
            double k = i / 7.0;
            Vec3 at = c.subtract(dir.scale(R * 0.8 * i));
            double rr = R * (1 - 0.8 * k) * pulse;
            sphere(m, vc, at, rr, 255, 190, 50, (int) (60 * (1 - k)));
            sphere(m, vc, at, rr * 0.7, 255, 235, 120, (int) (100 * (1 - k)));
        }
        // the head: orange outside, yellow, and a near-white core
        sphere(m, vc, c, R * pulse, 255, 150, 30, 90);
        sphere(m, vc, c, R * 0.8 * pulse, 255, 215, 70, 140);
        sphere(m, vc, c, R * 0.5, 255, 252, 215, 215);
    }

    // ---------------- Scissors: the blade (a full charge) ----------------
    private static final double BLADE_LEN = 1.5, BLADE_HALF_W = 0.2;
    /** Half the sweep of the slash crescent (rad): at the reach, about the width the blade really cuts. */
    private static final double ARC = 0.55;

    /** A flat, glowing blade pointing out of the fist along `face` (the way the arm points); grows in with `grow` (0..1). */
    private static void blade(Matrix4f m, VertexConsumer vc, Vec3 cam, Vec3 hand, Vec3 face, double grow, double time, int seed) {
        if (grow <= 0) return;
        Vec3 c = hand.subtract(cam);
        Vec3 ref = Math.abs(face.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0); // any axis that is not along the blade
        Vec3 side = face.cross(ref).normalize();   // perpendicular to the blade
        Vec3 up = side.cross(face).normalize();    // perpendicular to both
        double flick = 1 + 0.05 * Math.sin(time * 1.3 + seed);
        double len = BLADE_LEN * grow * flick;
        // glow layers, outside in: orange, gold, near-white edge/core
        bladeShape(m, vc, c, face, side, up, len * 1.12, BLADE_HALF_W * 1.9, 255, 110, 20, (int) (70 * grow));
        bladeShape(m, vc, c, face, side, up, len * 1.04, BLADE_HALF_W * 1.35, 255, 190, 40, (int) (120 * grow));
        bladeShape(m, vc, c, face, side, up, len, BLADE_HALF_W * 0.85, 255, 250, 215, (int) (225 * grow));
        // a few flame spikes licking off the blade, like the ball's rim
        for (int i = 0; i < 10; i++) {
            double t = (i + 0.5) / 10.0;
            double fl = 0.5 + 0.5 * Math.sin(time * 0.9 + i * 1.9 + seed);
            Vec3 at = c.add(face.scale(len * (0.15 + 0.8 * t)));
            Vec3 d = (i % 2 == 0 ? side : side.scale(-1)).add(up.scale(0.4 * (fl - 0.5))).normalize();
            double base = BLADE_HALF_W * 1.0 * (1 - 0.6 * t);
            spike(m, vc, cam, at, d, base, 0.25 + 0.25 * fl, 0.12, 255, 170, 40, (int) (180 * grow * (0.5 + 0.5 * fl)));
        }
    }

    /** One blade silhouette (widest a quarter of the way up, tapering to the tip), drawn once flat and once on edge so it reads from every angle. */
    private static void bladeShape(Matrix4f m, VertexConsumer vc, Vec3 c, Vec3 f, Vec3 side, Vec3 up, double len, double hw, int r, int g, int b, int a) {
        if (a <= 0 || len < 0.02) return;
        a = Math.min(255, a);
        Vec3 base = c.subtract(f.scale(0.1));
        Vec3 wide = c.add(f.scale(len * 0.25));
        Vec3 tip = c.add(f.scale(len));
        for (Vec3 w : new Vec3[] {side, up}) {
            Vec3 o = w.scale(hw);
            vtx(m, vc, base.add(o.scale(0.6)), r, g, b, a);
            vtx(m, vc, wide.add(o), r, g, b, a);
            vtx(m, vc, wide.subtract(o), r, g, b, a);
            vtx(m, vc, base.subtract(o.scale(0.6)), r, g, b, a);
            vtx(m, vc, wide.add(o), r, g, b, a);
            vtx(m, vc, tip, r, g, b, 0);
            vtx(m, vc, tip, r, g, b, 0);
            vtx(m, vc, wide.subtract(o), r, g, b, a);
        }
    }

    // ---------------- Scissors: the slash ----------------
    /** A wide horizontal crescent swept from the user's right to left where the dash ended, plus a streak along the dash. */
    private static void slash(Matrix4f m, VertexConsumer vc, Vec3 cam, JajankenFx.Rec r, double age) {
        double a = Mth.clamp(age, 0, 1);
        double rad = Math.toRadians(r.yaw);
        Vec3 face = new Vec3(-Math.sin(rad), 0, Math.cos(rad));
        Vec3 side = new Vec3(-face.z, 0, face.x);     // +side is the user's right
        Vec3 start = new Vec3(r.px, r.py + 1.1, r.pz);
        Vec3 end = start.add(face.scale(r.dist));

        // the dash streak: fat at the end, fading to nothing as time passes
        double fade = 1 - a;
        int n = 8;
        for (int i = 0; i < n; i++) {
            double t0 = (double) i / n, t1 = (double) (i + 1) / n;
            Vec3 p0 = start.add(face.scale(r.dist * t0)).subtract(cam), p1 = start.add(face.scale(r.dist * t1)).subtract(cam);
            ribbon(m, vc, cam, p0, p1, 0.15 + 0.9 * t1, 255, 230, 140, (int) (200 * fade * t1));
        }

        // the crescent: a band on the arc of radius R, swept over the first 60% of the time, with a tapered, fading trail
        double sweep = Mth.clamp(a / 0.6, 0, 1);
        double head = Mth.lerp(1 - Math.pow(1 - sweep, 3), ARC, -ARC);       // angle of the leading edge, radians from straight ahead (right -> left)
        double R = Jajanken.SCISSORS_REACH;
        int segs = 28;
        for (int i = 0; i < segs; i++) {
            double u0 = (double) i / segs, u1 = (double) (i + 1) / segs;     // 0 = the tail, 1 = the leading edge
            double th0 = Mth.lerp(u0, ARC, head), th1 = Mth.lerp(u1, ARC, head);
            double thick = 0.9 * Math.sin(Math.PI * Mth.clamp((u0 + u1) * 0.5, 0, 1)) * (1 - 0.5 * a);
            int alpha = (int) (230 * fade * (0.25 + 0.75 * u1));
            Vec3 o0 = arcPt(end, face, side, R, th0).subtract(cam), o1 = arcPt(end, face, side, R, th1).subtract(cam);
            Vec3 i0 = arcPt(end, face, side, R - thick, th0).subtract(cam), i1 = arcPt(end, face, side, R - thick, th1).subtract(cam);
            // flat band (seen from above)
            vtx(m, vc, o0, 255, 235, 170, alpha);
            vtx(m, vc, o1, 255, 235, 170, alpha);
            vtx(m, vc, i1, 255, 150, 40, alpha / 2);
            vtx(m, vc, i0, 255, 150, 40, alpha / 2);
            // upright curtain on the outer edge (seen from the side), transparent at top and bottom
            Vec3 hv = new Vec3(0, 0.55 * Math.sin(Math.PI * Mth.clamp((u0 + u1) * 0.5, 0, 1)), 0);
            vtx(m, vc, o0.add(hv), 255, 220, 120, 0);
            vtx(m, vc, o1.add(hv), 255, 220, 120, 0);
            vtx(m, vc, o1, 255, 255, 235, alpha);
            vtx(m, vc, o0, 255, 255, 235, alpha);
            vtx(m, vc, o0, 255, 255, 235, alpha);
            vtx(m, vc, o1, 255, 255, 235, alpha);
            vtx(m, vc, o1.subtract(hv), 255, 220, 120, 0);
            vtx(m, vc, o0.subtract(hv), 255, 220, 120, 0);
        }
    }

    /** A point on the arc around `centre`: `ang` radians from straight ahead (positive toward `side`). */
    private static Vec3 arcPt(Vec3 centre, Vec3 face, Vec3 side, double radius, double ang) {
        return centre.add(face.scale(radius * Math.cos(ang))).add(side.scale(radius * Math.sin(ang)));
    }

    // ---------------- geometry helpers (everything is in camera-relative coordinates) ----------------
    private static Vec3 fib(int i, int n) {
        double y = 1 - 2.0 * (i + 0.5) / n;
        double r = Math.sqrt(Math.max(0, 1 - y * y));
        double th = i * 2.399963;
        return new Vec3(Math.cos(th) * r, y, Math.sin(th) * r);
    }

    private static void sphere(Matrix4f m, VertexConsumer vc, Vec3 c, double r, int cr, int cg, int cb, int ca) {
        if (ca <= 0 || r < 0.01) return;
        ca = Math.min(255, ca);
        // big spheres (Gon's adult form: the orb and the blast) are finer and drawn from both sides, so they still show from inside
        boolean big = r > 3.0;
        int lat = big ? 18 : LAT, lon = big ? 32 : LON;
        for (int i = 0; i < lat; i++) {
            double t0 = Math.PI * i / lat, t1 = Math.PI * (i + 1) / lat;
            for (int j = 0; j < lon; j++) {
                double p0 = 2 * Math.PI * j / lon, p1 = 2 * Math.PI * (j + 1) / lon;
                Vec3 a = pt(c, r, t0, p0), b = pt(c, r, t1, p0), d = pt(c, r, t1, p1), e = pt(c, r, t0, p1);
                vtx(m, vc, a, cr, cg, cb, ca);
                vtx(m, vc, b, cr, cg, cb, ca);
                vtx(m, vc, d, cr, cg, cb, ca);
                vtx(m, vc, e, cr, cg, cb, ca);
                if (big) {
                    vtx(m, vc, e, cr, cg, cb, ca);
                    vtx(m, vc, d, cr, cg, cb, ca);
                    vtx(m, vc, b, cr, cg, cb, ca);
                    vtx(m, vc, a, cr, cg, cb, ca);
                }
            }
        }
    }

    private static Vec3 pt(Vec3 c, double r, double theta, double phi) {
        return c.add(r * Math.sin(theta) * Math.cos(phi), r * Math.cos(theta), r * Math.sin(theta) * Math.sin(phi));
    }

    /** A flame-tongue spike standing on a sphere of radius `base` around c, pointing along d. */
    private static void spike(Matrix4f m, VertexConsumer vc, Vec3 cam, Vec3 c, Vec3 d, double base, double len, double width, int cr, int cg, int cb, int ca) {
        if (ca <= 0) return;
        Vec3 b = c.add(d.scale(base));
        Vec3 tip = c.add(d.scale(base + len));
        Vec3 side = d.cross(b).lengthSqr() < 1e-8 ? new Vec3(1, 0, 0) : d.cross(b).normalize();
        side = side.scale(width * 0.5);
        vtx(m, vc, b.add(side), cr, cg, cb, ca);
        vtx(m, vc, b.subtract(side), cr, cg, cb, ca);
        vtx(m, vc, tip, cr, cg, cb, 0);
        vtx(m, vc, tip, cr, cg, cb, 0);
    }

    /** A camera-facing ribbon from a to b. */
    private static void ribbon(Matrix4f m, VertexConsumer vc, Vec3 cam, Vec3 a, Vec3 b, double width, int cr, int cg, int cb, int ca) {
        if (ca <= 0) return;
        Vec3 d = b.subtract(a);
        Vec3 side = d.cross(a.add(b).scale(0.5));
        if (side.lengthSqr() < 1e-10) return;
        side = side.normalize().scale(width * 0.5);
        vtx(m, vc, a.add(side), cr, cg, cb, 0);
        vtx(m, vc, a.subtract(side), cr, cg, cb, 0);
        vtx(m, vc, b.subtract(side), cr, cg, cb, ca);
        vtx(m, vc, b.add(side), cr, cg, cb, ca);
    }

    private static void vtx(Matrix4f m, VertexConsumer vc, Vec3 p, int r, int g, int b, int a) {
        vc.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, a).endVertex();
    }
}
