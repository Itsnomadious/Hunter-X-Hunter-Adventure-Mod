package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.client.event.RenderLivingEvent;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketLfGuard;
import net.hxhadventure.addon.network.PacketLfHands;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.client.event.RenderHandEvent;

/**
 * Genthru's Little Flower, client side: while the H mode is on, the left and right mouse buttons are palms, not a punch and not a use.
 * Their state is reported to the server whenever it changes.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class LittleFlowerClient {
    private LittleFlowerClient() {}

    private static boolean mode;
    private static boolean sentLeft, sentRight;

    public static void setMode(boolean on) {
        mode = on;
        if (!on) report(false, false);
    }

    private static void report(boolean l, boolean r) {
        if (l == sentLeft && r == sentRight) return;
        sentLeft = l;
        sentRight = r;
        AddonNetwork.sendToServer(new PacketLfHands(l, r));
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            mode = false;
            sentLeft = sentRight = false;
            BOMBED.clear();
            AURA.clear();
            LfHandFx.clear();
            guardNeed = 0;
            return;
        }
        reportGuard(mc);
        if (!BOMBED.isEmpty() && mc.level != null && mc.level.getGameTime() % 40 == 0) {
            BOMBED.removeIf(id -> mc.level.getEntity(id) == null); // gone (exploded, died, left)
        }
        if (!mode) return;
        boolean free = mc.screen == null && mc.isWindowActive();
        report(free && mc.options.keyAttack.isDown(), free && mc.options.keyUse.isDown());
    }

    /** No punching, mining, placing or using while the palms are out. */
    @SubscribeEvent
    public static void onClick(InputEvent.InteractionKeyMappingTriggered e) {
        if (!mode || !(e.isAttack() || e.isUseItem())) return;
        e.setCanceled(true);
        e.setSwingHand(false);
    }

    // ------------------------------------------------------------------ Countdown: the bomb on the victim's chest

    private static final Set<Integer> BOMBED = ConcurrentHashMap.newKeySet();
    private static final ResourceLocation BOMB_TEX = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/countdown_bomb.png");
    private static final int FULL_BRIGHT = 0xF000F0;

    public static void setBomb(int entityId, boolean on) {
        if (on) BOMBED.add(entityId);
        else BOMBED.remove(entityId);
    }

    /** A small black device with a blinking red light and a stub of an antenna, stuck on the front of the chest. */
    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Post<?, ?> e) {
        LivingEntity v = e.getEntity();
        if (BOMBED.isEmpty() || !BOMBED.contains(v.getId()) || v.isInvisible() || !v.isAlive()) return;
        PoseStack ps = e.getPoseStack();
        float pt = e.getPartialTick();
        float s = Mth.clamp(v.getBbHeight() / 1.8f, 0.4f, 2.0f);
        float bodyYaw = Mth.rotLerp(pt, v.yBodyRotO, v.yBodyRot);
        long t = v.level().getGameTime();
        boolean lit = (t % 20) < 10;

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180.0f - bodyYaw)); // the model's front is -Z from here on
        ps.translate(0.0, v.getBbHeight() * 0.66, -v.getBbWidth() * 0.26);
        ps.scale(s, s, s);
        VertexConsumer vc = e.getMultiBufferSource().getBuffer(RenderType.entityCutoutNoCull(BOMB_TEX));
        int light = e.getPackedLight();
        // body: a flat block 0.16 x 0.16 x 0.08
        box(ps, vc, -0.08f, -0.08f, -0.04f, 0.08f, 0.08f, 0.04f, 0, light);
        // fuse stub on top
        box(ps, vc, -0.015f, 0.08f, -0.015f, 0.015f, 0.14f, 0.015f, 4, light);
        box(ps, vc, -0.02f, 0.14f, -0.02f, 0.02f, 0.16f, 0.02f, 5, light);
        // face: a dark panel with the light (front is -Z)
        quad(ps, vc, -0.05f, -0.05f, -0.0415f, 0.05f, 0.03f, -0.0415f, 6, light, 1.0f);
        quad(ps, vc, -0.03f, -0.035f, -0.043f, 0.03f, -0.005f, -0.043f, lit ? 2 : 3, lit ? FULL_BRIGHT : light, 1.0f);
        ps.popPose();
    }

    /** Six faces of an axis-aligned box in the current pose, all painted with texel {@code texel} of the bomb texture. */
    private static void box(PoseStack ps, VertexConsumer vc, float x0, float y0, float z0, float x1, float y1, float z1, int texel, int light) {
        quad(ps, vc, x0, y0, z0, x1, y1, z0, texel, light, 0.85f);   // front (-Z)
        quad(ps, vc, x0, y0, z1, x1, y1, z1, texel, light, 0.85f);   // back
        quadSide(ps, vc, x0, y0, z0, z1, y1, texel, light, 0.75f);   // left
        quadSide(ps, vc, x1, y0, z0, z1, y1, texel, light, 0.75f);   // right
        quadTop(ps, vc, x0, x1, y1, z0, z1, texel, light, 1.0f);     // top
        quadTop(ps, vc, x0, x1, y0, z0, z1, texel, light, 0.55f);    // bottom
    }

    private static void vert(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z, float u, float w, int light, float shade, float nx, float ny, float nz) {
        int c = (int) (255 * shade);
        vc.vertex(m, x, y, z).color(c, c, c, 255).uv(u, w).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, nx, ny, nz).endVertex();
    }

    private static void quad(PoseStack ps, VertexConsumer vc, float x0, float y0, float z0, float x1, float y1, float z1, int texel, int light, float shade) {
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        float u = (texel + 0.5f) / 8f, w = 0.5f / 8f;
        vert(vc, m, n, x0, y0, z0, u, w, light, shade, 0, 0, -1);
        vert(vc, m, n, x1, y0, z1, u, w, light, shade, 0, 0, -1);
        vert(vc, m, n, x1, y1, z1, u, w, light, shade, 0, 0, -1);
        vert(vc, m, n, x0, y1, z0, u, w, light, shade, 0, 0, -1);
    }

    private static void quadSide(PoseStack ps, VertexConsumer vc, float x, float y0, float z0, float z1, float y1, int texel, int light, float shade) {
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        float u = (texel + 0.5f) / 8f, w = 0.5f / 8f;
        vert(vc, m, n, x, y0, z0, u, w, light, shade, 1, 0, 0);
        vert(vc, m, n, x, y0, z1, u, w, light, shade, 1, 0, 0);
        vert(vc, m, n, x, y1, z1, u, w, light, shade, 1, 0, 0);
        vert(vc, m, n, x, y1, z0, u, w, light, shade, 1, 0, 0);
    }

    private static void quadTop(PoseStack ps, VertexConsumer vc, float x0, float x1, float y, float z0, float z1, int texel, int light, float shade) {
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        float u = (texel + 0.5f) / 8f, w = 0.5f / 8f;
        vert(vc, m, n, x0, y, z0, u, w, light, shade, 0, 1, 0);
        vert(vc, m, n, x1, y, z0, u, w, light, shade, 0, 1, 0);
        vert(vc, m, n, x1, y, z1, u, w, light, shade, 0, 1, 0);
        vert(vc, m, n, x0, y, z1, u, w, light, shade, 0, 1, 0);
    }

    // ------------------------------------------------------------------ palm aura (H mode) and the counter

    private static final java.util.Map<Integer, long[]> AURA = new ConcurrentHashMap<>(); // entity id -> {flags, touchStart}
    private static int guardNeed;
    private static boolean sentGl, sentGr;

    public static void setAura(int entityId, int flags, long touchStart) {
        if (flags == 0) AURA.remove(entityId);
        else AURA.put(entityId, new long[] {flags, touchStart});
    }

    public static int auraFlags(int entityId) {
        long[] a = AURA.get(entityId);
        return a == null ? 0 : (int) a[0];
    }

    public static long auraStart(int entityId) {
        long[] a = AURA.get(entityId);
        return a == null ? 0 : a[1];
    }

    /** A palm is on you (need 1 = left click, 2 = right click, 3 = both) or it is over (0). */
    public static void setGuardNeed(int need) {
        guardNeed = need;
        Minecraft mc = Minecraft.getInstance();
        if (need != 0 && mc.gui != null) {
            String what = need == 1 ? "LEFT CLICK" : need == 2 ? "RIGHT CLICK" : "LEFT and RIGHT CLICK";
            mc.gui.setOverlayMessage(Component.literal("\u00a7c\u00a7lBrace! \u00a7r\u00a7fPress " + what), false);
        }
        if (need == 0) reportGuardNow(false, false);
    }

    private static void reportGuardNow(boolean l, boolean r) {
        if (l == sentGl && r == sentGr) return;
        sentGl = l;
        sentGr = r;
        AddonNetwork.sendToServer(new PacketLfGuard(l, r));
    }

    private static void reportGuard(Minecraft mc) {
        if (guardNeed == 0) return;
        boolean free = mc.screen == null && mc.isWindowActive();
        reportGuardNow(free && mc.options.keyAttack.isDown(), free && mc.options.keyUse.isDown());
    }

    /**
     * First person: Ren's flame round your own hand(s). It is put where the game draws the empty first-person arm (the same transform as
     * ItemInHandRenderer.renderPlayerArm, swing and equip included), then down the arm to the palm, so it follows the hand whether or not
     * something is held (it sits where the empty arm would be). The numbers worth tuning are FP_PALM (how far down the arm the middle of the flame sits), FP_UP / FP_OUT (a nudge up the screen / outwards) and FP_TILT.
     */
    private static final double FP_PALM = 0.86;
    private static final float FP_TILT = 20f; // degrees the flame leans towards the front of the view
    /** Extra nudge of the flame in the view's own axes (blocks): up the screen, and out to the side of the hand (the hand is on the right for the right arm, on the left for the left). */
    private static final float FP_UP = 0.10f, FP_OUT = 0.12f;

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        int f = auraFlags(mc.player.getId());
        if ((f & 1) == 0 || mc.player.isInvisible()) return;
        boolean mainIsRight = mc.player.getMainArm() == HumanoidArm.RIGHT;
        boolean right = (e.getHand() == InteractionHand.MAIN_HAND) == mainIsRight;
        boolean touching = (f & (right ? 4 : 2)) != 0;
        double now = mc.level == null ? 0 : mc.level.getGameTime() + e.getPartialTick();
        float prog = LfHandFx.progress(auraStart(mc.player.getId()), now);
        float strength = LfHandFx.strength(mc.player.getId(), right, touching, now);

        float side = right ? 1f : -1f;
        float swing = e.getSwingProgress(), equip = e.getEquipProgress();
        boolean slim = "slim".equals(mc.player.getModelName());

        // Where the palm is, relative to the hand's base pose: the vanilla first-person arm transform, then the arm's own place on the body, then down to the palm.
        PoseStack t = new PoseStack();
        armTransform(t, side, swing, equip);
        t.translate(-side * 5f / 16f, (slim ? 2.5f : 2f) / 16f, 0f);
        t.translate(0f, FP_PALM, 0f);
        Vector3f hand = t.last().pose().getTranslation(new Vector3f());

        // The game draws no arm for an empty off hand, which would leave the flame floating alone: draw it, exactly where the main hand's arm would be.
        if (e.getHand() == InteractionHand.OFF_HAND && e.getItemStack().isEmpty()
            && mc.getEntityRenderDispatcher().getRenderer(mc.player) instanceof PlayerRenderer pr) {
            PoseStack a = e.getPoseStack();
            a.pushPose();
            armTransform(a, side, swing, equip);
            if (right) pr.renderRightHand(a, e.getMultiBufferSource(), e.getPackedLight(), mc.player);
            else pr.renderLeftHand(a, e.getMultiBufferSource(), e.getPackedLight(), mc.player);
            a.popPose();
        }

        // The flame itself is drawn in the view's own axes (not the arm's), so it rises up the screen whichever way the arm is turned.
        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        ps.translate(hand.x() + side * FP_OUT, hand.y() + FP_UP, hand.z());
        ps.mulPose(Axis.XP.rotationDegrees(-FP_TILT));
        LfHandFx.draw(ps, e.getMultiBufferSource(), LfHandFx.colourIndex(mc.player), strength, touching ? prog : 0f, (float) now, mc.player.getId() * 0.37f + (right ? 1.7f : 0f), true);
        ps.popPose();
    }

    /** The vanilla first-person arm transform (ItemInHandRenderer.renderPlayerArm), up to where the arm model is drawn. */
    private static void armTransform(PoseStack ps, float side, float swing, float equip) {
        float s1 = Mth.sqrt(swing);
        float dx = -0.3f * Mth.sin(s1 * (float) Math.PI);
        float dy = 0.4f * Mth.sin(s1 * ((float) Math.PI * 2f));
        float dz = -0.4f * Mth.sin(swing * (float) Math.PI);
        float s2 = Mth.sin(swing * swing * (float) Math.PI), s3 = Mth.sin(s1 * (float) Math.PI);
        ps.translate(side * (dx + 0.64000005f), dy - 0.6f + equip * -0.6f, dz - 0.71999997f);
        ps.mulPose(Axis.YP.rotationDegrees(side * 45f));
        ps.mulPose(Axis.YP.rotationDegrees(side * s3 * 70f));
        ps.mulPose(Axis.ZP.rotationDegrees(side * s2 * -20f));
        ps.translate(side * -1f, 3.6f, 3.5f);
        ps.mulPose(Axis.ZP.rotationDegrees(side * 120f));
        ps.mulPose(Axis.XP.rotationDegrees(200f));
        ps.mulPose(Axis.YP.rotationDegrees(side * -135f));
        ps.translate(side * 5.6f, 0f, 0f);
    }
}
