package net.hxhadventure.addon.client;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.properties.Property;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderNameTagEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.hxhadventure.addon.NeedleAppearance;

/**
 * Body Alteration, client side. An entity marked with a saved look has its own render cancelled and a stand-in model of
 * the saved look drawn in its place, at its position, with its rotation, walk cycle, swing, hurt flash, pose and
 * equipment. The stand-in is a throwaway entity that is never added to the world: a {@link SkinDummy} for a player
 * (so the skin and slim/wide arms are right even when that player is offline) or a plain instance of the entity type.
 * Same idea as {@link DisguiseHandler}, which swaps two living entities instead of building a stand-in.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class NeedleDisguise {
    private NeedleDisguise() {}

    private static final Map<Integer, NeedleAppearance> LOOKS = new HashMap<>(); // shown entity id -> saved look
    private static final Map<Integer, Stand> STANDS = new HashMap<>();           // shown entity id -> its stand-in
    private static boolean rendering;
    private static LivingEntity renderingFor;

    private static final class Stand {
        final LivingEntity entity;
        final NeedleAppearance look;
        final ClientLevel level;
        int lastTick = Integer.MIN_VALUE;

        Stand(LivingEntity entity, NeedleAppearance look, ClientLevel level) {
            this.entity = entity;
            this.look = look;
            this.level = level;
        }
    }

    /** A remote player whose skin and arm model we choose ourselves instead of looking the player up on the server. */
    static final class SkinDummy extends RemotePlayer {
        private final ResourceLocation skin;
        private final String model;

        SkinDummy(ClientLevel level, GameProfile profile, ResourceLocation skin, String model) {
            super(level, profile);
            this.skin = skin;
            this.model = model;
        }

        @Override
        public ResourceLocation getSkinTextureLocation() {
            return skin;
        }

        @Override
        public String getModelName() {
            return model;
        }
    }

    /** Called by PacketNeedleDisguise: a null look takes the disguise off. */
    public static void set(int entityId, NeedleAppearance look) {
        STANDS.remove(entityId);
        if (look == null) LOOKS.remove(entityId);
        else LOOKS.put(entityId, look);
    }

    public static void clear() {
        LOOKS.clear();
        STANDS.clear();
    }

    /** The player-shaped stand-in drawn in place of this entity, or null (used to play the same animations on it). */
    static net.minecraft.client.player.AbstractClientPlayer standInFor(int entityId) {
        Stand st = STANDS.get(entityId);
        return st != null && st.entity instanceof net.minecraft.client.player.AbstractClientPlayer p ? p : null;
    }

    // ---------------- building the stand-in ----------------
    private static LivingEntity build(ClientLevel level, NeedleAppearance look) {
        if (look.isPlayer()) {
            GameProfile profile = new GameProfile(look.uuid, look.name.isEmpty() ? "Player" : look.name);
            ResourceLocation skin = DefaultPlayerSkin.getDefaultSkin(look.uuid);
            String model = DefaultPlayerSkin.getSkinModelName(look.uuid);
            if (!look.skin.isEmpty()) {
                // only with a textures property in hand: without one the skin manager would ask the Mojang servers on the render thread
                profile.getProperties().put("textures", new Property("textures", look.skin));
                MinecraftProfileTexture tex = Minecraft.getInstance().getSkinManager().getInsecureSkinInformation(profile).get(MinecraftProfileTexture.Type.SKIN);
                if (tex != null) {
                    skin = Minecraft.getInstance().getSkinManager().registerTexture(tex, MinecraftProfileTexture.Type.SKIN);
                    String m = tex.getMetadata("model");
                    model = "slim".equals(m) ? "slim" : "default";
                }
            }
            return new SkinDummy(level, profile, skin, model);
        }
        ResourceLocation npcSkin = npcSkin(look.type);
        if (npcSkin != null) {
            // the addon's player-model NPCs are drawn as a real player wearing their skin, so punches / kicks play and the size is a player's
            GameProfile npcProfile = new GameProfile(java.util.UUID.nameUUIDFromBytes(("hxh:" + look.type).getBytes(java.nio.charset.StandardCharsets.UTF_8)),
                look.name.isEmpty() ? "Player" : look.name);
            return new SkinDummy(level, npcProfile, npcSkin, "default");
        }
        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(look.type);
        if (type == null) return null;
        Entity e = type.create(level);
        return e instanceof LivingEntity le ? le : null;
    }

    private static ResourceLocation npcSkin(ResourceLocation type) {
        if (type == null || !"hxhadventure".equals(type.getNamespace())) return null;
        switch (type.getPath()) {
            case "hisoka": case "neferpitou": case "gon": case "hina": case "chrollo": case "netero": case "zeno": case "silva": case "bisky": case "illumi": case "kurapika": case "killua": return NpcPlayerRenderer.tex(type.getPath());
            default: return null;
        }
    }

    private static Stand standFor(int id, NeedleAppearance look, ClientLevel level) {
        Stand s = STANDS.get(id);
        if (s != null && s.level == level && s.look == look) return s;
        LivingEntity built;
        try {
            built = build(level, look);
        } catch (Throwable t) {
            built = null;
        }
        if (built == null) {
            LOOKS.remove(id); // cannot be drawn: stop trying and let the real model show
            STANDS.remove(id);
            return null;
        }
        s = new Stand(built, look, level);
        STANDS.put(id, s);
        return s;
    }

    // ---------------- copying the live state onto the stand-in ----------------
    private static void copyState(Stand st, LivingEntity from) {
        LivingEntity to = st.entity;
        to.setPos(from.getX(), from.getY(), from.getZ());
        to.xo = from.xo;
        to.yo = from.yo;
        to.zo = from.zo;
        to.yBodyRot = from.yBodyRot;
        to.yBodyRotO = from.yBodyRotO;
        to.yHeadRot = from.yHeadRot;
        to.yHeadRotO = from.yHeadRotO;
        to.setXRot(from.getXRot());
        to.xRotO = from.xRotO;
        to.setYRot(from.getYRot());
        to.yRotO = from.yRotO;
        to.tickCount = from.tickCount;
        to.setPose(from.getPose());
        to.setShiftKeyDown(from.isShiftKeyDown());
        to.setSprinting(from.isSprinting());
        to.setOnGround(from.onGround());
        to.swinging = from.swinging;
        to.swingTime = from.swingTime;
        to.swingingArm = from.swingingArm;
        to.attackAnim = from.attackAnim;
        to.oAttackAnim = from.oAttackAnim;
        to.hurtTime = from.hurtTime;
        to.deathTime = from.deathTime;
        // the walk cycle advances once per game tick, like LivingEntity.calculateEntityAnimation
        if (from.tickCount != st.lastTick) {
            st.lastTick = from.tickCount;
            float moved = (float) Mth.length(from.getX() - from.xo, 0.0, from.getZ() - from.zo);
            to.walkAnimation.update(Math.min(moved * 4.0F, 1.0F), 0.4F);
        }
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack want = from.getItemBySlot(slot);
            if (!ItemStack.matches(to.getItemBySlot(slot), want)) to.setItemSlot(slot, want.copy());
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @SubscribeEvent
    public static void onPre(RenderLivingEvent.Pre<?, ?> e) {
        if (rendering || LOOKS.isEmpty()) return;
        LivingEntity shown = e.getEntity();
        NeedleAppearance look = LOOKS.get(shown.getId());
        if (look == null || shown.isInvisible()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        Stand st = standFor(shown.getId(), look, level);
        if (st == null) return;

        copyState(st, shown);
        EntityRenderer renderer = mc.getEntityRenderDispatcher().getRenderer(st.entity);
        e.setCanceled(true);
        rendering = true;
        renderingFor = shown;
        try {
            renderer.render(st.entity, Mth.lerp(e.getPartialTick(), shown.yRotO, shown.getYRot()), e.getPartialTick(),
                e.getPoseStack(), e.getMultiBufferSource(), e.getPackedLight());
        } catch (Throwable t) {
            // a model that cannot be drawn this way (some modded entities): fall back to the real one from now on
            LOOKS.remove(shown.getId());
            STANDS.remove(shown.getId());
        } finally {
            rendering = false;
            renderingFor = null;
        }
    }

    /** The stand-in carries the copied name; hide it over your own head like vanilla does. */
    @SubscribeEvent
    public static void onNameTag(RenderNameTagEvent e) {
        if (rendering && renderingFor != null && renderingFor == Minecraft.getInstance().getCameraEntity()) {
            e.setResult(Event.Result.DENY);
        }
    }
}
