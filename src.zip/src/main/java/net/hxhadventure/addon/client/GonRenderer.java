package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.hxhadventure.addon.GonEntity;

/** Draws Gon with the player model, and grows him to the vow's adult size (eased in and out by GonVowClient, the same as a player in the form). */
public class GonRenderer extends NpcPlayerRenderer<GonEntity> {
    public GonRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, g -> tex("gon"), g -> false);
        addLayer(new NpcAuraLayer<>(this, tex("greenaura_ten"), NpcAuraLayer.standard(GonEntity::nenFlags)));
    }

    @Override
    protected void setupRotations(GonEntity npc, PoseStack pose, float ageInTicks, float rotationYaw, float partialTick) {
        super.setupRotations(npc, pose, ageInTicks, rotationYaw, partialTick);
        float s = GonVowClient.scale(npc, partialTick);
        if (s != 1f) pose.scale(s, s, s); // the pose stack is at his feet here, so this grows him upwards
    }
}
