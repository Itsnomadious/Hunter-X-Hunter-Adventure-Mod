package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.hxhadventure.addon.ExamQuestions;
import net.hxhadventure.addon.HunterExam;
import net.hxhadventure.addon.WaterPuzzle;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketExamStartBattle;
import net.hxhadventure.addon.network.PacketExamSubmit;
import net.hxhadventure.entity.client.gui.HxhUi;

/**
 * The dialogue of the Hunter Exam NPCs (right-click them), drawn with HxhUi like Hina's.
 *
 * <ul>
 *   <li>Receptionist: welcomes you and asks whether you want to take part; on yes she sends you upstairs to the third floor.</li>
 *   <li>Menchi: before the first test is passed she sends you to Satotz; after it she explains the second, final test (a free-for-all) and, on yes,
 *       starts it (see ExamBattle).</li>
 *   <li>Satotz: explains the questionnaire and asks whether you want to take part. On yes he asks the ten questions one at a time and never says
 *       whether an answer is right; question 10 is the water-pouring minigame. The server grades everything and only the verdict comes back.</li>
 * </ul>
 */
public class ExamScreen extends Screen {
    private static final int HALF_W = 200;
    private static final int TEXT_W = HALF_W * 2 - 40;
    private static final int WATER = 0xFF3F76E4;
    private static final int PX_PER_LITRE = 9;
    private static final int BOX_W = 56;
    private static final int BOX_GAP = 36;

    private enum Page { SPEECH, QUESTION, PUZZLE, WAIT }

    private final int npcId;
    private final int kind;
    private final boolean passed;
    private final boolean secondPassed;
    private final boolean battleActive;
    private final boolean awakened;
    private final boolean hasKite;
    private final int kiteX, kiteY, kiteZ;

    private Page page = Page.SPEECH;
    private String speech = "";
    private String[] labels = new String[0];
    private Runnable[] actions = new Runnable[0];

    private int q;
    private final int[] answers = new int[ExamQuestions.COUNT];
    private final int[] level = new int[3];
    private final List<Byte> moves = new ArrayList<>();
    private int selected = -1;

    private int[] optY = new int[4];
    private int[] optH = new int[4];

    private Button nextBtn;
    private Button fillBtn;
    private Button emptyBtn;

    public ExamScreen(int npcId, int kind, boolean passed, boolean secondPassed, boolean battleActive,
                      boolean awakened, boolean hasKite, int kiteX, int kiteY, int kiteZ) {
        super(Component.literal("Hunter Exam"));
        this.npcId = npcId;
        this.kind = kind;
        this.passed = passed;
        this.secondPassed = secondPassed;
        this.battleActive = battleActive;
        this.awakened = awakened;
        this.hasKite = hasKite;
        this.kiteX = kiteX;
        this.kiteY = kiteY;
        this.kiteZ = kiteZ;
        Arrays.fill(answers, -1);
        opening();
    }

    // ------------------------------------------------------------------ dialogue

    private String speaker() {
        return switch (kind) {
            case HunterExam.KIND_MENCHI -> "MENCHI";
            case HunterExam.KIND_SATOTZ -> "SATOTZ";
            default -> "RECEPTIONIST";
        };
    }

    private String role() {
        return switch (kind) {
            case HunterExam.KIND_MENCHI -> "Single-Star Gourmet Hunter";
            case HunterExam.KIND_SATOTZ -> "Examiner";
            default -> "Hunter Exam Reception";
        };
    }

    private void say(String text, String[] labels, Runnable[] actions) {
        this.page = Page.SPEECH;
        this.speech = text;
        this.labels = labels;
        this.actions = actions;
        if (this.minecraft != null) rebuildWidgets();
    }

    private void sayThenClose(String text) {
        say(text, new String[] {"Goodbye"}, new Runnable[] {this::onClose});
    }

    /** What the NPC says when the screen opens. */
    private void opening() {
        switch (kind) {
            case HunterExam.KIND_MENCHI -> {
                if (passed && secondPassed) {
                    say("Well, if it isn't our newest Hunter. You earned that card, so don't go and lose it. And try to keep your head down out there.",
                        new String[] {"Continue"},
                        new Runnable[] {this::menchiAfter});
                } else if (passed && battleActive) {
                    sayThenClose("Why are you talking to me?! The test is still going. Fight!");
                } else if (passed) {
                    say("Hm? You got through Satotz's questionnaire? Good. Then you're mine now. "
                            + "We're short on staff this year, so I'm running the rest of the exam on my own.",
                        new String[] {"Continue"},
                        new Runnable[] {this::menchiBanned});
                } else {
                    sayThenClose("Hm? Are you here for the exam? Then you're talking to the wrong person. Go and speak to Satotz, the other one in this room. He's running the first test.");
                }
            }
            case HunterExam.KIND_SATOTZ -> {
                if (passed) {
                    sayThenClose("You have already passed my questionnaire. There is nothing more for you to answer here.");
                } else {
                    say("We are short on staff this year, and a great deal has happened, so this test will be a questionnaire. "
                            + "Do you wish to participate in my questionnaire?",
                        new String[] {"Yes, I will participate", "No"},
                        new Runnable[] {this::startQuestions, this::onClose});
                }
            }
            default -> {
                if (passed) {
                    sayThenClose("Welcome back! I see you have already passed the first test. Congratulations, and good luck with the rest of the exam.");
                } else {
                    say("Welcome to the Hunter Exam! Would you like to participate?",
                        new String[] {"Yes, I would like to participate", "No"},
                        new Runnable[] {
                            () -> sayThenClose("Wonderful! Please go upstairs to the third floor to partake in the exam. Good luck!"),
                            this::onClose});
                }
            }
        }
    }

    // ------------------------------------------------------------------ Menchi's test (the second, final test)

    /** After the final test: what she adds depends on whether Nen is awakened. She never says why. */
    private void menchiAfter() {
        if (awakened) {
            sayThenClose("Hm. You have already passed the secret stage of the test. There is nothing more I need from you.");
        } else if (hasKite) {
            sayThenClose("Go and find Kite. The nearest one is at X: " + kiteX + ", Y: " + kiteY + ", Z: " + kiteZ + ". Don't ask me why.");
        } else {
            sayThenClose("Go and find Kite. I can't tell you where the nearest one is right now. Don't ask me why.");
        }
    }

    private void menchiBanned() {
        say("Last time I made the test a little too hard. Apparently \"nobody could possibly pass\" is not an acceptable standard, "
                + "and now I've been banned from giving impossible tests ever again. So this time I'm keeping it simple.",
            new String[] {"Continue"},
            new Runnable[] {this::menchiRules});
    }

    private void menchiRules() {
        say("Everyone present is going to fight. I'll watch until I decide that the ones who remain should pass. "
                + "Once it starts there's no backing out. Do you accept?",
            new String[] {"Yes, I accept", "Not yet"},
            new Runnable[] {this::acceptBattle, this::onClose});
    }

    private void acceptBattle() {
        AddonNetwork.sendToServer(new PacketExamStartBattle(npcId));
        onClose();
    }

    // ------------------------------------------------------------------ questionnaire

    private void startQuestions() {
        Arrays.fill(answers, -1);
        q = 0;
        showQuestion();
    }

    private void showQuestion() {
        if (q == ExamQuestions.PUZZLE) {
            Arrays.fill(level, 0);
            moves.clear();
            selected = -1;
            page = Page.PUZZLE;
        } else {
            page = Page.QUESTION;
        }
        rebuildWidgets();
    }

    private void submit() {
        byte[] ans = new byte[ExamQuestions.COUNT];
        for (int i = 0; i < ans.length; i++) ans[i] = (byte) Math.max(0, answers[i]);
        byte[] mv = new byte[moves.size()];
        for (int i = 0; i < mv.length; i++) mv[i] = moves.get(i);
        AddonNetwork.sendToServer(new PacketExamSubmit(npcId, ans, mv));
        page = Page.WAIT;
        rebuildWidgets();
    }

    /** Called when the server's verdict arrives. Satotz only says whether you passed, never which answers were right. */
    public static void onResult(boolean passed) {
        if (Minecraft.getInstance().screen instanceof ExamScreen s) s.showResult(passed);
    }

    private void showResult(boolean passed) {
        if (passed) {
            sayThenClose("Thank you. Your answers have been assessed. Congratulations, you have passed the first test.");
        } else {
            sayThenClose("Thank you. Your answers have been assessed. I am afraid you have not passed. You may speak to me again if you wish to try once more.");
        }
    }

    // ------------------------------------------------------------------ layout

    private int top(int height) {
        return Math.max(12, this.height / 2 - height / 2);
    }

    private int speechHeight() {
        return 36 + HxhUi.wrapHeight(this.font, speech, TEXT_W) + 14 + labels.length * 24 + 8;
    }

    /** Fills optY / optH (y of each option box relative to the screen) for the current question and returns the panel's content height. */
    private int layoutQuestion() {
        ExamQuestions.Q qq = ExamQuestions.ALL[q];
        int promptH = HxhUi.wrapHeight(this.font, qq.prompt, TEXT_W);
        int total = 34 + promptH + 10;
        int[] rel = new int[qq.options.length];
        int[] hh = new int[qq.options.length];
        for (int i = 0; i < qq.options.length; i++) {
            hh[i] = HxhUi.wrapHeight(this.font, "A) " + qq.options[i], TEXT_W - 16) + 8;
            rel[i] = total;
            total += hh[i] + 4;
        }
        total += 8 + 20 + 14;
        int top = top(total);
        optY = new int[qq.options.length];
        optH = hh;
        for (int i = 0; i < rel.length; i++) optY[i] = top + rel[i];
        return total;
    }

    /** {prompt y, help y, box baseline y, button row 1 y, button row 2 y, content height} for the water puzzle, relative to the content top. */
    private int[] puzzleLayout() {
        int promptH = HxhUi.wrapHeight(this.font, ExamQuestions.ALL[ExamQuestions.PUZZLE].prompt, TEXT_W);
        int helpH = HxhUi.wrapHeight(this.font, ExamQuestions.PUZZLE_HELP, TEXT_W);
        int promptY = 34;
        int helpY = promptY + promptH + 6;
        int base = helpY + helpH + 8 + WaterPuzzle.CAP[0] * PX_PER_LITRE + 2;
        int row1 = base + 24;
        int row2 = row1 + 24;
        return new int[] {promptY, helpY, base, row1, row2, row2 + 20 + 14};
    }

    private int boxX(int i, int cx) {
        int total = 3 * BOX_W + 2 * BOX_GAP;
        return cx - total / 2 + i * (BOX_W + BOX_GAP);
    }

    private int boxH(int i) {
        return WaterPuzzle.CAP[i] * PX_PER_LITRE + 2;
    }

    // ------------------------------------------------------------------ widgets

    @Override
    protected void init() {
        int cx = this.width / 2;
        nextBtn = null;
        fillBtn = null;
        emptyBtn = null;
        switch (page) {
            case SPEECH -> {
                int h = speechHeight();
                int top = top(h);
                for (int i = 0; i < labels.length; i++) {
                    final int idx = i;
                    int y = top + h - 8 - 20 - 24 * (labels.length - 1 - i);
                    addRenderableWidget(HxhUi.button(cx - 150, y, 300, 20, labels[i], b -> actions[idx].run(), i == 0 && labels.length > 1));
                }
            }
            case QUESTION -> {
                int h = layoutQuestion();
                int top = top(h);
                nextBtn = addRenderableWidget(HxhUi.button(cx - 70, top + h - 34, 140, 20, "Next", b -> {
                    q++;
                    showQuestion();
                }, true));
                nextBtn.active = answers[q] >= 0;
            }
            case PUZZLE -> {
                int[] pl = puzzleLayout();
                int top = top(pl[5]);
                fillBtn = addRenderableWidget(HxhUi.button(cx - 155, top + pl[3], 100, 20, "Fill", b -> act(WaterPuzzle.fill(selected)), false));
                emptyBtn = addRenderableWidget(HxhUi.button(cx - 50, top + pl[3], 100, 20, "Empty", b -> act(WaterPuzzle.empty(selected)), false));
                addRenderableWidget(HxhUi.button(cx + 55, top + pl[3], 100, 20, "Reset", b -> {
                    Arrays.fill(level, 0);
                    moves.clear();
                    selected = -1;
                    refreshPuzzleButtons();
                }, false));
                addRenderableWidget(HxhUi.button(cx - 80, top + pl[4], 160, 20, "Submit answer", b -> submit(), true));
                refreshPuzzleButtons();
            }
            case WAIT -> {
            }
        }
    }

    private void refreshPuzzleButtons() {
        if (fillBtn != null) fillBtn.active = selected >= 0;
        if (emptyBtn != null) emptyBtn.active = selected >= 0;
    }

    /** One puzzle move: applied to the containers and remembered so the server can replay it. */
    private void act(int move) {
        if (selected < 0 && move < 6) return;
        if (moves.size() < WaterPuzzle.MAX_MOVES && WaterPuzzle.apply(level, move)) {
            moves.add((byte) move);
        }
        selected = -1;
        refreshPuzzleButtons();
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button != 0) return false;
        int cx = this.width / 2;
        if (page == Page.QUESTION) {
            layoutQuestion();
            int x0 = cx - TEXT_W / 2;
            for (int i = 0; i < optY.length; i++) {
                if (mx >= x0 && mx < x0 + TEXT_W && my >= optY[i] && my < optY[i] + optH[i]) {
                    answers[q] = i;
                    if (nextBtn != null) nextBtn.active = true;
                    return true;
                }
            }
        } else if (page == Page.PUZZLE) {
            int[] pl = puzzleLayout();
            int top = top(pl[5]);
            for (int i = 0; i < 3; i++) {
                int bx = boxX(i, cx);
                int by = top + pl[2] - boxH(i);
                if (mx >= bx && mx < bx + BOX_W && my >= by && my < top + pl[2]) {
                    if (selected < 0) {
                        selected = i;
                    } else if (selected == i) {
                        selected = -1;
                    } else {
                        act(WaterPuzzle.pour(selected, i));
                    }
                    refreshPuzzleButtons();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        HxhUi.backdrop(g, this.width, this.height);
        int cx = this.width / 2;
        int x0 = cx - TEXT_W / 2;
        switch (page) {
            case SPEECH -> {
                int h = speechHeight();
                int top = top(h);
                HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, h + 8);
                HxhUi.title(g, this.font, speaker(), cx, top);
                HxhUi.subtitle(g, this.font, role(), cx, top + 14);
                HxhUi.wrap(g, this.font, speech, x0, top + 36, TEXT_W, HxhUi.TEXT_DIM);
            }
            case QUESTION -> {
                int h = layoutQuestion();
                int top = top(h);
                ExamQuestions.Q qq = ExamQuestions.ALL[q];
                HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, h + 8);
                HxhUi.title(g, this.font, "QUESTION " + (q + 1) + " OF " + ExamQuestions.COUNT, cx, top);
                HxhUi.subtitle(g, this.font, qq.category.toUpperCase(), cx, top + 14);
                HxhUi.wrap(g, this.font, qq.prompt, x0, top + 34, TEXT_W, HxhUi.TEXT);
                for (int i = 0; i < qq.options.length; i++) {
                    boolean sel = answers[q] == i;
                    boolean hover = mouseX >= x0 && mouseX < x0 + TEXT_W && mouseY >= optY[i] && mouseY < optY[i] + optH[i];
                    HxhUi.inset(g, x0, optY[i], TEXT_W, optH[i]);
                    if (sel) HxhUi.frame(g, x0, optY[i], TEXT_W, optH[i], HxhUi.GOLD);
                    else if (hover) HxhUi.frame(g, x0, optY[i], TEXT_W, optH[i], HxhUi.GOLD_DIM);
                    HxhUi.wrap(g, this.font, (char) ('A' + i) + ") " + qq.options[i], x0 + 8, optY[i] + 4, TEXT_W - 16, sel ? HxhUi.GOLD : HxhUi.TEXT);
                }
            }
            case PUZZLE -> {
                int[] pl = puzzleLayout();
                int top = top(pl[5]);
                HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, pl[5] + 8);
                HxhUi.title(g, this.font, "QUESTION " + (ExamQuestions.PUZZLE + 1) + " OF " + ExamQuestions.COUNT, cx, top);
                HxhUi.subtitle(g, this.font, ExamQuestions.ALL[ExamQuestions.PUZZLE].category.toUpperCase(), cx, top + 14);
                HxhUi.wrap(g, this.font, ExamQuestions.ALL[ExamQuestions.PUZZLE].prompt, x0, top + pl[0], TEXT_W, HxhUi.TEXT);
                HxhUi.wrap(g, this.font, ExamQuestions.PUZZLE_HELP, x0, top + pl[1], TEXT_W, HxhUi.TEXT_DIM);
                int baseY = top + pl[2];
                for (int i = 0; i < 3; i++) {
                    int bx = boxX(i, cx);
                    int bh = boxH(i);
                    int by = baseY - bh;
                    HxhUi.inset(g, bx, by, BOX_W, bh);
                    if (level[i] > 0) {
                        g.fill(bx + 1, baseY - 1 - level[i] * PX_PER_LITRE, bx + BOX_W - 1, baseY - 1, WATER);
                    }
                    if (selected == i) HxhUi.frame(g, bx - 2, by - 2, BOX_W + 4, bh + 4, HxhUi.GOLD);
                    g.drawCenteredString(this.font, level[i] + " / " + WaterPuzzle.CAP[i] + " L", bx + BOX_W / 2, baseY + 4,
                        selected == i ? HxhUi.GOLD : HxhUi.TEXT);
                }
            }
            case WAIT -> {
                int h = 70;
                int top = top(h);
                HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, h + 8);
                HxhUi.title(g, this.font, "SATOTZ", cx, top);
                HxhUi.subtitle(g, this.font, "Examiner", cx, top + 14);
                HxhUi.wrap(g, this.font, "Thank you. Please wait while I assess your answers...", x0, top + 36, TEXT_W, HxhUi.TEXT_DIM);
            }
        }
        super.render(g, mouseX, mouseY, partial);
    }
}
