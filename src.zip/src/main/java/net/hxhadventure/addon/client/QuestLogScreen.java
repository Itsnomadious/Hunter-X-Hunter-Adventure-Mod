package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.hxhadventure.addon.quest.Quest;
import net.hxhadventure.addon.quest.QuestData;
import net.hxhadventure.addon.quest.Quests;
import net.hxhadventure.entity.client.gui.HxhUi;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

/**
 * Page 4 of the O menu: the quests you currently have active (up to {@link QuestData#MAX_ACTIVE}) with the progress of every objective.
 * One class for both looks: {@code hunter} picks the Hunter licence style or the classic dark/gold one. Scrolls with the wheel or the arrow buttons.
 * Quests are accepted, handed in and abandoned at a Hunter laptop; this page only shows them.
 */
public class QuestLogScreen extends Screen {
    private static final int HALF_W = 172;
    private static final int MIN_PANEL_H = 276;
    private static final int MAX_PANEL_H = 420;
    private static final int TEXT_W = 276;
    private static final int LINE_H = 10;

    private record Line(FormattedCharSequence text, int color) {}

    private final boolean hunter;
    private final List<Line> lines = new ArrayList<>();
    private int scroll;

    public QuestLogScreen(boolean hunter) {
        super(Component.literal("Active Quests"));
        this.hunter = hunter;
    }

    // ---- style helpers
    private int cTitle() { return hunter ? HunterUi.NAVY : HxhUi.GOLD; }
    private int cText() { return hunter ? HunterUi.INK : HxhUi.TEXT; }
    private int cDim() { return hunter ? HunterUi.INK_DIM : HxhUi.TEXT_DIM; }
    private int cGood() { return hunter ? HunterUi.GREEN : HxhUi.GREEN; }

    private Button button(int x, int y, int w, int h, String label, Button.OnPress press, boolean primary) {
        return hunter ? HunterUi.button(x, y, w, h, label, press, primary) : HxhUi.button(x, y, w, h, label, press, primary);
    }

    private void go(Screen next) {
        if (hunter) HunterUi.go(next);
        else Minecraft.getInstance().setScreen(next);
    }

    // ---- layout
    private int panelH() {
        return Math.max(MIN_PANEL_H, Math.min(this.height - 16, MAX_PANEL_H));
    }

    private int top() {
        return Math.max(12, this.height / 2 - panelH() / 2 + 8);
    }

    private int viewH() {
        return panelH() - 44 - 40;
    }

    private int viewLines() {
        return Math.max(4, viewH() / LINE_H);
    }

    private int maxScroll() {
        return Math.max(0, lines.size() - viewLines());
    }

    private void add(String text, int color, int width) {
        for (FormattedCharSequence part : this.font.split(Component.literal(text), width)) lines.add(new Line(part, color));
    }

    private void build() {
        lines.clear();
        for (QuestData.Active a : ClientQuests.active()) {
            Quest q = Quests.get(a.id);
            if (q == null) continue;
            boolean ready = QuestData.isComplete(q, a);
            add(q.title.toUpperCase(java.util.Locale.ROOT), cTitle(), TEXT_W);
            add("   " + q.category.title + "  -  difficulty " + q.tier, cDim(), TEXT_W);
            for (int i = 0; i < q.objectives.size(); i++) {
                Quest.Objective o = q.objectives.get(i);
                int have = i < a.progress.length ? Math.min(o.count, a.progress[i]) : 0;
                boolean done = have >= o.count;
                String mark = done ? "[x] " : "[ ] ";
                String text = mark + o.type.verb + " " + o.label + (o.count > 1 || !done ? "  " + have + "/" + o.count : "");
                add("   " + text, done ? cGood() : cText(), TEXT_W - 8);
            }
            if (ready) add("   Ready to hand in at a Hunter laptop.", cGood(), TEXT_W);
            lines.add(new Line(FormattedCharSequence.EMPTY, 0));
        }
    }

    @Override
    protected void init() {
        build();
        scroll = Math.max(0, Math.min(scroll, maxScroll()));
        int cx = this.width / 2;
        int top = top();
        int by = top + panelH() - 44;
        addRenderableWidget(button(cx + 134, top + 40, 26, 16, "^", b -> scroll = Math.max(0, scroll - 3), false));
        addRenderableWidget(button(cx + 134, top + 40 + viewH() - 16, 26, 16, "v", b -> scroll = Math.min(maxScroll(), scroll + 3), false));
        addRenderableWidget(button(cx - 160, by, 80, 20, "< Page 3", b -> go(OMenu.page(OMenu.Page.ACTIVE)), false));
        addRenderableWidget(button(cx - 40, by, 80, 20, "Close", b -> onClose(), true));
        OMenu.addSide(this::addRenderableWidget, this.width, top() - 8, hunter, OMenu.Page.QUESTS);
    }

    @Override
    public void tick() {
        // progress can change while the page is open (a kill, a pickup handed in): rebuild from the latest log
        int before = lines.size();
        build();
        if (lines.size() != before) scroll = Math.max(0, Math.min(scroll, maxScroll()));
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + (delta < 0 ? 2 : -2)));
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        int cx = this.width / 2;
        int top = top();
        boolean flipping = false;
        if (hunter) {
            HunterUi.backdrop(g, this.width, this.height);
            flipping = HunterUi.flipBegin(g, cx);
            HunterUi.back(g, cx - HALF_W, top - 8, HALF_W * 2, panelH() + 10, 16);
            HunterUi.title(g, this.font, "ACTIVE QUESTS", cx, top);
        } else {
            HxhUi.backdrop(g, this.width, this.height);
            HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, panelH());
            HxhUi.title(g, this.font, "ACTIVE QUESTS", cx, top);
        }
        int n = ClientQuests.active().size();
        String sub = n == 0 ? "No active quests. Accept some at a Hunter laptop." : n + " / " + QuestData.MAX_ACTIVE + " active";
        if (hunter) {
            HunterUi.subtitle(g, this.font, sub, cx, top + 18);
            HunterUi.inset(g, cx - 160, top + 36, 320, viewH() + 8);
        } else {
            HxhUi.subtitle(g, this.font, sub, cx, top + 18);
            HxhUi.inset(g, cx - 160, top + 36, 320, viewH() + 8);
        }
        int rows = viewLines();
        for (int i = 0; i < rows && scroll + i < lines.size(); i++) {
            Line l = lines.get(scroll + i);
            g.drawString(this.font, l.text(), cx - 154, top + 42 + i * LINE_H, l.color() == 0 ? 0xFFFFFFFF : l.color(), false);
        }
        super.render(g, mouseX, mouseY, partial);
        if (hunter) HunterUi.flipEnd(g, flipping);
    }
}
