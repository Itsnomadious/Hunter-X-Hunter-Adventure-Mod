package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.hxhadventure.addon.HxHEntities;
import net.hxhadventure.addon.KurapikaEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Adds the scarlet Emperor Time eyes (the player version's texture) to the Kurapika NPC's renderer. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class KurapikaClientEvents {
    private KurapikaClientEvents() {}

    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers e) {
        NenFighterRenderer<KurapikaEntity> r = e.getRenderer(HxHEntities.KURAPIKA.get());
        if (r != null) r.addLayer(new EyesLayer(r));
    }

    static final class EyesLayer extends RenderLayer<KurapikaEntity, NpcModel<KurapikaEntity>> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/emperor_eyes.png");

        EyesLayer(RenderLayerParent<KurapikaEntity, NpcModel<KurapikaEntity>> parent) {
            super(parent);
        }

        @Override
        public void render(PoseStack pose, MultiBufferSource buffer, int light, KurapikaEntity npc, float limbSwing, float limbSwingAmount,
                           float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
            if (!npc.emperorEyes() || npc.isInvisible()) return;
            VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucentEmissive(TEXTURE));
            getParentModel().head.render(pose, vc, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
        }
    }
}
