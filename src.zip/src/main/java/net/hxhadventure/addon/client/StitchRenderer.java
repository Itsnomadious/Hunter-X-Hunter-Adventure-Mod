package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.ClientAddonState;
import net.hxhadventure.addon.NenStitchesTuning;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Draws Machi's Nen Stitches: a single thread is a hair-thin, near-white strand inside a faint blue-white glow (like the anime's), drawn as
 * camera-facing ribbons added together (RenderType.lightning), so no texture is needed.
 * <ul>
 *   <li>Trap threads: straight and taut between their two anchors, drawn only for someone with Gyo on (and a thread being placed, to its owner).</li>
 *   <li>Slashes: a bright crescent where the hand swung, and streaks of thread flying out across the area that was cut.</li>
 *   <li>Binds: threads winding up the body of whoever is tied up, and a taut thread back to the user's hand.</li>
 *   <li>Wound Sewing: threads from both hands darting to the wound in short stitches.</li>
 * </ul>
 * In hides the slashes, binds and sewing of its user from anyone without Gyo, like the other Nen constructs (see InFx).
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class StitchRenderer {
    private StitchRenderer() {}

    /** Thread layers, outermost first: full width in blocks, then red, green, blue, alpha. */
    private static final double[][] LAYERS = {
        {0.090, 140, 185, 255, 26},
        {0.055, 185, 215, 255, 64},
        {0.030, 225, 240, 255, 140},
        {0.012, 255, 255, 255, 255},
    };
    private static final int SIDES = 10;

    /** Everything a drawing helper needs. */
    private static final class Ctx {
        Minecraft mc;
        ClientLevel level;
        Matrix4f m;
        VertexConsumer vc;
        Vec3 cam, left, up;
        double time;
        float pt;
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || StitchFx.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        Camera camera = e.getCamera();
        Ctx c = new Ctx();
        c.mc = mc;
        c.level = mc.level;
        c.pt = e.getPartialTick();
        c.time = mc.level.getGameTime() + c.pt;
        c.cam = camera.getPosition();
        c.m = e.getPoseStack().last().pose();
        Vector3f l = camera.getLeftVector();
        Vector3f u = camera.getUpVector();
        c.left = new Vec3(l.x(), l.y(), l.z());
        c.up = new Vec3(u.x(), u.y(), u.z());
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.lightning();
        c.vc = buf.getBuffer(type);

        traps(c);
        pending(c);
        slashes(c);
        binds(c);
        sews(c);
        snaps(c);
        buf.endBatch(type);
    }

    // ---------------------------------------------------------------- trap threads

    private static void traps(Ctx c) {
        boolean gyo = ClientAddonState.gyo;
        int me = c.mc.player.getId();
        double far = 160.0 * 160.0;
        for (StitchFx.Trap t : StitchFx.traps().values()) {
            if (!gyo && !(t.owner == me && NenStitchesTuning.OWNER_SEES_TRAPS)) continue; // invisible unless the viewer uses Gyo
            if (t.a.distanceToSqr(c.cam) > far && t.b.distanceToSqr(c.cam) > far) continue;
            double pulse = 0.78 + 0.22 * Math.sin(c.time * 0.25 + t.id);
            thread(c, line(c, t.a, t.b, 0, 0, t.id), 1.15, pulse);
            glow(c, t.a, 0.11, pulse);
            glow(c, t.b, 0.11, pulse);
        }
    }

    /** The first anchor of the thread being placed, and a faint thread from it to where the user is looking (only its owner gets this). */
    private static void pending(Ctx c) {
        Vec3 a = StitchFx.pending();
        if (a == null) return;
        HitResult hr = c.mc.player.pick(NenStitchesTuning.TRAP_PLACE_RANGE, c.pt, false);
        Vec3 b = hr.getLocation();
        double pulse = 0.5 + 0.2 * Math.sin(c.time * 0.5);
        if (a.distanceToSqr(b) > 0.04) thread(c, line(c, a, b, 0, 0, 7.0), 0.9, pulse);
        glow(c, a, 0.13 + 0.03 * Math.sin(c.time * 0.5), 0.9);
    }

    // ---------------------------------------------------------------- slashes

    private static void slashes(Ctx c) {
        for (StitchFx.Slash s : StitchFx.slashes()) {
            if (InFx.hiddenFrom(s.owner)) continue;
            double age = c.time - s.t0;
            double life = s.life();
            if (age < 0 || age > life) continue;
            Vec3 f = new Vec3(s.fx, 0, s.fz);
            Vec3 r = new Vec3(-s.fz, 0, s.fx);
            double side = s.left ? -1 : 1;
            boolean strong = s.kind == 1;

            // the crescent where the hand swung: from high on the hand's side to low on the other, bulging forward
            double head = -1 + 2 * Math.min(1, age / (life * 0.4));
            double tail = Math.max(-1, head - 1.1);
            if (head > tail) {
                int n = 14;
                Vec3[] arc = new Vec3[n];
                for (int i = 0; i < n; i++) {
                    double u = Mth.lerp(i / (double) (n - 1), tail, head);
                    Vec3 p = s.origin.add(f.scale((strong ? 1.8 : 1.3) + 0.6 * (1 - u * u)))
                        .add(r.scale(side * -u * (strong ? 2.0 : 1.5)))
                        .add(0, -u * (strong ? 1.3 : 1.0), 0);
                    arc[i] = p.subtract(c.cam);
                }
                double fade = 1.0 - Math.max(0, (age - life * 0.4) / (life * 0.6));
                thread(c, arc, strong ? 3.0 : s.kind == 2 ? 1.8 : 2.4, Math.max(0.05, fade));
            }

            // streaks of thread flying out over the whole area that was cut
            int n = strong ? 13 : s.kind == 2 ? 6 : 9;
            for (int i = 0; i < n; i++) {
                double q = i / (double) (n - 1);
                double p = (age - q * life * 0.35) / (life * 0.6);
                if (p < 0 || p > 1) continue;
                double order = s.left ? 1 - q : q; // a right-hand slash sweeps from the right and high to the left and low
                double lateral = Mth.lerp(order, s.width * 0.5, -s.width * 0.5);
                double height = Mth.lerp(order, 1.3, -1.0);
                Vec3 end = s.origin.add(f.scale(s.length)).add(r.scale(lateral)).add(0, height, 0);
                double headF = 1 - Math.pow(1 - Math.min(1, p * 1.7), 3);
                double tailF = Math.max(0, p * 1.5 - 0.5);
                if (tailF >= headF) continue;
                int pts = 10;
                Vec3[] line = new Vec3[pts];
                for (int j = 0; j < pts; j++) {
                    double fr = Mth.lerp(j / (double) (pts - 1), tailF, headF);
                    double bow = Math.sin(fr * Math.PI) * 0.22 * Math.sin(i * 2.1 + 0.7);
                    line[j] = s.origin.add(end.subtract(s.origin).scale(fr)).add(0, bow, 0).subtract(c.cam);
                }
                thread(c, line, strong ? 1.9 : 1.5, 1 - p * p);
            }
            if (age < 3) glow(c, s.origin, 0.3 * (1 - age / 3.0) + 0.08, 1.0);
        }
    }

    // ---------------------------------------------------------------- binds

    private static void binds(Ctx c) {
        for (StitchFx.Bind b : StitchFx.binds().values()) {
            if (InFx.hiddenFrom(b.owner)) continue;
            Entity target = c.level.getEntity(b.target);
            if (target == null || target.isRemoved()) continue;
            double grow = Math.min(1, (c.time - b.t0) / 8.0);
            Vec3 tp = target.getPosition(c.pt);
            double h = target.getBbHeight();
            double rad = target.getBbWidth() * 0.55 + 0.12;
            int steps = 16;
            for (int k = 0; k < 4; k++) { // four strands winding up the body, tighter and tighter
                Vec3[] pts = new Vec3[steps + 1];
                for (int j = 0; j <= steps; j++) {
                    double f = j / (double) steps;
                    double ang = k * Math.PI / 2 + f * Math.PI * 5 + c.time * 0.07 * (k % 2 == 0 ? 1 : -1);
                    double rr = rad * (1 + 0.06 * Math.sin(c.time * 0.4 + f * 9 + k));
                    pts[j] = tp.add(Math.cos(ang) * rr, f * h * grow, Math.sin(ang) * rr).subtract(c.cam);
                }
                thread(c, pts, 1.1, 0.9);
            }
            Entity owner = c.level.getEntity(b.owner);
            if (owner != null && !owner.isRemoved()) { // the taut thread from the user's hand
                Vec3 hand = hand(c, owner, false);
                Vec3 mid = tp.add(0, h * 0.55, 0);
                if (hand.distanceToSqr(mid) > 0.25) thread(c, line(c, hand, mid, 0, 0.03, b.target * 0.7), 1.3, 0.85);
                glow(c, hand, 0.09, 0.9);
            }
        }
    }

    // ---------------------------------------------------------------- Wound Sewing

    private static void sews(Ctx c) {
        long seed = (long) (c.time / 2.0); // the stitches jump to new places every two ticks
        for (StitchFx.Sew s : StitchFx.sews().values()) {
            if (InFx.hiddenFrom(s.owner)) continue;
            Entity owner = c.level.getEntity(s.owner);
            if (owner == null || owner.isRemoved()) continue;
            Entity target = s.target >= 0 ? c.level.getEntity(s.target) : null;
            double in = Math.min(1, (c.time - s.t0) / 3.0);
            for (int side = 0; side < 2; side++) {
                Vec3 hp = hand(c, owner, side == 1);
                for (int k = 0; k < 4; k++) {
                    long h = seed * 131 + k * 17 + side * 7 + s.owner;
                    Vec3 end;
                    if (target != null && !target.isRemoved()) {
                        Vec3 tp = target.getPosition(c.pt);
                        double w = target.getBbWidth(), hh = target.getBbHeight();
                        end = tp.add((rnd(h) - 0.5) * w * 0.8, hh * (0.2 + 0.65 * rnd(h + 1)), (rnd(h + 2) - 0.5) * w * 0.8);
                    } else { // no one in sight: threads flutter in the air in front of the hands
                        Vec3 f = Vec3.directionFromRotation(0, owner.getViewYRot(c.pt));
                        end = hp.add(f.scale(0.5 + 0.4 * rnd(h))).add((rnd(h + 1) - 0.5) * 0.7, (rnd(h + 2) - 0.5) * 0.5, (rnd(h + 3) - 0.5) * 0.7);
                    }
                    Vec3[] pts = stitch(c, hp, end, 9, 0.07, h);
                    thread(c, pts, 1.0, 0.9 * in);
                    glow(c, end, 0.05, 0.8 * in);
                }
                glow(c, hp, 0.07 + 0.02 * Math.sin(c.time * 1.3 + side), 0.9 * in);
            }
        }
    }

    // ---------------------------------------------------------------- a cut thread

    private static void snaps(Ctx c) {
        for (StitchFx.Snap s : StitchFx.snaps()) {
            double age = c.time - s.t0;
            if (age < 0 || age > StitchFx.SNAP_TICKS) continue;
            double p = age / StitchFx.SNAP_TICKS;
            for (int k = 0; k < 8; k++) {
                double a = Math.PI * 2 * k / 8 + 0.3;
                double e = ((k % 3) - 1) * 0.5;
                Vec3 dir = new Vec3(Math.cos(a) * Math.cos(e), Math.sin(e), Math.sin(a) * Math.cos(e));
                double r0 = 0.15 + p * 0.5, r1 = r0 + 0.25 + p * 0.8;
                Vec3[] pts = {s.at.add(dir.scale(r0)).subtract(c.cam), s.at.add(dir.scale(r1)).subtract(c.cam)};
                thread(c, pts, 1.2, 1 - p);
            }
            glow(c, s.at, 0.35 * (1 - p) + 0.05, 1 - p);
        }
    }

    // ---------------------------------------------------------------- helpers

    /** Where a hand is: out in front of the chest, a little to each side (lower in first person, where the real arms are not drawn). */
    private static Vec3 hand(Ctx c, Entity owner, boolean left) {
        Vec3 f = Vec3.directionFromRotation(0, owner.getViewYRot(c.pt));
        Vec3 r = new Vec3(-f.z, 0, f.x);
        boolean firstPerson = owner == c.mc.player && c.mc.options.getCameraType().isFirstPerson();
        double height = owner.getEyeHeight() * (firstPerson ? 0.62 : 0.72);
        return owner.getPosition(c.pt).add(0, height, 0).add(f.scale(firstPerson ? 0.55 : 0.5)).add(r.scale(left ? -0.3 : 0.3));
    }

    /** A pseudo-random number in [0, 1) from a seed. */
    private static double rnd(long x) {
        x *= 0x9E3779B97F4A7C15L;
        x ^= x >>> 29;
        x *= 0xBF58476D1CE4E5B9L;
        x ^= x >>> 32;
        return (x & 0xFFFFFF) / (double) 0x1000000;
    }

    /** A thread from a to b, camera-relative. With sag it hangs a little; with ripple it trembles. Straight when both are 0. */
    private static Vec3[] line(Ctx c, Vec3 a, Vec3 b, double sag, double ripple, double seed) {
        double len = a.distanceTo(b);
        int n = (int) Math.max(2, Math.min(48, Math.ceil(len / 0.8) + 1));
        Vec3[] out = new Vec3[n];
        for (int i = 0; i < n; i++) {
            double f = i / (double) (n - 1);
            double dy = -sag * 4 * f * (1 - f) + ripple * Math.sin(f * Math.PI) * Math.sin(c.time * 0.55 + f * 10 + seed);
            out[i] = a.lerp(b, f).add(0, dy, 0).subtract(c.cam);
        }
        return out;
    }

    /** A thread that goes from a to b in short stitches (a zig-zag that dies away at both ends), camera-relative. */
    private static Vec3[] stitch(Ctx c, Vec3 a, Vec3 b, int n, double amp, long seed) {
        Vec3 d = b.subtract(a);
        Vec3 side = d.cross(new Vec3(0, 1, 0));
        side = side.lengthSqr() < 1.0e-6 ? new Vec3(1, 0, 0) : side.normalize();
        Vec3[] out = new Vec3[n];
        for (int i = 0; i < n; i++) {
            double f = i / (double) (n - 1);
            double z = (i % 2 == 0 ? 1 : -1) * amp * Math.sin(f * Math.PI) * (0.6 + 0.8 * rnd(seed + i * 5L));
            out[i] = a.add(d.scale(f)).add(side.scale(z)).subtract(c.cam);
        }
        return out;
    }

    /** The thread along camera-relative points: a white core inside faint layers of blue-white glow. */
    private static void thread(Ctx c, Vec3[] p, double widthScale, double alpha) {
        if (p.length < 2) return;
        for (double[] layer : LAYERS) {
            ribbon(c, p, layer[0] * widthScale, (int) layer[1], (int) layer[2], (int) layer[3], (int) Math.max(1, layer[4] * Math.min(1, alpha)));
        }
    }

    private static void ribbon(Ctx c, Vec3[] p, double width, int r, int g, int b, int a) {
        int n = p.length;
        Vec3[] lo = new Vec3[n];
        Vec3[] hi = new Vec3[n];
        for (int i = 0; i < n; i++) {
            Vec3 t = i == 0 ? p[1].subtract(p[0]) : i == n - 1 ? p[i].subtract(p[i - 1]) : p[i + 1].subtract(p[i - 1]);
            Vec3 side = t.cross(p[i]); // p[i] is camera-relative, so it is the view direction: the ribbon faces the camera
            side = side.lengthSqr() < 1.0e-8 ? new Vec3(0, 1, 0) : side.normalize();
            double w = width * 0.5 * (1.0 + 0.10 * Math.sin(c.time * 0.9 + i * 1.7));
            lo[i] = p[i].add(side.scale(w));
            hi[i] = p[i].subtract(side.scale(w));
        }
        for (int i = 0; i < n - 1; i++) {
            vertex(c, lo[i], r, g, b, a);
            vertex(c, hi[i], r, g, b, a);
            vertex(c, hi[i + 1], r, g, b, a);
            vertex(c, lo[i + 1], r, g, b, a);
        }
    }

    /** A round glow facing the camera, at a world position. */
    private static void glow(Ctx c, Vec3 world, double radius, double alpha) {
        Vec3 centre = world.subtract(c.cam);
        double[][] discs = {{1.0, 140, 185, 255, 40}, {0.62, 200, 225, 255, 100}, {0.3, 255, 255, 255, 210}};
        for (double[] d : discs) {
            int a = (int) Math.max(1, d[4] * Math.min(1, alpha));
            double rad = radius * d[0];
            Vec3 prev = centre.add(c.left.scale(rad));
            for (int k = 1; k <= SIDES; k++) {
                double th = 2 * Math.PI * k / SIDES;
                Vec3 cur = centre.add(c.left.scale(Math.cos(th) * rad)).add(c.up.scale(Math.sin(th) * rad));
                vertex(c, centre, (int) d[1], (int) d[2], (int) d[3], a);
                vertex(c, prev, (int) d[1], (int) d[2], (int) d[3], a);
                vertex(c, cur, (int) d[1], (int) d[2], (int) d[3], a);
                vertex(c, centre, (int) d[1], (int) d[2], (int) d[3], a);
                prev = cur;
            }
        }
    }

    private static void vertex(Ctx c, Vec3 p, int r, int g, int b, int a) {
        c.vc.vertex(c.m, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, a).endVertex();
    }
}
