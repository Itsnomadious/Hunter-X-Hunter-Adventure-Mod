package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Feitan's Pain Packer armour, built piece by piece rather than stretched over the skin:
 * <ul>
 *   <li><b>head:</b> a crimson hood with a pale eye slit and a cream strip down the mask, a stepped pointed hat with a cream stripe,
 *       the winged crest on the brow, and two wide horns sweeping out from the sides;</li>
 *   <li><b>body:</b> a cream coat with the red cross, the black X harness with its ring, a red belt with a spoked wheel, gold spikes,
 *       and the black rod hanging down the front;</li>
 *   <li><b>arms:</b> puffed red shoulders, sleeves, black buckled bands, big red mitts;</li>
 *   <li><b>legs:</b> the long coat in two flared halves that swing with the legs, red teeth along the hem, brown boots.</li>
 * </ul>
 * Everything is cut from one atlas painted by {@code tools/make_pain_armor.py} (see {@link PainArmorAtlas}). While the wearer's Rising Sun
 * burns, a second pass in the glow twin of the atlas makes the armour shine white-hot, pulsing.
 */
public class PainArmorLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/pain_packer_armor.png");
    private static final ResourceLocation GLOW = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/pain_packer_armor_glow.png");

    private static final float PX = 1.0f / 16.0f;

    // cells of the swatch region (2 x 2 pixels each, four across)
    private static final int RED = 0, RED_D = 1, RED_L = 2, CREAM = 3, GOLD = 4, GOLD_D = 5, NAVY = 6, METAL = 7;

    public PainArmorLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffer, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (!PainFx.hasArmor(player.getId()) || player.isInvisible() || player.isSpectator()) return;
        PlayerModel<AbstractClientPlayer> m = getParentModel();
        boolean slim = "slim".equals(player.getModelName());

        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0f);
        drawAll(pose, m, new Draw(vc, light, overlay, 255), slim);

        // the user's sun is burning: the armour shines through, pulsing
        if (PainFx.isHeated(player.getId())) {
            float pulse = 0.65f + 0.35f * Mth.sin(ageInTicks * 0.25f);
            VertexConsumer glow = buffer.getBuffer(RenderType.entityTranslucentEmissive(GLOW));
            drawAll(pose, m, new Draw(glow, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, (int) (255 * pulse)), slim);
        }
    }

    // ------------------------------------------------------------------ what we draw into

    /** The vertex sink and the matrices of the part being drawn. */
    private static final class Draw {
        final VertexConsumer vc;
        final int light, overlay, alpha;
        Matrix4f mat;
        Matrix3f nrm;

        Draw(VertexConsumer vc, int light, int overlay, int alpha) {
            this.vc = vc;
            this.light = light;
            this.overlay = overlay;
            this.alpha = alpha;
        }

        /** Take the matrices from the pose as it stands; all coordinates after this are in pixels. */
        void use(PoseStack pose) {
            this.mat = pose.last().pose();
            this.nrm = pose.last().normal();
        }

        void vertex(float x, float y, float z, float u, float v, float nx, float ny, float nz) {
            vc.vertex(mat, x, y, z).color(255, 255, 255, alpha).uv(u / PainArmorAtlas.SIZE, v / PainArmorAtlas.SIZE)
                .overlayCoords(overlay).uv2(light).normal(nrm, nx, ny, nz).endVertex();
        }
    }

    /** Runs one part's pieces: moves to the part, switches to pixel units, draws, puts the pose back. */
    private interface Pieces {
        void draw(Draw d);
    }

    private static void part(PoseStack pose, ModelPart part, Draw d, Pieces pieces) {
        pose.pushPose();
        part.translateAndRotate(pose);
        pose.scale(PX, PX, PX);
        d.use(pose);
        pieces.draw(d);
        pose.popPose();
    }

    private void drawAll(PoseStack pose, PlayerModel<AbstractClientPlayer> m, Draw d, boolean slim) {
        part(pose, m.head, d, PainArmorLayer::head);
        part(pose, m.body, d, PainArmorLayer::body);
        part(pose, m.rightArm, d, a -> arm(a, -1, slim));
        part(pose, m.leftArm, d, a -> arm(a, 1, slim));
        part(pose, m.rightLeg, d, l -> leg(l, -1));
        part(pose, m.leftLeg, d, l -> leg(l, 1));
    }

    // ------------------------------------------------------------------ head

    private static void head(Draw d) {
        // the hood, a little larger than the head
        box(d, PainArmorAtlas.HOOD_U, PainArmorAtlas.HOOD_V, 9, 9, 9, -4.7f, -8.7f, -4.7f, 4.7f, 0.7f, 4.7f); // a hair wider than the skin's own hat layer, so the two never fight
        // the stepped, pointed hat
        box(d, PainArmorAtlas.PEAK1_U, PainArmorAtlas.PEAK1_V, 8, 2, 8, -4f, -10.7f, -4f, 4f, -8.7f, 4f);
        box(d, PainArmorAtlas.PEAK2_U, PainArmorAtlas.PEAK2_V, 5, 2, 6, -2.5f, -12.7f, -3f, 2.5f, -10.7f, 3f);
        box(d, PainArmorAtlas.PEAK3_U, PainArmorAtlas.PEAK3_V, 2, 2, 3, -1f, -14.7f, -1.5f, 1f, -12.7f, 1.5f);
        // the winged crest on the brow, standing a little proud of the hood
        flatQuad(d, PainArmorAtlas.EMBLEM_U, PainArmorAtlas.EMBLEM_V, 16, 8, -3.7f, -11.6f, -4.82f, 3.7f, -7.9f, -4.82f);
        // the two horns sweeping out from the sides of the hat
        horn(d, 1);
        horn(d, -1);
    }

    /** A wide flat horn: a four-sided point, its base on the side of the hood and its tip out to the side and a little down. */
    private static void horn(Draw d, int side) {
        float bx = 4.7f * side, tx = 10.8f * side;
        float[] t = {tx, -5.3f, -0.6f};
        float[] a = {bx, -7.6f, -2.8f}, b = {bx, -7.6f, 2.8f}, c = {bx, -4.8f, 2.8f}, e = {bx, -4.8f, -2.8f};
        // top, front, bottom, back
        tri(d, a, b, t, RED_L, 0f, -1f, 0f);
        tri(d, b, c, t, RED, 0f, 0f, 1f);
        tri(d, c, e, t, RED_D, 0f, 1f, 0f);
        tri(d, e, a, t, RED, 0f, 0f, -1f);
    }

    // ------------------------------------------------------------------ body

    private static void body(Draw d) {
        // the coat
        box(d, PainArmorAtlas.TORSO_U, PainArmorAtlas.TORSO_V, 9, 13, 6, -4.5f, -0.5f, -3f, 4.5f, 12.5f, 3f);
        // the belt, and the spoked wheel on it
        box(d, PainArmorAtlas.BELT_U, PainArmorAtlas.BELT_V, 10, 2, 7, -5f, 9f, -3.5f, 5f, 11f, 3.5f);
        box(d, PainArmorAtlas.WHEEL_U, PainArmorAtlas.WHEEL_V, 4, 4, 1, -2f, 8.5f, -4.5f, 2f, 12.5f, -3.5f);
        // gold spikes: two hanging from the bar across the chest, and two each side on the belt
        for (int s = -1; s <= 1; s += 2) {
            spike(d, 2.3f * s, 6.9f, -3.1f, 0.55f, 2.3f * s, 9.4f, -3.55f, GOLD, GOLD_D);
            spike(d, 2.9f * s, 10.0f, -3.55f, 0.55f, 3.1f * s, 12.4f, -4.0f, GOLD, GOLD_D);
            spike(d, 4.3f * s, 10.0f, -3.55f, 0.55f, 4.9f * s, 12.2f, -3.95f, GOLD, GOLD_D);
        }
        // the black rod down the front of the coat, following its flare, and the bar across its foot
        slant(d, 0f, 11.5f, -3.9f, 0f, 21.0f, -5.0f, 0.6f, NAVY);
        box(d, PainArmorAtlas.BAR_U, PainArmorAtlas.BAR_V, 7, 1, 1, -3.5f, 18.6f, -5.3f, 3.5f, 19.6f, -4.3f);
    }

    // ------------------------------------------------------------------ arms

    private static void arm(Draw d, int side, boolean slim) {
        float cx = side * (slim ? 0.5f : 1.0f);   // the middle of the arm in its own part space
        float x0 = cx - 2.5f, x1 = cx + 2.5f;
        // puffed shoulder and sleeve
        box(d, PainArmorAtlas.PUFF_U, PainArmorAtlas.PUFF_V, 6, 4, 6, cx - 3f, -3f, -3f, cx + 3f, 1f, 3f);
        box(d, PainArmorAtlas.SLEEVE_U, PainArmorAtlas.SLEEVE_V, 5, 8, 5, x0, 0.5f, -2.5f, x1, 8.5f, 2.5f);
        // two black bands, each with a buckle on the outside
        band(d, side, cx, 2.2f);
        band(d, side, cx, 5.4f);
        // the big mitt
        box(d, PainArmorAtlas.MITT_U, PainArmorAtlas.MITT_V, 6, 5, 6, cx - 3f, 7.6f, -3f, cx + 3f, 12.6f, 3f);
    }

    private static void band(Draw d, int side, float cx, float y) {
        box(d, PainArmorAtlas.BAND_U, PainArmorAtlas.BAND_V, 5, 2, 5, cx - 2.75f, y, -2.75f, cx + 2.75f, y + 2f, 2.75f);
        float outer = cx + side * 2.75f;
        float bx0 = side < 0 ? outer - 0.8f : outer, bx1 = bx0 + 0.8f;
        box(d, PainArmorAtlas.BUCKLE_U, PainArmorAtlas.BUCKLE_V, 1, 1, 2, bx0, y + 0.5f, -1f, bx1, y + 1.5f, 1f);
    }

    // ------------------------------------------------------------------ legs

    private static void leg(Draw d, int side) {
        // brown boots (the skirt hangs over their tops)
        box(d, PainArmorAtlas.BOOT_U, PainArmorAtlas.BOOT_V, 5, 4, 5, -2.5f, 8f, -2.5f, 2.5f, 12f, 2.5f);

        // the long coat, this leg's half: out to the side as far as the flare goes, in to the middle line of the body.
        // "outer" is away from the middle, so the panel's picture always has its red centre stripe on the inner edge.
        float so = side;                       // the outer direction along x
        float yT = -1.0f, yB = 9.2f;
        float xOT = so * 2.9f, xOB = so * 4.6f, xI = -so * 1.9f;
        float zT = 3.2f, zB = 4.8f;
        float fu = PainArmorAtlas.SKIRTFRONT_U, fv = PainArmorAtlas.SKIRTFRONT_V;
        float bu = PainArmorAtlas.SKIRTBACK_U, bv = PainArmorAtlas.SKIRTBACK_V;
        float su = PainArmorAtlas.SKIRTSIDE_U, sv = PainArmorAtlas.SKIRTSIDE_V;
        // front
        quad(d, xOT, yT, -zT, xI, yT, -zT, xI, yB, -zB, xOB, yB, -zB, fu, fv, fu + 22, fv + 14, 0f, -0.15f, -1f);
        // back
        quad(d, xOT, yT, zT, xI, yT, zT, xI, yB, zB, xOB, yB, zB, bu, bv, bu + 22, bv + 14, 0f, -0.15f, 1f);
        // outer side
        quad(d, xOT, yT, -zT, xOT, yT, zT, xOB, yB, zB, xOB, yB, -zB, su, sv, su + 14, sv + 14, so, -0.15f, 0f);
    }

    // ------------------------------------------------------------------ geometry

    private static void vtx(Draw d, float[] p, float u, float v, float nx, float ny, float nz) {
        d.vertex(p[0], p[1], p[2], u, v, nx, ny, nz);
    }

    /** One face: corners top-left, top-right, bottom-right, bottom-left of the picture rectangle (u0,v0)-(u1,v1). */
    private static void quad(Draw d, float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float ex, float ey, float ez,
                             float u0, float v0, float u1, float v1, float nx, float ny, float nz) {
        d.vertex(ax, ay, az, u0, v0, nx, ny, nz);
        d.vertex(bx, by, bz, u1, v0, nx, ny, nz);
        d.vertex(cx, cy, cz, u1, v1, nx, ny, nz);
        d.vertex(ex, ey, ez, u0, v1, nx, ny, nz);
    }

    /** A flat picture facing forward, corners (x0,y0) top-left to (x1,y1) bottom-right at depth z. */
    private static void flatQuad(Draw d, int u, int v, int w, int h, float x0, float y0, float z, float x1, float y1, float z2) {
        quad(d, x0, y0, z, x1, y0, z, x1, y1, z2, x0, y1, z2, u, v, u + w, v + h, 0f, 0f, -1f);
    }

    /** A box cut from the atlas the way Minecraft cuts a model box: net at (u,v), picture size iw x ih x id. */
    private static void box(Draw d, int u, int v, int iw, int ih, int id,
                            float x0, float y0, float z0, float x1, float y1, float z1) {
        // front (towards -z)
        quad(d, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, u + id, v + id, u + id + iw, v + id + ih, 0f, 0f, -1f);
        // back (towards +z): seen from behind, so the picture runs the other way
        quad(d, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, u + 2 * id + iw, v + id, u + 2 * id + 2 * iw, v + id + ih, 0f, 0f, 1f);
        // right (towards -x): the front is on its right
        quad(d, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, u, v + id, u + id, v + id + ih, -1f, 0f, 0f);
        // left (towards +x): the front is on its left
        quad(d, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, u + id + iw, v + id, u + 2 * id + iw, v + id + ih, 1f, 0f, 0f);
        // top: the front edge is at the bottom of its picture
        quad(d, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, u + id, v, u + id + iw, v + id, 0f, -1f, 0f);
        // bottom: the front edge is at the top of its picture
        quad(d, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, u + id + iw, v, u + id + 2 * iw, v + id, 0f, 1f, 0f);
    }

    private static float[] cell(int n) {
        return new float[]{PainArmorAtlas.SWATCH_U + (n % 4) * 2 + 1f, PainArmorAtlas.SWATCH_V + (n / 4) * 2 + 1f};
    }

    /** A triangle in one flat colour of the swatch (drawn as a quad with a repeated corner). */
    private static void tri(Draw d, float[] a, float[] b, float[] c, int colour, float nx, float ny, float nz) {
        float[] uv = cell(colour);
        vtx(d, a, uv[0], uv[1], nx, ny, nz);
        vtx(d, b, uv[0], uv[1], nx, ny, nz);
        vtx(d, c, uv[0], uv[1], nx, ny, nz);
        vtx(d, c, uv[0], uv[1], nx, ny, nz);
    }

    /** A four-sided spike: a small square at (cx,cy,cz) running to a point; the sides in one colour, the underside in another. */
    private static void spike(Draw d, float cx, float cy, float cz, float half, float tx, float ty, float tz, int side, int under) {
        float[] t = {tx, ty, tz};
        float[] a = {cx - half, cy, cz - half}, b = {cx + half, cy, cz - half}, c = {cx + half, cy, cz + half}, e = {cx - half, cy, cz + half};
        tri(d, a, b, t, side, 0f, -0.3f, -1f);
        tri(d, b, c, t, under, 1f, 0.3f, 0f);
        tri(d, c, e, t, side, 0f, 0.3f, 1f);
        tri(d, e, a, t, under, -1f, 0.3f, 0f);
    }

    /** A thin four-sided bar from one point to another (it may lean), in one colour of the swatch. */
    private static void slant(Draw d, float x0, float y0, float z0, float x1, float y1, float z1, float half, int colour) {
        float[] uv = cell(colour);
        float[][] top = {{x0 - half, y0, z0 - half}, {x0 + half, y0, z0 - half}, {x0 + half, y0, z0 + half}, {x0 - half, y0, z0 + half}};
        float[][] bot = {{x1 - half, y1, z1 - half}, {x1 + half, y1, z1 - half}, {x1 + half, y1, z1 + half}, {x1 - half, y1, z1 + half}};
        float[][] n = {{0, 0, -1}, {1, 0, 0}, {0, 0, 1}, {-1, 0, 0}};
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            vtx(d, top[i], uv[0], uv[1], n[i][0], n[i][1], n[i][2]);
            vtx(d, top[j], uv[0], uv[1], n[i][0], n[i][1], n[i][2]);
            vtx(d, bot[j], uv[0], uv[1], n[i][0], n[i][1], n[i][2]);
            vtx(d, bot[i], uv[0], uv[1], n[i][0], n[i][1], n[i][2]);
        }
    }
}
