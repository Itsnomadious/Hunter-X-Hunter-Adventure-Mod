package net.hxhadventure.addon.client;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;

/**
 * Hunter License look for the O menu. Drop-in replacement for HxhUi (same helper names) so the three O-menu pages share one style.
 *
 * Page 1 (Mastery) is the FRONT of the license: black head with the XX logo plate, the white photo strip, a pale blue body.
 * Pages 2 and 3 (Vows, Active) are the BACK: pale blue card, black magnetic stripe across the top and the 16 digit licence number boxes.
 * Turning between pages plays a short card flip. Everything is drawn with fills except the logo and the Hunter script, which are cropped
 * from the reference licence art (textures/gui/hunter_logo.png, hunter_script.png).
 */
public final class HunterUi {
    private HunterUi() {}

    // ---- palette (ARGB). Text colours are chosen to read on the pale blue / white paper, not on a dark panel. ----
    public static final int INK = 0xFF16202B;       // main text
    public static final int INK_DIM = 0xFF55687C;   // secondary text
    public static final int NAVY = 0xFF1F5FA0;      // highlights and headings on paper
    public static final int RED = 0xFFC01D32;       // the diamond red: warnings, locked, hover accents
    public static final int GREEN = 0xFF1E7A3C;     // rewards
    public static final int GOLD = 0xFFA87400;      // stars and the Ultimate grade, dark enough for paper
    public static final int AMBER = 0xFFB35A00;     // Limitations
    public static final int PLATE = 0xFF1A1A1A;     // the licence's black
    public static final int PAPER = 0xFFF6F9FC;     // white boxes
    public static final int PAPER_LINE = 0xFF1C2630;
    public static final int DISABLED_TEXT = 0xFF8593A0;
    public static final int DISABLED_LINE = 0xFF9AA7B4;
    public static final int DISABLED_FILL = 0xFFDCE4EB;

    private static final int SHELL = 0xFFF1F2F2;        // the light grey plastic edge of the card
    private static final int SHELL_LINE = 0xFF8E949B;   // the thin second outline inside the edge
    private static final int BLUE_TOP = 0xFFEAF3FB;
    private static final int BLUE_BOTTOM = 0xFFB4D9F4;
    private static final int BLUE_FLAT = 0xFFB9DFF8;
    private static final int STRIPE = 0xFF150C0C;       // magnetic stripe, a brown-tinted black like the art

    private static final ResourceLocation LOGO = new ResourceLocation("hxhadventure", "textures/gui/hunter_logo.png");
    private static final ResourceLocation SCRIPT = new ResourceLocation("hxhadventure", "textures/gui/hunter_script.png");
    private static final ResourceLocation SCRIPT_LINES = new ResourceLocation("hxhadventure", "textures/gui/hunter_script_lines.png");
    private static final int LOGO_TEX_W = 192, LOGO_TEX_H = 132;
    private static final int SCRIPT_TEX_W = 330, SCRIPT_TEX_H = 39;
    private static final int LINES_TEX_W = 380, LINES_TEX_H = 140;

    // ---------------------------------------------------------------- primitives

    /** How far in from the edge row i starts, for a corner of radius r (i = 0 is the outermost row). */
    private static int cornerInset(int r, int i) {
        if (i >= r) return 0;
        double dy = r - i - 0.5;
        return (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
    }

    private static int lerp(int a, int b, float t) {
        int aa = (a >>> 24) & 255, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    /** Vertical gradient rectangle with optionally rounded top and/or bottom corners. */
    public static void rrGrad(GuiGraphics g, int x, int y, int w, int h, int r, boolean top, boolean bottom, int c0, int c1) {
        for (int i = 0; i < h; i++) {
            int in = 0;
            if (top && i < r) in = Math.max(in, cornerInset(r, i));
            if (bottom && h - 1 - i < r) in = Math.max(in, cornerInset(r, h - 1 - i));
            int c = c0 == c1 ? c0 : lerp(c0, c1, h <= 1 ? 0f : i / (float) (h - 1));
            g.fill(x + in, y + i, x + w - in, y + i + 1, c);
        }
    }

    /** Solid rounded rectangle. */
    public static void rr(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        rrGrad(g, x, y, w, h, r, true, true, color, color);
    }

    private static void diamond(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = r - Math.abs(dy);
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }

    // ---------------------------------------------------------------- scene

    /** Dim blue-black backdrop behind the card. */
    public static void backdrop(GuiGraphics g, int w, int h) {
        g.fillGradient(0, 0, w, h, 0xB0070C12, 0xD0070C12);
    }

    /** Card shell: soft shadow, light plastic edge with its thin inner outline. Content starts 5px in. */
    private static void shell(GuiGraphics g, int x, int y, int w, int h) {
        rr(g, x + 2, y + 3, w, h, 7, 0x55000000);
        rr(g, x, y, w, h, 7, 0xFF2A2A2E);
        rr(g, x + 1, y + 1, w - 2, h - 2, 6, SHELL);
        rr(g, x + 3, y + 3, w - 6, h - 6, 5, SHELL_LINE);
        rr(g, x + 4, y + 4, w - 8, h - 8, 4, SHELL);
    }

    /** Licence FRONT: black head (headH tall) over a pale blue body. */
    public static void front(GuiGraphics g, int x, int y, int w, int h, int headH) {
        shell(g, x, y, w, h);
        int cx = x + 5, cy = y + 5, cw = w - 10, ch = h - 10;
        rrGrad(g, cx, cy, cw, headH, 4, true, false, PLATE, PLATE);
        rrGrad(g, cx, cy + headH, cw, ch - headH, 4, false, true, BLUE_TOP, BLUE_BOTTOM);
        g.fill(cx, cy + headH, cx + cw, cy + headH + 1, 0xFF000000);
    }

    /** Licence BACK: flat pale blue, black magnetic stripe across the top (stripeH tall) and the 16 digit number boxes along the bottom. */
    public static void back(GuiGraphics g, int x, int y, int w, int h, int stripeH) {
        shell(g, x, y, w, h);
        int cx = x + 5, cy = y + 5, cw = w - 10, ch = h - 10;
        rr(g, cx, cy, cw, ch, 4, BLUE_FLAT);
        rrGrad(g, cx, cy, cw, stripeH, 4, true, false, STRIPE, STRIPE);
        licenceNumber(g, cx + 10, y + h - 20);
    }

    /** The 16 digit boxes in four groups of four, like the back of the art. The number is stable per player. */
    private static void licenceNumber(GuiGraphics g, int x, int y) {
        Font font = Minecraft.getInstance().font;
        String digits = digits();
        int bx = x;
        for (int i = 0; i < 16; i++) {
            if (i > 0) bx += (i % 4 == 0) ? 9 : 2;
            g.fill(bx, y, bx + 9, y + 12, PAPER_LINE);
            g.fill(bx + 1, y + 1, bx + 8, y + 11, BLUE_FLAT);
            String d = String.valueOf(digits.charAt(i));
            g.drawString(font, d, bx + (9 - font.width(d)) / 2, y + 2, INK, false);
            bx += 9;
        }
    }

    private static String digits() {
        Minecraft mc = Minecraft.getInstance();
        UUID id = mc.player != null ? mc.player.getUUID() : new UUID(0L, 0L);
        long a = id.getMostSignificantBits() * 0x9E3779B97F4A7C15L ^ id.getLeastSignificantBits();
        long b = (a ^ (a >>> 29)) * 0xC2B2AE3D27D4EB4FL;
        return String.format("%08d%08d", Long.remainderUnsigned(a, 100000000L), Long.remainderUnsigned(b, 100000000L));
    }

    // ---------------------------------------------------------------- artwork

    /** The XX logo plate cropped from the reference art. */
    public static void logo(GuiGraphics g, int x, int y, int w, int h) {
        RenderSystem.enableBlend();
        g.blit(LOGO, x, y, w, h, 0f, 0f, LOGO_TEX_W, LOGO_TEX_H, LOGO_TEX_W, LOGO_TEX_H);
    }

    /** The Hunter script title line, tinted to any ARGB colour (alpha is taken from the colour). */
    public static void script(GuiGraphics g, int x, int y, int w, int h, int argb) {
        tinted(g, SCRIPT, x, y, w, h, SCRIPT_TEX_W, SCRIPT_TEX_H, argb);
    }

    /** The four lines of Hunter script from the licence body, tinted. */
    public static void scriptLines(GuiGraphics g, int x, int y, int w, int h, int argb) {
        tinted(g, SCRIPT_LINES, x, y, w, h, LINES_TEX_W, LINES_TEX_H, argb);
    }

    private static void tinted(GuiGraphics g, ResourceLocation tex, int x, int y, int w, int h, int tw, int th, int argb) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        g.setColor(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, ((argb >>> 24) & 255) / 255f);
        g.blit(tex, x, y, w, h, 0f, 0f, tw, th, tw, th);
        g.setColor(1f, 1f, 1f, 1f);
    }

    /** The white photo strip with the hatch marks at both ends. */
    public static void strip(GuiGraphics g, int x, int y, int w, int h) {
        rr(g, x, y, w, h, 2, 0xFFF4F6F8);
        int hatch = 0xFFA3AAB1;
        for (int k = 0; k < 7; k++) {
            int len = Math.max(3, h - 4 - k * (h - 6) / 8);
            g.fill(x + 2 + k * 2, y + h - 2 - len, x + 3 + k * 2, y + h - 2, hatch);
            g.fill(x + w - 3 - k * 2, y + h - 2 - len, x + w - 2 - k * 2, y + h - 2, hatch);
        }
    }

    // ---------------------------------------------------------------- text blocks (same names as HxhUi)

    /** White box with a thin dark outline: the licence's title box and photo strip, used for every inset. */
    public static void inset(GuiGraphics g, int x, int y, int w, int h) {
        rr(g, x, y, w, h, 2, PAPER_LINE);
        rr(g, x + 1, y + 1, w - 2, h - 2, 1, PAPER);
    }

    /** Page title, white on the black stripe, flanked by two red diamonds. */
    public static void title(GuiGraphics g, Font font, String text, int cx, int y) {
        int tw = font.width(text);
        g.drawString(font, text, cx - tw / 2, y, 0xFFFFFFFF, false);
        diamond(g, cx - tw / 2 - 9, y + 4, 3, RED);
        diamond(g, cx + tw / 2 + 9, y + 4, 3, RED);
    }

    public static void subtitle(GuiGraphics g, Font font, String text, int cx, int y) {
        g.drawString(font, text, cx - font.width(text) / 2, y, INK_DIM, false);
    }

    /** Word-wrapped text. Returns the y of the next free line. */
    public static int wrap(GuiGraphics g, Font font, String text, int x, int y, int width, int color) {
        for (FormattedCharSequence line : font.split(Component.literal(text), width)) {
            g.drawString(font, line, x, y, color, false);
            y += 10;
        }
        return y;
    }

    // ---------------------------------------------------------------- buttons

    public static HunterButton button(int x, int y, int w, int h, String label, Button.OnPress onPress, boolean primary) {
        return new HunterButton(x, y, w, h, Component.literal(label), onPress, primary);
    }

    /** Paper button with a red tab on hover. The primary one (Close, confirm) is the black licence plate that turns diamond red on hover. */
    public static class HunterButton extends Button {
        private final boolean primary;

        HunterButton(int x, int y, int w, int h, Component msg, Button.OnPress onPress, boolean primary) {
            super(x, y, w, h, msg, onPress, DEFAULT_NARRATION);
            this.primary = primary;
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partial) {
            boolean hover = this.isHoveredOrFocused() && this.active;
            int x = getX(), y = getY(), w = this.width, h = this.height;
            int line, fill, text;
            if (!this.active) {
                line = DISABLED_LINE;
                fill = DISABLED_FILL;
                text = DISABLED_TEXT;
            } else if (primary) {
                line = hover ? RED : 0xFF000000;
                fill = hover ? RED : PLATE;
                text = 0xFFFFFFFF;
            } else {
                line = PAPER_LINE;
                fill = hover ? 0xFFD3EAFB : PAPER;
                text = INK;
            }
            rr(g, x, y, w, h, 2, line);
            rr(g, x + 1, y + 1, w - 2, h - 2, 1, fill);
            if (hover && !primary) g.fill(x + 1, y + 2, x + 3, y + h - 2, RED);
            Font font = Minecraft.getInstance().font;
            UiText.drawFit(g, font, getMessage().getString(), x + 4, y + (h - 8) / 2, w - 8, text, true);
        }
    }

    // ---------------------------------------------------------------- page flip

    private static final long FLIP_MS = 220L;
    private static long flipAt = 0L;

    /** Move to another O-menu page with a card flip and a page-turn sound. */
    public static void go(Screen next) {
        flipAt = System.currentTimeMillis();
        Minecraft mc = Minecraft.getInstance();
        mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.BOOK_PAGE_TURN, 1.0F));
        mc.setScreen(next);
    }

    /** Call before drawing the card and its widgets. If a flip is running it squeezes everything sideways around cx; pair with flipEnd. */
    public static boolean flipBegin(GuiGraphics g, int cx) {
        long dt = System.currentTimeMillis() - flipAt;
        if (dt < 0L || dt >= FLIP_MS) return false;
        float t = dt / (float) FLIP_MS;
        float s = Math.max(0.04f, 1f - (1f - t) * (1f - t) * (1f - t));
        g.pose().pushPose();
        g.pose().translate(cx, 0, 0);
        g.pose().scale(s, 1f, 1f);
        g.pose().translate(-cx, 0, 0);
        return true;
    }

    public static void flipEnd(GuiGraphics g, boolean began) {
        if (began) g.pose().popPose();
    }
}
