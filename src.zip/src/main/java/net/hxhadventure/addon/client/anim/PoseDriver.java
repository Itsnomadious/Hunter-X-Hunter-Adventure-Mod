package net.hxhadventure.addon.client.anim;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import org.joml.Quaternionf;

import java.util.HashMap;
import java.util.Map;

/**
 * Plays authored poses / animations (assets/hxhadventure/poses and pose_animations) on any entity that wears a player
 * model, and cross-fades between them. This is the general form of Project Murim's CombatStancePose: it owns the
 * per-entity state, PoseRig does the posing.
 *
 * What an entity shows is chosen by priority: /pose debug preview > the animation started with {@link #play} > the pose
 * kept with {@link #hold}. When none is left the model eases back to the vanilla pose and the entity is forgotten.
 * Every change of what is showing is cross-faded from the frame that was on screen (the pose's / animation's "blend"
 * ticks), so nothing snaps.
 *
 * Entry points: {@link #play}, {@link #hold}, {@link #release}, {@link #stop} (all safe to call from the client thread
 * at any time, for any entity id) and {@link #apply}, called from PlayerModelMixin after vanilla has posed the model.
 * Everything here runs on the render thread only.
 */
public final class PoseDriver {
    private PoseDriver() {}

    /** Cross-fade length (ticks) into an animation / pose that has no "blend" of its own. */
    private static final float DEFAULT_BLEND = 2F;
    /** Ease-out length (ticks) back to the vanilla pose. */
    private static final float MIN_EXIT = 2F;
    private static final int N = 40;   // 6 parts x (x, y, z, xRot, yRot, zRot) + wrist[2] + roll[2]

    private static final class State {
        String anim;                    // animation playing (null = none)
        String holdPose;                // pose kept when no animation is playing (null = none)
        float startAge = Float.NaN;     // render age of the animation's first frame, set lazily
        int serial;                     // bumps on every play(), so replaying the same animation restarts it
        String src = "";
        final float[] last = new float[N], from = new float[N], exitFrom = new float[N];
        float blendStart = -1000F, blendLen;
        boolean fromVanilla = true, has, exiting;
        float exitStart, exitLen = MIN_EXIT;
        float lastAge = -1000F;
    }

    private static final Map<Integer, State> STATES = new HashMap<>();   // render thread only

    /** Extra wrist bend / roll about the blade (radians) for the item in [0] the right and [1] the left hand. */
    private static final float[] WRIST = new float[2], ROLL = new float[2];
    /** True when the last posed model had its leg pivots moved; the mixin puts them back before the next model is posed. */
    private static boolean legsDirty;

    // ------------------------------------------------------------------------------------------------ api
    /** True if an animation of that name is loaded (pose_animations/<name>.json). */
    public static boolean has(String animation) {
        return animation != null && PoseLibrary.animation(animation) != null;
    }

    /**
     * Starts (or restarts) the animation on the entity. Returns false, and does nothing, if there is no such animation, so a
     * caller can fall back to another system. An animation that is neither "loop" nor "hold" plays once and eases out.
     */
    public static boolean play(int entityId, String animation) {
        if (!has(animation)) return false;
        State st = STATES.computeIfAbsent(entityId, k -> new State());
        st.anim = animation;
        st.startAge = Float.NaN;
        st.serial++;
        st.exiting = false;
        return true;
    }

    /** Keeps the named pose on the entity (under any animation that plays) until {@link #release} or {@link #stop}. */
    public static boolean hold(int entityId, String pose) {
        if (PoseLibrary.pose(pose) == null) return false;
        State st = STATES.computeIfAbsent(entityId, k -> new State());
        st.holdPose = pose;
        st.exiting = false;
        return true;
    }

    /** Drops the held pose; an animation still playing carries on. */
    public static void release(int entityId) {
        State st = STATES.get(entityId);
        if (st != null) st.holdPose = null;
    }

    /** Ends everything on the entity: it eases back to the vanilla pose. */
    public static void stop(int entityId) {
        State st = STATES.get(entityId);
        if (st != null) {
            st.anim = null;
            st.holdPose = null;
        }
    }

    public static boolean isActive(int entityId) {
        State st = STATES.get(entityId);
        return st != null && (st.anim != null || st.holdPose != null);
    }

    public static void forget(int entityId) {
        STATES.remove(entityId);
    }

    public static void clear() {
        STATES.clear();
    }

    // ------------------------------------------------------------------------------------------------ helpers
    private static void pack(ModelPart[] parts, float[] wrist, float[] roll, float[] o) {
        for (int i = 0; i < 6; i++) {
            ModelPart p = parts[i];
            int b = i * 6;
            o[b] = p.x; o[b + 1] = p.y; o[b + 2] = p.z; o[b + 3] = p.xRot; o[b + 4] = p.yRot; o[b + 5] = p.zRot;
        }
        o[36] = wrist[0]; o[37] = wrist[1]; o[38] = roll[0]; o[39] = roll[1];
    }

    private static void unpack(float[] o, ModelPart[] parts, float[] wrist, float[] roll) {
        for (int i = 0; i < 6; i++) {
            ModelPart p = parts[i];
            int b = i * 6;
            p.x = o[b]; p.y = o[b + 1]; p.z = o[b + 2]; p.xRot = o[b + 3]; p.yRot = o[b + 4]; p.zRot = o[b + 5];
        }
        wrist[0] = o[36]; wrist[1] = o[37]; roll[0] = o[38]; roll[1] = o[39];
    }

    private static float smooth(float u) {
        u = Mth.clamp(u, 0F, 1F);
        return u * u * (3F - 2F * u);
    }

    private static boolean armed(ItemStack s) {
        return !s.isEmpty() && (s.getItem() instanceof SwordItem || s.is(ItemTags.SWORDS));
    }

    /** Called at the head of every PlayerModel.setupAnim: vanilla never resets the leg x pivots, the pose rig moves them. */
    public static void beforeVanilla(PlayerModel<?> m) {
        if (!legsDirty) return;
        legsDirty = false;
        m.rightLeg.x = -1.9F;
        m.leftLeg.x = 1.9F;
    }

    // ------------------------------------------------------------------------------------------------ apply
    /**
     * Poses the model if the entity has something playing. Call after vanilla setupAnim (and before anything that is meant to
     * override the pose). Does nothing, and costs one map lookup, for every entity that has no state.
     */
    public static void apply(PlayerModel<?> m, LivingEntity e, float age) {
        WRIST[0] = WRIST[1] = ROLL[0] = ROLL[1] = 0F;
        State st = STATES.get(e.getId());
        boolean debug = PoseDebug.active(e);
        if (st == null && !debug) return;

        Minecraft mc = Minecraft.getInstance();
        // first-person hands reuse this model with the local player; leave those alone
        if (e == mc.player && mc.options.getCameraType().isFirstPerson()) return;
        // crouching, swimming, gliding, sleeping... keep their vanilla pose
        if (e.getPose() != net.minecraft.world.entity.Pose.STANDING) return;
        if (st == null) {
            st = new State();
            STATES.put(e.getId(), st);
        }

        // ---- what to show
        Pose pose = PoseDebug.poseFor(e, age);   // /pose preview of the local player, otherwise null
        String src = "debug";
        float blend = DEFAULT_BLEND;
        if (pose == null) {
            src = "";
            if (st.anim != null) {
                Animation a = PoseLibrary.animation(st.anim);
                if (a != null) {
                    if (Float.isNaN(st.startAge)) st.startAge = age;
                    float t = Math.max(0F, age - st.startAge);
                    if (a.loop || a.hold || t < a.length) {
                        pose = a.sample(t);
                        src = "anim#" + st.serial;
                        blend = a.blend >= 0F ? a.blend : DEFAULT_BLEND;
                    } else {
                        st.anim = null;   // finished
                    }
                } else {
                    st.anim = null;       // reloaded away
                }
            }
            if (pose == null && st.holdPose != null) {
                pose = PoseLibrary.pose(st.holdPose);
                if (pose != null) {
                    src = "pose:" + st.holdPose;
                    blend = !Float.isNaN(pose.blend) ? pose.blend : DEFAULT_BLEND;
                }
            }
        }

        ModelPart[] parts = {m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg};
        float[] vanilla = new float[N];
        pack(parts, WRIST, ROLL, vanilla);   // what vanilla just posed (also the blend source when entering / leaving)

        // ---- nothing left to show: ease back to vanilla, then forget the entity
        if (pose == null) {
            if (!st.has) {
                STATES.remove(e.getId());
                return;
            }
            if (!st.exiting) {
                st.exiting = true;
                st.exitStart = age;
                System.arraycopy(st.last, 0, st.exitFrom, 0, N);
            }
            float w = smooth((age - st.exitStart) / st.exitLen);
            if (w >= 1F || age < st.exitStart) {
                STATES.remove(e.getId());
                return;
            }
            float[] out = new float[N];
            for (int i = 0; i < N; i++) out[i] = Mth.lerp(w, st.exitFrom[i], vanilla[i]);
            System.arraycopy(out, 0, st.last, 0, N);
            st.lastAge = age;
            finish(m, parts, out);
            return;
        }
        st.exiting = false;
        st.exitLen = Math.max(MIN_EXIT, blend);

        // ---- pose the model
        boolean rightMain = e.getMainArm() == HumanoidArm.RIGHT;
        PoseRig.apply(m, rightMain, pose, age, armed(e.getMainHandItem()), armed(e.getOffhandItem()), WRIST, ROLL,
                e == mc.player);

        // ---- cross-fade from what was on screen
        float[] cur = new float[N];
        pack(parts, WRIST, ROLL, cur);
        if (!st.has || age - st.lastAge > 4F || age < st.lastAge) {   // first frame, or the entity was out of sight
            st.has = true;
            st.fromVanilla = true;
            st.blendStart = age;
            st.blendLen = blend;
            st.src = src;
        } else if (!src.equals(st.src)) {
            System.arraycopy(st.last, 0, st.from, 0, N);
            st.fromVanilla = false;
            st.blendStart = age;
            st.blendLen = blend;
            st.src = src;
        }
        float w = st.blendLen <= 0F ? 1F : smooth((age - st.blendStart) / st.blendLen);
        float[] out = cur;
        if (w < 1F) {
            float[] base = st.fromVanilla ? vanilla : st.from;
            out = new float[N];
            for (int i = 0; i < N; i++) out[i] = Mth.lerp(w, base[i], cur[i]);
        }
        System.arraycopy(out, 0, st.last, 0, N);
        st.lastAge = age;
        finish(m, parts, out);
    }

    private static void finish(PlayerModel<?> m, ModelPart[] parts, float[] out) {
        unpack(out, parts, WRIST, ROLL);
        legsDirty = true;
        // the clothing layers were copied from the base parts before we moved them: copy again
        m.leftPants.copyFrom(m.leftLeg);
        m.rightPants.copyFrom(m.rightLeg);
        m.leftSleeve.copyFrom(m.leftArm);
        m.rightSleeve.copyFrom(m.rightArm);
        m.jacket.copyFrom(m.body);
        m.hat.copyFrom(m.head);
    }

    /** Pivots the held item about the hand: bends the blade by the wrist angle and spins it about its own axis. */
    public static void applyWrist(PoseStack pose, HumanoidArm side) {
        float w = side == HumanoidArm.RIGHT ? WRIST[0] : WRIST[1];
        float r = side == HumanoidArm.RIGHT ? ROLL[0] : -ROLL[1];   // the left hand's blade is mirrored
        if (w == 0F && r == 0F) return;
        pose.translate(0.0F, 0.625F, 0.0F);   // pivot at the hand
        if (w != 0F) pose.mulPose(Axis.XP.rotation(w));
        // the blade lies along (0, 0.174, -0.985) in the hand's frame; roll about that line
        if (r != 0F) pose.mulPose(new Quaternionf().rotateAxis(r, 0.0F, 0.174F, -0.985F));
        pose.translate(0.0F, -0.625F, 0.0F);
    }
}
