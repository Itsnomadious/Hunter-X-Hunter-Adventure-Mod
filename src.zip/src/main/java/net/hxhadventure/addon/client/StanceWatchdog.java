package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.abilities.AnimationHandler;
import net.hxhadventure.event.ModKeyBindings;

/**
 * The Strong attack's charge stance is a "hold on the last frame" animation: it stays on until a stop signal arrives. If that signal is ever
 * lost (a reset, a respawn, a dropped packet) the body stays locked, which stops crouching, sprinting and attack poses from showing.
 * This watches every stance that is on and lets go of it once it cannot still be held: your own when the ability key is up, anyone else's after 30 s.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class StanceWatchdog {
    private StanceWatchdog() {}

    private static final Map<Integer, Integer> HELD = new HashMap<>(); // entity id -> ticks the stance has been on
    private static final int LOCAL_GRACE = 10, REMOTE_MAX = 600;

    public static void note(Player p, String anim) {
        if ("charge_stance".equals(anim) || "slash_charge".equals(anim) || "katana_charge".equals(anim) || "iaido_charge".equals(anim)) HELD.put(p.getId(), 0);
        else HELD.remove(p.getId());
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || HELD.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            HELD.clear();
            return;
        }
        List<Player> release = new ArrayList<>();
        List<Integer> gone = new ArrayList<>();
        for (Map.Entry<Integer, Integer> en : HELD.entrySet()) {
            if (!(mc.level.getEntity(en.getKey()) instanceof Player p) || !p.isAlive()) {
                gone.add(en.getKey());
                continue;
            }
            int t = en.getValue() + 1;
            en.setValue(t);
            boolean local = p == mc.player;
            if (local ? (t > LOCAL_GRACE && !ModKeyBindings.USE_ABILITY_KEY.isDown()) : t > REMOTE_MAX) release.add(p);
        }
        for (Integer id : gone) HELD.remove(id);
        for (Player p : release) AnimationHandler.playAnimation(p, "stop_anim", false); // also removes it from HELD
    }
}
