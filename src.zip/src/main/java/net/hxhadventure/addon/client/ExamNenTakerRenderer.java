package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.hxhadventure.addon.ExamNenTakerEntity;
import net.hxhadventure.addon.ExamTakerEntity;
import net.hxhadventure.addon.NenFighter;

/** A Nen user among the test takers: the same skins as the others, with a Ten / Ren / Ken aura whose colour depends on the skin. */
public class ExamNenTakerRenderer extends NpcPlayerRenderer<ExamNenTakerEntity> {
    public ExamNenTakerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, t -> tex(ExamTakerEntity.textureName(t.skin())), t -> ExamTakerEntity.isSlim(t.skin()));
        for (String aura : ExamNenTakerEntity.AURAS) {
            final int idx = java.util.Arrays.asList(ExamNenTakerEntity.AURAS).indexOf(aura);
            addLayer(new NpcAuraLayer<ExamNenTakerEntity>(this, tex(aura), npc -> {
                if (npc.skin() % ExamNenTakerEntity.AURAS.length != idx) return null;
                int f = npc.nenFlags();
                if ((f & NenFighter.F_TEN) == 0) return null;
                if ((f & NenFighter.F_REN) != 0) {
                    float flick = 0.9f + 0.1f * (float) Math.sin(npc.tickCount * 0.9);
                    return new float[] {1.4f, 1.5f, flick, 1f, 1f};
                }
                if ((f & NenFighter.F_KEN) != 0) return new float[] {1.2f, 1.3f, 0.85f, 1f, 1f};
                return new float[] {1.1f, 1.2f, 0.6f, 1f, 1f};
            }));
        }
    }
}
