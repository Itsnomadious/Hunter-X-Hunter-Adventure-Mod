package net.hxhadventure.addon.client;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Safety net + diagnostic: an entity whose type has no renderer makes EntityRenderDispatcher.shouldRender throw a NullPointerException
 * and kills the whole client. Frames can be drawn between two client ticks, so a tick check alone can be too late: the check also runs
 * the moment the entity joins the client level. It names the offending type in the log (once) and drops that entity on this client only.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class NoRendererGuard {
    private static final Logger LOG = LogManager.getLogger("hxhadventure/NoRendererGuard");
    private static final Set<EntityType<?>> REPORTED = new HashSet<>();

    private NoRendererGuard() {}

    private static void report(Entity en, String when) {
        if (REPORTED.add(en.getType())) {
            LOG.error("[{}] Entity type {} ({}) has no renderer on this client (id {}, at {}, {}, {}); dropping it so the game does not crash",
                when, BuiltInRegistries.ENTITY_TYPE.getKey(en.getType()), en.getClass().getName(), en.getId(),
                en.getX(), en.getY(), en.getZ());
        }
    }

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (!e.getLevel().isClientSide()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity en = e.getEntity();
        if (mc.getEntityRenderDispatcher().getRenderer(en) == null) {
            report(en, "join");
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();
        for (Entity en : level.entitiesForRendering()) {
            if (dispatcher.getRenderer(en) != null) continue;
            report(en, "tick");
            level.removeEntity(en.getId(), Entity.RemovalReason.DISCARDED);
        }
    }
}
