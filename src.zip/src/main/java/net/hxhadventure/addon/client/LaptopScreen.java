package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketQuestAction;
import net.hxhadventure.addon.quest.Quest;
import net.hxhadventure.addon.quest.QuestCategory;
import net.hxhadventure.addon.quest.QuestData;
import net.hxhadventure.addon.quest.QuestType;
import net.hxhadventure.addon.quest.Quests;
import net.hxhadventure.block.LaptopBlock;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * The Hunter laptop's browser. Opening it shows a plain screen with a web page: the Hunter Association's quest board, with a page per Hunter type, quest pages and "My Quests".
 *
 * <p>The page is laid out on a fixed 320 x 200 surface and scaled onto the panel's rectangle. Everything is immediate mode: each frame the page is
 * drawn and the clickable areas are collected in {@link #hits}.
 */
public class LaptopScreen extends Screen {
    private static final int VW = 384, VH = 240;

    // ---- palette (shares the Hunter licence's colours)
    private static final int CHROME = 0xFF272B31, CHROME_2 = 0xFF343A42, CHROME_TEXT = 0xFFD5DAE0;
    private static final int PAGE = 0xFFEEF2F6, SIDEBAR = 0xFFD9E3EC, WHITE = 0xFFFFFFFF, HOVER = 0xFFDCEEFC;
    private static final int INK = HunterUi.INK, DIM = HunterUi.INK_DIM, RED = HunterUi.RED, GREEN = HunterUi.GREEN, PLATE = HunterUi.PLATE;

    private final BlockPos pos;
    private QuestData.Snapshot data;

    // ---- navigation state
    private QuestCategory cat;
    private boolean mine;
    private String openId;
    private int scroll;

    private String status = "";
    private long statusUntil;
    private long arrivedAt = -1L;

    // ---- layout of the page on the screen (set in init)
    private float px, py, ps, pw, ph;

    // ---- per frame
    private record Hit(float x, float y, float w, float h, Runnable action) {}
    private final List<Hit> hits = new ArrayList<>();
    private float hmx, hmy;
    private static final Map<String, ItemStack> STACKS = new HashMap<>();

    public LaptopScreen(BlockPos pos, QuestData.Snapshot data) {
        super(Component.literal("Hunter Laptop"));
        this.pos = pos;
        this.data = data;
        Minecraft mc = Minecraft.getInstance();
    }

    /** Called from the network handler on the client thread. */
    public static void onSync(BlockPos pos, boolean open, QuestData.Snapshot data) {
        Minecraft mc = Minecraft.getInstance();
        if (open) {
            mc.setScreen(new LaptopScreen(pos, data));
            mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_CHIME.get(), 1.4f, 0.6f));
        } else if (mc.screen instanceof LaptopScreen s) {
            s.setData(data);
        }
    }

    private void setData(QuestData.Snapshot now) {
        QuestData.Snapshot old = this.data;
        for (QuestData.Active a : now.active) {
            if (old.find(a.id) == null) say("Accepted: " + titleOf(a.id));
        }
        for (QuestData.Active a : old.active) {
            if (now.find(a.id) == null && !now.completed.contains(a.id)) say("Quest abandoned.");
            else if (now.find(a.id) == null) say("Quest complete!  +" + (now.points - old.points) + " Hunter points");
        }
        this.data = now;
    }

    private static String titleOf(String id) {
        Quest q = Quests.get(id);
        return q == null ? id : q.title;
    }

    private void say(String s) {
        status = s;
        statusUntil = System.currentTimeMillis() + 4000L;
    }

    // ------------------------------------------------------------------ screen plumbing

    @Override
    protected void init() {
        // an ordinary screen: the browser is centred and scaled to fit the window
        ps = Math.max(0.5f, Math.min((this.width - 24f) / VW, (this.height - 24f) / VH));
        pw = VW * ps;
        ph = VH * ps;
        px = (this.width - pw) / 2f;
        py = (this.height - ph) / 2f;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        boolean gone = !(mc.level.getBlockState(pos).getBlock() instanceof LaptopBlock);
        if (gone || mc.player.distanceToSqr(Vec3.atCenterOf(pos)) > 100.0 || mc.player.hurtTime > 0) onClose();
    }

    // ------------------------------------------------------------------ input

    private void click() {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        float vx = (float) ((mx - px) / ps), vy = (float) ((my - py) / ps);
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (vx >= h.x && vx < h.x + h.w && vy >= h.y && vy < h.y + h.h) {
                click();
                h.action.run();
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (openId != null) return false;
        scroll -= (int) Math.signum(delta) * 24;
        return true;
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        hits.clear();
        if (arrivedAt < 0) arrivedAt = System.currentTimeMillis();

        hmx = (mouseX - px) / ps;
        hmy = (mouseY - py) / ps;

        g.fillGradient(0, 0, this.width, this.height, 0xB0070C12, 0xD0070C12);
        g.fill(Math.round(px) - 3, Math.round(py) - 3, Math.round(px + pw) + 3, Math.round(py + ph) + 3, 0xFF14181C);
        g.enableScissor(Math.round(px), Math.round(py), Math.round(px + pw), Math.round(py + ph));
        g.pose().pushPose();
        g.pose().translate(px, py, 0f);
        g.pose().scale(ps, ps, 1f);
        drawBrowser(g);
        float boot = Mth.clamp((System.currentTimeMillis() - arrivedAt) / 300f, 0f, 1f);
        if (boot < 1f) fill(g, 0, 0, VW, VH, ((int) ((1f - boot) * 255f) << 24) | 0x0A1020);
        g.pose().popPose();
        g.disableScissor();
    }

    private void drawBrowser(GuiGraphics g) {
        fill(g, 0, 0, VW, VH, PAGE);
        drawHeader(g);
        drawSidebar(g);
        if (openId != null && Quests.get(openId) != null) drawDetail(g, Quests.get(openId));
        else drawList(g);
        drawChrome(g);
        drawStatusBar(g);
    }

    // ---- small drawing helpers (virtual coordinates)

    private void fill(GuiGraphics g, float x, float y, float w, float h, int c) {
        g.fill((int) x, (int) y, (int) (x + w), (int) (y + h), c);
    }

    private void text(GuiGraphics g, String s, float x, float y, int c) {
        g.drawString(this.font, s, (int) x, (int) y, c, false);
    }

    private void small(GuiGraphics g, String s, float x, float y, int c) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(0.75f, 0.75f, 1f);
        g.drawString(this.font, s, 0, 0, c, false);
        g.pose().popPose();
    }

    private float smallWidth(String s) {
        return this.font.width(s) * 0.75f;
    }

    private int wrapSmall(GuiGraphics g, String s, float x, float y, float width, int c, int maxLines) {
        List<FormattedCharSequence> lines = this.font.split(Component.literal(s), (int) (width / 0.75f));
        int n = 0;
        for (FormattedCharSequence l : lines) {
            if (n >= maxLines) break;
            g.pose().pushPose();
            g.pose().translate(x, y + n * 7f, 0f);
            g.pose().scale(0.75f, 0.75f, 1f);
            g.drawString(this.font, l, 0, 0, c, false);
            g.pose().popPose();
            n++;
        }
        return n;
    }

    private void diamond(GuiGraphics g, float cx, float cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = r - Math.abs(dy);
            g.fill((int) cx - half, (int) cy + dy, (int) cx + half + 1, (int) cy + dy + 1, color);
        }
    }

    private void tier(GuiGraphics g, float x, float y, int tier, int color) {
        for (int i = 0; i < 5; i++) diamond(g, x + i * 7 + 3, y + 3, 3, i < tier ? color : 0xFFB8C2CC);
    }

    private boolean over(float x, float y, float w, float h) {
        return hmx >= x && hmx < x + w && hmy >= y && hmy < y + h;
    }

    private void hit(float x, float y, float w, float h, Runnable r) {
        hits.add(new Hit(x, y, w, h, r));
    }

    private void button(GuiGraphics g, float x, float y, float w, float h, String label, boolean enabled, boolean primary, Runnable r) {
        boolean hover = enabled && over(x, y, w, h);
        int line = !enabled ? HunterUi.DISABLED_LINE : primary ? (hover ? RED : 0xFF000000) : INK;
        int fill = !enabled ? HunterUi.DISABLED_FILL : primary ? (hover ? RED : PLATE) : (hover ? HOVER : WHITE);
        int txt = !enabled ? HunterUi.DISABLED_TEXT : primary ? 0xFFFFFFFF : INK;
        fill(g, x, y, w, h, line);
        fill(g, x + 1, y + 1, w - 2, h - 2, fill);
        String s = this.font.plainSubstrByWidth(label, (int) ((w - 6) / 0.8f));
        g.pose().pushPose();
        g.pose().translate(x + (w - this.font.width(s) * 0.8f) / 2f, y + (h - 6.4f) / 2f, 0f);
        g.pose().scale(0.8f, 0.8f, 1f);
        g.drawString(this.font, s, 0, 0, txt, false);
        g.pose().popPose();
        if (enabled) hit(x, y, w, h, r);
    }

    private static ItemStack stack(String id) {
        return STACKS.computeIfAbsent(id, k -> {
            Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(k));
            return new ItemStack(it == null || it == Items.AIR ? Items.PAPER : it);
        });
    }

    private void icon(GuiGraphics g, String id, float x, float y, float size) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        float s = size / 16f;
        g.pose().scale(s, s, 1f);
        g.renderItem(stack(id), 0, 0);
        g.pose().popPose();
    }

    private static String iconOf(Quest.Objective o) {
        return switch (o.type) {
            case COLLECT, CRAFT, EAT, MINE -> o.firstTarget();
            case KILL -> "minecraft:iron_sword";
            case VISIT -> "minecraft:compass";
            case FISH -> "minecraft:fishing_rod";
        };
    }

    private static String iconOf(Quest q) {
        return q.objectives.isEmpty() ? q.category.icon : iconOf(q.objectives.get(0));
    }

    // ---- progress

    /** What the page shows for an objective: what was handed in or tracked, plus (for hand-ins) what is in the inventory right now. */
    private int current(Quest q, QuestData.Active a, int i) {
        Quest.Objective o = q.objectives.get(i);
        int base = a == null ? 0 : a.progress[i];
        if (o.type == QuestType.COLLECT && a != null && Minecraft.getInstance().player != null) {
            base += QuestData.held(Minecraft.getInstance().player, o);
        }
        return Math.min(o.count, base);
    }

    private boolean ready(Quest q, QuestData.Active a) {
        for (int i = 0; i < q.objectives.size(); i++) {
            if (current(q, a, i) < q.objectives.get(i).count) return false;
        }
        return true;
    }

    // ---- chrome: tab strip, toolbar and window buttons

    private void drawChrome(GuiGraphics g) {
        fill(g, 0, 0, VW, 16, CHROME);
        fill(g, 4, 3, 130, 13, CHROME_2);
        diamond(g, 12, 9, 3, RED);
        small(g, "Hunter Association - Quest Net", 20, 7, CHROME_TEXT);
        boolean hc = over(VW - 14, 2, 12, 12);
        fill(g, VW - 14, 2, 12, 12, hc ? RED : CHROME_2);
        small(g, "x", VW - 10, 5, 0xFFFFFFFF);
        hit(VW - 14, 2, 12, 12, this::onClose);
        fill(g, 0, 16, VW, 14, CHROME_2);
        boolean canBack = openId != null || cat != null || mine;
        boolean hb = canBack && over(5, 18, 14, 10);
        fill(g, 5, 18, 14, 10, hb ? 0xFF4A515B : CHROME);
        small(g, "<", 10, 20, canBack ? CHROME_TEXT : 0xFF6A727C);
        if (canBack) hit(5, 18, 14, 10, this::goBack);
        fill(g, 24, 18, VW - 30, 10, CHROME);
        String url = "https://hunter.net/" + (openId != null ? (cat != null ? cat.slug + "/" : "") + openId : mine ? "my-quests" : cat != null ? cat.slug : "board");
        small(g, this.font.plainSubstrByWidth(url, (int) ((VW - 40) / 0.75f)), 29, 20, 0xFF9FB8D0);
        fill(g, 0, 30, VW, 1, 0xFF14171B);
    }

    private void goBack() {
        if (openId != null) openId = null;
        else {
            cat = null;
            mine = false;
            scroll = 0;
        }
    }

    private void drawStatusBar(GuiGraphics g) {
        fill(g, 0, VH - 12, VW, 12, CHROME);
        boolean showStatus = System.currentTimeMillis() < statusUntil;
        small(g, showStatus ? status : "Quest log " + data.active.size() + "/" + QuestData.MAX_ACTIVE, 5, VH - 9, showStatus ? 0xFFFFD27A : 0xFF9AA4AE);
        String right = "Hunter Association network";
        small(g, right, VW - 5 - smallWidth(right), VH - 9, 0xFF6F7983);
    }

    // ---- page header and sidebar

    private String starsText() {
        int n = QuestData.stars(data);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < QuestData.MAX_STARS; i++) sb.append(i < n ? "\u2605" : "\u2606");
        return sb.toString();
    }

    private void drawHeader(GuiGraphics g) {
        fill(g, 0, 31, VW, 19, PLATE);
        diamond(g, 10, 40, 3, RED);
        text(g, "HUNTER ASSOCIATION", 18, 36, 0xFFFFFFFF);
        String r = QuestData.rank(data.points) + "  -  " + data.points + " pts";
        small(g, r, VW - 6 - smallWidth(r), 33, 0xFFB9DFF8);
        int n = QuestData.stars(data);
        small(g, starsText() + "  Hunter stars", VW - 6 - smallWidth(starsText() + "  Hunter stars"), 42, n > 0 ? 0xFFFFD84A : 0xFF8593A0);
    }

    private static final int SIDE_W = 84;

    private void drawSidebar(GuiGraphics g) {
        fill(g, 0, 50, SIDE_W, VH - 62, SIDEBAR);
        float y = 54;
        navItem(g, y, "Quest Board", PLATE, cat == null && !mine, () -> { cat = null; mine = false; openId = null; scroll = 0; });
        y += 14;
        navItem(g, y, "My Quests (" + data.active.size() + ")", GREEN, mine, () -> { cat = null; mine = true; openId = null; scroll = 0; });
        y += 17;
        small(g, "HUNTER TYPES", 6, y, DIM);
        y += 9;
        for (QuestCategory c : QuestCategory.values()) {
            navItem(g, y, c.title.replace(" Hunter", ""), c.color, cat == c, () -> { cat = c; mine = false; openId = null; scroll = 0; });
            y += 14;
        }
        // star progress, at the bottom of the sidebar
        String hint = QuestData.nextStarHint(data);
        float sy = VH - 12 - 40;
        fill(g, 4, sy - 3, SIDE_W - 8, 1, 0xFFB8C2CC);
        small(g, "HUNTER STARS  " + starsText(), 6, sy, QuestData.stars(data) > 0 ? GOLD_TXT : DIM);
        if (hint.isEmpty()) small(g, "Maximum stars reached.", 6, sy + 10, DIM);
        else wrapSmall(g, hint, 6, sy + 10, SIDE_W - 12, DIM, 4);
    }

    private static final int GOLD_TXT = 0xFFB07A00;

    private void navItem(GuiGraphics g, float y, String label, int color, boolean selected, Runnable r) {
        boolean hover = over(0, y, SIDE_W, 13);
        if (selected) fill(g, 0, y, SIDE_W, 13, WHITE);
        else if (hover) fill(g, 0, y, SIDE_W, 13, HOVER);
        if (selected) fill(g, 0, y, 2, 13, color);
        fill(g, 7, y + 4, 5, 5, color);
        small(g, this.font.plainSubstrByWidth(label, (int) ((SIDE_W - 20) / 0.75f)), 16, y + 4, selected ? INK : DIM);
        hit(0, y, SIDE_W, 13, r);
    }

    // ---- quest list

    private List<Quest> visible() {
        List<Quest> src = new ArrayList<>();
        if (mine) {
            for (QuestData.Active a : data.active) {
                Quest q = Quests.get(a.id);
                if (q != null) src.add(q);
            }
        } else {
            List<Quest> pool = cat != null ? Quests.in(cat) : Quests.all();
            List<Quest> done = new ArrayList<>();
            for (Quest q : pool) {
                if (data.completed.contains(q.id) && !q.repeatable && data.find(q.id) == null) done.add(q);
                else src.add(q);
            }
            src.addAll(done); // finished quests sink to the bottom
        }
        return src;
    }

    private static final float CX = SIDE_W + 6, CW = VW - SIDE_W - 12;
    private static final float GRID_TOP = 66, GRID_BOTTOM = VH - 14, CARD_H = 24, GAP = 3;

    private void drawList(GuiGraphics g) {
        List<Quest> list = visible();
        String head = (mine ? "My quests" : cat != null ? cat.title : "All quests") + "  -  " + list.size() + (list.size() == 1 ? " quest" : " quests");
        small(g, head, CX, 55, DIM);

        float cardW = (CW - GAP - 5) / 2f;
        int rows = (list.size() + 1) / 2;
        float content = rows * (CARD_H + GAP);
        float view = GRID_BOTTOM - GRID_TOP;
        scroll = (int) Mth.clamp(scroll, 0f, Math.max(0f, content - view));
        g.enableScissor(Math.round(px + CX * ps), Math.round(py + GRID_TOP * ps), Math.round(px + (CX + CW) * ps), Math.round(py + GRID_BOTTOM * ps));
        if (list.isEmpty()) small(g, mine ? "No active quests yet." : "No quests here.", CX + 4, GRID_TOP + 6, DIM);
        for (int i = 0; i < list.size(); i++) {
            float x = CX + (i % 2) * (cardW + GAP);
            float y = GRID_TOP + (i / 2) * (CARD_H + GAP) - scroll;
            if (y + CARD_H < GRID_TOP || y > GRID_BOTTOM) continue;
            drawRow(g, list.get(i), x, y, cardW);
        }
        g.disableScissor();

        if (content > view) {
            float barH = Math.max(12f, view * (view / content));
            float barY = GRID_TOP + (view - barH) * (scroll / (content - view));
            fill(g, VW - 9, GRID_TOP, 4, view, 0xFFD0D9E2);
            fill(g, VW - 9, barY, 4, barH, 0xFF8593A0);
        }
    }

    /** One line of text shrunk (down to 60%) to fit the width. */
    private void fit(GuiGraphics g, String s, float x, float y, float maxW, int c) {
        float sc = Math.max(0.6f, Math.min(0.85f, maxW / Math.max(1, this.font.width(s))));
        String t = this.font.width(s) * sc > maxW ? this.font.plainSubstrByWidth(s, (int) (maxW / sc)) : s;
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(sc, sc, 1f);
        g.drawString(this.font, t, 0, 0, c, false);
        g.pose().popPose();
    }

    private void drawRow(GuiGraphics g, Quest q, float x, float y, float w) {
        QuestData.Active a = data.find(q.id);
        boolean done = data.completed.contains(q.id) && !q.repeatable && a == null;
        float h = CARD_H;
        float vy0 = Math.max(y, GRID_TOP), vy1 = Math.min(y + h, GRID_BOTTOM);
        boolean hover = over(x, vy0, w, vy1 - vy0) && hmy >= GRID_TOP && hmy < GRID_BOTTOM;
        fill(g, x, y, w, h, hover ? HOVER : WHITE);
        fill(g, x, y, 3, h, done ? 0xFFB8C2CC : q.category.color);
        icon(g, iconOf(q), x + 7, y + 4, 16);
        fit(g, q.title, x + 28, y + 3, w - 32, done ? 0xFF8593A0 : INK);
        tier(g, x + 27, y + 13, q.tier, done ? 0xFFB8C2CC : q.category.color);
        boolean again = data.completed.contains(q.id) && q.repeatable;
        small(g, "+" + (again ? QuestData.repeatPoints(q) : q.points) + " pts", x + 66, y + 14, DIM);
        String chip;
        int chipColor = DIM;
        if (a != null) {
            if (ready(q, a)) { chip = "READY"; chipColor = GREEN; }
            else { chip = "ACTIVE"; chipColor = HunterUi.NAVY; }
        } else if (done) chip = "DONE";
        else chip = again ? "REPEAT" : "NEW";
        small(g, chip, x + w - 4 - smallWidth(chip), y + 14, chipColor);
        if (vy1 > vy0) hit(x, vy0, w, vy1 - vy0, () -> openId = q.id);
    }

    // ---- quest page

    private void drawDetail(GuiGraphics g, Quest q) {
        QuestData.Active a = data.find(q.id);
        float x = CX, w = CW;

        g.pose().pushPose();
        g.pose().translate(x, 55, 0f);
        g.pose().scale(1.0f, 1.0f, 1f);
        g.drawString(this.font, this.font.plainSubstrByWidth(q.title, (int) (w - 50)), 0, 0, INK, false);
        g.pose().popPose();
        tier(g, x + w - 36, 55, q.tier, q.category.color);
        fill(g, x, 66, w, 1, q.category.color);
        String sub = q.category.title + (q.repeatable ? "  -  repeatable (10% points after the first clear)" : "")
            + (q.tier >= 4 ? "  -  counts toward Hunter stars" : "");
        small(g, this.font.plainSubstrByWidth(sub, (int) (w / 0.75f)), x, 69, q.category.color);

        int lines = wrapSmall(g, q.desc, x, 79, w, DIM, 3);

        float y = 79 + lines * 7 + 6;
        small(g, "OBJECTIVES", x, y, DIM);
        y += 9;
        for (int i = 0; i < q.objectives.size(); i++) {
            Quest.Objective o = q.objectives.get(i);
            int cur = current(q, a, i);
            boolean ok = cur >= o.count;
            icon(g, iconOf(o), x, y - 2, 12);
            String line = o.type.verb + " " + (o.type == QuestType.VISIT ? "" : o.count + " x ") + o.label;
            small(g, this.font.plainSubstrByWidth(line, (int) ((w - 16) / 0.75f)), x + 15, y, ok ? GREEN : INK);
            if (o.type != QuestType.VISIT || a != null) {
                float bx = x + 15, bw = 170;
                fill(g, bx, y + 7, bw, 3, 0xFFC5CED8);
                fill(g, bx, y + 7, bw * cur / (float) o.count, 3, ok ? GREEN : q.category.color);
                String frac = o.type == QuestType.VISIT ? (ok ? "found" : "not yet") : cur + "/" + o.count;
                small(g, frac, bx + bw + 6, y + 4, ok ? GREEN : DIM);
            }
            y += 15;
        }

        y += 3;
        small(g, "REWARD", x, y, DIM);
        float rx = x + 40;
        for (Quest.Reward r : q.rewards) {
            icon(g, r.item, rx, y - 3, 12);
            String c = "x" + r.count;
            small(g, c, rx + 13, y, INK);
            rx += 16 + smallWidth(c) + 4;
        }
        boolean again = data.completed.contains(q.id) && q.repeatable;
        small(g, "+" + q.xpLevels + " levels   +" + (again ? QuestData.repeatPoints(q) + " pts (repeat)" : q.points + " pts"), rx + 4, y, GREEN);

        float by = VH - 30, bh = 14;
        if (a == null) {
            boolean doneOnce = data.completed.contains(q.id) && !q.repeatable;
            boolean full = data.active.size() >= QuestData.MAX_ACTIVE;
            String label = doneOnce ? "Completed" : full ? "Quest log full" : data.completed.contains(q.id) ? "Accept again" : "Accept quest";
            button(g, x, by, 90, bh, label, !doneOnce && !full, true, () -> send(QuestData.ACTION_ACCEPT, q.id));
        } else {
            boolean rdy = ready(q, a);
            boolean anyHeld = false;
            Minecraft mc = Minecraft.getInstance();
            for (int i = 0; i < q.objectives.size(); i++) {
                Quest.Objective o = q.objectives.get(i);
                if (o.type == QuestType.COLLECT && a.progress[i] < o.count && mc.player != null && QuestData.held(mc.player, o) > 0) anyHeld = true;
            }
            String label = rdy ? "Claim reward" : q.hasHandIn() ? "Hand in items" : "In progress";
            button(g, x, by, 90, bh, label, rdy || anyHeld, true, () -> send(QuestData.ACTION_SUBMIT, q.id));
            button(g, x + 96, by, 60, bh, "Abandon", true, false, () -> send(QuestData.ACTION_ABANDON, q.id));
        }
        button(g, x + w - 56, by, 56, bh, "Back", true, false, () -> openId = null);
    }

    private void send(int action, String id) {
        AddonNetwork.sendToServer(new PacketQuestAction(action, pos, id));
    }
}
