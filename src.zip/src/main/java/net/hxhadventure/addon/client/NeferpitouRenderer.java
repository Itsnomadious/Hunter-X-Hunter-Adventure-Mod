package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.util.Mth;
import net.hxhadventure.addon.NeferpitouEntity;

/**
 * Draws Neferpitou with the player model, and her Pounce pose: a full squat leaning forward while she gathers herself, then flat out along
 * the line of the leap with her head leading. The pose is applied to the whole entity (the aura layer inherits it), so it needs no animation clip.
 */
public class NeferpitouRenderer extends NpcPlayerRenderer<NeferpitouEntity> {
    public NeferpitouRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, n -> tex("neferpitou"), n -> false);
        addLayer(new NpcAuraLayer<>(this, tex("pinkaura_ten"), npc -> {
            int f = npc.nenFlags();
            if ((f & NeferpitouEntity.F_TEN) == 0) return null;
            boolean ko = (f & NeferpitouEntity.F_KO) != 0;
            boolean ken = (f & NeferpitouEntity.F_KEN) != 0;
            float g = ko ? 0.55f : 1f; // Ko: her aura pulls into a deep red
            return new float[] {ko || ken ? 1.2f : 1.1f, ko || ken ? 1.3f : 1.2f, ko ? 0.9f : ken ? 0.85f : 0.6f, g, g};
        }));
    }

    @Override
    protected void setupRotations(NeferpitouEntity npc, PoseStack pose, float ageInTicks, float rotationYaw, float partialTick) {
        super.setupRotations(npc, pose, ageInTicks, rotationYaw, partialTick);
        int state = npc.pounceState();
        if (state == NeferpitouEntity.POUNCE_CROUCH) {
            pose.translate(0.0, 0.5, 0.0);
            pose.mulPose(Axis.XP.rotationDegrees(-58.0f));
            pose.translate(0.0, -0.5, 0.0);
            pose.scale(1.0f, 0.70f, 1.0f);
        } else if (state == NeferpitouEntity.POUNCE_LEAP) {
            float pitch = Mth.lerp(partialTick, npc.xRotO, npc.getXRot()); // + = looking down
            pose.translate(0.0, 0.9, 0.0);
            pose.mulPose(Axis.XP.rotationDegrees(-(90.0f + pitch)));
            pose.translate(0.0, -0.9, 0.0);
        }
    }
}
