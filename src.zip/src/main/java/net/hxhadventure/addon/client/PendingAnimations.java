package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.abilities.AnimationHandler;

/**
 * Animation packets can reach a client before the player they are for exists there (just tracked, just respawned, changed dimension) or
 * before its animation layer is set up; the clip used to be dropped, so the attack showed no animation. They wait here and play as soon as
 * the player is ready. A clip that is still not playable after about a second is too old to matter and is dropped.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class PendingAnimations {
    private PendingAnimations() {}

    private static final int MAX_AGE = 20;
    private static final int MAX_QUEUE = 64;
    private static final class Entry {
        final UUID id; final String anim; final boolean barrage; int age;
        Entry(UUID id, String anim, boolean barrage) { this.id = id; this.anim = anim; this.barrage = barrage; }
    }
    private static final List<Entry> QUEUE = new ArrayList<>();

    public static void add(UUID id, String anim, boolean barrage) {
        if (QUEUE.size() < MAX_QUEUE) QUEUE.add(new Entry(id, anim, barrage));
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || QUEUE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            QUEUE.clear();
            return;
        }
        for (Iterator<Entry> it = QUEUE.iterator(); it.hasNext(); ) {
            Entry en = it.next();
            Player p = mc.level.getPlayerByUUID(en.id);
            if (p != null && AnimationHandler.canPlay(p)) {
                AnimationHandler.playAnimation(p, en.anim, en.barrage);
                it.remove();
            } else if (++en.age > MAX_AGE) {
                it.remove();
            }
        }
    }
}
