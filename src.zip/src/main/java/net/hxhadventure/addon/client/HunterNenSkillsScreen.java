package net.hxhadventure.addon.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import java.util.List;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.client.Minecraft;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.Affinity;
import net.hxhadventure.addon.ClientAddonState;
import net.hxhadventure.addon.NenSkill;
import net.hxhadventure.addon.Tuning;
import net.hxhadventure.addon.Vows;
import net.hxhadventure.addon.network.PacketEnRadius;
import net.hxhadventure.addon.network.PacketRenSize;
import net.hxhadventure.addon.network.PacketInVisibility;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketAddonAction;
import net.hxhadventure.addon.network.PacketAddonAction.Action;

/** Mastery menu: overall level, skill levels, affinity passive and aura form buttons. Drawn as the front of a Hunter License (HunterUi). */
public class HunterNenSkillsScreen extends Screen {
    private static final int ROW = 18;
    private static final int HALF_W = 172;
    private static final int PANEL_H = 298; // card height with 8 skill rows
    private static final int HEAD_H = 52;    // black head of the licence
    private static final int BAR_W = 80;
    private static final int SLIDER_X = 46;
    private static final int SLIDER_W = 108;

    /** Mastery grade colours, darkened to read on the licence's white paper: Novice slate, Great blue, Excellent red, Genius purple (bold), Ultimate gold (bold). */
    private static final int[] GRADE_COLOURS = {0x2B3744, 0x1565C0, 0xC01D32, 0x7B2FBF, 0xA87400};
    private static final int[] GRADE_BAR_COLOURS = {0x7F8C99, 0x2E86DE, 0xD22B3F, 0x8E44D9, 0xE0A800};

    /** Text on the licence is drawn without a shadow. */
    private static int rgb(int c) {
        return 0xFF000000 | c;
    }

    private static MutableComponent gradeText(int rank, String text) {
        Style style = Style.EMPTY.withColor(TextColor.fromRgb(GRADE_COLOURS[rank])).withBold(rank >= 3);
        return Component.literal(text).withStyle(style);
    }

    public HunterNenSkillsScreen() {
        super(Component.literal("Mastery"));
    }

    /** The level a skill performs at (trained level raised by Vows and lockouts, can pass 100). */
    private static int eff(NenSkill s) {
        return Vows.effLevel(Minecraft.getInstance().player, s, ClientAddonState.level[s.ordinal()]);
    }

    /** Biggest En radius the local player can pick (their En level and affinity). */
    private static float enMaxRadius() {
        Minecraft mc = Minecraft.getInstance();
        Combat c = mc.player != null ? Combat.get(mc.player) : null;
        int type = ClientAddonState.emperor ? Affinity.ALL : (c != null ? c.getNenType() : 0);
        return Math.min(Vows.enRadiusLimit(mc.player), Tuning.enRadius(eff(NenSkill.EN), Affinity.enRadiusMult(type))); // sworn: En reaches 1 or 4 meters at most
    }

    /** A slider that snaps to a step, shows a short label, and sends its value to the server when released or when the screen closes. */
    private static class RangeSlider extends AbstractSliderButton {
        private final float min, max, step;
        private final java.util.function.Function<Float, String> label;
        private final java.util.function.Consumer<Float> send;
        private float pending = Float.NaN;

        RangeSlider(int x, int y, int w, int h, float min, float max, float step, float start,
                    java.util.function.Function<Float, String> label, java.util.function.Consumer<Float> send) {
            super(x, y, w, h, Component.empty(), max <= min ? 0.0 : (Math.max(min, Math.min(max, start)) - min) / (max - min));
            this.min = min;
            this.max = max;
            this.step = step;
            this.label = label;
            this.send = send;
            updateMessage();
        }

        private float current() {
            if (max <= min) return min;
            if (this.value >= 0.995) return max;
            float raw = min + (float) this.value * (max - min);
            float snapped = min + Math.round((raw - min) / step) * step;
            return Math.round(Math.max(min, Math.min(max, snapped)) * 100f) / 100f;
        }

        /** Licence slider: pale track, blue fill, dark handle that turns diamond red on hover. */
        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partial) {
            boolean hover = this.isHoveredOrFocused() && this.active;
            int x = getX(), y = getY();
            int line = !this.active ? HunterUi.DISABLED_LINE : (hover ? HunterUi.RED : HunterUi.PAPER_LINE);
            HunterUi.rr(g, x, y, width, height, 2, line);
            g.fill(x + 1, y + 1, x + width - 1, y + height - 1, this.active ? 0xFFE6F1FA : HunterUi.DISABLED_FILL);
            int fillW = (int) ((width - 2) * this.value);
            if (fillW > 0) g.fill(x + 1, y + 1, x + 1 + fillW, y + height - 1, this.active ? 0xFF8EC3EE : 0xFFBFCAD4);
            int hx = x + 1 + Math.max(0, Math.min(width - 5, fillW - 2));
            g.fill(hx, y + 1, hx + 3, y + height - 1, line);
            String text = Minecraft.getInstance().font.plainSubstrByWidth(getMessage().getString(), width - 6);
            g.drawString(Minecraft.getInstance().font, text, x + (width - Minecraft.getInstance().font.width(text)) / 2, y + (height - 8) / 2,
                this.active ? HunterUi.INK : HunterUi.DISABLED_TEXT, false);
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal(label.apply(current())));
        }

        @Override
        protected void applyValue() {
            pending = current();
        }

        void flush() {
            if (!Float.isNaN(pending)) {
                send.accept(pending);
                pending = Float.NaN;
            }
        }

        @Override
        public void onRelease(double mx, double my) {
            super.onRelease(mx, my);
            flush();
        }
    }

    private RangeSlider enSlider, renSlider, inSlider;
    private HunterUi.HunterButton shuButton;

    @Override
    public void removed() {
        if (enSlider != null) enSlider.flush(); // keyboard changes and anything not sent on release
        if (renSlider != null) renSlider.flush();
        if (inSlider != null) inSlider.flush();
        super.removed();
    }

    /** Widest text allowed inside the panel (the inset boxes are 320 wide). */
    private static final int TEXT_W = 308;
    private static final int LINE_H = 10;

    private List<FormattedCharSequence> typeLines = List.of();
    private int extra = 0;

    /** The Nen type / affinity text, word-wrapped so it can never run off the ends of the panel. */
    private List<FormattedCharSequence> buildTypeLines() {
        Combat c = Minecraft.getInstance().player != null ? Combat.get(Minecraft.getInstance().player) : null;
        int type = ClientAddonState.emperor ? Affinity.ALL : (c != null ? c.getNenType() : 0);
        String text = (ClientAddonState.emperor || ClientProfile.revealed)
            ? Affinity.name(type)
            : "Nen type: unknown (use a Water Divination glass)";
        return this.font.split(FormattedText.of(text), TEXT_W);
    }

    private void refreshLayout() {
        typeLines = buildTypeLines();
        extra = Math.max(0, typeLines.size() - 1) * LINE_H;
    }

    private int panelH() {
        return PANEL_H + extra;
    }

    private int top() {
        return Math.max(16, this.height / 2 - panelH() / 2 + 8);
    }

    @Override
    protected void init() {
        refreshLayout();
        int cx = this.width / 2;
        int by = top() + 239 + extra;
        Action[] actions = {Action.TOGGLE_KEN, Action.TOGGLE_KO};
        String[] labels = {"Ken (toggle)", "Ko (toggle)"};
        for (int i = 0; i < actions.length; i++) {
            Action a = actions[i];
            boolean locked = Vows.isLocked(Minecraft.getInstance().player, i == 0 ? "KEN" : "KO");
            HunterUi.HunterButton formButton = HunterUi.button(cx - 160 + i * 164, by, 156, 20, locked ? labels[i].replace("(toggle)", "(locked)") : labels[i],
                b -> AddonNetwork.sendToServer(new PacketAddonAction(a)), false);
            formButton.active = !locked;
            addRenderableWidget(formButton);
        }
        // Sliders sit on the En and Ren rows, right of the skill bars.
        float enMax = enMaxRadius();
        float enStart = Tuning.enSelectedRadius(ClientAddonState.enChosen, enMax);
        int enRowY = top() + 81 + extra + NenSkill.EN.ordinal() * ROW;
        enSlider = new RangeSlider(cx + SLIDER_X, enRowY - 3, SLIDER_W, 14, Math.min(5f, enMax), enMax, 5f, enStart,
            v -> "En " + Math.round(v) + "m",
            v -> { ClientAddonState.enChosen = v; AddonNetwork.sendToServer(new PacketEnRadius(v)); });
        enSlider.active = !Vows.isLocked(Minecraft.getInstance().player, "EN");
        addRenderableWidget(enSlider);
        float renMax = Tuning.renMaxSize(eff(NenSkill.REN));
        int renRowY = top() + 81 + extra + NenSkill.REN.ordinal() * ROW;
        renSlider = new RangeSlider(cx + SLIDER_X, renRowY - 3, SLIDER_W, 14, 1.0f, renMax, 0.1f, ClientAddonState.renSize,
            v -> "Size " + String.format(java.util.Locale.ROOT, "%.1f", v) + "x",
            v -> { ClientAddonState.renSize = v; AddonNetwork.sendToServer(new PacketRenSize(v)); });
        renSlider.active = !Vows.isLocked(Minecraft.getInstance().player, "REN");
        addRenderableWidget(renSlider);
        // Genius In: choose whether your hidden Nen (Chains, Bungee Gum) shows while In is on
        if (eff(NenSkill.IN) >= Tuning.IN_VISIBILITY_LEVEL) {
            int inRowY = top() + 81 + extra + NenSkill.IN.ordinal() * ROW;
            inSlider = new RangeSlider(cx + SLIDER_X, inRowY - 3, SLIDER_W, 14, 0f, 1f, 1f, ClientAddonState.inVisible ? 1f : 0f,
                v -> v >= 0.5f ? "Nen: Visible" : "Nen: Hidden",
                v -> { ClientAddonState.inVisible = v >= 0.5f; AddonNetwork.sendToServer(new PacketInVisibility(v >= 0.5f)); });
            addRenderableWidget(inSlider);
        }
        // Shu: an on/off button on its row (also the B key)
        int shuRowY = top() + 81 + extra + NenSkill.SHU.ordinal() * ROW;
        boolean shuLocked = Vows.isLocked(Minecraft.getInstance().player, "SHU");
        shuButton = HunterUi.button(cx + SLIDER_X, shuRowY - 3, SLIDER_W, 14, "Shu: Off",
            b -> AddonNetwork.sendToServer(new PacketAddonAction(Action.TOGGLE_SHU)), false);
        shuButton.active = !shuLocked;
        addRenderableWidget(shuButton);
        addRenderableWidget(HunterUi.button(cx - 40, by + 24, 80, 20, "Close", b -> onClose(), true));
        addRenderableWidget(HunterUi.button(cx + 44, by + 24, 116, 20, "Page 2: Vows >", b -> HunterUi.go(new HunterVowsScreen()), false));
        OMenu.addSide(this::addRenderableWidget, this.width, top() - 8, true, OMenu.Page.MASTERY);
}

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        // the type text can change while open (e.g. after Water Divination): re-lay everything out if its line count changed
        if (buildTypeLines().size() != typeLines.size()) this.rebuildWidgets();
        HunterUi.backdrop(g, this.width, this.height);
        int cx = this.width / 2;
        int top = top();
        int x0 = cx - HALF_W, y0 = top - 8;
        boolean flipping = HunterUi.flipBegin(g, cx);

        HunterUi.front(g, x0, y0, HALF_W * 2, panelH(), HEAD_H);

        // Head: logo plate, Hunter script, page name, and the photo strip holding the holder's name and level
        HunterUi.logo(g, x0 + 13, y0 + 9, 64, 44);
        HunterUi.script(g, x0 + 86, y0 + 10, 108, 13, 0xFFFFFFFF);
        g.drawString(this.font, "MASTERY", x0 + HALF_W * 2 - 14 - this.font.width("MASTERY"), y0 + 13, 0xFFFFFFFF, false);
        HunterUi.strip(g, x0 + 86, y0 + 26, HALF_W * 2 - 86 - 13, 27);

        Minecraft mc = Minecraft.getInstance();
        Combat c = mc.player != null ? Combat.get(mc.player) : null;
        int level = c != null ? c.getHatsuLevel() : 1;
        int stripCx = x0 + 86 + (HALF_W * 2 - 86 - 13) / 2;
        String holder = mc.player != null ? mc.player.getName().getString() : "Hunter";
        g.drawString(this.font, holder, stripCx - this.font.width(holder) / 2, y0 + 30, HunterUi.INK_DIM, false);
        MutableComponent levelText = Component.literal("Level " + level + (level >= Combat.MAX_LEVEL ? " (MAX)" : "") + "   Mastery: ")
            .withStyle(Style.EMPTY.withColor(TextColor.fromRgb(HunterUi.INK & 0xFFFFFF)))
            .append(gradeText(Tuning.gradeRank(level), Combat.masteryGrade(level)));
        g.drawString(this.font, levelText, stripCx - this.font.width(levelText) / 2, y0 + 41, 0xFFFFFFFF, false);

        // Nen type, in the licence's bordered title box
        boolean known = ClientAddonState.emperor || ClientProfile.revealed;
        HunterUi.inset(g, cx - 160, top + 55, 320, 16 + extra);
        for (int i = 0; i < typeLines.size(); i++) {
            FormattedCharSequence line = typeLines.get(i);
            g.drawString(this.font, line, cx - this.font.width(line) / 2, top + 59 + i * LINE_H, known ? HunterUi.NAVY : HunterUi.INK_DIM, false);
        }

        // Skill table on white paper
        HunterUi.inset(g, cx - 160, top + 75 + extra, 320, 146);
        int y = top + 81 + extra;
        boolean anyBoosted = false;
        for (NenSkill s : NenSkill.values()) {
            int trained = ClientAddonState.level[s.ordinal()];
            int lvl = eff(s); // what the skill performs at; a * marks a level boosted by Vows
            boolean boosted = lvl != trained;
            anyBoosted |= boosted;
            float prog = Math.max(0f, Math.min(1f, ClientAddonState.progress[s.ordinal()]));
            int rank = Tuning.gradeRank(lvl);
            MutableComponent skillText = gradeText(rank, s.label + "  Lv " + lvl + (boosted ? "*" : ""));
            g.drawString(this.font, skillText, cx - 154, y, 0xFFFFFFFF, false);
            if (trained >= NenSkill.MAX_LEVEL) g.drawString(this.font, "\u2605", cx - 154 + this.font.width(skillText) + 3, y, HunterUi.GOLD, false);
            int bx = cx - 40;
            g.fill(bx - 1, y, bx + BAR_W + 1, y + 9, HunterUi.INK_DIM);
            g.fill(bx, y + 1, bx + BAR_W, y + 8, 0xFFDCE6EF);
            if (Vows.isLocked(mc.player, s.name())) {
                g.drawString(this.font, "LOCKED", bx + (BAR_W - this.font.width("LOCKED")) / 2, y + 1, HunterUi.RED, false);
            } else {
                g.fill(bx, y + 1, bx + (int) (BAR_W * prog), y + 8, rgb(GRADE_BAR_COLOURS[rank]));
            }
            y += ROW;
        }
        String form = this.font.plainSubstrByWidth("Aura form: " + ClientAddonState.formLabel() + (anyBoosted ? "     * boosted by Vows" : ""), TEXT_W);
        g.drawString(this.font, form, cx - this.font.width(form) / 2, top + 227 + extra, HunterUi.NAVY, false);
        if (shuButton != null) shuButton.setMessage(Component.literal(ClientAddonState.shu ? "Shu: On" : "Shu: Off"));
        super.render(g, mouseX, mouseY, partial);
        HunterUi.flipEnd(g, flipping);
    }
}
