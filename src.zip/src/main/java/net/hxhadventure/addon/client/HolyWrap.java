package net.hxhadventure.addon.client;

import net.minecraft.world.phys.Vec3;

/**
 * Where the Holy Chain goes when you use it on yourself, in one place so the arms (ChainArm) and the chain (ChainRenderer) agree:
 * from the right hand's thumb, in under the left arm, round its left (outer) side and up over the top, and the cross lies on the
 * top of the left forearm with its foot toward the hand.
 *
 * Positions along the left arm are fractions u of the way from the shoulder (0) to the hand (1).
 */
final class HolyWrap {
    private HolyWrap() {}

    /** Shoulder to hand of an arm, blocks (the same reach ChainArm poses with). */
    static final double ARM_LEN = 0.68;
    /** Where the chain comes up under the arm, and where it has reached the top (the cross hangs from here, lying toward the hand). */
    static final double U_START = 0.30, U_END = 0.50;
    /** Distance of the wrapped chain from the arm's axis: the arm is about 0.23 wide, so this rides just on its surface. */
    static final double RADIUS = 0.145;
    /** Length of the cross, blocks. */
    static final double CROSS_LEN = 0.14;

    /** The left arm's own axes: along the arm, out to its left side, and up from its top. */
    static final class Frame {
        final Vec3 shoulder, ax, left, up;

        Frame(Vec3 shoulder, Vec3 ax, Vec3 left, Vec3 up) {
            this.shoulder = shoulder;
            this.ax = ax;
            this.left = left;
            this.up = up;
        }
    }

    static Frame frame(Vec3 leftShoulder, Vec3 leftDir, float bodyYawDeg) {
        Vec3 ax = leftDir.normalize();
        double rad = Math.toRadians(bodyYawDeg);
        Vec3 bodyLeft = new Vec3(Math.cos(rad), 0, Math.sin(rad));            // the player's left, horizontal
        Vec3 left = bodyLeft.subtract(ax.scale(bodyLeft.dot(ax)));
        left = left.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : left.normalize();
        Vec3 up = ax.cross(left);                                              // ax x left points up for an arm held out in front
        if (up.y < 0) up = up.scale(-1);
        return new Frame(leftShoulder, ax, left, up.normalize());
    }

    /** A point on the left arm: u along it, theta round it (-90 deg = underneath, 0 = its left side, +90 deg = on top), at this radius from the axis. */
    static Vec3 ring(Frame f, double u, double thetaRad, double radius) {
        return f.shoulder.add(f.ax.scale(ARM_LEN * u))
            .add(f.left.scale(Math.cos(thetaRad) * radius)).add(f.up.scale(Math.sin(thetaRad) * radius));
    }

    /** Where the right hand holds the chain's start: below and a little in front of where the chain comes up under the arm. */
    static Vec3 holdPoint(Frame f, Vec3 rightShoulder) {
        Vec3 under = ring(f, U_START, -Math.PI / 2, RADIUS);
        Vec3 toBody = rightShoulder.subtract(f.shoulder);
        toBody = new Vec3(toBody.x, 0, toBody.z).normalize();                  // across the chest, from the left arm to the right shoulder
        return under.add(f.up.scale(-0.10)).add(toBody.scale(0.14));
    }
}
