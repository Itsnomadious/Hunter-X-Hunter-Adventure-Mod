package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.addon.CrazySlotsEntity;
import net.hxhadventure.addon.CrazySlotsTuning;

/**
 * Draws Crazy Slots' clown: the {@link CrazySlotsModel} at {@link CrazySlotsTuning#CLOWN_HEIGHT}, with the roulette number written on its
 * tongue. Idle it shows "?", while the wheel spins it flickers through 1 to 9, and when it stops it shows the number that was drawn
 * (and pulses a little).
 */
public class CrazySlotsRenderer extends EntityRenderer<CrazySlotsEntity> {
    private final CrazySlotsModel model;

    public CrazySlotsRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.model = new CrazySlotsModel(ctx.bakeLayer(CrazySlotsModel.LAYER));
        this.shadowRadius = 0f;
    }

    @Override
    public ResourceLocation getTextureLocation(CrazySlotsEntity e) {
        return CrazySlotsModel.TEXTURE;
    }

    @Override
    public void render(CrazySlotsEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float s = CrazySlotsTuning.CLOWN_HEIGHT / (CrazySlotsModel.MODEL_HEIGHT_PX / 16f);
        float time = e.tickCount + pt;
        int phase = e.phase();
        float pulse = phase == CrazySlotsEntity.PHASE_LANDED ? 1f + 0.06f * (float) Math.sin(time * 0.9) : 1f;

        // Locked to the owner's shoulder every frame: the entity itself only moves with the server's ticks, which would trail a running player
        float faceYaw = Mth.rotLerp(pt, e.yRotO, e.getYRot());
        Vec3 shift = Vec3.ZERO;
        Entity owner = e.ownerEntityId() < 0 ? null : e.level().getEntity(e.ownerEntityId());
        if (owner instanceof LivingEntity lo) {
            Vec3 want = CrazySlotsEntity.hoverPoint(lo, pt, time);
            Vec3 at = new Vec3(Mth.lerp(pt, e.xo, e.getX()), Mth.lerp(pt, e.yo, e.getY()), Mth.lerp(pt, e.zo, e.getZ()));
            shift = want.subtract(at);
            Vec3 op = lo.getPosition(pt);
            faceYaw = (float) (Mth.atan2(-(op.x - want.x), op.z - want.z) * (180.0 / Math.PI)); // toward the owner, the same way the server turns it
        }

        ps.pushPose();
        ps.translate(shift.x, shift.y, shift.z);
        ps.mulPose(Axis.YP.rotationDegrees(180f - faceYaw));
        ps.scale(-s * pulse, -s * pulse, s * pulse);
        ps.translate(0f, -(CrazySlotsModel.FEET_Y / 16f + 0.001f), 0f); // soles at model y = 56
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(CrazySlotsModel.TEXTURE));
        model.render(ps, vc, light, OverlayTexture.NO_OVERLAY, time);

        // the roulette on the tongue
        String text;
        int colour;
        if (phase == CrazySlotsEntity.PHASE_ROLLING) {
            text = String.valueOf(1 + (int) ((e.tickCount / 2 + e.getId() * 3) % 9)); // a new number every other tick
            colour = 0xFFF2D24A;
        } else if (phase == CrazySlotsEntity.PHASE_LANDED && e.number() > 0) {
            text = String.valueOf(e.number());
            colour = 0xFFFFE94A;
        } else {
            text = "?";
            colour = 0xFFE8B33A;
        }
        Font font = getFont();
        int w = Math.max(1, font.width(text));
        float sc = Math.min(CrazySlotsModel.SCREEN_W / w, CrazySlotsModel.SCREEN_H / 8f);
        ps.pushPose();
        ps.translate((CrazySlotsModel.SCREEN_X - w * sc / 2f) / 16f, (CrazySlotsModel.SCREEN_Y - 4f * sc) / 16f, CrazySlotsModel.SCREEN_Z / 16f);
        ps.scale(sc / 16f, sc / 16f, sc / 16f);
        font.drawInBatch(text, 0f, 0f, colour, true, ps.last().pose(), buf, Font.DisplayMode.POLYGON_OFFSET, 0, light);
        ps.popPose();
        ps.popPose();

        super.render(e, yaw, pt, ps, buf, light);
    }
}
