package net.hxhadventure.addon.client;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.ParticleTypes;

/**
 * Client-side record of every Doctor Blythe in view (fed by PacketBlytheFx), keyed by its owner's entity id.
 * It also owns the per-finger animation state: which entity each finger is reaching for and how far its tendril has grown.
 */
public final class BlytheFx {
    private BlytheFx() {}

    public static final int FINGERS = BlythePose.FINGERS;
    /** Ticks for a doll to appear / vanish, and for a tendril to grow out / pull back. */
    public static final double BORN_TICKS = 12, DIE_TICKS = 10;
    private static final double GROW_TICKS = 7, RETRACT_TICKS = 4;

    public static final class Rec {
        public final int owner;
        public double x, y, z;
        public float yawDeg;
        public int[] targets = new int[0];
        public double born, ended = -1;
        /** Per finger: entity id it is reaching for (-1 none) and tendril growth 0..1. */
        public final int[] fTarget = new int[FINGERS];
        public final float[] ext = new float[FINGERS];
        private double last = Double.NaN;

        Rec(int owner, double born) {
            this.owner = owner;
            this.born = born;
            Arrays.fill(fTarget, -1);
        }

        /** Hands the fingers out to the touched entities and eases every tendril. Call once per frame. */
        public void step(double time, ClientLevel level) {
            double dt = Double.isNaN(last) ? 0 : Math.min(5, Math.max(0, time - last));
            last = time;
            int n = targets.length;
            for (int f = 0; f < FINGERS; f++) {
                int want = ended >= 0 || n == 0 ? -1 : targets[(f + f / 5) % n];
                if (want >= 0 && level.getEntity(want) == null) want = -1;
                if (want == fTarget[f]) {
                    if (want >= 0) ext[f] = (float) Math.min(1.0, ext[f] + dt / GROW_TICKS);
                } else if (fTarget[f] < 0) {
                    fTarget[f] = want;
                    ext[f] = 0f;
                } else { // pull back from the old target first, then reach for the new one
                    ext[f] -= (float) (dt / RETRACT_TICKS);
                    if (ext[f] <= 0f) {
                        ext[f] = 0f;
                        fTarget[f] = want;
                    }
                }
            }
        }
    }

    private static final Map<Integer, Rec> ACTIVE = new HashMap<>();

    public static Map<Integer, Rec> all() {
        return ACTIVE;
    }

    public static boolean isEmpty() {
        return ACTIVE.isEmpty();
    }

    public static void set(int owner, boolean active, double x, double y, double z, float yaw, int[] targets) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        double now = level.getGameTime();
        Rec r = ACTIVE.get(owner);
        if (active) {
            if (r == null || r.ended >= 0) {
                r = new Rec(owner, now);
                ACTIVE.put(owner, r);
                burst(level, x, y, z);
            }
            r.x = x;
            r.y = y;
            r.z = z;
            r.yawDeg = yaw;
            r.targets = targets;
        } else if (r != null && r.ended < 0) {
            r.ended = now;
            r.targets = new int[0];
        }
    }

    /** Souls and smoke where it arrives. */
    private static void burst(ClientLevel level, double x, double y, double z) {
        for (int i = 0; i < 24; i++) {
            double a = level.random.nextDouble() * Math.PI * 2, rad = 0.4 + level.random.nextDouble() * 1.4;
            level.addParticle(i % 3 == 0 ? ParticleTypes.POOF : ParticleTypes.SOUL,
                x + Math.cos(a) * rad, y + 0.1, z + Math.sin(a) * rad, 0, 0.03 + level.random.nextDouble() * 0.05, 0);
        }
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
