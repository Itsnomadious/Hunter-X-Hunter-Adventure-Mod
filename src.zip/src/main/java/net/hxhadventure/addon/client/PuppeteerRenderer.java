package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Draws the Puppeteer: the upper body of a clownish puppet-master floating in mid-air, built as a real textured 3D
 * model ({@link PuppeteerModel}). A big round green body with a cream chest strip of red and orange triangles, huge maroon
 * tube sleeves topped with yellow discs, bony hands with long needle claws, and a green hooded head with one red forehead
 * slit, orange eyes, a mouthful of teeth and two jagged purple antennae. Ten white strings run from its fingertips down to
 * the puppet it controls (head, shoulders, hands, knees and feet), or dangle loose while it waits beside its user.
 *
 * Like the Terpsichora renderer it draws in two complete passes (solid, then translucent glow), because a
 * MultiBufferSource only lets one RenderType be open at a time.
 *
 * Figure space: +x is the puppet's left, +y up, +z the way the puppet faces; the origin is the bottom centre of the torso.
 * The puppet stands about 2 figure units in front of it and well below.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class PuppeteerRenderer {
    private PuppeteerRenderer() {}

    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/puppeteer.png");
    private static final double CULL_DISTANCE = 96.0;
    private static final float BOX = 2f;
    private static final int FULL = LightTexture.FULL_BRIGHT;
    private static final int FINGERS = 5;
    /** Figure-space distance from the puppeteer's torso to the puppet in front of it. */
    private static final double OZ = 2.0;
    private static final double PALM_LEN = 6 * 2 / 16.0 * 1.2;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || PuppeteerFx.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        double time = level.getGameTime() + pt;
        Vec3 cam = e.getCamera().getPosition();
        PuppeteerModel.Parts parts = PuppeteerModel.parts(mc);
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();

        List<Scene> scenes = new ArrayList<>();
        Iterator<PuppeteerFx.Rec> it = PuppeteerFx.all().values().iterator();
        while (it.hasNext()) {
            PuppeteerFx.Rec r = it.next();
            if (r.ended >= 0 && time - r.ended > PuppeteerFx.DIE_TICKS) {
                it.remove();
                continue;
            }
            Entity anchor = level.getEntity(r.anchor);
            if (anchor == null) {
                if (++r.missing > 400) it.remove(); // out of view or gone
                continue;
            }
            r.missing = 0;
            if (cam.distanceToSqr(anchor.getX(), anchor.getY(), anchor.getZ()) > CULL_DISTANCE * CULL_DISTANCE) continue;
            follow(r, anchor, time, pt);
            scenes.add(new Scene(e.getPoseStack(), parts, cam, level, r, anchor, time, pt));
        }
        if (scenes.isEmpty()) return;

        RenderType solid = RenderType.entityCutoutNoCull(TEX);
        VertexConsumer vc = buf.getBuffer(solid);
        for (Scene s : scenes) s.solidPass(vc);
        buf.endBatch(solid);

        RenderType fx = RenderType.entityTranslucent(TEX);
        VertexConsumer fvc = buf.getBuffer(fx);
        for (Scene s : scenes) s.fxPass(fvc);
        buf.endBatch(fx);
    }

    private static float yawOf(Entity e, float pt) {
        return e instanceof LivingEntity le ? Mth.rotLerp(pt, le.yBodyRotO, le.yBodyRot) : Mth.rotLerp(pt, e.yRotO, e.getYRot());
    }

    /** Eases the puppeteer toward where it should hover: behind and above its puppet, or off its user's shoulder while it waits. */
    private static void follow(PuppeteerFx.Rec r, Entity e, double time, float pt) {
        double dt = Double.isNaN(r.last) ? 99 : Math.min(5, Math.max(0, time - r.last));
        r.last = time;
        double h = e.getBbHeight();
        boolean attached = r.mode == PuppeteerFx.ATTACHED;
        r.base = attached ? Mth.clamp(0.75 * Math.max(1.0, h / 1.9), 0.6, 2.2) : 0.6;
        float yaw = yawOf(e, pt);
        double rad = Math.toRadians(yaw);
        double fx = -Math.sin(rad), fz = Math.cos(rad), lx = Math.cos(rad), lz = Math.sin(rad);
        double ex = Mth.lerp(pt, e.xo, e.getX()), ey = Mth.lerp(pt, e.yo, e.getY()), ez = Mth.lerp(pt, e.zo, e.getZ());
        double tx, ty, tz;
        if (attached) {
            double behind = OZ * r.base;
            tx = ex - fx * behind;
            tz = ez - fz * behind;
            ty = ey + h + 0.55 * r.base;
        } else { // waiting: floats off the user's right shoulder, a little behind
            tx = ex - fx * 1.0 - lx * 1.5;
            tz = ez - fz * 1.0 - lz * 1.5;
            ty = ey + 1.1;
        }
        if (!r.placed) {
            r.sx = tx;
            r.sy = ty;
            r.sz = tz;
            r.yaw = yaw;
            r.placed = true;
            return;
        }
        double k = 1 - Math.exp(-dt * 0.4);
        r.sx += (tx - r.sx) * k;
        r.sy += (ty - r.sy) * k;
        r.sz += (tz - r.sz) * k;
        r.yaw = Mth.rotLerp((float) k, r.yaw, yaw);
    }

    private static Vec3 v(double x, double y, double z) {
        return new Vec3(x, y, z);
    }

    // ------------------------------------------------------------------------------------------------------------

    private static final class Scene {
        final PoseStack ps;
        final PuppeteerModel.Parts parts;
        final Vec3 cam;
        final PuppeteerFx.Rec r;
        final Entity anchor;
        final double time;
        final float pt;
        final boolean attached;
        final double scale, phi;
        final int light;
        VertexConsumer vc;

        Vec3 shL, shR, elL, elR, haL, haR, headBase;
        double headPitch, headYaw, torsoPitch;
        final Vec3[][] fingerPts = new Vec3[2 * FINGERS][];

        Scene(PoseStack ps, PuppeteerModel.Parts parts, Vec3 cam, ClientLevel level, PuppeteerFx.Rec r, Entity anchor, double time, float pt) {
            this.ps = ps;
            this.parts = parts;
            this.cam = cam;
            this.r = r;
            this.anchor = anchor;
            this.time = time;
            this.pt = pt;
            this.attached = r.mode == PuppeteerFx.ATTACHED;
            double born = clamp((time - r.born) / PuppeteerFx.BORN_TICKS, 0, 1);
            double grow = 1 - Math.pow(1 - born, 3);
            double die = r.ended >= 0 ? clamp((time - r.ended) / PuppeteerFx.DIE_TICKS, 0, 1) : 0;
            this.scale = Math.max(0.001, r.base * grow * (1 - die));
            this.phi = -Math.toRadians(r.yaw);
            this.light = LevelRenderer.getLightColor(level, BlockPos.containing(r.sx, r.sy + 1.0, r.sz));
            pose();
        }

        static double clamp(double v, double lo, double hi) {
            return Math.max(lo, Math.min(hi, v));
        }

        /** Figure space to world. */
        Vec3 W(Vec3 f) {
            double x = f.x * scale, y = f.y * scale, z = f.z * scale;
            double cos = Math.cos(-phi), sin = Math.sin(-phi);
            return new Vec3(r.sx + x * cos - z * sin, r.sy + y, r.sz + x * sin + z * cos);
        }

        // ---------- the pose ----------
        void pose() {
            double t = time, ph = r.anchor * 1.3;
            double B = 0.10 * Math.sin(t * 0.10 + ph), sway = Math.sin(t * 0.08 + ph), a1 = t * 0.12 + ph;
            torsoPitch = 0.12 + 0.03 * sway;
            headBase = v(0, 1.85 + B, 0.15);
            headPitch = 0.22 + 0.05 * Math.sin(t * 0.13 + ph);
            headYaw = 0.18 * sway;
            shL = v(1.25, 1.55 + B, 0.0);
            shR = v(-1.25, 1.55 + B, 0.0);
            elL = v(2.15 + 0.12 * Math.sin(a1), 1.75 + B + 0.1 * Math.cos(a1), 0.85);
            elR = v(-2.15 - 0.12 * Math.sin(a1 + 1), 1.75 + B + 0.1 * Math.cos(a1 + 1), 0.85);
            haL = v(0.72 + 0.1 * Math.sin(a1 + 2), 1.55 + B + 0.1 * Math.sin(a1 + 1), OZ - 0.15 + 0.08 * Math.cos(a1));
            haR = v(-0.72 - 0.1 * Math.sin(a1 + 3), 1.55 + B + 0.1 * Math.sin(a1 + 2), OZ - 0.15 + 0.08 * Math.sin(a1));
            for (int h = 0; h < 2; h++) {
                int side = h == 0 ? 1 : -1;
                Vec3 wrist = h == 0 ? haL : haR;
                Vec3 base0 = wrist.add(v(0, -0.932, 0.362).scale(PALM_LEN));
                for (int k = 0; k < FINGERS; k++) {
                    double s = k - 2, curl = 0.05 * Math.sin(t * 0.22 + k * 0.9 + side + ph);
                    Vec3 knuckle = base0.add(s * 0.14, 0, 0);
                    Vec3 mid = knuckle.add(s * 0.10, -0.42, 0.14);
                    Vec3 tip = mid.add(s * 0.07 + curl, -0.40, 0.10);
                    Vec3 claw = tip.add(s * 0.02, -0.24, 0.05);
                    fingerPts[h * FINGERS + k] = new Vec3[] {knuckle, mid, tip, claw};
                }
            }
        }

        /** A point in the head's own frame (x sideways, y up, z out of the face) in figure space. */
        Vec3 headLocal(double x, double y, double z) {
            double c = Math.cos(headPitch), sn = Math.sin(headPitch);
            return headBase.add(x, y * c - z * sn, y * sn + z * c);
        }

        // ---------- drawing helpers (same scheme as the Terpsichora renderer) ----------
        void frame(Vec3 at, double yaw, double pitch, double roll) {
            Vec3 p = W(at);
            ps.pushPose();
            ps.translate(p.x - cam.x, p.y - cam.y, p.z - cam.z);
            ps.mulPose(Axis.YP.rotation((float) phi));
            ps.mulPose(Axis.YP.rotation((float) yaw));
            ps.mulPose(Axis.XP.rotation((float) pitch));
            ps.mulPose(Axis.ZP.rotation((float) roll));
            ps.scale((float) scale, (float) scale, (float) scale);
        }

        void child(ModelPart part, double k, int lt) {
            ps.pushPose();
            ps.scale(BOX * (float) k, BOX * (float) k, BOX * (float) k);
            ps.mulPose(Axis.XP.rotation((float) Math.PI));
            part.render(ps, vc, lt, OverlayTexture.NO_OVERLAY);
            ps.popPose();
        }

        void raw(ModelPart part, Vec3 a, Vec3 b, double thick, int lt) {
            double dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1e-5) return;
            ps.pushPose();
            ps.translate(a.x - cam.x, a.y - cam.y, a.z - cam.z);
            ps.mulPose(Axis.YP.rotation((float) Math.atan2(dx, dz)));
            ps.mulPose(Axis.XP.rotation((float) -Math.asin(clamp(dy / len, -1, 1))));
            float t = (float) (thick * 16.0), l = (float) (len * 16.0);
            ps.scale(t, t, l);
            part.render(ps, vc, lt, OverlayTexture.NO_OVERLAY);
            ps.popPose();
        }

        /** A stick between two figure-space points; thickness in figure units. */
        void bone(ModelPart part, Vec3 a, Vec3 b, double thick) {
            raw(part, W(a), W(b), thick * scale, light);
        }

        /** A limb narrowing from t0 to t1, built from short sticks. */
        void taper(ModelPart part, Vec3 a, Vec3 b, double t0, double t1) {
            double len = b.subtract(a).length();
            int n = Math.max(1, (int) Math.ceil(len / 0.35));
            for (int i = 0; i < n; i++) {
                double u0 = (double) i / n, u1 = (double) (i + 1) / n;
                bone(part, a.add(b.subtract(a).scale(u0)), a.add(b.subtract(a).scale(Math.min(1.0, u1 + 0.02))), t0 + (t1 - t0) * (u0 + u1) * 0.5);
            }
        }

        // ---------- pass 1: solid ----------
        void solidPass(VertexConsumer vc) {
            this.vc = vc;
            int lt = light;

            // body: a round green torso over a paler lower belly (the underside is dark, like an open arch)
            frame(v(0, -0.55, 0), 0, 0, 0);
            child(parts.lower(), 1.0, lt);
            ps.popPose();
            frame(v(0, 0.15, 0), 0, torsoPitch, 0);
            child(parts.torso(), 1.0, lt);
            ps.popPose();

            // arms: huge maroon tube sleeves with dark open ends, yellow discs on the shoulders, bony hands
            arm(shL, elL, haL, 1);
            arm(shR, elR, haR, -1);

            // head
            frame(headBase, headYaw, headPitch, 0);
            child(parts.head(), 1.0, lt);
            ps.popPose();
            // two jagged purple antennae with pink outlines and red tips
            for (int s = -1; s <= 1; s += 2) {
                Vec3[] p = {headLocal(s * 0.4, 1.2, 0), headLocal(s * 0.85, 1.65, 0), headLocal(s * 1.25, 1.35, 0),
                            headLocal(s * 1.7, 1.95, 0), headLocal(s * 2.15, 1.6, 0), headLocal(s * 2.55, 2.1, 0)};
                for (int i = 0; i < p.length - 1; i++) {
                    double w = 0.30 - 0.03 * i;
                    bone(parts.pink(), p[i], p[i + 1], w);
                    bone(parts.purple(), p[i], p[i + 1], w - 0.10);
                }
                bone(parts.red(), p[4].add(0, 0.05, 0), p[5].add(0, 0.12, 0), 0.30);
            }

            // ten strings: one per fingertip
            strings();
        }

        void arm(Vec3 sh, Vec3 el, Vec3 wrist, int side) {
            Vec3 dir1 = el.subtract(sh).normalize();
            Vec3 dir2 = wrist.subtract(el).normalize();
            // sleeves: upper tube, dark open ring at the elbow, forearm tube, dark cuff at the wrist
            bone(parts.maroon(), sh.subtract(dir1.scale(0.25)), el, 1.0);
            bone(parts.inner(), el.subtract(dir1.scale(0.04)), el.add(dir2.scale(0.10)), 1.06);
            bone(parts.maroon(), el, wrist, 0.82);
            bone(parts.inner(), wrist.subtract(dir2.scale(0.14)), wrist.add(dir2.scale(0.10)), 0.88);
            // yellow discs on top of the shoulder sleeve
            Vec3 n = v(0.25 * side, 1, 0.15).normalize();
            for (int i = 0; i < 3; i++) {
                Vec3 p = sh.add(el.subtract(sh).scale(0.18 + 0.30 * i)).add(0, 0.5, 0);
                bone(parts.yellow(), p, p.add(n.scale(0.22)), 0.62 - 0.05 * i);
            }
            // bony palm hanging down from the cuff
            frame(wrist, 0, Math.atan2(0.362, -0.932), 0);
            child(parts.palm(), 1.2, light);
            ps.popPose();
            int h = side > 0 ? 0 : 1;
            for (int k = 0; k < FINGERS; k++) {
                Vec3[] f = fingerPts[h * FINGERS + k];
                taper(parts.bone(), f[0], f[1], 0.075, 0.06);
                taper(parts.bone(), f[1], f[2], 0.06, 0.05);
                for (int j = 0; j < 3; j++) { // knobbly joints
                    Vec3 d = (j == 0 ? f[1].subtract(f[0]) : j == 1 ? f[2].subtract(f[1]) : f[3].subtract(f[2])).normalize().scale(0.05);
                    bone(parts.bone(), f[j].subtract(d), f[j].add(d), 0.14);
                }
                taper(parts.tip(), f[2], f[3], 0.05, 0.006); // needle claw
            }
        }

        void strings() {
            Vec3 e = new Vec3(Mth.lerp(pt, anchor.xo, anchor.getX()), Mth.lerp(pt, anchor.yo, anchor.getY()), Mth.lerp(pt, anchor.zo, anchor.getZ()));
            double rad = Math.toRadians(yawOf(anchor, pt));
            Vec3 ol = new Vec3(Math.cos(rad), 0, Math.sin(rad));
            double h = anchor.getBbHeight(), w = anchor.getBbWidth();
            for (int hd = 0; hd < 2; hd++) {
                int side = hd == 0 ? 1 : -1;
                for (int k = 0; k < FINGERS; k++) {
                    Vec3 tip = W(fingerPts[hd * FINGERS + k][3]);
                    Vec3 tgt;
                    if (attached) {
                        // head, shoulder, hand, knee, foot of the puppet (scaled to its size)
                        double[][] pts = {{0, 0.92}, {0.38, 0.78}, {0.62, 0.46}, {0.2, 0.28}, {0.2, 0.04}};
                        tgt = e.add(ol.scale(side * pts[k][0] * w)).add(0, pts[k][1] * h, 0);
                    } else { // waiting: the strings just hang
                        tgt = tip.add(0.2 * Math.sin(time * 0.17 + k + hd), -(1.5 + 0.25 * k), 0.15 * Math.cos(time * 0.13 + k));
                    }
                    double len = tgt.distanceTo(tip);
                    double sagAmt = Math.min(0.35, len * 0.03) + 0.03 * Math.sin(time * 0.3 + k);
                    int n = 8;
                    Vec3 prev = tip;
                    for (int i = 1; i <= n; i++) {
                        double u = (double) i / n;
                        double sag = sagAmt * (1 - Math.pow(2 * u - 1, 2));
                        Vec3 p = tip.add(tgt.subtract(tip).scale(u)).add(0, -sag, 0);
                        raw(parts.string(), prev, p, 0.02, FULL);
                        prev = p;
                    }
                }
            }
        }

        // ---------- pass 2: glowing eyes ----------
        void fxPass(VertexConsumer vc) {
            this.vc = vc;
            for (int s = -1; s <= 1; s += 2) {
                bone(parts.glow(), headLocal(s * 0.31, 0.66, 0.60), headLocal(s * 0.31, 0.86, 0.60), 0.14);
            }
            bone(parts.glow(), headLocal(0, 0.98, 0.60), headLocal(0, 1.18, 0.60), 0.07); // the forehead slit
        }
    }
}
