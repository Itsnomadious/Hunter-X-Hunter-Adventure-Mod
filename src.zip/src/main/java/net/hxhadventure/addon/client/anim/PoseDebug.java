package net.hxhadventure.addon.client.anim;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/**
 * Client-only preview state driven by the /pose commands. While a debug pose or animation is active it replaces the
 * normal pose of the LOCAL player (whatever else is animating them), so a pose can be inspected, edited live and
 * dumped back to json. Nothing here is networked.
 */
public final class PoseDebug {
    private PoseDebug() {}

    private static Pose override;          // a pose being shown / edited
    private static String animName;        // an animation being played instead of the override
    private static boolean loop = true;
    private static float frozenAt = Float.NaN;
    private static float startAge = Float.NaN;
    private static Pose lastShown;         // what the last frame actually displayed

    public static boolean active(Entity e) {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && e == mc.player && (override != null || animName != null);
    }

    public static boolean anyActive() {
        return override != null || animName != null;
    }

    /** The pose to show for this entity this frame, or null to use the normal pose logic. */
    public static Pose poseFor(LivingEntity e, float age) {
        if (!active(e)) return null;
        Pose p = override;
        if (animName != null) {
            Animation a = PoseLibrary.animation(animName);
            if (a != null) {
                if (Float.isNaN(startAge)) startAge = age;
                float t = Float.isNaN(frozenAt) ? age - startAge : frozenAt;
                if (loop && a.length > 0F) t = t % a.length;
                p = a.sample(t);
            }
        }
        lastShown = p;
        return p;
    }

    public static void show(Pose pose) {
        override = pose.copy();
        animName = null;
    }

    public static void play(String name, boolean doLoop) {
        animName = name;
        loop = doLoop;
        frozenAt = Float.NaN;
        startAge = Float.NaN;
    }

    public static void freeze(float tick) {
        frozenAt = tick;
    }

    public static void resume() {
        frozenAt = Float.NaN;
        startAge = Float.NaN;
    }

    public static void clear() {
        override = null;
        animName = null;
        frozenAt = Float.NaN;
        lastShown = null;
        PoseRig.lastInfo = java.util.List.of();
    }

    /** A pose that can be edited: the one being shown (an animation is frozen into its current frame first). */
    public static Pose edit() {
        if (animName != null || override == null) {
            Pose src = lastShown != null ? lastShown : PoseLibrary.pose("neutral");
            override = src == null ? new Pose() : src.copy();
            animName = null;
        }
        return override;
    }

    /** Re-solves pitch_down after an edit. */
    public static void rebake() {
        if (override != null) PoseRig.bake(override);
    }
}
