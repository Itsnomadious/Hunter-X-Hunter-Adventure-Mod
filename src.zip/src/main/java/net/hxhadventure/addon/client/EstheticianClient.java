package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Quaternionf;
import net.hxhadventure.addon.EstheticianTuning;
import net.hxhadventure.addon.MagicalEsthetician;

/**
 * Client side of Magical Esthetician: the owner sitting or lying face down while Cookie works, and the growth of Body Transformation.
 * The hitbox and eye height are changed by an EntityEvent.Size hook (so the camera is right, see EstheticianEvents); this draws the model
 * lower / lying / bigger, and bends the limbs (called from PlayerModelMixin).
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class EstheticianClient {
    private EstheticianClient() {}

    /** Per entity id: {previous tick's scale, this tick's scale}. Only players that are, or are still shrinking back from, the form. */
    private static final Map<Integer, float[]> SCALE = new HashMap<>();
    private static final Set<Integer> PUSHED = new HashSet<>();
    private static final float GROW_PER_TICK = 0.04f;

    /** PacketEstheticianFx: a player entered or left Body Transformation. */
    public static void setForm(int owner, boolean on) {
        MagicalEsthetician.setClientForm(owner, on);
        SCALE.computeIfAbsent(owner, k -> new float[] {1f, 1f});
        refresh(owner);
    }

    /** PacketEstheticianFx: a player sat down, lay down or stood up (pose 0). */
    public static void setPose(int owner, int pose, float yaw) {
        MagicalEsthetician.setClientPose(owner, pose, yaw);
        refresh(owner);
    }

    private static void refresh(int owner) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity e = mc.level.getEntity(owner);
        if (e instanceof Player p) p.refreshDimensions();
    }

    /** The scale this entity is drawn at (1 for everyone not in the form). */
    public static float scale(Entity e, float partialTick) {
        if (e == null) return 1f;
        float[] s = SCALE.get(e.getId());
        return s == null ? 1f : Mth.lerp(partialTick, s[0], s[1]);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || SCALE.isEmpty()) return;
        Iterator<Map.Entry<Integer, float[]>> it = SCALE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, float[]> en = it.next();
            float target = MagicalEsthetician.clientHasForm(en.getKey()) ? EstheticianTuning.TRANSFORM_HEIGHT_MULT : 1f;
            float[] s = en.getValue();
            s[0] = s[1];
            s[1] = s[1] < target ? Math.min(target, s[1] + GROW_PER_TICK) : Math.max(target, s[1] - GROW_PER_TICK);
            if (s[0] == 1f && s[1] == 1f && target == 1f) it.remove();
        }
    }

    @SubscribeEvent
    public static void onPre(RenderPlayerEvent.Pre e) {
        Player p = e.getEntity();
        int pose = MagicalEsthetician.pose(p);
        float s = scale(p, e.getPartialTick());
        if (pose == MagicalEsthetician.POSE_NONE && s == 1f) return;
        PoseStack ps = e.getPoseStack();
        ps.pushPose(); // the pose stack is at the player's feet here
        PUSHED.add(p.getId());
        if (pose == MagicalEsthetician.POSE_SIT) {
            ps.translate(0.0, -EstheticianTuning.SIT_DROP * s, 0.0);
        } else if (pose == MagicalEsthetician.POSE_LIE) {
            float yaw = MagicalEsthetician.clientPoseYaw(p.getId());
            p.yBodyRot = yaw;
            p.yBodyRotO = yaw; // the body keeps the way it faced when the massage began
            double r = Math.toRadians(yaw);
            float fx = (float) -Math.sin(r), fz = (float) Math.cos(r);
            ps.translate(-fx * 0.85f * s, 0.25f * s, -fz * 0.85f * s); // lying along the facing direction, centred on the player
            ps.mulPose(new Quaternionf().rotateTo(0f, 1f, 0f, fx, 0f, fz)); // head forward, chest down
        }
        if (s != 1f) ps.scale(s, s, s);
    }

    @SubscribeEvent
    public static void onPost(RenderPlayerEvent.Post e) {
        if (PUSHED.remove(e.getEntity().getId())) e.getPoseStack().popPose();
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        MagicalEsthetician.clearClient();
        SCALE.clear();
        PUSHED.clear();
    }

    /** Sitting legs, lying head: bends the limbs after the game has posed the player. Called from PlayerModelMixin. */
    public static void applyPose(PlayerModel<?> model, LivingEntity entity) {
        if (!(entity instanceof AbstractClientPlayer p)) return;
        int pose = MagicalEsthetician.pose(p);
        if (pose == MagicalEsthetician.POSE_NONE) return;
        Minecraft mc = Minecraft.getInstance();
        if (p == mc.player && mc.options.getCameraType().isFirstPerson()) return; // first person draws its own hand
        if (pose == MagicalEsthetician.POSE_SIT) {
            model.rightLeg.xRot = -1.4137167f;
            model.rightLeg.yRot = 0.31415927f;
            model.rightLeg.zRot = 0.07853982f;
            model.leftLeg.xRot = -1.4137167f;
            model.leftLeg.yRot = -0.31415927f;
            model.leftLeg.zRot = -0.07853982f;
            model.rightArm.xRot = -0.7f;
            model.rightArm.yRot = 0f;
            model.rightArm.zRot = 0.1f;
            model.leftArm.xRot = -0.7f;
            model.leftArm.yRot = 0f;
            model.leftArm.zRot = -0.1f;
        } else {
            model.rightLeg.xRot = 0f;
            model.rightLeg.yRot = 0f;
            model.rightLeg.zRot = 0f;
            model.leftLeg.xRot = 0f;
            model.leftLeg.yRot = 0f;
            model.leftLeg.zRot = 0f;
            model.rightArm.xRot = 0f;
            model.rightArm.yRot = 0f;
            model.rightArm.zRot = 0.08f;
            model.leftArm.xRot = 0f;
            model.leftArm.yRot = 0f;
            model.leftArm.zRot = -0.08f;
            model.head.xRot -= 1.5707964f; // chest down: looking straight ahead means the head tips up along the body
        }
        model.rightPants.copyFrom(model.rightLeg);
        model.leftPants.copyFrom(model.leftLeg);
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);
        model.hat.copyFrom(model.head);
    }
}
