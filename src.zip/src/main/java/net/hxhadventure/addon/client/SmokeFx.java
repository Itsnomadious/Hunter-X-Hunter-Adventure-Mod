package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.hxhadventure.addon.SmokeTuning;
import net.hxhadventure.addon.network.PacketSmokeFx;

/**
 * Arm poses for Smoke Manipulation, for everyone who can see the cast (fed by PacketSmokeFx):
 * BLOW lifts the arm that holds the pipe so the mouthpiece is at the mouth and tilts the head back a little,
 * JAIL throws both arms out wide while the user breathes the dome out.
 * Like the other arm effects it leaves the caster's own first-person arm alone.
 */
public final class SmokeFx {
    private SmokeFx() {}

    private static final class Fx {
        final int kind;
        final boolean left;
        final double t0;
        final double life;

        Fx(int kind, boolean left, double t0, double life) {
            this.kind = kind;
            this.left = left;
            this.t0 = t0;
            this.life = life;
        }
    }

    private static final Map<Integer, Fx> ACTIVE = new HashMap<>();

    public static void add(int owner, int kind, boolean left) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        double life = kind == PacketSmokeFx.BLOW ? SmokeTuning.BLOW_TICKS + 8 : 40;
        ACTIVE.put(owner, new Fx(kind, left, level.getGameTime(), life));
    }

    public static void applyArm(PlayerModel<?> model, LivingEntity entity) {
        if (ACTIVE.isEmpty() || !(entity instanceof AbstractClientPlayer p)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || (p == mc.player && mc.options.getCameraType().isFirstPerson())) return;
        Fx fx = ACTIVE.get(p.getId());
        if (fx == null) return;
        double age = mc.level.getGameTime() + mc.getFrameTime() - fx.t0;
        if (age < 0) return;
        if (age > fx.life) {
            ACTIVE.remove(p.getId());
            return;
        }
        float w = (float) Mth.clamp(Math.min(age / 3.0, (fx.life - age) / 4.0), 0, 1); // ease in and out
        float side = fx.left ? -1f : 1f; // outward direction for this arm's z rotation

        if (fx.kind == PacketSmokeFx.BLOW) {
            var arm = fx.left ? model.leftArm : model.rightArm;
            // upper arm raised and turned in, so the hand (and the pipe's mouthpiece) is at the mouth
            arm.xRot = Mth.lerp(w, arm.xRot, -1.95f + Mth.sin((float) age * 0.5f) * 0.04f);
            arm.yRot = Mth.lerp(w, arm.yRot, -side * 0.45f);
            arm.zRot = Mth.lerp(w, arm.zRot, 0f);
            model.head.xRot = Mth.lerp(w, model.head.xRot, model.head.xRot - 0.25f);
            if (fx.left) model.leftSleeve.copyFrom(model.leftArm);
            else model.rightSleeve.copyFrom(model.rightArm);
            model.hat.copyFrom(model.head);
        } else {
            // both arms flung out and a little up while the breath goes out
            float wave = Mth.sin((float) age * 0.3f) * 0.06f;
            model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, -0.2f);
            model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, 0f);
            model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, 1.35f + wave);
            model.leftArm.xRot = Mth.lerp(w, model.leftArm.xRot, -0.2f);
            model.leftArm.yRot = Mth.lerp(w, model.leftArm.yRot, 0f);
            model.leftArm.zRot = Mth.lerp(w, model.leftArm.zRot, -1.35f - wave);
            model.head.xRot = Mth.lerp(w, model.head.xRot, -0.35f);
            model.rightSleeve.copyFrom(model.rightArm);
            model.leftSleeve.copyFrom(model.leftArm);
            model.hat.copyFrom(model.head);
        }
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
