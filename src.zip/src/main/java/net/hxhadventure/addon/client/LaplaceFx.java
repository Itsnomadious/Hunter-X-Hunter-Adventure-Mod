package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;

/**
 * Client-side record of the open Laplace Devil domains (fed by PacketLaplaceFx), keyed by the user's entity id.
 * The rules, for the local player: if they were inside the dome ("affected") the real user and the Devil are hidden and the double is
 * shown; if they were not, the real user and the Devil are shown and the double is hidden. The user themself keeps seeing everything of
 * their own, plus the double. A double or Devil nobody has told us about yet stays hidden until the packet arrives.
 */
public final class LaplaceFx {
    private LaplaceFx() {}

    private record Rec(int doubleId, int devilId, boolean affected) {}

    private static final Map<Integer, Rec> RECS = new HashMap<>();

    public static void set(int owner, int doubleId, int devilId, boolean active, boolean affected) {
        if (active) RECS.put(owner, new Rec(doubleId, devilId, affected));
        else RECS.remove(owner);
    }

    public static boolean isEmpty() {
        return RECS.isEmpty();
    }

    /** The real user's body must not be drawn for the local player. */
    public static boolean hideReal(int entityId) {
        Rec r = RECS.get(entityId);
        return r != null && r.affected();
    }

    public static boolean hideDevil(int entityId) {
        for (Rec r : RECS.values()) if (r.devilId() == entityId) return r.affected();
        return true;
    }

    public static boolean showDouble(int entityId) {
        Minecraft mc = Minecraft.getInstance();
        for (Map.Entry<Integer, Rec> e : RECS.entrySet()) {
            if (e.getValue().doubleId() != entityId) continue;
            return e.getValue().affected() || (mc.player != null && mc.player.getId() == e.getKey());
        }
        return false;
    }

    /** Real users hidden from the local player (their sprint particles must not give them away). */
    public static Iterable<Integer> hiddenUsers() {
        java.util.List<Integer> out = new java.util.ArrayList<>();
        for (Map.Entry<Integer, Rec> e : RECS.entrySet()) if (e.getValue().affected()) out.add(e.getKey());
        return out;
    }

    public static void clear() {
        RECS.clear();
    }
}
