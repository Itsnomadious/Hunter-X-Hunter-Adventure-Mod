package net.hxhadventure.addon.client;

/**
 * The Dowsing Chain as a small rope simulation (no Minecraft imports, so it can be tested on its own).
 *
 * The cast has three phases (ticks, measured from the start of the cast):
 *  1. SWING   (0 .. swing)            Nen steers the chain through its left-to-right arc. The links are pulled toward that arc
 *                                     by a spring, so they still lag, sag and whip instead of sitting rigid on it.
 *  2. CURL    (swing .. swing+HOLD)   Steering is let go. Momentum throws the tip past the arc and a curling force winds the
 *                                     chain into a coil, while gravity and the heavy ball drag it down.
 *  3. RETRACT (swing+HOLD .. end)     The chain is reeled into the hand from the tip, quicker and quicker. The slack bunches up
 *                                     and swings as it is hauled in.
 *
 * Everything runs in world space with verlet integration at a fixed sub-step, so it looks the same at any frame rate.
 * Node 0 is pinned to the hand; the last active node carries the steel ball and is much heavier than the links.
 */
public final class ChainRope {
    // ---- timeline, shared with the caster's arm (ChainFx forwards to these) ----
    public static final int RETRACT_TICKS = 8;
    /** Ticks after the swing during which the chain is left at full length before it is reeled in (none: it comes back the moment the cone ends). */
    public static final double HOLD = 0.0;
    public static final double HALF_ARC = Math.toRadians(70);
    /** The final 30% of the chain swings 50% further than the damage cone (visual only). */
    public static final double TIP_START = 0.7, TIP_EXTRA = 0.5;
    /** How many ticks the hand is ahead of the ball: the chain trails a little behind the hand (small, so the hand keeps pace with the chain). */
    public static final double LEAD = 0.9;

    /** Angle (rad, from the cast direction, negative = left, positive = right) of the part of the chain at u (0 = hand, 1 = ball). */
    public static double angle(double age, double swing, double u) {
        double t = age + LEAD * (1.0 - u);                             // the ball is behind the hand
        double x = clamp01(t / swing);
        double ease = 0.5 - 0.5 * Math.cos(Math.PI * x);              // starts and ends gently, whips through the middle
        double wide = 1.0 + TIP_EXTRA * smooth(clamp01((u - TIP_START) / (1.0 - TIP_START)));   // the last part of the chain swings wider than the cone
        double ang = (-HALF_ARC + 2 * HALF_ARC * ease) * wide;
        // no follow-through: the chain never goes past the end of the cone it hits in
        double r = clamp01((age - swing - HOLD) / (RETRACT_TICKS - HOLD));
        ang -= HALF_ARC * 0.7 * (r * r * (3 - 2 * r));                // the hand draws back as it reels the chain in
        return ang;
    }

    /** Fraction of its full length the chain has out: it unfurls quickly, holds while it curls, then is hauled in faster and faster. */
    public static double length(double age, double swing) {
        if (age <= swing) {
            double x = Math.min(1.0, 0.15 + age / 2.5);
            return 1 - (1 - x) * (1 - x);
        }
        double r = clamp01((age - swing - HOLD) / (RETRACT_TICKS - HOLD));
        return 1 - Math.pow(r, 1.25);
    }

    /**
     * A path the chain is led along instead of the Dowsing Chain's arc (used by the Holy Chain). The rope still runs the same
     * simulation (gravity, drag, the heavy tip, rope constraints, the lagging guide spring); only what it is steered toward differs.
     * Everything is in world space and may change from frame to frame (the arms move).
     */
    public interface Path {
        /** How much chain is paid out, blocks (the tip sits this far along the path). */
        double reel(double age);

        /** Steering strength: 1 = the Dowsing Chain's firm swing, 0 = let go and hang. */
        double guide(double age);

        /** Extra spring on the chain at s blocks along it, on top of guide() (a part that must hug something, like the wrapped arm). */
        double grip(double age, double s);

        /** Where the chain is steered to, s blocks along it (clamped to the end of the path by the caller). */
        void point(double age, double s, double[] out);
    }

    // ---- simulation ----
    private static final double DT = 0.25;               // ticks per sub-step
    private static final double DEFAULT_SEG = 0.25;      // rest length of a segment, blocks (the Dowsing Chain)
    private static final int MAX_NODES = 64;
    private static final int ITER = 30;
    private static final double GRAVITY = 0.05;          // blocks / tick^2
    private static final double AIR_LINK = 0.90;         // velocity kept per tick
    private static final double AIR_BALL = 0.965;
    private static final double BALL_INV_MASS = 0.22;    // links are 1.0: the ball is about 4.5 times as heavy
    private static final double GUIDE_K_XZ = 1.0, GUIDE_K_Y = 0.45, GUIDE_DAMP = 1.5;
    private static final double CURL_ANGLE = 0.20;       // radians each link turns from the one before it at the tip of a full curl (about 0.55 block radius)

    private final int nodeCap;
    private final double range;
    /** Rest length of one segment, blocks. */
    private final double segLen;
    /** The first block of chain out of the hand is rigid: it is locked to the hand's direction and never lags or sags (stiffLen blocks, as nodes). */
    private final int stiffNodes;
    /** Non-null while the chain is led along a path instead of the Dowsing Chain's swinging arc (see {@link Path}). */
    private Path path;
    private final double[] x, y, z, ox, oy, oz;
    private int active = 1;
    private double simAge = 0;
    private boolean started = false;
    private double rx, ry, rz;                            // root (hand) at simAge
    private double[] lastFwd;                             // cast direction at the last call

    /** The Dowsing Chain: quarter-block segments, the first block rigid. */
    public ChainRope(double range) {
        this(range, DEFAULT_SEG, 1.0);
    }

    /**
     * Same physics with a different link grouping: segLen is the rest length of one simulated segment and stiffLen how many blocks
     * out of the hand are held rigid (0 = none). The Holy Chain on yourself is short, so it simulates finer segments.
     */
    public ChainRope(double range, double segLen, double stiffLen) {
        this.range = range;
        this.segLen = segLen;
        this.stiffNodes = (int) Math.round(stiffLen / segLen);
        this.nodeCap = (int) Math.min(MAX_NODES, Math.ceil(range / segLen) + 2);
        x = new double[nodeCap]; y = new double[nodeCap]; z = new double[nodeCap];
        ox = new double[nodeCap]; oy = new double[nodeCap]; oz = new double[nodeCap];
    }

    public int count() { return active; }
    public double x(int i) { return x[i]; }
    public double y(int i) { return y[i]; }
    public double z(int i) { return z[i]; }

    /**
     * Advance the simulation to the given age. (hx,hy,hz) is where the hand is right now, fwd is the unit cast direction (it can point up or down) and side the unit vector the swing sweeps toward
     * (perpendicular to fwd; negate it to swing from the other side).
     * The hand is treated as moving in a straight line from where it was at the last call.
     */
    public void advance(double age, double hx, double hy, double hz, double[] fwd, double[] side, double swing) {
        path = null;
        if (!started) {
            started = true;
            rx = hx; ry = hy; rz = hz;
            x[0] = ox[0] = hx; y[0] = oy[0] = hy; z[0] = oz[0] = hz;
            simAge = 0;
        }
        turn(fwd);
        int steps = (int) Math.floor((age - simAge) / DT + 1e-9);
        if (steps <= 0) return;
        if (steps > 160) { simAge = age - 160 * DT; steps = 160; }
        double fx0 = rx, fy0 = ry, fz0 = rz;
        for (int s = 1; s <= steps; s++) {
            double f = s / (double) steps;
            double cx = fx0 + (hx - fx0) * f, cy = fy0 + (hy - fy0) * f, cz = fz0 + (hz - fz0) * f;
            simAge += DT;
            step(simAge, cx, cy, cz, fwd, side, swing);
        }
        rx = hx; ry = hy; rz = hz;
    }

    /**
     * Advance the simulation to the given age with the chain led along a path (hand = where the chain leaves, the pinned end).
     * The caster turning does not rotate the chain here: the path itself is rebuilt from the current pose every frame.
     */
    public void advance(double age, double hx, double hy, double hz, Path path) {
        this.path = path;
        lastFwd = null;
        if (!started) {
            started = true;
            rx = hx; ry = hy; rz = hz;
            x[0] = ox[0] = hx; y[0] = oy[0] = hy; z[0] = oz[0] = hz;
            simAge = 0;
        }
        int steps = (int) Math.floor((age - simAge) / DT + 1e-9);
        if (steps <= 0) return;
        if (steps > 160) { simAge = age - 160 * DT; steps = 160; }
        double fx0 = rx, fy0 = ry, fz0 = rz;
        for (int s = 1; s <= steps; s++) {
            double f = s / (double) steps;
            double cx = fx0 + (hx - fx0) * f, cy = fy0 + (hy - fy0) * f, cz = fz0 + (hz - fz0) * f;
            simAge += DT;
            step(simAge, cx, cy, cz, null, null, 0.0);
        }
        rx = hx; ry = hy; rz = hz;
    }

    /** Longest reel this rope can pay out, blocks. */
    public double maxReel() { return (nodeCap - 2) * segLen; }

    private static final double FRICTION = 0.6;
    private static final double[] VX = new double[MAX_NODES], VY = new double[MAX_NODES], VZ = new double[MAX_NODES];
    /**
     * When the caster turns, the whole chain turns with them as one piece (about the hand), instead of being left behind
     * in the world and snapping back: the swing stays coherent and only its own physics (lag, weight, whip) shows.
     */
    private void turn(double[] f) {
        double[] a = lastFwd;
        lastFwd = new double[] {f[0], f[1], f[2]};
        if (a == null) return;
        double kx = a[1] * f[2] - a[2] * f[1], ky = a[2] * f[0] - a[0] * f[2], kz = a[0] * f[1] - a[1] * f[0];
        double sn = Math.sqrt(kx * kx + ky * ky + kz * kz);
        if (sn < 1e-9) return;
        double cs = a[0] * f[0] + a[1] * f[1] + a[2] * f[2];
        kx /= sn; ky /= sn; kz /= sn;
        for (int i = 1; i < active; i++) {
            rot(x, y, z, i, kx, ky, kz, sn, cs);
            rot(ox, oy, oz, i, kx, ky, kz, sn, cs);
        }
    }

    private void rot(double[] px, double[] py, double[] pz, int i, double kx, double ky, double kz, double sn, double cs) {
        double vx = px[i] - rx, vy = py[i] - ry, vz = pz[i] - rz;
        double d = kx * vx + ky * vy + kz * vz;
        double cx = ky * vz - kz * vy, cy = kz * vx - kx * vz, cz = kx * vy - ky * vx;
        px[i] = rx + vx * cs + cx * sn + kx * d * (1 - cs);
        py[i] = ry + vy * cs + cy * sn + ky * d * (1 - cs);
        pz[i] = rz + vz * cs + cz * sn + kz * d * (1 - cs);
    }

    private static final double[] TX = new double[MAX_NODES], TY = new double[MAX_NODES], TZ = new double[MAX_NODES];
    private static final double[] PT = new double[3];

    private void step(double age, double hx, double hy, double hz, double[] fwd, double[] side, double swing) {
        double reel = path != null ? Math.min(path.reel(age), maxReel()) : range * length(age, swing);
        int want = (int) Math.max(1, Math.min(nodeCap, Math.ceil(reel / segLen) + 1));
        double lastSeg = reel - (want - 2) * segLen;                   // the partly paid-out last segment
        if (want == 1) lastSeg = 0;

        // the arc Nen steers the chain along: link by link, each turned to the angle that part of the chain has right now
        double curl = path != null ? 0.0 : smooth(clamp01((age - swing) / 1.5)) * (1.0 - 0.5 * smooth(clamp01((age - swing - HOLD) / (RETRACT_TICKS - HOLD))));
        // steering is firm through the swing, loosens while it curls (so the weight shows), and is let go as it is reeled in
        double guide;
        if (path != null) {
            guide = path.guide(age);
        } else {
            guide = age <= swing ? 1.0 : 0.55 * (1.0 - 0.55 * smooth(clamp01((age - swing) / 2.0)));
            guide *= 1.0 - smooth(clamp01((age - swing - HOLD) / 2.0));
        }
        double bendCum = 0;
        double gx = hx, gy = hy, gz = hz;
        double reelSafe = Math.max(reel, segLen);
        if (path != null) {
            // led along the path: node i is steered to the point s = i * segLen blocks along it (the tip to the end of the paid-out chain)
            for (int i = 1; i < nodeCap; i++) {
                double s = i < want ? Math.min(i * segLen, reel) : i * segLen;
                path.point(age, s, PT);
                TX[i] = PT[0]; TY[i] = PT[1]; TZ[i] = PT[2];
            }
        } else {
            for (int i = 1; i < nodeCap; i++) {
                double seg = i < want - 1 ? segLen : Math.max(0.0, lastSeg);
                if (i >= want) seg = segLen;
                double u = clamp01(((i - 0.5) * segLen) / reelSafe);
                bendCum -= CURL_ANGLE * curl * (0.2 + 0.8 * u);   // each link turns a bit further than the one before: a spiral
                double a = angle(age, swing, u) + bendCum;
                double c = Math.cos(a), sn = Math.sin(a);
                gx += (fwd[0] * c + side[0] * sn) * seg;
                gy += (fwd[1] * c + side[1] * sn) * seg;
                gz += (fwd[2] * c + side[2] * sn) * seg;
                TX[i] = gx; TY[i] = gy; TZ[i] = gz;
            }
        }

        // new links come out of the hand already on the arc
        while (active < want) {
            int i = active++;
            double px = i == 1 ? hx : TX[i - 1], py = i == 1 ? hy : TY[i - 1], pz = i == 1 ? hz : TZ[i - 1];   // continue on from the link before it, on the arc's heading
            x[i] = ox[i] = x[i - 1] + (TX[i] - px);
            y[i] = oy[i] = y[i - 1] + (TY[i] - py);
            z[i] = oz[i] = z[i - 1] + (TZ[i] - pz);
        }
        // links that were reeled in are gone: fold them back into the hand
        if (active > want) active = want;

        // curl strength: builds through the end of the swing, stays while it is held, fades as the chain is hauled in
        double ballInv = BALL_INV_MASS;
        double dt2 = DT * DT;
        double airLink = Math.pow(AIR_LINK, DT), airBall = Math.pow(AIR_BALL, DT);

        x[0] = hx; y[0] = hy; z[0] = hz;
        // internal friction: each link's velocity is pulled toward its neighbours', so ripples die out and the chain moves as one rope
        for (int i = 1; i + 1 < active; i++) {
            double ax = (x[i - 1] - ox[i - 1] + x[i + 1] - ox[i + 1]) * 0.5, ay = (y[i - 1] - oy[i - 1] + y[i + 1] - oy[i + 1]) * 0.5, az = (z[i - 1] - oz[i - 1] + z[i + 1] - oz[i + 1]) * 0.5;
            VX[i] = ax - (x[i] - ox[i]); VY[i] = ay - (y[i] - oy[i]); VZ[i] = az - (z[i] - oz[i]);
        }
        for (int i = 1; i + 1 < active; i++) { ox[i] -= VX[i] * FRICTION; oy[i] -= VY[i] * FRICTION; oz[i] -= VZ[i] * FRICTION; }
        for (int i = stiffNodes + 1; i < active; i++) {
            boolean tip = i == active - 1;
            double vx = x[i] - ox[i], vy = y[i] - oy[i], vz = z[i] - oz[i];
            double air = tip ? airBall : airLink;
            vx *= air; vy *= air; vz *= air;

            double ax = 0, ay = -GRAVITY, az = 0;
            double u = clamp01(i * segLen / Math.max(reel, segLen));

            if (guide > 0) {
                double k = guide * (1.0 + 2.0 * Math.max(0.0, 1.0 - (i - stiffNodes) / 6.0));   // eases from the rigid block into the loose chain
                double ty, kyy = GUIDE_K_Y;
                if (path != null) {
                    k += path.grip(age, Math.min(i * segLen, reel));   // the part wrapped round the arm is held tight
                    ty = TY[i];                                         // the path already says where the chain hangs, so no extra sag
                    kyy = GUIDE_K_XZ;                                   // and up/down is held as firmly as sideways, so a wrap does not sink into the arm
                } else {
                    if (age <= swing + 0.5) k *= 1.0 + 3.0 * smooth(clamp01((u - 0.5) / 0.5));   // the heavy tip is driven hard so it reaches the end of the arc on time
                    // sag the target a little, as a hanging chain would
                    ty = TY[i] - 0.03 * reel * Math.sin(Math.PI * u) + curl * 0.35 * u * (0.5 + 0.5 * Math.sin(i * 0.45));
                }
                ax += GUIDE_K_XZ * k * (TX[i] - x[i]) - GUIDE_DAMP * k * vx / DT;
                az += GUIDE_K_XZ * k * (TZ[i] - z[i]) - GUIDE_DAMP * k * vz / DT;
                ay += kyy * k * (ty - y[i]) - GUIDE_DAMP * 0.5 * k * vy / DT;
            }

            double nx = x[i] + vx + ax * dt2, ny = y[i] + vy + ay * dt2, nz = z[i] + vz + az * dt2;
            ox[i] = x[i]; oy[i] = y[i]; oz[i] = z[i];
            x[i] = nx; y[i] = ny; z[i] = nz;
        }

        // the first block is held exactly on the hand's heading
        for (int i = 1; i <= stiffNodes && i < active; i++) {
            x[i] = ox[i] = TX[i]; y[i] = oy[i] = TY[i]; z[i] = oz[i] = TZ[i];
        }

        // keep the links the right distance apart
        for (int it = 0; it < ITER; it++) {
            x[0] = hx; y[0] = hy; z[0] = hz;
            for (int i = 0; i + 1 < active; i++) {
                int j = i + 1;
                double rest = j == active - 1 && want > 1 ? Math.max(0.02, lastSeg) : segLen;
                double ex = x[j] - x[i], ey = y[j] - y[i], ez = z[j] - z[i];
                double d = Math.sqrt(ex * ex + ey * ey + ez * ez);
                if (d < 1e-9) { ex = 0; ey = -1; ez = 0; d = 1; }
                double wi = i <= stiffNodes ? 0.0 : 1.0;
                double wj = j <= stiffNodes ? 0.0 : j == active - 1 ? ballInv : 1.0;
                double ws = wi + wj;
                if (ws == 0) continue;
                double diff = (d - rest) / (d * ws);
                x[i] += ex * diff * wi; y[i] += ey * diff * wi; z[i] += ez * diff * wi;
                x[j] -= ex * diff * wj; y[j] -= ey * diff * wj; z[j] -= ez * diff * wj;
            }
        }
    }


    private static double clamp01(double v) { return v < 0 ? 0 : Math.min(v, 1); }
    private static double smooth(double r) { return r * r * (3 - 2 * r); }
}
