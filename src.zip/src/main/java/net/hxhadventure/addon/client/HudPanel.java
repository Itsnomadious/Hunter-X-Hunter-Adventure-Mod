package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.ClientAddonState;
import net.hxhadventure.addon.SkillHunter;

/** The movable box for irregular states: Emperor Time, aura form, Zetsu / En and the Skill Hunter book. */
public final class HudPanel {
    private HudPanel() {}

    /** One row: a white label, a coloured value, and optionally a bar (0-1) underneath. */
    public record Line(String label, String value, int colour, float bar, String widest) {
        public Line(String label, String value, int colour, float bar) { this(label, value, colour, bar, value); }
    }

    private static final int PAD = 6;
    private static final int LINE_H = 11;
    private static final int BAR_H = 5;
    private static final int MIN_W = 124;
    private static final int BG_RGB = 0x000000;
    private static final int BORDER_OUTER_RGB = 0xD8D8D8;
    private static final int BORDER_INNER_RGB = 0x909090;

    /** Alpha-prefixed colour; borders fade with the background but never vanish completely. */
    private static int argb(int alpha, int rgb) { return (Math.max(0, Math.min(255, alpha)) << 24) | rgb; }

    /**
     * Only the irregular states live in this box now (the Nen bar, selected ability and cooldowns are drawn by AddonHud).
     * Returns an empty list when nothing is active, in which case no box is drawn.
     */
    public static List<Line> lines(Minecraft mc, Combat c) {
        List<Line> out = new ArrayList<>();
        if (!c.hasNenUnlocked()) return out;

        if (ClientAddonState.emperor) {
            out.add(new Line("Emperor Time: ", "Active", 0xFF5555, -1f));
            out.add(new Line("Lifespan: ", Math.round(ClientAddonState.lifespan) + " yrs", 0xFF5555, -1f));
        }
        if (ClientAddonState.ken || ClientAddonState.ko) {
            out.add(new Line("Aura: ", ClientAddonState.formLabel(), 0x55FFFF, -1f, "Ken"));
        }
        if (ClientAddonState.zetsu) out.add(new Line("Zetsu: ", "On", 0xAAAAAA, -1f));
        if (ClientAddonState.in) out.add(new Line("In: ", ClientAddonState.inVisible && net.hxhadventure.addon.Vows.effLevel(net.minecraft.client.Minecraft.getInstance().player, net.hxhadventure.addon.NenSkill.IN, ClientAddonState.level[net.hxhadventure.addon.NenSkill.IN.ordinal()]) >= net.hxhadventure.addon.Tuning.IN_VISIBILITY_LEVEL ? "On (Nen shown)" : "On", 0xAA55FF, -1f));
        if (ClientAddonState.gyo) out.add(new Line("Gyo: ", "On", 0xFFFF55, -1f));
        if (ClientAddonState.shu) out.add(new Line("Shu: ", "On", 0xFFAA00, -1f));
        if (ClientAddonState.en) out.add(new Line("En: ", String.valueOf(Math.round(ClientAddonState.enRadius)), 0xFF55FF, -1f));
        if (ClientAddonState.bookState != 0) {
            String page = ClientAddonState.activePage >= 0 ? SkillHunter.Page.values()[ClientAddonState.activePage].label : "-";
            String mark = ClientAddonState.bookmark >= 0 ? SkillHunter.Page.values()[ClientAddonState.bookmark].label : "-";
            out.add(new Line("Bandit's Secret: ", ClientAddonState.bookState == 2 ? "Open" : "Closed", 0xAA55FF, -1f));
            out.add(new Line("Page: ", page, 0xAA55FF, -1f));
            out.add(new Line("Mark: ", mark, 0xAA55FF, -1f));
        }
        return out;
    }

    /** What the move-HUD screen shows when nothing irregular is active, so there is still a box to drag. */
    public static List<Line> sample() {
        List<Line> out = new ArrayList<>();
        out.add(new Line("Aura: ", "Ken", 0x55FFFF, -1f));
        out.add(new Line("En: ", "50", 0xFF55FF, -1f));
        return out;
    }

    /** On-screen size (includes the user's HUD scale). */
    public static int width(Font font, List<Line> lines) {
        return Math.round(rawWidth(font, lines) * HudLayout.scale());
    }

    public static int height(List<Line> lines) {
        return Math.round(rawHeight(lines) * HudLayout.scale());
    }

    private static int rawWidth(Font font, List<Line> lines) {
        int w = MIN_W;
        for (Line l : lines) w = Math.max(w, font.width(l.label) + Math.max(font.width(l.value), font.width(l.widest)) + PAD * 2 + 2);
        return w;
    }

    private static int rawHeight(List<Line> lines) {
        int h = PAD * 2 - 2;
        for (Line l : lines) h += LINE_H + (l.bar >= 0 ? BAR_H + 1 : 0);
        return h;
    }

    public static void draw(GuiGraphics g, Font font, int x, int y, List<Line> lines, boolean highlight) {
        float op = HudLayout.opacity();
        float sc = HudLayout.scale();
        int w = rawWidth(font, lines);
        int h = rawHeight(lines);
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(sc, sc, 1f);
        x = 0;
        y = 0;
        if (op <= 0.003f) { g.pose().popPose(); return; }
        int bgA = Math.round(0x1A * op);
        int outerA = Math.round(0x66 * op);
        int innerA = Math.round(0x44 * op);
        int textA = Math.round(255 * op);
        g.fill(x, y, x + w, y + h, argb(outerA, BORDER_OUTER_RGB));
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, argb(innerA, BORDER_INNER_RGB));
        g.fill(x + 2, y + 2, x + w - 2, y + h - 2, argb(bgA, BG_RGB));
        if (highlight) {
            g.fill(x - 1, y - 1, x + w + 1, y, 0xFFFFFFFF);
            g.fill(x - 1, y + h, x + w + 1, y + h + 1, 0xFFFFFFFF);
            g.fill(x - 1, y, x, y + h, 0xFFFFFFFF);
            g.fill(x + w, y, x + w + 1, y + h, 0xFFFFFFFF);
        }
        int ty = y + PAD - 1;
        for (Line l : lines) {
            g.drawString(font, l.label, x + PAD, ty, argb(Math.max(4, textA), 0xFFFFFF));
            g.drawString(font, l.value, x + PAD + font.width(l.label), ty, argb(Math.max(4, textA), l.colour & 0xFFFFFF));
            ty += LINE_H;
            if (l.bar >= 0) {
                int bx0 = x + PAD, bx1 = x + w - PAD;
                g.fill(bx0, ty, bx1, ty + BAR_H, argb(Math.round(0x40 * op), 0x000000));
                g.fill(bx0, ty, bx0 + Math.round((bx1 - bx0) * l.bar), ty + BAR_H, argb(textA, l.colour & 0xFFFFFF));
                ty += BAR_H + 1;
            }
        }
        g.pose().popPose();
    }
}
