package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * Draws Rising Sun: no model or texture, just layered translucent geometry.
 * <ul>
 *   <li>the star itself: a white-yellow core, a mottled red / orange / yellow body whose patches boil, a corona and a wide halo,
 *       with yellow-white lightning crawling over its surface and prominences (arches of flame) rising off it and falling back;</li>
 *   <li>around it: three tilted rings of plasma spinning with a bright head and a fading tail, long shafts of light, and pulses of
 *       corona that swell outwards and fade;</li>
 *   <li>when it finishes swelling: a shockwave (a flat ring and a sphere racing outwards);</li>
 *   <li>beneath it: a pool of molten light on the ground with glowing cracks spreading out across it, embers and smoke rising,
 *       and bolts of lightning that now and then leap from the sun down to the ground.</li>
 * </ul>
 * The ball of aura rises from the user's hands over the first part of the deployment and swells into the sun over the rest; at the end
 * it shrinks and fades.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class SunRenderer {
    private SunRenderer() {}

    private static final int LAT = 16, LON = 28;
    private static final double FADE_TICKS = 20;
    private static final double SHOCK_TICKS = 30;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || !PainFx.hasSuns()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        double time = level.getGameTime() + pt;
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        Matrix4f m = ps.last().pose();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.lightning();
        VertexConsumer vc = buf.getBuffer(type);

        Iterator<Map.Entry<Integer, PainFx.Sun>> it = PainFx.SUNS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, PainFx.Sun> en = it.next();
            PainFx.Sun s = en.getValue();
            int seed = en.getKey();
            double age = time - s.t0;
            if (age > s.life + 10) {
                it.remove();
                continue;
            }
            // where it is: leaves the hands, rises over the first 45% of the deployment, then hangs in the air
            double rise = ease(Math.min(1.0, age / (s.deploy * 0.45)));
            Vec3 world = new Vec3(Mth.lerp(rise, s.fromX, s.toX), Mth.lerp(rise, s.fromY, s.toY), Mth.lerp(rise, s.fromZ, s.toZ));
            Vec3 c = world.subtract(cam);
            // how big: a small ball of aura first, then the whole deployment swells it to its full size
            double full = s.diameter * 0.5;
            double grow = ease(Math.min(1.0, age / s.deploy));
            double r = Mth.lerp(grow, Math.min(0.25, full), full);
            // the last moments: it shrinks and fades
            double left = s.life - age;
            double fade = left < FADE_TICKS ? Math.max(0, left / FADE_TICKS) : 1.0;
            r *= 0.7 + 0.3 * fade;
            // a slow heartbeat
            r *= 1 + 0.025 * Math.sin(time * 0.5 + seed) + 0.015 * Math.sin(time * 1.3 + seed * 2);
            if (r < 0.02 || fade <= 0) continue;

            sun(m, vc, c, r, time, seed, fade, grow);

            if (age >= s.deploy * 0.6) {
                veins(m, vc, c, r, time, seed, fade);
                arches(m, vc, c, r, time, seed, fade);
            }
            if (age >= s.deploy * 0.8) {
                double reveal = Mth.clamp((age - s.deploy * 0.8) / (s.deploy * 0.4), 0, 1);
                rings(m, vc, c, r, time, seed, fade * reveal);
                rays(m, vc, c, r, time, seed, fade * reveal);
                pulses(m, vc, c, r, time, seed, fade * reveal);
            }
            double since = age - s.deploy;
            double gy = Double.NaN, emberR = 0;
            if (since >= 0) {
                double groundR = groundRadius(s);
                if (since < SHOCK_TICKS) shockwave(m, vc, c, r, groundR, since / SHOCK_TICKS, seed);
                gy = groundY(level, s, r);
                if (!Double.isNaN(gy)) {
                    Vec3 gc = new Vec3(s.toX - cam.x, gy + 0.06 - cam.y, s.toZ - cam.z);
                    double spread = ease(Math.min(1.0, since / 50.0));
                    emberR = groundR * spread;
                    ground(m, vc, gc, emberR, time, seed, fade);
                    bolts(m, vc, c, gc, r, emberR, time, seed, fade);
                }
            }
            // particles once per tick, not once per frame
            long tick = level.getGameTime();
            if (tick != s.lastTick) {
                s.lastTick = tick;
                if (!Double.isNaN(gy)) embers(level, s, gy, emberR);
                else sparks(level, s, r, rise);
            }
        }
        buf.endBatch(type);
    }

    private static double ease(double t) {
        return t * t * (3 - 2 * t);
    }

    private static Vec3 randUnit(Random rnd) {
        Vec3 d;
        do {
            d = new Vec3(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian());
        } while (d.lengthSqr() < 1e-6);
        return d.normalize();
    }

    /** How far the scorched ground reaches: grows with the sun, capped well inside the heat's range. */
    private static double groundRadius(PainFx.Sun s) {
        double base = 8 + s.diameter * 3.0;
        return s.range > 0 ? Math.min(s.range, base) : base;
    }

    /** The surface under the sun, or NaN when there is none worth drawing (a roof right above, unloaded chunk). */
    private static double groundY(ClientLevel level, PainFx.Sun s, double r) {
        int gx = Mth.floor(s.toX), gz = Mth.floor(s.toZ);
        if (!level.hasChunkAt(new net.minecraft.core.BlockPos(gx, 64, gz))) return Double.NaN;
        double gy = level.getHeight(Heightmap.Types.MOTION_BLOCKING, gx, gz);
        if (gy <= level.getMinBuildHeight() + 1) return Double.NaN;
        if (gy > s.toY - Math.max(1.0, r * 0.5)) return Double.NaN;
        return gy;
    }

    /** A few embers thrown off by the sun while it swells (afterwards the ground embers take over). */
    private static void sparks(ClientLevel level, PainFx.Sun s, double r, double rise) {
        Random rnd = new Random();
        double cx = Mth.lerp(rise, s.fromX, s.toX), cy = Mth.lerp(rise, s.fromY, s.toY), cz = Mth.lerp(rise, s.fromZ, s.toZ);
        int n = 1 + (int) Math.min(6, r);
        for (int i = 0; i < n; i++) {
            Vec3 d = randUnit(rnd);
            Vec3 p = new Vec3(cx, cy, cz).add(d.scale(r * 1.05));
            level.addParticle(ParticleTypes.FLAME, p.x, p.y, p.z, d.x * 0.05, d.y * 0.05 - 0.01, d.z * 0.05);
        }
    }

    /** Flames, lava pops and smoke rising off the scorched ground, and embers falling from the sun. */
    private static void embers(ClientLevel level, PainFx.Sun s, double gy, double groundR) {
        Random rnd = new Random();
        int n = 3 + (int) Math.min(8, groundR * 0.15);
        for (int i = 0; i < n; i++) {
            double ang = rnd.nextDouble() * Math.PI * 2;
            double d = Math.sqrt(rnd.nextDouble()) * groundR;
            double x = s.toX + Math.cos(ang) * d, z = s.toZ + Math.sin(ang) * d;
            level.addParticle(ParticleTypes.FLAME, x, gy + 0.1, z, (rnd.nextDouble() - 0.5) * 0.02, 0.04 + rnd.nextDouble() * 0.1, (rnd.nextDouble() - 0.5) * 0.02);
            if (rnd.nextInt(4) == 0) level.addParticle(ParticleTypes.LAVA, x, gy + 0.2, z, 0, 0, 0);
            if (rnd.nextInt(3) == 0) level.addParticle(ParticleTypes.SMOKE, x, gy + 0.3, z, 0, 0.07, 0);
        }
        // glowing flecks drifting down from the sun itself
        for (int i = 0; i < 2; i++) {
            Vec3 dir = randUnit(rnd);
            double rad = s.diameter * 0.5 * 1.1;
            level.addParticle(ParticleTypes.SMALL_FLAME, s.toX + dir.x * rad, s.toY + dir.y * rad, s.toZ + dir.z * rad, dir.x * 0.03, -0.04 - rnd.nextDouble() * 0.04, dir.z * 0.03);
        }
    }

    // ------------------------------------------------------------------ the star

    /** The whole sun, drawn inside-out so the translucent layers show through each other. */
    private static void sun(Matrix4f m, VertexConsumer vc, Vec3 c, double r, double time, int seed, double fade, double grow) {
        int a = (int) (255 * fade);
        // the faint halo (only the swollen sun has one worth the name)
        double halo = 0.35 + 0.65 * grow;
        sphere(m, vc, c, r * 2.6, 255, 60, 10, (int) (8 * fade * halo), time, seed, false);
        sphere(m, vc, c, r * 2.1, 255, 80, 10, (int) (14 * fade * halo), time, seed, false);
        sphere(m, vc, c, r * 1.6, 255, 110, 15, (int) (26 * fade * halo), time, seed, false);
        sphere(m, vc, c, r * 1.3, 255, 150, 25, (int) (50 * fade), time, seed, false);
        // the mottled body: red, orange and yellow patches that boil slowly
        sphere(m, vc, c, r, 255, 120, 20, (int) (215 * fade), time, seed, true);
        sphere(m, vc, c, r * 0.8, 255, 210, 90, (int) (a * 0.55), time, seed, false);
        // the white-yellow core
        sphere(m, vc, c, r * 0.5, 255, 245, 190, (int) (a * 0.7), time, seed, false);

        // solar flares leaping off the surface
        Random rnd = new Random((long) Math.floor(time * 0.4) * 7919L + seed * 104729L);
        int flares = 6 + (int) Math.min(10, r * 2);
        for (int k = 0; k < flares; k++) {
            Vec3 dir = randUnit(rnd);
            Vec3 p = c.add(dir.scale(r * 0.98));
            int segs = 4;
            for (int s = 0; s < segs; s++) {
                Vec3 jitter = new Vec3(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian()).scale(r * 0.07);
                Vec3 q = p.add(dir.scale(r * 0.14)).add(jitter);
                strip(m, vc, p, q, 0.02 + 0.03 * r * (1 - s / (double) segs), 255, 170 + 20 * s, 40, (int) (200 * fade));
                p = q;
            }
        }
    }

    /** Yellow-white lightning crawling over the surface; a new set of jagged paths every three ticks, so it flickers. */
    private static void veins(Matrix4f m, VertexConsumer vc, Vec3 c, double r, double time, int seed, double fade) {
        long bucket = (long) Math.floor(time / 3.0);
        Random rnd = new Random(bucket * 31L + seed * 7919L);
        int bolts = 5 + (int) Math.min(9, r * 1.5);
        double w = 0.010 + 0.009 * r;
        for (int k = 0; k < bolts; k++) {
            Vec3 p = randUnit(rnd);
            Vec3 prev = c.add(p.scale(r * 1.012));
            int segs = 6 + rnd.nextInt(5);
            for (int i = 0; i < segs; i++) {
                Vec3 t = randUnit(rnd);
                t = t.subtract(p.scale(t.dot(p)));
                if (t.lengthSqr() < 1e-6) continue;
                t = t.normalize();
                p = p.add(t.scale(0.20 + rnd.nextDouble() * 0.16)).normalize();
                Vec3 q = c.add(p.scale(r * 1.012));
                strip(m, vc, prev, q, w * 3.4, 255, 150, 20, (int) (90 * fade));
                strip(m, vc, prev, q, w, 255, 245, 170, (int) (235 * fade));
                prev = q;
            }
        }
    }

    /** Prominences: arches of flame that rise off the surface, hang, and sink back, each on its own rhythm. */
    private static void arches(Matrix4f m, VertexConsumer vc, Vec3 c, double r, double time, int seed, double fade) {
        int n = 5;
        for (int i = 0; i < n; i++) {
            double period = 90 + i * 17;
            double shifted = time + i * 29 + seed * 13;
            double ph = (shifted % period) / period;
            double env = Math.sin(Math.PI * ph);
            env *= env;
            if (env < 0.04) continue;
            Random ra = new Random(seed * 131L + i * 977L + (long) Math.floor(shifted / period) * 65537L);
            Vec3 a = randUnit(ra);
            Vec3 axis = randUnit(ra);
            axis = axis.subtract(a.scale(axis.dot(a)));
            if (axis.lengthSqr() < 1e-6) continue;
            axis = axis.normalize();
            double span = 0.5 + ra.nextDouble() * 0.5;
            double h = (0.3 + ra.nextDouble() * 0.5) * env;
            double w = r * 0.035 * (0.5 + env * 0.5);
            int segs = 12;
            Vec3 prev = null;
            for (int k = 0; k <= segs; k++) {
                double u = k / (double) segs;
                double ang = span * u;
                Vec3 d = a.scale(Math.cos(ang)).add(axis.scale(Math.sin(ang)));
                Vec3 q = c.add(d.scale(r * (1.0 + h * Math.sin(Math.PI * u))));
                if (prev != null) {
                    strip(m, vc, prev, q, w * 2.6, 255, 110, 15, (int) (70 * fade * env));
                    strip(m, vc, prev, q, w, 255, 200, 70, (int) (210 * fade * env));
                }
                prev = q;
            }
        }
    }

    // ------------------------------------------------------------------ around it

    /** Three tilted rings of plasma, each with a bright head and a tail that fades behind it. */
    private static void rings(Matrix4f m, VertexConsumer vc, Vec3 c, double r, double time, int seed, double fade) {
        double s = seed * 0.7;
        double drift = time * 0.004;
        ring(m, vc, c, r * 1.45, r * 0.05, 0.50 + drift, 0.20 + s, time * 0.045, 255, 170, 40, (int) (120 * fade), true);
        ring(m, vc, c, r * 1.75, r * 0.07, -0.40 - drift, 0.70 + s, -time * 0.032, 255, 120, 20, (int) (95 * fade), true);
        ring(m, vc, c, r * 2.10, r * 0.09, 0.90 + drift * 0.5, -0.50 + s, time * 0.022, 255, 220, 120, (int) (75 * fade), true);
    }

    /** Long shafts of light fanning out from the sun, turning slowly. */
    private static void rays(Matrix4f m, VertexConsumer vc, Vec3 c, double r, double time, int seed, double fade) {
        Random rr = new Random(seed * 17L + 5);
        for (int k = 0; k < 14; k++) {
            Vec3 d = randUnit(rr);
            double ang = time * 0.010 * (k % 2 == 0 ? 1 : -1);
            double ca = Math.cos(ang), sa = Math.sin(ang);
            d = new Vec3(d.x * ca - d.z * sa, d.y, d.x * sa + d.z * ca);
            double len = r * (1.6 + rr.nextDouble() * 2.2) * (0.8 + 0.2 * Math.sin(time * 0.2 + k));
            Vec3 a = c.add(d.scale(r * 1.05));
            Vec3 b = c.add(d.scale(r * 1.05 + len));
            strip(m, vc, a, b, r * 0.05, 255, 200, 60, (int) (38 * fade));
        }
    }

    /** Waves of corona that swell outwards from the surface and thin to nothing. */
    private static void pulses(Matrix4f m, VertexConsumer vc, Vec3 c, double r, double time, int seed, double fade) {
        for (int i = 0; i < 2; i++) {
            double ph = ((time + i * 30) % 60) / 60.0;
            sphere(m, vc, c, r * (1.1 + ph * 1.6), 255, 200, 80, (int) (40 * (1 - ph) * fade), time, seed, false);
        }
    }

    /** When the sun finishes swelling: a flat ring and a sphere race outwards and fade. {@code t} runs 0..1. */
    private static void shockwave(Matrix4f m, VertexConsumer vc, Vec3 c, double r, double groundR, double t, int seed) {
        double k = 1 - (1 - t) * (1 - t);
        int a = (int) (190 * (1 - t));
        ring(m, vc, c, r + (groundR * 1.1 - r) * k, r * 0.10 + 0.4, 0, 0, 0, 255, 235, 170, a, false);
        sphere(m, vc, c, r * (1.0 + 4.0 * k), 255, 230, 150, (int) (110 * (1 - t)), 0, seed, false);
    }

    // ------------------------------------------------------------------ the ground

    /** A pool of molten light on the ground with cracks of fire spreading out across it. */
    private static void ground(Matrix4f m, VertexConsumer vc, Vec3 gc, double R, double time, int seed, double fade) {
        if (R < 1) return;
        double pulse = 0.75 + 0.25 * Math.sin(time * 0.15);
        int bands = 6;
        for (int i = 0; i < bands; i++) {
            double mid = (i + 0.5) * R / bands;
            int a = (int) ((64 - i * 9) * pulse * fade);
            ring(m, vc, gc, mid, R / bands * 0.5, 0, 0, 0, 255, 90 + i * 8, 15, a, false);
        }
        Random rc = new Random(seed * 911L + 3);
        int cracks = 16;
        for (int k = 0; k < cracks; k++) {
            double ang = Math.PI * 2 * k / cracks + (rc.nextDouble() - 0.5) * 0.3;
            double flick = 0.55 + 0.45 * Math.sin(time * 0.2 + k * 1.7);
            Vec3 p = gc;
            double dist = 0;
            while (dist < R) {
                double len = R / 7.5 * (0.7 + 0.6 * rc.nextDouble());
                ang += (rc.nextDouble() - 0.5) * 0.7;
                len = Math.min(len, R - dist);
                Vec3 q = p.add(new Vec3(Math.cos(ang) * len, 0, Math.sin(ang) * len));
                double fall = 1 - dist / R * 0.6;
                strip(m, vc, p, q, 0.20, 255, 60, 10, (int) (110 * flick * fall * fade));
                strip(m, vc, p, q, 0.08, 255, 200, 60, (int) (170 * flick * fall * fade));
                p = q;
                dist += len;
            }
        }
    }

    /** Now and then a bolt of lightning leaps from the sun to the ground, with a flash where it lands. */
    private static void bolts(Matrix4f m, VertexConsumer vc, Vec3 c, Vec3 gc, double r, double R, double time, int seed, double fade) {
        long bucket = (long) Math.floor(time / 6.0);
        Random rb = new Random(bucket * 104729L + seed * 31L);
        if (rb.nextInt(3) != 0) return;
        if (time - bucket * 6.0 > 4.0) return;
        int count = 1 + rb.nextInt(2);
        for (int b = 0; b < count; b++) {
            double ang = rb.nextDouble() * Math.PI * 2;
            double dist = rb.nextDouble() * R * 0.85;
            Vec3 target = gc.add(new Vec3(Math.cos(ang) * dist, 0, Math.sin(ang) * dist));
            Vec3 toward = target.subtract(c);
            if (toward.lengthSqr() < 1e-6) continue;
            Vec3 start = c.add(toward.normalize().scale(r * 0.95));
            int segs = 16;
            Vec3 prev = start;
            for (int i = 1; i <= segs; i++) {
                double t = i / (double) segs;
                Vec3 q = start.add(target.subtract(start).scale(t));
                if (i < segs) q = q.add(new Vec3(rb.nextGaussian(), rb.nextGaussian() * 0.3, rb.nextGaussian()).scale(0.35));
                strip(m, vc, prev, q, 0.22, 255, 210, 60, (int) (110 * fade));
                strip(m, vc, prev, q, 0.07, 255, 255, 230, (int) (240 * fade));
                if (i == segs / 2) {
                    // one fork off the middle
                    Vec3 end = q.add(new Vec3(rb.nextGaussian(), -Math.abs(rb.nextGaussian()) * 2, rb.nextGaussian()).scale(1.6));
                    Vec3 fp = q;
                    for (int f = 1; f <= 5; f++) {
                        Vec3 fq = q.add(end.subtract(q).scale(f / 5.0)).add(new Vec3(rb.nextGaussian(), rb.nextGaussian(), rb.nextGaussian()).scale(0.2));
                        strip(m, vc, fp, fq, 0.04, 255, 240, 170, (int) (200 * fade));
                        fp = fq;
                    }
                }
                prev = q;
            }
            sphere(m, vc, target, 0.9, 255, 230, 140, (int) (150 * fade), time, seed, false);
        }
    }

    // ------------------------------------------------------------------ geometry

    /**
     * A flat annulus tilted about X then Z. With {@code comet} the ring has a bright head and a tail that fades behind it as
     * it spins; otherwise it is the same all the way round.
     */
    private static void ring(Matrix4f m, VertexConsumer vc, Vec3 c, double R, double halfW, double tiltX, double tiltZ, double spin,
                             int red, int green, int blue, int alpha, boolean comet) {
        if (alpha <= 0 || R <= 0) return;
        int n = 56;
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n + spin, a1 = Math.PI * 2 * (i + 1) / n + spin;
            int al = alpha;
            if (comet) {
                double f = (double) i / n;
                al = (int) (alpha * (0.12 + 0.88 * f * f));
            }
            Vec3 p0 = tilt(c, R - halfW, a0, tiltX, tiltZ), p1 = tilt(c, R + halfW, a0, tiltX, tiltZ);
            Vec3 p2 = tilt(c, R + halfW, a1, tiltX, tiltZ), p3 = tilt(c, R - halfW, a1, tiltX, tiltZ);
            quad(m, vc, p0, p1, p2, p3, red, green, blue, al);
            quad(m, vc, p3, p2, p1, p0, red, green, blue, al);
        }
    }

    private static Vec3 tilt(Vec3 c, double rad, double ang, double tx, double tz) {
        double x = Math.cos(ang) * rad, y = 0, z = Math.sin(ang) * rad;
        double y1 = y * Math.cos(tx) - z * Math.sin(tx);
        double z1 = y * Math.sin(tx) + z * Math.cos(tx);
        double x2 = x * Math.cos(tz) - y1 * Math.sin(tz);
        double y2 = x * Math.sin(tz) + y1 * Math.cos(tz);
        return new Vec3(c.x + x2, c.y + y2, c.z + z1);
    }

    /**
     * A UV sphere drawn from both sides. With {@code mottled} every patch of the surface takes its own colour from slowly changing noise
     * (deep red through orange to yellow), which is what makes the body look like a boiling star rather than a plain ball.
     */
    private static void sphere(Matrix4f m, VertexConsumer vc, Vec3 c, double r, int red, int green, int blue, int alpha, double time, int seed, boolean mottled) {
        if (alpha <= 0) return;
        for (int i = 0; i < LAT; i++) {
            double p0 = Math.PI * i / LAT - Math.PI / 2, p1 = Math.PI * (i + 1) / LAT - Math.PI / 2;
            for (int j = 0; j < LON; j++) {
                double t0 = 2 * Math.PI * j / LON, t1 = 2 * Math.PI * (j + 1) / LON;
                int rr = red, gg = green, bb = blue;
                if (mottled) {
                    double n = noise(i, j, time, seed); // 0..1
                    // 0 = deep red, 0.5 = orange, 1 = yellow
                    rr = 255;
                    gg = (int) Mth.lerp(n, 45, 225);
                    bb = (int) Mth.lerp(n, 5, 55);
                }
                Vec3 a = pt(c, r, p0, t0), b = pt(c, r, p1, t0), d = pt(c, r, p1, t1), e = pt(c, r, p0, t1);
                quad(m, vc, a, b, d, e, rr, gg, bb, alpha);
                quad(m, vc, e, d, b, a, rr, gg, bb, alpha);
            }
        }
    }

    /** Cheap blotchy noise: a few drifting sine waves summed over the patch's position, so neighbours resemble one another. */
    private static double noise(int i, int j, double time, int seed) {
        double s = seed * 0.37;
        double v = Math.sin(i * 0.9 + time * 0.045 + s)
            + Math.sin(j * 0.55 - time * 0.035 + i * 0.3 + s * 1.7)
            + Math.sin((i + j) * 0.7 + time * 0.06)
            + Math.sin(i * 1.7 - j * 0.9 - time * 0.025 + s);
        return Mth.clamp(0.5 + v * 0.14, 0.0, 1.0);
    }

    private static Vec3 pt(Vec3 c, double r, double phi, double theta) {
        double cp = Math.cos(phi);
        return new Vec3(c.x + r * cp * Math.cos(theta), c.y + r * Math.sin(phi), c.z + r * cp * Math.sin(theta));
    }

    /** A thin crossed-quad strip between two points: a flare segment visible from any angle. */
    private static void strip(Matrix4f m, VertexConsumer vc, Vec3 a, Vec3 b, double w, int red, int green, int blue, int alpha) {
        if (alpha <= 0) return;
        Vec3 d = b.subtract(a);
        if (d.lengthSqr() < 1e-8) return;
        Vec3 n = d.normalize();
        Vec3 p1 = n.cross(Math.abs(n.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0)).normalize().scale(w);
        Vec3 p2 = n.cross(p1).normalize().scale(w);
        for (Vec3 p : new Vec3[]{p1, p2}) {
            quad(m, vc, a.add(p), a.subtract(p), b.subtract(p), b.add(p), red, green, blue, alpha);
        }
    }

    private static void quad(Matrix4f m, VertexConsumer vc, Vec3 a, Vec3 b, Vec3 c, Vec3 d, int r, int g, int bl, int al) {
        al = Math.min(255, Math.max(0, al));
        v(m, vc, a, r, g, bl, al);
        v(m, vc, b, r, g, bl, al);
        v(m, vc, c, r, g, bl, al);
        v(m, vc, d, r, g, bl, al);
    }

    private static void v(Matrix4f m, VertexConsumer vc, Vec3 p, int r, int g, int b, int a) {
        vc.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, a).endVertex();
    }
}
