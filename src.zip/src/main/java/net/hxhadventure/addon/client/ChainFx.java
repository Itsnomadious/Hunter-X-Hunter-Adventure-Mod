package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;

/** Client-side list of chain visuals currently being drawn. */
public final class ChainFx {
    public enum Kind { SWEEP, HOLY, JAIL, JAIL_END, HOLY_END, JUDGMENT }

    public static final class Fx {
        public final Kind kind;
        public final int caster, target;
        /** Ticks the effect lasts. A held Holy Chain starts very long and is cut short (then reeled in) when HOLY_END arrives. */
        public int duration;
        public final long start;
        public final float dx, dy, dz, side, range;
        /** The Dowsing Chain's physics, created on first draw (Kind.SWEEP only). */
        public ChainRope rope;

        Fx(Kind k, int caster, int target, int duration, long start, float dx, float dy, float dz, float side, float range) {
            this.kind = k;
            this.caster = caster;
            this.target = target;
            this.duration = duration;
            this.start = start;
            this.dx = dx;
            this.dy = dy;
            this.dz = dz;
            this.side = side;
            this.range = range;
        }
    }

    public static final List<Fx> ACTIVE = new ArrayList<>();

    // ---- Dowsing Chain (Kind.SWEEP) motion, shared by the chain renderer and the caster's arm (see ChainRope) ----
    // The cast lasts fx.duration ticks: the swing (left to right), then RETRACT ticks of curling and reeling back into the hand.
    // ChainManager.SWEEP_TICKS + SWEEP_RETRACT_TICKS must add up to the duration it sends.
    public static final int SWEEP_RETRACT_TICKS = ChainRope.RETRACT_TICKS;
    public static final double SWEEP_HALF_ARC = ChainRope.HALF_ARC;

    /** Ticks the swing itself lasts. */
    public static double sweepSwing(Fx fx) {
        return Math.max(1, fx.duration - SWEEP_RETRACT_TICKS);
    }

    /** Angle (rad, negative = left, positive = right) of the part of the chain at u (0 = hand, 1 = ball). */
    public static double sweepAngle(double age, double swing, double u) {
        return ChainRope.angle(age, swing, u);
    }

    /** Fraction of its full length the chain has out. */
    public static double sweepLength(double age, double swing) {
        return ChainRope.length(age, swing);
    }

    /** Unit direction the Dowsing Chain is cast in (follows where the caster looked, up or down included). */
    public static double[] sweepForward(Fx fx) {
        double l = Math.sqrt(fx.dx * fx.dx + fx.dy * fx.dy + fx.dz * fx.dz);
        if (l < 1e-6) return new double[] {0, 0, 1};
        return new double[] {fx.dx / l, fx.dy / l, fx.dz / l};
    }

    /** Where the caster is looking right now: the whole swing follows the camera while it plays. */
    public static double[] liveForward(Fx fx, Entity caster, float pt) {
        if (caster == null) return sweepForward(fx);
        var v = caster.getViewVector(pt);
        double l = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
        if (l < 1e-6) return sweepForward(fx);
        return new double[] {v.x / l, v.y / l, v.z / l};
    }

    public static double[] sweepSide(Fx fx) {
        return sweepSide(fx, sweepForward(fx));
    }

    /** Unit vector (horizontal, perpendicular to the cast direction) the swing sweeps toward; points the other way when mirrored. */
    public static double[] sweepSide(Fx fx, double[] f) {
        double h = Math.hypot(f[0], f[2]);
        double sx = h < 1e-6 ? 1 : -f[2] / h, sz = h < 1e-6 ? 0 : f[0] / h;
        double sg = fx.side < 0 ? -1 : 1;
        return new double[] {sx * sg, 0, sz * sg};
    }

    private ChainFx() {}

    public static void add(byte kind, int caster, int target, int duration, float dx, float dy, float dz, float side, float range) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        Kind k = Kind.values()[Math.max(0, Math.min(Kind.values().length - 1, kind))];
        if (k == Kind.HOLY_END) {
            for (Fx f : ACTIVE) {
                if (f.kind == Kind.HOLY && f.caster == caster) f.duration = (int) (level.getGameTime() - f.start) + SWEEP_RETRACT_TICKS;
            }
            return;
        }
        if (k == Kind.HOLY) ACTIVE.removeIf(f -> f.kind == Kind.HOLY && f.caster == caster);
        if (k == Kind.JAIL_END || k == Kind.JAIL) ACTIVE.removeIf(f -> f.kind == Kind.JAIL && f.caster == caster);
        if (k == Kind.JAIL_END) return;
        ACTIVE.add(new Fx(k, caster, target, duration, level.getGameTime(), dx, dy, dz, side, range));
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
