package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Doctor Blythe's solid parts, built in code (pixel units; the renderer draws them at 2x, so 1px = 1/8 block).
 * Every box has its origin at the BOTTOM CENTRE of the box and grows upward, with its "front" (the face painted
 * at u+depth, v+depth) toward +Z once the renderer has flipped it the vanilla way.
 *
 * The arms, fingers, wings, tail and tendrils are not boxes of their own: they are the 1px "unit" parts (bone, metal,
 * cord, tendril, glow, plum) stretched between two points, which is how a skeleton with moving joints stays simple.
 *
 * Texture sheet 128x128: assets/hxhadventure/textures/entity/doctor_blythe.png (see tools/make_blythe_texture.py).
 */
public final class BlytheModel {
    private BlytheModel() {}

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("hxhadventure", "doctor_blythe"), "main");

    public record Parts(ModelPart torso, ModelPart head, ModelPart hairBack, ModelPart hairTop, ModelPart hairSide,
                        ModelPart bangs, ModelPart puff, ModelPart collar,
                        ModelPart bone, ModelPart metal, ModelPart cord, ModelPart tendril, ModelPart glow, ModelPart plum) {}

    /** A 1px cube running from z=0 to z=1: scaled along its length it becomes any stick between two points. */
    private static CubeListBuilder stick(int u, int v) {
        return CubeListBuilder.create().texOffs(u, v).addBox(-0.5f, -0.5f, 0f, 1f, 1f, 1f);
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(0, 0).addBox(-6f, -18f, -4.5f, 12f, 18f, 9f), PartPose.ZERO);
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 32).addBox(-7f, -15f, -6f, 14f, 15f, 12f), PartPose.ZERO);
        root.addOrReplaceChild("hair_back", CubeListBuilder.create().texOffs(64, 0).addBox(-8f, -16f, -1.5f, 16f, 16f, 3f), PartPose.ZERO);
        root.addOrReplaceChild("hair_top", CubeListBuilder.create().texOffs(64, 0).addBox(-8f, -3f, -7f, 16f, 3f, 14f), PartPose.ZERO);
        root.addOrReplaceChild("hair_side", CubeListBuilder.create().texOffs(64, 0).addBox(-1f, -14f, -6.5f, 2f, 14f, 13f), PartPose.ZERO);
        root.addOrReplaceChild("bangs", CubeListBuilder.create().texOffs(64, 0).addBox(-7f, -4f, -1f, 14f, 4f, 2f), PartPose.ZERO);
        root.addOrReplaceChild("puff", CubeListBuilder.create().texOffs(64, 32).addBox(-5f, -10f, -5f, 10f, 10f, 10f), PartPose.ZERO);
        root.addOrReplaceChild("collar", CubeListBuilder.create().texOffs(64, 64).addBox(-6.5f, -3f, -5.5f, 13f, 3f, 11f), PartPose.ZERO);
        root.addOrReplaceChild("bone", stick(0, 96), PartPose.ZERO);
        root.addOrReplaceChild("metal", stick(8, 96), PartPose.ZERO);
        root.addOrReplaceChild("cord", stick(16, 96), PartPose.ZERO);
        root.addOrReplaceChild("tendril", stick(24, 96), PartPose.ZERO);
        root.addOrReplaceChild("glow", stick(32, 96), PartPose.ZERO);
        root.addOrReplaceChild("plum", stick(40, 96), PartPose.ZERO);
        return LayerDefinition.create(mesh, 128, 128);
    }

    private static Parts cached;

    /** Baked once and reused: baking builds the whole model tree, far too slow to repeat every frame. */
    public static Parts parts(Minecraft mc) {
        if (cached == null) {
            ModelPart r = mc.getEntityModels().bakeLayer(LAYER);
            cached = new Parts(r.getChild("torso"), r.getChild("head"), r.getChild("hair_back"), r.getChild("hair_top"),
                r.getChild("hair_side"), r.getChild("bangs"), r.getChild("puff"), r.getChild("collar"),
                r.getChild("bone"), r.getChild("metal"), r.getChild("cord"), r.getChild("tendril"),
                r.getChild("glow"), r.getChild("plum"));
        }
        return cached;
    }
}
