package net.hxhadventure.addon.client;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.ClientAddonState;
import net.hxhadventure.event.ClientAbilityHandler;

/**
 * The always-on HUD:
 *  - the selected Z ability, centred above the hotbar (name only)
 *  - the Nen bar, bottom left, fixed size, with current / max above it
 *  - running cooldowns, bottom right (each one disappears when it ends)
 *  - the movable box (HudPanel) for irregular states: Emperor Time, Bandit's Secret, Aura form, En, Zetsu
 */
public final class AddonHud {
    private AddonHud() {}

    // Nen bar (fixed length, independent of the box's size slider)
    private static final int NEN_W = 150, NEN_H = 12, EDGE = 6;
    /** The darker horizontal stripe along the bottom of the Nen bar: its height in pixels and how much darker it is (1 = same, 0 = black). */
    private static final int DARK_BAND_H = 5;
    private static final float DARK_BAND_SHADE = 0.55f;
    /** The same stripe on a dark aura (black ...): a shade darker again, so the bottom of the bar is still told apart from the top. */
    private static final float DARK_BAND_SHADE_DARK = 0.35f;
    // Cooldown list
    private static final int CD_ROW_H = 13, CD_BAR_H = 2, CD_PAD = 3;
    private static final int ABILITY_COLOUR = 0x55FF55;
    /** Pixels between the bottom of the screen and the selected-ability text (clears the hotbar, bars and action bar). */
    private static final int ABILITY_BOTTOM = 96;

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Combat c = Combat.get(mc.player);
        if (c == null) return;
        if (c.hasNenUnlocked() && ClientAddonState.emperor) {
            int c1 = 0x55FF0000, c0 = 0x00FF0000, t = 14;
            g.fillGradient(0, 0, width, t, c1, c0);
            g.fillGradient(0, height - t, width, height, c0, c1);
            g.fill(0, 0, 2, height, c1);
            g.fill(width - 2, 0, width, height, c1);
        }

        // Terpsichora post-mortem: the whole screen goes red, deeper and more solid than Emperor Time's edge glow, and it throbs.
        if (TerpsichoraFx.localMode() == net.hxhadventure.addon.Terpsichora.DEAD) {
            double age = TerpsichoraFx.localDeadAge(partialTick);
            double fadeIn = Math.min(1.0, age / 8.0);                          // slams in over ~0.4 s
            double pulse = 0.5 + 0.5 * Math.sin(age * 0.22);
            int wash = (int) ((70 + 35 * pulse) * fadeIn);                     // full-screen blood-red tint
            int edge = (int) ((190 + 50 * pulse) * fadeIn), edge0 = 0x00FF0000;
            int t = Math.max(40, height / 5);
            g.fill(0, 0, width, height, (wash << 24) | 0xB00000);
            g.fillGradient(0, 0, width, t, (edge << 24) | 0xFF0000, edge0);
            g.fillGradient(0, height - t, width, height, edge0, (edge << 24) | 0xFF0000);
            int side = Math.max(40, width / 7); // left/right edges fade inward in 2px columns (GuiGraphics has no horizontal gradient)
            for (int i = 0; i < side; i += 2) {
                double k = 1.0 - (double) i / side;
                int a = (int) (edge * k * k);
                if (a <= 0) break;
                g.fill(i, 0, i + 2, height, (a << 24) | 0xFF0000);
                g.fill(width - i - 2, 0, width - i, height, (a << 24) | 0xFF0000);
            }
        }

        drawSelectedAbility(g, mc.font, width, height);
        if (c.hasNenUnlocked()) drawNenBar(g, mc.font, mc, c, height);
        drawCooldowns(g, mc.font, width, height);

        // While the move screen is open it draws the panel itself.
        if (mc.screen instanceof HudEditScreen) return;
        List<HudPanel.Line> lines = HudPanel.lines(mc, c);
        if (lines.isEmpty()) return;
        int x = HudLayout.x(width, HudPanel.width(mc.font, lines));
        int y = HudLayout.y(height, HudPanel.height(lines));
        HudPanel.draw(g, mc.font, x, y, lines, false);
    };

    /** Just the ability's name, always on screen, changing as the Z menu is cycled. */
    private static void drawSelectedAbility(GuiGraphics g, Font font, int width, int height) {
        String name = ClientAbilityHandler.getSelectedAbilityName();
        if (name == null || name.isEmpty()) return;
        g.drawCenteredString(font, name, width / 2, height - ABILITY_BOTTOM, 0xFF000000 | ABILITY_COLOUR);
    }

    private static void drawNenBar(GuiGraphics g, Font font, Minecraft mc, Combat c, int height) {
        int cur = (int) c.getCurrentEnergy();
        int max = (int) c.getMaxEnergy();
        float frac = max > 0 ? Math.max(0f, Math.min(1f, cur / (float) max)) : 0f;
        int colour = 0xFF000000 | lift(AuraColours.rgb(mc.player) & 0xFFFFFF); // dark auras get a slightly lighter version of the same colour
        boolean darkColour = brightness(colour) < 0.4f;

        int x = EDGE;
        int y = height - EDGE - NEN_H;
        String text = cur + " / " + max;
        boolean blackAura = mc.player != null && mc.player.getPersistentData().getInt("HxHCraft_PermanentAuraColor") == 9;
        net.minecraft.network.chat.Component label = blackAura
            ? net.minecraft.network.chat.Component.literal(text).withStyle(net.minecraft.ChatFormatting.BOLD)
            : net.minecraft.network.chat.Component.literal(text);
        int ty = y - font.lineHeight - 2;
        // an outline all round, then the text itself, so it reads on any background (grass, snow, night)
        net.minecraft.util.FormattedCharSequence seq = label.getVisualOrderText();
        for (int ox = -1; ox <= 1; ox++) for (int oy = -1; oy <= 1; oy++) {
            if (ox != 0 || oy != 0) g.drawString(font, seq, x + ox, ty + oy, darkColour ? 0xFFE6E6EC : 0xFF000000, false); // light outline round dark text, dark round bright
        }
        g.drawString(font, seq, x, ty, colour, false); // bold for the black aura so it stays readable

        g.fill(x - 1, y - 1, x + NEN_W + 1, y + NEN_H + 1, 0xFFD8D8D8);   // outer border
        g.fill(x, y, x + NEN_W, y + NEN_H, darkColour ? 0xFF060608 : 0xFF101010); // empty part (a touch darker behind a dark fill so the fill still shows)
        int fill = Math.round(NEN_W * frac);
        if (fill > 0) {
            g.fill(x, y, x + fill, y + NEN_H, colour);
            g.fill(x, y + NEN_H - DARK_BAND_H, x + fill, y + NEN_H, shade(colour, darkColour ? DARK_BAND_SHADE_DARK : DARK_BAND_SHADE)); // darker horizontal band along the bottom
            g.fill(x, y, x + fill, y + 2, 0x55FFFFFF);                    // soft highlight along the top
        }
    }

    /** Relative brightness 0-1 (perceptual weights, no gamma: good enough for a HUD). */
    private static float brightness(int rgb) {
        return (0.299f * ((rgb >> 16) & 0xFF) + 0.587f * ((rgb >> 8) & 0xFF) + 0.114f * (rgb & 0xFF)) / 255f;
    }

    /** Dark aura colours (black, midnight, indigo ...) are unreadable as a bar and as text, so the HUD uses the same colour mixed towards white just enough to be seen, so black still looks black (a dark charcoal, like the Ren flame) rather than grey. */
    private static final float MIN_HUD_BRIGHTNESS = 0.18f;

    private static int lift(int rgb) {
        float b = brightness(rgb);
        if (b >= MIN_HUD_BRIGHTNESS) return rgb;
        float k = (MIN_HUD_BRIGHTNESS - b) / (1f - b); // fraction of the way to white that reaches the minimum brightness
        int r = Math.round(((rgb >> 16) & 0xFF) + (255 - ((rgb >> 16) & 0xFF)) * k);
        int gr = Math.round(((rgb >> 8) & 0xFF) + (255 - ((rgb >> 8) & 0xFF)) * k);
        int bl = Math.round((rgb & 0xFF) + (255 - (rgb & 0xFF)) * k);
        return (r << 16) | (gr << 8) | bl;
    }

    /** The colour multiplied towards black, keeping full alpha. */
    private static int shade(int argb, float f) {
        int r = Math.round(((argb >> 16) & 0xFF) * f);
        int gr = Math.round(((argb >> 8) & 0xFF) * f);
        int b = Math.round((argb & 0xFF) * f);
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }

    private static void drawCooldowns(GuiGraphics g, Font font, int width, int height) {
        List<ClientCooldowns.Entry> list = ClientCooldowns.active();
        if (list.isEmpty()) return;
        long now = Minecraft.getInstance().level == null ? 0L : Minecraft.getInstance().level.getGameTime();
        int y = height - EDGE - CD_ROW_H;
        for (int i = list.size() - 1; i >= 0; i--) { // newest at the bottom, older ones stack upwards
            ClientCooldowns.Entry e = list.get(i);
            int left = e.remaining(now);
            String time = String.format(java.util.Locale.ROOT, "%.1fs", left / 20.0);
            int w = Math.max(80, font.width(e.name()) + font.width(time) + CD_PAD * 2 + 10);
            int x1 = width - EDGE;
            int x0 = x1 - w;
            g.fill(x0, y, x1, y + CD_ROW_H - 1, 0x80000000);
            g.drawString(font, e.name(), x0 + CD_PAD, y + 2, 0xFFFFFFFF, true);
            g.drawString(font, time, x1 - CD_PAD - font.width(time), y + 2, 0xFFFF5555, true);
            float frac = e.total() > 0 ? left / (float) e.total() : 0f;
            int bw = Math.round((w - 2) * frac);
            g.fill(x0 + 1, y + CD_ROW_H - 1 - CD_BAR_H, x0 + 1 + bw, y + CD_ROW_H - 1, 0xFFFF5555);
            y -= CD_ROW_H + 2;
        }
    }
}
