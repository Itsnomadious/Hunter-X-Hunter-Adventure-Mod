package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.hxhadventure.addon.HisokaEntity;

public class HisokaRenderer extends NpcPlayerRenderer<HisokaEntity> {
    public HisokaRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, h -> tex("hisoka"), h -> false);
        addLayer(new NpcAuraLayer<>(this, tex("pinkaura_ten"), NpcAuraLayer.standard(HisokaEntity::nenFlags)));
    }
}
