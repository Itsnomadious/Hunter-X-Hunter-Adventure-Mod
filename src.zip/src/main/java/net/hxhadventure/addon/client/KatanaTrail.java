package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.hxhadventure.addon.KatanaSwingTuning;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * A very thin, almost invisible white streak along the Katana's tip where the blade has just been, drawn during the cutting part of a slash.
 * Samples are taken while the sword is drawn (KatanaWrist.apply, third person) and drawn as a fading ribbon after the level's particles.
 * Numbers (length, thickness, brightness) are in {@link KatanaSwingTuning}.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class KatanaTrail {
    private KatanaTrail() {}

    /** x, y, z of the tip end and x, y, z of the inner end of the ribbon (camera-relative world), and the time (ticks) it was taken. */
    private static final class Sample {
        final float[] p = new float[7];
    }

    private static final Map<Integer, ArrayDeque<Sample>> TRAILS = new HashMap<>();

    // model-space points on the blade (see KatanaSwingTuning): blade runs along A = (0.7988, 0.6016), tip at 2.215
    private static final float AX = 0.7988f, AY = 0.6016f, EX = -0.6016f, EY = 0.7988f;
    private static final Quaternionf DISP = new Quaternionf().rotationXYZ(0f, (float) Math.toRadians(-90), (float) Math.toRadians(55));

    private static Vector3f toView(PoseStack pose, float t, float s) {
        // model point -> item frame (third-person right-hand display transform) -> current pose
        Vector3f v = new Vector3f(t * AX + s * EX - 0.5f, t * AY + s * EY - 0.5f, 0f).mul(0.85f);
        DISP.transform(v);
        v.add(0f, 4f / 16f, 0.5f / 16f);
        pose.last().pose().transformPosition(v);
        return v;
    }

    /** Records one sample of the blade's tip (called with the pose AFTER the wrist turn, only during the cut). */
    public static void record(LivingEntity e, PoseStack pose) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        float now = (float) mc.level.getGameTime() + mc.getFrameTime();
        ArrayDeque<Sample> q = TRAILS.computeIfAbsent(e.getId(), k -> new ArrayDeque<>());
        Sample last = q.peekLast();
        if (last != null && now - last.p[6] < 0.05f) return;
        Vector3f tip = toView(pose, 2.15f, 0.0f);
        Vector3f inner = toView(pose, 2.15f - KatanaSwingTuning.TRAIL_THICKNESS, 0.0f);
        // the pose includes the camera's view rotation: undo it so the sample is a world position relative to the camera
        Quaternionf camRot = mc.gameRenderer.getMainCamera().rotation();
        camRot.transform(tip);
        camRot.transform(inner);
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        Sample s = new Sample();
        s.p[0] = tip.x + (float) cam.x; s.p[1] = tip.y + (float) cam.y; s.p[2] = tip.z + (float) cam.z;
        s.p[3] = inner.x + (float) cam.x; s.p[4] = inner.y + (float) cam.y; s.p[5] = inner.z + (float) cam.z;
        s.p[6] = now;
        q.addLast(s);
        while (q.size() > 40) q.removeFirst();
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent ev) {
        if (ev.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || TRAILS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) { TRAILS.clear(); return; }
        float now = (float) mc.level.getGameTime() + mc.getFrameTime();
        float life = KatanaSwingTuning.TRAIL_LIFE_TICKS;
        Vec3 cam = ev.getCamera().getPosition();
        Matrix4f m = ev.getPoseStack().last().pose();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buf.getBuffer(RenderType.lightning());
        boolean any = false;
        for (Iterator<ArrayDeque<Sample>> it = TRAILS.values().iterator(); it.hasNext(); ) {
            ArrayDeque<Sample> q = it.next();
            while (!q.isEmpty() && now - q.peekFirst().p[6] > life) q.removeFirst();
            if (q.isEmpty()) { it.remove(); continue; }
            Sample prev = null;
            for (Sample s : q) {
                if (prev != null && s.p[6] - prev.p[6] < 1.6f) {
                    float a0 = KatanaSwingTuning.TRAIL_ALPHA * Math.max(0f, 1f - (now - prev.p[6]) / life);
                    float a1 = KatanaSwingTuning.TRAIL_ALPHA * Math.max(0f, 1f - (now - s.p[6]) / life);
                    quad(vc, m, cam, prev, s, a0, a1);
                    any = true;
                }
                prev = s;
            }
        }
        if (any) buf.endBatch(RenderType.lightning());
    }

    private static void v(VertexConsumer vc, Matrix4f m, Vec3 cam, float x, float y, float z, float a) {
        vc.vertex(m, (float) (x - cam.x), (float) (y - cam.y), (float) (z - cam.z)).color(1f, 1f, 1f, a).endVertex();
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Vec3 cam, Sample a, Sample b, float a0, float a1) {
        // both windings, so the ribbon is visible from either side
        v(vc, m, cam, a.p[0], a.p[1], a.p[2], a0); v(vc, m, cam, a.p[3], a.p[4], a.p[5], a0);
        v(vc, m, cam, b.p[3], b.p[4], b.p[5], a1); v(vc, m, cam, b.p[0], b.p[1], b.p[2], a1);
        v(vc, m, cam, b.p[0], b.p[1], b.p[2], a1); v(vc, m, cam, b.p[3], b.p[4], b.p[5], a1);
        v(vc, m, cam, a.p[3], a.p[4], a.p[5], a0); v(vc, m, cam, a.p[0], a.p[1], a.p[2], a0);
    }
}
