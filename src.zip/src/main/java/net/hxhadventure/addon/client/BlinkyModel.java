package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Blinky's vacuum cleaner body, built in code (pixel units, 16px = 1 block, Minecraft's usual axes: -Y is up, the front is -Z):
 * a teal canister with a lid, a tall tail fin, two eye-stalks with pupils, a green belly, two wheels and a nozzle port at the front
 * where the hose goes in. Plus the two pieces the hose is made of: a long ribbed link and a thin dark ring between links.
 * Texture sheet is 128x64, every part a flat colour: assets/hxhadventure/textures/entity/blinky.png (drawn by tools/make_blinky_textures.py).
 */
public final class BlinkyModel {
    private BlinkyModel() {}

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("hxhadventure", "blinky"), "main");
    public static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/blinky.png");

    /** Length of one hose link in pixels (the model of a link is this long). */
    public static final float LINK_LENGTH_PX = 3f;

    public record Parts(ModelPart canister, ModelPart link, ModelPart ring) {}

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("canister", CubeListBuilder.create()
            .texOffs(0, 0).addBox(-5f, -9f, -7f, 10f, 6f, 14f)         // body
            .texOffs(48, 0).addBox(-4f, -11f, -5f, 8f, 2f, 8f)         // lid
            .texOffs(80, 0).addBox(-1f, -13f, 3f, 2f, 6f, 6f)          // tail fin
            .texOffs(96, 0).addBox(-4.5f, -12f, -7f, 3f, 3f, 3f)       // eyes
            .texOffs(96, 0).addBox(1.5f, -12f, -7f, 3f, 3f, 3f)
            .texOffs(108, 0).addBox(-3.5f, -11f, -8f, 1f, 1f, 1f)      // pupils
            .texOffs(108, 0).addBox(2.5f, -11f, -8f, 1f, 1f, 1f)
            .texOffs(0, 20).addBox(-2f, -7f, -10f, 4f, 4f, 3f)         // nozzle port
            .texOffs(14, 20).addBox(-4f, -3f, -6f, 8f, 1f, 12f)        // belly
            .texOffs(54, 20).addBox(5f, -5f, -3f, 2f, 5f, 5f)          // wheels
            .texOffs(54, 20).addBox(-7f, -5f, -3f, 2f, 5f, 5f),
            PartPose.ZERO);
        root.addOrReplaceChild("link", CubeListBuilder.create().texOffs(76, 20)
            .addBox(-1.25f, -1.25f, -LINK_LENGTH_PX / 2f, 2.5f, 2.5f, LINK_LENGTH_PX), PartPose.ZERO);
        root.addOrReplaceChild("ring", CubeListBuilder.create().texOffs(87, 20)
            .addBox(-1.6f, -1.6f, -0.4f, 3.2f, 3.2f, 0.8f), PartPose.ZERO);
        return LayerDefinition.create(mesh, 128, 64);
    }

    private static Parts cached;

    /** Baked once and reused: baking builds the whole model tree, far too slow to repeat every frame. */
    public static Parts parts(Minecraft mc) {
        if (cached == null) {
            ModelPart root = mc.getEntityModels().bakeLayer(LAYER);
            cached = new Parts(root.getChild("canister"), root.getChild("link"), root.getChild("ring"));
        }
        return cached;
    }
}
