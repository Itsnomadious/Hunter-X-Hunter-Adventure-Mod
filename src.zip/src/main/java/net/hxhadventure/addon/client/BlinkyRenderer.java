package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.Blinky;

/**
 * Draws the rest of Shizuku's vacuum cleaner for everyone who is holding Blinky's head: the canister, which trails behind its user on
 * its little wheels and always turns to face them, and the ribbed hose that runs from its nozzle port, along the floor, up to the
 * hand that holds the head. Nothing here is an entity: the client works it all out from who is holding the head, so there is nothing to
 * sync. Drawn in world space after the entities (the same stage as the Aura Blast).
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class BlinkyRenderer {
    private BlinkyRenderer() {}

    /** Size of the canister: 1.0 would make its body 14 px (0.875 blocks) long. */
    private static final float SCALE = 0.7f;
    /** How far behind its user the canister likes to sit, and how hard it is dragged when the user walks away. */
    private static final double LEASH = 1.9;
    private static final double DRAG = 0.3;
    private static final int HOSE_POINTS = 16;

    private static final class Body {
        Vec3 pos;
        Vec3 prev;
        float yaw;
        float prevYaw;

        Body(Vec3 at) {
            this.pos = at;
            this.prev = at;
        }
    }

    private static final Map<Integer, Body> BODIES = new HashMap<>();

    private static boolean holdsHead(AbstractClientPlayer p) {
        return Blinky.isHead(p.getMainHandItem()) || Blinky.isHead(p.getOffhandItem());
    }

    /** Which side the head is held on: +1 right, -1 left. */
    private static float handSide(AbstractClientPlayer p) {
        boolean inMain = Blinky.isHead(p.getMainHandItem());
        boolean mainIsRight = p.getMainArm() == HumanoidArm.RIGHT;
        return inMain == mainIsRight ? 1f : -1f;
    }

    // ---------------------------------------------------------------- the canister follows its user

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            BODIES.clear();
            return;
        }
        Set<Integer> live = new HashSet<>();
        for (AbstractClientPlayer p : level.players()) {
            if (!holdsHead(p) || p.isSpectator()) continue;
            live.add(p.getId());
            Body b = BODIES.get(p.getId());
            Vec3 user = p.position();
            if (b == null) {
                float yawRad = p.yBodyRot * Mth.DEG_TO_RAD;
                Vec3 behind = new Vec3(Mth.sin(yawRad), 0, -Mth.cos(yawRad)).scale(LEASH);
                b = new Body(user.add(behind));
                b.yaw = b.prevYaw = p.yBodyRot;
                BODIES.put(p.getId(), b);
            }
            b.prev = b.pos;
            b.prevYaw = b.yaw;
            double dx = user.x - b.pos.x, dz = user.z - b.pos.z;
            double flat = Math.sqrt(dx * dx + dz * dz);
            Vec3 next = b.pos;
            if (flat > 12.0) {
                // far too far (teleport, ender pearl...): it catches up at once
                float yawRad = p.yBodyRot * Mth.DEG_TO_RAD;
                next = user.add(new Vec3(Mth.sin(yawRad), 0, -Mth.cos(yawRad)).scale(LEASH));
                b.prev = next;
            } else if (flat > LEASH) {
                double pull = (flat - LEASH) * DRAG;
                next = new Vec3(b.pos.x + dx / flat * pull, b.pos.y, b.pos.z + dz / flat * pull);
            }
            // it rolls on the floor the user stands on
            double y = Mth.lerp(0.4, next.y, user.y);
            b.pos = new Vec3(next.x, y, next.z);
            if (flat > 0.3) {
                float want = (float) (Mth.atan2(-dx, dz) * (180.0 / Math.PI)); // its front (the nozzle) turns toward the user
                b.yaw = b.yaw + Mth.wrapDegrees(want - b.yaw) * 0.3f;
            }
        }
        BODIES.keySet().removeIf(id -> !live.contains(id));
    }

    // ---------------------------------------------------------------- drawing

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || BODIES.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.entityCutoutNoCull(BlinkyModel.TEXTURE);
        VertexConsumer vc = buf.getBuffer(type);
        BlinkyModel.Parts parts = BlinkyModel.parts(mc);

        for (AbstractClientPlayer p : level.players()) {
            Body b = BODIES.get(p.getId());
            if (b == null || p.isInvisible() || !holdsHead(p)) continue;
            Vec3 pos = b.prev.lerp(b.pos, pt);
            float yaw = Mth.rotLerp(pt, b.prevYaw, b.yaw);
            int light = LevelRenderer.getLightColor(level, BlockPos.containing(pos.x, pos.y + 0.5, pos.z));

            // the canister: its front (-Z in the model) faces the way it is turned
            ps.pushPose();
            ps.translate(pos.x - cam.x, pos.y - cam.y, pos.z - cam.z);
            ps.mulPose(Axis.YP.rotationDegrees(180f - yaw));
            ps.scale(-SCALE, -SCALE, SCALE);
            parts.canister().render(ps, vc, light, OverlayTexture.NO_OVERLAY);
            ps.popPose();

            hose(ps, vc, parts, p, pos, yaw, cam, pt, light);
        }
        buf.endBatch(type);
    }

    /** From the nozzle port, sagging along the floor, up to the hand that holds the head. */
    private static void hose(PoseStack ps, VertexConsumer vc, BlinkyModel.Parts parts, AbstractClientPlayer p, Vec3 canister, float canisterYaw,
                             Vec3 cam, float pt, int light) {
        // the port, at the front of the canister
        float cy = canisterYaw * Mth.DEG_TO_RAD;
        Vec3 front = new Vec3(-Mth.sin(cy), 0, Mth.cos(cy));
        Vec3 from = canister.add(front.scale(10f / 16f * SCALE)).add(0, 5f / 16f * SCALE, 0);

        // the hand: out to the side of the body, about hip height, a little ahead
        Vec3 user = p.getPosition(pt);
        float by = Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot) * Mth.DEG_TO_RAD;
        Vec3 forward = new Vec3(-Mth.sin(by), 0, Mth.cos(by));
        Vec3 right = new Vec3(-Mth.cos(by), 0, -Mth.sin(by));
        float height = p.isCrouching() ? 0.75f : 0.95f;
        Vec3 to = user.add(right.scale(0.34 * handSide(p))).add(forward.scale(0.12)).add(0, height, 0);

        double span = from.distanceTo(to);
        double sag = 0.25 + span * 0.12;
        double floor = Math.min(canister.y, user.y) + 0.06;

        Vec3[] pts = new Vec3[HOSE_POINTS + 1];
        for (int i = 0; i <= HOSE_POINTS; i++) {
            double t = i / (double) HOSE_POINTS;
            Vec3 q = from.lerp(to, t);
            double drop = sag * 4.0 * t * (1.0 - t);           // hangs lowest in the middle
            double y = Math.max(floor, q.y - drop);
            // it leaves the port level and arrives at the hand from below
            pts[i] = new Vec3(q.x, y, q.z);
        }
        for (int i = 0; i < HOSE_POINTS; i++) {
            Vec3 a = pts[i], c = pts[i + 1];
            double dx = c.x - a.x, dy = c.y - a.y, dz = c.z - a.z;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1e-4) continue;
            ps.pushPose();
            ps.translate((a.x + c.x) / 2 - cam.x, (a.y + c.y) / 2 - cam.y, (a.z + c.z) / 2 - cam.z);
            ps.mulPose(Axis.YP.rotation((float) Math.atan2(dx, dz)));
            ps.mulPose(Axis.XP.rotation((float) -Math.asin(Math.max(-1.0, Math.min(1.0, dy / len)))));
            // the link is stretched to cover the whole segment, its ring sits at the joint
            ps.pushPose();
            ps.scale(1f, 1f, (float) (len * 16.0 / BlinkyModel.LINK_LENGTH_PX));
            parts.link().render(ps, vc, light, OverlayTexture.NO_OVERLAY);
            ps.popPose();
            ps.translate(0, 0, -len / 2);
            parts.ring().render(ps, vc, light, OverlayTexture.NO_OVERLAY);
            ps.popPose();
        }
    }

    public static void clear() {
        BODIES.clear();
    }
}
