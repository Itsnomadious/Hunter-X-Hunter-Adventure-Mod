package net.hxhadventure.addon.client;

import net.hxhadventure.addon.Talent;

/** Client-side mirror of the local player's talent and whether Water Divination has shown them their Nen type (fed by PacketSyncProfile). */
public final class ClientProfile {
    private ClientProfile() {}

    public static int talent;
    public static boolean revealed;
    /** The game rule hxhnentypeselect is on: Water Divination lets the player choose their type. */
    public static boolean canSelectType;

    public static void set(int talentOrdinal, boolean typeRevealed, boolean selectable) {
        talent = talentOrdinal;
        revealed = typeRevealed;
        canSelectType = selectable;
    }

    public static Talent talent() {
        return Talent.byOrdinal(talent);
    }
}
