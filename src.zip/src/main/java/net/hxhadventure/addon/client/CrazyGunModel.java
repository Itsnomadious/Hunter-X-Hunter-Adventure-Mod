package net.hxhadventure.addon.client;

import net.hxhadventure.HxHAdventure;
import net.hxhadventure.addon.CrazyGunItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

/** HxH Craft's clown shotgun: geo, texture and the "shotgun_appear" pop-in animation. */
public class CrazyGunModel extends GeoModel<CrazyGunItem> {
    @Override public ResourceLocation getModelResource(CrazyGunItem a)     { return ResourceLocation.fromNamespaceAndPath(HxHAdventure.MOD_ID, "geo/crazy_shotgun.geo.json"); }
    @Override public ResourceLocation getTextureResource(CrazyGunItem a)   { return ResourceLocation.fromNamespaceAndPath(HxHAdventure.MOD_ID, "textures/item/crazy_shotgun.png"); }
    @Override public ResourceLocation getAnimationResource(CrazyGunItem a) { return ResourceLocation.fromNamespaceAndPath(HxHAdventure.MOD_ID, "animations/shotgun_appear.animation.json"); }
}
