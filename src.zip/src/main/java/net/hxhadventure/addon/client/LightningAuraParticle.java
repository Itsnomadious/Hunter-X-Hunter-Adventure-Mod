package net.hxhadventure.addon.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** A short-lived, full-bright blue lightning crackle that spins at random and shrinks away (Lightning Aura / Godspeed). */
public class LightningAuraParticle extends TextureSheetParticle {
    protected LightningAuraParticle(ClientLevel level, double x, double y, double z, SpriteSet sprites) {
        super(level, x, y, z, 0, 0, 0);
        this.friction = 0.96f;
        this.roll = this.random.nextFloat() * ((float) Math.PI * 2f);
        this.oRoll = this.roll;
        this.quadSize = 0.2f + this.random.nextFloat() * 0.8f;
        this.lifetime = 3 + this.random.nextInt(4);
        this.rCol = 0.4f;
        this.gCol = 0.8f;
        this.bCol = 1.0f;
        this.pickSprite(sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 15728880; // always fully lit
    }

    @Override
    public void tick() {
        super.tick();
        this.quadSize *= 0.95f;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public net.minecraft.client.particle.Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                                                     double dx, double dy, double dz) {
            return new LightningAuraParticle(level, x, y, z, this.sprites);
        }
    }
}
