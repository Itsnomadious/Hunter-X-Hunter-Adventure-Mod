package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.ChainAbilities;
import net.hxhadventure.addon.IllumiNeedles;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketNeedleSave;
import net.hxhadventure.event.ClientAbilityHandler;

/**
 * Body Alteration's "right-click someone to save their look". The ability scroll only exists on the client, so the click
 * is caught here (only while Body Alteration is the selected ability) and the target is sent to the server. Cancelling it
 * here also stops the click from opening a villager's trade screen or the like. Self-registering.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class NeedleClientEvents {
    private NeedleClientEvents() {}

    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (!e.getLevel().isClientSide() || e.getHand() != InteractionHand.MAIN_HAND) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || e.getEntity() != mc.player || !(e.getTarget() instanceof LivingEntity)) return;
        Combat c = Combat.get(mc.player);
        if (c == null || c.getCurrentKit() != IllumiNeedles.KIT) return;
        if (!bodyAlterationSelected()) return;
        AddonNetwork.sendToServer(new PacketNeedleSave(e.getTarget().getId()));
        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.SUCCESS);
    }

    /** The scroll's selected entry is only exposed by name; the base method returns the raw id and our mixin swaps in the HUD name. */
    private static boolean bodyAlterationSelected() {
        String sel = ClientAbilityHandler.getSelectedAbilityName();
        return IllumiNeedles.BODY_ID.equals(sel) || ChainAbilities.displayName(IllumiNeedles.BODY_ID).equals(sel);
    }
}
