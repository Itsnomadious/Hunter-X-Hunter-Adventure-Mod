package net.hxhadventure.addon.client;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.hxhadventure.addon.ClientAddonState;

/**
 * Client-side set of entity ids whose Nen constructs are hidden by In (fed by PacketInFx).
 * Whoever draws a Chains / Bungee Gum effect asks {@link #hiddenFrom} first: the owner always sees their own,
 * and anyone with Gyo active sees through In.
 */
public final class InFx {
    private InFx() {}

    private static final Set<Integer> HIDDEN = new HashSet<>();

    public static void set(int entityId, boolean hidden) {
        if (hidden) HIDDEN.add(entityId);
        else HIDDEN.remove(entityId);
    }

    /** True when the Nen constructs owned by this entity must not be drawn for the local player. */
    public static boolean hiddenFrom(int owner) {
        if (HIDDEN.isEmpty() || !HIDDEN.contains(owner)) return false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.getId() == owner) return false;
        return !ClientAddonState.gyo;
    }

    public static void clear() {
        HIDDEN.clear();
    }
}
