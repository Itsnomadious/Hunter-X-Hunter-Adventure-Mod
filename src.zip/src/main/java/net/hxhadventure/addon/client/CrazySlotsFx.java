package net.hxhadventure.addon.client;

import com.mojang.math.Axis;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.CrazySlotsTuning;
import net.hxhadventure.addon.network.PacketCrazySlotsFx;

/**
 * Arm poses (and the spin) for Crazy Slots, for everyone who can see the move (fed by PacketCrazySlotsFx):
 * WALTZ holds both arms out level in front (the blade flat at shoulder height) while the blade grows, and the user then turns once on the spot;
 * SLAM raises the staff overhead and brings it down hard.
 * Like the other arm effects it leaves the caster's own first-person arm alone (the held item and the server's swing show there).
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class CrazySlotsFx {
    private CrazySlotsFx() {}

    private static final class Fx {
        final int kind;
        final boolean left;
        final double t0;
        final double life;

        Fx(int kind, boolean left, double t0, double life) {
            this.kind = kind;
            this.left = left;
            this.t0 = t0;
            this.life = life;
        }
    }

    private static final Map<Integer, Fx> ACTIVE = new HashMap<>();

    public static void add(int owner, int kind, boolean left, int ticks) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        if (kind == PacketCrazySlotsFx.STOP) {
            ACTIVE.remove(owner);
            return;
        }
        ACTIVE.put(owner, new Fx(kind, left, level.getGameTime(), ticks));
    }

    private static double age(Fx fx) {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? -1 : mc.level.getGameTime() + mc.getFrameTime() - fx.t0;
    }

    public static void applyArm(PlayerModel<?> model, LivingEntity entity) {
        if (ACTIVE.isEmpty() || !(entity instanceof AbstractClientPlayer p)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || (p == mc.player && mc.options.getCameraType().isFirstPerson())) return;
        Fx fx = ACTIVE.get(p.getId());
        if (fx == null) return;
        double age = age(fx);
        if (age < 0) return;
        if (age > fx.life + 2) {
            ACTIVE.remove(p.getId());
            return;
        }
        float w = (float) Mth.clamp(Math.min(age / 3.0, (fx.life + 2 - age) / 3.0), 0, 1); // ease in and out

        if (fx.kind == PacketCrazySlotsFx.SLAM) {
            var arm = fx.left ? model.leftArm : model.rightArm;
            float p01 = (float) Mth.clamp(age / fx.life, 0, 1);
            // up for the first 70 %, then down fast
            float target = p01 < 0.7f ? Mth.lerp(p01 / 0.7f, -0.4f, -3.1f) : Mth.lerp((p01 - 0.7f) / 0.3f, -3.1f, -0.15f);
            arm.xRot = Mth.lerp(w, arm.xRot, target);
            arm.yRot = Mth.lerp(w, arm.yRot, 0f);
            arm.zRot = Mth.lerp(w, arm.zRot, 0f);
            if (fx.left) model.leftSleeve.copyFrom(model.leftArm);
            else model.rightSleeve.copyFrom(model.rightArm);
            return;
        }

        // WALTZ
        double enlarge = CrazySlotsTuning.WALTZ_ENLARGE_TICKS;
        if (age < enlarge) { // the blade grows: both arms out level in front, the shaft pointing forward with the blade flat at shoulder height
            model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, -1.5f);
            model.leftArm.xRot = Mth.lerp(w, model.leftArm.xRot, -1.5f);
            model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, -0.35f);
            model.leftArm.yRot = Mth.lerp(w, model.leftArm.yRot, 0.35f);
        } else { // the turn: both arms out level in front, the blade swept around
            model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, -1.5f);
            model.leftArm.xRot = Mth.lerp(w, model.leftArm.xRot, -1.5f);
            model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, -0.35f);
            model.leftArm.yRot = Mth.lerp(w, model.leftArm.yRot, 0.35f);
        }
        model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, 0f);
        model.leftArm.zRot = Mth.lerp(w, model.leftArm.zRot, 0f);
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);
    }

    /** During the turn of Silent Waltz the whole body spins once around its vertical axis. */
    private static float spinDegrees(AbstractClientPlayer p) {
        Fx fx = ACTIVE.get(p.getId());
        if (fx == null || fx.kind != PacketCrazySlotsFx.WALTZ) return 0f;
        double age = age(fx);
        double start = CrazySlotsTuning.WALTZ_ENLARGE_TICKS;
        double spin = CrazySlotsTuning.WALTZ_SPIN_TICKS;
        if (age < start || age > start + spin) return 0f;
        return (float) ((age - start) / spin * 360.0);
    }

    @SubscribeEvent
    public static void onRenderPre(RenderPlayerEvent.Pre e) {
        // always push (and pop in onRenderPost): the entries of ACTIVE can change while the player is being drawn
        e.getPoseStack().pushPose();
        if (ACTIVE.isEmpty() || !(e.getEntity() instanceof AbstractClientPlayer p)) return;
        float deg = spinDegrees(p);
        if (deg != 0f) e.getPoseStack().mulPose(Axis.YP.rotationDegrees(deg));
    }

    @SubscribeEvent
    public static void onRenderPost(RenderPlayerEvent.Post e) {
        e.getPoseStack().popPose();
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
