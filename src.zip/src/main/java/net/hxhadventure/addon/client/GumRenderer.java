package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.Camera;
import net.minecraft.util.Mth;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.ClientAddonState;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Draws the Bungee Gum thread as a glowing pink beam like the anime's: a near-white core inside layers of pink and magenta glow
 * with slightly ragged, shimmering edges (the same soft aura look as Ten), a bright glow on the fist and another where it sticks.
 * Layers are added together (RenderType.lightning), so no texture is needed. In hides it from anyone without Gyo.
 * The same beam, thinner and mostly see-through, is the tether to a debuffed target, drawn only for someone with Gyo on.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class GumRenderer {
    private GumRenderer() {}

    /** Beam layers, outermost first: full width in blocks, then red, green, blue, alpha. */
    private static final double[][] LAYERS = {
        {0.44, 225, 60, 210, 34},
        {0.32, 235, 85, 215, 66},
        {0.21, 240, 120, 225, 115},
        {0.12, 250, 185, 240, 185},
        {0.055, 255, 238, 252, 255},
    };
    /** Glow discs on the fist and the sticking point: radius, then colour and alpha. */
    private static final double[][] GLOW = {
        {0.40, 225, 70, 210, 45},
        {0.26, 238, 120, 225, 100},
        {0.14, 255, 225, 248, 210},
    };
    private static final int SIDES = 10;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        boolean tethers = !GumFx.tethers().isEmpty(); // the tether is only visible with Gyo, and always to the user who made it
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || (GumFx.threads().isEmpty() && !tethers && GumFx.binds().isEmpty())) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        double time = level.getGameTime() + pt;
        Camera camera = e.getCamera();
        Vec3 cam = camera.getPosition();
        PoseStack ps = e.getPoseStack();
        Matrix4f m = ps.last().pose();
        Vector3f l = camera.getLeftVector();
        Vector3f u = camera.getUpVector();
        Vec3 left = new Vec3(l.x(), l.y(), l.z());
        Vec3 up = new Vec3(u.x(), u.y(), u.z());
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.lightning();
        VertexConsumer vc = buf.getBuffer(type);

        for (Map.Entry<Integer, GumFx.Strand> en : GumFx.threads().entrySet()) {
            int casterId = en.getKey();
            if (InFx.hiddenFrom(casterId)) continue; // In: invisible unless you have Gyo
            Entity caster = level.getEntity(casterId);
            if (caster == null || caster.isRemoved() || caster.isInvisible()) continue;
            Vec3 end = GumFx.endOf(level, en.getValue(), pt);
            if (end == null) continue;
            Vec3 hand = GumFx.handOf(mc, camera, caster, end, pt);
            if (hand.distanceToSqr(end) < 0.01) continue;
            beam(m, vc, hand.subtract(cam), end.subtract(cam), time, casterId * 1.7, 1.0, 1.0);
            for (double[] g : GLOW) {
                disc(m, vc, hand.subtract(cam), left, up, g[0] * (1 + 0.12 * Math.sin(time * 0.8)), (int) g[1], (int) g[2], (int) g[3], (int) g[4]);
                disc(m, vc, end.subtract(cam), left, up, g[0] * 0.8 * (1 + 0.15 * Math.sin(time * 0.9 + 1)), (int) g[1], (int) g[2], (int) g[3], (int) (g[4] * 0.8));
            }
        }
        if (tethers) { // the tether: the same thread, thinner and see-through, from the user to each tethered target
            for (Map.Entry<Integer, GumFx.Tether> en : GumFx.tethers().entrySet()) {
                Entity victim = level.getEntity(en.getKey());
                Entity caster = level.getEntity(en.getValue().caster);
                if (victim == null || caster == null || victim.isRemoved() || caster.isRemoved()) continue;
                if (!ClientAddonState.gyo && en.getValue().caster != mc.player.getId()) continue;
                Vec3 a = caster.getPosition(pt).add(0, caster.getBbHeight() * 0.5, 0);
                Vec3 b = victim.getPosition(pt).add(0, victim.getBbHeight() * 0.5, 0);
                if (a.distanceToSqr(b) < 1.0) continue;
                beam(m, vc, a.subtract(cam), b.subtract(cam), time, en.getKey() * 0.9, 0.3, 0.55);
            }
        }
        // Bungee Bind: the same glowing gum strands, tied to the captive's hands and feet and pulled out to the ground (visible to everyone)
        if (!GumFx.binds().isEmpty()) {
            Iterator<Map.Entry<Integer, Double>> bi = GumFx.binds().entrySet().iterator();
            while (bi.hasNext()) {
                Map.Entry<Integer, Double> be = bi.next();
                Entity victim = level.getEntity(be.getKey());
                if (be.getValue() < level.getGameTime() || victim == null || victim.isRemoved()) {
                    if (victim == null || victim.isRemoved() || be.getValue() < level.getGameTime()) bi.remove();
                    continue;
                }
                bindStrands(m, vc, victim, cam, left, up, pt, time);
            }
        }
        buf.endBatch(type);
    }

    /** Four strands, one from each limb: the hands out to the sides and the feet out front and back, each pinned to the ground by a blob of gum. */
    private static void bindStrands(Matrix4f m, VertexConsumer vc, Entity v, Vec3 cam, Vec3 left, Vec3 up, float pt, double time) {
        double yaw = Math.toRadians(v instanceof LivingEntity le ? Mth.rotLerp(pt, le.yBodyRotO, le.yBodyRot) : v.getYRot());
        Vec3 fwd = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
        Vec3 side = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 p = v.getPosition(pt);
        double w = v.getBbWidth() * 0.5;
        double h = v.getBbHeight();
        double pulse = 1.0 + 0.08 * Math.sin(time * 0.6);
        for (int i = 0; i < 4; i++) {
            boolean hand = i < 2;
            double s = (i & 1) == 0 ? 1.0 : -1.0;
            Vec3 limb = hand ? p.add(side.scale(s * (w + 0.1))).add(0, h * 0.42, 0)
                             : p.add(side.scale(s * w * 0.45)).add(0, 0.12, 0);
            Vec3 anchor = hand ? p.add(side.scale(s * (w + 1.5 * pulse))).add(fwd.scale(0.2)).add(0, 0.05, 0)
                               : p.add(side.scale(s * (w + 0.5))).add(fwd.scale(s * 1.4 * pulse)).add(0, 0.05, 0);
            beam(m, vc, limb.subtract(cam), anchor.subtract(cam), time, v.getId() * 1.3 + i, 1.0, 0.7);
            for (double[] g : GLOW) {
                disc(m, vc, limb.subtract(cam), left, up, g[0] * 0.7, (int) g[1], (int) g[2], (int) g[3], (int) (g[4] * 0.8));
                disc(m, vc, anchor.subtract(cam), left, up, g[0] * 0.9 * pulse, (int) g[1], (int) g[2], (int) g[3], (int) g[4]);
            }
        }
    }

    /** The thread from a to b (camera-relative), as stacked ribbons that always face the camera. */
    private static void beam(Matrix4f m, VertexConsumer vc, Vec3 a, Vec3 b, double time, double seed, double alpha, double widthScale) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        int n = (int) Math.max(3, Math.min(90, Math.ceil(len / 0.35) + 1));
        Vec3 dir = d.scale(1.0 / len);
        Vec3[] pts = new Vec3[n];
        for (int i = 0; i < n; i++) {
            double f = i / (double) (n - 1);
            // a faint ripple so it reads as a stretched, springy strand rather than a rigid rod
            double rip = 0.05 * Math.sin(f * Math.PI) * Math.sin(time * 0.55 + f * 10.0 + seed);
            pts[i] = a.add(d.scale(f)).add(0, rip, 0);
        }
        for (int k = 0; k < LAYERS.length; k++) {
            double[] L = LAYERS[k];
            ribbon(m, vc, pts, L[0] * widthScale, time, seed + k * 2.1, (int) L[1], (int) L[2], (int) L[3], (int) Math.max(1, L[4] * alpha));
        }
    }

    private static void ribbon(Matrix4f m, VertexConsumer vc, Vec3[] p, double width, double time, double phase, int r, int g, int b, int a) {
        int n = p.length;
        Vec3[] lo = new Vec3[n];
        Vec3[] hi = new Vec3[n];
        for (int i = 0; i < n; i++) {
            Vec3 t = i == 0 ? p[1].subtract(p[0]) : i == n - 1 ? p[i].subtract(p[i - 1]) : p[i + 1].subtract(p[i - 1]);
            Vec3 side = t.cross(p[i]); // p[i] is camera-relative, so it is the view direction: the ribbon faces the camera
            side = side.lengthSqr() < 1.0e-8 ? new Vec3(0, 1, 0) : side.normalize();
            double f = i / (double) (n - 1);
            double jag = 1.0 + 0.26 * Math.sin(time * 0.9 + i * 1.7 + phase) + 0.15 * Math.sin(time * 2.3 + i * 3.1 + phase * 2.0);
            double w = width * 0.5 * (1.0 - 0.2 * f) * jag;
            lo[i] = p[i].add(side.scale(w));
            hi[i] = p[i].subtract(side.scale(w));
        }
        for (int i = 0; i < n - 1; i++) {
            vertex(m, vc, lo[i], r, g, b, a);
            vertex(m, vc, hi[i], r, g, b, a);
            vertex(m, vc, hi[i + 1], r, g, b, a);
            vertex(m, vc, lo[i + 1], r, g, b, a);
        }
    }

    /** A round glow facing the camera. */
    private static void disc(Matrix4f m, VertexConsumer vc, Vec3 c, Vec3 left, Vec3 up, double radius, int r, int g, int b, int a) {
        Vec3 prev = c.add(left.scale(radius));
        for (int k = 1; k <= SIDES; k++) {
            double th = 2 * Math.PI * k / SIDES;
            Vec3 cur = c.add(left.scale(Math.cos(th) * radius)).add(up.scale(Math.sin(th) * radius));
            vertex(m, vc, c, r, g, b, a);
            vertex(m, vc, prev, r, g, b, a);
            vertex(m, vc, cur, r, g, b, a);
            vertex(m, vc, c, r, g, b, a);
            prev = cur;
        }
    }

    private static void vertex(Matrix4f m, VertexConsumer vc, Vec3 p, int r, int g, int b, int a) {
        vc.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, a).endVertex();
    }
}
