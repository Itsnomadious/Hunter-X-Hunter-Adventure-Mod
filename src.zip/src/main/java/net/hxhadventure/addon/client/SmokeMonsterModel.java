package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.hxhadventure.addon.SmokeMonsterEntity;

/**
 * Deep Purple's smoke monster, redone after the anime: a smooth, faceless white humanoid with a rounded, banded head, broad
 * shoulders, a pinched waist with a belt, long jointed arms with open hands, and baggy legs ending in pointed shoes.
 * Pixel units, feet at y = 24 (the vanilla convention), exactly 32 px tall = 2 blocks (a player is 1.8), so the renderer draws it at
 * scale 1. Texture sheet 64x64: assets/hxhadventure/textures/entity/smoke_monster.png (made by tools/make_smoke_textures.py;
 * the UV offsets below are the layout that script paints).
 */
public class SmokeMonsterModel<T extends SmokeMonsterEntity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("hxhadventure", "smoke_monster"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart body;
    private final ModelPart armR;
    private final ModelPart armL;
    private final ModelPart foreR;
    private final ModelPart foreL;
    private final ModelPart legR;
    private final ModelPart legL;
    private final ModelPart shinR;
    private final ModelPart shinL;

    public SmokeMonsterModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.armR = root.getChild("arm_r");
        this.armL = root.getChild("arm_l");
        this.foreR = this.armR.getChild("fore");
        this.foreL = this.armL.getChild("fore");
        this.legR = root.getChild("leg_r");
        this.legL = root.getChild("leg_l");
        this.shinR = this.legR.getChild("shin");
        this.shinL = this.legL.getChild("shin");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // head: a round dome (box plus a narrower cap) with a band around it, no face
        PartDefinition head = root.addOrReplaceChild("head",
            CubeListBuilder.create().texOffs(0, 0).addBox(-4.0f, -6.0f, -4.0f, 8.0f, 6.0f, 8.0f), PartPose.offset(0.0f, 0.0f, 0.0f));
        head.addOrReplaceChild("cap",
            CubeListBuilder.create().texOffs(32, 0).addBox(-3.0f, -2.0f, -3.0f, 6.0f, 2.0f, 6.0f), PartPose.offset(0.0f, -6.0f, 0.0f));
        head.addOrReplaceChild("band",
            CubeListBuilder.create().texOffs(0, 14).addBox(-4.5f, -3.5f, -4.5f, 9.0f, 2.0f, 9.0f), PartPose.ZERO);

        // torso: broad shoulders, pinched waist, belted hips
        PartDefinition body = root.addOrReplaceChild("body",
            CubeListBuilder.create().texOffs(0, 26).addBox(-4.5f, 0.0f, -2.5f, 9.0f, 8.0f, 5.0f), PartPose.ZERO);
        body.addOrReplaceChild("waist",
            CubeListBuilder.create().texOffs(28, 26).addBox(-3.5f, 0.0f, -2.0f, 7.0f, 2.0f, 4.0f), PartPose.offset(0.0f, 8.0f, 0.0f));
        body.addOrReplaceChild("belt",
            CubeListBuilder.create().texOffs(28, 32).addBox(-4.0f, 0.0f, -2.5f, 8.0f, 2.0f, 5.0f), PartPose.offset(0.0f, 10.0f, 0.0f));

        createArm(root, "arm_r", false, -6.0f);
        createArm(root, "arm_l", true, 6.0f);
        createLeg(root, "leg_r", false, -2.2f);
        createLeg(root, "leg_l", true, 2.2f);
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Shoulder (upper arm) with an elbow, a forearm, an open hand and three spread fingers. */
    private static void createArm(PartDefinition root, String name, boolean left, float x) {
        PartDefinition arm = root.addOrReplaceChild(name,
            CubeListBuilder.create().texOffs(0, 39).mirror(left).addBox(-1.5f, -1.0f, -1.5f, 3.0f, 5.0f, 3.0f), PartPose.offset(x, 1.5f, 0.0f));
        PartDefinition fore = arm.addOrReplaceChild("fore",
            CubeListBuilder.create().texOffs(12, 39).mirror(left).addBox(-1.5f, 0.0f, -1.5f, 3.0f, 5.0f, 3.0f), PartPose.offset(0.0f, 4.0f, 0.0f));
        PartDefinition hand = fore.addOrReplaceChild("hand",
            CubeListBuilder.create().texOffs(24, 39).mirror(left).addBox(-1.5f, 0.0f, -1.0f, 3.0f, 3.0f, 2.0f), PartPose.offset(0.0f, 5.0f, 0.0f));
        CubeListBuilder finger = CubeListBuilder.create().texOffs(34, 39).addBox(-0.5f, 0.0f, -0.5f, 1.0f, 2.0f, 1.0f);
        hand.addOrReplaceChild("finger_a", finger, PartPose.offsetAndRotation(-1.0f, 3.0f, 0.0f, 0.0f, 0.0f, 0.35f));
        hand.addOrReplaceChild("finger_b", finger, PartPose.offset(0.0f, 3.0f, 0.0f));
        hand.addOrReplaceChild("finger_c", finger, PartPose.offsetAndRotation(1.0f, 3.0f, 0.0f, 0.0f, 0.0f, -0.35f));
    }

    /** Baggy thigh, a knee, the shin and a pointed shoe. */
    private static void createLeg(PartDefinition root, String name, boolean left, float x) {
        PartDefinition leg = root.addOrReplaceChild(name,
            CubeListBuilder.create().texOffs(0, 47).mirror(left).addBox(-2.0f, 0.0f, -2.0f, 4.0f, 6.0f, 4.0f), PartPose.offset(x, 12.0f, 0.0f));
        PartDefinition shin = leg.addOrReplaceChild("shin",
            CubeListBuilder.create().texOffs(16, 47).mirror(left).addBox(-2.0f, 0.0f, -2.0f, 4.0f, 4.0f, 4.0f), PartPose.offset(0.0f, 6.0f, 0.0f));
        shin.addOrReplaceChild("foot",
            CubeListBuilder.create().texOffs(32, 47).mirror(left).addBox(-2.0f, 0.0f, -4.0f, 4.0f, 2.0f, 6.0f), PartPose.offset(0.0f, 4.0f, 0.0f));
    }

    @Override
    public void setupAnim(T mob, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        boolean crouch = mob.isCrouching();
        boolean air = !mob.onGround() && !crouch;
        float swing = limbSwing * 0.6662f;
        float cos = Mth.cos(swing) * limbSwingAmount;
        float bob = Mth.sin(ageInTicks * 0.08f) * 0.04f;

        this.root.y = 0.0f;
        this.body.xRot = 0f;
        this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;

        // walking: legs swing and the knee bends on the back-swing; arms swing against the legs, loose and slightly out
        this.legR.xRot = cos * 1.3f;
        this.legL.xRot = -cos * 1.3f;
        this.legR.yRot = 0f;
        this.legL.yRot = 0f;
        this.shinR.xRot = Math.max(0f, -cos) * 1.1f;
        this.shinL.xRot = Math.max(0f, cos) * 1.1f;
        this.armR.xRot = -cos * 1.1f - 0.15f + bob;
        this.armL.xRot = cos * 1.1f - 0.15f - bob;
        this.armR.zRot = 0.18f;
        this.armL.zRot = -0.18f;
        this.armR.yRot = 0f;
        this.armL.yRot = 0f;
        this.foreR.xRot = -0.5f - Math.max(0f, cos) * 0.6f;
        this.foreL.xRot = -0.5f - Math.max(0f, -cos) * 0.6f;

        if (air) {
            // leaping: arms flung wide and back, one knee up and the other leg trailing
            this.armR.xRot = 0.3f;
            this.armL.xRot = -0.9f;
            this.armR.zRot = 1.2f;
            this.armL.zRot = -1.5f;
            this.foreR.xRot = -0.3f;
            this.foreL.xRot = -0.5f;
            this.legR.xRot = -1.1f;
            this.shinR.xRot = 1.3f;
            this.legL.xRot = 0.5f;
            this.shinL.xRot = 0.5f;
            this.body.xRot = 0.1f;
        }

        if (this.attackTime > 0f) {
            // both arms swing up and over in a wide arc
            float s = Mth.sin(this.attackTime * Mth.PI);
            this.armR.xRot = -0.4f - s * 2.2f;
            this.armL.xRot = -0.4f - s * 2.2f;
            this.armR.zRot = 0.3f;
            this.armL.zRot = -0.3f;
            this.foreR.xRot = -0.2f - s * 0.4f;
            this.foreL.xRot = -0.2f - s * 0.4f;
            this.body.xRot = s * 0.25f;
        }

        if (crouch) {
            // kneeling on one knee like the anime shot: front foot flat, back knee down, arms flung up and out, head tilted back
            this.root.y = 5.0f;
            this.body.xRot = 0.1f;
            this.head.xRot = -0.4f;
            this.legR.xRot = -1.45f;
            this.shinR.xRot = 1.45f;
            this.legL.xRot = -0.05f;
            this.shinL.xRot = 1.55f;
            this.armR.xRot = -0.3f;
            this.armR.zRot = 1.9f;
            this.armL.xRot = -0.9f;
            this.armL.zRot = -1.4f;
            this.foreR.xRot = -0.2f;
            this.foreL.xRot = -0.6f;
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        this.root.render(pose, vc, light, overlay, r, g, b, a);
    }
}
