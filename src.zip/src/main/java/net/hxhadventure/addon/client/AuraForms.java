package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.hxhadventure.addon.AuraForm;

/** Client-side map of entity id -> aura form (fed by PacketAuraForm). */
public final class AuraForms {
    private AuraForms() {}

    private static final Map<Integer, AuraForm> FORMS = new HashMap<>();

    public static void set(int entityId, AuraForm form) {
        if (form == AuraForm.NONE) FORMS.remove(entityId);
        else FORMS.put(entityId, form);
    }

    public static AuraForm get(int entityId) {
        if (FORMS.isEmpty()) return AuraForm.NONE;
        return FORMS.getOrDefault(entityId, AuraForm.NONE);
    }

    public static void clear() {
        FORMS.clear();
    }
}
