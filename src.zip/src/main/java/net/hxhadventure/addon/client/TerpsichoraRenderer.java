package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.hxhadventure.addon.TerpsichoraEntity;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class TerpsichoraRenderer extends GeoEntityRenderer<TerpsichoraEntity> {
    public TerpsichoraRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new TerpsichoraModel());
        this.shadowRadius = 0.6f;
        addRenderLayer(new TerpsichoraThreadLayer<>(this, TerpsichoraEntity::clientOwner));
    }
}
