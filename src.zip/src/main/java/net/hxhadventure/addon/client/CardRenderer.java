package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Map;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Draws the thrown Playing Cards as real cards that tumble as they fly: one side shows an ace (hearts, clubs, diamonds or spades, by card),
 * the other side the blue or red card back, all from the textures under textures/entity/gum_card_*.png, with a faint pink glow behind.
 * In hides them from anyone without Gyo, like the rest of Bungee Gum.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class CardRenderer {
    private CardRenderer() {}

    private static final double HALF_LEN = 0.27;   // along the flight path (a card is 2:3)
    private static final double HALF_WID = 0.18;

    private static final ResourceLocation[] ACES = {
        tex("gum_card_ace_hearts"), tex("gum_card_ace_clubs"), tex("gum_card_ace_diamonds"), tex("gum_card_ace_spades")
    };
    private static final ResourceLocation[] BACKS = { tex("gum_card_back_blue"), tex("gum_card_back_red") };

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/" + name + ".png");
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || CardFx.all().isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        double time = level.getGameTime() + pt;
        Camera camera = e.getCamera();
        Vec3 cam = camera.getPosition();
        PoseStack ps = e.getPoseStack();
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();

        // pass 1: the glow
        RenderType glowType = RenderType.lightning();
        VertexConsumer glow = buf.getBuffer(glowType);
        for (Map.Entry<Integer, Map<Integer, CardFx.Card>> owner : CardFx.all().entrySet()) {
            if (InFx.hiddenFrom(owner.getKey())) continue;
            for (Map.Entry<Integer, CardFx.Card> en : owner.getValue().entrySet()) {
                Axes a = axes(en.getValue(), time, cam, en.getKey());
                if (a == null) continue;
                quad(m, glow, a.p, a.dir, a.side, HALF_LEN * 1.5, HALF_WID * 1.6, 235, 90, 215, 34);
            }
        }
        buf.endBatch(glowType);

        // pass 2: the two faces of every card
        for (Map.Entry<Integer, Map<Integer, CardFx.Card>> owner : CardFx.all().entrySet()) {
            if (InFx.hiddenFrom(owner.getKey())) continue;
            for (Map.Entry<Integer, CardFx.Card> en : owner.getValue().entrySet()) {
                int id = en.getKey();
                Axes a = axes(en.getValue(), time, cam, id);
                if (a == null) continue;
                Vec3 off = a.face.scale(0.004);
                // flipped round: the card back is on the leading face, the ace on the other
                textured(m, n, buf.getBuffer(RenderType.entityCutoutNoCull(BACKS[(id >> 2) & 1])), a.p.add(off), a.dir, a.side, a.face);
                textured(m, n, buf.getBuffer(RenderType.entityCutoutNoCull(ACES[id & 3])), a.p.subtract(off), a.dir, a.side.scale(-1), a.face.scale(-1));
            }
        }
        for (ResourceLocation t : ACES) buf.endBatch(RenderType.entityCutoutNoCull(t));
        for (ResourceLocation t : BACKS) buf.endBatch(RenderType.entityCutoutNoCull(t));
    }

    /** A card's position and its three axes: along its flight, across it, and its face normal. */
    private record Axes(Vec3 p, Vec3 dir, Vec3 side, Vec3 face) {}

    private static Axes axes(CardFx.Card c, double time, Vec3 cam, int id) {
        double f = Mth.clamp(time - c.t0, 0.0, 1.0);
        Vec3 p = c.prev.lerp(c.cur, f).subtract(cam);
        if (p.lengthSqr() > 160 * 160) return null;
        Vec3 dir = c.vel.lengthSqr() < 1.0e-4 ? new Vec3(0, 1, 0) : c.vel.normalize();
        Vec3 toCam = p.scale(-1);
        Vec3 side0 = dir.cross(toCam);
        side0 = side0.lengthSqr() < 1.0e-8 ? new Vec3(1, 0, 0) : side0.normalize();
        Vec3 face0 = dir.cross(side0).normalize();
        double th = time * 0.7 + id * 1.3; // the tumble: the card turns about its flight path, sometimes edge-on
        Vec3 side = side0.scale(Math.cos(th)).add(face0.scale(Math.sin(th)));
        Vec3 face = side.cross(dir).normalize();
        return new Axes(p, dir, side, face);
    }

    /** One textured face: the top of the picture is towards the direction of flight, its left edge on the -side. */
    private static void textured(Matrix4f m, Matrix3f n, VertexConsumer vc, Vec3 p, Vec3 dir, Vec3 side, Vec3 face) {
        Vec3 top = dir.scale(HALF_LEN);
        Vec3 bot = dir.scale(-HALF_LEN);
        Vec3 l = side.scale(-HALF_WID);
        Vec3 r = side.scale(HALF_WID);
        tv(m, n, vc, p.add(top).add(l), 0f, 0f, face);
        tv(m, n, vc, p.add(bot).add(l), 0f, 1f, face);
        tv(m, n, vc, p.add(bot).add(r), 1f, 1f, face);
        tv(m, n, vc, p.add(top).add(r), 1f, 0f, face);
    }

    private static void tv(Matrix4f m, Matrix3f n, VertexConsumer vc, Vec3 p, float u, float v, Vec3 normal) {
        vc.vertex(m, (float) p.x, (float) p.y, (float) p.z)
            .color(255, 255, 255, 255)
            .uv(u, v)
            .overlayCoords(OverlayTexture.NO_OVERLAY)
            .uv2(LightTexture.FULL_BRIGHT)
            .normal(n, (float) normal.x, (float) normal.y, (float) normal.z)
            .endVertex();
    }

    private static void quad(Matrix4f m, VertexConsumer vc, Vec3 p, Vec3 dir, Vec3 side, double hl, double hw, int r, int g, int b, int a) {
        v(m, vc, p.add(dir.scale(hl)).add(side.scale(hw)), r, g, b, a);
        v(m, vc, p.add(dir.scale(hl)).subtract(side.scale(hw)), r, g, b, a);
        v(m, vc, p.subtract(dir.scale(hl)).subtract(side.scale(hw)), r, g, b, a);
        v(m, vc, p.subtract(dir.scale(hl)).add(side.scale(hw)), r, g, b, a);
    }

    private static void v(Matrix4f m, VertexConsumer vc, Vec3 p, int r, int g, int b, int a) {
        vc.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, a).endVertex();
    }
}
