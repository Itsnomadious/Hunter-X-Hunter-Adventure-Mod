package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;

/**
 * Client-side: enemies a Dowsing Chain has wrapped an invisible chain round (hit while In was on), victim entity id -> owner entity id
 * (fed by PacketChainMark). They are drawn only for the owner and for anyone with Gyo active (see ChainRenderer.drawMarks).
 */
public final class ChainMarks {
    private ChainMarks() {}

    private static final Map<Integer, Integer> MARKS = new HashMap<>();

    public static void set(int victim, int owner, boolean on) {
        if (on) MARKS.put(victim, owner);
        else MARKS.remove(victim);
    }

    public static boolean isEmpty() {
        return MARKS.isEmpty();
    }

    static Map<Integer, Integer> all() {
        return MARKS;
    }

    public static void clear() {
        MARKS.clear();
    }
}
