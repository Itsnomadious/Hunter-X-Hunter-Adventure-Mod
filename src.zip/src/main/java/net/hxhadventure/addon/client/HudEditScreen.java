package net.hxhadventure.addon.client;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.hxhadventure.abilities.Combat;

/** Opened with V: click and drag the HUD panel to reposition it. The position is saved when you let go. */
public class HudEditScreen extends Screen {
    private boolean dragging;
    private int grabDx, grabDy;

    public HudEditScreen() {
        super(Component.literal("Move HUD"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        addRenderableWidget(new HudSlider(cx - 105, this.height - 80, 100, "Size", 0.5, 2.0, HudLayout.scale(),
            v -> HudLayout.scale = (float) v, v -> Math.round(v * 100) + "%"));
        addRenderableWidget(new HudSlider(cx + 5, this.height - 80, 100, "Opacity", 0.0, 1.0, HudLayout.opacity(),
            v -> HudLayout.opacity = (float) v, v -> Math.round(v * 100) + "%"));
        addRenderableWidget(Button.builder(Component.literal("Reset"), b -> { HudLayout.reset(); this.rebuildWidgets(); })
            .bounds(cx - 85, this.height - 32, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
            .bounds(cx + 5, this.height - 32, 80, 20).build());
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private List<HudPanel.Line> lines() {
        Combat c = Combat.get(Minecraft.getInstance().player);
        List<HudPanel.Line> real = c == null ? List.of() : HudPanel.lines(Minecraft.getInstance(), c);
        return real.isEmpty() ? HudPanel.sample() : real;
    }

    private int px(List<HudPanel.Line> l) { return HudLayout.x(this.width, HudPanel.width(this.font, l)); }
    private int py(List<HudPanel.Line> l) { return HudLayout.y(this.height, HudPanel.height(l)); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        g.drawCenteredString(this.font, "Click and drag the panel to move it. Use the sliders to change its size and opacity", this.width / 2, 14, 0xFFFFFF);
        g.drawCenteredString(this.font, "V or Esc to finish", this.width / 2, 26, 0xAAAAAA);
        List<HudPanel.Line> l = lines();
        int x = px(l), y = py(l);
        boolean hover = mouseX >= x && mouseX < x + HudPanel.width(this.font, l)
            && mouseY >= y && mouseY < y + HudPanel.height(l);
        HudPanel.draw(g, this.font, x, y, l, hover || dragging);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button == 0) {
            List<HudPanel.Line> l = lines();
            int x = px(l), y = py(l);
            if (mx >= x && mx < x + HudPanel.width(this.font, l) && my >= y && my < y + HudPanel.height(l)) {
                dragging = true;
                grabDx = (int) mx - x;
                grabDy = (int) my - y;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            List<HudPanel.Line> l = lines();
            HudLayout.setPos((int) mx - grabDx, (int) my - grabDy, this.width, this.height,
                HudPanel.width(this.font, l), HudPanel.height(l));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging && button == 0) {
            dragging = false;
            HudLayout.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (AddonKeys.HUD_EDIT.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    /** A labelled slider over [min, max] that writes straight into HudLayout and saves when released. */
    private static final class HudSlider extends AbstractSliderButton {
        private final String label;
        private final double min, max;
        private final java.util.function.DoubleConsumer setter;
        private final java.util.function.DoubleFunction<String> fmt;

        HudSlider(int x, int y, int w, String label, double min, double max, double current,
                  java.util.function.DoubleConsumer setter, java.util.function.DoubleFunction<String> fmt) {
            super(x, y, w, 20, Component.empty(), (current - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.setter = setter;
            this.fmt = fmt;
            updateMessage();
        }

        private double real() { return min + (max - min) * this.value; }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal(label + ": " + fmt.apply(real())));
        }

        @Override
        protected void applyValue() {
            setter.accept(real());
        }

        @Override
        public void onRelease(double mx, double my) {
            super.onRelease(mx, my);
            HudLayout.save();
        }
    }
}
