package net.hxhadventure.addon.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.hxhadventure.addon.ClientVows;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketHinaExorcise;
import net.hxhadventure.entity.client.gui.HxhUi;

/**
 * Hina's dialogue (right-click her). She asks whether you want every Nen restriction (Conditions, Limitations and Vows) removed;
 * Yes starts her ritual, which removes all of them. After that she needs an hour to recover. Drawn with HxhUi like the O menu.
 */
public class HinaScreen extends Screen {
    private static final int HALF_W = 160;
    private static final int PANEL_H = 176;

    private final int hinaId;
    private final int cooldown;
    private final boolean hasStake;

    public HinaScreen(int hinaId, int cooldownTicks, boolean hasStake) {
        super(Component.literal("Hina"));
        this.hinaId = hinaId;
        this.cooldown = cooldownTicks;
        this.hasStake = hasStake;
    }

    private int top() {
        return Math.max(12, this.height / 2 - PANEL_H / 2);
    }

    private boolean nothingSworn() {
        return ClientVows.chosen.isEmpty();
    }

    private boolean canAsk() {
        return cooldown <= 0 && !nothingSworn();
    }

    private boolean canPullStake() {
        return cooldown <= 0 && hasStake;
    }

    private String line() {
        if (cooldown > 0) {
            int mins = (int) Math.ceil(cooldown / 1200.0); // 20 ticks a second: 1200 ticks a minute
            return "I am still resting. I can help again in about " + mins + " minute" + (mins == 1 ? "" : "s") + ".";
        }
        if (nothingSworn() && hasStake) {
            return "A Stake of Retribution is wrapped round your heart. I can pull it out: every command laid on you will be lifted, "
                + "and so will the death-Vows you swore under your own stake. I will need an hour to recover afterwards.";
        }
        if (nothingSworn()) return "You have nothing sworn. There is nothing for me to lift.";
        return (hasStake ? "I can also pull the Stake of Retribution out of your heart, which lifts the death-Vows too. " : "")
            + "Do you want me to remove your Nen restrictions? Every Condition, Limitation and Vow you have sworn will be gone for good, "
            + "and so will the power they gave you. I will need an hour to recover afterwards.";
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int by = top() + PANEL_H - 36;
        if (canAsk() || canPullStake()) {
            int y = by - 24 * ((canAsk() ? 1 : 0) + (canPullStake() ? 1 : 0));
            if (canAsk()) {
                addRenderableWidget(HxhUi.button(cx - 150, y, 300, 20, "Yes, remove my restrictions", b -> {
                    AddonNetwork.sendToServer(new PacketHinaExorcise(hinaId, false));
                    onClose();
                }, true));
                y += 24;
            }
            if (canPullStake()) {
                addRenderableWidget(HxhUi.button(cx - 150, y, 300, 20, "Remove the Stake of Retribution", b -> {
                    AddonNetwork.sendToServer(new PacketHinaExorcise(hinaId, true));
                    onClose();
                }, true));
                y += 24;
            }
            addRenderableWidget(HxhUi.button(cx - 70, by, 140, 20, "No", b -> onClose(), false));
        } else {
            addRenderableWidget(HxhUi.button(cx - 70, by, 140, 20, "Goodbye", b -> onClose(), false));
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        HxhUi.backdrop(g, this.width, this.height);
        int cx = this.width / 2;
        int top = top();
        HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, PANEL_H + 8);
        HxhUi.title(g, this.font, "HINA", cx, top);
        HxhUi.subtitle(g, this.font, "Nen Exorcist", cx, top + 14);
        HxhUi.wrap(g, this.font, line(), cx - 148, top + 36, 296, cooldown > 0 ? HxhUi.RED : HxhUi.TEXT_DIM);
        super.render(g, mouseX, mouseY, partial);
    }
}
