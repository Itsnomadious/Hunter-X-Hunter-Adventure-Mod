package net.hxhadventure.addon.client;

import java.util.function.Function;
import java.util.function.Predicate;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

/**
 * Draws an NPC with the vanilla player model (the same one players use), so it moves exactly like a player: the same walk / run swing,
 * arm bob, head turn, sneak pose and punch swing, and it holds and wears items the way a player does. Skins use the normal 64x64 player layout,
 * wide or slim arms (picked per NPC), with the jacket / sleeve / hat overlays.
 */
public class NpcPlayerRenderer<T extends Mob> extends HumanoidMobRenderer<T, NpcModel<T>> {
    private final NpcModel<T> wide;
    private final NpcModel<T> slim;
    private final Function<T, ResourceLocation> texture;
    private final Predicate<T> isSlim;

    public NpcPlayerRenderer(EntityRendererProvider.Context ctx, Function<T, ResourceLocation> texture, Predicate<T> isSlim) {
        super(ctx, new NpcModel<T>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
        this.wide = this.model;
        this.slim = new NpcModel<T>(ctx.bakeLayer(ModelLayers.PLAYER_SLIM), true);
        this.texture = texture;
        this.isSlim = isSlim;
        this.addLayer(new HumanoidArmorLayer<T, NpcModel<T>, HumanoidModel<T>>(this,
            new HumanoidModel<T>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
            new HumanoidModel<T>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
            ctx.getModelManager()));
    }

    public static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/" + name + ".png");
    }

    @Override
    public void render(T mob, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        this.model = isSlim.test(mob) ? slim : wide;
        this.model.crouching = mob.isCrouching();
        this.model.rightArmPose = mob.getMainHandItem().isEmpty() ? HumanoidModel.ArmPose.EMPTY : HumanoidModel.ArmPose.ITEM;
        this.model.leftArmPose = mob.getOffhandItem().isEmpty() ? HumanoidModel.ArmPose.EMPTY : HumanoidModel.ArmPose.ITEM;
        super.render(mob, yaw, partialTick, pose, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(T mob) {
        return texture.apply(mob);
    }

    /** Vanilla draws every player at 15/16 scale (that is what makes a player 1.8 tall); an NPC with the same model must match it. */
    @Override
    protected void scale(T mob, PoseStack pose, float partialTick) {
        pose.scale(0.9375f, 0.9375f, 0.9375f);
    }

    /** Sneaking players are drawn a little lower. */
    @Override
    public Vec3 getRenderOffset(T mob, float partialTick) {
        return mob.isCrouching() ? new Vec3(0.0, -0.125, 0.0) : super.getRenderOffset(mob, partialTick);
    }
}
