package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Moves the caster's arms with the chain ability that is playing (read from ChainFx.ACTIVE, so it works for
 * every player who can see the cast, not just the caster):
 *  - Dowsing Chain: the arm swings (left to right, or mirrored) through the same arc the chain draws, then draws back as it reels in.
 *  - Chain Jail / Holy Chain on an ally: the right arm reaches out and holds on the target.
 *  - Holy Chain on yourself: the left arm goes straight out, the right hand reaches across to just under it (see HolyWrap).
 * The same pose also tells ChainRenderer where the hand is, so the chains leave the fingertips.
 */
public final class ChainArm {
    private ChainArm() {}

    /** Shoulder to hand, blocks (HolyWrap.ARM_LEN is the same number). */
    private static final double ARM_REACH = HolyWrap.ARM_LEN;
    /** Ticks to raise the arm at the start and lower it at the end. */
    private static final float BLEND_TICKS = 1.5f;

    public static final class Pose {
        /** Right arm: direction it points, and its shoulder. */
        public final Vec3 dir, shoulder;
        /** Left arm (Holy Chain on yourself only, else null). */
        public final Vec3 leftDir, leftShoulder;
        public final float yawDeg, pitchRad, leftYawDeg, leftPitchRad, bodyYawDeg, weight;
        public final boolean jail;

        Pose(Vec3 dir, Vec3 shoulder, Vec3 leftDir, Vec3 leftShoulder, float bodyYawDeg, float weight, boolean jail) {
            this.dir = dir;
            this.shoulder = shoulder;
            this.leftDir = leftDir;
            this.leftShoulder = leftShoulder;
            this.yawDeg = yawOf(dir);
            this.pitchRad = pitchOf(dir);
            this.leftYawDeg = leftDir == null ? 0f : yawOf(leftDir);
            this.leftPitchRad = leftDir == null ? 0f : pitchOf(leftDir);
            this.bodyYawDeg = bodyYawDeg;
            this.weight = weight;
            this.jail = jail;
        }

        /** World position of the right hand. */
        public Vec3 hand() {
            return shoulder.add(dir.scale(ARM_REACH));
        }

        /** World position of the left hand, or null. */
        public Vec3 leftHand() {
            return leftDir == null ? null : leftShoulder.add(leftDir.scale(ARM_REACH));
        }
    }

    private static float yawOf(Vec3 d) {
        return (float) (Mth.atan2(-d.x, d.z) * (180.0 / Math.PI));
    }

    private static float pitchOf(Vec3 d) {
        return (float) -Math.asin(Mth.clamp(d.y, -1.0, 1.0));
    }

    /** The arm pose for this caster right now, or null if none of their chain abilities is playing. */
    public static Pose of(Entity caster, float pt) {
        if (ChainFx.ACTIVE.isEmpty()) return null;
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return null;

        ChainFx.Fx fx = null;
        for (int i = ChainFx.ACTIVE.size() - 1; i >= 0; i--) {
            ChainFx.Fx f = ChainFx.ACTIVE.get(i);
            if (f.caster == caster.getId() && f.kind != ChainFx.Kind.JAIL_END) {
                fx = f;
                break;
            }
        }
        if (fx == null) return null;
        float age = Math.max(0f, (level.getGameTime() - fx.start) + pt);
        if (age >= fx.duration) return null;

        float bodyYaw = caster instanceof LivingEntity le ? Mth.rotLerp(pt, le.yBodyRotO, le.yBodyRot) : caster.getYRot();
        double rad = Math.toRadians(bodyYaw);
        Vec3 forward = new Vec3(-Math.sin(rad), 0, Math.cos(rad));
        Vec3 right = new Vec3(-Math.cos(rad), 0, -Math.sin(rad));
        Vec3 shoulder = caster.getPosition(pt).add(right.scale(0.3)).add(0, caster.isCrouching() ? 1.15 : 1.38, 0);

        Vec3 dir;
        Vec3 leftDir = null, leftShoulder = null;
        switch (fx.kind) {
            case SWEEP -> {
                double ang = ChainFx.sweepAngle(age, ChainFx.sweepSwing(fx), 0.0);
                double cos = Math.cos(ang), sin = Math.sin(ang);
                double[] f = ChainFx.liveForward(fx, caster, pt), sd = ChainFx.sweepSide(fx, f);
                dir = new Vec3(f[0] * cos + sd[0] * sin, f[1] * cos + sd[1] * sin, f[2] * cos + sd[2] * sin);
            }
            case HOLY, JAIL, JUDGMENT -> { // JUDGMENT: the arm points at the target, like Chain Jail
                Entity t = level.getEntity(fx.target);
                if (t == null) return null;
                if (t == caster && fx.kind == ChainFx.Kind.HOLY) {
                    // Holy Chain on yourself: the left arm goes straight out and the chain (from the right thumb) winds round it
                    Vec3 left = right.scale(-1);
                    leftShoulder = caster.getPosition(pt).add(left.scale(0.3)).add(0, caster.isCrouching() ? 1.15 : 1.38, 0);
                    leftDir = forward.add(left.scale(0.08)).normalize(); // straight out in front
                    // the right hand reaches across to just under the left arm: that is where the chain starts (from its thumb)
                    dir = HolyWrap.holdPoint(HolyWrap.frame(leftShoulder, leftDir, bodyYaw), shoulder).subtract(shoulder);
                } else if (t == caster) {
                    return null;
                } else {
                    dir = t.getPosition(pt).add(0, t.getBbHeight() * 0.5, 0).subtract(shoulder);
                }
            }
            default -> {
                return null;
            }
        }
        if (dir.lengthSqr() < 1e-6) return null;
        dir = dir.normalize();

        float w = Mth.clamp(Math.min(age / BLEND_TICKS, (fx.duration - age) / BLEND_TICKS), 0f, 1f);
        w = w * w * (3f - 2f * w);
        return new Pose(dir, shoulder, leftDir, leftShoulder, bodyYaw, w, fx.kind == ChainFx.Kind.JAIL);
    }

    /** The pose while this caster is wrapping the Holy Chain round their own left arm, else null. */
    public static Pose holySelf(Entity caster, float pt) {
        Pose p = of(caster, pt);
        return p != null && p.leftDir != null ? p : null;
    }

    /** Called at the end of PlayerModel.setupAnim (see PlayerModelMixin): overrides the right arm. */
    public static void apply(PlayerModel<?> model, LivingEntity entity, float ageInTicks) {
        if (!(entity instanceof AbstractClientPlayer p) || ChainFx.ACTIVE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        // First person draws the hand through its own setupAnim call; leave that one alone.
        if (p == mc.player && mc.options.getCameraType().isFirstPerson()) return;
        if (p.isSleeping() || p.isFallFlying() || p.isVisuallySwimming() || p.isSpectator()) return;

        Pose pose = of(p, mc.getFrameTime());
        if (pose == null || pose.weight <= 0f) return;

        float w = pose.weight;
        float tx = -Mth.HALF_PI + pose.pitchRad + (p.isCrouching() ? 0.4f : 0f);
        float ty = Mth.wrapDegrees(pose.yawDeg - pose.bodyYawDeg) * Mth.DEG_TO_RAD;
        if (pose.jail) tx += Mth.sin(ageInTicks * 0.6f) * 0.025f; // a tense tremble while holding the jail
        model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, tx);
        model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, ty);
        model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, 0f);
        model.rightSleeve.copyFrom(model.rightArm);

        if (pose.leftDir != null) {
            float lx = -Mth.HALF_PI + pose.leftPitchRad + (p.isCrouching() ? 0.4f : 0f);
            float ly = Mth.wrapDegrees(pose.leftYawDeg - pose.bodyYawDeg) * Mth.DEG_TO_RAD;
            model.leftArm.xRot = Mth.lerp(w, model.leftArm.xRot, lx);
            model.leftArm.yRot = Mth.lerp(w, model.leftArm.yRot, ly);
            model.leftArm.zRot = Mth.lerp(w, model.leftArm.zRot, 0f);
            model.leftSleeve.copyFrom(model.leftArm);
        }
    }
}
