package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Nen chain model, built in code (pixel units, 16px = 1 block):
 *  - link_flat / link_vertical: one oval chain link, 4px long, the vertical one turned 90 degrees so links interlock
 *  - tip: the spiked dagger head with a collar. Local +Z is the direction the chain points.
 *  - ball: the small steel ball on the end of the Dowsing Chain.
 *  - stake: the Judgment Chain's pointed head, the Stake of Retribution: a ring, a cross guard, a bone-shaped crossbar and a long
 *    tapering blade (about 18px long). Local +Z is the way it points; its origin is at the first guard.
 * Texture sheet is 32x16: assets/hxhadventure/textures/entity/nen_chain.png (steel) and nen_chain_holy.png (gold).
 */
public final class ChainModel {
    private ChainModel() {}

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("hxhadventure", "nen_chain"), "main");

    /** unit = a 1px cube, scaled into thin plates for the finger bands. */
    public record Parts(ModelPart flat, ModelPart vertical, ModelPart tip, ModelPart unit, ModelPart ball, ModelPart stake) {}

    private static CubeListBuilder linkCubes() {
        return CubeListBuilder.create()
            .texOffs(0, 0).addBox(-2f, -0.5f, -2f, 1f, 1f, 4f)  // left bar
            .texOffs(0, 0).addBox(1f, -0.5f, -2f, 1f, 1f, 4f)   // right bar
            .texOffs(0, 0).addBox(-1f, -0.5f, 1f, 2f, 1f, 1f)   // front cap
            .texOffs(0, 0).addBox(-1f, -0.5f, -2f, 2f, 1f, 1f); // back cap
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("link_flat", linkCubes(), PartPose.ZERO);
        root.addOrReplaceChild("link_vertical", linkCubes(), PartPose.rotation(0f, 0f, (float) Math.PI / 2f));
        root.addOrReplaceChild("tip", CubeListBuilder.create()
            .texOffs(0, 0).addBox(-1.5f, -1.5f, -1f, 3f, 3f, 1f)    // collar
            .texOffs(0, 0).addBox(-1f, -1f, 0f, 2f, 2f, 3f)         // shaft
            .texOffs(0, 0).addBox(-0.5f, -0.5f, 3f, 1f, 1f, 2f)     // taper
            .texOffs(0, 0).addBox(-0.25f, -0.25f, 5f, 0.5f, 0.5f, 1.5f), // point
            PartPose.ZERO);
        // Dowsing Chain's weight: a small steel ball (about 5.5px across, a little thicker than the 4px links), built from
        // three crossed boxes and a core so its corners are cut away and it reads as round at this size
        root.addOrReplaceChild("ball", CubeListBuilder.create()
            .texOffs(0, 0).addBox(-2.75f, -1.75f, -1.75f, 5.5f, 3.5f, 3.5f)
            .texOffs(0, 0).addBox(-1.75f, -2.75f, -1.75f, 3.5f, 5.5f, 3.5f)
            .texOffs(0, 0).addBox(-1.75f, -1.75f, -2.75f, 3.5f, 3.5f, 5.5f)
            .texOffs(0, 0).addBox(-2.3f, -2.3f, -2.3f, 4.6f, 4.6f, 4.6f),
            PartPose.ZERO);
        root.addOrReplaceChild("stake", CubeListBuilder.create()
            // ring the chain hangs from
            .texOffs(0, 0).addBox(-1.5f, -1.5f, -5f, 3f, 0.6f, 1f)
            .texOffs(0, 0).addBox(-1.5f, 0.9f, -5f, 3f, 0.6f, 1f)
            .texOffs(0, 0).addBox(-1.5f, -0.9f, -5f, 0.6f, 1.8f, 1f)
            .texOffs(0, 0).addBox(0.9f, -0.9f, -5f, 0.6f, 1.8f, 1f)
            // neck and the first, cross-shaped guard
            .texOffs(0, 0).addBox(-0.8f, -0.8f, -4f, 1.6f, 1.6f, 3f)
            .texOffs(0, 0).addBox(-2.5f, -0.7f, -1.5f, 5f, 1.4f, 1.5f)
            .texOffs(0, 0).addBox(-0.7f, -2.5f, -1.5f, 1.4f, 5f, 1.5f)
            .texOffs(0, 0).addBox(-1.4f, -1.4f, 0f, 2.8f, 2.8f, 1f)
            // the wide bone-shaped crossbar
            .texOffs(0, 0).addBox(-5f, -0.9f, 1f, 10f, 1.8f, 1.4f)
            .texOffs(0, 0).addBox(-5.6f, -1.4f, 1f, 1.2f, 2.8f, 1.4f)
            .texOffs(0, 0).addBox(4.4f, -1.4f, 1f, 1.2f, 2.8f, 1.4f)
            .texOffs(0, 0).addBox(-1.6f, -1.6f, 1f, 3.2f, 3.2f, 1.4f)
            .texOffs(0, 0).addBox(-1.4f, -1.4f, 2.4f, 2.8f, 2.8f, 1f)
            // the blade, tapering to the point
            .texOffs(0, 0).addBox(-2.6f, -0.9f, 3.4f, 5.2f, 1.8f, 3f)
            .texOffs(0, 0).addBox(-2.1f, -0.8f, 6.4f, 4.2f, 1.6f, 3f)
            .texOffs(0, 0).addBox(-1.5f, -0.7f, 9.4f, 3f, 1.4f, 3f)
            .texOffs(0, 0).addBox(-0.9f, -0.55f, 12.4f, 1.8f, 1.1f, 2.6f)
            .texOffs(0, 0).addBox(-0.4f, -0.35f, 15f, 0.8f, 0.7f, 1.8f)
            .texOffs(0, 0).addBox(-0.15f, -0.15f, 16.8f, 0.3f, 0.3f, 1.2f),
            PartPose.ZERO);
        root.addOrReplaceChild("unit", CubeListBuilder.create().texOffs(0, 0).addBox(-0.5f, -0.5f, -0.5f, 1f, 1f, 1f), PartPose.ZERO);
        return LayerDefinition.create(mesh, 32, 16);
    }

    public static Parts bake(Minecraft mc) {
        ModelPart root = mc.getEntityModels().bakeLayer(LAYER);
        return new Parts(root.getChild("link_flat"), root.getChild("link_vertical"), root.getChild("tip"), root.getChild("unit"), root.getChild("ball"), root.getChild("stake"));
    }

    private static Parts cached;

    /** Baked once and reused: baking builds the whole model tree, far too slow to repeat every frame. */
    public static Parts parts(Minecraft mc) {
        if (cached == null) cached = bake(mc);
        return cached;
    }
}
