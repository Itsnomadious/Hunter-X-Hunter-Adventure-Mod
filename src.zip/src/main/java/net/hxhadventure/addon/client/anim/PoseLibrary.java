package net.hxhadventure.addon.client.anim;

import net.hxhadventure.HxHAdventure;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import org.slf4j.Logger;

import java.io.Reader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Function;

/**
 * Every pose and animation the mod ships, loaded from assets/hxhadventure/poses and /pose_animations as a client resource
 * reload (F3+T, or /pose reload). A file with a mistake is skipped and reported in the log and in /pose list; the
 * rest still load.
 */
public final class PoseLibrary {
    private static final Logger LOGGER = LogUtils.getLogger();

    private static volatile Map<String, Pose> raw = Map.of();
    private static volatile Map<String, Pose> baked = Map.of();
    private static volatile Map<String, Animation> animations = Map.of();
    private static volatile List<String> errors = List.of();

    private PoseLibrary() {}

    /** A ready-to-use pose (wrist angles solved). Shared: copy before changing. Null if there is no such pose. */
    public static Pose pose(String name) {
        return baked.get(name);
    }

    /** The pose as authored (pitch_down not yet solved), used as the base when extending. */
    public static Pose rawPose(String name) {
        return raw.get(name);
    }

    public static Animation animation(String name) {
        return name == null ? null : animations.get(name);
    }

    public static Set<String> poseNames() {
        return new TreeSet<>(baked.keySet());
    }

    public static Set<String> animationNames() {
        return new TreeSet<>(animations.keySet());
    }

    public static List<String> errors() {
        return errors;
    }

    private record Loaded(Map<String, JsonObject> poses, Map<String, JsonObject> anims, List<String> errors) {}

    public static final class Loader extends SimplePreparableReloadListener<Loaded> {
        @Override
        protected Loaded prepare(ResourceManager manager, ProfilerFiller profiler) {
            Loaded l = new Loaded(new LinkedHashMap<>(), new LinkedHashMap<>(), new ArrayList<>());
            read(manager, "poses", l.poses(), l.errors());
            read(manager, "pose_animations", l.anims(), l.errors());
            return l;
        }

        private static void read(ResourceManager manager, String dir, Map<String, JsonObject> out, List<String> errors) {
            for (Map.Entry<ResourceLocation, net.minecraft.server.packs.resources.Resource> e
                    : manager.listResources(dir, rl -> rl.getPath().endsWith(".json")).entrySet()) {
                ResourceLocation rl = e.getKey();
                if (!HxHAdventure.MOD_ID.equals(rl.getNamespace())) continue;
                String path = rl.getPath();
                String name = path.substring(dir.length() + 1, path.length() - ".json".length());
                try (Reader r = e.getValue().openAsReader()) {
                    out.put(name, JsonParser.parseReader(r).getAsJsonObject());
                } catch (Exception ex) {
                    errors.add(dir + "/" + name + ": " + ex.getMessage());
                }
            }
        }

        @Override
        protected void apply(Loaded l, ResourceManager manager, ProfilerFiller profiler) {
            List<String> errs = new ArrayList<>(l.errors());
            Map<String, Pose> rawPoses = new HashMap<>();
            Map<String, Pose> bakedPoses = new HashMap<>();
            Deque<String> stack = new ArrayDeque<>();
            for (String name : l.poses().keySet()) {
                try {
                    Pose p = resolve(name, l.poses(), rawPoses, stack);
                    Pose b = p.copy();
                    PoseRig.bake(b);
                    bakedPoses.put(name, b);
                } catch (Exception ex) {
                    errs.add("poses/" + name + ": " + ex.getMessage());
                }
            }
            Function<String, Pose> rawLookup = n -> {
                Pose p = rawPoses.get(n);
                if (p == null) throw new IllegalArgumentException("no pose named '" + n + "'");
                return p;
            };
            Map<String, Animation> anims = new HashMap<>();
            for (Map.Entry<String, JsonObject> e : l.anims().entrySet()) {
                try {
                    anims.put(e.getKey(), Animation.fromJson(e.getValue(), rawLookup));
                } catch (Exception ex) {
                    errs.add("pose_animations/" + e.getKey() + ": " + ex.getMessage());
                }
            }
            raw = Collections.unmodifiableMap(rawPoses);
            baked = Collections.unmodifiableMap(bakedPoses);
            animations = Collections.unmodifiableMap(anims);
            errors = List.copyOf(errs);
            LOGGER.info("Pose library: {} poses, {} animations, {} errors", bakedPoses.size(), anims.size(), errs.size());
            for (String e : errs) LOGGER.error("Pose library: {}", e);
        }

        private static Pose resolve(String name, Map<String, JsonObject> json, Map<String, Pose> done, Deque<String> stack) {
            Pose p = done.get(name);
            if (p != null) return p;
            JsonObject o = json.get(name);
            if (o == null) throw new IllegalArgumentException("no pose named '" + name + "'");
            if (stack.contains(name)) throw new IllegalArgumentException("extends loop through '" + name + "'");
            stack.push(name);
            try {
                p = Pose.fromJson(o, base -> resolve(base, json, done, stack));
            } finally {
                stack.pop();
            }
            done.put(name, p);
            return p;
        }
    }
}
