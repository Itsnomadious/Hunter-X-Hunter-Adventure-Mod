package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;

/** Client-side list of the golden arrows falling in a Dragon Dive, fed by PacketDiveArrowsFx. */
public final class DiveArrowFx {
    private DiveArrowFx() {}

    public static final class Arrow {
        public final float x, startY, z, impactY, speed;
        public final long t0;

        Arrow(float x, float startY, float z, float impactY, float speed, long t0) {
            this.x = x;
            this.startY = startY;
            this.z = z;
            this.impactY = impactY;
            this.speed = speed;
            this.t0 = t0;
        }
    }

    private static final int MAX = 4000;
    public static final List<Arrow> ACTIVE = new ArrayList<>();

    public static void add(float speed, float[] data) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        long now = level.getGameTime();
        for (int i = 0; i + 3 < data.length; i += 4) {
            if (ACTIVE.size() >= MAX) break;
            ACTIVE.add(new Arrow(data[i], data[i + 1], data[i + 2], data[i + 3], speed, now));
        }
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
