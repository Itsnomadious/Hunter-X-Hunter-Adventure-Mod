package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.player.Player;
import net.hxhadventure.addon.LittleFlowerTuning;
import net.hxhadventure.entity.client.Aura.FlameAura;
import net.hxhadventure.entity.client.Aura.FlameRenderType;

/**
 * Little Flower's palm aura: Ren's flame (FlameAura, in the player's own aura colour) wrapped round the hand while the H mode is on.
 * While a palm is on someone it swells by {@link #GROW} and turns denser and brighter. The caller puts the pose at the middle of the hand
 * (with +Y the way the flame should rise); this only draws.
 */
public final class LfHandFx {
    private LfHandFx() {}

    /** Size of the flame ball round a resting hand, in blocks (a hand is about 0.25 wide; 0.17 was the first size, now 50% larger). */
    public static final float BASE_RADIUS = 0.255f;
    /** How much bigger it is at full strength (0.20 = 20%). */
    public static final float GROW = 0.20f;
    /** Opacity: resting, and at full strength (Ren's own opacity is 1; these are for a small flame close to the eye). */
    public static final float OPACITY_REST = 0.9f, OPACITY_FULL = 2.6f;
    /** How far towards white the colour is pushed at full strength. */
    public static final float BRIGHT_FULL = 0.55f;

    // ---- per-hand strength, eased so it swells and fades instead of snapping: key -> {strength, last game time}
    private static final Map<Integer, double[]> STRENGTH = new ConcurrentHashMap<>();

    public static void clear() {
        STRENGTH.clear();
    }

    /** 0..1 how strongly this hand's aura is up right now; rises quickly when a palm lands, falls more slowly when it lifts. */
    public static float strength(int entityId, boolean right, boolean touching, double now) {
        double[] s = STRENGTH.computeIfAbsent(entityId * 2 + (right ? 1 : 0), k -> new double[] {0, now});
        double dt = Math.max(0, Math.min(3, now - s[1]));
        s[1] = now;
        double target = touching ? 1 : 0;
        double rate = touching ? 0.45 : 0.18;
        s[0] += (target - s[0]) * Math.min(1, dt * rate);
        if (Math.abs(target - s[0]) < 0.002) s[0] = target;
        return (float) s[0];
    }

    /** The player's aura colour as FlameAura wants it: 0-19, the same as Ren and Ten use. */
    public static int colourIndex(Player p) {
        int id = p == null ? 0 : p.getPersistentData().getInt("HxHCraft_PermanentAuraColor");
        return id > 0 ? Math.min(id - 1, 19) : 0;
    }

    /**
     * @param strength 0..1 from {@link #strength}
     * @param progress 0..1 how far the contact has got (how close the blast is); only adds a little more brightness near the end
     * @param inside   draw both faces, as for the flame of your own first-person view
     */
    public static void draw(PoseStack ps, MultiBufferSource buf, int colour, float strength, float progress, float time, float seed, boolean inside) {
        float k = Math.max(0f, Math.min(1f, strength));
        float p = Math.max(0f, Math.min(1f, progress));
        float size = BASE_RADIUS * (1f + GROW * k);
        float opacity = OPACITY_REST + (OPACITY_FULL - OPACITY_REST) * k;
        float bright = BRIGHT_FULL * k * (0.8f + 0.2f * p);
        FlameAura.Style style = FlameAura.Style.HAND;
        ps.pushPose();
        ps.scale(size, size, size);
        ps.translate(0f, -FlameAura.bellyCentreY(style), 0f); // the middle of the ball on the middle of the hand
        VertexConsumer vc = buf.getBuffer(inside ? FlameRenderType.flameInside() : FlameRenderType.flame());
        FlameAura.draw(ps, vc, style, colour, time / 20f, seed, opacity, 1f, bright);
        ps.popPose();
    }

    /** Pulls the progress of a contact that began at {@code start} (game ticks). */
    public static float progress(long start, double now) {
        return (float) ((now - start) / (double) LittleFlowerTuning.LF_CONTACT_TICKS);
    }
}
