package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.hxhadventure.addon.ExamTakerEntity;

/** A Hunter Exam test taker with the player model and one of its 46 skins (see ExamTakerEntity#textureName). */
public class ExamTakerRenderer extends NpcPlayerRenderer<ExamTakerEntity> {
    public ExamTakerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, t -> tex(ExamTakerEntity.textureName(t.skin())), t -> ExamTakerEntity.isSlim(t.skin()));
    }
}
