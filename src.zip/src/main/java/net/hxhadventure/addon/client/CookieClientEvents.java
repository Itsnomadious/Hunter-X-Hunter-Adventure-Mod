package net.hxhadventure.addon.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.HxHEntities;

/** Registers Cookie's renderer (mod event bus, client only). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class CookieClientEvents {
    private CookieClientEvents() {}

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(HxHEntities.COOKIE.get(), CookieRenderer::new);
    }
}
