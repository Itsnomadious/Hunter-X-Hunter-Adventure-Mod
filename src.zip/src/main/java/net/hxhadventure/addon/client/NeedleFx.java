package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-side record of every head with needles in it (fed by PacketNeedleFx), keyed by entity id. */
public final class NeedleFx {
    private NeedleFx() {}

    public static final int FOREHEAD = 1, SKULL = 2, NECK = 3;
    /** Ticks for the needles to sink in / slide out. */
    public static final double BORN_TICKS = 6, DIE_TICKS = 8;

    public static final class Rec {
        public final int anchor;
        public int style;
        public double born, ended = -1;
        public int missing;

        Rec(int anchor, double born) {
            this.anchor = anchor;
            this.born = born;
        }
    }

    private static final Map<Integer, Rec> ACTIVE = new HashMap<>();

    public static Map<Integer, Rec> all() {
        return ACTIVE;
    }

    public static boolean isEmpty() {
        return ACTIVE.isEmpty();
    }

    public static void set(int anchor, int style) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        double now = level.getGameTime();
        Rec r = ACTIVE.get(anchor);
        if (style != 0) {
            if (r == null || r.ended >= 0) {
                r = new Rec(anchor, now);
                ACTIVE.put(anchor, r);
            }
            r.style = style;
        } else if (r != null && r.ended < 0) {
            r.ended = now;
        }
    }

    public static void clear() {
        ACTIVE.clear();
    }

    /** Forget everything when leaving a world. Self-registering, so no existing client event class needs editing. */
    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class NeedleClientHooks {
        private NeedleClientHooks() {}

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
            clear();
            NeedleDisguise.clear();
        }
    }
}
