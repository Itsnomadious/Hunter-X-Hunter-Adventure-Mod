package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.hxhadventure.addon.ClientAddonState;

/** Gyo: the grade of the player in the crosshair, shown just under it. */
public final class GyoInfoHud {
    private GyoInfoHud() {}

    private static String text = "";
    private static long until;

    public static void set(String t) {
        Minecraft mc = Minecraft.getInstance();
        text = t == null ? "" : t;
        until = mc.level == null ? 0 : mc.level.getGameTime() + 60;
    }

    public static void clear() {
        text = "";
        until = 0;
    }

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui || !ClientAddonState.gyo) return;
        if (text.isEmpty() || mc.level.getGameTime() > until) return;
        g.drawCenteredString(mc.font, text, width / 2, height / 2 + 16, 0xFFFFFFFF);
    };
}
