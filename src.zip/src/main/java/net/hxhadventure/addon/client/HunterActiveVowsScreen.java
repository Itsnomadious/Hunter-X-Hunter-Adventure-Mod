package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.hxhadventure.addon.ClientVows;
import net.hxhadventure.addon.Vows;

/**
 * Page 3 of the O menu: every Condition, Limitation and Vow you have sworn, grouped by the skill, attack or Hatsu it is bound to,
 * with its reward. Scrolls with the wheel or the arrow buttons.
 */
public class HunterActiveVowsScreen extends Screen {
    private static final int HALF_W = 172;
    private static final int MIN_PANEL_H = 276;
    private static final int MAX_PANEL_H = 420;
    private static final int TEXT_W = 276;
    private static final int LINE_H = 10;

    /** One drawn line: either a group header or a piece of a rule. */
    private record Line(FormattedCharSequence text, int color) {}

    private final List<Line> lines = new ArrayList<>();
    private int scroll;

    public HunterActiveVowsScreen() {
        super(Component.literal("Current Conditions, Limitations and Vows"));
    }

    private int panelH() {
        return Math.max(MIN_PANEL_H, Math.min(this.height - 16, MAX_PANEL_H));
    }

    private int top() {
        return Math.max(12, this.height / 2 - panelH() / 2 + 8);
    }

    private int viewH() {
        return panelH() - 44 - 40;
    }

    private int viewLines() {
        return Math.max(4, viewH() / LINE_H);
    }

    private int maxScroll() {
        return Math.max(0, lines.size() - viewLines());
    }

    private void build() {
        lines.clear();
        Map<String, List<Vows.Rule>> byTarget = new LinkedHashMap<>();
        for (String id : ClientVows.chosen) {
            Vows.Rule r = Vows.RULES.get(id);
            if (r != null) byTarget.computeIfAbsent(r.target(), k -> new ArrayList<>()).add(r);
        }
        for (Map.Entry<String, List<Vows.Rule>> e : byTarget.entrySet()) {
            String t = e.getKey();
            String name = Vows.isSkill(t) || Vows.isForm(t) || Vows.isAttack(t) ? Vows.label(t) : "Hatsu: " + Vows.label(t);
            lines.add(new Line(Component.literal(name.toUpperCase(java.util.Locale.ROOT)).getVisualOrderText(), HunterUi.NAVY));
            for (Vows.Kind k : Vows.Kind.values()) {
                for (Vows.Rule r : e.getValue()) {
                    if (r.kind() != k) continue;
                    int color = k == Vows.Kind.VOW ? HunterUi.RED : k == Vows.Kind.LIMITATION ? HunterUi.AMBER : HunterUi.INK;
                    List<FormattedCharSequence> parts = this.font.split(Component.literal(r.id().equals(Vows.EVERYTHING_VOW) ? r.text() : k.label + ": " + r.text()), TEXT_W);
                    for (FormattedCharSequence part : parts) lines.add(new Line(part, color));
                    for (FormattedCharSequence part : this.font.split(Component.literal("   Reward: " + r.boostText()), TEXT_W)) lines.add(new Line(part, HunterUi.GREEN));
                }
            }
            String combined = Vows.combinedText(t, ClientVows.chosen);
            if (combined != null) {
                for (FormattedCharSequence part : this.font.split(Component.literal("Combined: " + combined), TEXT_W)) lines.add(new Line(part, HunterUi.NAVY));
            }
            lines.add(new Line(FormattedCharSequence.EMPTY, 0));
        }
    }

    @Override
    protected void init() {
        build();
        scroll = Math.max(0, Math.min(scroll, maxScroll()));
        int cx = this.width / 2;
        int top = top();
        int by = top + panelH() - 44;
        HunterUi.HunterButton up = HunterUi.button(cx + 134, top + 40, 26, 16, "^", b -> {
            scroll = Math.max(0, scroll - 3);
        }, false);
        addRenderableWidget(up);
        addRenderableWidget(HunterUi.button(cx + 134, top + 40 + viewH() - 16, 26, 16, "v", b -> {
            scroll = Math.min(maxScroll(), scroll + 3);
        }, false));
        addRenderableWidget(HunterUi.button(cx - 160, by, 80, 20, "< Page 2", b -> HunterUi.go(new HunterVowsScreen()), false));
        addRenderableWidget(HunterUi.button(cx - 40, by, 80, 20, "Close", b -> onClose(), true));
        if (OMenu.licensed()) addRenderableWidget(HunterUi.button(cx + 44, by, 116, 20, "Page 4: Quests >", b -> HunterUi.go(OMenu.page(OMenu.Page.QUESTS)), false));
        OMenu.addSide(this::addRenderableWidget, this.width, top() - 8, true, OMenu.Page.ACTIVE);
}

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + (delta < 0 ? 2 : -2)));
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        HunterUi.backdrop(g, this.width, this.height);
        int cx = this.width / 2;
        int top = top();
        boolean flipping = HunterUi.flipBegin(g, cx);
        HunterUi.back(g, cx - HALF_W, top - 8, HALF_W * 2, panelH() + 10, 16);
        HunterUi.title(g, this.font, "CURRENT RESTRICTIONS", cx, top);
        int total = ClientVows.chosen.size();
        HunterUi.subtitle(g, this.font, total == 0 ? "You have not sworn anything yet." : total + " rule(s) sworn. None can be removed.", cx, top + 18);
        HunterUi.inset(g, cx - 160, top + 36, 320, viewH() + 8);
        int n = viewLines();
        for (int i = 0; i < n && scroll + i < lines.size(); i++) {
            Line l = lines.get(scroll + i);
            g.drawString(this.font, l.text(), cx - 154, top + 42 + i * LINE_H, l.color() == 0 ? 0xFFFFFFFF : l.color(), false);
        }
        super.render(g, mouseX, mouseY, partial);
        HunterUi.flipEnd(g, flipping);
    }
}
