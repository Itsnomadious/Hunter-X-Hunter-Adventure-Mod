package net.hxhadventure.addon.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.hxhadventure.addon.MagicalEsthetician;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketCookieService;
import net.hxhadventure.entity.client.gui.HxhUi;

/**
 * Cookie's menu (right-click her): Magical Spa Services or Piano Massage. Picking one sends the choice to the server, which checks everything
 * again and starts the service. Drawn with HxhUi like Hina's and the O menu.
 */
public class CookieScreen extends Screen {
    private static final int HALF_W = 170;
    private static final int PANEL_H = 196;

    private final int cookieId;

    public CookieScreen(int cookieId) {
        super(Component.literal("Cookie"));
        this.cookieId = cookieId;
    }

    private int top() {
        return Math.max(12, this.height / 2 - PANEL_H / 2);
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int by = top() + PANEL_H - 92;
        addRenderableWidget(HxhUi.button(cx - 110, by, 220, 20, "Magical Spa Services", b -> pick(MagicalEsthetician.SERVICE_SPA), true));
        addRenderableWidget(HxhUi.button(cx - 110, by + 26, 220, 20, "Piano Massage", b -> pick(MagicalEsthetician.SERVICE_PIANO), true));
        addRenderableWidget(HxhUi.button(cx - 110, by + 52, 220, 20, "Not now", b -> onClose(), false));
    }

    private void pick(int service) {
        AddonNetwork.sendToServer(new PacketCookieService(cookieId, service));
        onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        HxhUi.backdrop(g, this.width, this.height);
        int cx = this.width / 2;
        int top = top();
        HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, PANEL_H + 8);
        HxhUi.title(g, this.font, "COOKIE", cx, top);
        HxhUi.subtitle(g, this.font, "Magical Esthetician", cx, top + 14);
        String text = "Welcome! What will it be today?  Magical Spa Services: sit down while I groom your hair, "
            + "and you glow with Spa Afterglow for 30 minutes (+10% damage and durability, +0.1% per Hatsu level).  "
            + "Piano Massage: lie down for a massage, and your aura recovers 25% faster for 30 minutes (+0.1% per Hatsu level).";
        HxhUi.wrap(g, this.font, text, cx - 158, top + 34, 316, HxhUi.TEXT_DIM);
        super.render(g, mouseX, mouseY, partial);
    }
}
