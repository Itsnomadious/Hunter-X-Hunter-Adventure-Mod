package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Draws the Skill Hunter book as a real held item (first person, third person, other players' hands).
 * Used only for the hand perspectives (see models/item/skill_hunter_book.json, forge:separate_transforms);
 * inventory / ground / item frames keep the flat icon. The hinge, page flip and ribbon animations come from {@link BookRenderer}.
 * Where the book sits and how it is angled in the hand is set by the "display" blocks in models/item/skill_hunter_book_held.json.
 */
public final class BookItemRenderer extends BlockEntityWithoutLevelRenderer {
    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/skill_hunter_book.png");

    // book size inside the item frame (1.0 = 16 model pixels = one block); the JSON display scale multiplies this
    private static final float SCALE = 1.0f;
    // when closed the book turns this many degrees so its cover faces you (flip the sign if you see the spine side)
    private static final float CLOSED_YAW = -90f;
    // closed halves are pushed apart by this many pixels so the covers end up outside and the pages inside
    private static final float CLOSED_SPREAD = 2.1f;
    // sideways shift (pixels) that re-centres the book once it has turned to show its cover
    private static final float CLOSED_RECENTER = 3.75f;
    private static final float RIBBON_REST_X = 3.6f, RIBBON_START_Y = -14f;

    private BookModel.Parts parts;

    public BookItemRenderer(BlockEntityRenderDispatcher dispatcher, EntityModelSet models) {
        super(dispatcher, models);
    }

    @Override
    public void onResourceManagerReload(ResourceManager rm) {
        parts = null;
    }

    private static float easeOutBack(float t) {
        float c1 = 1.70158f, c3 = c1 + 1f, u = t - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    private static float smooth(float t) {
        return t * t * (3f - 2f * t);
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        if (parts == null) parts = BookModel.bake(mc);

        BookRenderer.Rec r = BookRenderer.forStack(stack, level);
        float hinge, ribbon = 0f, flip = -1f;
        boolean open = false, marked = false;
        if (r != null) {
            r.step(level.getGameTime() + mc.getFrameTime());
            hinge = r.hinge;
            ribbon = r.ribbon;
            flip = r.flip;
            open = r.open();
            marked = r.hasMark();
        } else {
            hinge = BookRenderer.CLOSED_ANGLE;
        }
        // 0 = fully open, 1 = fully closed
        float closed = Math.max(0f, Math.min(1f, (hinge - BookRenderer.OPEN_ANGLE) / (BookRenderer.CLOSED_ANGLE - BookRenderer.OPEN_ANGLE)));
        float rad = (float) Math.toRadians(hinge);

        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEX));
        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        // model space has +Y down and its pages on -Z; turn it upright so the pages face the viewer (+Z of the item frame)
        ps.scale(SCALE, -SCALE, -SCALE);
        // as it closes, turn it so the front cover faces you instead of the page edges
        ps.translate(CLOSED_RECENTER * closed * closed / 16f, 0, 0);
        ps.mulPose(Axis.YP.rotationDegrees(CLOSED_YAW * closed * closed));

        parts.right().x = CLOSED_SPREAD * closed * closed * closed;
        parts.left().x = -CLOSED_SPREAD * closed * closed * closed;
        parts.right().yRot = rad;
        parts.left().yRot = -rad;
        parts.right().render(ps, vc, light, overlay);
        parts.left().render(ps, vc, light, overlay);
        parts.spine().render(ps, vc, light, overlay);

        // page turn: the leaf swings from the right pages over the spine to the left pages, lifting mid-flip
        if (flip >= 0f && open) {
            float t = smooth(flip);
            parts.leaf().yRot = rad + t * ((float) Math.PI - 2f * rad);
            ps.pushPose();
            ps.translate(0, 0, -(float) Math.sin(t * Math.PI) * 0.06f);
            parts.leaf().render(ps, vc, light, overlay);
            ps.popPose();
        }

        // bookmark ribbon: drops in from above with a small overshoot, lifts back out when removed
        if (ribbon > 0f) {
            float t = marked ? easeOutBack(Math.min(1f, ribbon)) : ribbon;
            parts.ribbon().x = RIBBON_REST_X;
            parts.ribbon().y = RIBBON_START_Y * (1f - t);
            parts.ribbon().yRot = rad;
            parts.ribbon().render(ps, vc, light, overlay);
        }
        ps.popPose();
    }
}
