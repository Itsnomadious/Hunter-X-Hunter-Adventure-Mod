package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-side record of every Puppeteer in view (fed by PacketPuppeteerFx), keyed by the entity it is drawn around. */
public final class PuppeteerFx {
    private PuppeteerFx() {}

    public static final int READY = 1, ATTACHED = 2;
    /** Ticks for it to appear / vanish. */
    public static final double BORN_TICKS = 14, DIE_TICKS = 12;

    public static final class Rec {
        public final int anchor;
        public int mode;
        public double born, ended = -1;
        /** Smoothed position (the torso's bottom centre), facing and size: it trails its anchor a little, as if floating. */
        public double sx, sy, sz, base = 0.75;
        public float yaw;
        public boolean placed;
        public double last = Double.NaN;
        public int missing;

        Rec(int anchor, double born) {
            this.anchor = anchor;
            this.born = born;
        }
    }

    private static final Map<Integer, Rec> ACTIVE = new HashMap<>();

    public static Map<Integer, Rec> all() {
        return ACTIVE;
    }

    public static boolean isEmpty() {
        return ACTIVE.isEmpty();
    }

    public static void set(int anchor, int mode) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        double now = level.getGameTime();
        Rec r = ACTIVE.get(anchor);
        if (mode != 0) {
            if (r == null || r.ended >= 0) {
                r = new Rec(anchor, now);
                ACTIVE.put(anchor, r);
            }
            r.mode = mode;
        } else if (r != null && r.ended < 0) {
            r.ended = now;
        }
    }

    public static void clear() {
        ACTIVE.clear();
    }

    /** Forget everything when leaving a world. Self-registering, so no existing client event class needs editing. */
    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class PuppeteerClientHooks {
        private PuppeteerClientHooks() {}

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
            clear();
        }
    }

    /** Registers the model layer. Also self-registering (mod event bus). */
    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModEvents {
        private ModEvents() {}

        @SubscribeEvent
        public static void layers(net.minecraftforge.client.event.EntityRenderersEvent.RegisterLayerDefinitions e) {
            e.registerLayerDefinition(PuppeteerModel.LAYER, PuppeteerModel::createLayer);
        }
    }
}
