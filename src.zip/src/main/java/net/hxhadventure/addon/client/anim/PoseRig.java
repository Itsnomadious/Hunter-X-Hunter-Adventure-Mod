package net.hxhadventure.addon.client.anim;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Applies a {@link Pose} to the player model. tools/pose_preview.py mirrors this file line for line (with vanilla
 * contributions treated as zero), so keep the two in step.
 *
 * Model space: +x = character's left, +y = down, -z = forward. A part's rotation is Rz * Ry * Rx (x applied first).
 * Poses are authored for a right-handed player; for a left-handed one the y/z rotations, x offsets and the turn are
 * mirrored and main/off, lead/rear swap sides.
 */
public final class PoseRig {
    private PoseRig() {}

    /** Blade tip relative to the wrist pivot (blocks), arm frame, zero wrist bend, RIGHT hand. All sword models are ~1.66 long. */
    private static final float TIP_X = -0.063F, TIP_Y = 0.150F, TIP_Z = -1.652F;
    private static final float HAND_REACH = 0.625F;   // shoulder pivot -> hand pivot
    private static final float FLOOR_PX = 24F;        // model-space y of the ground under the feet
    private static final float HIP_Y = 12F;           // model-space y of the hip joint
    private static final float WRIST_STEP = 0.02F;
    private static final float DEFAULT_CLEARANCE = 0.10F;

    /** Filled by apply() when trace is true: the numbers behind the pose the local player is showing (/pose info). */
    public static volatile List<String> lastInfo = List.of();

    private static float rad(float deg) {
        return deg * Mth.DEG_TO_RAD;
    }

    private static float comp(float rot, float van, float vanillaValue, float sign) {
        float r = Float.isNaN(rot) ? 0F : sign * rad(rot);
        float f = Float.isNaN(van) ? (Float.isNaN(rot) ? 1F : 0F) : van;
        return r + f * vanillaValue;
    }

    private static void rotate(ModelPart part, Pose p, int bone, float s) {
        part.xRot = comp(p.rot[bone][0], p.vanilla[bone][0], part.xRot, 1F);
        part.yRot = comp(p.rot[bone][1], p.vanilla[bone][1], part.yRot, s);
        part.zRot = comp(p.rot[bone][2], p.vanilla[bone][2], part.zRot, s);
    }

    private static void leanAboutHips(ModelPart p, float cos, float sin) {
        float y = p.y - HIP_Y, z = p.z;
        p.y = HIP_Y + y * cos - z * sin;
        p.z = y * sin + z * cos;
    }

    /** How far the figure must sink so the lower foot meets the ground (a stride shortens the legs). */
    static float groundDrop(float rx, float rz, float lx, float lz) {
        float ext = Math.max(Mth.cos(rx) * Mth.cos(rz), Mth.cos(lx) * Mth.cos(lz));
        return Mth.clamp(HIP_Y * (1F - ext), 0F, 6F);
    }

    // ------------------------------------------------------------------------------------------------ apply
    /**
     * Poses the model. Call after vanilla setupAnim: bones left unset keep their vanilla values.
     * wristOut / rollOut are indexed 0 = right arm, 1 = left arm (consumed by PoseDriver.applyWrist).
     */
    public static void apply(PlayerModel<?> m, boolean rightMain, Pose in, float age, boolean mainArmed,
                             boolean offArmed, float[] wristOut, float[] rollOut, boolean trace) {
        Pose p = in.effective(mainArmed, offArmed);
        float s = rightMain ? 1F : -1F;
        float turn = s * rad(Pose.or0(p.turn));
        float lean = rad(Pose.or0(p.lean));

        ModelPart main = rightMain ? m.rightArm : m.leftArm;
        ModelPart off = rightMain ? m.leftArm : m.rightArm;
        ModelPart lead = rightMain ? m.leftLeg : m.rightLeg;
        ModelPart rear = rightMain ? m.rightLeg : m.leftLeg;
        ModelPart[] part = {m.head, m.body, main, off, lead, rear};   // same order as Pose bones 0..5

        // shoulders and hips swing round with the turned chest / pelvis
        float ct = Mth.cos(turn), st = Mth.sin(turn);
        m.rightArm.x = -5F * ct;
        m.rightArm.z = 5F * st;
        m.leftArm.x = 5F * ct;
        m.leftArm.z = -5F * st;
        m.rightLeg.x = -1.9F * ct + 0.1F * st;
        m.rightLeg.z = 1.9F * st + 0.1F * ct;
        m.leftLeg.x = 1.9F * ct + 0.1F * st;
        m.leftLeg.z = -1.9F * st + 0.1F * ct;

        for (int i = 0; i < 6; i++) rotate(part[i], p, i, s);
        m.body.yRot += turn;
        m.body.xRot += lean;

        // the upper body leans about the hips, so head, chest and shoulders move together
        if (lean != 0F) {
            float lc = Mth.cos(lean), ls = Mth.sin(lean);
            leanAboutHips(m.head, lc, ls);
            leanAboutHips(m.body, lc, ls);
            leanAboutHips(m.rightArm, lc, ls);
            leanAboutHips(m.leftArm, lc, ls);
        }

        for (int i = 0; i < 6; i++) {
            part[i].x += s * Pose.or0(p.pos[i][0]);
            part[i].y += Pose.or0(p.pos[i][1]);
            part[i].z += Pose.or0(p.pos[i][2]);
        }

        if (Boolean.TRUE.equals(p.ground)) {
            float drop = groundDrop(m.rightLeg.xRot, m.rightLeg.zRot, m.leftLeg.xRot, m.leftLeg.zRot);
            for (ModelPart part1 : part) part1.y += drop;
        }

        if (!Float.isNaN(p.breath)) {
            float b = rad(p.breath) * Mth.sin(age * 0.15F);
            if (!offArmed) off.xRot += b;
            if (!mainArmed) main.xRot -= b;
        }

        // held swords: the wrist bend, never letting the blade tip go below the floor
        for (int h = 0; h < 2; h++) {
            ModelPart arm = h == 0 ? main : off;
            boolean armed = h == 0 ? mainArmed : offArmed;
            boolean right = arm == m.rightArm;
            int idx = right ? 0 : 1;
            if (!armed) {
                wristOut[idx] = 0F;
                rollOut[idx] = 0F;
                continue;
            }
            float w = rad(Pose.or0(p.wrist[h]));
            if (!Boolean.FALSE.equals(p.clearFloor[h])) {
                float clr = Float.isNaN(p.tipClearance[h]) ? DEFAULT_CLEARANCE : p.tipClearance[h];
                w = clampWrist(arm.xRot, arm.yRot, arm.zRot, arm.y, right, w, clr, Boolean.TRUE.equals(p.bladeBack[h]));
            }
            wristOut[idx] = w;
            rollOut[idx] = rad(Pose.or0(p.roll[h]));
        }

        if (trace) lastInfo = describe(main, off, m, mainArmed, offArmed, wristOut);
    }

    // ------------------------------------------------------------------------------------------------ sword geometry
    private static Quaternionf armRotation(float xr, float yr, float zr) {
        return new Quaternionf().rotationZYX(zr, yr, xr);   // matrix Rz * Ry * Rx, exactly what ModelPart does
    }

    private static Vector3f tipVec(Quaternionf armRot, float wrist, boolean right) {
        return new Quaternionf(armRot).rotateX(wrist).transform(new Vector3f(right ? TIP_X : -TIP_X, TIP_Y, TIP_Z));
    }

    /** Height of the hand above the floor in blocks. shoulderY is the shoulder pivot's model-space y (sink included). */
    private static float handHeight(Quaternionf armRot, float shoulderY) {
        Vector3f hand = armRot.transform(new Vector3f(0F, HAND_REACH, 0F));
        return (FLOOR_PX - shoulderY) / 16F - hand.y;   // model +y is down
    }

    /**
     * The wrist bend nearest `desired` that keeps the blade tip `clearance` blocks off the ground without flipping the
     * blade's facing: a forward blade is straightened (bend reduced), a back-pointing blade is raised (bend increased).
     */
    static float clampWrist(float xr, float yr, float zr, float shoulderY, boolean right, float desired, float clearance,
                            boolean back) {
        Quaternionf q = armRotation(xr, yr, zr);
        float hh = handHeight(q, shoulderY);
        if (hh - tipVec(q, desired, right).y >= clearance) return desired;
        if (back) {
            float limit = Mth.PI + 0.3F;
            for (float w = desired + WRIST_STEP; w < limit; w += WRIST_STEP) {
                if (hh - tipVec(q, w, right).y >= clearance) return w;
            }
            return limit;
        }
        for (float w = desired - WRIST_STEP; w > 0F; w -= WRIST_STEP) {
            if (hh - tipVec(q, w, right).y >= clearance) return w;
        }
        return 0F;
    }

    // ------------------------------------------------------------------------------------------------ bake
    /**
     * Resolves "pitch_down" into a concrete wrist angle, using only the pose's own numbers (right-handed layout, vanilla
     * ignored). Call on every finished pose: poses that extend others must be baked after the merge.
     */
    public static void bake(Pose raw) {
        for (int h = 0; h < 2; h++) {
            if (Float.isNaN(raw.pitchDown[h])) continue;
            Pose e = raw.effective(h == 0, h == 1);
            int bone = h == 0 ? Pose.MAIN_ARM : Pose.OFF_ARM;
            boolean right = h == 0;
            float turn = rad(Pose.or0(e.turn)), lean = rad(Pose.or0(e.lean));
            float baseX = right ? -5F : 5F;
            float y = 2F, z = -baseX * Mth.sin(turn);
            if (lean != 0F) y = HIP_Y + (y - HIP_Y) * Mth.cos(lean) - z * Mth.sin(lean);
            y += Pose.or0(e.pos[bone][1]);
            if (Boolean.TRUE.equals(e.ground)) {
                y += groundDrop(rad(Pose.or0(e.rot[Pose.REAR_LEG][0])), rad(Pose.or0(e.rot[Pose.REAR_LEG][2])),
                        rad(Pose.or0(e.rot[Pose.LEAD_LEG][0])), rad(Pose.or0(e.rot[Pose.LEAD_LEG][2])));
            }
            float xBase = rad(Pose.or0(e.rot[bone][0])), yr = rad(Pose.or0(e.rot[bone][1])), zr = rad(Pose.or0(e.rot[bone][2]));
            boolean back = Boolean.TRUE.equals(e.bladeBack[h]);
            boolean floorOn = !Boolean.FALSE.equals(e.clearFloor[h]);
            float clr = Float.isNaN(e.tipClearance[h]) ? DEFAULT_CLEARANCE : e.tipClearance[h];
            int maxRaise = Math.round(Pose.or0(e.armRaise[h]));

            // swing the arm forward one degree at a time until the blade can take the wanted pitch with the tip clear
            // of the floor; the arm moves with the sword instead of only the wrist bending
            float xr = xBase, bw = 0F;
            for (int raise = 0; raise <= maxRaise; raise++) {
                xr = xBase - rad(raise);
                bw = solvePitch(armRotation(xr, yr, zr), right, raw.pitchDown[h], back);
                boolean ok = !floorOn || clampWrist(xr, yr, zr, y, right, bw, clr, back) == bw;
                if (ok) break;
            }
            if (floorOn) bw = clampWrist(xr, yr, zr, y, right, bw, clr, back);
            raw.wrist[h] = (float) Math.toDegrees(bw);
            if (xr != xBase) raw.rot[h == 0 ? Pose.MAIN_ARM_ARMED : Pose.OFF_ARM_ARMED][0] = (float) Math.toDegrees(xr);
        }
    }

    /** Wrist bend whose blade points pitchDown degrees below horizontal, facing forward (or back). */
    private static float solvePitch(Quaternionf q, boolean right, float pitchDown, boolean back) {
        float best = 1e9F, bw = 0F;
        for (float w = -0.7F; w < 3.5F; w += 0.01F) {
            Vector3f t = tipVec(q, w, right);
            if (back ? t.z > 0F : t.z < 0F) {
                float err = Math.abs((float) Math.toDegrees(Math.asin(Mth.clamp(t.y / t.length(), -1F, 1F))) - pitchDown);
                if (err < best - 1e-6F) {
                    best = err;
                    bw = w;
                }
            }
        }
        return bw;
    }

    // ------------------------------------------------------------------------------------------------ info
    private static List<String> describe(ModelPart main, ModelPart off, PlayerModel<?> m, boolean mainArmed,
                                         boolean offArmed, float[] wrist) {
        List<String> out = new ArrayList<>();
        for (int h = 0; h < 2; h++) {
            if (h == 0 ? !mainArmed : !offArmed) continue;
            ModelPart arm = h == 0 ? main : off;
            boolean right = arm == m.rightArm;
            Quaternionf q = armRotation(arm.xRot, arm.yRot, arm.zRot);
            float w = wrist[right ? 0 : 1];
            float hh = handHeight(q, arm.y);
            Vector3f t = tipVec(q, w, right);
            float pitch = (float) Math.toDegrees(Math.asin(t.y / t.length()));
            float side = (float) Math.toDegrees(Math.atan2(-t.x * (right ? 1F : -1F), Math.abs(t.z)));
            out.add(String.format(Locale.ROOT,
                    "%s hand: arm %.0f deg forward | wrist %.1f deg | hand %.2f blocks up | tip %.2f blocks up | blade %.0f deg below horizontal, pointing %s, %+.0f deg outward",
                    h == 0 ? "main" : "off", -Math.toDegrees(arm.xRot), Math.toDegrees(w), hh, hh - t.y, pitch, t.z > 0F ? "BACK" : "forward", side));
        }
        return out;
    }
}
