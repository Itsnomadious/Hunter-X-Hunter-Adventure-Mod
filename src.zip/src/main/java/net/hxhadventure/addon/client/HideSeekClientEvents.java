package net.hxhadventure.addon.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.HxHEntities;

/** Registers the Hide and Seek circle's renderer (mod event bus, client only). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class HideSeekClientEvents {
    private HideSeekClientEvents() {}

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(HxHEntities.HIDE_SEEK_PORTAL.get(), HideSeekPortalRenderer::new);
    }
}
