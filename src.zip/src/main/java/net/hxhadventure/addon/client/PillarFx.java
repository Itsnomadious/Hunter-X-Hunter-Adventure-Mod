package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;

/** Client-side list of golden sky pillars (Dragon Head's summon beam), fed by PacketPillarFx. */
public final class PillarFx {
    private PillarFx() {}

    public static final class Pillar {
        public final double x, y, z, t0;
        public final int ticks;

        Pillar(double x, double y, double z, double t0, int ticks) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.t0 = t0;
            this.ticks = ticks;
        }
    }

    public static final List<Pillar> ACTIVE = new ArrayList<>();

    public static void add(double x, double y, double z, int ticks) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        ACTIVE.add(new Pillar(x, y, z, level.getGameTime(), Math.max(1, ticks)));
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
