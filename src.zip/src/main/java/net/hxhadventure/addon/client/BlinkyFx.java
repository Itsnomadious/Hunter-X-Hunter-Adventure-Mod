package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.hxhadventure.addon.Blinky;
import net.hxhadventure.addon.network.PacketBlinkyFx;

/**
 * Arm poses for Blinky, for everyone who can see the user (the swings and the drain come from PacketBlinkyFx; the suction pose is read
 * straight from the player's "using item" state, which every client already has): SWING is a sideways sweep of the head after a short
 * wind-up, HEAVY a big overhead slam, DRAIN and SUCK hold the head out in front, aimed where the user looks.
 * Like the other arm effects it leaves the user's own first-person arm alone.
 */
public final class BlinkyFx {
    private BlinkyFx() {}

    private static final class Fx {
        final int kind;
        final boolean left;
        final double t0;
        final double life;

        Fx(int kind, boolean left, double t0, double life) {
            this.kind = kind;
            this.left = left;
            this.t0 = t0;
            this.life = life;
        }
    }

    private static final Map<Integer, Fx> ACTIVE = new HashMap<>();

    public static void add(int owner, int kind, boolean left, int ticks) {
        if (kind == PacketBlinkyFx.STOP) {
            ACTIVE.remove(owner);
            return;
        }
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        double life = kind == PacketBlinkyFx.DRAIN ? Math.max(ticks, 4) : kind == PacketBlinkyFx.HEAVY ? 14 : 8;
        ACTIVE.put(owner, new Fx(kind, left, level.getGameTime(), life));
    }

    public static void applyArm(PlayerModel<?> model, LivingEntity entity) {
        if (!(entity instanceof AbstractClientPlayer p)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || (p == mc.player && mc.options.getCameraType().isFirstPerson())) return;

        double now = mc.level.getGameTime() + mc.getFrameTime();
        Fx fx = ACTIVE.get(p.getId());
        if (fx != null && now - fx.t0 > fx.life) { // over
            ACTIVE.remove(p.getId());
            fx = null;
        }
        if (fx != null && now < fx.t0) return;
        boolean suck = p.isUsingItem() && Blinky.isHead(p.getUseItem());
        if (fx == null && !suck) return;

        int kind;
        boolean left;
        double age;
        double life;
        if (fx != null) {
            kind = fx.kind;
            left = fx.left;
            age = now - fx.t0;
            life = fx.life;
        } else {
            kind = 0; // suction: the arm that holds the head, for as long as the button is down
            boolean mainIsLeft = p.getMainArm() == HumanoidArm.LEFT;
            left = p.getUsedItemHand() == InteractionHand.OFF_HAND ? !mainIsLeft : mainIsLeft;
            age = p.tickCount + mc.getFrameTime();
            life = 1000000;
        }

        var arm = left ? model.leftArm : model.rightArm;
        float side = left ? -1f : 1f; // outward direction for this arm's y and z rotation
        float pitch = p.getXRot() * Mth.DEG_TO_RAD;
        float w = (float) Mth.clamp(Math.min(age / 2.0, (life - age) / 2.5), 0, 1); // ease in and out
        float t = (float) Mth.clamp(age / life, 0, 1);

        if (kind == PacketBlinkyFx.SWING) {
            // wind-up out to the side, then the head sweeps across in front
            float wind = Mth.clamp(t / 0.3f, 0f, 1f);
            float sweep = Mth.clamp((t - 0.3f) / 0.7f, 0f, 1f);
            sweep = sweep * sweep * (3f - 2f * sweep);
            float x = t < 0.3f ? Mth.lerp(wind, -1.2f, -2.0f) : Mth.lerp(sweep, -2.0f, -1.3f);
            arm.xRot = Mth.lerp(w, arm.xRot, x + pitch * 0.5f);
            arm.yRot = Mth.lerp(w, arm.yRot, side * (0.9f - 1.8f * sweep));
            arm.zRot = Mth.lerp(w, arm.zRot, side * 0.1f);
        } else if (kind == PacketBlinkyFx.HEAVY) {
            // all the way up and back, then slammed down in front
            float wind = Mth.clamp(t / 0.5f, 0f, 1f);
            float slam = Mth.clamp((t - 0.5f) / 0.5f, 0f, 1f);
            slam = slam * slam;
            float x = t < 0.5f ? Mth.lerp(wind, -1.0f, -3.0f) : Mth.lerp(slam, -3.0f, -1.2f);
            arm.xRot = Mth.lerp(w, arm.xRot, x + pitch * 0.3f);
            arm.yRot = Mth.lerp(w, arm.yRot, -side * 0.15f);
            arm.zRot = Mth.lerp(w, arm.zRot, side * 0.05f);
        } else {
            // sucking or draining: the head held out in front, aimed where the user looks, trembling a little
            float shake = Mth.sin((float) age * 1.7f) * (kind == PacketBlinkyFx.DRAIN ? 0.05f : 0.025f);
            float ease = kind == PacketBlinkyFx.DRAIN ? w : 1f;
            arm.xRot = Mth.lerp(ease, arm.xRot, -1.45f + pitch + shake);
            arm.yRot = Mth.lerp(ease, arm.yRot, -side * 0.1f);
            arm.zRot = Mth.lerp(ease, arm.zRot, side * 0.05f);
        }
        if (left) model.leftSleeve.copyFrom(model.leftArm);
        else model.rightSleeve.copyFrom(model.rightArm);
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
