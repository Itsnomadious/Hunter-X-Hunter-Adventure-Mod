package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.hxhadventure.addon.network.PacketPaperFx;

/**
 * Arm poses for Paper Manipulation, for everyone who can see the cast (fed by PacketPaperFx):
 * DROP lifts the left arm high while the confetti falls, WAVE swings the fan arm across the body, SWARM is a bigger, slower sweep.
 * Like the other arm effects it leaves the caster's own first-person arm alone.
 */
public final class PaperFx {
    private PaperFx() {}

    private static final class Fx {
        final int kind;
        final boolean left;
        final double t0;
        final double life;

        Fx(int kind, boolean left, double t0, double life) {
            this.kind = kind;
            this.left = left;
            this.t0 = t0;
            this.life = life;
        }
    }

    private static final Map<Integer, Fx> ACTIVE = new HashMap<>();

    public static void add(int owner, int kind, boolean left) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        double life = kind == PacketPaperFx.DROP ? 18 : kind == PacketPaperFx.SWARM ? 20 : 9;
        ACTIVE.put(owner, new Fx(kind, left, level.getGameTime(), life));
    }

    public static void applyArm(PlayerModel<?> model, LivingEntity entity) {
        if (ACTIVE.isEmpty() || !(entity instanceof AbstractClientPlayer p)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || (p == mc.player && mc.options.getCameraType().isFirstPerson())) return;
        Fx fx = ACTIVE.get(p.getId());
        if (fx == null) return;
        double age = mc.level.getGameTime() + mc.getFrameTime() - fx.t0;
        if (age < 0) return;
        if (age > fx.life) {
            ACTIVE.remove(p.getId());
            return;
        }
        float w = (float) Mth.clamp(Math.min(age / 2.5, (fx.life - age) / 3.0), 0, 1); // ease in and out
        float t = (float) (age / fx.life);
        var arm = fx.left ? model.leftArm : model.rightArm;
        float side = fx.left ? -1f : 1f; // outward direction for this arm's z rotation

        if (fx.kind == PacketPaperFx.DROP) {
            // the arm goes up and a little out, and the wrist shakes the paper loose
            arm.xRot = Mth.lerp(w, arm.xRot, -Mth.PI * 0.88f + Mth.sin((float) age * 1.6f) * 0.12f);
            arm.yRot = Mth.lerp(w, arm.yRot, 0f);
            arm.zRot = Mth.lerp(w, arm.zRot, side * 0.25f);
        } else if (fx.kind == PacketPaperFx.WAVE) {
            // forearm out front, swept across the body and back
            float sweep = Mth.sin(t * Mth.PI) * 1.0f;
            arm.xRot = Mth.lerp(w, arm.xRot, -Mth.HALF_PI + 0.1f);
            arm.yRot = Mth.lerp(w, arm.yRot, -side * (0.5f - sweep));
            arm.zRot = Mth.lerp(w, arm.zRot, side * 0.1f);
        } else {
            // swarm: arm goes up and back, then slashes forward
            float slash = Mth.clamp(t * 2f - 0.4f, 0f, 1f);
            arm.xRot = Mth.lerp(w, arm.xRot, Mth.lerp(slash, -Mth.PI * 0.8f, -Mth.HALF_PI + 0.1f));
            arm.yRot = Mth.lerp(w, arm.yRot, -side * Mth.lerp(slash, 0.1f, 0.6f));
            arm.zRot = Mth.lerp(w, arm.zRot, side * 0.2f);
        }
        if (fx.left) model.leftSleeve.copyFrom(model.leftArm);
        else model.rightSleeve.copyFrom(model.rightArm);
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
