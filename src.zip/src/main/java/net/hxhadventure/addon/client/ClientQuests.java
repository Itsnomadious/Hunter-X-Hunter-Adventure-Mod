package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.hxhadventure.addon.quest.Quest;
import net.hxhadventure.addon.quest.QuestData;
import net.hxhadventure.addon.quest.QuestType;
import net.hxhadventure.addon.quest.Quests;

/** Client copy of the player's active quests (fed by PacketQuestLog / PacketQuestSync). Read by the O menu's quest page and the En quest markers. */
public final class ClientQuests {
    private static List<QuestData.Active> active = new ArrayList<>();

    private ClientQuests() {}

    public static void set(List<QuestData.Active> now) {
        active = new ArrayList<>(now);
    }

    public static void clear() {
        active = new ArrayList<>();
    }

    public static List<QuestData.Active> active() {
        return active;
    }

    /** True if an unfinished Defeat objective of any active quest accepts this entity type id (e.g. "minecraft:pillager"). */
    public static boolean isKillTarget(String entityTypeId) {
        for (QuestData.Active a : active) {
            Quest q = Quests.get(a.id);
            if (q == null) continue;
            for (int i = 0; i < q.objectives.size() && i < a.progress.length; i++) {
                Quest.Objective o = q.objectives.get(i);
                if (o.type == QuestType.KILL && a.progress[i] < o.count && o.matches(entityTypeId)) return true;
            }
        }
        return false;
    }
}
