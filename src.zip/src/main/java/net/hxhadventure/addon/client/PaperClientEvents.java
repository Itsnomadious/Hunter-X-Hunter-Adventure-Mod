package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.hxhadventure.addon.PaperFanItem;
import net.hxhadventure.addon.PaperItems;

/** Lets the fan's item model switch between folded and unfolded (the "open" property in kallutos_fan.json). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class PaperClientEvents {
    private PaperClientEvents() {}

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> {
            if (PaperItems.FAN == null) return;
            ItemProperties.register(PaperItems.FAN, ResourceLocation.fromNamespaceAndPath("hxhadventure", "open"),
                (stack, level, entity, seed) -> PaperFanItem.isOpen(stack) ? 1.0f : 0.0f);
        });
    }
}
