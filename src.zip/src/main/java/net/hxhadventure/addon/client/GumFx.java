package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.addon.network.PacketGumFx;
import org.joml.Vector3f;

/**
 * Client-side state for Bungee Gum (fed by PacketGumFx).
 *  - Threads: who has one out and where it ends. GumRenderer draws the glowing pink beam from the fist, and applyArm holds the
 *    caster's right arm out along it for as long as it lasts (for everyone who can see the caster).
 *  - Tethers: on anything carrying "Properties of Rubber and Gum", a faint pink aura; GumRenderer also draws the see-through tether
 *    back to the user, but only for someone with Gyo on.
 * In hides the thread and the aura from anyone without Gyo (see InFx).
 */
public final class GumFx {
    private GumFx() {}

    public static final class Strand {
        public int target;          // entity id the thread ends on, or -1 for a point
        public Vec3 point = Vec3.ZERO;
        public Vec3 prev = Vec3.ZERO;
        public double t0;           // game time of the latest update (the tip eases from prev to point over one tick)
        public double born;         // game time the thread was thrown (the arm eases up over this)
    }

    public static final class Tether {
        public int caster;
        public int stage;
    }

    private static final Map<Integer, Strand> THREADS = new HashMap<>();   // caster entity id -> thread
    private static final Map<Integer, Tether> TETHERS = new HashMap<>();   // debuffed entity id -> tether
    private static final Map<Integer, Double> BINDS = new HashMap<>();     // bound entity id -> game time its Bungee Bind ends

    private static final ParticleOptions AURA_DUST = new DustParticleOptions(new Vector3f(0.93f, 0.45f, 0.85f), 0.7f);

    /** Length of the arm from the shoulder to the middle of the fist, blocks. */
    private static final double ARM_REACH = 0.8;

    public static void handle(byte kind, int id, int target, double x, double y, double z) {
        ClientLevel level = Minecraft.getInstance().level;
        double now = level == null ? 0 : level.getGameTime();
        switch (kind) {
            case PacketGumFx.THREAD -> {
                Strand s = THREADS.get(id);
                Vec3 p = new Vec3(x, y, z);
                if (s == null) {
                    s = new Strand();
                    s.born = now;
                    s.prev = p;
                    THREADS.put(id, s);
                } else {
                    s.prev = s.point;
                }
                s.point = p;
                s.target = target;
                s.t0 = now;
            }
            case PacketGumFx.THREAD_OFF -> THREADS.remove(id);
            case PacketGumFx.TETHER -> {
                Tether t = new Tether();
                t.caster = target;
                t.stage = (int) x;
                TETHERS.put(id, t);
            }
            case PacketGumFx.TETHER_OFF -> TETHERS.remove(id);
            case PacketGumFx.BIND -> BINDS.put(id, now + x);
            case PacketGumFx.BIND_OFF -> BINDS.remove(id);
            default -> { }
        }
    }

    public static void clear() {
        THREADS.clear();
        TETHERS.clear();
        BINDS.clear();
    }

    public static Map<Integer, Double> binds() {
        return BINDS;
    }

    public static Map<Integer, Strand> threads() {
        return THREADS;
    }

    public static Map<Integer, Tether> tethers() {
        return TETHERS;
    }

    public static boolean hasThread(int casterId) {
        return !THREADS.isEmpty() && THREADS.containsKey(casterId);
    }

    /** Where the thread ends right now, or null if what it is stuck to is gone. */
    public static Vec3 endOf(ClientLevel level, Strand s, float pt) {
        if (s.target >= 0) {
            Entity e = level.getEntity(s.target);
            if (e == null || e.isRemoved()) return null;
            return e.getPosition(pt).add(0, e.getBbHeight() * 0.5, 0);
        }
        double f = Mth.clamp(level.getGameTime() + pt - s.t0, 0.0, 1.0);
        return s.prev.lerp(s.point, f);
    }

    /** The caster's right shoulder (the arm is posed from the body yaw, like every other arm ability here). */
    public static Vec3 shoulderOf(Entity caster, float pt) {
        float yaw = caster instanceof LivingEntity le ? Mth.rotLerp(pt, le.yBodyRotO, le.yBodyRot) : caster.getYRot();
        double rad = Math.toRadians(yaw);
        Vec3 right = new Vec3(-Math.cos(rad), 0, -Math.sin(rad));
        return caster.getPosition(pt).add(right.scale(0.31)).add(0, caster.getBbHeight() * 0.77, 0);
    }

    /** The fist: where the thread leaves the caster. In your own first-person view that is the lower right of the screen. */
    public static Vec3 handOf(Minecraft mc, Camera camera, Entity caster, Vec3 end, float pt) {
        if (caster == mc.player && mc.options.getCameraType().isFirstPerson()) {
            Vec3 c = camera.getPosition();
            Vector3f look = camera.getLookVector();
            Vector3f left = camera.getLeftVector();
            Vector3f up = camera.getUpVector();
            return c.add(look.x() * 0.8 - left.x() * 0.34 - up.x() * 0.30,
                         look.y() * 0.8 - left.y() * 0.34 - up.y() * 0.30,
                         look.z() * 0.8 - left.z() * 0.34 - up.z() * 0.30);
        }
        Vec3 sh = shoulderOf(caster, pt);
        Vec3 d = end.subtract(sh);
        double len = d.length();
        if (len < 1.0e-4) return sh;
        return sh.add(d.scale(Math.min(ARM_REACH, len) / len));
    }

    /** The right arm held straight out along the thread for as long as it is out, palm closed into a fist. */
    public static void applyArm(PlayerModel<?> model, LivingEntity entity) {
        if (THREADS.isEmpty() || !(entity instanceof AbstractClientPlayer p)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || (p == mc.player && mc.options.getCameraType().isFirstPerson())) return;
        Strand s = THREADS.get(p.getId());
        if (s == null) return;
        float pt = mc.getFrameTime();
        Vec3 end = endOf(mc.level, s, pt);
        if (end == null) return;
        Vec3 d = end.subtract(shoulderOf(p, pt));
        if (d.lengthSqr() < 1.0e-4) return;
        d = d.normalize();
        float w = (float) Mth.clamp((mc.level.getGameTime() + pt - s.born) / 1.5, 0.0, 1.0);
        float bodyYaw = Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot);
        float yaw = (float) (Mth.atan2(-d.x, d.z) * (180.0 / Math.PI));
        float pitch = (float) -Math.asin(Mth.clamp(d.y, -1.0, 1.0));
        model.rightArm.xRot = Mth.lerp(w, model.rightArm.xRot, -Mth.HALF_PI + pitch);
        model.rightArm.yRot = Mth.lerp(w, model.rightArm.yRot, Mth.wrapDegrees(yaw - bodyYaw) * Mth.DEG_TO_RAD);
        model.rightArm.zRot = Mth.lerp(w, model.rightArm.zRot, 0f);
        model.rightSleeve.copyFrom(model.rightArm);
    }

    /** Drops threads whose caster is gone, and draws the debuff's faint aura (the beams, tether included, are GumRenderer's). */
    public static void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        if (level == null || (THREADS.isEmpty() && TETHERS.isEmpty())) return;
        long time = level.getGameTime();

        Iterator<Map.Entry<Integer, Strand>> ti = THREADS.entrySet().iterator();
        while (ti.hasNext()) {
            Entity caster = level.getEntity(ti.next().getKey());
            if (caster == null || caster.isRemoved()) ti.remove();
        }

        Iterator<Map.Entry<Integer, Tether>> ei = TETHERS.entrySet().iterator();
        while (ei.hasNext()) {
            Map.Entry<Integer, Tether> en = ei.next();
            Entity victim = level.getEntity(en.getKey());
            Tether t = en.getValue();
            if (victim == null || victim.isRemoved()) {
                ei.remove();
                continue;
            }
            if (InFx.hiddenFrom(t.caster)) continue; // In: the build-up is invisible unless you have Gyo
            if (time % 3 == 0) { // the subtle aura: a few pink motes around the body, more of them at higher stages
                for (int i = 0; i < 1 + t.stage; i++) {
                    level.addParticle(AURA_DUST, victim.getRandomX(0.6), victim.getRandomY(), victim.getRandomZ(0.6), 0, 0.01, 0);
                }
            }
        }
    }
}
