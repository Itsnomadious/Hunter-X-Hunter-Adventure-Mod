package net.hxhadventure.addon.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.HxHEntities;

/** Registers the clown's model layer and renderer (mod bus), so no existing client class needs editing. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class CrazySlotsClientEvents {
    private CrazySlotsClientEvents() {}

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(CrazySlotsModel.LAYER, CrazySlotsModel::createLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(HxHEntities.CRAZY_SLOTS.get(), CrazySlotsRenderer::new);
    }
}
