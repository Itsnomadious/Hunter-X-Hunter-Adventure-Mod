package net.hxhadventure.addon.client;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.SmokePipeItem;
import org.joml.Vector3f;

/**
 * A faint wisp of smoke rising out of the hole in the top of Morel's pipe for as long as someone holds it. Purely cosmetic and drawn
 * client side for every player in view, so it needs no packets. The hole sits where models/item/morels_pipe.json puts it: far end of
 * the stem, bowl open on top. The offsets below were worked out from that model's display transforms (third person: scale 0.72,
 * rotation 0/-90/45; first person: scale 0.5, rotation 0/-70/120); change them together if the model's display block changes.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class PipeSmokeClient {
    private PipeSmokeClient() {}

    /** Third person, in blocks from the player's feet: hand, then hole relative to the hand (all x the player's right, y up, z forward). */
    private static final double HAND_RIGHT = 0.234, HAND_UP = 0.768, HAND_FWD = 0.292;
    private static final double HOLE_UP = 0.522, HOLE_FWD = 1.061;
    /** First person, in the camera's frame. */
    private static final double FP_RIGHT = 0.285, FP_UP = -0.175, FP_FWD = 1.477;

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || mc.isPaused()) return;
        for (AbstractClientPlayer p : level.players()) {
            if (p.isSpectator() || p.isInvisible()) continue;
            InteractionHand hand = SmokePipeItem.heldIn(p);
            if (hand == null) continue;
            if (level.random.nextInt(3) != 0) continue;
            HumanoidArm arm = hand == InteractionHand.MAIN_HAND ? p.getMainArm() : p.getMainArm().getOpposite();
            boolean left = arm == HumanoidArm.LEFT;
            Vec3 at = holeOf(mc, p, left);
            double vy = 0.012 + level.random.nextDouble() * 0.012;
            double vx = (level.random.nextDouble() - 0.5) * 0.004;
            double vz = (level.random.nextDouble() - 0.5) * 0.004;
            level.addParticle(level.random.nextInt(4) == 0 ? ParticleTypes.SMOKE : ParticleTypes.CLOUD, at.x, at.y, at.z, vx, vy, vz);
        }
    }

    /** Where the hole in the pipe's bowl is right now. */
    private static Vec3 holeOf(Minecraft mc, AbstractClientPlayer p, boolean left) {
        double side = left ? -1.0 : 1.0;
        if (p == mc.player && mc.options.getCameraType().isFirstPerson()) {
            Camera cam = mc.gameRenderer.getMainCamera();
            Vec3 c = cam.getPosition();
            Vector3f look = cam.getLookVector();
            Vector3f lf = cam.getLeftVector();
            Vector3f up = cam.getUpVector();
            double r = FP_RIGHT * side;
            return c.add(look.x() * FP_FWD - lf.x() * r + up.x() * FP_UP,
                         look.y() * FP_FWD - lf.y() * r + up.y() * FP_UP,
                         look.z() * FP_FWD - lf.z() * r + up.z() * FP_UP);
        }
        double rad = Math.toRadians(p.yBodyRot);
        Vec3 fwd = new Vec3(-Math.sin(rad), 0, Math.cos(rad));
        Vec3 right = new Vec3(-Math.cos(rad), 0, -Math.sin(rad));
        double up = HAND_UP + HOLE_UP - (p.isCrouching() ? 0.2 : 0.0);
        double f = HAND_FWD + HOLE_FWD + (p.isCrouching() ? 0.1 : 0.0);
        return p.position().add(right.scale(HAND_RIGHT * side)).add(fwd.scale(f)).add(0, up, 0);
    }
}
