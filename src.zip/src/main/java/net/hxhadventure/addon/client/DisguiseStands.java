package net.hxhadventure.addon.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.player.AbstractClientPlayer;

/** The player-shaped stand-ins (Body Alteration, Convert Hands) currently drawn in place of an entity. */
public final class DisguiseStands {
    private DisguiseStands() {}

    /** Stand-ins that are drawn instead of this entity and are players, so punches / kicks played on it can be played on them as well. */
    public static List<AbstractClientPlayer> standInsFor(int entityId) {
        List<AbstractClientPlayer> out = new ArrayList<>(2);
        AbstractClientPlayer a = NeedleDisguise.standInFor(entityId);
        if (a != null) out.add(a);
        AbstractClientPlayer b = DisguiseHandler.standInFor(entityId);
        if (b != null) out.add(b);
        return out;
    }
}
