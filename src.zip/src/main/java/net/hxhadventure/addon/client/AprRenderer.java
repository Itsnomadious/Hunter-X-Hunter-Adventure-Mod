package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.hxhadventure.addon.AprEntity;

/** Draws A.P.R.: the {@link AprModel} at the size its growth says, with the aura owed written on the forehead counter. */
public class AprRenderer extends EntityRenderer<AprEntity> {
    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/apr.png");
    private final AprModel model;

    public AprRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.model = new AprModel(ctx.bakeLayer(AprModel.LAYER));
        this.shadowRadius = 0f;
    }

    @Override
    public ResourceLocation getTextureLocation(AprEntity e) {
        return TEX;
    }

    @Override
    public void render(AprEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float h = AprEntity.heightFor(e.renderGrowth(pt));
        float s = h / AprModel.MODEL_HEIGHT;
        float time = e.tickCount + pt;

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180f - Mth.rotLerp(pt, e.yRotO, e.getYRot())));
        ps.scale(-s, -s, s);
        ps.translate(0f, -1.501f, 0f); // feet at model y = 24
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEX));
        model.render(ps, vc, light, OverlayTexture.NO_OVERLAY, time);

        // the counter: the aura owed, squeezed to fit the little screen
        String text = format(e.debtShown());
        Font font = getFont();
        int w = Math.max(1, font.width(text));
        float sc = Math.min(AprModel.SCREEN_W / w, AprModel.SCREEN_H / 8f);
        ps.pushPose();
        ps.translate((AprModel.SCREEN_X - w * sc / 2f) / 16f, (AprModel.SCREEN_Y - 4f * sc) / 16f, AprModel.SCREEN_Z / 16f);
        ps.scale(sc / 16f, sc / 16f, sc / 16f);
        font.drawInBatch(text, 0f, 0f, 0xFF1F3340, false, ps.last().pose(), buf, Font.DisplayMode.POLYGON_OFFSET, 0, light);
        ps.popPose();
        ps.popPose();

        super.render(e, yaw, pt, ps, buf, light); // the speech bubble (its name tag)
    }

    /** 1920, 12.3K, 4.5M: short enough for a forehead. */
    private static String format(int v) {
        if (v < 10000) return String.valueOf(Math.max(0, v));
        if (v < 1000000) return String.format(java.util.Locale.ROOT, "%.1fK", v / 1000f);
        return String.format(java.util.Locale.ROOT, "%.1fM", v / 1000000f);
    }
}
