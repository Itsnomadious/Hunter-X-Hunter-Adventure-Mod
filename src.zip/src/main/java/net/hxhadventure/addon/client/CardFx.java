package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;

/** Client-side state for Hisoka's cards (fed by PacketCardFx): where each card is, so CardRenderer can draw it smoothly. */
public final class CardFx {
    private CardFx() {}

    public static final class Card {
        public Vec3 prev = Vec3.ZERO;
        public Vec3 cur = Vec3.ZERO;
        public Vec3 vel = Vec3.ZERO;
        public double t0;
    }

    private static final Map<Integer, Map<Integer, Card>> BY_OWNER = new HashMap<>(); // owner entity id -> card id -> card

    public static void handle(int owner, int[] ids, float[] d) {
        ClientLevel level = Minecraft.getInstance().level;
        double now = level == null ? 0 : level.getGameTime();
        Map<Integer, Card> m = BY_OWNER.computeIfAbsent(owner, k -> new HashMap<>());
        Set<Integer> seen = new HashSet<>();
        for (int i = 0; i < ids.length; i++) {
            Vec3 p = new Vec3(d[i * 6], d[i * 6 + 1], d[i * 6 + 2]);
            Card c = m.get(ids[i]);
            if (c == null) {
                c = new Card();
                c.prev = p;
                m.put(ids[i], c);
            } else {
                c.prev = c.cur;
            }
            c.cur = p;
            c.vel = new Vec3(d[i * 6 + 3], d[i * 6 + 4], d[i * 6 + 5]);
            c.t0 = now;
            seen.add(ids[i]);
        }
        m.keySet().retainAll(seen); // cards missing from the latest packet are gone
        if (m.isEmpty()) BY_OWNER.remove(owner);
    }

    public static Map<Integer, Map<Integer, Card>> all() {
        return BY_OWNER;
    }

    /** Drops cards whose updates stopped coming (the user left range, say). */
    public static void tick(Minecraft mc) {
        if (BY_OWNER.isEmpty() || mc.level == null) return;
        long now = mc.level.getGameTime();
        Iterator<Map<Integer, Card>> it = BY_OWNER.values().iterator();
        while (it.hasNext()) {
            Map<Integer, Card> m = it.next();
            m.values().removeIf(c -> now - c.t0 > 10);
            if (m.isEmpty()) it.remove();
        }
    }

    public static void clear() {
        BY_OWNER.clear();
    }
}
