package net.hxhadventure.addon.client;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.addon.SkillHunter;

/**
 * Client-side animation state for each Skill Hunter's book (open/closed hinge, page flip, bookmark ribbon).
 * The book is no longer drawn floating in the world: {@link BookItemRenderer} draws it as the held item and reads
 * its animation from here. State is keyed by the owner's entity id and fed by PacketBookFx.
 */
public final class BookRenderer {
    private BookRenderer() {}

    public static final float OPEN_ANGLE = 10f, CLOSED_ANGLE = 88f;
    // animation lengths in ticks
    private static final float HINGE_TICKS = 8f, FLIP_TICKS = 9f, RIBBON_TICKS = 14f;

    public static final class Rec {
        byte state;                    // 1 closed (bookmarked), 2 open
        byte mark = -1;
        public float hinge = CLOSED_ANGLE; // current hinge angle (degrees), eases toward target
        public float ribbon;               // 0 = out of the book, 1 = placed
        public float flip = -1f;           // page-turn progress 0..1, -1 = idle
        float last = Float.NaN;            // last update time, for easing

        public boolean open() { return state == 2; }
        public boolean hasMark() { return mark >= 0; }

        /** Advance the animations to the given time (game ticks + partial). Safe to call several times per frame. */
        public void step(float time) {
            float dt = Float.isNaN(last) ? 0f : Math.min(5f, Math.max(0f, time - last));
            last = time;
            float target = state == 2 ? OPEN_ANGLE : CLOSED_ANGLE;
            float stepDeg = Math.abs(CLOSED_ANGLE - OPEN_ANGLE) * dt / HINGE_TICKS;
            if (hinge < target) hinge = Math.min(target, hinge + stepDeg);
            else hinge = Math.max(target, hinge - stepDeg);
            float rt = mark >= 0 ? 1f : 0f;
            float rs = dt / RIBBON_TICKS;
            ribbon = ribbon < rt ? Math.min(rt, ribbon + rs) : Math.max(rt, ribbon - rs);
            if (flip >= 0f) {
                flip += dt / FLIP_TICKS;
                if (flip >= 1f) flip = -1f;
            }
        }
    }

    private static final Map<Integer, Rec> BOOKS = new HashMap<>();

    public static void set(int entityId, byte state, byte page, byte mark, byte flags) {
        if (state == 0) {
            BOOKS.remove(entityId);
            return;
        }
        Rec r = BOOKS.computeIfAbsent(entityId, k -> new Rec());
        r.state = state;
        r.mark = mark;
        if ((flags & 1) != 0) r.flip = 0f;
        if ((flags & 2) != 0) {
            r.ribbon = 0f;
            sparkle(entityId);
        }
    }

    /** Animation state for the owner of this book stack, or null if the owner has no active book (render it closed). */
    public static Rec forStack(ItemStack stack, ClientLevel level) {
        UUID owner = SkillHunter.bookOwner(stack);
        if (owner == null) return null;
        Player p = level.getPlayerByUUID(owner);
        return p == null ? null : BOOKS.get(p.getId());
    }

    private static void sparkle(int entityId) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        Entity owner = level.getEntity(entityId);
        if (owner == null) return;
        Vec3 p = owner.getEyePosition(1f).add(owner.getLookAngle().scale(0.6)).add(0, -0.4, 0);
        for (int i = 0; i < 18; i++) {
            double a = level.random.nextDouble() * Math.PI * 2;
            double sp = 0.02 + level.random.nextDouble() * 0.05;
            level.addParticle(i % 3 == 0 ? ParticleTypes.ENCHANT : ParticleTypes.END_ROD, p.x, p.y, p.z, Math.cos(a) * sp, 0.03 + level.random.nextDouble() * 0.04, Math.sin(a) * sp);
        }
    }

    public static void clear() {
        BOOKS.clear();
    }
}
