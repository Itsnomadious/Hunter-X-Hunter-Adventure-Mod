package net.hxhadventure.addon.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.HxHEntities;

/** Registers the A.P.R. and I.R.S. models and renderers (mod event bus, client only). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class HakowareClientEvents {
    private HakowareClientEvents() {}

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(AprModel.LAYER, AprModel::createLayer);
        e.registerLayerDefinition(IrsModel.LAYER, IrsModel::createLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(HxHEntities.APR.get(), AprRenderer::new);
        e.registerEntityRenderer(HxHEntities.IRS.get(), IrsRenderer::new);
    }
}
