package net.hxhadventure.addon.client;

import net.hxhadventure.addon.NenFighter;
import net.hxhadventure.addon.NpcStats;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

/** A Nen-fighter NPC drawn with the player model and its skin, with its Ten / Ren / Ken aura (Ren is wider, brighter and flickers; Ken is solid). */
public class NenFighterRenderer<T extends NenFighter> extends NpcPlayerRenderer<T> {
    public NenFighterRenderer(EntityRendererProvider.Context ctx, NpcStats stats) {
        super(ctx, n -> tex(stats.skin), n -> stats.slim);
        addLayer(new NpcAuraLayer<T>(this, tex(stats.auraTex), npc -> {
            int f = npc.nenFlags();
            if ((f & NenFighter.F_TEN) == 0) return null;
            if ((f & NenFighter.F_REN) != 0) {
                float flick = 0.9f + 0.1f * (float) Math.sin(npc.tickCount * 0.9);
                return new float[] {1.4f, 1.5f, flick, 1f, 1f};
            }
            if ((f & NenFighter.F_KEN) != 0) return new float[] {1.2f, 1.3f, 0.85f, 1f, 1f};
            return new float[] {1.1f, 1.2f, 0.6f, 1f, 1f};
        }));
    }
}
