package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.hxhadventure.addon.NeferpitouEntity;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

/** Ten glow (always), fuller and redder in Ko. Ren is the big aura entity, drawn by the aura renderer. Only shown to players with Nen unlocked. */
public class NeferpitouAuraLayer extends GeoRenderLayer<NeferpitouEntity> {
    private static final ResourceLocation TEN = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/pinkaura_ten.png");

    public NeferpitouAuraLayer(GeoRenderer<NeferpitouEntity> renderer) {
        super(renderer);
    }

    @Override
    public void render(PoseStack poseStack, NeferpitouEntity npc, BakedGeoModel model, RenderType renderType, MultiBufferSource buffers,
                       VertexConsumer buffer, float partialTick, int packedLight, int packedOverlay) {
        int f = npc.nenFlags();
        if ((f & NeferpitouEntity.F_TEN) == 0 || npc.isInvisible()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !mc.player.getPersistentData().getBoolean("HxHCraft_NenUnlocked")) return;

        boolean ko = (f & NeferpitouEntity.F_KO) != 0;
        boolean ken = (f & NeferpitouEntity.F_KEN) != 0;
        float sx = ko || ken ? 1.2f : 1.1f, sz = ko || ken ? 1.3f : 1.2f;
        float alpha = ko ? 0.9f : ken ? 0.85f : 0.6f;
        float g = ko ? 0.55f : 1f, b = ko ? 0.55f : 1f;   // Ko: her aura pulls into a deep red

        RenderType type = RenderType.entityTranslucentEmissive(TEN);
        poseStack.pushPose();
        poseStack.scale(sx, 1.0f, sz);
        getRenderer().reRender(model, poseStack, buffers, npc, type, buffers.getBuffer(type), partialTick, 15728880, packedOverlay, 1f, g, b, alpha);
        poseStack.popPose();
    }
}
