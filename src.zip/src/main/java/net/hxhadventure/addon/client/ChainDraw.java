package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.texture.OverlayTexture;

/** Draws one chain piece at a position, turned so its local +Z points along (dx, dy, dz). Positions are in blocks. */
final class ChainDraw {
    private ChainDraw() {}

    static void piece(PoseStack ps, VertexConsumer vc, ModelPart part, double x, double y, double z,
                      double dx, double dy, double dz, float scale, int light) {
        piece(ps, vc, part, x, y, z, dx, dy, dz, scale, light, 1f, 1f, 1f, 1f);
    }

    /** Same, tinted (r, g, b, a): used for the glow of the Ten that covers the Holy Chain. */
    static void piece(PoseStack ps, VertexConsumer vc, ModelPart part, double x, double y, double z,
                      double dx, double dy, double dz, float scale, int light, float r, float g, float b, float a) {
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6) return;
        ps.pushPose();
        ps.translate(x, y, z);
        ps.mulPose(Axis.YP.rotation((float) Math.atan2(dx, dz)));
        ps.mulPose(Axis.XP.rotation((float) -Math.asin(Math.max(-1.0, Math.min(1.0, dy / len)))));
        ps.scale(scale, scale, scale);
        part.render(ps, vc, light, OverlayTexture.NO_OVERLAY, r, g, b, a);
        ps.popPose();
    }
}
