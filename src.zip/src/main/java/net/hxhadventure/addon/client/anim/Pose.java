package net.hxhadventure.addon.client.anim;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

/**
 * One complete (or partial) body pose, as authored in assets/hxhadventure/poses/*.json.
 * Every number may be unset (NaN): an unset value inherits from the pose it extends, or from vanilla animation.
 * See docs/ANIMATION.md for the file format and the axis conventions.
 */
public final class Pose {
    public static final String[] BONES = {"head", "body", "main_arm", "off_arm", "lead_leg", "rear_leg",
            "main_arm_armed", "off_arm_armed"};
    public static final int HEAD = 0, BODY = 1, MAIN_ARM = 2, OFF_ARM = 3, LEAD_LEG = 4, REAR_LEG = 5,
            MAIN_ARM_ARMED = 6, OFF_ARM_ARMED = 7;

    private static final float NAN = Float.NaN;
    private static final Set<String> TOP_KEYS = Set.of("extends", "pose", "turn", "lean", "ground", "breath", "bones",
            "main_item", "off_item", "time", "ease", "base", "length", "loop", "hold", "keys", "blend", "interp");
    private static final Set<String> BONE_KEYS = Set.of("rot", "pos", "vanilla");
    private static final Set<String> ITEM_KEYS = Set.of("wrist", "pitch_down", "blade", "arm_raise", "roll", "clear_floor", "tip_clearance");

    /** Chest/hip turn off the line to the opponent (deg). Mirrored for left-handed players. */
    public float turn = NAN;
    /** Forward lean of the upper body about the hips (deg). */
    public float lean = NAN;
    /** Idle breathing amplitude on the empty hands (deg). */
    public float breath = NAN;
    /** Ticks to cross-fade INTO this pose from whatever was showing before (unset = the default for its kind). */
    public float blend = NAN;
    /** Sink the figure so the lower foot touches the ground. */
    public Boolean ground;

    /** [bone][x,y,z]: rotation in degrees. */
    public final float[][] rot = new float[BONES.length][3];
    /** [bone][x,y,z]: pivot offset in model pixels. */
    public final float[][] pos = new float[BONES.length][3];
    /** [bone][x,y,z]: how much of the vanilla animation to keep (1 = all, 0 = none). Default: 1 where rot is unset, else 0. */
    public final float[][] vanilla = new float[BONES.length][3];

    // held item, index 0 = main hand, 1 = off hand
    public final float[] wrist = {NAN, NAN};          // deg, bends the blade about the hand
    public final float[] pitchDown = {NAN, NAN};      // deg below horizontal the blade should point (solved into wrist)
    public final float[] armRaise = {NAN, NAN};       // deg the arm may swing further forward to reach pitch_down
    public final float[] roll = {NAN, NAN};           // deg, spin of the item about the blade
    public final float[] tipClearance = {NAN, NAN};   // blocks the tip keeps above the ground
    public final Boolean[] clearFloor = new Boolean[2];
    public final Boolean[] bladeBack = new Boolean[2]; // pitch_down aims the blade backward instead of forward

    public Pose() {
        for (float[][] group : new float[][][]{rot, pos, vanilla}) {
            for (float[] v : group) Arrays.fill(v, NAN);
        }
    }

    public Pose copy() {
        Pose c = new Pose();
        c.turn = turn;
        c.lean = lean;
        c.breath = breath;
        c.blend = blend;
        c.ground = ground;
        for (int i = 0; i < BONES.length; i++) {
            System.arraycopy(rot[i], 0, c.rot[i], 0, 3);
            System.arraycopy(pos[i], 0, c.pos[i], 0, 3);
            System.arraycopy(vanilla[i], 0, c.vanilla[i], 0, 3);
        }
        for (int h = 0; h < 2; h++) {
            c.wrist[h] = wrist[h];
            c.pitchDown[h] = pitchDown[h];
            c.roll[h] = roll[h];
            c.armRaise[h] = armRaise[h];
            c.tipClearance[h] = tipClearance[h];
            c.clearFloor[h] = clearFloor[h];
            c.bladeBack[h] = bladeBack[h];
        }
        return c;
    }

    public static float or0(float v) {
        return Float.isNaN(v) ? 0F : v;
    }

    public static int boneIndex(String name) {
        for (int i = 0; i < BONES.length; i++) {
            if (BONES[i].equals(name)) return i;
        }
        return -1;
    }

    /** Merges the *_armed bones over the plain arm bones for each hand that holds a sword. */
    public Pose effective(boolean mainArmed, boolean offArmed) {
        Pose e = copy();
        if (mainArmed) e.mergeBone(MAIN_ARM, MAIN_ARM_ARMED);
        if (offArmed) e.mergeBone(OFF_ARM, OFF_ARM_ARMED);
        return e;
    }

    private void mergeBone(int dst, int src) {
        for (int i = 0; i < 3; i++) {
            if (!Float.isNaN(rot[src][i])) rot[dst][i] = rot[src][i];
            if (!Float.isNaN(pos[src][i])) pos[dst][i] = pos[src][i];
            if (!Float.isNaN(vanilla[src][i])) vanilla[dst][i] = vanilla[src][i];
        }
    }

    private static float l(float a, float b, float u) {
        if (Float.isNaN(a)) return b;
        if (Float.isNaN(b)) return a;
        return a + (b - a) * u;
    }

    public static Pose lerp(Pose a, Pose b, float u) {
        Pose r = new Pose();
        r.turn = l(a.turn, b.turn, u);
        r.lean = l(a.lean, b.lean, u);
        r.breath = l(a.breath, b.breath, u);
        r.blend = l(a.blend, b.blend, u);
        r.ground = (u < 0.5F || b.ground == null) ? a.ground : b.ground;
        for (int i = 0; i < BONES.length; i++) {
            for (int k = 0; k < 3; k++) {
                r.rot[i][k] = l(a.rot[i][k], b.rot[i][k], u);
                r.pos[i][k] = l(a.pos[i][k], b.pos[i][k], u);
                r.vanilla[i][k] = l(a.vanilla[i][k], b.vanilla[i][k], u);
            }
        }
        for (int h = 0; h < 2; h++) {
            r.wrist[h] = l(a.wrist[h], b.wrist[h], u);
            r.pitchDown[h] = l(a.pitchDown[h], b.pitchDown[h], u);
            r.roll[h] = l(a.roll[h], b.roll[h], u);
            r.armRaise[h] = l(a.armRaise[h], b.armRaise[h], u);
            r.tipClearance[h] = l(a.tipClearance[h], b.tipClearance[h], u);
            r.clearFloor[h] = (u < 0.5F || b.clearFloor[h] == null) ? a.clearFloor[h] : b.clearFloor[h];
            r.bladeBack[h] = (u < 0.5F || b.bladeBack[h] == null) ? a.bladeBack[h] : b.bladeBack[h];
        }
        return r;
    }

    // ------------------------------------------------------------------------------------------------ spline
    /** Cubic Hermite value between b (at t1) and c (at t2); a / d are the neighbours (NaN = none: zero tangent, so ends ease). */
    private static float h(float a, float b, float c, float d, float t0, float t1, float t2, float t3, float u) {
        if (Float.isNaN(b) || Float.isNaN(c)) return l(b, c, u);
        float dt = Math.max(1e-6F, t2 - t1);
        float m1 = Float.isNaN(a) ? 0F : (c - a) / Math.max(1e-6F, t2 - t0);
        float m2 = Float.isNaN(d) ? 0F : (d - b) / Math.max(1e-6F, t3 - t1);
        float u2 = u * u, u3 = u2 * u;
        return (2F * u3 - 3F * u2 + 1F) * b + (u3 - 2F * u2 + u) * dt * m1 + (-2F * u3 + 3F * u2) * c + (u3 - u2) * dt * m2;
    }

    /**
     * Catmull-Rom through p1 -> p2 using the keys either side (p0 / p3 may be null at the ends). The velocity is continuous
     * across keys, so a swing flows through them instead of stopping at each one. u is 0..1 between the two keys.
     */
    public static Pose cubic(Pose p0, Pose p1, Pose p2, Pose p3, float t0, float t1, float t2, float t3, float u) {
        Pose a = p0 != null ? p0 : p1, d = p3 != null ? p3 : p2;
        float ta = p0 != null ? t0 : t1, td = p3 != null ? t3 : t2;
        Pose r = lerp(p1, p2, u);   // booleans and unset values
        boolean s0 = p0 == null, s3 = p3 == null;
        r.turn = h(s0 ? NAN : a.turn, p1.turn, p2.turn, s3 ? NAN : d.turn, ta, t1, t2, td, u);
        r.lean = h(s0 ? NAN : a.lean, p1.lean, p2.lean, s3 ? NAN : d.lean, ta, t1, t2, td, u);
        for (int i = 0; i < BONES.length; i++) {
            for (int k = 0; k < 3; k++) {
                r.rot[i][k] = h(s0 ? NAN : a.rot[i][k], p1.rot[i][k], p2.rot[i][k], s3 ? NAN : d.rot[i][k], ta, t1, t2, td, u);
                r.pos[i][k] = h(s0 ? NAN : a.pos[i][k], p1.pos[i][k], p2.pos[i][k], s3 ? NAN : d.pos[i][k], ta, t1, t2, td, u);
            }
        }
        for (int k = 0; k < 2; k++) {
            r.wrist[k] = h(s0 ? NAN : a.wrist[k], p1.wrist[k], p2.wrist[k], s3 ? NAN : d.wrist[k], ta, t1, t2, td, u);
            r.roll[k] = h(s0 ? NAN : a.roll[k], p1.roll[k], p2.roll[k], s3 ? NAN : d.roll[k], ta, t1, t2, td, u);
        }
        return r;
    }

    // ------------------------------------------------------------------------------------------------ json in
    /** Parses a pose object. `lookup` resolves the name in "extends" / "pose" to an unbaked pose. Throws on typos. */
    public static Pose fromJson(JsonObject o, Function<String, Pose> lookup) {
        for (String key : o.keySet()) {
            if (!key.startsWith("_") && !TOP_KEYS.contains(key)) {
                throw new IllegalArgumentException("unknown key '" + key + "'");
            }
        }
        String base = str(o, "extends");
        if (base == null) base = str(o, "pose");
        Pose p = base != null ? lookup.apply(base).copy() : new Pose();

        if (has(o, "turn")) p.turn = o.get("turn").getAsFloat();
        if (has(o, "lean")) p.lean = o.get("lean").getAsFloat();
        if (has(o, "breath")) p.breath = o.get("breath").getAsFloat();
        if (has(o, "blend")) p.blend = o.get("blend").getAsFloat();
        if (has(o, "ground")) p.ground = o.get("ground").getAsBoolean();

        if (has(o, "bones")) {
            for (Map.Entry<String, JsonElement> e : o.getAsJsonObject("bones").entrySet()) {
                if (e.getKey().startsWith("_")) continue;
                int i = boneIndex(e.getKey());
                if (i < 0) {
                    throw new IllegalArgumentException("unknown bone '" + e.getKey() + "' (valid: " + String.join(", ", BONES) + ")");
                }
                JsonObject b = e.getValue().getAsJsonObject();
                for (String key : b.keySet()) {
                    if (!key.startsWith("_") && !BONE_KEYS.contains(key)) {
                        throw new IllegalArgumentException("unknown key '" + key + "' in bone '" + e.getKey() + "'");
                    }
                }
                readVec(b.get("rot"), p.rot[i]);
                readVec(b.get("pos"), p.pos[i]);
                readVec(b.get("vanilla"), p.vanilla[i]);
            }
        }
        readItem(o, "main_item", 0, p);
        readItem(o, "off_item", 1, p);
        return p;
    }

    private static void readItem(JsonObject o, String key, int h, Pose p) {
        if (!has(o, key)) return;
        JsonObject it = o.getAsJsonObject(key);
        for (String k : it.keySet()) {
            if (!k.startsWith("_") && !ITEM_KEYS.contains(k)) {
                throw new IllegalArgumentException("unknown key '" + k + "' in " + key);
            }
        }
        // setting either wrist or pitch_down replaces both, so an explicit wrist beats an inherited pitch_down
        if (it.has("wrist") || it.has("pitch_down")) {
            p.wrist[h] = it.has("wrist") ? it.get("wrist").getAsFloat() : NAN;
            p.pitchDown[h] = it.has("pitch_down") ? it.get("pitch_down").getAsFloat() : NAN;
        }
        if (it.has("blade")) {
            String blade = it.get("blade").getAsString();
            if (!blade.equals("forward") && !blade.equals("back")) throw new IllegalArgumentException("blade must be \"forward\" or \"back\"");
            p.bladeBack[h] = blade.equals("back");
        }
        if (it.has("arm_raise")) p.armRaise[h] = it.get("arm_raise").getAsFloat();
        if (it.has("roll")) p.roll[h] = it.get("roll").getAsFloat();
        if (it.has("clear_floor")) p.clearFloor[h] = it.get("clear_floor").getAsBoolean();
        if (it.has("tip_clearance")) p.tipClearance[h] = it.get("tip_clearance").getAsFloat();
    }

    private static boolean has(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull();
    }

    private static String str(JsonObject o, String k) {
        return has(o, k) ? o.get(k).getAsString() : null;
    }

    private static void readVec(JsonElement e, float[] dst) {
        if (e == null || e.isJsonNull()) return;
        if (e.isJsonPrimitive()) {
            Arrays.fill(dst, e.getAsFloat());
            return;
        }
        JsonArray a = e.getAsJsonArray();
        for (int i = 0; i < 3 && i < a.size(); i++) {
            if (!a.get(i).isJsonNull()) dst[i] = a.get(i).getAsFloat();
        }
    }

    // ------------------------------------------------------------------------------------------------ json out
    private static double r2(float v) {
        return Math.round(v * 100.0) / 100.0;
    }

    private static void put(JsonObject o, String k, float v) {
        if (!Float.isNaN(v)) o.addProperty(k, r2(v));
    }

    private static void putVec(JsonObject o, String k, float[] v) {
        if (Float.isNaN(v[0]) && Float.isNaN(v[1]) && Float.isNaN(v[2])) return;
        JsonArray a = new JsonArray();
        for (float f : v) a.add(Float.isNaN(f) ? JsonNull.INSTANCE : new JsonPrimitive(r2(f)));
        o.add(k, a);
    }

    /** Only the values that are set, in the same format fromJson reads: paste it straight into a pose file. */
    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        put(o, "turn", turn);
        put(o, "lean", lean);
        put(o, "breath", breath);
        if (ground != null) o.addProperty("ground", ground);
        JsonObject bones = new JsonObject();
        for (int i = 0; i < BONES.length; i++) {
            JsonObject b = new JsonObject();
            putVec(b, "rot", rot[i]);
            putVec(b, "pos", pos[i]);
            putVec(b, "vanilla", vanilla[i]);
            if (b.size() > 0) bones.add(BONES[i], b);
        }
        if (bones.size() > 0) o.add("bones", bones);
        itemJson(o, "main_item", 0);
        itemJson(o, "off_item", 1);
        return o;
    }

    private void itemJson(JsonObject o, String key, int h) {
        JsonObject it = new JsonObject();
        if (!Float.isNaN(pitchDown[h])) put(it, "pitch_down", pitchDown[h]);
        else put(it, "wrist", wrist[h]);
        if (bladeBack[h] != null) it.addProperty("blade", bladeBack[h] ? "back" : "forward");
        put(it, "arm_raise", armRaise[h]);
        put(it, "roll", roll[h]);
        if (clearFloor[h] != null) it.addProperty("clear_floor", clearFloor[h]);
        put(it, "tip_clearance", tipClearance[h]);
        if (it.size() > 0) o.add(key, it);
    }
}
