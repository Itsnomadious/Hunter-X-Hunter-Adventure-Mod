package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.hxhadventure.addon.HideSeekPortalEntity;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Draws a Hide and Seek circle: two glowing layers of symbols (the rune ring and the star with its eye) lying on the block face and
 * turning slowly in opposite directions. Only drawn for a player who has Gyo on. Full-bright, so it shows in the dark. An exit circle is tinted violet-white.
 */
public class HideSeekPortalRenderer extends EntityRenderer<HideSeekPortalEntity> {
    private static final ResourceLocation OUTER = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/hide_seek_circle_outer.png");
    private static final ResourceLocation INNER = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/hide_seek_circle_inner.png");

    public HideSeekPortalRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public ResourceLocation getTextureLocation(HideSeekPortalEntity entity) {
        return OUTER;
    }

    @Override
    public void render(HideSeekPortalEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        if (!net.hxhadventure.addon.ClientAddonState.gyo) return; // the circles are hidden Nen: only Gyo shows them
        float time = e.tickCount + pt;
        float r = 1f, g = 1f, b = 1f;
        if (e.isExit()) { // the way out looks a little different from the ways in
            r = 0.85f;
            g = 0.75f;
            b = 1f;
        }
        float appear = Math.min(1f, time / 8f); // the circle is drawn in over a third of a second

        ps.pushPose();
        orient(ps, e.facing());
        float half = 1.0f * (0.6f + 0.4f * appear);
        quad(buf, ps, OUTER, half, time * 1.5f, 0.00f, r, g, b, appear);
        quad(buf, ps, INNER, half, -time * 2.5f, 0.01f, r, g, b, appear);
        ps.popPose();
    }

    /** Turns the pose so that +Z (the way a flat quad faces) points out of the block face. */
    private static void orient(PoseStack ps, Direction f) {
        switch (f) {
            case EAST -> ps.mulPose(Axis.YP.rotationDegrees(90));
            case WEST -> ps.mulPose(Axis.YP.rotationDegrees(-90));
            case NORTH -> ps.mulPose(Axis.YP.rotationDegrees(180));
            case UP -> ps.mulPose(Axis.XP.rotationDegrees(-90));
            case DOWN -> ps.mulPose(Axis.XP.rotationDegrees(90));
            default -> { } // SOUTH
        }
    }

    private static void quad(MultiBufferSource buf, PoseStack ps, ResourceLocation tex, float half, float spinDeg, float z,
                             float r, float g, float b, float a) {
        ps.pushPose();
        ps.mulPose(Axis.ZP.rotationDegrees(spinDeg));
        VertexConsumer vc = buf.getBuffer(RenderType.entityTranslucentEmissive(tex));
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        vertex(vc, m, n, -half, -half, z, 0f, 1f, r, g, b, a);
        vertex(vc, m, n, half, -half, z, 1f, 1f, r, g, b, a);
        vertex(vc, m, n, half, half, z, 1f, 0f, r, g, b, a);
        vertex(vc, m, n, -half, half, z, 0f, 0f, r, g, b, a);
        ps.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z, float u, float v,
                               float r, float g, float b, float a) {
        vc.vertex(m, x, y, z).color(r, g, b, a).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY)
            .uv2(LightTexture.FULL_BRIGHT).normal(n, 0f, 0f, 1f).endVertex();
    }
}
