package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.hxhadventure.addon.ChrolloEntity;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;

/**
 * Bandit's Secret in Chrollo's hands: the Skill Hunter book, open, held in front of his chest while it is out (he conjures it when he is
 * attacked). Drawn with the same model and texture as the player's book (BookModel); hidden while Convert Hands has him disguised as a Bystander.
 * Where it sits is set by the three numbers below.
 */
public class ChrolloBookLayer extends RenderLayer<ChrolloEntity, NpcModel<ChrolloEntity>> {
    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/skill_hunter_book.png");
    private static final double HEIGHT = 1.05, FORWARD = 0.42;   // blocks above his feet / in front of his body
    private static final float SCALE = 0.55f;                    // 1.0 = the book as big as the item model's frame
    private static final float TILT = 25f;                       // degrees the top of the book leans back toward him

    private BookModel.Parts parts;

    public ChrolloBookLayer(RenderLayerParent<ChrolloEntity, NpcModel<ChrolloEntity>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int packedLight, ChrolloEntity npc, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!npc.isBookOut() || npc.isDisguised() || npc.isInvisible()) return;
        if (parts == null) parts = BookModel.bake(Minecraft.getInstance());

        float rad = (float) Math.toRadians(BookRenderer.OPEN_ANGLE);
        int packedOverlay = net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY;
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEX));
        ps.pushPose();
        // the vanilla model space has its origin 1.5 blocks above the feet with +Y down: turn it into "above his feet, +Y up"
        ps.translate(0.0, 1.5, 0.0);
        ps.scale(1f, -1f, 1f);
        // the model's front is -Z here: the book hangs in front of him with its pages toward him
        ps.translate(0.0, HEIGHT, -FORWARD);
        ps.mulPose(Axis.XP.rotationDegrees(TILT));
        ps.scale(SCALE, -SCALE, -SCALE); // book model space has +Y down and its pages on -Z

        parts.right().x = 0f;
        parts.left().x = 0f;
        parts.right().yRot = rad;
        parts.left().yRot = -rad;
        parts.right().render(ps, vc, packedLight, packedOverlay);
        parts.left().render(ps, vc, packedLight, packedOverlay);
        parts.spine().render(ps, vc, packedLight, packedOverlay);
        ps.popPose();
    }
}
