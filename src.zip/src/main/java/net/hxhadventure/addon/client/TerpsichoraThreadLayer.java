package net.hxhadventure.addon.client;

import java.util.function.Function;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

/** One thread from every claw tip (5 per hand) to the user's arm, like puppet strings. */
public class TerpsichoraThreadLayer<T extends Entity & GeoAnimatable> extends GeoRenderLayer<T> {
    // Claw tips in GeckoLib pose space (blocks): x already flipped, generated from the model.
    // The hands never move, so these are constants.
    private static final Vec3[] LEFT_HAND = {
            new Vec3(-0.8537, 3.1374, -2.3892),
            new Vec3(-0.9878, 3.1068, -2.4377),
            new Vec3(-1.1251, 3.1068, -2.4232),
            new Vec3(-1.2463, 3.1374, -2.3479),
            new Vec3(-0.5813, 3.2424, -2.0429)
    };
    private static final Vec3[] RIGHT_HAND = {
            new Vec3(1.2463, 3.1374, -2.3479),
            new Vec3(1.1251, 3.1068, -2.4232),
            new Vec3(0.9878, 3.1068, -2.4377),
            new Vec3(0.8537, 3.1374, -2.3892),
            new Vec3(0.5813, 3.2424, -2.0429)
    };

    private final Function<T, LivingEntity> ownerGetter;

    public TerpsichoraThreadLayer(GeoRenderer<T> renderer, Function<T, LivingEntity> ownerGetter) {
        super(renderer);
        this.ownerGetter = ownerGetter;
    }

    @Override
    public void render(PoseStack pose, T self, BakedGeoModel model, RenderType type, MultiBufferSource buffers,
                       VertexConsumer buf, float pt, int light, int overlay) {
        LivingEntity owner = ownerGetter.apply(self);
        if (owner == null || !owner.isAlive()) return;

        double sx = Mth.lerp(pt, self.xo, self.getX()), sy = Mth.lerp(pt, self.yo, self.getY()), sz = Mth.lerp(pt, self.zo, self.getZ());
        double ox = Mth.lerp(pt, owner.xo, owner.getX()), oy = Mth.lerp(pt, owner.yo, owner.getY()), oz = Mth.lerp(pt, owner.zo, owner.getZ());
        float selfYaw = self instanceof LivingEntity le ? Mth.rotLerp(pt, le.yBodyRotO, le.yBodyRot) : self.getYRot();
        float ownerYaw = Mth.rotLerp(pt, owner.yBodyRotO, owner.yBodyRot);

        // pose stack is in the model's space: the entity is rotated by (180 - yaw) about Y
        Quaternionf inv = new Quaternionf().rotationY((float) -Math.toRadians(180.0F - selfYaw));
        Vec3 delta = new Vec3(ox - sx, oy - sy, oz - sz);

        // The user's arms are raised straight out to the sides while Terpsichora is out (the player pose from TerpsichoraFx, and Neferpitou's
        // "terp_arms" clip). Real shoulder pivots: x +-5/16, y 22/16 of the model, which a vanilla player draws at 15/16 size and the
        // GeckoLib NPC at full size. The arm is 10/16 long beyond the pivot.
        double yr = Math.toRadians(ownerYaw);
        double lx = Math.cos(yr),  lz = Math.sin(yr);       // user left
        boolean npc = !(owner instanceof net.minecraft.world.entity.player.Player);
        double sc = npc ? 1.0 : 0.9375;
        double shX = 0.3125 * sc, shY = 1.375 * sc, reach = 0.625 * sc;
        if (!npc && owner.isShiftKeyDown()) shY -= 0.2;
        Vec3 leftShoulder  = new Vec3(delta.x + lx * shX, delta.y + shY, delta.z + lz * shX);
        Vec3 rightShoulder = new Vec3(delta.x - lx * shX, delta.y + shY, delta.z - lz * shX);
        Vec3 outLeft = new Vec3(lx, 0, lz), outRight = new Vec3(-lx, 0, -lz);

        Vec3 leftHandCenter  = center(LEFT_HAND);
        Vec3 rightHandCenter = center(RIGHT_HAND);
        Vec3 la = to(inv, leftShoulder), ra = to(inv, rightShoulder);
        // each hand strings to whichever of the user's arms is closer
        boolean straight = leftHandCenter.distanceToSqr(la) + rightHandCenter.distanceToSqr(ra)
                        <= leftHandCenter.distanceToSqr(ra) + rightHandCenter.distanceToSqr(la);

        VertexConsumer vc = buffers.getBuffer(RenderType.lightning());
        Matrix4f m = pose.last().pose();
        drawHand(vc, m, LEFT_HAND,  straight ? leftShoulder : rightShoulder,  straight ? outLeft : outRight,  inv, reach);
        drawHand(vc, m, RIGHT_HAND, straight ? rightShoulder : leftShoulder, straight ? outRight : outLeft, inv, reach);
    }

    private static Vec3 to(Quaternionf inv, Vec3 v) {
        org.joml.Vector3f r = new org.joml.Vector3f((float) v.x, (float) v.y, (float) v.z); inv.transform(r);
        return new Vec3(r.x, r.y, r.z);
    }
    private static Vec3 center(Vec3[] pts) {
        Vec3 c = Vec3.ZERO; for (Vec3 p : pts) c = c.add(p); return c.scale(1.0 / pts.length);
    }

    /** Five threads per hand, spread along the length of the raised arm from just outside the shoulder to the hand. */
    private void drawHand(VertexConsumer vc, Matrix4f m, Vec3[] tips, Vec3 shoulderWorld, Vec3 outWorld, Quaternionf inv, double reach) {
        for (int i = 0; i < tips.length; i++) {
            double t = tips.length == 1 ? 0 : i / (double) (tips.length - 1);
            Vec3 target = to(inv, shoulderWorld.add(outWorld.scale(0.06 + (reach - 0.06) * t)));
            thread(vc, m, tips[i], target);
        }
    }

    /** Thin double-sided crossed ribbon with a little sag, soft red-white glow. */
    private static void thread(VertexConsumer vc, Matrix4f m, Vec3 a, Vec3 b) {
        final int N = 14; final float w = 0.012f;
        Vec3 prev = a;
        for (int i = 1; i <= N; i++) {
            double t = i / (double) N;
            Vec3 p = a.lerp(b, t).add(0, -Math.sin(Math.PI * t) * 0.18, 0);
            Vec3 d = p.subtract(prev).normalize();
            Vec3 n1 = d.cross(new Vec3(0, 1, 0)); if (n1.lengthSqr() < 1e-6) n1 = d.cross(new Vec3(1, 0, 0));
            n1 = n1.normalize().scale(w);
            Vec3 n2 = d.cross(n1).normalize().scale(w);
            quad(vc, m, prev, p, n1); quad(vc, m, prev, p, n2);
            prev = p;
        }
    }
    private static void quad(VertexConsumer vc, Matrix4f m, Vec3 a, Vec3 b, Vec3 n) {
        int r = 255, g = 190, bl = 200, al = 200;
        float[][] v = {{(float)(a.x-n.x),(float)(a.y-n.y),(float)(a.z-n.z)},{(float)(a.x+n.x),(float)(a.y+n.y),(float)(a.z+n.z)},
                       {(float)(b.x+n.x),(float)(b.y+n.y),(float)(b.z+n.z)},{(float)(b.x-n.x),(float)(b.y-n.y),(float)(b.z-n.z)}};
        for (int k = 0; k < 4; k++) vc.vertex(m, v[k][0], v[k][1], v[k][2]).color(r, g, bl, al).endVertex();
        for (int k = 3; k >= 0; k--) vc.vertex(m, v[k][0], v[k][1], v[k][2]).color(r, g, bl, al).endVertex(); // back face
    }
}
