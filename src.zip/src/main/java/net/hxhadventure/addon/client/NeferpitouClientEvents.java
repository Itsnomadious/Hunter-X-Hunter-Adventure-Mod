package net.hxhadventure.addon.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.GonVow;
import net.hxhadventure.addon.HxHEntities;
import net.hxhadventure.addon.Jajanken;
import net.hxhadventure.addon.UseEverything;

/**
 * Renderers for Neferpitou and Terpsichora, and the H key for "I'll use everything" (client only).
 * H must be HELD for {@link #HOLD_TICKS} (2 s) before the vow is activated or deactivated; letting go early cancels it.
 */
public final class NeferpitouClientEvents {
    private NeferpitouClientEvents() {}

    /** How long H has to be held before the vow switches on or off. */
    public static final int HOLD_TICKS = 40;

    public static final KeyMapping USE_EVERYTHING = new KeyMapping("key.hxhadventure.nen_hatsu",
        KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, 72 /* GLFW_KEY_H */, "key.category.hxhadventure");

    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerEntityRenderer(HxHEntities.NEFERPITOU.get(), NeferpitouRenderer::new);
            e.registerEntityRenderer(HxHEntities.TERPSICHORA.get(), TerpsichoraRenderer::new);
        }

        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) {
            e.register(USE_EVERYTHING);
        }
    }

    @Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class Game {
        private static int held;
        private static boolean fired;

        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            while (USE_EVERYTHING.consumeClick()) { /* the press itself does nothing: only a 2 s hold counts */ }
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || !USE_EVERYTHING.isDown()) {
                held = 0;
                fired = false;
                return;
            }
            if (fired) return; // already switched: release H before it can switch again
            held++;
            Combat c = Combat.get(mc.player);
            // Godspeed, Emperor Time, the Guanyin, Terpsichora, Nen Threads and Skill Hunter's book are plain presses; only Gon's vow needs the 2 s hold
            boolean plainPress = c != null && (net.hxhadventure.addon.LightningAura.canUse(c)
                || net.hxhadventure.addon.Hakoware.canUse(c)
                || net.hxhadventure.addon.PainPacker.canUse(c)
                || net.hxhadventure.addon.Blinky.canUse(c)
                || net.hxhadventure.addon.CrazySlots.canUse(c)
                || net.hxhadventure.addon.NenStitches.canUse(c)
                || net.hxhadventure.addon.LittleFlower.canUse(c)
                || net.hxhadventure.addon.ChainManager.canUseChains(c)
                || net.hxhadventure.addon.Guanyin.canUse(c)
                || net.hxhadventure.addon.Terpsichora.canUse(c)
                || net.hxhadventure.addon.BungeeGum.canUse(c)
                || net.hxhadventure.addon.BlackVoice.canUse(c)
                || net.hxhadventure.addon.SkillHunter.isHunter(mc.player, c));
            boolean returning = mc.player.isShiftKeyDown() && DisguiseHandler.resizeBody(mc.player) != null; // Shift+H in a Black Voice body: an instant press
            int need = plainPress || returning ? 1 : HOLD_TICKS;
            if (held >= need) {
                fired = true;
                UseEverything.CHANNEL.sendToServer(new UseEverything.Press());
                return;
            }
            if (c != null && net.hxhadventure.addon.MagicalEsthetician.canUse(c) && held % 2 == 0) {
                String what = net.hxhadventure.addon.MagicalEsthetician.isForm(mc.player) ? "Returning to normal" : "Body Transformation";
                int pct = held * 100 / HOLD_TICKS;
                mc.player.displayClientMessage(Component.literal("\u00a7d" + what + "... " + pct + "% \u00a77(keep holding H)"), true);
            }
            if (c != null && Jajanken.canUse(c) && held % 2 == 0) {
                String what = GonVow.isActive(mc.player) ? "Letting the vow go" : "Gathering the vow";
                int pct = held * 100 / HOLD_TICKS;
                mc.player.displayClientMessage(Component.literal("\u00a76" + what + "... " + pct + "% \u00a77(keep holding H)"), true);
            }
        }
    }
}
