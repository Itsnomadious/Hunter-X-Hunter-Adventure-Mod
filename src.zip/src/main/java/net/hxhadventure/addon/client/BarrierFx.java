package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.BarrierPose;
import net.hxhadventure.entity.custom.AuraEntity;

/**
 * The Bungee Barrier's body: a wide stance, lowered a little; the hands come together in front of the chest and then pull apart vertically
 * (right hand up, left hand down, both still in a line in front of the body), and the user holds that pose until the barrier is released.
 * The timeline (and the aura stretched between the hands) is {@link BarrierPose}, driven by the age of the barrier's dough aura.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class BarrierFx {
    private BarrierFx() {}

    private static final float LEG_SPLAY = 0.70f;      // radians each leg swings out: 0.75 * (1 - cos 0.7) = BarrierPose.STANCE_DROP
    private static final float ARM_FORWARD = -1.50f;   // both arms straight out in front
    private static final float ARM_IN = 0.50f;         // turned inward so the hands meet in the middle
    private static final float ARM_PART = 0.35f;       // extra angle as the hands part (right up, left down)
    private static final float SHOULDER_PART = 2.5f;   // and the shoulders' pivots move this far (pixels), so the arms stay parallel

    /** The barrier's dough aura for this player, or null (also forgets one that has gone). */
    private static AuraEntity find(int owner) {
        AuraEntity a = BarrierPose.CLIENT.get(owner);
        if (a == null) return null;
        if (a.isRemoved() || !a.isAlive()) {
            BarrierPose.CLIENT.remove(owner);
            return null;
        }
        return a;
    }

    private static double age(AuraEntity a) {
        return a.tickCount + Minecraft.getInstance().getFrameTime();
    }

    // ---------------------------------------------------------------- the model

    public static void applyPose(PlayerModel<?> model, LivingEntity entity) {
        if (BarrierPose.CLIENT.isEmpty() || !(entity instanceof AbstractClientPlayer p)) return;
        AuraEntity a = find(p.getId());
        if (a == null) return;
        double age = age(a);
        float g = (float) BarrierPose.gather(age);
        float part = (float) BarrierPose.part(age);
        float st = (float) BarrierPose.stance(age);

        // arms: out in front and turned in until the hands meet, then the right one rises and the left one falls
        model.rightArm.xRot = Mth.lerp(g, model.rightArm.xRot, ARM_FORWARD - ARM_PART * part);
        model.rightArm.yRot = Mth.lerp(g, model.rightArm.yRot, -ARM_IN);
        model.rightArm.zRot = Mth.lerp(g, model.rightArm.zRot, 0f);
        model.leftArm.xRot = Mth.lerp(g, model.leftArm.xRot, ARM_FORWARD + ARM_PART * part);
        model.leftArm.yRot = Mth.lerp(g, model.leftArm.yRot, ARM_IN);
        model.leftArm.zRot = Mth.lerp(g, model.leftArm.zRot, 0f);
        model.rightArm.y = 2.0f - SHOULDER_PART * part;
        model.leftArm.y = 2.0f + SHOULDER_PART * part;
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);

        // legs: a wide stance (the body itself is lowered to match in onPre)
        model.rightLeg.xRot = Mth.lerp(st, model.rightLeg.xRot, 0f);
        model.rightLeg.yRot = Mth.lerp(st, model.rightLeg.yRot, 0f);
        model.rightLeg.zRot = Mth.lerp(st, model.rightLeg.zRot, LEG_SPLAY);
        model.leftLeg.xRot = Mth.lerp(st, model.leftLeg.xRot, 0f);
        model.leftLeg.yRot = Mth.lerp(st, model.leftLeg.yRot, 0f);
        model.leftLeg.zRot = Mth.lerp(st, model.leftLeg.zRot, -LEG_SPLAY);
        model.rightPants.copyFrom(model.rightLeg);
        model.leftPants.copyFrom(model.leftLeg);
    }

    private static final Set<Integer> LOWERED = new HashSet<>();

    @SubscribeEvent
    public static void onPre(RenderPlayerEvent.Pre e) {
        if (BarrierPose.CLIENT.isEmpty()) return;
        AuraEntity a = find(e.getEntity().getId());
        if (a == null) return;
        double drop = BarrierPose.drop(age(a));
        if (drop <= 0.0) return;
        e.getPoseStack().pushPose();
        e.getPoseStack().translate(0, -drop, 0);
        LOWERED.add(e.getEntity().getId());
    }

    @SubscribeEvent
    public static void onPost(RenderPlayerEvent.Post e) {
        if (LOWERED.remove(e.getEntity().getId())) e.getPoseStack().popPose();
    }

    // ---------------------------------------------------------------- first person

    /**
     * First person: both hands are drawn the way the praying hands are (PrayFx.onHand: wrists meeting at the centre of the view), then the
     * right hand rises and the left falls as they part.
     */
    @SubscribeEvent
    public static void onHand(RenderHandEvent e) {
        if (BarrierPose.CLIENT.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        AbstractClientPlayer p = mc.player;
        if (p == null || mc.level == null || p.isInvisible()) return;
        AuraEntity a = find(p.getId());
        if (a == null) return;
        e.setCanceled(true); // neither hand is drawn the normal way, and the held item is put away while the barrier stands
        if (e.getHand() != InteractionHand.MAIN_HAND) return;
        EntityRenderer<?> r = mc.getEntityRenderDispatcher().getRenderer(p);
        if (!(r instanceof PlayerRenderer pr)) return;
        double age = a.tickCount + e.getPartialTick();
        float w = (float) BarrierPose.gather(age);
        float part = (float) BarrierPose.part(age);
        PoseStack ps = e.getPoseStack();
        for (int side = 1; side >= -1; side -= 2) {
            float f = side;
            ps.pushPose();
            ps.translate(f * lerp(w, 0.64, 0.362), lerp(w, -1.0, -0.616) + f * 0.30f * part, lerp(w, -0.72, -0.703));
            ps.mulPose(Axis.YP.rotationDegrees(f * lerp(w, 45.0, 117.2)));
            ps.mulPose(Axis.XP.rotationDegrees(lerp(w, 0.0, 21.7)));
            ps.translate(f * -1.0F, 3.6F, 3.5F);
            ps.mulPose(Axis.ZP.rotationDegrees(f * 120.0F));
            ps.mulPose(Axis.XP.rotationDegrees(200.0F));
            ps.mulPose(Axis.YP.rotationDegrees(f * -135.0F));
            ps.translate(f * 5.6F, 0.0F, 0.0F);
            if (side == 1) pr.renderRightHand(ps, e.getMultiBufferSource(), e.getPackedLight(), p);
            else pr.renderLeftHand(ps, e.getMultiBufferSource(), e.getPackedLight(), p);
            ps.popPose();
        }
    }

    private static float lerp(double t, double a, double b) {
        return (float) (a + (b - a) * Mth.clamp(t, 0, 1));
    }
}
