package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.hxhadventure.addon.KatanaItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.joml.Quaternionf;

/**
 * Draws the sheathed Katana on the player's LEFT HIP, edge up, hilt forward, instead of in the hand. The in-hand display transforms of
 * katana_sheathed.json are shrunk to nothing, so the item only shows on the hip (and still shows normally in the inventory, on the ground,
 * in frames).
 *
 * <p>Layer space: x = character's left, y = down, z = back, origin = top of the torso.
 */
public class KatanaHipLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final float HIP_X = 0.330000f, HIP_Y = 0.700000f, HIP_Z = -0.100000f;   // where the guard sits
    private static final float SCALE = 0.850000f;
    private static final float QX = 0.579228f, QY = 0.405580f, QZ = 0.579228f, QW = 0.405580f;     // blade orientation
    private static final float PX = 0.388235f, PY = 0.372006f, PZ = 0.500000f;             // guard position in the OBJ model

    public KatanaHipLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (KatanaItems.KATANA_SHEATHED == null) return;
        ItemStack stack = ItemStack.EMPTY;
        if (player.getMainHandItem().is(KatanaItems.KATANA_SHEATHED)) {
            stack = player.getMainHandItem();
        } else if (player.getOffhandItem().is(KatanaItems.KATANA_SHEATHED)) {
            stack = player.getOffhandItem();
        }
        if (stack.isEmpty()) return;

        pose.pushPose();
        getParentModel().body.translateAndRotate(pose);      // follows sneaking / body turn
        pose.translate(HIP_X, HIP_Y, HIP_Z);
        pose.mulPose(new Quaternionf(QX, QY, QZ, QW));
        pose.scale(SCALE, SCALE, SCALE);
        pose.translate(-(PX - 0.5f), -(PY - 0.5f), -(PZ - 0.5f));
        Minecraft.getInstance().getItemRenderer().renderStatic(player, stack, ItemDisplayContext.NONE, false,
                pose, buffers, player.level(), light, OverlayTexture.NO_OVERLAY, player.getId());
        pose.popPose();
    }
}
