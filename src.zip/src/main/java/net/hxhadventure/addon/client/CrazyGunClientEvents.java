package net.hxhadventure.addon.client;

import net.hxhadventure.addon.CrazyGunItem;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Makes the Crazy Slots gun pop in whenever it comes into your main hand (conjured, or switched to), like HxH Craft's shotgun does.
 * Only a change of ITEM counts: the carbine's ammo count changes with every shot, and that must not replay the animation.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class CrazyGunClientEvents {
    private CrazyGunClientEvents() {}

    private static Item lastHeld = null;

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player != Minecraft.getInstance().player) return;
        ItemStack held = e.player.getItemBySlot(EquipmentSlot.MAINHAND);
        Item now = held.isEmpty() ? null : held.getItem();
        if (now != lastHeld) {
            lastHeld = now;
            if (now instanceof CrazyGunItem) held.getOrCreateTag().putBoolean(CrazyGunItem.APPEAR_TAG, true);
        }
    }
}
