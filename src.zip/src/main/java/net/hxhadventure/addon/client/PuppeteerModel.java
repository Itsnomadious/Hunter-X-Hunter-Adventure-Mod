package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * The Puppeteer's solid parts (same conventions as {@link TerpsichoraModel}: pixel units drawn at 2x, boxes have their
 * origin at the BOTTOM CENTRE, front toward +Z once flipped). Sleeves, discs, bones, horns and strings are 1px "stick"
 * parts stretched between two points. Texture sheet 128x128: textures/entity/puppeteer.png
 * (see tools/make_puppeteer_texture.py).
 */
public final class PuppeteerModel {
    private PuppeteerModel() {}

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("hxhadventure", "puppeteer"), "main");

    public record Parts(ModelPart torso, ModelPart lower, ModelPart head, ModelPart palm,
                        ModelPart green, ModelPart maroon, ModelPart inner, ModelPart yellow, ModelPart bone, ModelPart tip,
                        ModelPart purple, ModelPart pink, ModelPart red, ModelPart string, ModelPart glow, ModelPart dkGreen) {}

    private static CubeListBuilder stick(int u, int v) {
        return CubeListBuilder.create().texOffs(u, v).addBox(-0.5f, -0.5f, 0f, 1f, 1f, 1f);
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(0, 0).addBox(-8f, -14f, -6f, 16f, 14f, 12f), PartPose.ZERO);
        root.addOrReplaceChild("lower", CubeListBuilder.create().texOffs(60, 0).addBox(-6f, -6f, -4.5f, 12f, 6f, 9f), PartPose.ZERO);
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 40).addBox(-6f, -10f, -4.5f, 12f, 10f, 9f), PartPose.ZERO);
        root.addOrReplaceChild("palm", CubeListBuilder.create().texOffs(60, 40).addBox(-3f, -6f, -1f, 6f, 6f, 2f), PartPose.ZERO);
        String[] names = {"green", "maroon", "inner", "yellow", "bone", "tip", "purple", "pink", "red", "string", "glow", "dkgreen"};
        for (int i = 0; i < names.length; i++) root.addOrReplaceChild(names[i], stick(8 * i, 96), PartPose.ZERO);
        return LayerDefinition.create(mesh, 128, 128);
    }

    private static Parts cached;

    public static Parts parts(Minecraft mc) {
        if (cached == null) {
            ModelPart r = mc.getEntityModels().bakeLayer(LAYER);
            cached = new Parts(r.getChild("torso"), r.getChild("lower"), r.getChild("head"), r.getChild("palm"),
                r.getChild("green"), r.getChild("maroon"), r.getChild("inner"), r.getChild("yellow"), r.getChild("bone"), r.getChild("tip"),
                r.getChild("purple"), r.getChild("pink"), r.getChild("red"), r.getChild("string"), r.getChild("glow"), r.getChild("dkgreen"));
        }
        return cached;
    }
}
