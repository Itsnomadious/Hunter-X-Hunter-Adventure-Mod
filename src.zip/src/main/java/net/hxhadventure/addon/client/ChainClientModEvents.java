package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ChainClientModEvents {
    private ChainClientModEvents() {}

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(ChainModel.LAYER, ChainModel::createLayer);
        e.registerLayerDefinition(BookModel.LAYER, BookModel::createLayer);
        e.registerLayerDefinition(BlytheModel.LAYER, BlytheModel::createLayer);
    }

    /** Emperor Time eyes, the Chains hand and Gon's hair anchor, on both player models (wide and slim arms). */
    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers e) {
        for (String skin : e.getSkins()) {
            PlayerRenderer r = e.getSkin(skin);
            if (r != null) {
                r.addLayer(new EmperorEyesLayer(r));
                r.addLayer(new ChainHandLayer(r));
                r.addLayer(new GonHairLayer(r));
                r.addLayer(new PainArmorLayer(r));
                r.addLayer(new LfHandLayer(r));
            }
        }
    }
}
