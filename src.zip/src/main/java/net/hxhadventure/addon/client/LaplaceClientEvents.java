package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.LaplaceDoubleEntity;

/** Client side of the Laplace Devil (game bus): hiding the real user / the double from the right viewers. Renderers: LaplaceClientModEvents. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class LaplaceClientEvents {
    private LaplaceClientEvents() {}

    /** Cancelling the render removes everything drawn with the body: skin, armour, held items, name tag, aura layers. */
    @SubscribeEvent
    public static void onRender(RenderLivingEvent.Pre<?, ?> e) {
        if (LaplaceFx.isEmpty()) return;
        Entity en = e.getEntity();
        if (en instanceof LaplaceDoubleEntity) {
            if (!LaplaceFx.showDouble(en.getId())) e.setCanceled(true);
        } else if (LaplaceFx.hideReal(en.getId())) {
            e.setCanceled(true);
        }
    }

    /**
     * A user hidden from us must leave no trace: running on blocks spawns sprint particles for as long as the game thinks they are
     * sprinting, so on this client they are never left sprinting.
     */
    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || LaplaceFx.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (int id : LaplaceFx.hiddenUsers()) {
            Entity en = mc.level.getEntity(id);
            if (en != null && en != mc.player && en.isSprinting()) en.setSprinting(false);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        LaplaceFx.clear();
    }
}
