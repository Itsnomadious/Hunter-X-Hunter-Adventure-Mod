package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * The clown of Crazy Slots, built in code at 2.5x detail (1 px = 1/16 block of a figure that is 76 px tall; the renderer scales it down to
 * the real size). Front is -Z, y grows downwards, the soles of the body are at y = 56 and the tip of the hat is at y = -20.
 * A big white head with a blue-patched left eye, a red nose and a wide dark mouth (the roulette: the renderer draws the number on it),
 * a purple hat band with a green cone marked "?", orange hair at the sides, a black body with a red collar, and two floating white gloves.
 * Texture: textures/entity/crazy_slots.png, drawn by tools/make_crazy_slots_assets.py (the offsets below are repeated there in ENTITY_UV).
 */
public final class CrazySlotsModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("hxhadventure", "crazy_slots"), "main");
    public static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/crazy_slots.png");
    /** Height of the figure in model px, hat tip to soles. */
    public static final float MODEL_HEIGHT_PX = 76f;
    /** Model y of the soles: the renderer puts this line on the ground. */
    public static final float FEET_Y = 56f;
    /** The roulette panel on the tongue, in model px: centre x, centre y, width, height, and the z of the face it sits on. */
    public static final float SCREEN_X = 0f, SCREEN_Y = 27.5f, SCREEN_W = 18f, SCREEN_H = 8f, SCREEN_Z = -16.06f;

    private final ModelPart root, head, handL, handR;

    public CrazySlotsModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.handL = root.getChild("hand_l");
        this.handR = root.getChild("hand_r");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-20f, 2f, -16f, 40f, 32f, 32f), PartPose.ZERO);
        root.addOrReplaceChild("hat_band", CubeListBuilder.create().texOffs(0, 64).addBox(-16f, -3f, -12f, 32f, 5f, 24f), PartPose.ZERO);
        root.addOrReplaceChild("hat_cone", CubeListBuilder.create().texOffs(112, 64).addBox(-10f, -16f, -9f, 20f, 13f, 18f), PartPose.ZERO);
        root.addOrReplaceChild("hat_tip", CubeListBuilder.create().texOffs(188, 64).addBox(-3f, -20f, -3f, 6f, 4f, 6f), PartPose.ZERO);
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 96).addBox(-12f, 36f, -9f, 24f, 20f, 18f), PartPose.ZERO);
        root.addOrReplaceChild("collar", CubeListBuilder.create().texOffs(84, 96).addBox(-15f, 33f, -12f, 30f, 6f, 24f), PartPose.ZERO);
        root.addOrReplaceChild("hair_l", CubeListBuilder.create().texOffs(0, 136).addBox(18f, 8f, -8f, 8f, 18f, 16f), PartPose.ZERO);
        root.addOrReplaceChild("hair_r", CubeListBuilder.create().texOffs(48, 136).addBox(-26f, 8f, -8f, 8f, 18f, 16f), PartPose.ZERO);
        root.addOrReplaceChild("nose", CubeListBuilder.create().texOffs(96, 136).addBox(-4f, 14f, -22f, 8f, 8f, 6f), PartPose.ZERO);

        for (int side = 0; side < 2; side++) {
            boolean left = side == 0;
            float sx = left ? 1f : -1f;
            // a floating glove beside the mouth: cuff, palm, and three fingers up
            PartDefinition hand = root.addOrReplaceChild(left ? "hand_l" : "hand_r", CubeListBuilder.create()
                    .texOffs(124, 136).addBox(-5f, -6f, -5f, 10f, 12f, 10f)
                    .texOffs(176, 136).addBox(-4f, 6f, -4f, 8f, 4f, 8f),
                PartPose.offsetAndRotation(sx * 31f, 22f, 0f, 0f, 0f, sx * -0.3f));
            for (int i = 0; i < 3; i++) {
                hand.addOrReplaceChild("finger" + i, CubeListBuilder.create().texOffs(164, 136).addBox(-4.9f + i * 3.4f, -15f, -1.5f, 3f, 9f, 3f), PartPose.ZERO);
            }
            hand.addOrReplaceChild("thumb", CubeListBuilder.create().texOffs(164, 136).addBox(sx > 0 ? -8.5f : 5.5f, -3f, -1.5f, 3f, 6f, 3f), PartPose.ZERO);
        }
        return LayerDefinition.create(mesh, 256, 256);
    }

    /** Draws the figure; the hands wave and the head sways. {@code time} is in ticks. */
    public void render(PoseStack ps, VertexConsumer vc, int light, int overlay, float time) {
        head.zRot = 0.03f * (float) Math.sin(time * 0.11);
        handL.zRot = -0.3f + 0.12f * (float) Math.sin(time * 0.23);
        handR.zRot = 0.3f - 0.12f * (float) Math.sin(time * 0.23 + 0.9);
        handL.y = 22f + 1.5f * (float) Math.sin(time * 0.19);
        handR.y = 22f + 1.5f * (float) Math.sin(time * 0.19 + 1.3);
        root.render(ps, vc, light, overlay);
    }
}
