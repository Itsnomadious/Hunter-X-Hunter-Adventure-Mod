package net.hxhadventure.addon.client.anim;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

/**
 * A timeline of poses, authored in assets/hxhadventure/pose_animations/*.json (see docs/ANIMATION.md). Times are client ticks. Every key is a full
 * pose (the animation's "base", or the pose it names, with the key's own values on top) so interpolation is always
 * pose-to-pose. Each key's ease shapes the segment that ENDS at that key.
 */
public final class Animation {
    public enum Ease {
        SMOOTH, LINEAR, IN, OUT, STEP;

        static Ease parse(String s) {
            if (s == null) return SMOOTH;
            switch (s) {
                case "linear": return LINEAR;
                case "in": return IN;
                case "out": return OUT;
                case "step": return STEP;
                case "smooth": return SMOOTH;
                default: throw new IllegalArgumentException("unknown ease '" + s + "' (smooth, linear, in, out, step)");
            }
        }

        float apply(float u) {
            switch (this) {
                case LINEAR: return u;
                case IN: return u * u;
                case OUT: return 1F - (1F - u) * (1F - u);
                case STEP: return u >= 1F ? 1F : 0F;
                default: return u * u * (3F - 2F * u);
            }
        }
    }

    private record Key(float time, Pose pose, Ease ease) {}

    public final float length;
    public final boolean loop;
    /** Stays on the last key after the end, until PoseDriver.stop() (a charge stance), instead of easing back to vanilla. */
    public final boolean hold;
    /** Ticks to cross-fade into this animation from the previous pose (-1 = default). */
    public final float blend;
    private final boolean spline;
    private final Key[] keys;

    private Animation(float length, boolean loop, boolean hold, float blend, boolean spline, List<Key> keys) {
        this.length = length;
        this.loop = loop;
        this.hold = hold;
        this.blend = blend;
        this.spline = spline;
        this.keys = keys.toArray(new Key[0]);
    }

    public static Animation fromJson(JsonObject o, Function<String, Pose> rawPose) {
        String base = o.has("base") ? o.get("base").getAsString() : null;   // no base: keys inherit vanilla for whatever they leave unset
        JsonArray arr = o.getAsJsonArray("keys");
        if (arr == null || arr.size() == 0) throw new IllegalArgumentException("animation has no keys");
        List<Key> keys = new ArrayList<>();
        for (JsonElement el : arr) {
            JsonObject k = el.getAsJsonObject();
            if (!k.has("time")) throw new IllegalArgumentException("a key is missing \"time\"");
            JsonObject src = (k.has("pose") || k.has("extends")) ? k : k.deepCopy();
            if (base != null && !src.has("pose") && !src.has("extends")) src.addProperty("pose", base);
            Pose p = Pose.fromJson(src, rawPose);
            PoseRig.bake(p);
            keys.add(new Key(k.get("time").getAsFloat(), p, Ease.parse(k.has("ease") ? k.get("ease").getAsString() : null)));
        }
        keys.sort(Comparator.comparingDouble(Key::time));
        float length = o.has("length") ? o.get("length").getAsFloat() : keys.get(keys.size() - 1).time();
        float blend = o.has("blend") ? o.get("blend").getAsFloat() : -1F;
        boolean spline = o.has("interp") && "spline".equals(o.get("interp").getAsString());
        return new Animation(length, o.has("loop") && o.get("loop").getAsBoolean(),
                o.has("hold") && o.get("hold").getAsBoolean(), blend, spline, keys);
    }

    /** The pose at tick t. May return a shared key pose: callers must copy before changing it. */
    public Pose sample(float t) {
        if (loop && length > 0F) t = t % length;
        if (t <= keys[0].time()) return keys[0].pose();
        for (int i = 1; i < keys.length; i++) {
            if (t <= keys[i].time()) {
                float u = (t - keys[i - 1].time()) / Math.max(1e-6F, keys[i].time() - keys[i - 1].time());
                if (spline && keys[i].ease() != Ease.STEP) {
                    Key k0 = i >= 2 ? keys[i - 2] : null, k3 = i + 1 < keys.length ? keys[i + 1] : null;
                    return Pose.cubic(k0 == null ? null : k0.pose(), keys[i - 1].pose(), keys[i].pose(), k3 == null ? null : k3.pose(),
                            k0 == null ? 0F : k0.time(), keys[i - 1].time(), keys[i].time(), k3 == null ? 0F : k3.time(), u);
                }
                return Pose.lerp(keys[i - 1].pose(), keys[i].pose(), keys[i].ease().apply(u));
            }
        }
        return keys[keys.length - 1].pose();
    }
}
