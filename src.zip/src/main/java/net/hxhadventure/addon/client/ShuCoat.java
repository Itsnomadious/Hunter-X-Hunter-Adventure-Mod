package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.hxhadventure.addon.ClientAddonState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * Shu visual: the item in hand is covered in the user's Ten, the same way HandChains covers the Chains: the thing is drawn again,
 * glowing, translucent and tinted with the wearer's aura colour, once at its own size and then slightly bigger twice with less alpha.
 * Called from ItemInHandRendererMixin after the game has drawn a held item, so it is in the exact pose the game used (first and third person).
 */
public final class ShuCoat {
    private ShuCoat() {}

    /** {scale around the item's centre, alpha}: a tight coat plus two wider, fainter halos (HandChains does 1.0 / 1.7 / 2.6 with small alphas). */
    private static final float[][] PASSES = {{1.02f, 0.30f}, {1.09f, 0.12f}, {1.17f, 0.045f}};

    /** Whose held item gets the coat. Only the local player's Shu state is known on the client (ClientAddonState), so only that player for now. */
    private static boolean coated(LivingEntity e) {
        Minecraft mc = Minecraft.getInstance();
        if (e != mc.player || !ClientAddonState.shu) return false;
        Player p = (Player) e;
        return !p.isInvisible() && !p.isSpectator() && !InFx.hiddenFrom(p.getId());
    }

    private static boolean isHeld(ItemDisplayContext ctx) {
        return ctx == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND || ctx == ItemDisplayContext.FIRST_PERSON_LEFT_HAND
            || ctx == ItemDisplayContext.THIRD_PERSON_RIGHT_HAND || ctx == ItemDisplayContext.THIRD_PERSON_LEFT_HAND;
    }

    /** Draws the coat. Pose stack, buffer and light are exactly those the game passed to ItemInHandRenderer.renderItem. */
    public static void render(LivingEntity entity, ItemStack stack, ItemDisplayContext ctx, boolean left, PoseStack pose, MultiBufferSource buf) {
        if (stack.isEmpty() || !isHeld(ctx) || !coated(entity)) return;
        Player p = (Player) entity;
        // only the main-hand item is coated (the off-hand is drawn through this same method)
        ItemStack main = p.getMainHandItem();
        if (stack != main && !ItemStack.isSameItemSameTags(stack, main)) return;

        Minecraft mc = Minecraft.getInstance();
        BakedModel model = mc.getItemRenderer().getModel(stack, entity.level(), entity, entity.getId() + ctx.ordinal());
        if (model == null || model.isCustomRenderer()) return; // shield / trident style items are drawn by their own renderer, not from quads

        int rgb = AuraColours.rgb(p);
        float r = (rgb >> 16 & 255) / 255f, g = (rgb >> 8 & 255) / 255f, b = (rgb & 255) / 255f;
        RenderType type = RenderType.entityTranslucentEmissive(TextureAtlas.LOCATION_BLOCKS); // the item's own texture, so the coat keeps its silhouette

        for (float[] pass : PASSES) {
            pose.pushPose();
            BakedModel m = model.applyTransform(ctx, pose, left); // the item's display transform for this hand, as the game applies it
            pose.scale(pass[0], pass[0], pass[0]);               // grow around the item's own centre
            pose.translate(-0.5, -0.5, -0.5);
            VertexConsumer vc = new Tint(buf.getBuffer(type), r, g, b, pass[1]);
            quads(m, pose, vc);
            pose.popPose();
        }
    }

    private static void quads(BakedModel m, PoseStack pose, VertexConsumer vc) {
        RandomSource rnd = RandomSource.create(42L);
        for (Direction d : Direction.values()) {
            rnd.setSeed(42L);
            put(pose, vc, m.getQuads(null, d, rnd));
        }
        rnd.setSeed(42L);
        put(pose, vc, m.getQuads(null, null, rnd));
    }

    private static void put(PoseStack pose, VertexConsumer vc, List<BakedQuad> quads) {
        for (BakedQuad q : quads) vc.putBulkData(pose.last(), q, 1f, 1f, 1f, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
    }

    /** Passes everything through except colour, which is forced to the aura tint and alpha of the current pass. */
    private static final class Tint implements VertexConsumer {
        private final VertexConsumer out;
        private final int r, g, b, a;

        Tint(VertexConsumer out, float r, float g, float b, float a) {
            this.out = out;
            this.r = Math.round(r * 255f);
            this.g = Math.round(g * 255f);
            this.b = Math.round(b * 255f);
            this.a = Math.round(a * 255f);
        }

        @Override public VertexConsumer vertex(double x, double y, double z) { out.vertex(x, y, z); return this; }
        @Override public VertexConsumer color(int r, int g, int b, int a) { out.color(this.r, this.g, this.b, this.a); return this; }
        @Override public VertexConsumer uv(float u, float v) { out.uv(u, v); return this; }
        @Override public VertexConsumer overlayCoords(int u, int v) { out.overlayCoords(u, v); return this; }
        @Override public VertexConsumer uv2(int u, int v) { out.uv2(u, v); return this; }
        @Override public VertexConsumer normal(float x, float y, float z) { out.normal(x, y, z); return this; }
        @Override public void endVertex() { out.endVertex(); }
        @Override public void defaultColor(int r, int g, int b, int a) { out.defaultColor(r, g, b, a); }
        @Override public void unsetDefaultColor() { out.unsetDefaultColor(); }
    }
}
