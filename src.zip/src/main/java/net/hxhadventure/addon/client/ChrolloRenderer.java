package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.hxhadventure.addon.ChrolloEntity;

/** Chrollo with the player model. Convert Hands puts a Bystander's skin on him (two of the five Bystander skins have slim arms). */
public class ChrolloRenderer extends NpcPlayerRenderer<ChrolloEntity> {
    public ChrolloRenderer(EntityRendererProvider.Context ctx) {
        super(ctx,
            c -> c.disguiseSkin() >= 0 ? tex("bystander_" + c.disguiseSkin()) : tex("chrollo"),
            c -> c.disguiseSkin() >= 2); // bystander_2 to bystander_4 are slim
        addLayer(new NpcAuraLayer<>(this, tex("blackaura_ten"), NpcAuraLayer.standard(ChrolloEntity::nenFlags)));
        addLayer(new ChrolloBookLayer(this));
    }
}
