package net.hxhadventure.addon.client;

import net.hxhadventure.addon.CrazyGunItem;
import software.bernie.geckolib.renderer.GeoItemRenderer;

/** Draws the Crazy Slots gun (held, in the inventory, on the ground) from the GeckoLib model. */
public class CrazyGunRenderer extends GeoItemRenderer<CrazyGunItem> {
    public CrazyGunRenderer() {
        super(new CrazyGunModel());
    }
}
