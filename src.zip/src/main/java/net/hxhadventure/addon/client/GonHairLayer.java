package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.hxhadventure.addon.GonVow;
import org.joml.Vector3f;

/**
 * Gon's adult form: finds where the top of the head really is. Layers are drawn with the pose stack already carrying everything
 * that moves the head (Gon's 1.5x growth, the crouch, the Jajanken charge pose, the head's own look direction), so asking the head
 * model part to transform the stack and then reading off the top-centre of the skull gives the exact spot, however the player is posed.
 * It draws nothing itself: it hands that point to {@link GonHairRenderer}, which grows the hair from it.
 */
public class GonHairLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    /** The skull's top face is 8 px above the head's pivot (the neck); a hair of a pixel's depth is sunk into it so there is never a gap. */
    private static final float TOP_OF_HEAD = -(8f - 0.5f) / 16f;

    public GonHairLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffer, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (!GonVow.clientHas(player.getId()) || player.isInvisible() || player.isSpectator()) return;
        pose.pushPose();
        getParentModel().head.translateAndRotate(pose);
        Vector3f p = new Vector3f(0f, TOP_OF_HEAD, 0f);
        pose.last().pose().transformPosition(p); // model space -> view space (the same space the world is drawn in)
        pose.popPose();
        GonHairRenderer.recordHead(player.getId(), p.x, p.y, p.z);
    }
}
