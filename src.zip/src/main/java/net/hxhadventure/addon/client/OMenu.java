package net.hxhadventure.addon.client;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraftforge.fml.loading.FMLPaths;
import net.hxhadventure.addon.ClientAddonState;
import net.hxhadventure.addon.HunterExam;
import net.hxhadventure.entity.client.gui.HxhUi;

/**
 * Which O menu to open. Once the Hunter Exam is completed (stage 3) the Hunter licence style is used, unless the player switched back to the
 * classic style with the small toggle on the screen (saved on the client). Before that only the classic menu exists.
 */
public final class OMenu {
    private OMenu() {}

    /** The four O pages, so the style toggle can reopen the same page in the other style. */
    public enum Page { MASTERY, VOWS, ACTIVE, QUESTS }

    private static final String FILE = "hxhadventure-ui-style.txt";
    private static Boolean hunterStyle;

    public static boolean licensed() {
        return ClientAddonState.examStage >= HunterExam.STAGE_DONE;
    }

    /** The player's chosen style (default: Hunter). Only meaningful once licensed. */
    public static boolean prefersHunter() {
        if (hunterStyle == null) {
            boolean v = true;
            try {
                Path p = FMLPaths.CONFIGDIR.get().resolve(FILE);
                if (Files.exists(p)) v = !Files.readString(p).trim().equalsIgnoreCase("classic");
            } catch (IOException | RuntimeException ignored) {
            }
            hunterStyle = v;
        }
        return hunterStyle;
    }

    private static void setHunter(boolean v) {
        hunterStyle = v;
        try {
            Files.writeString(FMLPaths.CONFIGDIR.get().resolve(FILE), v ? "hunter" : "classic");
        } catch (IOException | RuntimeException ignored) {
        }
    }

    /** True when the Hunter screens are in use. */
    public static boolean useHunter() {
        return licensed() && prefersHunter();
    }

    public static Screen page(Page p) {
        boolean h = useHunter();
        return switch (p) {
            case MASTERY -> h ? new HunterNenSkillsScreen() : new NenSkillsScreen();
            case VOWS -> h ? new HunterVowsScreen() : new VowsScreen();
            case ACTIVE -> h ? new HunterActiveVowsScreen() : new ActiveVowsScreen();
            case QUESTS -> new QuestLogScreen(h);
        };
    }

    /** Page 1 (Mastery): what the O key opens. */
    public static Screen mastery() {
        return page(Page.MASTERY);
    }

    /** Page 2 (Vows). */
    public static Screen vows() {
        return page(Page.VOWS);
    }

    /**
     * Adds the small side buttons, only for players who passed the exam: the UI style toggle and a shortcut to the Active Quests page (or back to
     * Mastery when already there). They sit beside the panel (centred on {@code screenW / 2}, 172 wide each side), stacked, or in a strip across
     * the top when the window is too narrow for that.
     */
    public static void addSide(Consumer<AbstractWidget> add, int screenW, int panelTop, boolean hunterScreen, Page page) {
        if (!licensed()) return;
        int cx = screenW / 2;
        int w = 104, h = 16;
        boolean beside = screenW >= cx + 172 + 6 + w + 4;
        int x0 = beside ? cx + 172 + 6 : screenW - w - 4;
        int y0 = beside ? panelTop : 1;

        String toggleLabel = hunterScreen ? "UI: Hunter (switch)" : "UI: Classic (switch)";
        add.accept(make(hunterScreen, x0, y0, w, h, toggleLabel, () -> {
            setHunter(!hunterScreen);
            Minecraft.getInstance().setScreen(page(page));
        }));

        // second button: stacked under the toggle, or to its left in the top strip
        int x1 = beside ? x0 : x0 - w - 4;
        int y1 = beside ? y0 + h + 4 : y0;
        boolean onQuests = page == Page.QUESTS;
        String label = onQuests ? "Back to Mastery" : "Active Quests (" + ClientQuests.active().size() + ")";
        add.accept(make(hunterScreen, x1, y1, w, h, label, () -> {
            Screen next = page(onQuests ? Page.MASTERY : Page.QUESTS);
            if (hunterScreen) HunterUi.go(next);
            else Minecraft.getInstance().setScreen(next);
        }));
    }

    private static AbstractWidget make(boolean hunterScreen, int x, int y, int w, int h, String label, Runnable run) {
        return hunterScreen
            ? HunterUi.button(x, y, w, h, label, b -> run.run(), false)
            : HxhUi.button(x, y, w, h, label, b -> run.run(), false);
    }
}
