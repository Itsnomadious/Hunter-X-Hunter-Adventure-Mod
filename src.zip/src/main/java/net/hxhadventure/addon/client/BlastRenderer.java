package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.AuraBlast;
import org.joml.Matrix4f;

/**
 * Draws the Aura Blast as a widening cone of white-grey aura from the palm: a hot narrow core inside a pale body inside a
 * faint wide halo, shooting out over a couple of ticks and then fading. No model or texture.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class BlastRenderer {
    private BlastRenderer() {}

    private static final int RINGS = 16, SIDES = 18;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || BlastFx.ACTIVE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        double time = level.getGameTime() + e.getPartialTick();
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        Matrix4f m = ps.last().pose();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.lightning();
        VertexConsumer vc = buf.getBuffer(type);

        Iterator<BlastFx.Blast> it = BlastFx.ACTIVE.iterator();
        while (it.hasNext()) {
            BlastFx.Blast b = it.next();
            double age = time - b.t0;
            if (age > BlastFx.LIFE_TICKS) {
                it.remove();
                continue;
            }
            if (age < 0) continue;
            double reach = Math.min(1.0, age / BlastFx.SHOOT_TICKS);            // how far along the beam the front has got
            double fade = Math.max(0, 1 - Math.max(0, age - BlastFx.SHOOT_TICKS) / (BlastFx.LIFE_TICKS - BlastFx.SHOOT_TICKS));
            Vec3 o = new Vec3(b.ox - cam.x, b.oy - cam.y, b.oz - cam.z);
            Vec3 dir = new Vec3(b.dx, b.dy, b.dz).normalize();
            double len = b.length * (1 - Math.pow(1 - reach, 3));
            if (b.golden) {
                cone(m, vc, o, dir, len, 0.35, b.extra, 255, 248, 200, (int) (240 * fade));  // white-gold core
                cone(m, vc, o, dir, len, 0.75, b.extra, 255, 205, 70, (int) (160 * fade));   // golden body
                cone(m, vc, o, dir, len, 1.0, b.extra, 230, 150, 20, (int) (80 * fade));     // deep gold halo
            } else {
                cone(m, vc, o, dir, len, 0.35, 0, 255, 255, 255, (int) (235 * fade));   // hot core
                cone(m, vc, o, dir, len, 0.75, 0, 225, 225, 232, (int) (150 * fade));   // body
                cone(m, vc, o, dir, len, 1.0, 0, 190, 190, 205, (int) (75 * fade));     // halo
            }
        }
        buf.endBatch(type);
    }

    /** A cone from the palm: its radius at each distance is the server's hit radius times `scale`. */
    private static void cone(Matrix4f m, VertexConsumer vc, Vec3 o, Vec3 dir, double len, double scale, double extra, int r, int g, int b, int a) {
        if (a <= 0 || len < 0.05) return;
        Vec3 u = dir.cross(Math.abs(dir.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0)).normalize();
        Vec3 v = dir.cross(u).normalize();
        Vec3[] prev = null;
        for (int k = 0; k <= RINGS; k++) {
            double d = len * k / RINGS;
            Vec3 c = o.add(dir.scale(d));
            double rad = (AuraBlast.radiusAt(d) + extra) * scale;
            Vec3[] ring = new Vec3[SIDES];
            for (int s = 0; s < SIDES; s++) {
                double th = 2 * Math.PI * s / SIDES;
                ring[s] = c.add(u.scale(Math.cos(th) * rad)).add(v.scale(Math.sin(th) * rad));
            }
            if (prev != null) {
                for (int s = 0; s < SIDES; s++) {
                    int n = (s + 1) % SIDES;
                    quad(m, vc, prev[s], ring[s], ring[n], prev[n], r, g, b, a);
                    quad(m, vc, prev[n], ring[n], ring[s], prev[s], r, g, b, a);
                }
            }
            prev = ring;
        }
    }

    private static void quad(Matrix4f m, VertexConsumer vc, Vec3 a, Vec3 b, Vec3 c, Vec3 d, int r, int g, int bl, int al) {
        for (Vec3 p : new Vec3[]{a, b, c, d}) {
            vc.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(r, g, bl, al).endVertex();
        }
    }
}
