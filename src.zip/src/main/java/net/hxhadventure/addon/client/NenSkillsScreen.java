package net.hxhadventure.addon.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import java.util.List;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.client.Minecraft;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.Affinity;
import net.hxhadventure.addon.ClientAddonState;
import net.hxhadventure.addon.NenSkill;
import net.hxhadventure.addon.Tuning;
import net.hxhadventure.addon.Vows;
import net.hxhadventure.addon.network.PacketEnRadius;
import net.hxhadventure.addon.network.PacketRenSize;
import net.hxhadventure.addon.network.PacketInVisibility;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketAddonAction;
import net.hxhadventure.addon.network.PacketAddonAction.Action;
import net.hxhadventure.entity.client.gui.HxhUi;

/** Mastery menu: overall level, skill levels, affinity passive and aura form buttons. Drawn with HxhUi so it matches the Kite menu. */
public class NenSkillsScreen extends Screen {
    private static final int ROW = 18;
    private static final int HALF_W = 172;
    private static final int PANEL_H = 276; // 8 skill rows
    private static final int BAR_W = 80;
    private static final int SLIDER_X = 46;
    private static final int SLIDER_W = 114;

    /** Mastery grade colours: Novice white, Great blue, Excellent red, Genius purple (bold), Ultimate gold (bold). */
    private static final int[] GRADE_COLOURS = {0xFFFFFF, 0x55FFFF, 0xFF5555, 0xAA55FF, 0xFFD700};
    private static final int[] GRADE_BAR_COLOURS = {0xAAAAAA, 0x55FFFF, 0xFF5555, 0xAA55FF, 0xFFD700};

    /** The mastery text colours are used on the dark HxhUi panel, so they are drawn without a shadow, like the rest of the Kite menu look. */
    private static int rgb(int c) {
        return 0xFF000000 | c;
    }

    private static MutableComponent gradeText(int rank, String text) {
        Style style = Style.EMPTY.withColor(TextColor.fromRgb(GRADE_COLOURS[rank])).withBold(rank >= 3);
        return Component.literal(text).withStyle(style);
    }

    public NenSkillsScreen() {
        super(Component.literal("Mastery"));
    }

    /** The level a skill performs at (trained level raised by Vows and lockouts, can pass 100). */
    private static int eff(NenSkill s) {
        return Vows.effLevel(Minecraft.getInstance().player, s, ClientAddonState.level[s.ordinal()]);
    }

    /** Biggest En radius the local player can pick (their En level and affinity). */
    private static float enMaxRadius() {
        Minecraft mc = Minecraft.getInstance();
        Combat c = mc.player != null ? Combat.get(mc.player) : null;
        int type = ClientAddonState.emperor ? Affinity.ALL : (c != null ? c.getNenType() : 0);
        return Math.min(Vows.enRadiusLimit(mc.player), Tuning.enRadius(eff(NenSkill.EN), Affinity.enRadiusMult(type))); // sworn: En reaches 1 or 4 meters at most
    }

    /** A slider that snaps to a step, shows a short label, and sends its value to the server when released or when the screen closes. */
    private static class RangeSlider extends AbstractSliderButton {
        private final float min, max, step;
        private final java.util.function.Function<Float, String> label;
        private final java.util.function.Consumer<Float> send;
        private float pending = Float.NaN;

        RangeSlider(int x, int y, int w, int h, float min, float max, float step, float start,
                    java.util.function.Function<Float, String> label, java.util.function.Consumer<Float> send) {
            super(x, y, w, h, Component.empty(), max <= min ? 0.0 : (Math.max(min, Math.min(max, start)) - min) / (max - min));
            this.min = min;
            this.max = max;
            this.step = step;
            this.label = label;
            this.send = send;
            updateMessage();
        }

        private float current() {
            if (max <= min) return min;
            if (this.value >= 0.995) return max;
            float raw = min + (float) this.value * (max - min);
            float snapped = min + Math.round((raw - min) / step) * step;
            return Math.round(Math.max(min, Math.min(max, snapped)) * 100f) / 100f;
        }

        /** Square HxhUi slider: dark track, gold fill and a gold handle, with the label on top. */
        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partial) {
            boolean hover = this.isHoveredOrFocused();
            int x = getX(), y = getY();
            g.fill(x, y, x + width, y + height, hover ? HxhUi.GOLD : HxhUi.GOLD_DIM);
            g.fill(x + 1, y + 1, x + width - 1, y + height - 1, 0xFF14181C);
            int fillW = (int) ((width - 2) * this.value);
            g.fill(x + 1, y + 1, x + 1 + fillW, y + height - 1, 0xFF4A3F17);
            int hx = x + 1 + Math.max(0, Math.min(width - 5, fillW - 2));
            g.fill(hx, y + 1, hx + 3, y + height - 1, HxhUi.GOLD);
            g.drawCenteredString(Minecraft.getInstance().font, Minecraft.getInstance().font.plainSubstrByWidth(getMessage().getString(), width - 6), x + width / 2, y + (height - 8) / 2, hover ? 0xFFFFE9A8 : HxhUi.TEXT);
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal(label.apply(current())));
        }

        @Override
        protected void applyValue() {
            pending = current();
        }

        void flush() {
            if (!Float.isNaN(pending)) {
                send.accept(pending);
                pending = Float.NaN;
            }
        }

        @Override
        public void onRelease(double mx, double my) {
            super.onRelease(mx, my);
            flush();
        }
    }

    private RangeSlider enSlider, renSlider, inSlider;
    private HxhUi.HxhButton shuButton;

    @Override
    public void removed() {
        if (enSlider != null) enSlider.flush(); // keyboard changes and anything not sent on release
        if (renSlider != null) renSlider.flush();
        if (inSlider != null) inSlider.flush();
        super.removed();
    }

    /** Widest text allowed inside the panel (the inset boxes are 320 wide). */
    private static final int TEXT_W = 308;
    private static final int LINE_H = 10;

    private List<FormattedCharSequence> typeLines = List.of();
    private int extra = 0;

    /** The Nen type / affinity text, word-wrapped so it can never run off the ends of the panel. */
    private List<FormattedCharSequence> buildTypeLines() {
        Combat c = Minecraft.getInstance().player != null ? Combat.get(Minecraft.getInstance().player) : null;
        int type = ClientAddonState.emperor ? Affinity.ALL : (c != null ? c.getNenType() : 0);
        String text = (ClientAddonState.emperor || ClientProfile.revealed)
            ? Affinity.name(type)
            : "Nen type: unknown (use a Water Divination glass)";
        return this.font.split(FormattedText.of(text), TEXT_W);
    }

    private void refreshLayout() {
        typeLines = buildTypeLines();
        extra = Math.max(0, typeLines.size() - 1) * LINE_H;
    }

    private int panelH() {
        return PANEL_H + extra;
    }

    private int top() {
        return Math.max(16, this.height / 2 - panelH() / 2 + 8);
    }

    @Override
    protected void init() {
        refreshLayout();
        int cx = this.width / 2;
        int by = top() + 218 + extra;
        Action[] actions = {Action.TOGGLE_KEN, Action.TOGGLE_KO};
        String[] labels = {"Ken (toggle)", "Ko (toggle)"};
        for (int i = 0; i < actions.length; i++) {
            Action a = actions[i];
            boolean locked = Vows.isLocked(Minecraft.getInstance().player, i == 0 ? "KEN" : "KO");
            HxhUi.HxhButton formButton = HxhUi.button(cx - 160 + i * 164, by, 156, 20, locked ? labels[i].replace("(toggle)", "(locked)") : labels[i],
                b -> AddonNetwork.sendToServer(new PacketAddonAction(a)), false);
            formButton.active = !locked;
            addRenderableWidget(formButton);
        }
        // Sliders sit on the En and Ren rows, right of the skill bars.
        float enMax = enMaxRadius();
        float enStart = Tuning.enSelectedRadius(ClientAddonState.enChosen, enMax);
        int enRowY = top() + 58 + extra + NenSkill.EN.ordinal() * ROW;
        enSlider = new RangeSlider(cx + SLIDER_X, enRowY - 3, SLIDER_W, 14, Math.min(5f, enMax), enMax, 5f, enStart,
            v -> "En " + Math.round(v) + "m",
            v -> { ClientAddonState.enChosen = v; AddonNetwork.sendToServer(new PacketEnRadius(v)); });
        enSlider.active = !Vows.isLocked(Minecraft.getInstance().player, "EN");
        addRenderableWidget(enSlider);
        float renMax = Tuning.renMaxSize(eff(NenSkill.REN));
        int renRowY = top() + 58 + extra + NenSkill.REN.ordinal() * ROW;
        renSlider = new RangeSlider(cx + SLIDER_X, renRowY - 3, SLIDER_W, 14, 1.0f, renMax, 0.1f, ClientAddonState.renSize,
            v -> "Size " + String.format(java.util.Locale.ROOT, "%.1f", v) + "x",
            v -> { ClientAddonState.renSize = v; AddonNetwork.sendToServer(new PacketRenSize(v)); });
        renSlider.active = !Vows.isLocked(Minecraft.getInstance().player, "REN");
        addRenderableWidget(renSlider);
        // Genius In: choose whether your hidden Nen (Chains, Bungee Gum) shows while In is on
        if (eff(NenSkill.IN) >= Tuning.IN_VISIBILITY_LEVEL) {
            int inRowY = top() + 58 + extra + NenSkill.IN.ordinal() * ROW;
            inSlider = new RangeSlider(cx + SLIDER_X, inRowY - 3, SLIDER_W, 14, 0f, 1f, 1f, ClientAddonState.inVisible ? 1f : 0f,
                v -> v >= 0.5f ? "Nen: Visible" : "Nen: Hidden",
                v -> { ClientAddonState.inVisible = v >= 0.5f; AddonNetwork.sendToServer(new PacketInVisibility(v >= 0.5f)); });
            addRenderableWidget(inSlider);
        }
        // Shu: an on/off button on its row (also the B key)
        int shuRowY = top() + 58 + extra + NenSkill.SHU.ordinal() * ROW;
        boolean shuLocked = Vows.isLocked(Minecraft.getInstance().player, "SHU");
        shuButton = HxhUi.button(cx + SLIDER_X, shuRowY - 3, SLIDER_W, 14, "Shu: Off",
            b -> AddonNetwork.sendToServer(new PacketAddonAction(Action.TOGGLE_SHU)), false);
        shuButton.active = !shuLocked;
        addRenderableWidget(shuButton);
        addRenderableWidget(HxhUi.button(cx - 40, by + 24, 80, 20, "Close", b -> onClose(), true));
        addRenderableWidget(HxhUi.button(cx + 44, by + 24, 116, 20, "Page 2: Vows >", b -> Minecraft.getInstance().setScreen(new VowsScreen()), false));
        OMenu.addSide(this::addRenderableWidget, this.width, top() - 8, false, OMenu.Page.MASTERY);
}

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        // the type text can change while open (e.g. after Water Divination): re-lay everything out if its line count changed
        if (buildTypeLines().size() != typeLines.size()) this.rebuildWidgets();
        HxhUi.backdrop(g, this.width, this.height);
        int cx = this.width / 2;
        int top = top();
        HxhUi.panel(g, cx - HALF_W, top - 8, HALF_W * 2, panelH());
        HxhUi.title(g, this.font, "MASTERY", cx, top);

        Combat c = Minecraft.getInstance().player != null ? Combat.get(Minecraft.getInstance().player) : null;

        // Level section, on its own
        HxhUi.inset(g, cx - 160, top + 12, 320, 24);
        int level = c != null ? c.getHatsuLevel() : 1;
        MutableComponent levelText = Component.literal("Level " + level + (level >= Combat.MAX_LEVEL ? " (MAX)" : "") + "   Mastery: ")
            .withStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xE8E4D8)))
            .append(gradeText(Tuning.gradeRank(level), Combat.masteryGrade(level)));
        g.drawString(this.font, levelText, cx - this.font.width(levelText) / 2, top + 20, 0xFFFFFFFF, false);

        boolean known = ClientAddonState.emperor || ClientProfile.revealed;
        for (int i = 0; i < typeLines.size(); i++) {
            FormattedCharSequence line = typeLines.get(i);
            g.drawString(this.font, line, cx - this.font.width(line) / 2, top + 42 + i * LINE_H, known ? HxhUi.GOLD : HxhUi.TEXT_DIM, false);
        }

        HxhUi.inset(g, cx - 160, top + 52 + extra, 320, 146);
        int y = top + 58 + extra;
        boolean anyBoosted = false;
        for (NenSkill s : NenSkill.values()) {
            int trained = ClientAddonState.level[s.ordinal()];
            int lvl = eff(s); // what the skill performs at; a * marks a level boosted by Vows
            boolean boosted = lvl != trained;
            anyBoosted |= boosted;
            float prog = Math.max(0f, Math.min(1f, ClientAddonState.progress[s.ordinal()]));
            int rank = Tuning.gradeRank(lvl);
            MutableComponent skillText = gradeText(rank, s.label + "  Lv " + lvl + (boosted ? "*" : ""));
            g.drawString(this.font, skillText, cx - 154, y, 0xFFFFFFFF, false);
            if (trained >= NenSkill.MAX_LEVEL) g.drawString(this.font, "\u2605", cx - 154 + this.font.width(skillText) + 3, y, HxhUi.GOLD, false);
            int bx = cx - 40;
            g.fill(bx - 1, y, bx + BAR_W + 1, y + 9, HxhUi.INSET_LINE);
            g.fill(bx, y + 1, bx + BAR_W, y + 8, 0xFF0C0F12);
            if (Vows.isLocked(Minecraft.getInstance().player, s.name())) {
                g.drawCenteredString(this.font, "LOCKED", bx + BAR_W / 2, y + 1, HxhUi.RED);
            } else {
                g.fill(bx, y + 1, bx + (int) (BAR_W * prog), y + 8, rgb(GRADE_BAR_COLOURS[rank]));
            }
            y += ROW;
        }
        g.drawCenteredString(this.font, this.font.plainSubstrByWidth("Aura form: " + ClientAddonState.formLabel() + (anyBoosted ? "     * boosted by Vows" : ""), TEXT_W), cx, top + 204 + extra, HxhUi.GOLD);
        if (shuButton != null) shuButton.setMessage(Component.literal(ClientAddonState.shu ? "Shu: On" : "Shu: Off"));
        super.render(g, mouseX, mouseY, partial);
    }
}
