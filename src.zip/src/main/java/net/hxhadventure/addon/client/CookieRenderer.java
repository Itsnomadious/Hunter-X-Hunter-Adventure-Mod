package net.hxhadventure.addon.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.addon.CookieEntity;
import net.hxhadventure.addon.EstheticianTuning;

/** Cookie: the player model with her own slim-armed skin; she sinks down onto her knees while she works. */
public class CookieRenderer extends NpcPlayerRenderer<CookieEntity> {
    public CookieRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, c -> tex("cookie"), c -> true);
    }

    @Override
    public Vec3 getRenderOffset(CookieEntity cookie, float partialTick) {
        if (cookie.stance() != 0) return new Vec3(0.0, -EstheticianTuning.KNEEL_DROP, 0.0);
        return super.getRenderOffset(cookie, partialTick);
    }
}
