package net.hxhadventure.addon.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.hxhadventure.addon.ExamGuideEntity;
import net.hxhadventure.addon.ExamReceptionistEntity;
import net.hxhadventure.addon.HxHEntities;
import net.hxhadventure.addon.MenchiEntity;
import net.hxhadventure.addon.SatotzEntity;

/** Registers the Hunter Exam NPC renderers (mod event bus, client only). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ExamClientEvents {
    private ExamClientEvents() {}

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(HxHEntities.EXAM_RECEPTIONIST.get(), ctx -> new ExamNpcRenderer<ExamReceptionistEntity>(ctx, "exam_receptionist"));
        e.registerEntityRenderer(HxHEntities.MENCHI.get(), ctx -> new ExamNpcRenderer<MenchiEntity>(ctx, "menchi"));
        e.registerEntityRenderer(HxHEntities.SATOTZ.get(), ctx -> new ExamNpcRenderer<SatotzEntity>(ctx, "satotz"));
        e.registerEntityRenderer(HxHEntities.EXAM_GUIDE.get(), ctx -> new ExamNpcRenderer<ExamGuideEntity>(ctx, "exam_guide"));
        e.registerEntityRenderer(HxHEntities.EXAM_TAKER.get(), ExamTakerRenderer::new);
        e.registerEntityRenderer(HxHEntities.EXAM_NEN_TAKER.get(), ExamNenTakerRenderer::new);
    }
}
