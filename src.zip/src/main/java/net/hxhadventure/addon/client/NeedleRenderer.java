package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Draws Illumi's needles: thin steel pins with round gold heads pushed into the head of whoever carries them.
 * {@link NeedleFx#FOREHEAD} is a short curved row across the forehead (Corpse Control, Body Alteration);
 * {@link NeedleFx#SKULL} is two columns of twelve over the back of the skull (Needle People).
 *
 * Everything is built from plain cuboids sampled from a tiny four-colour swatch texture, so no model files are needed.
 * The head is taken to be centred on the entity's eyes and sized from its hitbox, which fits humanoids best.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class NeedleRenderer {
    private NeedleRenderer() {}

    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/needle.png");
    private static final ResourceLocation TEX_BV = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/black_voice_needle.png");
    private static final double CULL_DISTANCE = 64.0;

    // swatch centres in the 8x8 texture: gold, highlight, dark gold, steel
    private static final float[] GOLD = {0.25f, 0.25f}, SHINE = {0.75f, 0.25f}, DARK = {0.25f, 0.75f}, STEEL = {0.75f, 0.75f};

    /** Pin positions on the head in head-size units (x = left, y = up, z = forward); the outward direction is derived from it. */
    private static final double[][] FOREHEAD_PINS = {
        {-0.56, 0.60, 1.0}, {-0.19, 0.74, 1.0}, {0.19, 0.74, 1.0}, {0.56, 0.60, 1.0}
    };
    private static final double[][] SKULL_PINS = new double[12][];

    static {
        for (int i = 0; i < 6; i++) {
            double y = 0.78 - i * 0.31;
            SKULL_PINS[i] = new double[] {0.42, y, -1.0};
            SKULL_PINS[6 + i] = new double[] {-0.42, y - 0.15, -1.0};
        }
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || NeedleFx.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        double time = level.getGameTime() + pt;
        Vec3 cam = e.getCamera().getPosition();
        boolean firstPerson = mc.options.getCameraType().isFirstPerson();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        RenderType rt = RenderType.entityCutoutNoCull(TEX);
        VertexConsumer vc = null;
        RenderType rtBv = RenderType.entityCutoutNoCull(TEX_BV);
        VertexConsumer vcBv = null;

        Iterator<NeedleFx.Rec> it = NeedleFx.all().values().iterator();
        while (it.hasNext()) {
            NeedleFx.Rec r = it.next();
            if (r.ended >= 0 && time - r.ended > NeedleFx.DIE_TICKS) {
                it.remove();
                continue;
            }
            Entity anchor = level.getEntity(r.anchor);
            if (anchor == null) {
                if (++r.missing > 400) it.remove(); // out of view or gone
                continue;
            }
            r.missing = 0;
            if (anchor.isInvisible()) continue;
            if (firstPerson && anchor == mc.getCameraEntity()) continue; // the needles would sit right in front of the camera
            if (cam.distanceToSqr(anchor.getX(), anchor.getY(), anchor.getZ()) > CULL_DISTANCE * CULL_DISTANCE) continue;
            if (r.style == NeedleFx.NECK) {
                if (vcBv == null) vcBv = buf.getBuffer(rtBv);
                drawNeck(e.getPoseStack(), vcBv, level, cam, r, anchor, time, pt);
                continue;
            }
            if (vc == null) vc = buf.getBuffer(rt);
            drawHead(e.getPoseStack(), vc, level, cam, r, anchor, time, pt);
        }
        if (vc != null) buf.endBatch(rt);
        if (vcBv != null) buf.endBatch(rtBv);
    }

    private static void drawHead(PoseStack ps, VertexConsumer vc, ClientLevel level, Vec3 cam, NeedleFx.Rec r, Entity a, double time, float pt) {
        double born = clamp((time - r.born) / NeedleFx.BORN_TICKS, 0, 1);
        double die = r.ended >= 0 ? clamp((time - r.ended) / NeedleFx.DIE_TICKS, 0, 1) : 0;
        double out = (1 - Math.pow(1 - born, 3)) * (1 - die); // 0 = fully sunk in, 1 = fully showing
        if (out <= 0.001) return;

        double ex = Mth.lerp(pt, a.xo, a.getX()), ey = Mth.lerp(pt, a.yo, a.getY()), ez = Mth.lerp(pt, a.zo, a.getZ());
        Vec3 centre = new Vec3(ex, ey + a.getEyeHeight(), ez);
        double yaw = Math.toRadians(a instanceof LivingEntity le ? Mth.rotLerp(pt, le.yHeadRotO, le.yHeadRot) : Mth.rotLerp(pt, a.yRotO, a.getYRot()));
        double pitch = Math.toRadians(Mth.lerp(pt, a.xRotO, a.getXRot()));
        // head frame: forward, left and up
        Vec3 fwd = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 left = new Vec3(Math.cos(yaw), 0, Math.sin(yaw));
        Vec3 up = fwd.cross(left).normalize();
        double h = clamp(0.30 * a.getBbWidth() + 0.07, 0.12, 0.9); // half the head's width
        int light = LevelRenderer.getLightColor(level, BlockPos.containing(centre));

        double[][] pins = r.style == NeedleFx.SKULL ? SKULL_PINS : FOREHEAD_PINS;
        for (int i = 0; i < pins.length; i++) {
            double[] p = pins[i];
            double jx = jitter(i * 2 + 1, r.anchor) * 0.16, jy = jitter(i * 2 + 2, r.anchor) * 0.16;
            // outward direction in head space: mostly along the face it sits on, leaning away from the middle
            double lx = p[0] * 0.38 + jx, ly = p[1] * 0.22 + jy, lz = p[2] > 0 ? 1.0 : -1.0;
            Vec3 dir = left.scale(lx).add(up.scale(ly)).add(fwd.scale(lz)).normalize();
            Vec3 base = centre.add(left.scale(p[0] * h)).add(up.scale(p[1] * h)).add(fwd.scale(p[2] * h));
            double len = h * 0.46 * out;
            pin(ps, vc, base.subtract(dir.scale(h * 0.06)).subtract(cam), dir, len, h, light);
        }
    }

    /**
     * Black Voice: one small needle pushed tip first into the back of the neck, its red bat-headed end (round head, two little wings)
     * sticking out behind. Drawn from the same swatch layout as the gold pins, with red in place of gold.
     */
    private static void drawNeck(PoseStack ps, VertexConsumer vc, ClientLevel level, Vec3 cam, NeedleFx.Rec r, Entity a, double time, float pt) {
        double born = clamp((time - r.born) / NeedleFx.BORN_TICKS, 0, 1);
        double die = r.ended >= 0 ? clamp((time - r.ended) / NeedleFx.DIE_TICKS, 0, 1) : 0;
        double out = (1 - Math.pow(1 - born, 3)) * (1 - die);
        if (out <= 0.001) return;

        double ex = Mth.lerp(pt, a.xo, a.getX()), ey = Mth.lerp(pt, a.yo, a.getY()), ez = Mth.lerp(pt, a.zo, a.getZ());
        Vec3 centre = new Vec3(ex, ey + a.getEyeHeight(), ez);
        // the neck turns with the body, not the head
        double yaw = Math.toRadians(a instanceof LivingEntity le ? Mth.rotLerp(pt, le.yBodyRotO, le.yBodyRot) : Mth.rotLerp(pt, a.yRotO, a.getYRot()));
        Vec3 fwd = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
        Vec3 left = new Vec3(Math.cos(yaw), 0, Math.sin(yaw));
        Vec3 up = new Vec3(0, 1, 0);
        double h = clamp(0.30 * a.getBbWidth() + 0.07, 0.12, 0.9);
        int light = LevelRenderer.getLightColor(level, BlockPos.containing(centre));

        Vec3 dir = fwd.scale(-1.0).add(up.scale(0.22)).normalize(); // out of the nape, leaning a little upward
        Vec3 base = centre.add(up.scale(-1.0 * h)).add(fwd.scale(-0.32 * h));
        double len = h * 0.50 * out;
        float t = (float) (h * 0.028);   // shaft half-thickness
        float hs = (float) (h * 0.11);   // head half-size
        float l = (float) len;
        ps.pushPose();
        Vec3 at = base.subtract(dir.scale(h * 0.10)).subtract(cam); // the first part of the needle is under the skin
        ps.translate(at.x, at.y, at.z);
        ps.mulPose(Axis.YP.rotation((float) Math.atan2(dir.x, dir.z)));
        ps.mulPose(Axis.XP.rotation((float) -Math.asin(clamp(dir.y, -1, 1))));
        cube(ps, vc, -t, -t, 0f, t, t, l * 0.45f, STEEL, light);                   // the tip
        cube(ps, vc, -t * 1.1f, -t * 1.1f, l * 0.45f, t * 1.1f, t * 1.1f, l, GOLD, light); // the red shaft
        cube(ps, vc, -hs, -hs, l, hs, hs, l + 2 * hs, GOLD, light);                // the round head
        cube(ps, vc, -hs * 0.8f, hs, l + 0.2f * hs, -hs * 0.3f, hs * 1.9f, l + 0.9f * hs, DARK, light); // little ear
        cube(ps, vc, hs * 0.3f, hs, l + 0.2f * hs, hs * 0.8f, hs * 1.9f, l + 0.9f * hs, DARK, light);   // little ear
        float wing = (float) (h * 0.26), wt = hs * 0.12f;
        cube(ps, vc, -wing, -wt, l + 0.2f * hs, -hs, wt, l + 1.6f * hs, SHINE, light); // wings
        cube(ps, vc, hs, -wt, l + 0.2f * hs, wing, wt, l + 1.6f * hs, SHINE, light);
        ps.popPose();
    }

    /** One pin: a steel shaft from just under the skin and a round-ish gold head, along +Z of its own frame. */
    private static void pin(PoseStack ps, VertexConsumer vc, Vec3 at, Vec3 d, double len, double h, int light) {
        float t = (float) (h * 0.03);      // shaft half-thickness
        float hs = (float) (h * 0.14);     // head half-size
        float l = (float) len;
        ps.pushPose();
        ps.translate(at.x, at.y, at.z);
        ps.mulPose(Axis.YP.rotation((float) Math.atan2(d.x, d.z)));
        ps.mulPose(Axis.XP.rotation((float) -Math.asin(clamp(d.y, -1, 1))));
        cube(ps, vc, -t, -t, 0f, t, t, l, STEEL, light);
        // the head: a gold cube plus a copy turned 45 degrees, which reads as a small octagonal bead
        cube(ps, vc, -hs, -hs, l, hs, hs, l + 2 * hs, GOLD, light);
        ps.mulPose(Axis.ZP.rotationDegrees(45f));
        cube(ps, vc, -hs, -hs, l + 0.15f * hs, hs, hs, l + 1.85f * hs, SHINE, light);
        ps.popPose();
    }

    private static void cube(PoseStack ps, VertexConsumer vc, float x0, float y0, float z0, float x1, float y1, float z1, float[] uv, int light) {
        PoseStack.Pose p = ps.last();
        // -Z, +Z, -X, +X, -Y, +Y
        quad(p, vc, uv, light, 0, 0, -1, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0);
        quad(p, vc, uv, light, 0, 0, 1, x1, y0, z1, x1, y1, z1, x0, y1, z1, x0, y0, z1);
        quad(p, vc, uv, light, -1, 0, 0, x0, y0, z1, x0, y1, z1, x0, y1, z0, x0, y0, z0);
        quad(p, vc, uv, light, 1, 0, 0, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1);
        quad(p, vc, uv, light, 0, -1, 0, x0, y0, z1, x0, y0, z0, x1, y0, z0, x1, y0, z1);
        quad(p, vc, uv, light, 0, 1, 0, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0);
    }

    private static void quad(PoseStack.Pose p, VertexConsumer vc, float[] uv, int light, float nx, float ny, float nz,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz) {
        vert(p, vc, uv, light, nx, ny, nz, ax, ay, az);
        vert(p, vc, uv, light, nx, ny, nz, bx, by, bz);
        vert(p, vc, uv, light, nx, ny, nz, cx, cy, cz);
        vert(p, vc, uv, light, nx, ny, nz, dx, dy, dz);
    }

    private static void vert(PoseStack.Pose p, VertexConsumer vc, float[] uv, int light, float nx, float ny, float nz, float x, float y, float z) {
        vc.vertex(p.pose(), x, y, z).color(255, 255, 255, 255).uv(uv[0], uv[1])
            .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(p.normal(), nx, ny, nz).endVertex();
    }

    /** A stable pseudo-random number in [-1, 1] for a pin, so the needles do not flicker from frame to frame. */
    private static double jitter(int n, int seed) {
        double v = Math.sin(n * 12.9898 + seed * 78.233) * 43758.5453;
        return (v - Math.floor(v)) * 2 - 1;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
