package net.hxhadventure.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Skill Hunter book, built in code (pixel units). The spine is the Y axis at the origin; the two halves hinge on it.
 * Each half = a cover plus a block of pages on its local -Z side, so the pages face each other when it closes.
 * Extra parts: leaf (page-turn animation) and ribbon (bookmark).
 * Texture sheet is 64x32 in UV space (the PNG can be any 2:1 size, e.g. 1024x512, UVs are normalized): textures/entity/skill_hunter_book.png
 */
public final class BookModel {
    private BookModel() {}

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("hxhadventure", "skill_hunter_book"), "main");

    public record Parts(ModelPart right, ModelPart left, ModelPart spine, ModelPart leaf, ModelPart ribbon) {}

    private static void half(PartDefinition root, String name, float sign, int coverU) {
        PartDefinition half = root.addOrReplaceChild(name, CubeListBuilder.create(), PartPose.ZERO);
        float x0 = sign > 0 ? 0.5f : -7.5f;
        half.addOrReplaceChild("cover", CubeListBuilder.create().texOffs(coverU, 0).addBox(x0, -5f, -0.5f, 7f, 10f, 1f), PartPose.ZERO);
        half.addOrReplaceChild("pages", CubeListBuilder.create().texOffs(0, 12).addBox(sign > 0 ? 0.7f : -7.2f, -4.6f, -1.6f, 6.5f, 9.2f, 1.1f), PartPose.ZERO);
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        half(root, "right", 1f, 0);   // front cover art lives at u=0
        half(root, "left", -1f, 16);  // back cover art lives at u=16
        root.addOrReplaceChild("spine", CubeListBuilder.create().texOffs(32, 0).addBox(-0.5f, -5f, -1.6f, 1f, 10f, 2.2f), PartPose.ZERO);
        // the page that flips when you change ability (sits on the right pages, swings over to the left)
        root.addOrReplaceChild("leaf", CubeListBuilder.create().texOffs(40, 12).addBox(0.7f, -4.6f, -1.9f, 6.3f, 9.2f, 0.1f), PartPose.ZERO);
        // the bookmark ribbon: hangs out of the bottom of the pages
        root.addOrReplaceChild("ribbon", CubeListBuilder.create().texOffs(40, 0).addBox(-0.6f, -2f, -1.9f, 1.2f, 8f, 0.15f), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 32);
    }

    public static Parts bake(Minecraft mc) {
        ModelPart root = mc.getEntityModels().bakeLayer(LAYER);
        return new Parts(root.getChild("right"), root.getChild("left"), root.getChild("spine"), root.getChild("leaf"), root.getChild("ribbon"));
    }
}
