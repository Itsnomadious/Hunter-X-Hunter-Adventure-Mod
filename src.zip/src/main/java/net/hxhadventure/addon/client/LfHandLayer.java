package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import org.joml.Vector3f;

/** Little Flower's palm aura (Ren's flame) on other players' (and your own third-person) hands. */
public class LfHandLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public LfHandLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffer, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        int f = LittleFlowerClient.auraFlags(player.getId());
        if ((f & 1) == 0 || player.isInvisible() || player.isSpectator()) return;
        double now = player.level().getGameTime() + partialTick;
        float prog = LfHandFx.progress(LittleFlowerClient.auraStart(player.getId()), now);
        int colour = LfHandFx.colourIndex(player);
        for (int side = 0; side < 2; side++) {
            boolean right = side == 1;
            boolean touching = (f & (right ? 4 : 2)) != 0;
            ModelPart arm = right ? getParentModel().rightArm : getParentModel().leftArm;
            // Where the palm is, in the body's frame: down the arm to the palm. The flame is then drawn in the body's frame (not the arm's),
            // turned so it rises towards the head whichever way the arm points.
            PoseStack t = new PoseStack();
            arm.translateAndRotate(t);
            t.translate(0.0, 0.68, 0.0);
            Vector3f hand = t.last().pose().getTranslation(new Vector3f());
            float strength = LfHandFx.strength(player.getId(), right, touching, now);
            pose.pushPose();
            pose.translate(hand.x(), hand.y(), hand.z());
            pose.mulPose(Axis.XP.rotationDegrees(180f)); // the layer's +Y is down the body
            LfHandFx.draw(pose, buffer, colour, strength, touching ? prog : 0f, (float) now, player.getId() * 0.37f + side * 1.7f, true);
            pose.popPose();
        }
    }
}
