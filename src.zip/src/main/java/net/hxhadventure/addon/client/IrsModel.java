package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * I.R.S.'s body (see {@link AprModel} for the conventions): a lilac demon cat with a wide head, tall pointed ears, red slit eyes, a
 * wide-open fanged mouth, long whisker hairs, raised arms, splayed legs, red wings and a tail that curls up into a heart.
 * Feet at about y=24, ear tips at y=-12; the front is -Z. Texture: textures/entity/irs.png.
 */
public final class IrsModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("hxhadventure", "irs"), "main");
    public static final float MODEL_HEIGHT = 2.25f;                // blocks, ear tip to sole

    private static final int TAIL_SEGMENTS = 5;

    private final ModelPart root, head, earL, earR, armL, armR, wingL, wingR, hairL, hairR;
    private final ModelPart[] tail = new ModelPart[TAIL_SEGMENTS];

    public IrsModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.earL = head.getChild("ear_l");
        this.earR = head.getChild("ear_r");
        this.hairL = head.getChild("hair_l");
        this.hairR = head.getChild("hair_r");
        this.armL = root.getChild("arm_l");
        this.armR = root.getChild("arm_r");
        this.wingL = root.getChild("wing_l");
        this.wingR = root.getChild("wing_r");
        ModelPart seg = root.getChild("tail");
        tail[0] = seg;
        for (int i = 1; i < TAIL_SEGMENTS; i++) {
            seg = seg.getChild("seg" + i);
            tail[i] = seg;
        }
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(HakowareUv.IRS_BODY_U, HakowareUv.IRS_BODY_V)
            .addBox(-7f, 10f, -4.5f, 14f, 11f, 9f), PartPose.ZERO);

        // head with ears, whisker hairs and cheek whiskers all attached to it
        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(HakowareUv.IRS_HEAD_U, HakowareUv.IRS_HEAD_V)
            .addBox(-10f, -4f, -7f, 20f, 14f, 14f), PartPose.ZERO);
        for (int side = 0; side < 2; side++) {
            boolean left = side == 0;
            float sx = left ? 1f : -1f;
            CubeListBuilder earCube = CubeListBuilder.create().texOffs(HakowareUv.IRS_EAR_U, HakowareUv.IRS_EAR_V);
            if (!left) earCube.mirror();
            PartDefinition ear = head.addOrReplaceChild(left ? "ear_l" : "ear_r", earCube.addBox(-3f, -5f, -1f, 6f, 5f, 2f),
                PartPose.offsetAndRotation(sx * 6.5f, -3f, 0f, 0f, 0f, sx * 0.25f));
            CubeListBuilder tipCube = CubeListBuilder.create().texOffs(HakowareUv.IRS_EAR_TIP_U, HakowareUv.IRS_EAR_TIP_V);
            if (!left) tipCube.mirror();
            ear.addOrReplaceChild("tip", tipCube.addBox(-2f, -4f, -1f, 4f, 4f, 2f), PartPose.offset(0f, -5f, 0f));

            head.addOrReplaceChild(left ? "hair_l" : "hair_r", CubeListBuilder.create().texOffs(HakowareUv.IRS_HAIR_U, HakowareUv.IRS_HAIR_V)
                .addBox(-0.5f, -7f, -0.5f, 1f, 7f, 1f), PartPose.offsetAndRotation(sx * 3f, -4f, -1f, 0f, 0f, sx * 0.55f));

            for (int w = 0; w < 2; w++) {
                float tilt = (w == 0 ? -1f : 1f) * 0.18f;
                CubeListBuilder whisker = CubeListBuilder.create().texOffs(HakowareUv.IRS_WHISKER_U, HakowareUv.IRS_WHISKER_V);
                whisker.addBox(left ? 0f : -6f, -0.5f, -0.5f, 6f, 1f, 1f);
                head.addOrReplaceChild((left ? "whisker_l" : "whisker_r") + w, whisker,
                    PartPose.offsetAndRotation(sx * 9.5f, 6f + w * 2f, -6f, 0f, sx * -0.35f, sx * tilt));
            }
        }

        for (int side = 0; side < 2; side++) {
            boolean left = side == 0;
            float sx = left ? 1f : -1f;
            PartDefinition arm = root.addOrReplaceChild(left ? "arm_l" : "arm_r",
                CubeListBuilder.create().texOffs(HakowareUv.IRS_ARM_U, HakowareUv.IRS_ARM_V).addBox(-2f, -1f, -2f, 4f, 7f, 4f),
                PartPose.offsetAndRotation(sx * 7.5f, 12.5f, 0f, 0f, 0f, sx * -2.3f));
            arm.addOrReplaceChild("paw", CubeListBuilder.create().texOffs(HakowareUv.IRS_PAW_U, HakowareUv.IRS_PAW_V)
                .addBox(-2.5f, 0f, -2.5f, 5f, 3f, 5f), PartPose.offset(0f, 6f, 0f));

            // legs splayed out to the sides, feet kept flat
            PartDefinition thigh = root.addOrReplaceChild(left ? "thigh_l" : "thigh_r",
                CubeListBuilder.create().texOffs(HakowareUv.IRS_THIGH_U, HakowareUv.IRS_THIGH_V).addBox(-2.5f, 0f, -3f, 5f, 4f, 6f),
                PartPose.offsetAndRotation(sx * 5f, 19f, 0f, 0f, 0f, sx * -0.93f));
            thigh.addOrReplaceChild("foot", CubeListBuilder.create().texOffs(HakowareUv.IRS_FOOT_U, HakowareUv.IRS_FOOT_V)
                .addBox(-4f, 0f, -2f, 8f, 3f, 4f), PartPose.offsetAndRotation(0f, 3.5f, 0f, 0f, 0f, sx * 0.93f));

            // wing: three red feathers fanned behind
            PartDefinition wing = root.addOrReplaceChild(left ? "wing_l" : "wing_r", CubeListBuilder.create(), PartPose.offset(sx * 5f, 12f, 5.5f));
            float[] fan = {0.1f, 0.55f, 1.0f};
            for (int i = 0; i < fan.length; i++) {
                CubeListBuilder feather = CubeListBuilder.create().texOffs(HakowareUv.IRS_FEATHER_U, HakowareUv.IRS_FEATHER_V);
                feather.addBox(left ? 0f : -10f, -1.5f, -0.5f, 10f, 3f, 1f);
                wing.addOrReplaceChild("feather" + i, feather, PartPose.offsetAndRotation(0f, 0f, 0f, 0f, 0f, sx * -fan[i]));
            }
        }

        // tail: five short segments curling up the right side, ending in a heart
        PartDefinition seg = root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(HakowareUv.IRS_TAIL_U, HakowareUv.IRS_TAIL_V)
            .addBox(-1f, -1f, -1f, 2f, 2f, 2f), PartPose.offsetAndRotation(6f, 19f, 3f, 0f, 0f, -0.3f));
        for (int i = 1; i < TAIL_SEGMENTS; i++) {
            seg = seg.addOrReplaceChild("seg" + i, CubeListBuilder.create().texOffs(HakowareUv.IRS_TAIL_U, HakowareUv.IRS_TAIL_V)
                .addBox(-1f, -1f, -1f, 2f, 2f, 2f), PartPose.offsetAndRotation(2f, 0f, 0f, 0f, 0f, -0.3f));
        }
        seg.addOrReplaceChild("heart", CubeListBuilder.create().texOffs(HakowareUv.IRS_HEART_A_U, HakowareUv.IRS_HEART_A_V)
            .addBox(-2.5f, -2.5f, -0.5f, 5f, 5f, 1f), PartPose.offsetAndRotation(3.5f, 0f, 0f, 0f, 0f, 0.785f));
        for (int lobe = 0; lobe < 2; lobe++) {
            seg.addOrReplaceChild("lobe" + lobe, CubeListBuilder.create().texOffs(HakowareUv.IRS_HEART_B_U, HakowareUv.IRS_HEART_B_V)
                .addBox(-1.5f, -1.5f, -0.5f, 3f, 3f, 1f), PartPose.offsetAndRotation(5.2f, lobe == 0 ? -1.8f : 1.8f, 0f, 0f, 0f, 0.785f));
        }
        return LayerDefinition.create(mesh, 128, 128);
    }

    /** Draws the figure with its idle animation (wings flapping, arms waving, ears twitching, tail swaying). */
    public void render(PoseStack ps, VertexConsumer vc, int light, int overlay, float time) {
        head.zRot = 0.05f * (float) Math.sin(time * 0.1);
        earL.zRot = 0.25f + 0.07f * (float) Math.sin(time * 0.33);
        earR.zRot = -0.25f - 0.07f * (float) Math.sin(time * 0.33 + 1.3);
        hairL.zRot = 0.55f + 0.12f * (float) Math.sin(time * 0.2);
        hairR.zRot = -0.55f - 0.12f * (float) Math.sin(time * 0.2 + 0.7);
        armL.zRot = -2.3f + 0.25f * (float) Math.sin(time * 0.3);
        armR.zRot = 2.3f - 0.25f * (float) Math.sin(time * 0.3 + 1.0);
        float flap = (float) Math.sin(time * 0.5);
        wingL.yRot = -0.1f - 0.45f * flap;
        wingR.yRot = 0.1f + 0.45f * flap;
        for (int i = 0; i < TAIL_SEGMENTS; i++) tail[i].zRot = -0.3f + 0.08f * (float) Math.sin(time * 0.15 - i * 0.6);
        root.render(ps, vc, light, overlay);
    }
}
