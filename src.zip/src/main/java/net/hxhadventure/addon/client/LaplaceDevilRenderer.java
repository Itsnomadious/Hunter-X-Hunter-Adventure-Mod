package net.hxhadventure.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.hxhadventure.addon.LaplaceDevilEntity;

/** Draws the Laplace Devil (see LaplaceDevilModel) about 14 blocks tall, centred on the entity, hidden for everyone inside the dome. */
public class LaplaceDevilRenderer extends EntityRenderer<LaplaceDevilEntity> {
    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/laplace_devil.png");
    /** Model pixels -> blocks (1/16) times this. 120 px * 5.7 / 16 is about 43 blocks (three times the old 14). */
    private static final float SCALE = 5.7f;

    private final ModelPart root;

    public LaplaceDevilRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.root = ctx.bakeLayer(LaplaceDevilModel.LAYER);
        this.shadowRadius = 0f;
    }

    @Override
    public boolean shouldRender(LaplaceDevilEntity e, Frustum frustum, double x, double y, double z) {
        return !LaplaceFx.hideDevil(e.getId());
    }

    @Override
    public void render(LaplaceDevilEntity e, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        pose.pushPose();
        float s = SCALE / 16f;
        pose.translate(0.0, -LaplaceDevilModel.HEIGHT * s * 0.5, 0.0); // the entity is the middle of the figure, its roots hang below
        pose.mulPose(Axis.YP.rotationDegrees(180f - yaw));
        pose.scale(-s, -s, s);                                         // model space is y-down, like every vanilla entity model
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEX));
        root.render(pose, vc, light, OverlayTexture.NO_OVERLAY);
        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(LaplaceDevilEntity e) {
        return TEX;
    }
}
