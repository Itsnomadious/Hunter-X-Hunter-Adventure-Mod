package net.hxhadventure.addon.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.client.settings.KeyModifier;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class AddonKeys {
    public static final String CATEGORY = "key.category.hxhadventure";
    // New key names (nen_*) so the defaults below apply even if an old options.txt still holds the previous bindings.
    // Ten has no key: it is always on. Hatsu Mode is H (registered in NeferpitouClientEvents).
    public static final KeyMapping ZETSU = key("key.hxhadventure.nen_zetsu", GLFW.GLFW_KEY_F, KeyModifier.SHIFT);
    public static final KeyMapping REN = key("key.hxhadventure.nen_ren", GLFW.GLFW_KEY_F);
    public static final KeyMapping EN = key("key.hxhadventure.nen_en", GLFW.GLFW_KEY_G);
    public static final KeyMapping IN = key("key.hxhadventure.in", GLFW.GLFW_KEY_I);
    public static final KeyMapping GYO = key("key.hxhadventure.gyo", GLFW.GLFW_KEY_Y);
    public static final KeyMapping SHU = key("key.hxhadventure.nen_shu", GLFW.GLFW_KEY_U);
    public static final KeyMapping KEN = key("key.hxhadventure.nen_ken", GLFW.GLFW_KEY_C);
    public static final KeyMapping KO = key("key.hxhadventure.nen_ko", GLFW.GLFW_KEY_V);
    public static final KeyMapping RESET_SCROLL = key("key.hxhadventure.reset_scroll", GLFW.GLFW_KEY_Q);
    public static final KeyMapping SKILLS = key("key.hxhadventure.skills", GLFW.GLFW_KEY_O);
    public static final KeyMapping HUD_EDIT = key("key.hxhadventure.hud_edit", GLFW.GLFW_KEY_J);

    private AddonKeys() {}

    private static KeyMapping key(String name, int code) {
        return key(name, code, KeyModifier.NONE);
    }

    private static KeyMapping key(String name, int code, KeyModifier modifier) {
        return new KeyMapping(name, KeyConflictContext.IN_GAME, modifier, InputConstants.Type.KEYSYM, code, CATEGORY);
    }

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(ZETSU);
        e.register(REN);
        e.register(EN);
        e.register(IN);
        e.register(GYO);
        e.register(SHU);
        e.register(KEN);
        e.register(KO);
        e.register(RESET_SCROLL);
        e.register(SKILLS);
        e.register(HUD_EDIT);
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("addon_hud", AddonHud.OVERLAY);
        e.registerAboveAll("gyo_info", GyoInfoHud.OVERLAY);
    }
}
