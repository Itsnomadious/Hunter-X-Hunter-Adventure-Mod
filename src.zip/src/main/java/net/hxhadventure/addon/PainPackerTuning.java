package net.hxhadventure.addon;

/** Numbers for Feitan's Pain Packer and Rising Sun (Hatsu kit 21, Transmuters). Change them here. */
public final class PainPackerTuning {
    private PainPackerTuning() {}

    // ---- unlocks ----
    /** Hatsu level needed for Pain Packer (the armour). */
    public static final int MIN_LEVEL = 10;
    /** Hatsu level needed for Rising Sun. */
    public static final int SUN_MIN_LEVEL = 25;

    // ---- pain: damage taken is stored, and Rising Sun is fed by it ----
    /** Pain stored for every point of damage taken (1 heart = 2 points). */
    public static final float PAIN_PER_DAMAGE = 1.0f;
    /** The most pain that can be stored; Rising Sun is at full power here. */
    public static final float PAIN_CAP = 60f;
    /** Pain starts to fade this many ticks after the last wound (600 = 30 s)... */
    public static final int PAIN_DECAY_DELAY_TICKS = 600;
    /** ...and then fades by this much per tick (0.02 = 0.4 per second). */
    public static final float PAIN_DECAY_PER_TICK = 0.02f;

    // ---- Pain Packer (the armour) ----
    /** Pain needed before the armour can be conjured ("after taking damage"). */
    public static final float ARMOR_MIN_PAIN = 3f;
    /** Aura paid to conjure the armour (taking it off is free). Ren is forced on meanwhile and costs its usual upkeep. */
    public static final float ARMOR_COST = 120f;
    public static final int TOGGLE_COOLDOWN_TICKS = 20;
    /** Damage the armoured user takes, as a share of normal. 1.0 = the armour only protects against the heat. */
    public static final float ARMOR_DAMAGE_TAKEN_MULT = 1.0f;
    /** After the sun goes out the armour still shields from its heat for this long (stray flames, ongoing fire). */
    public static final int HEAT_GRACE_TICKS = 100;

    // ---- Rising Sun ----
    /** Pain needed to call the sun. */
    public static final float SUN_MIN_PAIN = 6f;
    public static final float SUN_COST = 350f;
    public static final int SUN_COOLDOWN_TICKS = 1200;           // 60 s
    /** The ball of aura rises and swells into the sun over this long (3 s). */
    public static final int SUN_DEPLOY_TICKS = 60;

    /** Sun diameter in blocks: smallest at the least pain, largest at full pain. */
    public static final float SUN_MIN_SIZE = 1f;
    public static final float SUN_MAX_SIZE = 8f;
    /** Reach of the heat in blocks, measured from the centre of the sun. */
    public static final float SUN_MIN_RANGE = 10f;
    public static final float SUN_MAX_RANGE = 60f;
    /** How long the sun burns once deployed (200 = 10 s, 1200 = 60 s). More pain, longer burn. */
    public static final int SUN_MIN_BURN_TICKS = 200;
    public static final int SUN_MAX_BURN_TICKS = 1200;
    /** Heat in damage per second: hotter with more pain, plus a little per Hatsu level. */
    public static final float SUN_DPS_MIN = 3f;
    public static final float SUN_DPS_MAX = 14f;
    public static final float SUN_DPS_PER_LEVEL = 0.04f;
    /** Heat is applied this often (ticks). */
    public static final int SUN_DAMAGE_INTERVAL = 10;
    /** Heat at the very edge of the range, as a share of the heat at the centre (it falls off in between). */
    public static final float SUN_EDGE_HEAT = 0.5f;
    /** Anything the sun has no clear line to (under a roof, in a cave) takes this share, and is not set on fire. */
    public static final float SUN_SHELTER_MULT = 0.35f;
    /** Seconds of burning set on everything caught in the open. */
    public static final int SUN_IGNITE_SECONDS = 4;
    /** The sun hovers this high above the user: base + per block of its diameter. */
    public static final float SUN_HEIGHT_BASE = 6f;
    public static final float SUN_HEIGHT_PER_SIZE = 1.5f;
    /** true: allies of the user are left alone. (The user is only spared while wearing the armour.) */
    public static final boolean SPARE_ALLIES = true;
}
