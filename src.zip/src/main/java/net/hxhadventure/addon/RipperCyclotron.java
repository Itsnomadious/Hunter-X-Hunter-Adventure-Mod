package net.hxhadventure.addon;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketCyclotronFx;

/**
 * Phinks's Ripper Cyclotron (Hatsu kit 22, Enhancers).
 * <ol>
 *   <li><b>Spin:</b> press Z on its entry in the list and keep HOLDING Z. The user spins the right arm in a circle (clockwise, one rotation
 *       every {@link RipperCyclotronTuning#ROTATION_TICKS} ticks = 0.5 s) and the aura in the fist grows with every rotation, from
 *       {@link RipperCyclotronTuning#AURA_MIN_DIAMETER} up to {@link RipperCyclotronTuning#AURA_MAX_DIAMETER} blocks wide.</li>
 *   <li><b>Damage:</b> every finished rotation adds {@link RipperCyclotronTuning#DAMAGE_PER_ROTATION} (5%) to the punch. There is no cap on
 *       the damage and no time limit on the spin: only the aura's size stops growing.</li>
 *   <li><b>Release:</b> let go of Z to throw a fully charged Jajanken Rock punch, +5% for every rotation.</li>
 * </ol>
 * Everything is decided here on the server; clients are only told what to draw ({@link PacketCyclotronFx}). Forge hooks live in
 * {@link RipperCyclotronEvents}.
 */
public final class RipperCyclotron {
    private RipperCyclotron() {}

    public static final int KIT = 22;
    public static final String ID = "riper_cyclotron";
    private static final String NAME = "Ripper Cyclotron";

    private static final class Spin {
        long start;
        boolean release;
    }

    private static final Map<UUID, Spin> SPINNING = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> READY_AT = new ConcurrentHashMap<>();
    /** Players whose Z key is down right now, as last reported by the client. */
    private static final Set<UUID> Z_DOWN = ConcurrentHashMap.newKeySet();

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    public static boolean isSpinning(Player p) {
        return p != null && SPINNING.containsKey(p.getUUID());
    }

    /** Adds the entry to the Z list once the Hatsu level allows it (runs on the client too, so the menu shows it). */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < RipperCyclotronTuning.MIN_LEVEL) return base;
        String[] out = java.util.Arrays.copyOf(base, base.length + 1);
        out[out.length - 1] = ID;
        return out;
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(ID, RipperCyclotron::begin);
    }

    public static String displayName(String id) {
        return ID.equals(id) ? "\u00a76 Ripper Cyclotron" : null;
    }

    /** The damage multiplier after this many finished rotations. */
    public static double multiplier(int rotations) {
        return RipperCyclotronTuning.COMPOUND
            ? Math.pow(1.0 + RipperCyclotronTuning.DAMAGE_PER_ROTATION, rotations)
            : 1.0 + RipperCyclotronTuning.DAMAGE_PER_ROTATION * rotations;
    }

    /** The aura's width in blocks after this many rotations (continuous, so it grows smoothly): min at 0, max from ROTATIONS_TO_MAX_SIZE on. */
    public static double auraDiameter(double rotations) {
        double t = Mth.clamp(rotations / RipperCyclotronTuning.ROTATIONS_TO_MAX_SIZE, 0.0, 1.0);
        t = t * t * (3 - 2 * t);
        return Mth.lerp(t, RipperCyclotronTuning.AURA_MIN_DIAMETER, RipperCyclotronTuning.AURA_MAX_DIAMETER);
    }

    // ---------------------------------------------------------------- Z pressed: start spinning

    public static void begin(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Ripper Cyclotron"), true);
            return;
        }
        if (c.getHatsuLevel() < RipperCyclotronTuning.MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7c" + NAME + " unlocks at Level " + RipperCyclotronTuning.MIN_LEVEL), true);
            return;
        }
        if (SPINNING.containsKey(sp.getUUID())) return;
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        if (ChainManager.onCooldown(sp, NAME, (int) Math.max(0, READY_AT.getOrDefault(sp.getUUID(), 0L) - now))) return;
        if (c.getCurrentEnergy() < RipperCyclotronTuning.COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        Spin s = new Spin();
        s.start = now;
        SPINNING.put(sp.getUUID(), s);
        Prayer.chargeBegan(sp, ID, null); // Ko / root limitations start on the press
        AddonNetwork.sendToTrackingAndSelf(PacketCyclotronFx.spin(sp.getId(), 0), sp);
        level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0f, 0.6f);
    }

    /** From PacketZHold: Z went down or up. Letting go throws the punch. */
    public static void setZHeld(ServerPlayer sp, boolean held) {
        if (held) {
            Z_DOWN.add(sp.getUUID());
        } else {
            Z_DOWN.remove(sp.getUUID());
            Spin s = SPINNING.get(sp.getUUID());
            if (s != null) s.release = true;
        }
    }

    // ---------------------------------------------------------------- per tick

    public static void tick(ServerPlayer sp) {
        Spin s = SPINNING.get(sp.getUUID());
        if (s == null) return;
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || !sp.isAlive() || ExtrasHooks.hatsuForced(sp) || !(sp.level() instanceof ServerLevel level)) {
            end(sp);
            return;
        }
        long elapsed = level.getGameTime() - s.start;
        // a missed key-up (or a press whose hold packet never came) must not leave the arm spinning for ever
        if (!s.release && elapsed >= 4 && !Z_DOWN.contains(sp.getUUID())) s.release = true;
        if (s.release) {
            SPINNING.remove(sp.getUUID());
            punch(sp, c, level, elapsed);
            return;
        }
        int rotations = (int) (elapsed / RipperCyclotronTuning.ROTATION_TICKS);
        if (elapsed > 0 && elapsed % RipperCyclotronTuning.ROTATION_TICKS == 0) { // a rotation just finished: a whoosh that climbs in pitch
            float pitch = Math.min(2.0f, 0.7f + rotations * 0.04f);
            level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.8f, pitch);
            if (rotations % 4 == 0) level.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 0.6f, Math.min(2.0f, 0.6f + rotations * 0.03f));
        }
        if (elapsed % 5 == 0) {
            sp.displayClientMessage(Component.literal(String.format(java.util.Locale.ROOT,
                "\u00a76%s: %d rotations, x%.2f damage \u00a77(release Z)", NAME, rotations, multiplier(rotations))), true);
        }
    }

    // ---------------------------------------------------------------- the punch

    private static void punch(ServerPlayer sp, Combat c, ServerLevel level, long elapsed) {
        if (c.getCurrentEnergy() < RipperCyclotronTuning.COST) {
            AddonNetwork.sendToTrackingAndSelf(PacketCyclotronFx.gone(sp.getId()), sp);
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(RipperCyclotronTuning.COST);
        long now = level.getGameTime();
        READY_AT.put(sp.getUUID(), now + RipperCyclotronTuning.COOLDOWN_TICKS);
        ChainManager.startCooldown(sp, NAME, RipperCyclotronTuning.COOLDOWN_TICKS);
        sp.swing(InteractionHand.MAIN_HAND, true);

        int rotations = (int) (elapsed / RipperCyclotronTuning.ROTATION_TICKS);
        double diameter = auraDiameter(elapsed / (double) RipperCyclotronTuning.ROTATION_TICKS);

        // the same hit a fully charged Jajanken Rock lands, +5% per finished rotation
        float dmg = Jajanken.fullChargeDamage(c) * (float) multiplier(rotations) * Vows.power(sp, ID);
        Prayer.attackOut(sp, ID);
        Vec3 impact = Jajanken.strike(sp, level, dmg, false, 1.0, false);

        AddonNetwork.sendToTrackingAndSelf(PacketCyclotronFx.punch(sp.getId(), impact, diameter), sp);
        sp.displayClientMessage(Component.literal(String.format(java.util.Locale.ROOT,
            "\u00a76%s: %d rotations, %.0f damage", NAME, rotations, dmg)), true);
        Vows.afterCharge(sp, ID);
    }

    // ---------------------------------------------------------------- clean-up

    /** The spin is lost without a punch (death, logout, lost the Hatsu, forced Zetsu). */
    public static void end(Player p) {
        Z_DOWN.remove(p.getUUID());
        if (SPINNING.remove(p.getUUID()) == null) return;
        if (p instanceof ServerPlayer sp) AddonNetwork.sendToTrackingAndSelf(PacketCyclotronFx.gone(sp.getId()), sp);
    }

    public static void clear(Player p) {
        end(p);
        READY_AT.remove(p.getUUID());
    }

    /** A player who comes into view of someone mid-spin sees the aura at once. */
    public static void sendTo(ServerPlayer owner, ServerPlayer viewer) {
        Spin s = SPINNING.get(owner.getUUID());
        if (s == null) return;
        AddonNetwork.sendToPlayer(PacketCyclotronFx.spin(owner.getId(), owner.level().getGameTime() - s.start), viewer);
    }
}
