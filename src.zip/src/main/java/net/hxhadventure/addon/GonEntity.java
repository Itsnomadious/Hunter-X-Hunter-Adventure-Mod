package net.hxhadventure.addon;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketRockFx;
import net.hxhadventure.addon.network.PacketVowFx;
import net.hxhadventure.entity.ModEntities;
import net.hxhadventure.entity.custom.AuraEntity;
import java.util.Optional;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Gon, an Enhancer NPC with Jajanken, level 60 in everything. He is passive to players. He fights hostile mobs, and he goes for
 * Neferpitou on sight.
 *
 * <p>His Jajanken is the player's ({@link Jajanken}): the same flare, the same charge, the same Rock / Scissors / Paper numbers and the
 * same effects (PacketRockFx), run by the NPC. His body is a Hisoka-style Nen user: Ten always, Ken as his fighting stance, an aura pool that every form and move draws from (see {@link GonTuning}).
 *
 * <p><b>"I'll use everything."</b> ({@link GonVow}) can only be used while he can see an aggravated Neferpitou (one that has a target).
 * He enters the form the moment he does: taller, x10 damage and durability, faster, the 10x Ren aura, and only the cycling-orb Rock.
 * When it is over his Nen is spent (he is exhausted until some aura comes back) and he cannot take the form again for a while.
 */
public class GonEntity extends PathfinderMob implements GeoEntity, NpcMelee.Host, NpcFightGoal.FightNpc {

    // ---- synced to the client: which aura forms to draw, and whether he is in the vow's form ----
    private static final EntityDataAccessor<Integer> NEN_FLAGS = SynchedEntityData.defineId(GonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> VOW = SynchedEntityData.defineId(GonEntity.class, EntityDataSerializers.BOOLEAN);
    public static final int F_TEN = 1, F_KEN = 4;

    private static final int NEN_TYPE = GonTuning.NEN_TYPE;
    private static final UUID MOD_TEN_ARMOR = UUID.fromString("b4000000-0000-4000-8000-000000000001");
    private static final UUID MOD_TEN_TOUGH = UUID.fromString("b4000000-0000-4000-8000-000000000002");
    private static final UUID MOD_AFF_SPEED = UUID.fromString("b4000000-0000-4000-8000-000000000004");
    private static final UUID MOD_ATTACK_SLOW = UUID.fromString("b4000000-0000-4000-8000-000000000005");
    private static final java.util.UUID MOD_TEN_SPEED = UUID.fromString("b4000000-0000-4000-8000-000000000007");
    private static final UUID MOD_VOW_SPEED = UUID.fromString("b4000000-0000-4000-8000-000000000006");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    // ---- aura / Nen ----
    private enum Stance { NONE, KEN }
    private final float maxAura = GonTuning.maxAura();
    private float aura = maxAura;
    private boolean exhausted;
    private boolean ten, ken;
    private Stance stance = Stance.NONE;
    private int formCooldown;
    private int lastHitTick = -1000;
    private int idleTicks;
    private boolean wasFighting;

    // ---- plain attacks ----
    private final NpcMelee melee = new NpcMelee(this, this, meleeCfg());
    private final float meleeGovern = NpcBalance.governedMelee(profile());

    static MeleeCore.Cfg meleeCfg() {
        return MeleeCore.Cfg.of(GonTuning.PUNCH_DAMAGE, GonTuning.PUNCH_RANGE, GonTuning.STRONG_DAMAGE, GonTuning.STRONG_RANGE, GonTuning.STRONG_KNOCKBACK,
            GonTuning.STRONG_CHARGE_TICKS, GonTuning.STRONG_MAX_HOLD_TICKS, GonTuning.STRONG_COOLDOWN_TICKS,
            GonTuning.BARRAGE_DAMAGE, GonTuning.BARRAGE_TICKS, GonTuning.BARRAGE_HIT_GAP, GonTuning.BARRAGE_COOLDOWN_TICKS,
            GonTuning.PUNCH_WEIGHT_BARRAGE, GonTuning.PUNCH_WEIGHT_STRONG);
    }

    /** What the balance model (NpcBalance) knows about this NPC. */
    static NpcBalance.Profile profile() {
        return new NpcBalance.Profile("gon", GonTuning.MAX_HEALTH, GonTuning.HATSU_LEVEL, Math.min(NpcFeelTuning.PLAYER_CAP, GonTuning.TEN_LEVEL))
            .affinity(Affinity.dealt(NEN_TYPE), Affinity.taken(NEN_TYPE)).ren(0).regen(GonTuning.HEAL_PER_SECOND).cfg(meleeCfg());
    }
    private boolean punchOne = true;

    // ---- Jajanken (server) ----
    /** The move being charged (Jajanken.ROCK / SCISSORS / PAPER), or -1 when he is not charging. */
    private int janMove = -1;
    private int janPressed, janStart, janPatience, janThink;
    private boolean janVow, janCalled, janRelease;
    private AuraEntity flare;
    private final int[] janReady = new int[3];
    /** A Paper ball in flight. */
    private boolean shotLive;
    private Vec3 shotPos = Vec3.ZERO, shotDir = Vec3.ZERO;
    private double shotTravelled, shotRadius;
    private float shotDmg;

    // ---- the vow ----
    private boolean vow;
    private int vowTicks, vowSeen, vowCooldown, vowRocks;

    private final Map<UUID, Long> foes = new HashMap<>();

    public GonEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 30;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, NpcBalance.governedHealth(profile()))
            .add(Attributes.MOVEMENT_SPEED, GonTuning.BASE_SPEED)
            .add(Attributes.ATTACK_DAMAGE, 5.0)
            .add(Attributes.FOLLOW_RANGE, GonTuning.FOLLOW_RANGE)
            .add(Attributes.KNOCKBACK_RESISTANCE, GonTuning.KNOCKBACK_RESISTANCE);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(NEN_FLAGS, 0);
        this.entityData.define(VOW, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new NpcFightGoal(this, this, t -> janBusy() || tryJajanken(t)));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        // no target goals on purpose: he picks his own enemies (see scan()) and never a player
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        this.aura = maxAura;
        this.setPersistenceRequired();
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("GonAura", aura);
        tag.putBoolean("GonExhausted", exhausted);
        tag.putInt("GonVowCooldown", vowCooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("GonAura")) aura = Math.max(0f, Math.min(maxAura, tag.getFloat("GonAura")));
        exhausted = tag.getBoolean("GonExhausted");
        vowCooldown = tag.getInt("GonVowCooldown");
    }

    // =====================================================================================================
    // size: taller in the vow's form
    // =====================================================================================================

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        EntityDimensions d = super.getDimensions(pose);
        return this.entityData.get(VOW) ? d.scale(GonVow.HEIGHT_MULT) : d;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (VOW.equals(key)) refreshDimensions();
    }

    // =====================================================================================================
    // queries used by the goal, the damage events and other mobs
    // =====================================================================================================

    public float aura() { return aura; }

    public float maxAura() { return maxAura; }

    public boolean isExhausted() { return exhausted; }

    public boolean isAttacking() { return melee.isAttacking(); }

    /** Is he in "I'll use everything." right now (works on both sides: the flag is synced). */
    public boolean isUsingEverything() { return this.entityData.get(VOW); }

    /** Charging a Jajanken move (the goal keeps him still while he does). */
    public boolean janBusy() { return janMove >= 0; }

    public int nenFlags() { return this.entityData.get(NEN_FLAGS); }

    /** Nen can be used: he has aura left and nothing (Chain Jail, Forced Zetsu) is holding it down. */
    public boolean canUseNen() {
        return !exhausted && !ExtrasHooks.hatsuForced(this);
    }

    /** HxHAdventure's spirit bonus for his Hatsu level: 1 + 0.1 sqrt(L). Multiplies his plain punches. */
    public float spiritBonus() {
        return 1.0f + (float) Math.sqrt(GonTuning.HATSU_LEVEL) * 0.1f;
    }

    /** Multiplier on the damage of his plain punches (affinity, the aura form, the vow). Jajanken works out its own. */
    public float outgoingMult() {
        float m = Affinity.dealt(NEN_TYPE);
        m *= NpcAura.outgoing(GonTuning.TEN_LEVEL, ten, false, ken, false); // Ten / Ken, the same as a player's
        if (vow) m *= GonVow.npcMeleeMult(GonTuning.TEN_LEVEL); // the form: 2x Ren's damage bonus + Ko's (same as a player)
        return m;
    }

    /** Multiplier on damage he takes: affinity, the aura form, Ko's open body while he charges, and the vow's durability. */
    public float incomingMult(DamageSource src) {
        float m = Affinity.taken(NEN_TYPE);
        if (src.is(DamageTypes.LIGHTNING_BOLT)) m *= 1f - Affinity.lightningReduction(NEN_TYPE);
        if (src.is(DamageTypes.FALL)) m *= 1f - Affinity.fallReduction(NEN_TYPE);
        if (Affinity.isStatusDamage(src)) m *= 1f - Affinity.statusReduction(NEN_TYPE);
        boolean ko = janMove >= 0 && tickCount >= janStart; // all the aura is in the fist: Ko, the body has no defence
        m *= NpcAura.incoming(GonTuning.TEN_LEVEL, ten && !ko, false, ken && !ko, ko);
        if (vow) m /= GonVow.npcDurabilityDivisor(GonTuning.TEN_LEVEL); // the form: Ren's durability + 100% (same as a player)
        return m;
    }

    /** Pays for a move out of his aura. False, and nothing paid, if he cannot afford it. */
    private boolean payAura(float cost) {
        if (!canUseNen()) return false;
        float c = cost * (1f - Math.min(0.5f, Affinity.abilityRefund(NEN_TYPE)));
        if (aura < c) return false;
        aura -= c;
        return true;
    }

    /** What his hits and blasts may touch: hostile mobs, Neferpitou and her Terpsichora, what he is fighting, and mobs that hurt him lately. Never players. */
    public boolean isFoe(Entity e) {
        if (!(e instanceof LivingEntity le) || e == this || !le.isAlive() || e instanceof ArmorStand || e instanceof GonEntity) return false;
        if (e instanceof Player p) {
            return GonTuning.RETALIATE_AGAINST_PLAYERS && e == getTarget() && !p.isCreative() && !p.isSpectator();
        }
        if (e == getTarget() || e instanceof Enemy || e instanceof NeferpitouEntity || e instanceof TerpsichoraEntity) return true;
        Long t = foes.get(e.getUUID());
        return t != null && level().getGameTime() - t <= GonTuning.FOE_MEMORY_TICKS;
    }

    private void noteFoe(LivingEntity e) {
        foes.put(e.getUUID(), level().getGameTime());
        if (foes.size() > 32) {
            long now = level().getGameTime();
            foes.values().removeIf(t -> now - t > GonTuning.FOE_MEMORY_TICKS);
        }
    }

    private boolean validTarget(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof ArmorStand || e instanceof GonEntity) return false;
        if (e instanceof Player p) return GonTuning.RETALIATE_AGAINST_PLAYERS && !p.isCreative() && !p.isSpectator();
        return true;
    }

    // =====================================================================================================
    // being hurt: he fights back (but never against a player, unless the tuning says so)
    // =====================================================================================================

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide) {
            lastHitTick = tickCount;
            if (source.getEntity() instanceof LivingEntity attacker && validTarget(attacker)) {
                noteFoe(attacker);
                LivingEntity cur = getTarget();
                boolean keepPitou = vow && cur instanceof NeferpitouEntity;
                if (!keepPitou && (cur == null || !cur.isAlive() || distanceToSqr(cur) > 16.0)) setTarget(attacker);
            }
        }
        return hit;
    }

    // =====================================================================================================
    // per tick (server)
    // =====================================================================================================

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !isAlive() || !(level() instanceof ServerLevel)) return;
        LivingEntity t = getTarget();
        if (t != null && (!t.isAlive() || t.level() != level() || distanceToSqr(t) > 96.0 * 96.0 || !validTarget(t))) {
            setTarget(null);
            t = null;
        }
        if (vowCooldown > 0) vowCooldown--;
        if (janThink > 0) janThink--;
        if (tickCount % GonTuning.SCAN_INTERVAL_TICKS == 0) scan();
        t = getTarget();
        boolean fighting = t != null;
        if (fighting) idleTicks = 0; else idleTicks++;
        if (!fighting && wasFighting) {
            cancelAttack();
            abortCharge();
        }
        wasFighting = fighting;

        tickVow();
        tickNen(fighting);
        melee.tick(t, t != null && inReach(t), janMove >= 0);
        tickJajanken(t);
        tickShot();
        refreshModifiers();
        syncFlags();
    }

    // =====================================================================================================
    // who he fights, and the vow's trigger
    // =====================================================================================================

    /** The nearest Neferpitou he can see; with {@code aggroOnly}, only one that has a target. */
    @Nullable
    private NeferpitouEntity findPitou(boolean aggroOnly) {
        AABB box = getBoundingBox().inflate(GonTuning.PITOU_SIGHT_RANGE);
        NeferpitouEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (NeferpitouEntity p : level().getEntitiesOfClass(NeferpitouEntity.class, box, q -> q.isAlive() && (!aggroOnly || q.getTarget() != null))) {
            double d = distanceToSqr(p);
            if (d >= bestD || !hasLineOfSight(p)) continue;
            best = p;
            bestD = d;
        }
        return best;
    }

    private void scan() {
        NeferpitouEntity aggro = findPitou(true);
        if (aggro != null) {
            vowSeen = tickCount;
            if (!vow && canEnterVow()) enterVow(aggro);
        }
        LivingEntity cur = getTarget();
        if (vow) { // the vow has one enemy
            if (aggro != null && cur != aggro) setTarget(aggro);
            return;
        }
        NeferpitouEntity pitou = aggro != null ? aggro : findPitou(false);
        if (pitou != null) {
            if (cur != pitou) {
                if (cur != null) abortCharge();
                setTarget(pitou);
            }
            return;
        }
        if (cur != null) return;
        AABB box = getBoundingBox().inflate(GonTuning.SIGHT_RANGE);
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, box, c -> c instanceof Enemy && validTarget(c))) {
            double d = distanceToSqr(e);
            if (d >= bestD || !hasLineOfSight(e)) continue;
            best = e;
            bestD = d;
        }
        if (best != null) setTarget(best);
    }

    // =====================================================================================================
    // "I'll use everything."
    // =====================================================================================================

    private boolean canEnterVow() {
        return vowCooldown <= 0 && canUseNen() && GonTuning.HATSU_LEVEL >= GonVow.MIN_LEVEL && !ChainManager.isJailed(this);
    }

    private void enterVow(NeferpitouEntity pitou) {
        abortCharge();
        cancelAttack();
        vow = true;
        vowTicks = 0;
        vowRocks = 0;
        vowSeen = tickCount;
        aura = maxAura;
        this.entityData.set(VOW, true);
        applyVowSpeed();
        AddonNetwork.sendToTracking(new PacketVowFx(getId(), true), this);
        say(GonVow.PHRASE);
        level().playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 1.6f, 0.5f);
        level().playSound(null, blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 0.6f, 1.6f);
        setTarget(pitou);
    }

    private void tickVow() {
        if (!vow) return;
        vowTicks++;
        boolean broke = ExtrasHooks.hatsuForced(this) || ChainManager.isJailed(this);
        boolean idle = janMove < 0 && getTarget() == null && tickCount - vowSeen > 20;
        boolean lost = janMove < 0 && tickCount - vowSeen > GonTuning.VOW_LINGER_TICKS;
        boolean spent = janMove < 0 && vowRocks >= GonTuning.VOW_MAX_ROCKS;
        if (broke || idle || lost || spent || vowTicks >= GonTuning.VOW_MAX_TICKS) endVow();
    }

    /** Leaves the form: the Nen is spent (exhausted until some aura returns) and the vow cannot be used again for a while. */
    private void endVow() {
        if (!vow) return;
        vow = false;
        abortCharge();
        this.entityData.set(VOW, false);
        setMod(Attributes.MOVEMENT_SPEED, MOD_VOW_SPEED, 0, AttributeModifier.Operation.MULTIPLY_TOTAL);
        AddonNetwork.sendToTracking(new PacketVowFx(getId(), false), this);
        vowCooldown = GonTuning.VOW_COOLDOWN_TICKS;
        runDry();
    }

    // =====================================================================================================
    // Nen: the aura pool and the stances
    // =====================================================================================================

    private void tickNen(boolean fighting) {
        if (formCooldown > 0) formCooldown--;

        final float perTick = 1f / 20f;
        if (exhausted) {
            aura += (GonTuning.BASE_REGEN + maxAura * GonTuning.EXHAUST_REGEN_PCT) * perTick;
        } else {
            aura += (ten ? GonTuning.tenRegenPerSecond() : GonTuning.BASE_REGEN) * perTick;
            if (!fighting && idleTicks > GonTuning.REST_DELAY_TICKS) aura += maxAura * GonTuning.REST_REGEN_PCT * perTick;
            float eff = Math.min(0.5f, Affinity.efficiency(NEN_TYPE));
            if (ken) aura -= Tuning.KEN_UPKEEP * (1f - eff) * perTick;
            if (ten && tickCount % 20 == 0 && getHealth() < getMaxHealth() && tickCount - lastHitTick > 40) heal(GonTuning.HEAL_PER_SECOND);
        }
        aura = Math.max(0f, Math.min(maxAura, aura));
        if (vow) aura = maxAura; // the form runs on the vow, not on aura

        if (!exhausted && aura <= 0.01f) {
            runDry();
        } else if (exhausted && aura >= maxAura * GonTuning.EXHAUST_RESUME_FRACTION) {
            exhausted = false;
            level().playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 0.8f, 1.4f);
        }

        // Chain Jail / Forced Zetsu hold everything down, like they do for a player
        boolean blocked = exhausted || ExtrasHooks.hatsuForced(this);
        ten = !blocked;
        if (blocked) {
            if (stance != Stance.NONE) setStance(Stance.NONE, true);
            return;
        }

        Stance want = Stance.NONE;
        if (fighting && janMove < 0) want = Stance.KEN; // while he charges, all the aura is in the fist: no Ken
        if (want != stance && formCooldown <= 0) setStance(want, false);
    }

    private void runDry() {
        exhausted = true;
        aura = 0f;
        ten = false;
        setStance(Stance.NONE, true);
        if (level() instanceof ServerLevel sl) {
            sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 1.0f, 0.7f);
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0, getZ(), 20, 0.4, 0.6, 0.4, 0.02);
        }
    }

    private void setStance(Stance s, boolean force) {
        if (s == stance) return;
        stance = s;
        formCooldown = GonTuning.FORM_SWITCH_TICKS;
        ken = s == Stance.KEN;
        if (!(level() instanceof ServerLevel sl)) return;
        switch (s) {
            case KEN -> sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 0.8f, 1.2f);
            case NONE -> {
                if (!force) sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 0.4f, 1.5f);
            }
        }
    }

    private void syncFlags() {
        int f = (ten ? F_TEN : 0) | (ken ? F_KEN : 0);
        if (this.entityData.get(NEN_FLAGS) != f) this.entityData.set(NEN_FLAGS, f);
    }

    /** Ten's armour and toughness, the Enhancer's speed and the slow of a punch in progress. */
    private void refreshModifiers() {
        updateAttackSlow(); // every tick: a punch's slow lasts nine
        if (tickCount % 5 != 0) return;
        // Ten's old armour / toughness are gone (a player does not have them either)
        setMod(Attributes.MOVEMENT_SPEED, MOD_AFF_SPEED, Affinity.speedBonus(NEN_TYPE), AttributeModifier.Operation.MULTIPLY_TOTAL);        // Ten's movement speed, the same curve a player gets (Tuning.tenSpeedBonus), capped for NPCs
        setMod(Attributes.MOVEMENT_SPEED, MOD_TEN_SPEED, NpcAura.speedBonus(GonTuning.TEN_LEVEL, ten, false, ken, false), AttributeModifier.Operation.MULTIPLY_TOTAL);
        if (vow) applyVowSpeed(); // Ten may switch on or off while the form lasts
    }

    /** The form's speed: total bonus = Ren's speed bonus x 1.5 (like a player), topped up on top of Ten's speed that is already on. */
    private void applyVowSpeed() {
        double have = NpcAura.speedBonus(GonTuning.TEN_LEVEL, ten, false, ken, false);
        double amount = Math.max(0.0, (1.0 + GonVow.npcSpeedTotal(GonTuning.TEN_LEVEL)) / (1.0 + have) - 1.0);
        setMod(Attributes.MOVEMENT_SPEED, MOD_VOW_SPEED, amount, AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    private void setMod(Attribute attr, UUID id, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = getAttribute(attr);
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(id);
        if (Math.abs(amount) < 1e-6) {
            if (cur != null) inst.removeModifier(id);
            return;
        }
        if (cur != null && Math.abs(cur.getAmount() - amount) < 1e-6) return;
        if (cur != null) inst.removeModifier(id);
        inst.addTransientModifier(new AttributeModifier(id, "Gon Nen", amount, op));
    }

    // =====================================================================================================
    // Attack / Barrage / Strong attack (Combat.java's moves, run by the NPC)
    // =====================================================================================================

    @Override
    public NpcMelee melee() { return melee; }

    /** Called by the combat goal every tick the target is within reach: picks the next move when free to. */
    @Override
    public void chooseAttack(LivingEntity t) {
        if (janMove >= 0) return;
        melee.choose(t);
    }

    @Override
    public boolean inReach(LivingEntity t) {
        return distanceTo(t) - t.getBbWidth() * 0.5 <= GonTuning.REACH && Math.abs(t.getY() - getY()) < 2.5;
    }

    private void cancelAttack() {
        melee.cancel();
    }

    /** Spirit bonus (and the NPC's own boosts) x the fairness governor (NpcBalance). */
    @Override
    public float meleeScale() {
        return spiritBonus() * outgoingMult() * meleeGovern;
    }

    @Override
    public void swingAnim() {
        triggerPunchAnim();
    }

    void triggerPunchAnim() {
        triggerAnim("attack_controller", punchOne ? "punch1" : "punch2");
        punchOne = !punchOne;
    }

    private void updateAttackSlow() {
        setMod(Attributes.MOVEMENT_SPEED, MOD_ATTACK_SLOW, -melee.slow(), AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    // =====================================================================================================
    // Jajanken: Rock, Scissors, Paper (the player's moves, run by the NPC)
    // =====================================================================================================

    private static float janCost(int move) {
        return move == Jajanken.SCISSORS ? Jajanken.SCISSORS_COST : move == Jajanken.PAPER ? Jajanken.PAPER_COST : Jajanken.ROCK_COST;
    }

    private static int janCooldown(int move) {
        return move == Jajanken.SCISSORS ? Jajanken.SCISSORS_COOLDOWN_TICKS : move == Jajanken.PAPER ? Jajanken.PAPER_COOLDOWN_TICKS : Jajanken.ROCK_COOLDOWN_TICKS;
    }

    private double gap(LivingEntity t) {
        return distanceTo(t) - t.getBbWidth() * 0.5;
    }

    /**
     * Called by the combat goal every tick: if he is free and a Jajanken move fits the distance to {@code t}, he starts charging it.
     * In the vow's form only Rock is ever used, and it starts as soon as the target is near enough to be inside the blast.
     */
    boolean tryJajanken(LivingEntity t) {
        if (janMove >= 0) return true;
        if (!melee.core.ready() || !canUseNen() || janThink > 0) return false;
        janThink = 10;
        if (vow) {
            if (vowRocks >= GonTuning.VOW_MAX_ROCKS || tickCount < janReady[Jajanken.ROCK] || distanceTo(t) > 14.0) return false;
            return beginJajanken(Jajanken.ROCK, true);
        }
        if (random.nextFloat() > GonTuning.JAJANKEN_CHANCE) return false;
        double d = gap(t);
        int[] options = new int[3];
        int n = 0;
        if (d <= GonTuning.ROCK_START_DIST && ready(Jajanken.ROCK)) options[n++] = Jajanken.ROCK;
        if (d >= GonTuning.SCISSORS_MIN_DIST && d <= GonTuning.SCISSORS_MAX_DIST && ready(Jajanken.SCISSORS)) options[n++] = Jajanken.SCISSORS;
        if (d >= GonTuning.PAPER_MIN_DIST && d <= GonTuning.PAPER_MAX_DIST && ready(Jajanken.PAPER) && hasLineOfSight(t)) options[n++] = Jajanken.PAPER;
        if (n == 0) return false;
        return beginJajanken(options[random.nextInt(n)], false);
    }

    private boolean ready(int move) {
        return tickCount >= janReady[move] && aura >= janCost(move);
    }

    private boolean beginJajanken(int move, boolean isVow) {
        if (!(level() instanceof ServerLevel sl) || janMove >= 0) return false;
        janMove = move;
        janVow = isVow;
        janPressed = tickCount;
        janStart = tickCount + Jajanken.ROCK_FLARE_TICKS;
        janCalled = false;
        janRelease = false;
        janPatience = 0;
        if (isVow) vowRocks++;
        flare = spawnFlare(sl, isVow ? GonVow.REN_SIZE : Tuning.REN_MAX_SIZE);
        getNavigation().stop();
        AddonNetwork.sendToTracking(new PacketRockFx(getId(), 1, move, 0, 0, 0, 0, 0), this);
        say("First comes rock...");
        sl.playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 1.0f, 0.6f);
        sl.sendParticles(ParticleTypes.FLASH, getX(), getY() + 1.0, getZ(), 1, 0, 0, 0, 0.0);
        return true;
    }

    private AuraEntity spawnFlare(ServerLevel sl, float size) {
        AuraEntity a = new AuraEntity(ModEntities.AURA_ENTITY.get(), sl);
        a.setOwner(this);
        a.setAuraColorIndex(GonTuning.AURA_COLOR_INDEX);
        a.setAuraType(0);
        a.setAuraScale(size);
        a.setPos(getX(), getY(), getZ());
        sl.addFreshEntity(a);
        return a;
    }

    /** Max size -> nothing, fast at first (ease-out), then gone. */
    private void shrinkFlare() {
        if (flare == null) return;
        double t = (tickCount - janPressed) / (double) Jajanken.ROCK_FLARE_TICKS;
        if (t >= 1.0 || !flare.isAlive()) {
            dropFlare();
            return;
        }
        double left = 1.0 - t;
        float size = janVow ? GonVow.REN_SIZE : Tuning.REN_MAX_SIZE;
        flare.setAuraScale(Math.max(0.02f, (float) (size * left * left)));
        flare.setPos(getX(), getY(), getZ());
    }

    private void dropFlare() {
        if (flare != null) {
            if (!flare.isRemoved()) flare.discard();
            flare = null;
        }
    }

    /** The charge is lost without a punch (target gone, Nen held down, the vow ended). */
    private void abortCharge() {
        if (janMove < 0) return;
        janMove = -1;
        dropFlare();
        AddonNetwork.sendToTracking(new PacketRockFx(getId(), 0, 0, 0, 0, 0, 0, 0), this);
    }

    private void faceInstant(Entity t) {
        double dx = t.getX() - getX(), dz = t.getZ() - getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        double dy = t.getY(0.5) - getEyeY();
        float pitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * (180.0 / Math.PI));
        setYRot(yaw);
        yBodyRot = yaw;
        setYHeadRot(yaw);
        setXRot(pitch);
    }

    private boolean inRangeOf(int move, LivingEntity t) {
        double d = gap(t);
        if (move == Jajanken.SCISSORS) return d <= Jajanken.SCISSORS_DASH + Jajanken.SCISSORS_REACH - 1.0;
        if (move == Jajanken.PAPER) return d <= Jajanken.PAPER_RANGE && hasLineOfSight(t);
        return d <= Jajanken.ROCK_REACH - 0.3;
    }

    private void tickJajanken(@Nullable LivingEntity t) {
        if (janMove < 0) return;
        if (!(level() instanceof ServerLevel sl)) return;
        if (ExtrasHooks.hatsuForced(this) || t == null) {
            abortCharge();
            return;
        }
        // rooted and facing the target for the whole charge
        getNavigation().stop();
        Vec3 m = getDeltaMovement();
        if (m.x != 0 || m.z != 0) {
            setDeltaMovement(0, m.y, 0);
            hurtMarked = true;
        }
        faceInstant(t);

        int elapsed = tickCount - janStart; // negative while the flare is still shrinking
        if (!janRelease) {
            if (elapsed < 0) {
                shrinkFlare();
                return;
            }
            if (flare != null) { // the flare is gone: all the aura goes into the fist
                dropFlare();
                sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 0.8f, 0.8f);
            }
            if (!janCalled && elapsed >= Jajanken.CALL_FRACTION * Jajanken.ROCK_CHARGE_TICKS) {
                janCalled = true;
                say("Jan... ken...");
            }
            if (janVow) {
                if (GonVow.cyclesDone(elapsed) >= GonTuning.VOW_CYCLES_BEFORE_RELEASE) janRelease = true;
            } else {
                if (elapsed == Jajanken.ROCK_CHARGE_TICKS) sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.HOSTILE, 1.2f, 0.7f);
                if (elapsed >= Jajanken.ROCK_CHARGE_TICKS) {
                    if (inRangeOf(janMove, t) || ++janPatience >= GonTuning.CHARGE_PATIENCE_TICKS) janRelease = true;
                }
                if (elapsed > Jajanken.ROCK_CHARGE_TICKS + Jajanken.ROCK_HOLD_LIMIT_TICKS) janRelease = true;
            }
        }
        if (janRelease) release(t, elapsed);
    }

    private void release(LivingEntity t, int elapsed) {
        int move = janMove;
        boolean isVow = janVow;
        double charge = Math.min(1.0, elapsed / (double) (isVow ? GonVow.CYCLE_TICKS : Jajanken.ROCK_CHARGE_TICKS));
        int cycles = isVow ? GonVow.cyclesDone(elapsed) : 0;
        janMove = -1;
        dropFlare();
        if (elapsed < Jajanken.ROCK_MIN_CHARGE_TICKS || (!isVow && !payAura(janCost(move)))) { // scattered or no aura to pay for it
            AddonNetwork.sendToTracking(new PacketRockFx(getId(), 0, 0, 0, 0, 0, 0, 0), this);
            return;
        }
        janReady[move] = tickCount + janCooldown(move);
        melee.recover(GonTuning.PUNCH_GAP_TICKS);
        faceInstant(t);
        if (move == Jajanken.SCISSORS) slash(charge);
        else if (move == Jajanken.PAPER) fire(charge);
        else punch(charge, isVow, cycles);
    }

    /** A Jajanken move's damage: the move's base and his level, how far it was charged, Ko's multiplier (all the aura was in the fist), affinity and the vow. */
    private float janDamage(int move, double charge, boolean isVow) {
        float base = move == Jajanken.SCISSORS ? Jajanken.SCISSORS_BASE_DAMAGE : move == Jajanken.PAPER ? Jajanken.PAPER_BASE_DAMAGE : Jajanken.ROCK_BASE_DAMAGE;
        float d = (base + GonTuning.HATSU_LEVEL * Jajanken.ROCK_DAMAGE_PER_LEVEL)
            * (float) (Jajanken.ROCK_MIN_CHARGE_FACTOR + (1.0 - Jajanken.ROCK_MIN_CHARGE_FACTOR) * charge);
        d *= NpcAura.koMeleeMult(GonTuning.TEN_LEVEL); // Ko, as a player's Jajanken gets it (1 + 2 x Ten's bonus)
        d *= Affinity.dealt(NEN_TYPE);
        if (isVow) d *= GonVow.HATSU_DAMAGE_MULT;
        return d;
    }

    private boolean canGrief(ServerLevel level) {
        return level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
    }

    // ---------------- Rock ----------------
    private void punch(double charge, boolean isVow, int cycles) {
        if (!(level() instanceof ServerLevel level)) return;
        triggerPunchAnim();
        Vec3 eye = getEyePosition();
        Vec3 look = getLookAngle().normalize();
        Vec3 end = eye.add(look.scale(Jajanken.ROCK_REACH));
        HitResult wall = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        double wallDist = wall.getType() == HitResult.Type.MISS ? Jajanken.ROCK_REACH + 1 : wall.getLocation().distanceTo(eye);

        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(1.5), this::isFoe)) {
            Vec3 v = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(eye);
            double proj = v.dot(look);
            if (proj < 0 || proj > Jajanken.ROCK_REACH + e.getBbWidth() * 0.5 || proj > wallDist + 0.5) continue;
            double perp = v.subtract(look.scale(proj)).length();
            if (perp > Jajanken.ROCK_HIT_WIDTH + e.getBbWidth() * 0.5 || proj >= best) continue;
            best = proj;
            target = e;
        }
        Vec3 impact;
        if (target != null) impact = target.position().add(0, target.getBbHeight() * 0.5, 0);
        else if (wall.getType() != HitResult.Type.MISS) impact = wall.getLocation();
        else impact = end;

        float dmg = janDamage(Jajanken.ROCK, charge, isVow);
        if (isVow) dmg = Math.min(GonVow.MAX_DAMAGE, dmg * GonVow.cycleMult(cycles)); // x1.5 per finished orb cycle
        double radiusMult = isVow ? GonTuning.VOW_RADIUS_MULT : 1.0;
        if (target != null) {
            target.invulnerableTime = 0;
            target.hurt(damageSources().mobAttack(this), dmg);
            Vec3 push = look.scale(Jajanken.ROCK_KNOCKBACK).add(0, 0.45, 0);
            target.push(push.x, push.y, push.z);
            target.hurtMarked = true;
        }
        // the shock: every other enemy near the impact takes a share of it
        AABB shock = new AABB(impact, impact).inflate(Jajanken.ROCK_SHOCK_RADIUS * radiusMult);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, shock, this::isFoe)) {
            if (e == target) continue;
            e.invulnerableTime = 0;
            e.hurt(damageSources().mobAttack(this), dmg * Jajanken.ROCK_SHOCK_FRACTION);
            Vec3 away = e.position().subtract(impact).multiply(1, 0, 1);
            if (away.lengthSqr() > 1e-4) away = away.normalize().scale(0.8);
            e.push(away.x, 0.3, away.z);
            e.hurtMarked = true;
        }

        if (canGrief(level)) {
            if (isVow && GonTuning.VOW_CRATER) GonVow.startCrater(level, impact.add(look.scale(0.4)), Jajanken.ROCK_BREAK_RADIUS * radiusMult, blockPosition().getY());
            else Jajanken.breakBlocks(level, this, impact, look);
        }

        say("G\u016b!");
        AddonNetwork.sendToTracking(new PacketRockFx(getId(), 2, Jajanken.ROCK, impact.x, impact.y, impact.z, isVow ? radiusMult : 0, 0), this);
        if (isVow) {
            level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 8.0f, 0.5f);
            level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.WITHER_BREAK_BLOCK, SoundSource.HOSTILE, 6.0f, 0.6f);
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, impact.x, impact.y, impact.z, 12, Jajanken.ROCK_SHOCK_RADIUS * radiusMult * 0.4, 1.5, Jajanken.ROCK_SHOCK_RADIUS * radiusMult * 0.4, 0.0);
        }
        level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.6f, 0.7f);
        level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.IRON_GOLEM_ATTACK, SoundSource.HOSTILE, 1.8f, 0.5f);
        level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 0.8f, 0.6f);
        level.sendParticles(ParticleTypes.EXPLOSION, impact.x, impact.y, impact.z, 2, 0.3, 0.3, 0.3, 0.0);
        level.sendParticles(ParticleTypes.FLASH, impact.x, impact.y, impact.z, 1, 0, 0, 0, 0.0);
    }

    // ---------------- Scissors ----------------
    private void slash(double charge) {
        if (!(level() instanceof ServerLevel level)) return;
        triggerPunchAnim();
        float yaw = getYRot();
        double rad = Math.toRadians(yaw);
        Vec3 dir = new Vec3(-Math.sin(rad), 0, Math.cos(rad));
        Vec3 start = position();
        if (canGrief(level)) Jajanken.cutBlocks(level, this, start, dir);

        double dist = 0;
        AABB box = getBoundingBox();
        for (double d = 0.25; d <= Jajanken.SCISSORS_DASH + 1e-6; d += 0.25) {
            if (!level.noCollision(this, box.move(dir.scale(d)))) break;
            dist = d;
        }
        Vec3 end = start.add(dir.scale(dist));

        float dmg = janDamage(Jajanken.SCISSORS, charge, false);
        double length = dist + Jajanken.SCISSORS_REACH;
        AABB zone = new AABB(start, start.add(dir.scale(length))).inflate(Jajanken.SCISSORS_WIDTH + 1.0, 2.5, Jajanken.SCISSORS_WIDTH + 1.0);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, zone, this::isFoe)) {
            Vec3 v = e.position().subtract(start);
            double along = v.x * dir.x + v.z * dir.z;
            double lateral = Math.abs(v.x * -dir.z + v.z * dir.x);
            double half = e.getBbWidth() * 0.5;
            if (along < -0.5 || along > length + half || lateral > Jajanken.SCISSORS_WIDTH + half) continue;
            if (e.getBoundingBox().maxY < start.y - 0.5 || e.getBoundingBox().minY > start.y + 2.2) continue;
            e.invulnerableTime = 0;
            e.hurt(damageSources().mobAttack(this), dmg);
            e.push(dir.x * Jajanken.SCISSORS_KNOCKBACK, 0.3, dir.z * Jajanken.SCISSORS_KNOCKBACK);
            e.hurtMarked = true;
        }

        moveTo(end.x, end.y, end.z, yaw, getXRot());
        getNavigation().stop();
        setDeltaMovement(dir.scale(Jajanken.SCISSORS_EXIT_SPEED));
        hurtMarked = true;
        fallDistance = 0;

        say("Chii!");
        AddonNetwork.sendToTracking(new PacketRockFx(getId(), 3, Jajanken.SCISSORS, start.x, start.y, start.z, dist, yaw), this);
        level.playSound(null, end.x, end.y, end.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 1.8f, 0.6f);
        level.playSound(null, end.x, end.y, end.z, SoundEvents.TRIDENT_RIPTIDE_3, SoundSource.HOSTILE, 1.0f, 1.4f);
        for (double t = 0; t <= length; t += 0.8) {
            Vec3 pt = start.add(dir.scale(t));
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, pt.x, pt.y + 1.1, pt.z, 1, 0.3, 0.2, 0.3, 0.0);
        }
    }

    // ---------------- Paper ----------------
    private void fire(double charge) {
        if (!(level() instanceof ServerLevel level)) return;
        triggerPunchAnim();
        Vec3 look = getLookAngle().normalize();
        Vec3 origin = getEyePosition().add(look.scale(0.8)).subtract(0, 0.45, 0);
        shotLive = true;
        shotPos = origin;
        shotDir = look;
        shotTravelled = 0;
        shotDmg = janDamage(Jajanken.PAPER, charge, false);
        shotRadius = Jajanken.PAPER_RADIUS_MIN + (Jajanken.PAPER_RADIUS_MAX - Jajanken.PAPER_RADIUS_MIN) * charge;

        say("Pa!");
        AddonNetwork.sendToTracking(new PacketRockFx(getId(), 4, Jajanken.PAPER, origin.x, origin.y, origin.z, charge, getYRot(), getXRot()), this);
        level.playSound(null, origin.x, origin.y, origin.z, SoundEvents.FIRECHARGE_USE, SoundSource.HOSTILE, 1.6f, 0.6f);
        level.playSound(null, origin.x, origin.y, origin.z, SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 1.2f, 1.6f);
    }

    /** Moves his ball along, one tick: it stops at the first wall or enemy, or at the end of its range, and bursts. */
    private void tickShot() {
        if (!shotLive || !(level() instanceof ServerLevel level)) return;
        double step = Math.min(Jajanken.PAPER_SPEED, Jajanken.PAPER_RANGE - shotTravelled);
        Vec3 p0 = shotPos, p1 = p0.add(shotDir.scale(step));
        HitResult wall = level.clip(new ClipContext(p0, p1, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        Vec3 limit = wall.getType() == HitResult.Type.MISS ? p1 : wall.getLocation();

        LivingEntity hit = null;
        Vec3 hitAt = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(p0, limit).inflate(shotRadius + 1.0), this::isFoe)) {
            AABB bb = e.getBoundingBox().inflate(shotRadius);
            Vec3 at;
            if (bb.contains(p0)) {
                at = p0;
            } else {
                Optional<Vec3> o = bb.clip(p0, limit);
                if (o.isEmpty()) continue;
                at = o.get();
            }
            double d = at.distanceToSqr(p0);
            if (d < best) {
                best = d;
                hit = e;
                hitAt = at;
            }
        }
        if (hit != null) {
            blast(hitAt, hit);
        } else if (wall.getType() != HitResult.Type.MISS) {
            blast(limit, null);
        } else if (shotTravelled + step >= Jajanken.PAPER_RANGE - 1e-6) {
            blast(p1, null);
        } else {
            shotPos = p1;
            shotTravelled += step;
        }
    }

    private void blast(Vec3 at, @Nullable LivingEntity direct) {
        shotLive = false;
        if (!(level() instanceof ServerLevel level)) return;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(Jajanken.PAPER_BLAST_RADIUS), this::isFoe)) {
            double dist = e.position().add(0, e.getBbHeight() * 0.5, 0).distanceTo(at);
            float fall = e == direct ? 1f : (float) Math.max(0.5, 1.0 - 0.5 * dist / Jajanken.PAPER_BLAST_RADIUS);
            e.invulnerableTime = 0;
            e.hurt(damageSources().mobAttack(this), shotDmg * fall);
            Vec3 away = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(at);
            away = away.lengthSqr() > 1e-4 ? away.normalize().scale(Jajanken.PAPER_KNOCKBACK) : shotDir.scale(Jajanken.PAPER_KNOCKBACK);
            e.push(away.x, 0.3 + Math.max(0, away.y) * 0.3, away.z);
            e.hurtMarked = true;
        }
        if (canGrief(level)) Jajanken.breakBlocks(level, this, at, shotDir, Jajanken.PAPER_BREAK_RADIUS, Jajanken.PAPER_MAX_BLOCKS);
        AddonNetwork.sendToTracking(new PacketRockFx(getId(), 5, Jajanken.PAPER, at.x, at.y, at.z, 0, 0), this);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.4f, 0.9f);
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0.2, 0.2, 0.2, 0.0);
        level.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0, 0, 0, 0.0);
    }

    /** Every Jajanken line goes to the players near him, as if he said it. */
    private void say(String text) {
        if (!(level() instanceof ServerLevel sl)) return;
        Component msg = Component.literal("<").append(getDisplayName()).append(Component.literal("> " + text));
        double r2 = GonTuning.CHAT_RANGE * GonTuning.CHAT_RANGE;
        for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(this) <= r2) p.sendSystemMessage(msg);
        }
    }

    // =====================================================================================================
    // players who come into view mid-charge / mid-vow see it at once
    // =====================================================================================================

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (vow) AddonNetwork.sendToPlayer(new PacketVowFx(getId(), true), player);
        if (janMove >= 0) AddonNetwork.sendToPlayer(new PacketRockFx(getId(), 1, janMove, tickCount - janPressed, 0, 0, 0, 0), player);
    }

    // =====================================================================================================
    // end of life
    // =====================================================================================================

    @Override
    public void die(DamageSource source) {
        cleanUp();
        super.die(source);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        cleanUp();
        super.remove(reason);
    }

    private void cleanUp() {
        dropFlare();
        shotLive = false;
        if (!level().isClientSide) {
            if (janMove >= 0) {
                janMove = -1;
                AddonNetwork.sendToTracking(new PacketRockFx(getId(), 0, 0, 0, 0, 0, 0, 0), this);
            }
            if (vow) {
                vow = false;
                AddonNetwork.sendToTracking(new PacketVowFx(getId(), false), this);
            }
        }
    }

    // =====================================================================================================
    // animation (GeckoLib): the same walk / idle / punch clips as the Kite NPC
    // =====================================================================================================

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement_controller", 1, event -> {
            if (this.isInWater()) {
                return PlayState.STOP;
            } else if (event.isMoving()) {
                event.getController().setAnimationSpeed(1.0);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.walk"));
            } else {
                event.getController().setAnimationSpeed(0.5);
                return event.setAndContinue(RawAnimation.begin().thenLoop("animation.player_clone.idle"));
            }
        }));
        controllers.add(new AnimationController<>(this, "attack_controller", 1, state -> PlayState.STOP)
            .triggerableAnim("punch1", RawAnimation.begin().thenPlay("punch1"))
            .triggerableAnim("punch2", RawAnimation.begin().thenPlay("punch2")));
    }

    /** The Geo punch clips are gone: the NPC is drawn with the player model, so a punch is the normal arm swing. */
    @Override
    public void triggerAnim(String controllerName, String animName) {
        if (!level().isClientSide && animName.startsWith("punch")) net.hxhadventure.addon.SwingUtil.forceSwing(this, net.minecraft.world.InteractionHand.MAIN_HAND);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
