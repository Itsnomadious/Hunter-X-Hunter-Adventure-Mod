package net.hxhadventure.addon;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.EntityTeleportEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Hide and Seek's hooks into the game: the rooms cannot be broken, captives cannot teleport out, a dead user's key does not drop. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class HideSeekEvents {
    private HideSeekEvents() {}

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (NenRooms.isNen((net.minecraft.world.level.Level) e.getLevel()) && !e.getPlayer().isCreative()) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (NenRooms.isNen((net.minecraft.world.level.Level) e.getLevel())
            && !(e.getEntity() instanceof Player p && p.isCreative())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onExplosion(ExplosionEvent.Detonate e) {
        if (NenRooms.isNen(e.getLevel())) e.getAffectedBlocks().clear();
    }

    private static boolean captive(net.minecraft.world.entity.Entity en) {
        return en.getServer() != null && NenRooms.get(en.getServer()).isCaptive(en.getUUID());
    }

    @SubscribeEvent
    public static void onPearl(EntityTeleportEvent.EnderPearl e) {
        if (captive(e.getPlayer())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onChorus(EntityTeleportEvent.ChorusFruit e) {
        if (captive(e.getEntity())) e.setCanceled(true);
    }

    /** A user's Master Key goes with them: it does not drop (they get a new one). */
    @SubscribeEvent
    public static void onDrops(LivingDropsEvent e) {
        if (e.getEntity() instanceof Player) e.getDrops().removeIf(i -> i.getItem().getItem() instanceof MasterKeyItem);
    }

    /** A captive who dies is free (they respawn in the world). */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp && sp.getServer() != null) {
            NenRooms.get(sp.getServer()).forget(sp.getUUID());
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp && sp.getServer() != null && !NenRooms.isNen(sp.level())) {
            NenRooms.get(sp.getServer()).forget(sp.getUUID()); // held somewhere other than a room: not held any more
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getFrom().equals(NenRooms.DIM) && e.getEntity() instanceof ServerPlayer sp && sp.getServer() != null) {
            NenRooms rooms = NenRooms.get(sp.getServer());
            if (rooms.isCaptive(sp.getUUID())) rooms.forget(sp.getUUID());
        }
    }
}
