package net.hxhadventure.addon;

import java.util.EnumSet;
import java.util.function.Predicate;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

/**
 * The fighting of every melee NPC (it replaces the five copy-pasted goals). Always facing the target; a Hatsu-specific "prelude" may take the
 * tick (a channel, a pounce, a thread); otherwise: close the gap (rush from afar, steer straight at it when near instead of re-pathing every
 * few ticks), attack when in reach, and between attacks circle the target instead of standing still. Casters ({@link FightNpc#fightRange})
 * keep their distance as before.
 */
public final class NpcFightGoal extends Goal {

    /** What the goal needs from an NPC. */
    public interface FightNpc {
        NpcMelee melee();
        boolean inReach(LivingEntity t);
        void chooseAttack(LivingEntity t);
        /** How far it likes to stand from its target (0 = melee range). */
        default double fightRange() { return 0.0; }
    }

    private final PathfinderMob mob;
    private final FightNpc npc;
    private final Predicate<LivingEntity> prelude;
    private int repath;

    public NpcFightGoal(PathfinderMob mob, FightNpc npc, Predicate<LivingEntity> prelude) {
        this.mob = mob;
        this.npc = npc;
        this.prelude = prelude;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    /** Steering and footwork every tick, not every other tick (what Goal does by default): half-rate steering is what made them stutter. */
    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public boolean canUse() {
        LivingEntity t = mob.getTarget();
        return t != null && t.isAlive();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        LivingEntity t = mob.getTarget();
        if (t == null) return;
        NpcMelee melee = npc.melee();
        // it always faces its target; the lunge direction of a Strong attack is locked when its lock-in starts (see MeleeCore), so it can be sidestepped
        mob.getLookControl().setLookAt(t, 60.0f, 60.0f);
        if (prelude.test(t)) {
            mob.getNavigation().stop();
            return;
        }
        if (melee.mobilityBusy()) return;                      // a rush / lunge / dodge is carrying it

        double dist = mob.distanceTo(t);
        boolean inReach = npc.inReach(t);
        if (inReach) npc.chooseAttack(t);
        boolean attacking = melee.isAttacking();

        double want = npc.fightRange();
        if (want > 0.0 && !attacking) {
            casterMove(t, want, dist, inReach);
            return;
        }
        if (!inReach) {
            if (melee.tryRush(t, dist)) return;
            steer(t, dist, NpcFeelTuning.PURSUIT_SPEED);
        } else if (attacking) {
            if (dist > 1.6) steer(t, dist, NpcFeelTuning.PURSUIT_SPEED);   // keeps on top of it through a barrage
        } else {
            melee.footwork(t, dist);
        }
    }

    /** Pathfinds while far, steers straight at the target when near (no stop / re-path stutter). */
    private void steer(LivingEntity t, double dist, double speed) {
        if (dist < NpcFeelTuning.DIRECT_STEER_DIST && mob.hasLineOfSight(t)) {
            mob.getNavigation().stop();
            mob.getMoveControl().setWantedPosition(t.getX(), t.getY(), t.getZ(), speed);
            return;
        }
        if (--repath <= 0) {
            repath = 4 + mob.getRandom().nextInt(4);
            mob.getNavigation().moveTo(t, speed);
        }
    }

    private void casterMove(LivingEntity t, double want, double dist, boolean inReach) {
        if (dist > want + 2.0) {
            if (--repath <= 0) {
                repath = 4 + mob.getRandom().nextInt(4);
                mob.getNavigation().moveTo(t, 1.2);
            }
        } else if (dist < want * 0.45 && !inReach) {
            if (--repath <= 0) {
                repath = 10;
                Vec3 away = DefaultRandomPos.getPosAway(mob, 10, 4, t.position());
                if (away != null) mob.getNavigation().moveTo(away.x, away.y, away.z, 1.2);
            }
        } else if (!inReach) {
            mob.getNavigation().stop();
        }
    }
}
