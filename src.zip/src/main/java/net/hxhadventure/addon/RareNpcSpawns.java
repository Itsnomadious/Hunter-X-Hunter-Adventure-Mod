package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.hxhadventure.HxHAdventure;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Makes the roaming NPCs (Killua, Gon, Hisoka, Chrollo, Netero and the rest of the Nen fighters, plus Hina) turn up in the Overworld, rarely.
 *
 * <p>Every {@link RareNpcTuning#CHECK_INTERVAL_TICKS} each player is rolled; on a hit, one NPC (picked by weight) appears on the surface a few dozen
 * blocks away, out of sight where possible. They never despawn (they are persistent) and, like everywhere else, leave people alone until hurt.
 * A player is rolled again only after {@link RareNpcTuning#PLAYER_COOLDOWN_TICKS}, and nothing appears while another one is already near.
 * Neferpitou is not in the table on purpose, and the Hunter Exam staff and Kite have their own places and are not touched.
 */
@Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class RareNpcSpawns {
    /** Persistent player value: game time of the last NPC that turned up near them. */
    private static final String LAST_KEY = "hxh_rare_npc_last";

    private record Entry(Supplier<EntityType<?>> type, int weight) {}

    private static List<Entry> table;

    private RareNpcSpawns() {}

    /** Built on first use (the entity types are registered by then). */
    private static List<Entry> table() {
        if (table == null) {
            List<Entry> t = new ArrayList<>();
            add(t, () -> HxHEntities.KILLUA.get(), RareNpcTuning.WEIGHT_KILLUA);
            add(t, () -> HxHEntities.GON.get(), RareNpcTuning.WEIGHT_GON);
            add(t, () -> HxHEntities.HISOKA.get(), RareNpcTuning.WEIGHT_HISOKA);
            add(t, () -> HxHEntities.CHROLLO.get(), RareNpcTuning.WEIGHT_CHROLLO);
            add(t, () -> HxHEntities.NETERO.get(), RareNpcTuning.WEIGHT_NETERO);
            add(t, () -> HxHEntities.KURAPIKA.get(), RareNpcTuning.WEIGHT_KURAPIKA);
            add(t, () -> HxHEntities.ILLUMI.get(), RareNpcTuning.WEIGHT_ILLUMI);
            add(t, () -> HxHEntities.BISKY.get(), RareNpcTuning.WEIGHT_BISKY);
            add(t, () -> HxHEntities.HINA.get(), RareNpcTuning.WEIGHT_HINA);
            add(t, () -> HxHEntities.SILVA.get(), RareNpcTuning.WEIGHT_SILVA);
            add(t, () -> HxHEntities.ZENO.get(), RareNpcTuning.WEIGHT_ZENO);
            // Neferpitou: intentionally absent
            table = t;
        }
        return table;
    }

    private static void add(List<Entry> t, Supplier<EntityType<?>> type, int weight) {
        if (weight > 0) t.add(new Entry(type, weight));
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (!RareNpcTuning.ENABLED || e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer sp)) return;
        if (sp.tickCount % RareNpcTuning.CHECK_INTERVAL_TICKS != 0 || sp.isSpectator()) return;
        if (!(sp.level() instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) return;

        RandomSource rng = level.random;
        if (rng.nextDouble() >= RareNpcTuning.CHANCE_PER_CHECK) return;

        CompoundTag per = sp.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        long now = level.getGameTime();
        if (per.contains(LAST_KEY) && now - per.getLong(LAST_KEY) < RareNpcTuning.PLAYER_COOLDOWN_TICKS) return;
        if (crowded(level, sp)) return;

        List<Entry> entries = table();
        int total = 0;
        for (Entry en : entries) total += en.weight();
        if (total <= 0) return;
        int roll = rng.nextInt(total);
        EntityType<?> chosen = entries.get(0).type().get();
        for (Entry en : entries) {
            roll -= en.weight();
            if (roll < 0) {
                chosen = en.type().get();
                break;
            }
        }

        if (spawnNear(level, sp, chosen, rng)) {
            per.putLong(LAST_KEY, now);
            sp.getPersistentData().put(Player.PERSISTED_NBT_TAG, per);
        }
    }

    /** True if one of the roaming NPCs is already close to the player. */
    private static boolean crowded(ServerLevel level, ServerPlayer sp) {
        AABB box = sp.getBoundingBox().inflate(RareNpcTuning.CROWD_RADIUS);
        for (Entry en : table()) {
            EntityType<?> type = en.type().get();
            if (!level.getEntities(type, box, Entity::isAlive).isEmpty()) return true;
        }
        return false;
    }

    private static boolean spawnNear(ServerLevel level, ServerPlayer sp, EntityType<?> type, RandomSource rng) {
        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = rng.nextDouble() * Math.PI * 2.0;
            double dist = RareNpcTuning.MIN_DISTANCE + rng.nextDouble() * (RareNpcTuning.MAX_DISTANCE - RareNpcTuning.MIN_DISTANCE);
            int x = (int) Math.floor(sp.getX() + Math.cos(angle) * dist);
            int z = (int) Math.floor(sp.getZ() + Math.sin(angle) * dist);
            BlockPos column = new BlockPos(x, 0, z);
            if (!level.hasChunkAt(column)) continue;

            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos feet = new BlockPos(x, y, z);
            BlockPos floor = feet.below();
            if (!level.getFluidState(floor).isEmpty() || !level.getFluidState(feet).isEmpty()) continue;
            if (!level.getBlockState(floor).isFaceSturdy(level, floor, Direction.UP)) continue;
            if (!level.canSeeSky(feet)) continue;
            if (!level.noCollision(type.getAABB(x + 0.5, y, z + 0.5))) continue;

            Entity entity = type.create(level);
            if (!(entity instanceof Mob mob)) continue;
            mob.moveTo(x + 0.5, y, z + 0.5, rng.nextFloat() * 360.0f, 0.0f);
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(feet), MobSpawnType.EVENT, null, null);
            level.addFreshEntity(mob);
            return true;
        }
        return false;
    }
}
