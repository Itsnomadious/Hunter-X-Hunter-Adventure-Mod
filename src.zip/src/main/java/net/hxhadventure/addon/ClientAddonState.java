package net.hxhadventure.addon;

/** Client-side mirror of the local player's addon state. No client-only imports, safe to load anywhere. */
public final class ClientAddonState {
    private ClientAddonState() {}

    /** The local player's Hunter Exam stage (0 to 3, see HunterExam#stage); 3 = Hunter License menu. */
    public static int examStage;
    public static boolean zetsu;
    public static boolean en;
    public static boolean emperor;
    public static int bookState;
    public static int bookmark = -1;
    public static int activePage = -1;
    public static int stolenMask;
    public static int stolenKit;
    public static boolean hostKit;
    public static boolean bookHeld;
    public static float lifespan = Tuning.LIFESPAN_MAX;
    public static float enRadius;
    /** The En slider's saved pick (-1 = never set). */
    public static float enChosen = -1f;
    /** The Ren size slider's saved pick (1 = normal). */
    public static float renSize = 1f;
    public static boolean ken;
    public static boolean ko;
    /** In (hides your Nen), Gyo (sees hidden Nen), and the Genius-In "show my Nen" choice. */
    public static boolean in;
    public static boolean gyo;
    public static boolean inVisible;
    /** Shu (weapon aura coating) is on. */
    public static boolean shu;
    public static final int[] level = new int[NenSkill.values().length];
    public static final float[] progress = new float[NenSkill.values().length];

    static {
        java.util.Arrays.fill(level, 1);
    }

    /** One-line description of the active aura form for the HUD and the Mastery screen. */
    public static String formLabel() {
        if (ko) return "Ko";
        if (ken) return "Ken";
        return "None";
    }

    public static void reset() {
        zetsu = false;
        en = false;
        emperor = false;
        bookState = 0;
        bookmark = -1;
        activePage = -1;
        stolenMask = 0;
        stolenKit = 0;
        hostKit = false;
        bookHeld = false;
        lifespan = Tuning.LIFESPAN_MAX;
        enRadius = 0;
        enChosen = -1f;
        renSize = 1f;
        ken = false;
        ko = false;
        in = false;
        gyo = false;
        inVisible = false;
        shu = false;
        java.util.Arrays.fill(level, 1);
        java.util.Arrays.fill(progress, 0f);
    }
}
