package net.hxhadventure.addon;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/** Registers Blinky's head without touching ModItem (same way as Shalnark's phone). */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class BlinkyItems {
    private BlinkyItems() {}

    public static Item HEAD;

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.ITEMS, helper -> {
            HEAD = new BlinkyHeadItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "blinky"), HEAD);
        });
    }
}
