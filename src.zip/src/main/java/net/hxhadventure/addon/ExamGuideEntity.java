package net.hxhadventure.addon;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * The Hunter Exam guide: one stands in every village (see {@link VillageGuides}) and, when right-clicked, tells the player where the nearest
 * Hunter Exam hall is (see {@link ExamGuide}). Same behaviour as the other exam NPCs: stands still, looks at players, cannot be hurt.
 *
 * <p>{@code villageKey} ties the guide to the village it was made for (0 = not made by a village, e.g. from a spawn egg: it is left alone).
 */
public class ExamGuideEntity extends ExamNpcEntity {
    private long villageKey;

    public ExamGuideEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public long getVillageKey() {
        return villageKey;
    }

    public void setVillageKey(long key) {
        this.villageKey = key;
    }

    /** Not used: the guide has no exam dialogue, {@link #mobInteract} is overridden. */
    @Override
    public int examKind() {
        return HunterExam.KIND_RECEPTIONIST;
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!this.level().isClientSide && player instanceof ServerPlayer sp) {
            ExamGuide.talk(sp, this);
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putLong("VillageKey", villageKey);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.villageKey = tag.getLong("VillageKey");
    }
}
