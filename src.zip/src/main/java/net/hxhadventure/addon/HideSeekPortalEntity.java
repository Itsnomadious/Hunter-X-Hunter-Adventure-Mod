package net.hxhadventure.addon;

import java.util.List;
import java.util.UUID;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import org.joml.Vector3f;

/**
 * A Hide and Seek circle: a ring of symbols drawn on a face of a block. Walk into it and you are in the room it is connected to.
 * The same entity is the exit circle on the wall of every room ({@link #isExit()}), which takes you back where you came from.
 *
 * <p>The hitbox is a flat slab, 2 x 2 blocks across and a little over half a block deep, standing on the block face the circle was drawn on.
 * Right-click one with a Master Key to connect it to the room the key has selected; its owner (or a creative player) hits it to close it.
 */
public class HideSeekPortalEntity extends Entity {
    private static final EntityDataAccessor<Integer> FACING = SynchedEntityData.defineId(HideSeekPortalEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> EXIT = SynchedEntityData.defineId(HideSeekPortalEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> ROOM = SynchedEntityData.defineId(HideSeekPortalEntity.class, EntityDataSerializers.INT);

    private static final double HALF = 1.0;      // the circle is 2 blocks across
    private static final double BACK = 0.06;     // how far the hitbox reaches behind the centre (into the block face)
    private static final double FRONT = 0.55;    // ...and in front of it
    private static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.45f, 0.75f, 1.0f), 1.0f);

    /** Plain field copy of the facing: Entity's constructor calls setPos before the synched data exists. */
    private Direction dir;
    private UUID owner;

    public HideSeekPortalEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noCulling = true;
        this.setNoGravity(true);
    }

    /** Sets up a freshly made circle: which way it faces, its centre, whether it is a room's exit, and the room it leads to. */
    public void configure(Direction facing, Vec3 centre, boolean exit, int room, UUID owner) {
        this.dir = facing;
        this.entityData.set(FACING, facing.get3DDataValue());
        this.entityData.set(EXIT, exit);
        this.entityData.set(ROOM, room);
        this.owner = owner;
        this.setPos(centre.x, centre.y, centre.z);
    }

    public Direction facing() {
        if (dir != null) return dir;
        int v = this.entityData.get(FACING);
        return v >= 0 && v < 6 ? Direction.from3DDataValue(v) : Direction.SOUTH;
    }

    public boolean isExit() {
        return this.entityData.get(EXIT);
    }

    public int room() {
        return this.entityData.get(ROOM);
    }

    public void setRoom(int room) {
        this.entityData.set(ROOM, room);
    }

    public UUID owner() {
        return owner;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(FACING, 6); // not a real direction, so the first real one always counts as a change and reaches the client
        this.entityData.define(EXIT, false);
        this.entityData.define(ROOM, -1);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (FACING.equals(key)) {
            int v = this.entityData.get(FACING);
            if (v >= 0 && v < 6) {
                this.dir = Direction.from3DDataValue(v);
                refreshBox();
            }
        }
    }

    // ---------------------------------------------------------------- hitbox

    @Override
    public void setPos(double x, double y, double z) {
        super.setPos(x, y, z);
        refreshBox();
    }

    private void refreshBox() {
        if (dir == null) return; // still inside Entity's constructor
        double x = getX(), y = getY(), z = getZ();
        double[] c = {x, y, z};
        double[] lo = {x - HALF, y - HALF, z - HALF};
        double[] hi = {x + HALF, y + HALF, z + HALF};
        int axis = dir.getAxis().ordinal(); // Axis: X, Y, Z in this order
        if (dir.getAxisDirection() == Direction.AxisDirection.POSITIVE) {
            lo[axis] = c[axis] - BACK;
            hi[axis] = c[axis] + FRONT;
        } else {
            lo[axis] = c[axis] - FRONT;
            hi[axis] = c[axis] + BACK;
        }
        setBoundingBox(new AABB(lo[0], lo[1], lo[2], hi[0], hi[1], hi[2]));
    }

    // ---------------------------------------------------------------- save / sync

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        Direction f = Direction.from3DDataValue(tag.getInt("Facing"));
        this.dir = f;
        this.entityData.set(FACING, f.get3DDataValue());
        this.entityData.set(EXIT, tag.getBoolean("Exit"));
        this.entityData.set(ROOM, tag.contains("Room") ? tag.getInt("Room") : -1);
        this.owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        refreshBox();
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Facing", facing().get3DDataValue());
        tag.putBoolean("Exit", isExit());
        tag.putInt("Room", room());
        if (owner != null) tag.putUUID("Owner", owner);
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    // ---------------------------------------------------------------- being a thing in the world

    @Override
    public boolean isPickable() {
        return !isRemoved();
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel sl)) return;
        if (tickCount % 4 == 0) {
            List<LivingEntity> touching = sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox(), p -> p.isAlive() && !p.isSpectator() && !(p instanceof ArmorStand));
            for (LivingEntity p : touching) NenRooms.touch(this, p);
        }
    }

    /** Only the owner (or a creative player) can close a circle; an exit circle is never closed. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved()) return false;
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            close();
            return true;
        }
        if (source.getEntity() instanceof ServerPlayer p) {
            boolean mine = p.getUUID().equals(owner);
            if (p.isCreative() || (mine && !isExit())) {
                close();
                return true;
            }
        }
        return false;
    }

    private void close() {
        if (level() instanceof ServerLevel sl) {
            if (owner != null && sl.getServer() != null) NenRooms.get(sl.getServer()).unregisterPortal(owner, getUUID());
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.8f, 1.4f);
        }
        discard();
    }

    /** Right-click with a Master Key: connect this circle to the key's selected room (crouch: mark it as a place an exit can lead to; on an exit: link the exit to the marked circle, or crouch to free the captives). */
    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (!(held.getItem() instanceof MasterKeyItem)) return InteractionResult.PASS;
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer sp) || sp.getServer() == null) return InteractionResult.CONSUME;
        UUID keyOwner = MasterKeyItem.ownerOf(held);
        if (keyOwner == null || !keyOwner.equals(sp.getUUID())) {
            sp.displayClientMessage(Component.literal("§7This key is not yours"), true);
            return InteractionResult.CONSUME;
        }
        NenRooms rooms = NenRooms.get(sp.getServer());
        if (isExit()) {
            NenRooms.Room r = rooms.room(room());
            if (r == null || !r.owner.equals(keyOwner)) {
                sp.displayClientMessage(Component.literal("§7This is not one of your rooms"), true);
            } else if (sp.isSecondaryUseActive()) {
                int n = rooms.releaseRoom(sp.getServer(), r.id);
                sp.displayClientMessage(Component.literal("§b" + (n == 0 ? "Nobody is held in this room" : "Let " + n + " go: they can leave now")), true);
            } else {
                NenRooms.Link marked = rooms.marked(keyOwner);
                if (marked != null) {
                    r.link = marked;
                    rooms.setDirty();
                    sp.displayClientMessage(Component.literal("§bThis exit now leads to the circle you marked"), true);
                } else if (r.link != null) {
                    r.link = null;
                    rooms.setDirty();
                    sp.displayClientMessage(Component.literal("§bThis exit leads back to wherever each visitor came from again"), true);
                } else {
                    sp.displayClientMessage(Component.literal("§b" + rooms.describe(r) + " §7(mark a circle with crouch + key, then use the key here to link the exit to it)"), true);
                }
            }
            return InteractionResult.CONSUME;
        }
        if (owner != null && !owner.equals(sp.getUUID())) {
            sp.displayClientMessage(Component.literal("§7This circle is not yours"), true);
            return InteractionResult.CONSUME;
        }
        if (sp.isSecondaryUseActive()) { // crouch: mark this circle, so a room's exit can be linked to it
            rooms.mark(keyOwner, NenRooms.linkFor(this));
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8f, 1.2f);
            sp.displayClientMessage(Component.literal("§bCircle marked. Use the key on a room's exit to link the exit to it"), true);
            return InteractionResult.CONSUME;
        }
        net.hxhadventure.abilities.Combat cb = net.hxhadventure.abilities.Combat.get(sp);
        NenRooms.Room sel = rooms.selectedRoom(keyOwner, cb == null ? 0 : cb.getHatsuLevel());
        if (sel == null) {
            sp.displayClientMessage(Component.literal("§7You have no room yet. Crouch and use the key in the air to make one"), true);
            return InteractionResult.CONSUME;
        }
        setRoom(sel.id);
        level().playSound(null, getX(), getY(), getZ(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8f, 1.6f);
        sp.displayClientMessage(Component.literal("§bCircle connected to " + rooms.describe(sel)), true);
        return InteractionResult.CONSUME;
    }
}
