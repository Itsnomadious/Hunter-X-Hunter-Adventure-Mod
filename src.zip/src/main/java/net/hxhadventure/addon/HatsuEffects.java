package net.hxhadventure.addon;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/**
 * "Forced Zetsu": while it lasts the holder cannot use Ten or Ren (players), and Kite cannot
 * raise their aura. Chain Jail applies it to its victim; it can also be given with
 * {@code /effect give <target> hxhadventure:forced_zetsu}.
 */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.MOD)
public final class HatsuEffects {
    private HatsuEffects() {}

    /** Set when the effect is registered; always null-check through {@link #has}. */
    public static MobEffect FORCED_ZETSU;

    private static final class ForcedZetsuEffect extends MobEffect {
        ForcedZetsuEffect() {
            super(MobEffectCategory.HARMFUL, 0x5B2A86);
        }
    }

    /** "Properties of Rubber and Gum" (Bungee Gum): slows by a step per level. The tether itself is enforced by BungeeGum. */
    public static MobEffect RUBBER_GUM;

    private static final class RubberGumEffect extends MobEffect {
        RubberGumEffect() {
            super(MobEffectCategory.HARMFUL, 0xFF6FB5);
            addAttributeModifier(Attributes.MOVEMENT_SPEED, "7C1E5A3D-92B4-4F6A-8E01-3B5D7A9C2E44",
                -Tuning.GUM_SLOW_PER_STAGE, AttributeModifier.Operation.MULTIPLY_TOTAL); // scaled by (amplifier + 1)
        }
    }

    /**
     * "Paralysis" from Lightning Aura: the holder cannot move (walking speed 0, no jumping: see LightningEvents). Lightning Aura users
     * are immune ({@link LightningAura#isImmune}).
     */
    public static MobEffect LIGHTNING_STUN;

    private static final class LightningStunEffect extends MobEffect {
        LightningStunEffect() {
            super(MobEffectCategory.HARMFUL, 0x8CC8FF);
            addAttributeModifier(Attributes.MOVEMENT_SPEED, "3F6B1A52-5C0E-4D7B-9A38-61D2E04B7C15",
                -1.0, AttributeModifier.Operation.MULTIPLY_TOTAL);
        }
    }

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.MOB_EFFECTS, helper -> {
            FORCED_ZETSU = new ForcedZetsuEffect();
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "forced_zetsu"), FORCED_ZETSU);
            RUBBER_GUM = new RubberGumEffect();
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "rubber_and_gum"), RUBBER_GUM);
            LIGHTNING_STUN = new LightningStunEffect();
            helper.register(ResourceLocation.fromNamespaceAndPath("hxhadventure", "lightning_stun"), LIGHTNING_STUN);
        });
    }

    public static boolean has(LivingEntity e) {
        return FORCED_ZETSU != null && e != null && e.hasEffect(FORCED_ZETSU);
    }

    /** Applies (or refreshes) the effect. Ambient = false, particles hidden, icon shown. */
    public static void apply(LivingEntity e, int ticks) {
        apply(e, ticks, true);
    }

    /** showIcon = false for a secret Chain Jail: the victim gets no effect icon. */
    public static void apply(LivingEntity e, int ticks, boolean showIcon) {
        if (FORCED_ZETSU == null || e == null) return;
        MobEffectInstance cur = e.getEffect(FORCED_ZETSU);
        if (cur != null && cur.getDuration() >= ticks) return; // already long enough: no packet spam
        e.addEffect(new MobEffectInstance(FORCED_ZETSU, ticks, 0, false, false, showIcon));
    }

    public static void remove(LivingEntity e) {
        if (FORCED_ZETSU != null && e != null) e.removeEffect(FORCED_ZETSU);
    }

    public static boolean hasGum(LivingEntity e) {
        return RUBBER_GUM != null && e != null && e.hasEffect(RUBBER_GUM);
    }

    /** Applies or refreshes the debuff at this level (amplifier 0 = stage I). A different level or icon setting replaces the old one outright. */
    public static void applyGum(LivingEntity e, int ticks, int amplifier, boolean showIcon) {
        if (RUBBER_GUM == null || e == null) return;
        MobEffectInstance cur = e.getEffect(RUBBER_GUM);
        boolean same = cur != null && cur.getAmplifier() == amplifier && cur.showIcon() == showIcon;
        if (same && cur.getDuration() >= ticks / 2) return; // fresh enough: no packet spam
        if (cur != null && !same) e.removeEffect(RUBBER_GUM);
        e.addEffect(new MobEffectInstance(RUBBER_GUM, ticks, amplifier, false, false, showIcon));
    }

    public static boolean isStunned(LivingEntity e) {
        return LIGHTNING_STUN != null && e != null && e.hasEffect(LIGHTNING_STUN);
    }

    /** Stuns for this long unless the target is a Lightning Aura user. A longer stun already running is kept. */
    public static void stun(LivingEntity e, int ticks) {
        if (LIGHTNING_STUN == null || e == null || LightningAura.isImmune(e)) return;
        MobEffectInstance cur = e.getEffect(LIGHTNING_STUN);
        if (cur != null && cur.getDuration() >= ticks) return;
        e.addEffect(new MobEffectInstance(LIGHTNING_STUN, ticks, 0, false, false, true));
    }

    public static void removeStun(LivingEntity e) {
        if (LIGHTNING_STUN != null && e != null) e.removeEffect(LIGHTNING_STUN);
    }

    public static void removeGum(LivingEntity e) {
        if (RUBBER_GUM != null && e != null) e.removeEffect(RUBBER_GUM);
    }
}
