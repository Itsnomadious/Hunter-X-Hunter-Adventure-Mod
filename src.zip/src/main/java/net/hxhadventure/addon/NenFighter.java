package net.hxhadventure.addon;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * The shared brain of the Nen-fighter NPCs (Netero, Zeno, Silva, Bisky, Illumi, Kurapika, Killua). They are built to behave like a
 * player of their levels: they leave people alone until hurt (or, for a grudge like Kurapika's, until they see the enemy), then they fight with
 * <ul>
 *   <li><b>Ten</b>: always on while they have aura (regen, a little armour and speed);</li>
 *   <li><b>Ren</b>: the offensive burst, used while closing in on / hitting a target that is not hurting them much, only while the pool is healthy,
 *       and never for long (a burst, then a cool-off), because it is the most expensive form;</li>
 *   <li><b>Ken</b>: the defensive stance, taken when the pressure on them is high (a lot of damage lately) or when the pool is too low for Ren;</li>
 *   <li>Attack / Strong attack / Barrage with the same numbers and timing a player's punches have, and their own Hatsu on top ({@link #tickHatsu}).</li>
 * </ul>
 * The upkeep of Ren and Ken is the player's (a share of max aura per second); when the pool runs dry every form goes until a share of it has come back.
 * Subclasses only add their Hatsu: they override {@link #tickHatsu}, and optionally {@link #hatsuBusy}, {@link #preferredRange} and the damage hooks.
 */
public abstract class NenFighter extends PathfinderMob implements NpcPose, NpcMelee.Host, NpcFightGoal.FightNpc {

    /** Synced to the client: which aura forms to draw (see the F_ flags). */
    private static final EntityDataAccessor<Integer> NEN_FLAGS = SynchedEntityData.defineId(NenFighter.class, EntityDataSerializers.INT);
    public static final int F_TEN = 1, F_REN = 2, F_KEN = 4;

    private static final UUID MOD_AFF_SPEED = UUID.fromString("b3000000-0000-4000-8000-000000000004");
    private static final UUID MOD_ATTACK_SLOW = UUID.fromString("b3000000-0000-4000-8000-000000000005");
    private static final UUID MOD_TEN_SPEED = UUID.fromString("b3000000-0000-4000-8000-000000000006");

    /** Ren and Ken keep these limits so a fight can be won by hitting, not only by out-running: Ten / Ken speed is capped at +100%, Ren at +130%. */
    private static final float SPEED_CAP = Tuning.NPC_TEN_SPEED_CAP, REN_SPEED_CAP = 1.3f;

    // ---- the efficiency rules of the aura forms ----
    private static final int FORM_SWITCH_TICKS = 5;           // delay before a form change applies
    private static final int FORM_MIN_HOLD_TICKS = 16;        // a form is held at least this long, so they do not flicker between Ren and Ken
    private static final int REN_MAX_TICKS = 140;             // one Ren burst lasts at most this long...
    private static final int REN_REST_TICKS = 90;             // ...and Ren cannot be used again for this long
    private static final float REN_MIN_FRACTION = 0.30f;      // Ren only while the pool is above this share of its max
    private static final float REN_STOP_FRACTION = 0.18f;     // ...and it ends when it drops below this
    private static final float KEN_MIN_FRACTION = 0.06f;      // below this share of the pool only Ten is left
    private static final float PRESSURE_FRACTION = 0.04f;     // damage taken lately (share of max health) that makes them guard with Ken
    private static final int EXHAUST_FOE_MEMORY_TICKS = 1200; // how long something that hurt them counts as an enemy

    protected final NpcStats stats;
    protected final int nenType;

    // ---- aura / Nen ----
    private final float maxAura;
    private float aura;
    private boolean exhausted;
    private boolean ten, ren, ken;
    private int formCooldown, formHeld, renTicks, renRest;
    private int lastHitTick = -1000;
    private int idleTicks;
    private boolean wasFighting;
    private float recentDamage;

    // ---- attacks: the melee body (combos, Strong attack, Barrage, footwork) lives in NpcMelee / MeleeCore ----
    private final NpcMelee melee;
    private final float meleeGovern;

    private final Map<UUID, Long> foes = new HashMap<>();

    protected NenFighter(EntityType<? extends PathfinderMob> type, Level level, NpcStats stats) {
        super(type, level);
        this.stats = stats;
        this.nenType = stats.nenType;
        this.maxAura = stats.maxAura();
        this.aura = maxAura;
        this.xpReward = stats.xp;
        this.melee = new NpcMelee(this, this, meleeCfg(stats));
        this.meleeGovern = NpcBalance.governedMelee(profile(stats));
    }

    /** The attack numbers of an NPC (Combat.java's, from its stats). */
    static MeleeCore.Cfg meleeCfg(NpcStats s) {
        MeleeCore.Cfg c = new MeleeCore.Cfg();
        c.strongCharge = s.strongCharge;
        c.strongMaxHold = s.strongCharge + 15;
        c.strongCooldown = s.strongCooldown;
        c.barrageCooldown = s.barrageCooldown;
        c.barrageGap = s.barrageHitGap;
        c.weightBarrage = s.weightBarrage;
        c.weightStrong = s.weightStrong;
        return c;
    }

    private static final java.util.Map<String, MeleeCore.Cfg> CFGS = new java.util.HashMap<>();

    /** What the balance model (NpcBalance) knows about this NPC. */
    static synchronized NpcBalance.Profile profile(NpcStats s) {
        MeleeCore.Cfg cfg = CFGS.computeIfAbsent(s.id, k -> meleeCfg(s));
        return new NpcBalance.Profile(s.id, s.health, s.hatsu, s.ten).mult(s.meleeMult)
            .affinity(Affinity.dealt(s.nenType), Affinity.taken(s.nenType)).ren(NpcFeelTuning.FIGHTERS_USE_REN ? 0.5 : 0.0).regen(s.healPerSecond).cfg(cfg);
    }

    public static AttributeSupplier.Builder createAttributes(NpcStats s) {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, NpcBalance.governedHealth(profile(s)))
            .add(Attributes.MOVEMENT_SPEED, s.speed)
            .add(Attributes.ATTACK_DAMAGE, 5.0)
            .add(Attributes.FOLLOW_RANGE, s.followRange)
            .add(Attributes.KNOCKBACK_RESISTANCE, s.knockbackRes);
    }

    public NpcStats stats() { return stats; }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(NEN_FLAGS, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new NpcFightGoal(this, this, t -> false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        // no target goals on purpose: they only fight what hurt them (see hurt()) or what they hold a grudge against (see hostileOnSight())
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        this.aura = maxAura;
        this.setPersistenceRequired();
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("NpcAura", aura);
        tag.putBoolean("NpcExhausted", exhausted);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("NpcAura")) aura = Math.max(0f, Math.min(maxAura, tag.getFloat("NpcAura")));
        exhausted = tag.getBoolean("NpcExhausted");
    }

    // =====================================================================================================
    // what subclasses implement / may override
    // =====================================================================================================

    /** Called every server tick while alive. {@code target} is null at peace. The Hatsu goes here: decide, pay ({@link #payAura}), act. */
    protected abstract void tickHatsu(@Nullable LivingEntity target, boolean fighting);

    /** True while the Hatsu holds the NPC in place (a channel, a charge): no walking, no punching. They still face the target. */
    protected boolean hatsuBusy() { return false; }

    /** How far the NPC likes to stand from its target: 0 = melee range. Casters return a few blocks; they still punch when the target gets in reach. */
    protected double preferredRange() { return 0.0; }

    /** The fight is over (target gone / dead): clean up anything the Hatsu left out. */
    protected void onFightEnd() { }

    /** Something hurt this NPC and became its enemy. */
    protected void onProvoked(LivingEntity attacker) { }

    /** A grudge: something that is attacked on sight, without being provoked (Kurapika and Chrollo). */
    protected boolean hostileOnSight(LivingEntity e) { return false; }

    /** Extra things that are never enemies (own summons, allies). */
    protected boolean isAlly(Entity e) { return false; }

    /** True when this hit is dodged / negated before it lands (Killua's Whirlwind and Godspeed). Called from the attack event. */
    public boolean negatesHit(DamageSource src, float amount) { return false; }

    /** Further multiplier on the damage taken (a Hatsu's armour). */
    protected float extraIncomingMult(DamageSource src) { return 1.0f; }

    /** Further multiplier on the melee damage dealt (a Hatsu's damage boost). */
    protected float extraOutgoingMult(@Nullable DamageSource src) { return 1.0f; }

    /** Further speed bonus (a fraction, 0.5 = +50%) from the Hatsu. */
    protected float extraSpeedBonus() { return 0.0f; }

    /** Ren is not allowed right now (Godspeed seals it). */
    protected boolean renForbidden() { return false; }

    /** Both arms are held out (a pose some Hatsu use). */
    @Override
    public boolean armsOut() { return false; }

    // =====================================================================================================
    // queries
    // =====================================================================================================

    public float aura() { return aura; }

    public float maxAura() { return maxAura; }

    public float auraFraction() { return maxAura <= 0 ? 0 : aura / maxAura; }

    public boolean isExhausted() { return exhausted; }

    public boolean isAttacking() { return melee.isAttacking(); }

    @Override
    public NpcMelee melee() { return melee; }

    @Override
    public double fightRange() { return preferredRange(); }

    public boolean isTen() { return ten; }

    public boolean isRen() { return ren; }

    public boolean isKen() { return ken; }

    public int hatsuLevel() { return stats.hatsu; }

    public int lastHitAge() { return tickCount - lastHitTick; }

    /** Nen can be used: aura left and nothing (Chain Jail, Forced Zetsu) holding it down. */
    public boolean canUseNen() {
        return !exhausted && !ExtrasHooks.hatsuForced(this);
    }

    public int nenFlags() { return this.entityData.get(NEN_FLAGS); }

    /** The spirit bonus of the Hatsu level: multiplies punches and Hatsu damage. */
    public float spiritBonus() { return stats.spiritBonus(); }

    /** What a Hatsu hit's base damage is multiplied by: the Hatsu level's spirit bonus and the Nen type's affinity (what a player's Hatsu uses). */
    public float hatsuScale() { return spiritBonus() * Affinity.dealt(nenType); }

    /** Deals Hatsu damage the way a player's Hatsu does (marked, so Ten / Ren / Ken do not multiply it again). */
    public boolean hatsuHurt(LivingEntity victim, float baseDamage) {
        return Vows.hatsuHurt(victim, damageSources().mobAttack(this), baseDamage * hatsuScale());
    }

    /** Same, but with an explicit source (an arrow, an explosion, a needle...). The amount is NOT scaled. */
    public boolean hatsuHurt(LivingEntity victim, DamageSource src, float amount) {
        return Vows.hatsuHurt(victim, src, amount);
    }

    /** Multiplier on damage dealt (affinity, the aura form, the Hatsu's boost). Hatsu hits skip the aura form, like a player's. */
    public float outgoingMult(@Nullable DamageSource src) {
        float m = Affinity.dealt(nenType) * extraOutgoingMult(src);
        if (src == null || !Vows.isHatsuHit(src)) m *= NpcAura.outgoing(stats.ten, ten, ren, ken, false);
        return m;
    }

    /** Multiplier on damage taken (affinity, the aura form's durability, the Hatsu's armour). */
    public float incomingMult(DamageSource src) {
        float m = Affinity.taken(nenType);
        if (src.is(DamageTypes.LIGHTNING_BOLT)) m *= 1f - Affinity.lightningReduction(nenType);
        if (src.is(DamageTypes.FALL)) m *= 1f - Affinity.fallReduction(nenType);
        if (Affinity.isStatusDamage(src)) m *= 1f - Affinity.statusReduction(nenType);
        m *= NpcAura.incoming(stats.ten, ten, ren, ken, false);
        return m * extraIncomingMult(src);
    }

    /** Pays for an ability out of the aura (Transmuters pay less). False, and nothing paid, if it cannot be afforded. */
    protected boolean payAura(float cost) {
        if (!canUseNen()) return false;
        float c = cost * (1f - Math.min(0.5f, Affinity.abilityRefund(nenType)));
        if (aura < c) return false;
        aura -= c;
        return true;
    }

    protected boolean canAfford(float cost) {
        return canUseNen() && aura >= cost * (1f - Math.min(0.5f, Affinity.abilityRefund(nenType)));
    }

    /** Takes aura that is not a normal ability cost (a continuous upkeep). The pool can run dry from it. */
    protected void drainAura(float amount) {
        aura = Math.max(0f, aura - amount);
    }

    /** Whether something counts as an enemy: what they are fighting, or anything that hurt them lately. Area hits only touch these. */
    public boolean isFoe(Entity e) {
        if (!(e instanceof LivingEntity le) || e == this || !le.isAlive() || e instanceof ArmorStand || e.getType() == getType() || isAlly(e)) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        if (e == getTarget()) return true;
        Long t = foes.get(e.getUUID());
        return t != null && level().getGameTime() - t <= EXHAUST_FOE_MEMORY_TICKS;
    }

    protected void noteFoe(LivingEntity e) {
        foes.put(e.getUUID(), level().getGameTime());
        if (foes.size() > 32) {
            long now = level().getGameTime();
            foes.values().removeIf(t -> now - t > EXHAUST_FOE_MEMORY_TICKS);
        }
    }

    protected boolean validTarget(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof ArmorStand || e.getType() == getType() || isAlly(e)) return false;
        return !(e instanceof Player p && (p.isCreative() || p.isSpectator()));
    }

    // =====================================================================================================
    // being hurt: they fight back
    // =====================================================================================================

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide) {
            lastHitTick = tickCount;
            recentDamage += amount;
            if (source.getEntity() instanceof LivingEntity attacker && validTarget(attacker)) provoke(attacker);
        }
        return hit;
    }

    /** Something attacked this NPC: it becomes an enemy, and the NPC goes for it unless it is already busy with something close. */
    public void provoke(LivingEntity attacker) {
        if (level().isClientSide || !validTarget(attacker)) return;
        noteFoe(attacker);
        LivingEntity cur = getTarget();
        if (cur == null || !cur.isAlive() || distanceToSqr(cur) > 16.0) setTarget(attacker);
        onProvoked(attacker);
    }

    // =====================================================================================================
    // per tick (server)
    // =====================================================================================================

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !isAlive() || !(level() instanceof ServerLevel)) return;
        LivingEntity t = getTarget();
        if (t != null && (!t.isAlive() || t.level() != level() || distanceToSqr(t) > 96.0 * 96.0
            || (t instanceof Player p && (p.isCreative() || p.isSpectator())))) {
            setTarget(null);
            t = null;
        }
        if (t == null && tickCount % 10 == 0 && canUseNen()) t = lookForGrudge();
        boolean fighting = t != null;
        if (fighting) idleTicks = 0; else idleTicks++;
        if (!fighting && wasFighting) {
            cancelAttack();
            onFightEnd();
        }
        wasFighting = fighting;
        recentDamage *= 0.97f;

        tickNen(fighting, t);
        melee.tick(t, t != null && inReach(t), hatsuBusy());
        tickHatsu(t, fighting);
        refreshModifiers();
        syncFlags();
    }

    @Nullable
    private LivingEntity lookForGrudge() {
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(32.0, 12.0, 32.0), x -> x != this && x.isAlive())) {
            if (validTarget(e) && hostileOnSight(e) && hasLineOfSight(e)) {
                noteFoe(e);
                setTarget(e);
                return e;
            }
        }
        return null;
    }

    // =====================================================================================================
    // Nen: the aura pool and the forms (Ten always, Ren as the burst, Ken as the guard)
    // =====================================================================================================

    private void tickNen(boolean fighting, @Nullable LivingEntity t) {
        if (formCooldown > 0) formCooldown--;
        formHeld++;
        if (renRest > 0) renRest--;

        final float perTick = 1f / 20f;
        float eff = Math.min(0.5f, Affinity.efficiency(nenType));
        if (exhausted) {
            aura += (0.5f + maxAura * 0.008f) * perTick;
        } else {
            aura += (ten ? stats.tenRegenPerSecond() : 0.5f) * perTick;
            if (!fighting && idleTicks > 100) aura += maxAura * 0.004f * perTick;
            if (ren) aura -= Tuning.renUpkeep(maxAura) * (1f - eff) * perTick;
            if (ken) aura -= Tuning.kenUpkeep(maxAura) * (1f - eff) * perTick;
            if (ten && tickCount % 20 == 0 && getHealth() < getMaxHealth() && tickCount - lastHitTick > 40) heal(stats.healPerSecond);
        }
        aura = Math.max(0f, Math.min(maxAura, aura));

        if (!exhausted && aura <= 0.01f) {
            runDry();
        } else if (exhausted && aura >= maxAura * 0.10f) {
            exhausted = false;
            level().playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 0.8f, 1.4f);
        }

        boolean blocked = exhausted || ExtrasHooks.hatsuForced(this); // Chain Jail / Forced Zetsu hold everything down, like they do for a player
        ten = !blocked;
        if (blocked) {
            if (ren || ken) setForm(false, false, true);
            return;
        }

        boolean wantRen = false, wantKen = false;
        if (fighting && t != null) {
            float frac = aura / maxAura;
            boolean pressed = recentDamage > getMaxHealth() * PRESSURE_FRACTION;
            boolean close = distanceTo(t) < 6.0 || isAttacking();
            boolean canRen = NpcFeelTuning.FIGHTERS_USE_REN && !renForbidden() && renRest <= 0;
            if (ren && (renTicks >= REN_MAX_TICKS || frac < REN_STOP_FRACTION)) canRen = false;
            if (close && !NpcFeelTuning.FIGHTERS_USE_REN) {
                wantKen = (pressed || isAttacking()) && frac > KEN_MIN_FRACTION;            // like Hisoka: Ken while swinging or hammered, Ten the rest of the time
            } else if (close) {
                if (pressed && frac > KEN_MIN_FRACTION) wantKen = true;                     // hammered: guard
                else if (canRen && frac > (ren ? REN_STOP_FRACTION : REN_MIN_FRACTION)) wantRen = true;   // free to hit: burst
                else if (frac > KEN_MIN_FRACTION + 0.10f && renRest > 0 && !hatsuBusy()) wantKen = isAttacking();   // cooling off from a burst: guard only while swinging
            } else if (pressed && frac > 0.15f) {
                wantKen = true;
            }
            if (hatsuBusy() && !pressed) { wantRen = false; wantKen = false; }               // channelling: save the aura
        }
        if (renRest > 0 && (wantRen)) wantRen = false;
        if (wantRen == ren && wantKen == ken) return;
        if (formCooldown <= 0 && formHeld >= FORM_MIN_HOLD_TICKS) setForm(wantRen, wantKen, false);
    }

    private void setForm(boolean newRen, boolean newKen, boolean force) {
        if (ren && !newRen && renTicks >= REN_MAX_TICKS / 2) renRest = REN_REST_TICKS;
        ren = newRen;
        ken = newKen;
        renTicks = newRen ? 0 : renTicks;
        formCooldown = FORM_SWITCH_TICKS;
        formHeld = 0;
        if (!(level() instanceof ServerLevel sl)) return;
        if (newRen) sl.playSound(null, blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 0.7f, 1.6f);
        else if (newKen) sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 0.8f, 1.2f);
        else if (!force) sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 0.4f, 1.5f);
    }

    private void runDry() {
        exhausted = true;
        aura = 0f;
        ten = false;
        setForm(false, false, true);
        onAuraGone();
        if (level() instanceof ServerLevel sl) {
            sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 1.0f, 0.7f);
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0, getZ(), 20, 0.4, 0.6, 0.4, 0.02);
        }
    }

    /** The pool ran dry: every Hatsu that needs aura must end. */
    protected void onAuraGone() { }

    private void syncFlags() {
        int f = (ten ? F_TEN : 0) | (ren ? F_REN : 0) | (ken ? F_KEN : 0);
        if (ren) renTicks++;
        if (this.entityData.get(NEN_FLAGS) != f) this.entityData.set(NEN_FLAGS, f);
    }

    /** Ten / Ren / Ken speed, the Hatsu's speed and the slow of a punch in progress. */
    private void refreshModifiers() {
        updateAttackSlow(); // every tick: a punch's slow lasts a few
        if (tickCount % 5 != 0) return;
        float aura = NpcAura.speedBonus(stats.ten, ten, ren, ken, false);
        aura = Math.min(aura, ren ? REN_SPEED_CAP : SPEED_CAP);
        setMod(Attributes.MOVEMENT_SPEED, MOD_AFF_SPEED, Affinity.speedBonus(nenType), AttributeModifier.Operation.MULTIPLY_TOTAL);
        setMod(Attributes.MOVEMENT_SPEED, MOD_TEN_SPEED, aura + extraSpeedBonus(), AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    protected void setMod(Attribute attr, UUID id, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = getAttribute(attr);
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(id);
        if (Math.abs(amount) < 1e-6) {
            if (cur != null) inst.removeModifier(id);
            return;
        }
        if (cur != null && Math.abs(cur.getAmount() - amount) < 1e-6) return;
        if (cur != null) inst.removeModifier(id);
        inst.addTransientModifier(new AttributeModifier(id, "Npc Nen", amount, op));
    }

    // =====================================================================================================
    // Attack / Barrage / Strong attack: the moves are NpcMelee's (see MeleeCore); this is what it asks of the NPC
    // =====================================================================================================

    /** Called by the combat goal every tick the target is within reach: picks the next move when free to. */
    @Override
    public void chooseAttack(LivingEntity t) {
        if (hatsuBusy()) return;
        melee.choose(t);
    }

    @Override
    public boolean inReach(LivingEntity t) {
        return distanceTo(t) - t.getBbWidth() * 0.5 <= stats.reach && Math.abs(t.getY() - getY()) < 2.5;
    }

    protected void cancelAttack() {
        melee.cancel();
    }

    /** Spirit bonus x melee multiplier x the fairness governor (NpcBalance); Ten / Ren / Ken are applied afterwards by the hurt event. */
    @Override
    public float meleeScale() {
        return spiritBonus() * stats.meleeMult * meleeGovern;
    }

    /** The NPC is drawn with the player model, so a punch is the normal arm swing. */
    @Override
    public void swingAnim() {
        swingArm();
    }

    protected void swingArm() {
        if (!level().isClientSide) SwingUtil.forceSwing(this, net.minecraft.world.InteractionHand.MAIN_HAND);
    }

    private void updateAttackSlow() {
        setMod(Attributes.MOVEMENT_SPEED, MOD_ATTACK_SLOW, -melee.slow(), AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    // =====================================================================================================
    // end of life
    // =====================================================================================================

    @Override
    public void die(DamageSource source) {
        onFightEnd();
        super.die(source);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        if (!level().isClientSide) onFightEnd();
        super.remove(reason);
    }
}
