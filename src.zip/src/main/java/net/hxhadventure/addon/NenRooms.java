package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.RelativeMovement;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The artificial Nen dimension of Knov's Hide and Seek, and everything saved about it.
 *
 * <p>The dimension itself ({@code hxhadventure:nen_dimension}) is an empty void defined by the data files in
 * {@code data/hxhadventure}: no sky, no mobs, always full-bright. Every room is a separate sealed box of white panels with blue grid lines
 * built on demand, {@link #SPACING} blocks away from its neighbours, so no two rooms are ever connected. Each room has an exit circle
 * on one wall; a room belongs to the Hide and Seek user who made it.
 *
 * <p>Saved with the world (so it is per save): the rooms, the room each user has selected with the Master Key, the place every visitor
 * has to go back to, who is being held captive by whom (Scream), and which circles each user has open.
 */
public final class NenRooms extends SavedData {
    public static final ResourceKey<Level> DIM = ResourceKey.create(Registries.DIMENSION,
        ResourceLocation.fromNamespaceAndPath("hxhadventure", "nen_dimension"));
    private static final String NAME = "hxhadventure_nen_rooms";

    /** The floor panels are at this Y, so everyone stands at FLOOR_Y + 1. */
    public static final int FLOOR_Y = 63;
    private static final int GRID = 8;          // rooms per row
    private static final int SPACING = 512;     // blocks between the origins of two rooms
    private static final int LINE_EVERY = 6;    // a blue grid line every this many blocks

    // ---------------------------------------------------------------- data

    /** One room: an empty box of {@code sx x sy x sz} blocks whose lowest corner is at (ox, FLOOR_Y + 1, oz). */
    public static final class Room {
        public final int id;
        public final UUID owner;
        public final int sx, sy, sz;
        public boolean built;
        /** Where this room's exit leads instead of back to each visitor's own entry point (set with the Master Key); null = the normal way. */
        public Link link;

        Room(int id, UUID owner, int sx, int sy, int sz, boolean built) {
            this.id = id;
            this.owner = owner;
            this.sx = sx;
            this.sy = sy;
            this.sz = sz;
            this.built = built;
        }

        public int ox() { return (id % GRID) * SPACING; }
        public int oz() { return (id / GRID) * SPACING; }
        public double cx() { return ox() + sx / 2.0; }
        public double cz() { return oz() + sz / 2.0; }
        public String size() { return sx + "x" + sy + "x" + sz; }

        /** Where a visitor arrives: just in front of the exit circle, facing into the room. */
        public Vec3 entrance() { return new Vec3(cx(), FLOOR_Y + 1, oz() + 2.5); }

        /** The exit circle's centre: on the inside of the north wall, a hand above the floor. */
        public Vec3 exitCentre() { return new Vec3(cx(), FLOOR_Y + 2.0, oz() + 0.06); }

        /** A random place on the floor, away from the walls. */
        public Vec3 randomSpot(Random rnd) {
            return new Vec3(ox() + 1.5 + rnd.nextDouble() * Math.max(0.1, sx - 3), FLOOR_Y + 1, oz() + 3.5 + rnd.nextDouble() * Math.max(0.1, sz - 5));
        }
    }

    /** Where a visitor goes back to when they leave a room. */
    public record Return(String dim, double x, double y, double z, float yaw) {
        CompoundTag toTag() {
            CompoundTag t = new CompoundTag();
            t.putString("dim", dim);
            t.putDouble("x", x);
            t.putDouble("y", y);
            t.putDouble("z", z);
            t.putFloat("yaw", yaw);
            return t;
        }

        static Return fromTag(CompoundTag t) {
            return new Return(t.getString("dim"), t.getDouble("x"), t.getDouble("y"), t.getDouble("z"), t.getFloat("yaw"));
        }

        public static Return of(Entity e) {
            return new Return(e.level().dimension().location().toString(), e.getX(), e.getY(), e.getZ(), e.getYRot());
        }
    }

    /** A place just in front of one circle, and which circle it is. */
    public record Link(UUID portal, Return spot) {}

    /** The place in front of a circle where somebody coming out of it would stand. */
    public static Link linkFor(HideSeekPortalEntity p) {
        Direction f = p.facing();
        double x = p.getX(), y = p.getY(), z = p.getZ();
        float yaw = 0f;
        if (f.getAxis().isHorizontal()) {
            x += f.getStepX() * 1.3;
            z += f.getStepZ() * 1.3;
            y -= 1.0; // the centre stands a block above the floor
            yaw = f.toYRot();
        } else if (f == Direction.UP) {
            y += 0.1;
        } else {
            y -= 2.1;
        }
        return new Link(p.getUUID(), new Return(p.level().dimension().location().toString(), x, y, z, yaw));
    }

    /** A creature held in a room by someone's Scream: it cannot use the exit until it is let go. */
    public record Captive(UUID owner, int room) {}

    private record PortalRef(UUID id, String dim) {}

    private final Map<Integer, Room> rooms = new TreeMap<>();
    private int nextId = 0;
    private final Map<UUID, Integer> selected = new HashMap<>();
    private final Map<UUID, Return> returns = new HashMap<>();
    private final Map<UUID, Captive> captives = new HashMap<>();
    private final Map<UUID, List<PortalRef>> portals = new HashMap<>();
    /** The circle each user last marked with a crouching Master Key (not saved). */
    private final Map<UUID, Link> marks = new HashMap<>();

    /** Entities that just went through a circle may not use another for a moment (so they cannot bounce straight back). */
    private static final Map<UUID, Long> LOCK = new ConcurrentHashMap<>();

    // ---------------------------------------------------------------- access

    public static NenRooms get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(NenRooms::load, NenRooms::new, NAME);
    }

    /** The Nen dimension, or null if the data pack that defines it is missing. */
    public static ServerLevel nen(MinecraftServer server) {
        return server.getLevel(DIM);
    }

    public static boolean isNen(Level level) {
        return level != null && level.dimension().equals(DIM);
    }

    // ---------------------------------------------------------------- save / load

    public static NenRooms load(CompoundTag tag) {
        NenRooms d = new NenRooms();
        d.nextId = tag.getInt("next");
        for (Tag t : tag.getList("rooms", Tag.TAG_COMPOUND)) {
            CompoundTag r = (CompoundTag) t;
            Room room = new Room(r.getInt("id"), r.getUUID("owner"), r.getInt("sx"), r.getInt("sy"), r.getInt("sz"), r.getBoolean("built"));
            if (r.hasUUID("linkId")) room.link = new Link(r.getUUID("linkId"), Return.fromTag(r.getCompound("linkSpot")));
            d.rooms.put(room.id, room);
        }
        for (Tag t : tag.getList("selected", Tag.TAG_COMPOUND)) {
            CompoundTag s = (CompoundTag) t;
            d.selected.put(s.getUUID("who"), s.getInt("room"));
        }
        for (Tag t : tag.getList("returns", Tag.TAG_COMPOUND)) {
            CompoundTag r = (CompoundTag) t;
            d.returns.put(r.getUUID("who"), Return.fromTag(r));
        }
        for (Tag t : tag.getList("captives", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            d.captives.put(c.getUUID("who"), new Captive(c.getUUID("owner"), c.getInt("room")));
        }
        for (Tag t : tag.getList("portals", Tag.TAG_COMPOUND)) {
            CompoundTag p = (CompoundTag) t;
            d.portals.computeIfAbsent(p.getUUID("owner"), k -> new ArrayList<>()).add(new PortalRef(p.getUUID("id"), p.getString("dim")));
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt("next", nextId);
        ListTag rl = new ListTag();
        for (Room r : rooms.values()) {
            CompoundTag t = new CompoundTag();
            t.putInt("id", r.id);
            t.putUUID("owner", r.owner);
            t.putInt("sx", r.sx);
            t.putInt("sy", r.sy);
            t.putInt("sz", r.sz);
            t.putBoolean("built", r.built);
            if (r.link != null) {
                t.putUUID("linkId", r.link.portal());
                t.put("linkSpot", r.link.spot().toTag());
            }
            rl.add(t);
        }
        tag.put("rooms", rl);
        ListTag sl = new ListTag();
        selected.forEach((who, room) -> {
            CompoundTag t = new CompoundTag();
            t.putUUID("who", who);
            t.putInt("room", room);
            sl.add(t);
        });
        tag.put("selected", sl);
        ListTag ret = new ListTag();
        returns.forEach((who, r) -> {
            CompoundTag t = r.toTag();
            t.putUUID("who", who);
            ret.add(t);
        });
        tag.put("returns", ret);
        ListTag cl = new ListTag();
        captives.forEach((who, c) -> {
            CompoundTag t = new CompoundTag();
            t.putUUID("who", who);
            t.putUUID("owner", c.owner());
            t.putInt("room", c.room());
            cl.add(t);
        });
        tag.put("captives", cl);
        ListTag pl = new ListTag();
        portals.forEach((owner, list) -> {
            for (PortalRef p : list) {
                CompoundTag t = new CompoundTag();
                t.putUUID("owner", owner);
                t.putUUID("id", p.id());
                t.putString("dim", p.dim());
                pl.add(t);
            }
        });
        tag.put("portals", pl);
        return tag;
    }

    // ---------------------------------------------------------------- rooms

    /** How many rooms a user of this Hatsu level may own. */
    public static int maxRooms(int hatsuLevel) {
        return Math.min(Tuning.HIDESEEK_MAX_ROOMS, Tuning.HIDESEEK_BASE_ROOMS + Math.max(0, hatsuLevel - Tuning.HIDESEEK_MIN_LEVEL) / Tuning.HIDESEEK_LEVELS_PER_ROOM);
    }

    public Link marked(UUID owner) {
        return marks.get(owner);
    }

    public void mark(UUID owner, Link l) {
        marks.put(owner, l);
    }

    /** A circle is gone: no exit may lead to it any more. */
    private void portalGone(UUID portalId) {
        marks.values().removeIf(l -> l.portal().equals(portalId));
        for (Room r : rooms.values()) {
            if (r.link != null && r.link.portal().equals(portalId)) {
                r.link = null;
                setDirty();
            }
        }
    }

    public Room room(int id) {
        return rooms.get(id);
    }

    public List<Room> roomsOf(UUID owner) {
        List<Room> out = new ArrayList<>();
        for (Room r : rooms.values()) if (r.owner.equals(owner)) out.add(r);
        return out;
    }

    /** Makes a new room of a random size for this user, or returns null if they already own as many as their level allows. */
    public Room createRoom(UUID owner, int hatsuLevel) {
        if (roomsOf(owner).size() >= maxRooms(hatsuLevel)) return null;
        Random rnd = new Random(owner.getLeastSignificantBits() * 31 + nextId * 0x9E3779B97F4A7C15L);
        int sizeSteps = (Tuning.ROOM_MAX_SIZE - Tuning.ROOM_MIN_SIZE) / 2 + 1;
        int sx = Tuning.ROOM_MIN_SIZE + 2 * rnd.nextInt(sizeSteps);
        int sz = Tuning.ROOM_MIN_SIZE + 2 * rnd.nextInt(sizeSteps);
        int sy = Tuning.ROOM_MIN_HEIGHT + rnd.nextInt(Tuning.ROOM_MAX_HEIGHT - Tuning.ROOM_MIN_HEIGHT + 1);
        Room r = new Room(nextId++, owner, sx, sy, sz, false);
        rooms.put(r.id, r);
        selected.put(owner, r.id);
        setDirty();
        return r;
    }

    /** The room this user has selected with the Master Key, making their first one if they have none. Null only when no room could be made. */
    public Room selectedRoom(UUID owner, int hatsuLevel) {
        Integer id = selected.get(owner);
        Room r = id == null ? null : rooms.get(id);
        if (r != null && r.owner.equals(owner)) return r;
        List<Room> mine = roomsOf(owner);
        if (!mine.isEmpty()) {
            select(owner, mine.get(0).id);
            return mine.get(0);
        }
        return createRoom(owner, hatsuLevel);
    }

    public void select(UUID owner, int roomId) {
        selected.put(owner, roomId);
        setDirty();
    }

    /** Selects the user's next room (wrapping round) and returns it, or null if they have none. */
    public Room cycle(UUID owner) {
        List<Room> mine = roomsOf(owner);
        if (mine.isEmpty()) return null;
        Integer cur = selected.get(owner);
        int idx = 0;
        for (int i = 0; i < mine.size(); i++) if (cur != null && mine.get(i).id == cur) idx = i;
        Room next = mine.get((idx + 1) % mine.size());
        select(owner, next.id);
        return next;
    }

    /** "Room 2/5 (15x9x21)": the room's place in its owner's list and its size. */
    public String describe(Room r) {
        List<Room> mine = roomsOf(r.owner);
        int idx = 1;
        for (int i = 0; i < mine.size(); i++) if (mine.get(i).id == r.id) idx = i + 1;
        return "Room " + idx + "/" + mine.size() + " (" + r.size() + ")";
    }

    // ---------------------------------------------------------------- building

    /** Builds the room if it is not there yet, and makes sure its exit circle exists. */
    public void ensureBuilt(ServerLevel nen, Room r) {
        if (!r.built) {
            build(nen, r);
            r.built = true;
            setDirty();
        }
        Vec3 c = r.exitCentre();
        if (nen.getEntitiesOfClass(HideSeekPortalEntity.class, new AABB(c, c).inflate(1.5)).isEmpty()) {
            HideSeekPortalEntity exit = new HideSeekPortalEntity(HxHEntities.HIDE_SEEK_PORTAL.get(), nen);
            exit.configure(Direction.SOUTH, c, true, r.id, null);
            nen.addFreshEntity(exit);
        }
    }

    private static boolean isLine(int c, int size) {
        return c == -1 || c == size || Math.floorMod(c + 1, LINE_EVERY) == 0;
    }

    private static void build(ServerLevel nen, Room r) {
        int ox = r.ox(), oz = r.oz();
        for (int cx = (ox - 1) >> 4; cx <= (ox + r.sx) >> 4; cx++) {
            for (int cz = (oz - 1) >> 4; cz <= (oz + r.sz) >> 4; cz++) nen.getChunk(cx, cz); // load (and so generate) every chunk the room touches
        }
        BlockState white = Blocks.WHITE_CONCRETE.defaultBlockState();
        BlockState line = Blocks.LIGHT_BLUE_CONCRETE.defaultBlockState();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int lx = -1; lx <= r.sx; lx++) {
            for (int ly = -1; ly <= r.sy; ly++) {
                for (int lz = -1; lz <= r.sz; lz++) {
                    boolean fx = lx == -1 || lx == r.sx, fy = ly == -1 || ly == r.sy, fz = lz == -1 || lz == r.sz;
                    if (!(fx || fy || fz)) continue; // the inside stays empty
                    boolean grid = (fx && (isLine(ly, r.sy) || isLine(lz, r.sz)))
                        || (fy && (isLine(lx, r.sx) || isLine(lz, r.sz)))
                        || (fz && (isLine(lx, r.sx) || isLine(ly, r.sy)));
                    p.set(ox + lx, FLOOR_Y + 1 + ly, oz + lz);
                    nen.setBlock(p, grid ? line : white, 18);
                }
            }
        }
        // The dimension uses a vanilla dimension type (so a saved world never refers to anything of this mod and still opens without it).
        // That type has no ambient light, so the rooms light themselves: invisible vanilla light blocks, spread through the inside.
        BlockState lamp = Blocks.LIGHT.defaultBlockState();
        for (int lx = (r.sx / 2) % 10; lx < r.sx; lx += 10) {
            for (int ly = (r.sy / 2) % 8; ly < r.sy; ly += 8) {
                for (int lz = (r.sz / 2) % 10; lz < r.sz; lz += 10) {
                    p.set(ox + lx, FLOOR_Y + 1 + ly, oz + lz);
                    nen.setBlock(p, lamp, 18);
                }
            }
        }
    }

    // ---------------------------------------------------------------- getting around

    /** A spot near {@code want} where {@code e} fits and stands on something. Falls back to {@code want}. */
    public static Vec3 safeSpot(ServerLevel level, Entity e, Vec3 want) {
        AABB base = e.getBoundingBox();
        Vec3 cur = e.position();
        int[] dys = {0, 1, -1, 2, -2, 3};
        for (int r = 0; r <= 3; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                    for (int dy : dys) {
                        Vec3 p = new Vec3(want.x + dx, want.y + dy, want.z + dz);
                        AABB box = base.move(p.x - cur.x, p.y - cur.y, p.z - cur.z);
                        if (level.noCollision(e, box) && !level.noCollision(e, box.move(0, -0.51, 0))) return p;
                    }
                }
            }
        }
        return want;
    }

    /** Moves any entity to a position in any dimension. Returns false if it refused (bosses cannot change dimension). */
    public static boolean moveTo(Entity e, ServerLevel to, Vec3 pos, float yaw, float pitch) {
        to.getChunkAt(BlockPos.containing(pos)); // make sure the destination exists
        e.fallDistance = 0;
        if (e instanceof ServerPlayer sp) {
            sp.teleportTo(to, pos.x, pos.y, pos.z, yaw, pitch);
            return true;
        }
        if (e.level() != to && !e.canChangeDimensions()) return false;
        return e.teleportTo(to, pos.x, pos.y, pos.z, Set.<RelativeMovement>of(), yaw, pitch);
    }

    private static void whoosh(ServerLevel level, Vec3 at) {
        level.playSound(null, at.x, at.y, at.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.8f, 0.7f);
        level.sendParticles(ParticleTypes.PORTAL, at.x, at.y + 1.0, at.z, 30, 0.4, 0.8, 0.4, 0.2);
    }

    private static void say(Entity e, String text) {
        if (e instanceof ServerPlayer sp) sp.displayClientMessage(Component.literal(text), true);
    }

    /**
     * Something walked into a circle: a player or any other creature (Hisoka, Gon, mobs...). A circle in the world leads into its room;
     * a circle inside the Nen dimension leads to another room (without losing the way back to the real world); an exit leads back out.
     */
    public static void touch(HideSeekPortalEntity portal, Entity e) {
        MinecraftServer server = e.getServer();
        if (server == null || e.isPassenger() || e.isVehicle()) return;
        long now = e.level().getGameTime();
        Long until = LOCK.get(e.getUUID());
        if (until != null && until > now) return;
        LOCK.put(e.getUUID(), now + 40);
        ServerLevel nen = nen(server);
        if (nen == null) {
            say(e, "§cThe Nen dimension is missing (is the mod's data pack loaded?)");
            return;
        }
        NenRooms rooms = get(server);
        boolean captive = rooms.captives.containsKey(e.getUUID());
        if (portal.isExit()) {
            if (captive) {
                say(e, "§7The circle will not open for you");
                return;
            }
            rooms.leave(e, rooms.room(portal.room()));
            return;
        }
        if (captive) {
            say(e, "§7The circle will not open for you");
            return;
        }
        Room r = rooms.room(portal.room());
        if (r == null) {
            say(e, "§7This circle leads nowhere. Connect it to a room with a Master Key");
            return;
        }
        rooms.ensureBuilt(nen, r);
        ServerLevel from = (ServerLevel) e.level();
        Return prev = rooms.returns.get(e.getUUID());
        boolean inside = isNen(from);
        if (!inside) {
            // where this visitor comes back to: in front of the circle they just walked into
            Vec3 want;
            Direction f = portal.facing();
            if (f.getAxis().isHorizontal()) want = new Vec3(portal.getX() + f.getStepX() * 1.3, e.getY(), portal.getZ() + f.getStepZ() * 1.3);
            else want = e.position().add(e.getLookAngle().x * 2, 0, e.getLookAngle().z * 2);
            Vec3 back = safeSpot(from, e, want);
            rooms.returns.put(e.getUUID(), new Return(from.dimension().location().toString(), back.x, back.y, back.z, e.getYRot()));
            rooms.setDirty();
        }
        whoosh(from, e.position());
        Vec3 in = r.entrance();
        if (!moveTo(e, nen, in, 0f, 0f)) {
            if (!inside) { // it could not follow: put the way back as it was
                if (prev == null) rooms.returns.remove(e.getUUID()); else rooms.returns.put(e.getUUID(), prev);
                rooms.setDirty();
            }
            return;
        }
        whoosh(nen, in);
        say(e, "§b" + rooms.describe(r));
    }

    /** Sends an entity back to where it came from, or home if that is unknown. */
    public void leave(Entity e) {
        leave(e, null);
    }

    /** Leaves through a room's exit: to the circle the exit is linked to if it has one, otherwise back to where the visitor came from. */
    public void leave(Entity e, Room via) {
        MinecraftServer server = e.getServer();
        if (server == null) return;
        Return back = returns.get(e.getUUID());
        if (via != null && via.link != null) {
            back = via.link.spot();
            if (ResourceLocation.tryParse(back.dim()) != null && DIM.location().toString().equals(back.dim())) {
                // leading to another place inside the Nen dimension: the way back to the real world is still remembered
            } else {
                returns.remove(e.getUUID());
            }
        } else {
            returns.remove(e.getUUID());
        }
        setDirty();
        LOCK.put(e.getUUID(), e.level().getGameTime() + 40);
        whoosh((ServerLevel) e.level(), e.position());
        ServerLevel dest;
        Vec3 pos;
        float yaw = e.getYRot();
        if (back != null) {
            ResourceLocation id = ResourceLocation.tryParse(back.dim());
            dest = id == null ? null : server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
            pos = new Vec3(back.x(), back.y(), back.z());
            yaw = back.yaw();
            if (dest != null) {
                dest.getChunkAt(BlockPos.containing(pos));
                pos = safeSpot(dest, e, pos);
            }
        } else {
            dest = null;
            pos = null;
        }
        if (dest == null) { // unknown or gone: the player's bed, or the world spawn
            if (e instanceof ServerPlayer sp && sp.getRespawnPosition() != null) {
                ServerLevel bed = server.getLevel(sp.getRespawnDimension());
                if (bed != null) {
                    dest = bed;
                    pos = Vec3.atBottomCenterOf(sp.getRespawnPosition());
                }
            }
            if (dest == null) {
                dest = server.overworld();
                pos = Vec3.atBottomCenterOf(dest.getSharedSpawnPos());
            }
        }
        moveTo(e, dest, pos, yaw, 0f);
        whoosh(dest, pos);
    }

    // ---------------------------------------------------------------- items

    /** Puts an item on the floor of a room (the part of a thing Scream took). */
    public void dropIn(MinecraftServer server, Room r, ItemStack stack) {
        ServerLevel nen = nen(server);
        if (nen == null || stack.isEmpty()) return;
        ensureBuilt(nen, r);
        Vec3 p = r.randomSpot(new Random());
        ItemEntity item = new ItemEntity(nen, p.x, p.y + 0.5, p.z, stack);
        item.setPickUpDelay(10);
        nen.addFreshEntity(item);
    }

    // ---------------------------------------------------------------- captives

    public boolean isCaptive(UUID id) {
        return captives.containsKey(id);
    }

    public Captive captiveInfo(UUID id) {
        return captives.get(id);
    }

    /** Whole creature taken by Scream: sent to the room and held there. Returns false if it could not be moved. */
    public boolean capture(MinecraftServer server, Entity e, Room r, UUID captor, boolean living) {
        ServerLevel nen = nen(server);
        if (nen == null) return false;
        ensureBuilt(nen, r);
        Return back = Return.of(e);
        ServerLevel from = (ServerLevel) e.level();
        UUID id = e.getUUID();
        whoosh(from, e.position());
        if (!moveTo(e, nen, r.randomSpot(new Random()), e.getYRot(), 0f)) return false;
        if (living) {
            captives.put(id, new Captive(captor, r.id));
            returns.put(id, back);
            setDirty();
        }
        return true;
    }

    /** Lets a captive go: it may use the exit again, and with {@code sendHome} it is put back where it was taken from. */
    public void release(MinecraftServer server, UUID id, boolean sendHome) {
        if (captives.remove(id) == null) return;
        setDirty();
        if (!sendHome) return;
        ServerLevel nen = nen(server);
        Entity e = nen == null ? null : nen.getEntity(id);
        if (e != null) leave(e);
    }

    /** Frees everyone one user is holding (they died, or lost their Hatsu). */
    public void releaseAllOf(MinecraftServer server, UUID owner) {
        List<UUID> ids = new ArrayList<>();
        captives.forEach((who, c) -> { if (c.owner().equals(owner)) ids.add(who); });
        for (UUID id : ids) release(server, id, true);
    }

    /** Frees everyone held in one room, but leaves them where they are. */
    public int releaseRoom(MinecraftServer server, int roomId) {
        List<UUID> ids = new ArrayList<>();
        captives.forEach((who, c) -> { if (c.room() == roomId) ids.add(who); });
        for (UUID id : ids) release(server, id, false);
        return ids.size();
    }

    /** A captive player died or logged in somewhere other than the Nen dimension: they are free. */
    public void forget(UUID id) {
        if (captives.remove(id) != null) setDirty();
        if (returns.remove(id) != null) setDirty();
    }

    // ---------------------------------------------------------------- circles

    public void registerPortal(MinecraftServer server, UUID owner, HideSeekPortalEntity portal) {
        List<PortalRef> list = portals.computeIfAbsent(owner, k -> new ArrayList<>());
        list.add(new PortalRef(portal.getUUID(), portal.level().dimension().location().toString()));
        while (list.size() > Tuning.HIDESEEK_MAX_PORTALS) {
            PortalRef old = list.remove(0);
            portalGone(old.id());
            Entity e = findPortal(server, old);
            if (e != null) e.discard();
        }
        setDirty();
    }

    public void unregisterPortal(UUID owner, UUID portalId) {
        portalGone(portalId);
        List<PortalRef> list = portals.get(owner);
        if (list == null) return;
        for (Iterator<PortalRef> it = list.iterator(); it.hasNext(); ) {
            if (it.next().id().equals(portalId)) it.remove();
        }
        setDirty();
    }

    /** Closes every circle one user has open. */
    public void closePortals(MinecraftServer server, UUID owner) {
        List<PortalRef> list = portals.remove(owner);
        if (list == null) return;
        for (PortalRef p : list) {
            portalGone(p.id());
            Entity e = findPortal(server, p);
            if (e != null) e.discard();
        }
        setDirty();
    }

    private static Entity findPortal(MinecraftServer server, PortalRef p) {
        ResourceLocation id = ResourceLocation.tryParse(p.dim());
        ServerLevel lvl = id == null ? null : server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
        return lvl == null ? null : lvl.getEntity(p.id());
    }
}
