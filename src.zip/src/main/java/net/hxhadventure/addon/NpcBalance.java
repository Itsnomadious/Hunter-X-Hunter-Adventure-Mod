package net.hxhadventure.addon;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * The fairness guarantee. For every melee NPC it models a MATCHED PLAYER (no mastery / Ten / Ren above the player caps, max health from
 * the level, Ren on, NO Hatsu: only Attack / Strong attack / Barrage) trading blows with the NPC, using the same formulas the game uses
 * ({@link Tuning}, {@link NpcAura}) and the NPC's own attack timing ({@link MeleeCore}, run here for real).
 * <pre>
 *   S = how long the player survives if every NPC blow lands          T = how long (landing blows) the player needs to kill
 *   M = S / T   (the "brawl ratio")        a = 1 - M / CLOSE_SHARE: the share of the NPC's damage a player must avoid to reach 90% of its health
 * </pre>
 * M is kept in [M_FLOOR, M_CEIL]: below the floor a skilled player (avoiding up to MAX_AVOID of the damage) could not get close to a kill,
 * above the ceiling the NPC would not be "stupidly hard". The governor enforces this in two steps, so the guarantee holds whatever the numbers in
 * the NPCs' tuning files say: (1) cap the NPC's health to what MAX_CONTACT_SECONDS of the player's best melee can remove, (2) scale the NPC's
 * melee damage by g (down if M is too low, up if too high) within [G_MIN, G_MAX].
 * Not modelled: armour and food (they only help the player), and the burst of an NPC's own Hatsu beyond the HATSU_PRESSURE share added to its damage.
 */
public final class NpcBalance {
    private NpcBalance() {}

    /** Everything the model needs to know about an NPC. */
    public static final class Profile {
        public final String name;
        public double hp, regen;
        public int hatsu, ten;
        public double meleeMult = 1.0;     // everything the NPC multiplies a blow's base damage by, on top of the spirit bonus
        public double dealt = 1.0, taken = 1.0;   // Nen-type affinity (Affinity.dealt / taken)
        public double renShare = 0.0;      // share of a fight spent in Ren (the rest counts as Ken)
        public MeleeCore.Cfg cfg = new MeleeCore.Cfg();

        public Profile(String name, double hp, int hatsu, int ten) {
            this.name = name;
            this.hp = hp;
            this.hatsu = hatsu;
            this.ten = ten;
        }

        public Profile mult(double m) { this.meleeMult = m; return this; }
        public Profile affinity(double dealt, double taken) { this.dealt = dealt; this.taken = taken; return this; }
        public Profile ren(double share) { this.renShare = share; return this; }
        public Profile cfg(MeleeCore.Cfg c) { this.cfg = c; return this; }
        public Profile regen(double r) { this.regen = r; return this; }
    }

    /** The governor's verdict for one NPC. */
    public static final class Result {
        public String name;
        public double hp, g, m, avoidNeeded, contactSeconds, surviveSeconds, playerDps, npcDps, playerHp;
        public boolean holds() { return m >= NpcFeelTuning.M_FLOOR - 1e-9; }
    }

    // ---------------------------------------------------------------------------------------------
    // the matched player
    // ---------------------------------------------------------------------------------------------

    public static double playerHp(int level) {
        return 20.0 + Math.floor(Math.min(40.0, (level - 1) * 0.41) / 4.0) * 4.0;   // Combat.maxHealthForLevel: 20 + a Health Boost in steps of 4
    }

    private static double spirit(int level) {
        return 1.0 + Math.sqrt(Math.max(0, level)) * 0.1;
    }

    /** Damage per second the matched player deals to the NPC in contact: Ren, and the best of Strong / Attack / Barrage on the player's own cooldowns. */
    static double playerDps(Profile p, int cap, double npcInMult, double npcTakenMult) {
        int lvl = Math.min(cap, p.hatsu), ten = Math.min(cap, p.ten);
        double renMult = NpcAura.outgoing(ten, false, true, false, false);                  // 1 + 2 x Ten's bonus
        double sp = spirit(lvl);
        double strong = 15.0 * sp / 3.0;      // 2 s charge, 1 s cooldown (Combat: STRONG_CHARGE_TICKS, ATTACK_COOLDOWN_MS)
        double single = 3.0 * sp / 1.0;       // one per second
        double barrage = 5 * 1.5 * sp / 4.0;  // invulnerability frames let one hit in ~12 ticks through: 5 per 60-tick barrage + 20 cooldown
        double raw = Math.max(strong, Math.max(single, barrage)) * renMult;
        return raw * npcInMult * npcTakenMult * (1.0 - NpcFeelTuning.DODGE_EXPECTED_AVOID) * NpcFeelTuning.PLAYER_UPTIME;
    }

    private static final Map<MeleeCore.Cfg, Double> RAW_CACHE = new HashMap<>();

    /** Base damage per second of the NPC's attack pattern when every blow lands (MeleeCore run for 3 minutes, fixed seed). */
    static synchronized double rawBasePerSecond(MeleeCore.Cfg cfg) {
        Double c = RAW_CACHE.get(cfg);
        if (c != null) return c;
        final double[] sum = {0};
        MeleeCore.Sink sink = new MeleeCore.Sink() {
            public void swing() { }
            public int impact(MeleeCore.Hit h) { sum[0] += h.damage; return 1; }
            public void charge(float p) { }
            public void snapFace() { }
            public void lunge(double s, int t) { }
            public void strongStarted() { }
        };
        MeleeCore core = new MeleeCore(cfg, sink, new Random(7));
        final int ticks = 20 * 180;
        for (int i = 0; i < ticks; i++) {
            if (core.ready()) core.choose();
            core.tick(true, false);
        }
        double v = sum[0] / (ticks / 20.0);
        RAW_CACHE.put(cfg, v);
        return v;
    }

    // ---------------------------------------------------------------------------------------------
    // the evaluation and the governor
    // ---------------------------------------------------------------------------------------------

    /** The model for NPC health {@code hp} and melee governor {@code g}. */
    public static Result evaluate(Profile p, double hp, double g) {
        final int cap = NpcFeelTuning.PLAYER_CAP;
        int pl = Math.min(cap, p.hatsu), pt = Math.min(cap, p.ten);
        double playerHp = playerHp(pl);
        double playerIn = NpcAura.incoming(pt, false, true, false, false);                   // the matched player in Ren
        // the NPC's side: its real levels, a Ren / Ken mix
        double rs = p.renShare;
        double outMix = rs * NpcAura.outgoing(p.ten, false, true, false, false) + (1 - rs) * NpcAura.outgoing(p.ten, false, false, true, false);
        double inMix = rs * NpcAura.incoming(p.ten, false, true, false, false) + (1 - rs) * NpcAura.incoming(p.ten, false, false, true, false);
        double npcDps = rawBasePerSecond(p.cfg) * spirit(p.hatsu) * p.meleeMult * g * p.dealt * outMix * playerIn * (1.0 + NpcFeelTuning.HATSU_PRESSURE);
        double pDps = playerDps(p, cap, inMix, p.taken);
        Result r = new Result();
        r.name = p.name;
        r.hp = hp;
        r.g = g;
        r.playerHp = playerHp;
        r.npcDps = npcDps;
        r.playerDps = pDps;
        r.surviveSeconds = playerHp / Math.max(1e-9, npcDps);
        r.contactSeconds = hp / Math.max(1e-9, pDps);
        r.m = r.surviveSeconds / r.contactSeconds;
        r.avoidNeeded = Math.max(0.0, 1.0 - r.m / NpcFeelTuning.CLOSE_SHARE);
        return r;
    }

    private static final Map<String, Result> GOVERNED = new HashMap<>();

    /** The governed health and melee factor of an NPC (cached per name). */
    public static synchronized Result govern(Profile p) {
        Result c = GOVERNED.get(p.name);
        if (c != null) return c;
        double hp = p.hp, g = 1.0;
        if (NpcFeelTuning.GOVERNOR_ENABLED) {
            Result base = evaluate(p, hp, 1.0);
            if (NpcFeelTuning.HEALTH_CAP_ENABLED) hp = Math.min(hp, NpcFeelTuning.MAX_CONTACT_SECONDS * base.playerDps);
            Result r1 = evaluate(p, hp, 1.0);
            if (r1.m < NpcFeelTuning.M_FLOOR) g = r1.m / NpcFeelTuning.M_FLOOR;
            else if (r1.m > NpcFeelTuning.M_CEIL) g = r1.m / NpcFeelTuning.M_CEIL;
            g = Math.max(NpcFeelTuning.G_MIN, Math.min(NpcFeelTuning.G_MAX, g));
            if (NpcFeelTuning.HEALTH_CAP_ENABLED) {            // g hit its lower limit and it is still too hard: the health gives way
                Result r2 = evaluate(p, hp, g);
                if (r2.m < NpcFeelTuning.M_FLOOR) hp = hp * r2.m / NpcFeelTuning.M_FLOOR;
            }
        }
        Result out = evaluate(p, hp, g);
        GOVERNED.put(p.name, out);
        return out;
    }

    public static float governedMelee(Profile p) { return (float) govern(p).g; }

    public static double governedHealth(Profile p) { return govern(p).hp; }

    public static String describe(Result r) {
        return String.format("%-11s hp %6.0f  g %.2f  matched player %.0f hp: survives %5.1fs of full contact, needs %5.1fs to kill  M=%.2f  must avoid %2.0f%% for 90%%  %s",
            r.name, r.hp, r.g, r.playerHp, r.surviveSeconds, r.contactSeconds, r.m, r.avoidNeeded * 100, r.holds() ? "OK" : "VIOLATES");
    }
}
