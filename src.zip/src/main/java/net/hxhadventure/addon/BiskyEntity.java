package net.hxhadventure.addon;

import java.util.UUID;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketEstheticianFx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Bisky (NPC): Transmutation Hatsu "Magical Esthetician". With a target still far off she calls Cookie and takes a Magical Spa Service
 * (or a Piano Massage when her aura is low): the player's 10-second service and 30-minute buff (Spa Afterglow: damage and durability,
 * Piano: aura regeneration), broken off if she is hit. Close to a target she grows into Body Transformation (+50% damage, +50% durability,
 * +20% speed, 1.3x height) for ten minutes and fights in it with Ten / Ren / Ken, with the player's cooldown afterwards.
 */
public class BiskyEntity extends NenFighter {
    public static final NpcStats STATS = new NpcStats("bisky", Combat.NEN_TRANSMUTATION)
        .levels(100, 96, 96, 94)
        .body(170.0, 0.30, 0.4, 1.0f)
        .melee(1.0f, 2.5)
        .look("pinkaura_ten", 0xF2D13A, 0xB03060);

    private static final double SERVICE_MIN_TARGET_DISTANCE = 14.0;

    // Cookie and the service in progress
    private UUID cookie;
    private int service;                 // 0 none, MagicalEsthetician.SERVICE_SPA / SERVICE_PIANO
    private int serviceTicks;
    private int summonReady;
    // the buffs, as game-time deadlines
    private long spaUntil, pianoUntil;
    // Body Transformation
    private boolean form;
    private long formEnd, formReady;
    private int lastFightTick = -1000;

    public BiskyEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, STATS);
    }

    // ---------------- numbers ----------------
    private float spaBonus() {
        return level().getGameTime() < spaUntil ? EstheticianTuning.SPA_BASE + EstheticianTuning.SPA_PER_LEVEL * stats.hatsu : 0f;
    }

    private float pianoBonus() {
        return level().getGameTime() < pianoUntil ? EstheticianTuning.PIANO_BASE + EstheticianTuning.PIANO_PER_LEVEL * stats.hatsu : 0f;
    }

    @Override
    protected float extraOutgoingMult(@Nullable DamageSource src) {
        return (1f + spaBonus()) * (form ? EstheticianTuning.TRANSFORM_DAMAGE_MULT : 1f);
    }

    @Override
    protected float extraIncomingMult(DamageSource src) {
        return 1f / ((1f + spaBonus()) * (form ? EstheticianTuning.TRANSFORM_DURABILITY_MULT : 1f));
    }

    @Override
    protected float extraSpeedBonus() {
        return form ? EstheticianTuning.TRANSFORM_SPEED_BONUS : 0f;
    }

    /** The transformed Bisky is taller (and so is her hitbox). */
    @Override
    public EntityDimensions getDimensions(Pose pose) {
        EntityDimensions d = super.getDimensions(pose);
        return form ? d.scale(1.0f, EstheticianTuning.TRANSFORM_HEIGHT_MULT) : d;
    }

    @Override
    protected boolean hatsuBusy() {
        return service != 0;
    }

    @Override
    protected boolean isAlly(Entity e) {
        return e instanceof CookieEntity c && c.getUUID().equals(cookie);
    }

    // ---------------- the Hatsu ----------------
    @Override
    protected void tickHatsu(@Nullable LivingEntity target, boolean fighting) {
        if (!(level() instanceof ServerLevel sl)) return;
        long now = sl.getGameTime();
        if (!canUseNen()) { // Forced Zetsu / Chain Jail / dry: Cookie goes, the body shrinks back
            if (cookie != null || service != 0) dismissCookie();
            if (form) endForm(true);
            return;
        }
        if (fighting) lastFightTick = tickCount;

        // Piano Massage: faster aura regeneration (the base's Ten regen, plus the bonus)
        float piano = pianoBonus();
        if (piano > 0f && isTen() && tickCount % 20 == 0) drainAura(-stats.tenRegenPerSecond() * piano);

        if (service != 0) {
            tickService(sl, target, fighting);
            return;
        }
        if (cookie != null && !fighting) dismissCookie();

        if (form) {
            if (now >= formEnd) endForm(true);
            else if (!fighting && tickCount - lastFightTick > 200) endForm(true); // fight over: back to normal
        }

        if (!fighting || target == null) return;
        double d = distanceTo(target);

        // 1. a far target: call Cookie and sit through a service (the buff lasts 30 minutes)
        if (d > SERVICE_MIN_TARGET_DISTANCE && tickCount >= summonReady && lastHitAge() > 60) {
            boolean wantPiano = auraFraction() < 0.6f && now >= pianoUntil;
            boolean wantSpa = now >= spaUntil;
            if (wantSpa || wantPiano) {
                startService(sl, wantSpa ? MagicalEsthetician.SERVICE_SPA : MagicalEsthetician.SERVICE_PIANO);
                return;
            }
        }
        // 2. in reach of the fight: grow (Body Transformation)
        if (!form && d < 12.0 && now >= formReady && stats.hatsu >= EstheticianTuning.TRANSFORM_MIN_LEVEL
            && auraFraction() > 0.4f && payAura(EstheticianTuning.TRANSFORM_COST)) {
            startForm(sl);
        }
    }

    // ---------------- Cookie and the services ----------------
    private void startService(ServerLevel sl, int which) {
        if (!payAura(EstheticianTuning.SUMMON_COST)) return;
        if (!payAura(EstheticianTuning.SERVICE_COST)) {
            drainAura(-EstheticianTuning.SUMMON_COST); // could not afford both: the summon is refunded
            return;
        }
        Vec3 look = getLookAngle().multiply(1, 0, 1).normalize();
        Vec3 at = position().subtract(look.scale(EstheticianTuning.SPA_BEHIND + 0.2));
        CookieEntity c = new CookieEntity(HxHEntities.COOKIE.get(), sl);
        c.setOwner(getUUID());
        c.moveTo(at.x, at.y, at.z, getYRot(), 0f);
        c.setYHeadRot(getYRot());
        c.setYBodyRot(getYRot());
        c.setStance(which == MagicalEsthetician.SERVICE_SPA ? 1 : 2);
        sl.addFreshEntity(c);
        cookie = c.getUUID();
        MagicalEsthetician.registerNpcCookie(getUUID(), cookie);
        service = which;
        serviceTicks = which == MagicalEsthetician.SERVICE_SPA ? EstheticianTuning.SPA_TICKS : EstheticianTuning.PIANO_TICKS;
        summonReady = tickCount + EstheticianTuning.SUMMON_COOLDOWN_TICKS;
        sl.sendParticles(ParticleTypes.HEART, at.x, at.y + 1.6, at.z, 8, 0.4, 0.4, 0.4, 0.0);
        sl.sendParticles(ParticleTypes.END_ROD, at.x, at.y + 1.0, at.z, 20, 0.35, 0.8, 0.35, 0.05);
        sl.playSound(null, at.x, at.y, at.z, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.HOSTILE, 1.0f, 1.4f);
    }

    private void tickService(ServerLevel sl, @Nullable LivingEntity target, boolean fighting) {
        // hit, or the enemy is on top of her: the service is broken off, with no buff (like the player's)
        if (lastHitAge() < 3 || (target != null && distanceTo(target) < 7.0)) {
            dismissCookie();
            return;
        }
        if (cookie == null || !(sl.getEntity(cookie) instanceof CookieEntity)) {
            dismissCookie();
            return;
        }
        serviceTicks--;
        if (serviceTicks % 10 == 0) sl.sendParticles(ParticleTypes.NOTE, getX(), getY() + 2.2, getZ(), 1, 0.3, 0.2, 0.3, 1.0);
        if (serviceTicks <= 0) {
            long until = sl.getGameTime() + EstheticianTuning.BUFF_TICKS;
            if (service == MagicalEsthetician.SERVICE_SPA) spaUntil = until;
            else pianoUntil = until;
            sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.6, getZ(), 10, 0.5, 0.6, 0.5, 0.0);
            sl.playSound(null, blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.HOSTILE, 0.8f, 1.6f);
            service = 0;
            dismissCookie();
        }
    }

    private void dismissCookie() {
        service = 0;
        serviceTicks = 0;
        MagicalEsthetician.unregisterNpcCookie(getUUID());
        if (cookie != null && level() instanceof ServerLevel sl) {
            Entity e = sl.getEntity(cookie);
            if (e != null) {
                sl.sendParticles(ParticleTypes.HEART, e.getX(), e.getY() + 1.6, e.getZ(), 6, 0.4, 0.4, 0.4, 0.0);
                sl.sendParticles(ParticleTypes.POOF, e.getX(), e.getY() + 0.9, e.getZ(), 14, 0.3, 0.6, 0.3, 0.03);
                sl.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 1.0f, 1.2f);
                e.discard();
            }
        }
        cookie = null;
    }

    // ---------------- Body Transformation ----------------
    private void startForm(ServerLevel sl) {
        form = true;
        formEnd = sl.getGameTime() + EstheticianTuning.TRANSFORM_TICKS;
        drainAura(-auraNow() * (EstheticianTuning.TRANSFORM_AURA_MULT - 1f)); // the tank is bigger, so what was in it grows too
        refreshDimensions();
        AddonNetwork.sendToTracking(PacketEstheticianFx.form(getId(), true), this);
        sl.playSound(null, blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 1.2f, 1.2f);
        sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.4, getZ(), 14, 0.5, 0.8, 0.5, 0.0);
        sl.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.0, getZ(), 30, 0.5, 0.9, 0.5, 0.12);
    }

    private float auraNow() { return aura(); }

    private void endForm(boolean cooldown) {
        if (!form) return;
        form = false;
        float cur = aura();
        drainAura(cur - cur / EstheticianTuning.TRANSFORM_AURA_MULT);
        refreshDimensions();
        AddonNetwork.sendToTracking(PacketEstheticianFx.form(getId(), false), this);
        if (cooldown) formReady = level().getGameTime() + EstheticianTuning.TRANSFORM_COOLDOWN_TICKS;
    }

    @Override
    protected void onFightEnd() {
        if (cookie != null || service != 0) dismissCookie();
        // the form and the buffs run their course (checked in tickHatsu)
    }

    @Override
    protected void onAuraGone() {
        dismissCookie();
        if (form) endForm(true);
    }

    /** A player who starts tracking her sees the grown body at once. */
    @Override
    public void startSeenByPlayer(net.minecraft.server.level.ServerPlayer viewer) {
        super.startSeenByPlayer(viewer);
        if (form) AddonNetwork.sendToPlayer(PacketEstheticianFx.form(getId(), true), viewer);
    }
}
