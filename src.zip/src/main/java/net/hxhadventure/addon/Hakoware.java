package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Knuckle's Hakoware (Hatsu kit 19, Conjurers). Z switches it on (and off again); while it is on:
 *
 * <ol>
 *   <li><b>The loan.</b> The first blow on an enemy lends them aura and conjures <b>A.P.R.</b>, which hovers beside them. From then
 *       on every blow of the user's only lends more aura (no damage, knockback still works): the debt grows by the strength of the
 *       blow ({@link HakowareTuning#LEND_PER_DAMAGE} per point of damage).</li>
 *   <li><b>The repayment.</b> Every blow the debtor lands on the user returns aura instead of hurting, and lowers the debt the same
 *       way. While anything is owed the user cannot be physically hurt by that debtor. When it is all repaid, A.P.R. leaves.</li>
 *   <li><b>The interest.</b> Every {@link HakowareTuning#INTEREST_TICKS} ticks A.P.R. says its line and adds
 *       {@link HakowareTuning#INTEREST_RATE} of the debt, if the debtor is within {@link HakowareTuning#INTEREST_RANGE} blocks of the user.
 *       A.P.R. grows with the debt.</li>
 *   <li><b>Bankruptcy.</b> When the debt is more than the debtor's remaining aura (see {@link #pop}) A.P.R. becomes <b>I.R.S.</b>, which
 *       follows the debtor for {@link HakowareTuning#IRS_DAYS} Minecraft days and holds them in Forced Zetsu.</li>
 * </ol>
 * Everything is decided on the server. The creatures are {@link AprEntity} and {@link IrsEntity}. Forge hooks: {@link HakowareEvents}.
 */
public final class Hakoware {
    private Hakoware() {}

    public static final int KIT = 19;
    public static final String ID = "hakoware";
    private static final String NAME = "Hakoware";
    /** Player data (kept through death): game time the I.R.S. sentence ends. */
    public static final String CURSE_KEY = "HxHExtras_IrsUntil";

    private static final class Contract {
        final UUID target;
        UUID apr;
        float debt;         // everything owed, interest included
        float principal;    // aura actually lent, interest left out (used when interest is not compounded)
        int timer = HakowareTuning.INTEREST_TICKS;

        Contract(UUID target) {
            this.target = target;
        }
    }

    private static final class State {
        boolean on;
        int cd;
        final Map<UUID, Contract> contracts = new LinkedHashMap<>();
    }

    private static final Map<UUID, State> STATES = new HashMap<>();
    /** Ids of the A.P.R. creatures that belong to a live contract (an A.P.R. that is not in here removes itself). */
    private static final Set<UUID> APRS = new HashSet<>();

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    /** Adds Hakoware to the scroll once the Hatsu level allows it. */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < HakowareTuning.MIN_LEVEL) return base;
        String[] out = Arrays.copyOf(base, base.length + 1);
        out[out.length - 1] = ID;
        return out;
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(ID, Hakoware::toggle);
    }

    public static boolean isTracked(UUID aprId) {
        return APRS.contains(aprId);
    }

    /** Is the user's Hakoware switched on right now? */
    public static boolean isOn(Player p) {
        State s = p == null ? null : STATES.get(p.getUUID());
        return s != null && s.on;
    }

    private static State state(ServerPlayer sp) {
        return STATES.computeIfAbsent(sp.getUUID(), k -> new State());
    }

    private static void msg(ServerPlayer sp, String text) {
        sp.displayClientMessage(Component.literal(text), true);
    }

    private static void chat(ServerPlayer sp, String text) {
        sp.sendSystemMessage(Component.literal(text));
    }

    private static void sound(ServerLevel level, Entity at, SoundEvent ev, float vol, float pitch) {
        level.playSound(null, at.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }

    private static String num(float v) {
        return String.valueOf(Math.round(v));
    }

    private static boolean hostile(ServerPlayer sp, Entity e) {
        if (!(e instanceof LivingEntity le) || le == sp || !le.isAlive() || e instanceof ArmorStand) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        return !AllianceUtils.isAlly(e, sp);
    }

    /**
     * The "remaining aura" (P.O.P) of anything that can owe aura: a Nen user's current aura, Kite's aura, and for everything
     * without a Nen of its own its maximum health times {@link HakowareTuning#FALLBACK_POP_PER_HEALTH}.
     */
    public static float pop(LivingEntity e) {
        if (e instanceof Player p) {
            Combat c = Combat.get(p);
            if (c != null && c.hasNenUnlocked()) return Math.max(0f, c.getCurrentEnergy());
        } else if (e instanceof HisokaEntity h) {
            return h.aura();
        } else if (e instanceof NeferpitouEntity n) {
            return n.aura();
        } else if (e instanceof GonEntity g) {
            return g.aura();
        } else if (e instanceof ChrolloEntity ch) {
            return ch.aura();
        }
        return e.getMaxHealth() * HakowareTuning.FALLBACK_POP_PER_HEALTH;
    }

    // ---------------------------------------------------------------- Z: switch on / off

    public static void toggle(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return;
        if (!canUse(c)) {
            msg(sp, "\u00a7cYour Hatsu is not Hakoware");
            return;
        }
        if (c.getHatsuLevel() < HakowareTuning.MIN_LEVEL) {
            msg(sp, "\u00a7c" + NAME + " unlocks at Level " + HakowareTuning.MIN_LEVEL);
            return;
        }
        State s = state(sp);
        if (s.on) {
            release(sp, s, "\u00a77Hakoware released");
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            msg(sp, "\u00a75Forced Zetsu: Hakoware will not answer");
            return;
        }
        if (HatsuEffects.isStunned(sp)) return;
        if (ChainManager.onCooldown(sp, NAME, s.cd)) return;
        if (c.getCurrentEnergy() < HakowareTuning.ACTIVATE_COST) {
            msg(sp, "\u00a7cNot enough energy");
            return;
        }
        c.consumeEnergy(HakowareTuning.ACTIVATE_COST);
        s.on = true;
        s.cd = HakowareTuning.TOGGLE_COOLDOWN_TICKS;
        if (sp.level() instanceof ServerLevel level) {
            Vec3 p = sp.position();
            level.sendParticles(ParticleTypes.END_ROD, p.x, p.y + 1.1, p.z, 24, 0.5, 0.6, 0.5, 0.04);
            sound(level, sp, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0f, 0.8f);
            sound(level, sp, SoundEvents.BOOK_PAGE_TURN, 0.8f, 1.2f);
        }
        msg(sp, "\u00a76Hakoware: \u00a7fhit an enemy to lend them aura");
    }

    private static void release(ServerPlayer sp, State s, String message) {
        boolean had = !s.contracts.isEmpty();
        for (Contract k : s.contracts.values()) dismissApr(sp.level() instanceof ServerLevel lv ? lv : null, k, "Contract void. No refunds");
        s.contracts.clear();
        s.on = false;
        s.cd = HakowareTuning.TOGGLE_COOLDOWN_TICKS;
        msg(sp, message + (had ? " \u00a77(every debt is void)" : ""));
    }

    // ---------------------------------------------------------------- the blows

    /** LivingHurtEvent (lowest priority, so the amount is the final strength of the blow). */
    public static void onHurt(LivingHurtEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide || STATES.isEmpty()) return;
        float amount = e.getAmount();
        if (amount <= 0f) return;
        DamageSource src = e.getSource();
        if (src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return;
        Entity cause = src.getEntity();
        if (cause == null || !(victim.level() instanceof ServerLevel level)) return;

        // 1) the debtor's blow on the user: it repays
        if (victim instanceof ServerPlayer user) {
            State s = STATES.get(user.getUUID());
            if (s != null && s.on) {
                Contract k = s.contracts.get(cause.getUUID());
                if (k != null) {
                    repay(user, s, k, cause instanceof LivingEntity le ? le : null, level, amount, e);
                    return;
                }
            }
        }
        // 2) the user's blow: it lends
        if (cause instanceof ServerPlayer user && user != victim) {
            State s = STATES.get(user.getUUID());
            if (s == null || !s.on) return;
            Combat c = Combat.get(user);
            if (!canUse(c) || ExtrasHooks.hatsuForced(user)) return;
            Contract k = s.contracts.get(victim.getUUID());
            if (k == null) {
                if (!hostile(user, victim) || s.contracts.size() >= HakowareTuning.MAX_CONTRACTS) return;
                if (isIndebted(victim)) return; // already bankrupt: an ordinary fight
                k = new Contract(victim.getUUID());
                s.contracts.put(victim.getUUID(), k);
                spawnApr(user, victim, k);
                sound(level, victim, SoundEvents.BELL_BLOCK, 0.9f, 1.4f);
            }
            lend(user, s, k, victim, level, amount, e);
        }
    }

    private static float lendWorth(float damage) {
        return Math.max(HakowareTuning.MIN_LEND_PER_BLOW, damage * HakowareTuning.LEND_PER_DAMAGE);
    }

    private static float repayWorth(float damage) {
        return Math.max(HakowareTuning.MIN_REPAY_PER_BLOW, damage * HakowareTuning.REPAY_PER_DAMAGE);
    }

    private static void lend(ServerPlayer user, State s, Contract k, LivingEntity victim, ServerLevel level, float damage, LivingHurtEvent e) {
        float lent = lendWorth(damage);
        k.debt += lent;
        k.principal += lent;
        e.setAmount(0f); // no damage; the blow still pushes
        e.setCanceled(true);
        trail(level, user, victim, ParticleTypes.END_ROD);
        sound(level, victim, SoundEvents.AMETHYST_BLOCK_CHIME, 0.7f, 1.3f);
        float pop = pop(victim);
        msg(user, "\u00a76Lent \u00a7f" + num(lent) + " \u00a76aura \u00a77(owed " + num(k.debt) + " of " + num(pop) + ")");
        if (k.debt > pop) {
            s.contracts.remove(k.target);
            bankrupt(user, k, victim, level);
        } else {
            refreshApr(level, k, pop);
        }
    }

    private static void repay(ServerPlayer user, State s, Contract k, LivingEntity debtor, ServerLevel level, float damage, LivingHurtEvent e) {
        float back = repayWorth(damage);
        k.debt -= back;
        k.principal = Math.max(0f, k.principal - back);
        e.setAmount(0f); // the user is not hurt; the knockback still lands
        e.setCanceled(true);
        if (debtor != null) trail(level, debtor, user, ParticleTypes.ENCHANT);
        sound(level, user, SoundEvents.EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
        if (k.debt <= 0.5f) {
            s.contracts.remove(k.target);
            dismissApr(level, k, "Paid in full. A pleasure");
            chat(user, "\u00a76" + (debtor == null ? "The debtor" : debtor.getDisplayName().getString()) + " \u00a77paid everything back");
            msg(user, "\u00a76Hakoware: \u00a7fdebt repaid, you can be hurt again");
            return;
        }
        msg(user, "\u00a76Returned \u00a7f" + num(back) + " \u00a76aura \u00a77(still owed " + num(k.debt) + ")");
        if (debtor != null) refreshApr(level, k, pop(debtor));
    }

    private static void trail(ServerLevel level, Entity from, Entity to, ParticleOptions p) {
        Vec3 a = from.position().add(0, from.getBbHeight() * 0.65, 0);
        Vec3 b = to.position().add(0, to.getBbHeight() * 0.55, 0);
        for (int i = 0; i <= 8; i++) {
            Vec3 at = a.lerp(b, i / 8.0);
            level.sendParticles(p, at.x, at.y, at.z, 1, 0.05, 0.05, 0.05, 0.0);
        }
    }

    // ---------------------------------------------------------------- A.P.R.

    private static AprEntity spawnApr(ServerPlayer user, LivingEntity victim, Contract k) {
        if (!(victim.level() instanceof ServerLevel level)) return null;
        AprEntity apr = new AprEntity(HxHEntities.APR.get(), level);
        apr.bind(user, victim);
        apr.moveTo(victim.getX(), victim.getY() + 1.0, victim.getZ(), 0f, 0f);
        if (k.apr != null) APRS.remove(k.apr); // a replacement for one that was lost
        k.apr = apr.getUUID();
        APRS.add(k.apr);
        level.addFreshEntity(apr);
        return apr;
    }

    private static AprEntity aprOf(ServerLevel level, Contract k) {
        return k.apr != null && level.getEntity(k.apr) instanceof AprEntity a && a.isAlive() ? a : null;
    }

    /** Size and counter follow the debt. */
    private static void refreshApr(ServerLevel level, Contract k, float pop) {
        AprEntity apr = aprOf(level, k);
        if (apr == null) return;
        apr.setTargetGrowth(pop <= 0f ? 1f : k.debt / pop);
        apr.setDebt(Math.round(k.debt));
    }

    private static void dismissApr(ServerLevel level, Contract k, String line) {
        if (k.apr == null) return;
        UUID id = k.apr;
        APRS.remove(id);
        k.apr = null;
        if (level != null && level.getEntity(id) instanceof AprEntity apr) apr.dismiss(line);
    }

    /** Something died: any A.P.R. that was on it vanishes at once and the debt is gone. */
    public static void onAnyDeath(LivingEntity dead) {
        if (dead.level().isClientSide || STATES.isEmpty() || !(dead.level() instanceof ServerLevel level)) return;
        for (State s : STATES.values()) {
            Contract k = s.contracts.remove(dead.getUUID());
            if (k != null) removeApr(level, k);
        }
    }

    /** A.P.R. vanishes at once (bankruptcy: it is about to come back as I.R.S.). */
    private static void removeApr(ServerLevel level, Contract k) {
        if (k.apr == null) return;
        UUID id = k.apr;
        APRS.remove(id);
        k.apr = null;
        if (level != null && level.getEntity(id) instanceof AprEntity apr) {
            level.sendParticles(ParticleTypes.POOF, apr.getX(), apr.getY() + apr.getBbHeight() * 0.5, apr.getZ(), 16, 0.3, 0.3, 0.3, 0.03);
            apr.discard();
        }
    }

    private static void interest(ServerPlayer user, ServerLevel level, Contract k, LivingEntity debtor) {
        AprEntity apr = aprOf(level, k);
        if (apr == null) apr = spawnApr(user, debtor, k);
        if (apr != null) apr.say(HakowareTuning.SPEECH);
        if (HakowareTuning.SPEECH_IN_CHAT) {
            String line = "\u00a76<A.P.R.> \u00a7f" + HakowareTuning.SPEECH;
            chat(user, line);
            if (debtor instanceof ServerPlayer dp) chat(dp, line);
        }
        if (user.distanceTo(debtor) > HakowareTuning.INTEREST_RANGE) return; // out of reach: it says its line, but nothing builds
        float add = HakowareTuning.INTEREST_RATE * (HakowareTuning.COMPOUND ? k.debt : k.principal);
        k.debt += add;
        Vec3 at = debtor.position().add(0, debtor.getBbHeight() * 0.6, 0);
        level.sendParticles(ParticleTypes.ENCHANT, at.x, at.y, at.z, 24, 0.5, 0.6, 0.5, 0.5);
        sound(level, debtor, SoundEvents.BELL_BLOCK, 0.8f, 0.9f);
        if (debtor instanceof ServerPlayer dp) msg(dp, "\u00a76Interest: \u00a7f+" + num(add) + " \u00a76aura \u00a77(you owe " + num(k.debt) + ")");
    }

    // ---------------------------------------------------------------- bankruptcy and I.R.S.

    /** The debt is more than the debtor has left: A.P.R. turns into I.R.S. The contract must already be out of the user's list. */
    private static void bankrupt(ServerPlayer user, Contract k, LivingEntity debtor, ServerLevel level) {
        removeApr(level, k); // A.P.R. turns into I.R.S. on the spot
        long until = level.getServer().overworld().getGameTime() + HakowareTuning.IRS_DAYS * HakowareTuning.TICKS_PER_DAY;
        spawnIrs(debtor, until);
        HatsuEffects.apply(debtor, 100);
        Vec3 at = debtor.position().add(0, debtor.getBbHeight() * 0.6, 0);
        level.sendParticles(ParticleTypes.POOF, at.x, at.y, at.z, 30, 0.6, 0.6, 0.6, 0.05);
        level.sendParticles(ParticleTypes.SQUID_INK, at.x, at.y, at.z, 20, 0.5, 0.6, 0.5, 0.05);
        sound(level, debtor, SoundEvents.ENDER_DRAGON_GROWL, 0.6f, 1.6f);
        String name = debtor.getDisplayName().getString();
        chat(user, "\u00a76" + name + " \u00a7chas gone bankrupt! \u00a77I.R.S. will follow them for " + HakowareTuning.IRS_DAYS + " days");
        msg(user, "\u00a76Hakoware: \u00a7fbankruptcy");
        if (debtor instanceof ServerPlayer dp) {
            chat(dp, "\u00a74You owe more aura than you have. I.R.S. has come for you: Zetsu is forced on you for " + HakowareTuning.IRS_DAYS + " days");
        }
    }

    /** Has an I.R.S. sentence running (a player's record, or an I.R.S. creature next to them). */
    public static boolean isIndebted(LivingEntity e) {
        if (e instanceof ServerPlayer p && curseUntil(p) > 0) return true;
        if (!(e.level() instanceof ServerLevel level)) return false;
        return !level.getEntitiesOfClass(IrsEntity.class, e.getBoundingBox().inflate(48),
            irs -> e.getUUID().equals(irs.debtorId())).isEmpty();
    }

    /** Raises an I.R.S. beside the debtor and, for a player, writes the sentence into their own data. */
    public static IrsEntity spawnIrs(LivingEntity debtor, long until) {
        if (!(debtor.level() instanceof ServerLevel level)) return null;
        if (debtor instanceof ServerPlayer p) setCurse(p, until);
        IrsEntity irs = new IrsEntity(HxHEntities.IRS.get(), level);
        irs.setDebtor(debtor.getUUID(), until);
        irs.moveTo(debtor.getX(), debtor.getY() + debtor.getBbHeight() + 0.3, debtor.getZ(), debtor.getYRot(), 0f);
        level.addFreshEntity(irs);
        return irs;
    }

    private static long curseUntil(ServerPlayer p) {
        return p.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG).getLong(CURSE_KEY);
    }

    private static void setCurse(ServerPlayer p, long until) {
        CompoundTag persisted = p.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        persisted.putLong(CURSE_KEY, until);
        p.getPersistentData().put(Player.PERSISTED_NBT_TAG, persisted);
    }

    private static void clearCurse(ServerPlayer p) {
        CompoundTag persisted = p.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        persisted.remove(CURSE_KEY);
        p.getPersistentData().put(Player.PERSISTED_NBT_TAG, persisted);
    }

    /** The sentence is over (the I.R.S. creature ran out its time): Forced Zetsu comes off. */
    public static void curseEnded(MinecraftServer server, UUID debtorId) {
        ServerPlayer p = server.getPlayerList().getPlayer(debtorId);
        if (p != null) {
            clearCurse(p);
            HatsuEffects.remove(p);
            msg(p, "\u00a77I.R.S. has left. Your Nen is yours again");
            return;
        }
        for (ServerLevel l : server.getAllLevels()) {
            if (l.getEntity(debtorId) instanceof LivingEntity le) HatsuEffects.remove(le);
        }
    }

    /** Once a second: every player under sentence is held in Forced Zetsu and has an I.R.S. beside them. */
    private static void curseTick(MinecraftServer server) {
        long now = server.overworld().getGameTime();
        for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
            long until = curseUntil(p);
            if (until <= 0) continue;
            if (now >= until) {
                clearCurse(p);
                HatsuEffects.remove(p);
                msg(p, "\u00a77I.R.S. has left. Your Nen is yours again");
                continue;
            }
            if (!p.isAlive() || !(p.level() instanceof ServerLevel level)) continue;
            HatsuEffects.apply(p, 100);
            boolean has = !level.getEntitiesOfClass(IrsEntity.class, p.getBoundingBox().inflate(48),
                irs -> p.getUUID().equals(irs.debtorId())).isEmpty();
            if (!has) spawnIrs(p, until);
        }
    }

    // ---------------------------------------------------------------- per tick

    public static void serverTick(MinecraftServer server) {
        if (server == null) return;
        int gameTick = server.getTickCount();
        if (gameTick % 20 == 0) curseTick(server);
        if (STATES.isEmpty()) return;
        for (Map.Entry<UUID, State> en : new ArrayList<>(STATES.entrySet())) {
            State s = en.getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null) {
                wipe(en.getKey());
                continue;
            }
            Combat c = Combat.get(sp);
            if (!sp.isAlive() || !canUse(c) || ExtrasHooks.hatsuForced(sp)) {
                clear(sp);
                continue;
            }
            if (!(sp.level() instanceof ServerLevel level)) continue;
            tick(sp, s, level, gameTick);
        }
    }

    private static void tick(ServerPlayer sp, State s, ServerLevel level, int gameTick) {
        if (s.cd > 0) s.cd--;
        if (!s.on) return;
        Iterator<Contract> it = s.contracts.values().iterator();
        while (it.hasNext()) {
            Contract k = it.next();
            LivingEntity t = level.getEntity(k.target) instanceof LivingEntity le && le.isAlive() ? le : null;
            if (t == null) { // dead, gone, or in another dimension: the debt goes with them, and A.P.R. vanishes
                removeApr(level, k);
                it.remove();
                continue;
            }
            if (--k.timer <= 0) {
                k.timer = HakowareTuning.INTEREST_TICKS;
                interest(sp, level, k, t);
            }
            if (gameTick % 5 == 0) {
                float pop = pop(t);
                if (k.debt > pop) {
                    it.remove();
                    bankrupt(sp, k, t, level);
                    continue;
                }
                if (aprOf(level, k) == null && k.apr != null) spawnApr(sp, t, k); // it was lost (unloaded, killed): a new one takes over
                refreshApr(level, k, pop);
            }
        }
    }

    // ---------------------------------------------------------------- ending

    private static void wipe(UUID id) {
        State s = STATES.remove(id);
        if (s == null) return;
        for (Contract k : s.contracts.values()) {
            if (k.apr != null) APRS.remove(k.apr);
        }
    }

    /** Death, losing the Hatsu, Forced Zetsu, logging out: every contract is void and every A.P.R. is gone (I.R.S. sentences stay). */
    public static void clear(ServerPlayer sp) {
        State s = STATES.remove(sp.getUUID());
        if (s == null) return;
        ServerLevel level = sp.level() instanceof ServerLevel lv ? lv : null;
        for (Contract k : s.contracts.values()) {
            if (k.apr != null) {
                UUID id = k.apr;
                APRS.remove(id);
                if (level != null && level.getEntity(id) instanceof AprEntity apr) apr.discard();
            }
        }
    }

    public static void reset() {
        STATES.clear();
        APRS.clear();
    }
}
