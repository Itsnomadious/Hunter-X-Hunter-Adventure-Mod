package net.hxhadventure.addon;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import java.util.Collection;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * /hxh set nenlevel <level|ten|zetsu|ren|en|hatsu|all> <1-100> [players]
 * ("level" is your overall Nen level; the rest are the individual skills shown in the Mastery menu.)
 * /hxh set lifespan <0-100> [players]   /hxh lifespan add <years> [players]   (add may be negative)
 * Both need permission level 2 (op / command blocks / cheats).
 */
public final class NenSkillCommand {
    private NenSkillCommand() {}

    public static LiteralArgumentBuilder<CommandSourceStack> levelNode() {
        var set = Commands.literal("nenlevel").requires(src -> src.hasPermission(2));
        for (NenSkill skill : NenSkill.values()) {
            set.then(branch(skill.name().toLowerCase(), skill));
        }
        set.then(branch("all", null));
        set.then(Commands.literal("level").then(
            Commands.argument("level", IntegerArgumentType.integer(1, NenSkill.MAX_LEVEL))
                .executes(ctx -> applyOverall(ctx.getSource(), java.util.List.of(ctx.getSource().getPlayerOrException()),
                    IntegerArgumentType.getInteger(ctx, "level")))
                .then(Commands.argument("targets", EntityArgument.players())
                    .executes(ctx -> applyOverall(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"),
                        IntegerArgumentType.getInteger(ctx, "level"))))));
        return set;
    }

    /** /hxh set gratitude <0-10000> [players]: sets how many times the player has prayed (see Prayer). */
    public static LiteralArgumentBuilder<CommandSourceStack> gratitudeNode() {
        return Commands.literal("gratitude").requires(src -> src.hasPermission(2)).then(
            Commands.argument("count", IntegerArgumentType.integer(0, Prayer.MAX_PRAYERS))
                .executes(ctx -> applyGratitude(ctx.getSource(), java.util.List.of(ctx.getSource().getPlayerOrException()),
                    IntegerArgumentType.getInteger(ctx, "count")))
                .then(Commands.argument("targets", EntityArgument.players())
                    .executes(ctx -> applyGratitude(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"),
                        IntegerArgumentType.getInteger(ctx, "count")))));
    }

    private static int applyGratitude(CommandSourceStack src, Collection<ServerPlayer> targets, int count) {
        for (ServerPlayer p : targets) {
            NenAddonData d = NenAddonData.get(p);
            d.prayers = count;
            d.save();
        }
        String msg = targets.size() == 1
            ? "Set prayers to " + count + " for " + targets.iterator().next().getName().getString()
            : "Set prayers to " + count + " for " + targets.size() + " players";
        src.sendSuccess(() -> Component.literal(msg), true);
        return targets.size();
    }

    /** /hxh set lifespan <0-max> [players] */
    public static LiteralArgumentBuilder<CommandSourceStack> setLifespanNode() {
        return lifespanBranch("lifespan", 0f, Tuning.LIFESPAN_MAX, false);
    }

    /** /hxh lifespan add <years> [players]  (may be negative) */
    public static LiteralArgumentBuilder<CommandSourceStack> addLifespanNode() {
        float max = Tuning.LIFESPAN_MAX;
        return Commands.literal("lifespan").requires(src -> src.hasPermission(2)).then(lifespanBranch("add", -max, max, true));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> lifespanBranch(String name, float lo, float hi, boolean add) {
        return Commands.literal(name).requires(src -> src.hasPermission(2)).then(
            Commands.argument("years", FloatArgumentType.floatArg(lo, hi))
                .executes(ctx -> applyLifespan(ctx.getSource(), java.util.List.of(ctx.getSource().getPlayerOrException()),
                    FloatArgumentType.getFloat(ctx, "years"), add))
                .then(Commands.argument("targets", EntityArgument.players())
                    .executes(ctx -> applyLifespan(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"),
                        FloatArgumentType.getFloat(ctx, "years"), add))));
    }

    private static int applyLifespan(CommandSourceStack src, Collection<ServerPlayer> targets, float years, boolean add) {
        for (ServerPlayer p : targets) {
            NenAddonData d = NenAddonData.get(p);
            d.setLifespan(add ? d.lifespan + years : years);
            if (p != src.getEntity()) {
                p.sendSystemMessage(Component.literal("\u00a7aLifespan is now " + Math.round(d.lifespan * 10f) / 10f + " years"));
            }
        }
        String msg = targets.size() == 1
            ? targets.iterator().next().getName().getString() + " now has "
                + Math.round(NenAddonData.get(targets.iterator().next()).lifespan * 10f) / 10f + " years of lifespan"
            : "Changed lifespan for " + targets.size() + " players";
        src.sendSuccess(() -> Component.literal(msg), true);
        return targets.size();
    }

    private static ArgumentBuilder<CommandSourceStack, ?> branch(String name, NenSkill skill) {
        return Commands.literal(name).then(
            Commands.argument("level", IntegerArgumentType.integer(1, NenSkill.MAX_LEVEL))
                .executes(ctx -> apply(ctx.getSource(), java.util.List.of(ctx.getSource().getPlayerOrException()),
                    skill, IntegerArgumentType.getInteger(ctx, "level")))
                .then(Commands.argument("targets", EntityArgument.players())
                    .executes(ctx -> apply(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"),
                        skill, IntegerArgumentType.getInteger(ctx, "level")))));
    }

    private static int apply(CommandSourceStack src, Collection<ServerPlayer> targets, NenSkill skill, int level) {
        String what = skill == null ? "Level and all Nen skills" : skill.label;
        for (ServerPlayer p : targets) {
            NenAddonData d = NenAddonData.get(p);
            if (skill == null) {
                for (NenSkill s : NenSkill.values()) d.setLevel(s, level);
                net.hxhadventure.abilities.Combat c = net.hxhadventure.abilities.Combat.get(p);
                if (c != null) c.setHatsuLevel(level); // "all" also sets the main Level
            } else {
                d.setLevel(skill, level);
            }
            if (p != src.getEntity()) {
                p.sendSystemMessage(Component.literal("\u00a7a" + what + " set to level " + level));
            }
        }
        String msg = targets.size() == 1
            ? "Set " + what + " to level " + level + " for " + targets.iterator().next().getName().getString()
            : "Set " + what + " to level " + level + " for " + targets.size() + " players";
        src.sendSuccess(() -> Component.literal(msg), true);
        return targets.size();
    }

    private static int applyOverall(CommandSourceStack src, Collection<ServerPlayer> targets, int level) {
        for (ServerPlayer p : targets) {
            net.hxhadventure.abilities.Combat c = net.hxhadventure.abilities.Combat.get(p);
            if (c == null) continue;
            c.setHatsuLevel(level);
            if (p != src.getEntity()) {
                p.sendSystemMessage(Component.literal("\u00a7eYour Nen level has been set to \u00a7b" + level + "\u00a7e!"));
            }
        }
        String msg = targets.size() == 1
            ? "Set Nen level to " + level + " for " + targets.iterator().next().getName().getString()
            : "Set Nen level to " + level + " for " + targets.size() + " players";
        src.sendSuccess(() -> Component.literal(msg), true);
        return targets.size();
    }
}
