package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.List;
import net.hxhadventure.abilities.Combat;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * The melee body of an NPC: runs {@link MeleeCore} and turns its blows into hits, knockback, particles and movement, plus the footwork
 * around it (the rush that closes a gap, backstep after a combo, a sidestep against a charging Strong attack or an incoming projectile).
 * One instance per NPC; the entity forwards its tick, choose, cancel and slow to it.
 */
public final class NpcMelee implements MeleeCore.Sink {

    /** What the NPC has to provide. */
    public interface Host {
        boolean isFoe(Entity e);
        /** Multiplier on a blow's base damage (spirit bonus, melee multiplier, Hatsu boosts...). Asked once per blow, only when it lands. */
        float meleeScale();
        /** The arm / punch animation. */
        void swingAnim();
    }

    private final PathfinderMob mob;
    private final Host host;
    public final MeleeCore core;

    private LivingEntity target;
    private Vec3 moveDir = Vec3.ZERO;
    private double moveSpeed;
    private int moveTicks;
    private boolean moveIsDodge;
    private int rushCooldown, dodgeCooldown, strafeFlip;
    private boolean strafeRight;

    public NpcMelee(PathfinderMob mob, Host host, MeleeCore.Cfg cfg) {
        this.mob = mob;
        this.host = host;
        this.core = new MeleeCore(cfg, this, new java.util.Random(mob.getRandom().nextLong()));
        this.strafeRight = mob.getRandom().nextBoolean();
    }

    // ---------------------------------------------------------------------------------------------
    // what the entity calls
    // ---------------------------------------------------------------------------------------------

    public boolean isAttacking() { return core.isAttacking(); }

    public float slow() { return core.currentSlow(); }

    public void recover(int ticks) { core.setRecovery(ticks); }

    public void cancel() {
        core.cancel();
        moveTicks = 0;
    }

    public void choose(@Nullable LivingEntity t) {
        if (t != null) target = t;
        core.choose();
    }

    /** True while a rush, backstep or sidestep is carrying the NPC: the goal does not steer. */
    public boolean mobilityBusy() { return moveTicks > 0; }

    /** Once per server tick. */
    public void tick(@Nullable LivingEntity t, boolean inReach, boolean busy) {
        target = t;
        if (rushCooldown > 0) rushCooldown--;
        if (dodgeCooldown > 0) dodgeCooldown--;
        core.tick(inReach, busy);
        if (moveTicks > 0) driveMove(inReach);
        if (t != null && !busy && !core.isAttacking() && moveTicks <= 0) {
            if (core.takeComboEnded() && mob.getRandom().nextDouble() < NpcFeelTuning.BACKSTEP_CHANCE) backstep(t);
            else react(t);
        } else if (t == null || busy) {
            core.takeComboEnded();
        }
    }

    // ---------------------------------------------------------------------------------------------
    // footwork
    // ---------------------------------------------------------------------------------------------

    /** The gap closer: a short, very fast run at a target that is far enough to be worth it. True if it started. */
    public boolean tryRush(LivingEntity t, double dist) {
        if (rushCooldown > 0 || core.isAttacking() || moveTicks > 0 || !mob.onGround()) return false;
        if (dist < NpcFeelTuning.RUSH_MIN_DIST || dist > NpcFeelTuning.RUSH_MAX_DIST || !mob.hasLineOfSight(t)) return false;
        Vec3 d = new Vec3(t.getX() - mob.getX(), 0, t.getZ() - mob.getZ()).normalize();
        startMove(d, NpcFeelTuning.RUSH_SPEED, NpcFeelTuning.RUSH_TICKS, false);
        rushCooldown = NpcFeelTuning.RUSH_COOLDOWN;
        if (mob.level() instanceof ServerLevel sl) {
            sl.playSound(null, mob.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 0.9f, 1.4f);
            sl.sendParticles(ParticleTypes.CLOUD, mob.getX(), mob.getY() + 0.1, mob.getZ(), 8, 0.3, 0.05, 0.3, 0.02);
        }
        return true;
    }

    /** Between attacks and in reach: circle the target instead of standing like a post. */
    public void footwork(LivingEntity t, double dist) {
        if (--strafeFlip <= 0) {
            strafeFlip = NpcFeelTuning.STRAFE_FLIP_MIN + mob.getRandom().nextInt(NpcFeelTuning.STRAFE_FLIP_RANGE);
            strafeRight = !strafeRight;
        }
        float fwd = dist < 1.4 ? -0.25f : (float) NpcFeelTuning.STRAFE_FORWARD;
        mob.getMoveControl().strafe(fwd, (float) (strafeRight ? NpcFeelTuning.STRAFE_SIDE : -NpcFeelTuning.STRAFE_SIDE));
    }

    private void backstep(LivingEntity t) {
        Vec3 away = new Vec3(mob.getX() - t.getX(), 0, mob.getZ() - t.getZ()).normalize();
        startMove(away, NpcFeelTuning.BACKSTEP_SPEED, NpcFeelTuning.BACKSTEP_TICKS, true);
    }

    /** Sidestep a Strong attack being charged at us, or a projectile that is about to hit. */
    private void react(LivingEntity t) {
        if (dodgeCooldown > 0 || !mob.onGround()) return;
        boolean charging = false;
        if (t instanceof Player p && mob.distanceTo(t) < NpcFeelTuning.DODGE_TRIGGER_DIST) {
            Combat c = Combat.get(p);
            charging = c != null && c.isChargingStrongAttack();
        }
        boolean incoming = !charging && incomingProjectile();
        if (!charging && !incoming) return;
        dodgeCooldown = NpcFeelTuning.DODGE_COOLDOWN / 2;           // do not re-roll every tick
        double chance = charging ? NpcFeelTuning.DODGE_CHARGE_CHANCE : NpcFeelTuning.DODGE_PROJECTILE_CHANCE;
        if (mob.getRandom().nextDouble() >= chance) return;
        dodgeCooldown = NpcFeelTuning.DODGE_COOLDOWN;
        Vec3 to = new Vec3(t.getX() - mob.getX(), 0, t.getZ() - mob.getZ()).normalize();
        Vec3 side = new Vec3(-to.z, 0, to.x).scale(mob.getRandom().nextBoolean() ? 1 : -1);
        startMove(side, NpcFeelTuning.DODGE_SPEED, NpcFeelTuning.DODGE_TICKS, true);
        if (mob.level() instanceof ServerLevel sl) {
            sl.playSound(null, mob.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 0.7f, 1.7f);
            sl.sendParticles(ParticleTypes.POOF, mob.getX(), mob.getY() + 0.9, mob.getZ(), 6, 0.25, 0.4, 0.25, 0.02);
        }
    }

    private boolean incomingProjectile() {
        AABB box = mob.getBoundingBox().inflate(7.0);
        List<Projectile> list = mob.level().getEntitiesOfClass(Projectile.class, box, p -> p.getOwner() != mob && p.getDeltaMovement().lengthSqr() > 0.04);
        Vec3 me = mob.position().add(0, mob.getBbHeight() * 0.5, 0);
        for (Projectile p : list) {
            Vec3 v = p.getDeltaMovement().normalize();
            Vec3 to = me.subtract(p.position());
            double d = to.length();
            if (d < 0.1) continue;
            if (v.dot(to.scale(1.0 / d)) > 0.85 && d < 7.0) return true;
        }
        return false;
    }

    private void startMove(Vec3 dir, double speed, int ticks, boolean dodge) {
        if (dir.lengthSqr() < 1e-6) return;
        moveDir = dir.normalize();
        moveSpeed = speed;
        moveTicks = ticks;
        moveIsDodge = dodge;
    }

    private void driveMove(boolean inReach) {
        moveTicks--;
        mob.getNavigation().stop();
        Vec3 v = mob.getDeltaMovement();
        mob.setDeltaMovement(moveDir.x * moveSpeed, v.y, moveDir.z * moveSpeed);
        mob.hasImpulse = true;
        if (mob.horizontalCollision || (!moveIsDodge && inReach)) moveTicks = 0;   // a rush ends the moment it arrives
    }

    // ---------------------------------------------------------------------------------------------
    // MeleeCore.Sink
    // ---------------------------------------------------------------------------------------------

    @Override
    public void swing() {
        host.swingAnim();
    }

    @Override
    public void snapFace() {
        if (target == null) return;
        double dx = target.getX() - mob.getX(), dz = target.getZ() - mob.getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        double dy = target.getEyeY() - mob.getEyeY();
        float pitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * (180.0 / Math.PI));
        mob.setYRot(yaw);
        mob.setYHeadRot(yaw);
        mob.yBodyRot = yaw;
        mob.setXRot(pitch);
    }

    @Override
    public void lunge(double speed, int ticks) {
        if (target == null) return;
        double dist = mob.distanceTo(target);
        if (dist < 1.3) return;                                     // already on top of it
        Vec3 d = new Vec3(target.getX() - mob.getX(), 0, target.getZ() - mob.getZ()).normalize();
        startMove(d, speed, ticks, true);
    }

    @Override
    public void strongStarted() {
        if (mob.level() instanceof ServerLevel sl)
            sl.playSound(null, mob.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 0.6f, 0.6f);
    }

    @Override
    public void charge(float progress) {
        if (!(mob.level() instanceof ServerLevel sl)) return;
        Vec3 look = mob.getLookAngle();
        int count = 1 + (int) (3.0f * progress);
        sl.sendParticles(ParticleTypes.CRIT, mob.getX() + look.x * 0.7, mob.getY() + 1.2, mob.getZ() + look.z * 0.7, count, 0.15, 0.15, 0.15, 0.02);
    }

    @Override
    public int impact(MeleeCore.Hit h) {
        if (!(mob.level() instanceof ServerLevel sl)) return 0;
        // the hit volume starts at the body: everything around the NPC within (range + BODY_REACH_BONUS) of its surface and in front of it
        double reach = h.range + NpcFeelTuning.BODY_REACH_BONUS;
        Vec3 look = mob.getLookAngle();
        double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
        AABB box = mob.getBoundingBox().inflate(reach, 1.0, reach);
        List<LivingEntity> victims = new ArrayList<>(sl.getEntitiesOfClass(LivingEntity.class, box, e -> host.isFoe(e) && inFront(e, reach, lx, lz, ll)));
        // a hit the AI judged "in reach" must not be lost to aim: its own target always counts when it is that close
        if (target != null && !victims.contains(target) && host.isFoe(target)
            && mob.distanceTo(target) - target.getBbWidth() * 0.5 <= h.range + NpcFeelTuning.TARGET_HIT_LEEWAY && Math.abs(target.getY() - mob.getY()) < 2.5) {
            victims.add(target);
        }
        int landed = 0;
        if (!victims.isEmpty()) {
            float total = h.damage * host.meleeScale();
            for (LivingEntity e : victims) {
                e.invulnerableTime = 0;                              // every blow of a chain lands in full
                if (!e.hurt(mob.damageSources().mobAttack(mob), total)) continue;
                landed++;
                if (h.pin) pin(e); else launch(e, h.knockH, h.knockV);
                impactFx(sl, e, h);
            }
        }
        if (landed == 0 && NpcFeelTuning.DEBUG_MELEE) {
            com.mojang.logging.LogUtils.getLogger().info("[hxh melee] {} {} hit nobody: victims {}, target {}, dist {}", mob.getName().getString(), h.kind, victims.size(),
                target == null ? "none" : target.getName().getString(), target == null ? -1 : mob.distanceTo(target));
        }
        if (landed == 0) sl.playSound(null, mob.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 0.8f, h.kind == MeleeCore.Kind.STRONG ? 0.7f : 1.1f);
        return landed;
    }

    /** Within reach of the NPC's body surface and in its front half (so a victim hugging it still counts, one behind it does not). */
    private boolean inFront(LivingEntity e, double reach, double lx, double lz, double ll) {
        double dx = e.getX() - mob.getX(), dz = e.getZ() - mob.getZ();
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d - e.getBbWidth() * 0.5 - mob.getBbWidth() * 0.5 > reach) return false;
        if (d < 0.9 || ll < 1e-4) return true;
        return (lx * dx + lz * dz) / (ll * d) >= NpcFeelTuning.FRONT_COS;
    }

    /** Knockback as a direct launch (Jujutsu Craft's way) instead of vanilla's nudge; replaces the 0.4 push hurt() already gave. */
    private void launch(LivingEntity e, double horizontal, double vertical) {
        Vec3 d = new Vec3(e.getX() - mob.getX(), 0, e.getZ() - mob.getZ());
        d = d.lengthSqr() < 1e-6 ? mob.getLookAngle().multiply(1, 0, 1) : d;
        d = d.normalize();
        double res = e.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE) * NpcFeelTuning.LAUNCH_RESIST_SHARE;
        double h = horizontal * (1.0 - Mth.clamp(res, 0.0, 0.8));
        double vy = vertical > 0 ? (e.onGround() ? vertical : Math.max(e.getDeltaMovement().y, vertical * 0.5)) : Math.min(e.getDeltaMovement().y, 0.0);
        e.setDeltaMovement(d.x * h, vy, d.z * h);
        e.hurtMarked = true;
        e.hasImpulse = true;
    }

    /** A barrage hit holds the target where it is (and reels it in a little), so the next hit connects. */
    private void pin(LivingEntity e) {
        Vec3 v = e.getDeltaMovement();
        double vx = v.x * 0.1, vz = v.z * 0.1;
        double dx = mob.getX() - e.getX(), dz = mob.getZ() - e.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > NpcFeelTuning.BARRAGE_PIN_DIST) {
            vx += dx / dist * NpcFeelTuning.BARRAGE_PIN_PULL;
            vz += dz / dist * NpcFeelTuning.BARRAGE_PIN_PULL;
        }
        e.setDeltaMovement(vx, Math.min(v.y, 0.0) * 0.5, vz);
        e.hurtMarked = true;
        e.hasImpulse = true;
    }

    private void impactFx(ServerLevel sl, LivingEntity e, MeleeCore.Hit h) {
        double x = e.getX(), y = e.getY() + e.getBbHeight() * 0.6, z = e.getZ();
        switch (h.kind) {
            case STRONG -> {
                sl.playSound(null, mob.blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.HOSTILE, 1.0f, 0.7f);
                sl.playSound(null, mob.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 0.4f, 1.5f);
                sl.sendParticles(ParticleTypes.SONIC_BOOM, x, y, z, 1, 0, 0, 0, 0);
                sl.sendParticles(ParticleTypes.CRIT, x, y, z, 14, 0.3, 0.3, 0.3, 0.3);
            }
            case FINISHER, BARRAGE_END -> {
                sl.playSound(null, mob.blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.HOSTILE, 0.9f, 1.0f);
                sl.sendParticles(ParticleTypes.SWEEP_ATTACK, x, y, z, 1, 0, 0, 0, 0);
                sl.sendParticles(ParticleTypes.CRIT, x, y, z, 8, 0.25, 0.25, 0.25, 0.25);
            }
            case BARRAGE -> {
                sl.playSound(null, mob.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, 0.6f, 1.3f);
                sl.sendParticles(ParticleTypes.CRIT, x, y, z, 2, 0.2, 0.2, 0.2, 0.1);
            }
            default -> {
                sl.playSound(null, mob.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, 1.0f, 1.0f);
                sl.sendParticles(ParticleTypes.CRIT, x, y, z, 4, 0.2, 0.2, 0.2, 0.15);
            }
        }
    }
}
