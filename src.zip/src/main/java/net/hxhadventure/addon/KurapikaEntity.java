package net.hxhadventure.addon;

import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.client.ChainFx;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketChainFx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Kurapika (NPC): the Chains, run like a player runs them. Dowsing Chain as the ranged opener, Chain Jail to bind the target for a free
 * exchange, Holy Chain to heal himself when hurt, and Emperor Time (all Nen types at 100%, +50% damage / speed / durability, chains +50%,
 * scarlet eyes) when the fight is hard or his enemy is Chrollo, whom he attacks on sight. In Emperor Time he also casts the Judgment Chain,
 * which seals the target's Nen. The numbers are the player's (ChainManager / JudgmentChain / Tuning); the chain visuals reuse PacketChainFx.
 * Emperor Time costs aura instead of lifespan here: a start cost, an upkeep, a time limit and the player's cooldown.
 */
public class KurapikaEntity extends NenFighter {
    public static final NpcStats STATS = new NpcStats("kurapika", Combat.NEN_CONJURATION)
        .levels(90, 92, 90, 88)
        .body(150.0, 0.30, 0.35, 1.0f)
        .melee(1.0f, 2.5)
        .look("redaura_ten", 0xE9D9A0, 0x1F3A8A);

    /** Synced: Emperor Time is on (draws the scarlet eyes). */
    private static final EntityDataAccessor<Boolean> EMPEROR_FX = SynchedEntityData.defineId(KurapikaEntity.class, EntityDataSerializers.BOOLEAN);

    // ---- the player's numbers (ChainManager is private about them) ----
    private static final float SWEEP_COST = 100f, HOLY_COST = 150f, JAIL_COST = 300f, JAIL_UPKEEP = 15f;
    private static final int SWEEP_CD = 30, JAIL_CD = 400, HOLY_RELEASE_CD = 20;
    private static final int JAIL_BASE_TICKS = 20;
    private static final int SWEEP_TICKS = 6, SWEEP_RETRACT_TICKS = 8;
    private static final double SWEEP_HALF_ARC = Math.toRadians(70);
    private static final double JAIL_RANGE = 18.0;
    // ---- NPC-only: how long and how dearly Emperor Time runs for him ----
    private static final float EMPEROR_START_COST = 300f, EMPEROR_UPKEEP = 15f;
    private static final int EMPEROR_MAX_TICKS = 20 * 45;
    private static final int HOLY_MAX_TICKS = 20 * 8;
    private static final int JUDGMENT_SEAL_TICKS = 20 * 12;

    private int sweepCd, jailCd, holyCd, judgCd, emperorCd;
    private int sweepTick = -1;
    private Vec3 sweepSide = Vec3.ZERO;
    private double sweepSign = 1;
    private final java.util.Set<Integer> sweepHit = new java.util.HashSet<>();
    private java.util.UUID jailTarget;
    private int jailTicks;
    private boolean holyOn;
    private int holyTick;
    private int judgTicks;
    private java.util.UUID judgTarget;
    private int castBusy;
    private boolean emperor;
    private int emperorTicks;

    public KurapikaEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, STATS);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(EMPEROR_FX, false);
    }

    public boolean emperorEyes() { return this.entityData.get(EMPEROR_FX); }

    public boolean inEmperorTime() { return emperor; }

    // ------------------------------------------------------------------ hooks into the base

    /** He attacks Chrollo on sight. */
    @Override
    protected boolean hostileOnSight(LivingEntity e) {
        return e instanceof ChrolloEntity;
    }

    @Override
    protected boolean hatsuBusy() {
        return castBusy > 0;
    }

    /** Stands off to swing the Dowsing Chain while it is ready; otherwise fights in reach. */
    @Override
    protected double preferredRange() {
        return !emperor && sweepCd <= 0 && jailTarget == null && canAfford(SWEEP_COST) ? 6.0 : 0.0;
    }

    private float boost() { return emperor ? Tuning.EMPEROR_CHAIN_BOOST : 1.0f; }

    @Override
    protected float extraOutgoingMult(@Nullable DamageSource src) {
        if (!emperor) return 1.0f;
        return Tuning.EMPEROR_BOOST * Affinity.dealt(Affinity.ALL) / Affinity.dealt(nenType);
    }

    @Override
    protected float extraIncomingMult(DamageSource src) {
        if (!emperor) return 1.0f;
        return Affinity.taken(Affinity.ALL) / Affinity.taken(nenType) / Tuning.EMPEROR_BOOST;
    }

    @Override
    protected float extraSpeedBonus() {
        return emperor ? Tuning.EMPEROR_BOOST - 1.0f : 0.0f;
    }

    @Override
    protected void onAuraGone() {
        endEmperor(false);
        releaseJail(false);
        endHoly();
    }

    @Override
    protected void onFightEnd() {
        endEmperor(false);
        releaseJail(false);
        endHoly();
        judgTarget = null;
        judgTicks = 0;
        castBusy = 0;
        sweepTick = -1;
    }

    // ------------------------------------------------------------------ the Hatsu

    @Override
    protected void tickHatsu(@Nullable LivingEntity target, boolean fighting) {
        if (sweepCd > 0) sweepCd--;
        if (jailCd > 0) jailCd--;
        if (holyCd > 0) holyCd--;
        if (judgCd > 0) judgCd--;
        if (emperorCd > 0) emperorCd--;
        if (castBusy > 0) castBusy--;
        if (!(level() instanceof ServerLevel level)) return;

        // held down: Chain Jail / Forced Zetsu take the Hatsu away with the Nen
        boolean held = !canUseNen() || ChainManager.isJailed(this);
        if (held) {
            if (emperor) endEmperor(true);
            releaseJail(true);
            endHoly();
        }

        tickSweep(level);
        tickJail(level);
        tickHoly(level);
        tickJudgment(level);
        tickEmperor(level);
        if (held || target == null || !fighting) return;

        double dist = distanceTo(target);
        boolean los = hasLineOfSight(target);

        // Emperor Time: when the fight is hard, or the enemy is the Phantom Troupe's
        if (!emperor && emperorCd <= 0 && (target instanceof ChrolloEntity
            || getHealth() < getMaxHealth() * 0.65f || (lastHitAge() < 60 && getHealth() < getMaxHealth() * 0.8f))) {
            startEmperor();
        }
        // Holy Chain: heal when hurt (the self-heal; he can keep fighting while it is held)
        if (!holyOn && holyCd <= 0 && getHealth() < getMaxHealth() * 0.55f && payAura(HOLY_COST)) startHoly(level);

        // Judgment Chain (Emperor Time only): seals the target's Nen
        if (emperor && judgCd <= 0 && judgTarget == null && los && dist <= JudgmentChain.RANGE && payAura(JudgmentChain.COST)) {
            startJudgment(level, target);
        }
        // Chain Jail: bind the target for a free exchange
        if (jailTarget == null && jailCd <= 0 && los && dist <= JAIL_RANGE && dist >= 2.0 && !ChainManager.isJailed(target)
            && !(target instanceof NenFighter) || (jailTarget == null && jailCd <= 0 && los && dist <= JAIL_RANGE && dist >= 2.0 && !ChainManager.isJailed(target))) {
            if (payAura(JAIL_COST)) startJail(level, target);
        }
        // Dowsing Chain: the ranged swing
        if (sweepTick < 0 && sweepCd <= 0 && dist <= sweepRange() && dist >= 2.5 && los && payAura(SWEEP_COST)) startSweep(level, target);
    }

    // ---- Dowsing Chain ----
    private double sweepRange() {
        return Math.min(14.0, 8.0 + stats.hatsu * 0.1);
    }

    private float sweepDamage() {
        return (6.0f + stats.hatsu * 0.25f) * boost();
    }

    private static double sweepAngleAt(double tick) {
        double x = Math.max(0.0, Math.min(1.0, tick / SWEEP_TICKS));
        return -SWEEP_HALF_ARC + 2 * SWEEP_HALF_ARC * (0.5 - 0.5 * Math.cos(Math.PI * x));
    }

    private void fx(ChainFx.Kind kind, int target, int duration, float dx, float dy, float dz, float side, float range) {
        AddonNetwork.sendToTracking(new PacketChainFx(kind, getId(), target, duration, dx, dy, dz, side, range), this);
    }

    private void sound(net.minecraft.sounds.SoundEvent ev, float vol, float pitch) {
        level().playSound(null, blockPosition(), ev, SoundSource.HOSTILE, vol, pitch);
    }

    private void startSweep(ServerLevel level, LivingEntity target) {
        sweepCd = SWEEP_CD;
        swingArm();
        sweepTick = 0;
        sweepHit.clear();
        Vec3 look = getLookAngle().normalize();
        Vec3 flat = new Vec3(-look.z, 0, look.x);
        sweepSide = flat.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : flat.normalize();
        sweepSign = random.nextBoolean() ? 1 : -1;
        castBusy = Math.max(castBusy, SWEEP_TICKS);
        fx(ChainFx.Kind.SWEEP, 0, SWEEP_TICKS + SWEEP_RETRACT_TICKS, (float) look.x, (float) look.y, (float) look.z, (float) sweepSign, (float) sweepRange());
        sound(SoundEvents.CHAIN_PLACE, 1.0f, 1.3f);
    }

    private void tickSweep(ServerLevel level) {
        if (sweepTick < 0) return;
        double a0 = sweepAngleAt(sweepTick), a1 = sweepAngleAt(sweepTick + 1);
        double out = Math.min(1.0, 0.15 + (sweepTick + 1) / 2.5);
        double range = sweepRange() * (1 - (1 - out) * (1 - out));
        Vec3 dir0 = getLookAngle().normalize();
        Vec3 flat = new Vec3(-dir0.z, 0, dir0.x);
        if (flat.lengthSqr() > 1e-6) sweepSide = flat.normalize();
        double am = (a0 + a1) * 0.5;
        Vec3 side = sweepSide.scale(sweepSign);
        Vec3 dir = dir0.scale(Math.cos(am)).add(side.scale(Math.sin(am)));
        Vec3 origin = position().add(0, getBbHeight() * 0.6, 0);
        Vec3 normal = dir0.cross(side);
        AABB box = getBoundingBox().inflate(range, range, range);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, this::isFoe)) {
            if (sweepHit.contains(e.getId())) continue;
            Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(origin);
            double along = to.dot(dir0), across = to.dot(side);
            double d = Math.sqrt(along * along + across * across);
            if (d > range) continue;
            if (Math.abs(to.dot(normal)) > 1.3 + e.getBbHeight() * 0.5) continue;
            double a = Math.atan2(across, along);
            double margin = 0.06 + Math.atan2(e.getBbWidth() * 0.5, Math.max(d, 0.5));
            if (a < a0 - margin || a > a1 + margin) continue;
            sweepHit.add(e.getId());
            hatsuHurt(e, sweepDamage());
            Vec3 push = dir.scale(0.4).add(0, 0.15, 0);
            e.push(push.x, push.y, push.z);
            e.hurtMarked = true;
            level.sendParticles(ParticleTypes.CRIT, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 8, 0.3, 0.3, 0.3, 0.1);
        }
        if (++sweepTick >= SWEEP_TICKS) {
            sweepTick = -1;
            sound(SoundEvents.CHAIN_HIT, 0.9f, 1.5f);
        }
    }

    // ---- Chain Jail ----
    private void startJail(ServerLevel level, LivingEntity victim) {
        swingArm();
        jailTarget = victim.getUUID();
        jailTicks = Math.max(1, (int) (JAIL_BASE_TICKS * boost()));
        ChainManager.npcJail(victim.getUUID(), getUUID());
        HatsuEffects.apply(victim, 40, true);
        fx(ChainFx.Kind.JAIL, victim.getId(), jailTicks, 0, 0, 0, 1f, 0);
        sound(SoundEvents.CHAIN_PLACE, 1.2f, 0.7f);
        sound(SoundEvents.ANVIL_LAND, 0.5f, 1.6f);
        castBusy = Math.max(castBusy, 4);
        if (victim instanceof ServerPlayer vp) {
            Combat vc = Combat.get(vp);
            if (vc != null && vc.hasNenUnlocked()) {
                NenAddonData.get(vp).setZetsu(vp, true, null);
                vp.displayClientMessage(net.minecraft.network.chat.Component.literal("§7Chain Jail: your aura is sealed (Zetsu)"), true);
            }
        }
    }

    private void tickJail(ServerLevel level) {
        if (jailTarget == null) return;
        if (!(level.getEntity(jailTarget) instanceof LivingEntity victim) || !victim.isAlive() || victim.distanceToSqr(this) > 30 * 30 || --jailTicks <= 0) {
            releaseJail(true);
            return;
        }
        if (tickCount % 20 == 0) {
            if (aura() < JAIL_UPKEEP) { releaseJail(true); return; }
            drainAura(JAIL_UPKEEP);
        }
        if (tickCount % 10 == 0) HatsuEffects.apply(victim, 40, true);
        victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 6, false, false, false));
        victim.addEffect(new MobEffectInstance(MobEffects.JUMP, 5, 128, false, false, false));
        if (victim instanceof Mob mob) {
            mob.setTarget(null);
            mob.getNavigation().stop();
        }
    }

    private void releaseJail(boolean cooldown) {
        if (jailTarget == null) return;
        if (level() instanceof ServerLevel sl && sl.getEntity(jailTarget) instanceof LivingEntity v) HatsuEffects.remove(v);
        ChainManager.npcRelease(jailTarget);
        fx(ChainFx.Kind.JAIL_END, 0, 0, 0, 0, 0, 0, 0);
        jailTarget = null;
        jailTicks = 0;
        if (cooldown) jailCd = JAIL_CD;
    }

    // ---- Holy Chain (on himself) ----
    private void startHoly(ServerLevel level) {
        holyOn = true;
        holyTick = 0;
        swingArm();
        fx(ChainFx.Kind.HOLY, getId(), HOLY_MAX_TICKS + 20, 0, 0, 0, 1f, 0);
        sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.0f, 1.0f);
    }

    private void tickHoly(ServerLevel level) {
        if (!holyOn) return;
        if (++holyTick > HOLY_MAX_TICKS || getHealth() >= getMaxHealth() * 0.9f) { endHoly(); return; }
        if (holyTick % 20 == 0) {
            heal(Math.max(1.0f, getMaxHealth() * 0.015f) * boost());
            level.sendParticles(ParticleTypes.HEART, getX(), getY() + getBbHeight() + 0.3, getZ(), 1, 0.3, 0.2, 0.3, 0.0);
        }
    }

    private void endHoly() {
        if (!holyOn) return;
        holyOn = false;
        holyCd = Math.max(HOLY_RELEASE_CD, 200);
        fx(ChainFx.Kind.HOLY_END, 0, 0, 0, 0, 0, 0, 0);
    }

    // ---- Judgment Chain: the stake seals the target's Nen ----
    private void startJudgment(ServerLevel level, LivingEntity target) {
        judgCd = JudgmentChain.COOLDOWN_TICKS;
        judgTarget = target.getUUID();
        judgTicks = JUDGMENT_SEAL_TICKS;
        swingArm();
        castBusy = Math.max(castBusy, 10);
        fx(ChainFx.Kind.JUDGMENT, target.getId(), JudgmentChain.FX_TICKS, 0, 0, 0, 1f, 0f);
        sound(SoundEvents.CHAIN_PLACE, 1.2f, 0.5f);
        sound(SoundEvents.TRIDENT_THUNDER, 0.6f, 0.6f);
    }

    private void tickJudgment(ServerLevel level) {
        if (judgTarget == null) return;
        if (!(level.getEntity(judgTarget) instanceof LivingEntity v) || !v.isAlive() || --judgTicks <= 0) {
            if (level.getEntity(judgTarget) instanceof LivingEntity v2 && jailTarget == null) HatsuEffects.remove(v2);
            judgTarget = null;
            return;
        }
        if (tickCount % 10 == 0) HatsuEffects.apply(v, 40, false); // the command "never use Nen again", for as long as the stake holds
    }

    // ---- Emperor Time ----
    private void startEmperor() {
        if (!payAura(EMPEROR_START_COST)) return;
        emperor = true;
        emperorTicks = 0;
        this.entityData.set(EMPEROR_FX, true);
        sound(SoundEvents.ENDER_DRAGON_GROWL, 0.8f, 1.4f);
    }

    private void endEmperor(boolean silent) {
        if (!emperor) return;
        emperor = false;
        emperorCd = Tuning.EMPEROR_COOLDOWN_TICKS;
        this.entityData.set(EMPEROR_FX, false);
        if (!silent) sound(SoundEvents.BEACON_DEACTIVATE, 0.6f, 0.7f);
    }

    private void tickEmperor(ServerLevel level) {
        if (!emperor) return;
        if (++emperorTicks >= EMPEROR_MAX_TICKS) { endEmperor(false); return; }
        if (tickCount % 20 == 0) {
            if (aura() < EMPEROR_UPKEEP) { endEmperor(false); return; }
            drainAura(EMPEROR_UPKEEP);
        }
        if (tickCount % 4 == 0) level.sendParticles(ParticleTypes.CRIMSON_SPORE, getX(), getY() + 1.0, getZ(), 2, 0.3, 0.6, 0.3, 0.01);
    }
}
