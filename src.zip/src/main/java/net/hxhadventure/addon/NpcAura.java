package net.hxhadventure.addon;

/**
 * Ten / Ren / Ken / Ko for NPCs (Hisoka, Chrollo, Gon, Neferpitou, Kite): the SAME numbers a player gets, so an NPC behaves as close to a
 * player as possible. Everything is driven by the NPC's Ten level through {@link Tuning#tenBonus}:
 * <ul>
 *   <li>Ten: damage +b, durability +b, speed +s (s = {@link Tuning#tenSpeedBonus})</li>
 *   <li>Ren: doubles Ten (all three x2)</li>
 *   <li>Ken: Ren + Ten, but 20% of the damage is given up (damage x0.8 of b, durability x1.8 of b, speed x1)</li>
 *   <li>Ko: out of Ten, all aura in the right arm: melee damage x2 of b, no durability, no speed, and the body is open ({@link Tuning#KO_INCOMING_MULT})</li>
 * </ul>
 * Ten's old armour / toughness attributes and the old NPC-only Ken / Ren numbers are gone: players do not have them either.
 */
public final class NpcAura {
    private NpcAura() {}

    /** 1 = exactly a player's speed percentages (Ten +20% at level 1, +1.1% per level, Ren x2). Lower it if an NPC becomes too hard to hit. */
    public static final float SPEED_SCALE = 1.0f;

    public static float damageBonus(int tenLevel, boolean ten, boolean ren, boolean ken, boolean ko, boolean melee) {
        float b = Tuning.tenBonus(tenLevel);
        if (ko) return melee ? b * Tuning.KO_DAMAGE_SHARE : 0f;
        if (ken) return b * Tuning.KEN_DAMAGE_SHARE;
        if (ren) return b * Tuning.REN_TEN_MULT;
        if (ten) return b;
        return 0f;
    }

    /**
     * The most durability an NPC's Ten / Ren / Ken can ever give. A level-100 NPC in Ren used to take 1/7 of the damage (Ten bonus 3.0, doubled by Ren),
     * which made them practically unhittable. Capped at 1.0 = at most half damage, so Ten / Ren / Ken still matter but a player can always hurt them.
     */
    public static final float MAX_DURABILITY_BONUS = 1.0f;

    public static float durabilityBonus(int tenLevel, boolean ten, boolean ren, boolean ken, boolean ko) {
        float b = Tuning.tenBonus(tenLevel);
        if (ko) return 0f;
        float d = 0f;
        if (ken) d = b * Tuning.KEN_DURABILITY_SHARE;
        else if (ren) d = b * Tuning.REN_TEN_MULT;
        else if (ten) d = b;
        return Math.min(d, MAX_DURABILITY_BONUS);
    }

    public static float speedBonus(int tenLevel, boolean ten, boolean ren, boolean ken, boolean ko) {
        float s = Tuning.tenSpeedBonus(tenLevel) * Tuning.BUFF_SPEED_SCALE * SPEED_SCALE;
        if (ko) return 0f;
        if (ken) return s * Tuning.KEN_SPEED_SHARE;
        if (ren) return s * Tuning.REN_TEN_MULT;
        if (ten) return s;
        return 0f;
    }

    /** Multiplier on the damage this NPC deals (melee hits; Hatsu hits skip it, exactly like a player's). */
    public static float outgoing(int tenLevel, boolean ten, boolean ren, boolean ken, boolean ko) {
        return 1f + damageBonus(tenLevel, ten, ren, ken, ko, true);
    }

    /** Multiplier on the damage this NPC takes: durability divides it, and Ko leaves the body wide open. */
    public static float incoming(int tenLevel, boolean ten, boolean ren, boolean ken, boolean ko) {
        float m = 1f / (1f + durabilityBonus(tenLevel, ten, ren, ken, ko));
        if (ko) m *= Tuning.KO_INCOMING_MULT;
        return m;
    }

    /** Ko's melee multiplier (1 + 2 x Ten's bonus): what Jajanken's Rock uses while all the aura is in the fist. */
    public static float koMeleeMult(int tenLevel) {
        return 1f + Tuning.tenBonus(tenLevel) * Tuning.KO_DAMAGE_SHARE;
    }
}
