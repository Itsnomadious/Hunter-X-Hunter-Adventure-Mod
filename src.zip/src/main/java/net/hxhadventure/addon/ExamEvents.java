package net.hxhadventure.addon;

import net.hxhadventure.HxHAdventure;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Registers the attributes of the Hunter Exam NPCs and test takers, and the guide's spawn egg. */
@Mod.EventBusSubscriber(modid = HxHAdventure.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ExamEvents {
    private ExamEvents() {}

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(HxHEntities.EXAM_RECEPTIONIST.get(), ExamNpcEntity.createAttributes().build());
        e.put(HxHEntities.MENCHI.get(), ExamNpcEntity.createAttributes().build());
        e.put(HxHEntities.SATOTZ.get(), ExamNpcEntity.createAttributes().build());
        e.put(HxHEntities.EXAM_GUIDE.get(), ExamNpcEntity.createAttributes().build());
        e.put(HxHEntities.EXAM_TAKER.get(), ExamTakerEntity.createAttributes().build());
        e.put(HxHEntities.EXAM_NEN_TAKER.get(), NenFighter.createAttributes(ExamNenTakerEntity.STATS).build());
    }

    @SubscribeEvent
    public static void creativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) e.accept(HxHEntities.EXAM_GUIDE_SPAWN_EGG.get());
    }
}
