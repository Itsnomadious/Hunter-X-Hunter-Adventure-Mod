package net.hxhadventure.addon;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.abilities.Combat;

/**
 * Losing the Nen for good: the player goes back to being a fresh player. Nen is locked (no kit, no Nen type), the Hatsu level and
 * experience are 1 / 0, every Nen skill is Level 1 with no progress, and Kite's quest starts again, so the Nen has to be
 * awakened all over again (Kite's quest, Water Divination, Hatsu roll).
 *
 * Today the only cause is Gon's vow reaching {@link GonVow#NEN_LOSS_DEBT} Nen debt ({@link GonVow}), but this is a general
 * "forget everything" and can be called from anywhere (it must run on the server thread).
 */
public final class NenLoss {
    private NenLoss() {}

    /**
     * The nodes are closed (e.g. "/hxh set nentype none"): Nen is locked again and the Nen type is cleared, so Kite has to open the
     * nodes again, which rolls a brand new Nen type that Water Divination has to reveal. Levels and skill progress are kept.
     */
    public static void closeNodes(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        NenAddonData d = NenAddonData.get(sp);

        Vows.clearAll(sp); // no Nen, no Conditions, Limitations or Vows
        Jajanken.clear(sp);
        Guanyin.clear(sp);
        ChainManager.clear(sp);
        ChainManager.clearCooldowns(sp);
        DoctorBlythe.clear(sp);
        Terpsichora.clear(sp);
        ExplosiveOrbs.clear(sp);
        DragonHead.clear(sp);
        BungeeGum.clear(sp);
        NenStitches.clear(sp);
        Blinky.clear(sp);
        SmokeManipulation.clear(sp);
        CrazySlots.clear(sp);
        LittleFlower.release(sp);
        LaplaceDevil.clear(sp);
        if (HideAndSeek.canUse(Combat.get(sp))) HideAndSeek.onLost(sp);
        HideAndSeek.clear(sp);
        LightningAura.clear(sp);
        PainPacker.clear(sp);
        MagicalEsthetician.clear(sp);
        RipperCyclotron.clear(sp);
        BigBangImpact.clear(sp);
        PaperManipulation.clear(sp);
        Hakoware.clear(sp);
        GumCards.clear(sp);
        SkillHunter.clear(sp);
        BlackVoice.clear(sp);

        if (c != null) {
            if (c.isTenActive()) AbilityRegistry.toggleTen(sp, false);
            if (c.isAuraActive()) AbilityRegistry.toggleRen(sp, false);
            c.setTenActive(false);
        }
        d.closeNodes(sp);

        if (c != null) {
            c.setKit(0);
            c.setNenType(0);
            c.updatePlayerMaxHealth();
        }

        CompoundTag pd = sp.getPersistentData();
        pd.remove("HxHCraft_HatsuAbility");      // the Hatsu belongs to the old type
        pd.remove("HxHCraft_LastRespinLevel");
        pd.putBoolean("HxHCraft_NenUnlocked", false);
        pd.putBoolean("HxHCraft_NenQuestAccepted", false);
        pd.putInt("HxHCraft_BrokenWoodCount", 0);
        NenProfile.setTypeRevealed(sp, false);
        NenProfile.sync(sp);

        if (c != null) {
            float over = c.getCurrentEnergy();
            if (over > 0) c.consumeEnergy(over);
        }

        sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.8f, 0.6f);
        sp.displayClientMessage(Component.literal("§4Your nodes have closed"), true);
        sp.sendSystemMessage(Component.literal("§cYour aura nodes have closed. Find Kite to awaken your Nen again; you will receive a new Nen type."));
    }

    /**
     * "/hxh set nentype none": a completely fresh character. Every restriction (Condition, Limitation, Vow, Forced Zetsu) is removed,
     * gratitude (prayers) is 0, every Nen skill and the Hatsu level are back to 1, lifespan is full again, and the rolled aura colour,
     * talent and Nen type are all forgotten, so speaking to Kite and awakening again rolls a brand new colour, talent and Nen type.
     */
    public static void resetCharacter(ServerPlayer sp) {
        Vows.removeAllRestrictions(sp);   // rules gone, and everything they had set going (forced Zetsu, prayers, Ko, locks) stopped
        HatsuEffects.remove(sp);
        wipeState(sp);

        NenAddonData d = NenAddonData.get(sp);
        d.prayers = 0;                    // gratitude back to 0
        Prayer.forget(sp.getUUID());
        d.resetLifespan();                // a new body: full lifespan, Emperor Time ready

        // forget the awakening roll: colour, talent (the Nen type was cleared by wipeState), so all three are rolled again
        CompoundTag pd = sp.getPersistentData();
        pd.remove("HxHCraft_PermanentAuraColor");
        pd.remove("HxHCraft_HinaReadyAt");
        NenProfile.clearTalent(sp);
        NenProfile.setTypeRevealed(sp, false);
        d.markSync();
        d.save();
        AbilityRegistry.syncAuraColor(sp);
        NenProfile.sync(sp);

        sp.level().playSound(null, sp.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.8f, 0.6f);
        sp.displayClientMessage(Component.literal("\u00a74Your Nen has been reset"), true);
        sp.sendSystemMessage(Component.literal("\u00a7cYour Nen has been reset completely. Find Kite to awaken it again: your aura colour, talent and Nen type will all be rolled anew."));
    }

    /**
     * Reborn as a Chimera Ant (Crazy Slots' staff): a fresh, unawakened player. Nen is locked again with every skill and the Hatsu level at 1
     * (as in {@link #wipe}), without the Nen-debt message. The aura colour and talent are kept; the Nen type is rolled anew at the awakening.
     */
    public static void rebirth(ServerPlayer sp) {
        wipeState(sp);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.PLAYERS, 0.5f, 1.6f);
    }

    public static void wipe(ServerPlayer sp) {
        wipeState(sp);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.WITHER_DEATH, SoundSource.PLAYERS, 0.8f, 0.6f);
        sp.displayClientMessage(Component.literal("§4Your Nen is gone"), true);
        sp.sendSystemMessage(Component.literal("§4Your Nen debt was too much. Your Nen is gone: you are a fresh player again, with every Nen skill and level at 1. "
            + "Find Kite to awaken it again."));
    }

    /** Everything wipe and resetCharacter share: no kit or type, Level 1 everywhere, the awakening quest starts again. Silent. */
    private static void wipeState(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        NenAddonData d = NenAddonData.get(sp);

        Vows.clearAll(sp); // no Nen, no Conditions, Limitations or Vows
        // anything the Hatsu has out in the world or holds on to (the same clean-up a death does)
        Jajanken.clear(sp);
        Guanyin.clear(sp);
        ChainManager.clear(sp);
        ChainManager.clearCooldowns(sp);
        DoctorBlythe.clear(sp);
        Terpsichora.clear(sp);
        ExplosiveOrbs.clear(sp);
        DragonHead.clear(sp);
        BungeeGum.clear(sp);
        NenStitches.clear(sp);
        Blinky.clear(sp);
        SmokeManipulation.clear(sp);
        CrazySlots.clear(sp);
        LittleFlower.release(sp);
        LaplaceDevil.clear(sp);
        if (HideAndSeek.canUse(Combat.get(sp))) HideAndSeek.onLost(sp);
        HideAndSeek.clear(sp);
        MagicalEsthetician.clear(sp);
        LightningAura.clear(sp);
        PainPacker.clear(sp);
        RipperCyclotron.clear(sp);
        BigBangImpact.clear(sp);
        PaperManipulation.clear(sp);
        Hakoware.clear(sp);
        GumCards.clear(sp);
        SkillHunter.clear(sp);
        BlackVoice.clear(sp);

        if (c != null) {
            // Ten and Ren off while the player still counts as a Nen user, so their modifiers and aura entities are removed properly
            if (c.isTenActive()) AbilityRegistry.toggleTen(sp, false);
            if (c.isAuraActive()) AbilityRegistry.toggleRen(sp, false);
            c.setTenActive(false);
        }
        d.wipeForNenLoss(sp);

        if (c != null) {
            c.setKit(0);          // no kit = Nen locked (hasNenUnlocked is kit >= 1); also resets aura flags and tells the client
            c.setNenType(0);      // Water Divination has to be done again; also locks Nen and tells the client
            c.setHatsuLevel(1);   // also clears the respin record
            c.setHatsuExp(0);
            c.updatePlayerMaxHealth();
        }

        // the awakening quest, the Hatsu roll and the saved copies of all of it
        CompoundTag pd = sp.getPersistentData();
        pd.putInt("HatsuLevel", 1);
        pd.putInt("HatsuExp", 0);
        pd.remove("HxHCraft_HatsuExpFrac");
        pd.remove("HxHCraft_HatsuAbility");
        pd.remove("HxHCraft_LastRespinLevel");
        pd.putBoolean("HxHCraft_NenUnlocked", false);
        pd.putBoolean("HxHCraft_NenQuestAccepted", false);
        pd.putInt("HxHCraft_BrokenWoodCount", 0);

        if (c != null) { // a Level 1 tank is smaller: the energy that was in the big one does not carry over
            float over = c.getCurrentEnergy() - c.getMaxEnergy();
            if (over > 0) c.consumeEnergy(over);
        }

    }
}
