package net.hxhadventure.addon;

/**
 * Satotz's questionnaire (the first test of the Hunter Exam). Only the questions live here; the answer key stays on the server (see HunterExam).
 * Question 10 is not multiple choice: it is the water-pouring minigame (see WaterPuzzle).
 */
public final class ExamQuestions {
    public static final class Q {
        public final String category;
        public final String prompt;
        public final String[] options;

        Q(String category, String prompt, String... options) {
            this.category = category;
            this.prompt = prompt;
            this.options = options;
        }
    }

    public static final int COUNT = 10;
    /** Index of the water puzzle (question 10). */
    public static final int PUZZLE = 9;

    public static final String PUZZLE_HELP =
        "Click a container to select it. Click a second container to pour the first one into it. "
            + "Use Fill and Empty on the selected container. Submit your answer when you are ready.";

    public static final Q[] ALL = {
        new Q("Geography",
            "Which of the following environments would generally pose the greatest challenge to a traveller without proper preparation?",
            "A temperate forest", "A tropical rainforest", "A frozen mountain range", "A coastal grassland"),
        new Q("Wildlife",
            "You encounter an unfamiliar animal in the wilderness. It appears injured but has not approached you. What is the most sensible course of action?",
            "Approach slowly and attempt to help it.", "Keep your distance and observe its behaviour.",
            "Attempt to scare it away immediately.", "Capture it before it can become a threat."),
        new Q("International Affairs",
            "What is the primary purpose of the V5?",
            "To regulate international trade between all nations.", "To govern and coordinate the five major world powers.",
            "To oversee the Hunter Association.", "To maintain the world's criminal justice system."),
        new Q("Survival",
            "You are stranded in an unfamiliar wilderness with limited supplies. Which should generally be your first priority?",
            "Finding food.", "Establishing shelter and assessing immediate dangers.",
            "Travelling in a random direction until you find civilisation.", "Hunting local wildlife."),
        new Q("The Hunter Association",
            "Which statement best describes the general purpose of a Hunter Licence?",
            "It grants unrestricted authority over any country's laws.",
            "It identifies its holder as a licensed Hunter and grants access to various privileges.",
            "It grants automatic citizenship in every country.", "It allows its holder to command local military forces."),
        new Q("Criminal Investigation",
            "You discover evidence of illegal activity in an unfamiliar town. The suspected criminals appear well-connected and potentially dangerous. What should you do?",
            "Confront them immediately.", "Publicly accuse them to attract attention.",
            "Gather reliable information before deciding how to proceed.", "Abandon the investigation without considering the evidence."),
        new Q("Economics",
            "Why might an ordinary-looking object be worth an extraordinary amount of money?",
            "Its physical size determines its value.", "It may possess historical, cultural, artistic, or scientific significance.",
            "Its age automatically makes it valuable.", "Its value is determined exclusively by its material composition."),
        new Q("Exploration",
            "You are leading an expedition into an uncharted region. One member of your team becomes separated during poor weather. What is the most responsible response?",
            "Continue the expedition and assume they will catch up.", "Split the remaining team into smaller groups to search independently.",
            "Establish a safe position, assess the situation, and organise a coordinated search.",
            "Abandon all equipment and immediately run in the direction they disappeared."),
        new Q("Ethics and Judgement",
            "You are offered a substantial financial reward to retrieve an item from a location that is known to be protected by local inhabitants. What should be your first consideration?",
            "Whether the reward justifies the risk.", "Whether you can retrieve the item without being detected.",
            "The legitimacy of the request and the rights of those inhabiting the area.", "Whether another Hunter has already accepted the job."),
        new Q("Practical Reasoning",
            "You have three containers. One holds 8 litres, another holds 5 litres, and the last holds 3 litres. None has measurement markings. "
                + "You have an unlimited supply of water. Measure exactly 4 litres using only these containers."),
    };

    private ExamQuestions() {}
}
