package net.hxhadventure.addon;

/** Numbers for Kite's Crazy Slots (Hatsu kit 29, Conjurers). Change them here. */
public final class CrazySlotsTuning {
    private CrazySlotsTuning() {}

    // ---- unlocks ----
    /** Hatsu level needed to summon the clown (H) and roll (Z). */
    public static final int MIN_LEVEL = 10;

    // ---- the clown (H) ----
    /** Aura paid to summon the clown (sending it away again is free). */
    public static final float CLOWN_COST = 40f;
    /** Aura paid for each roll of the roulette. */
    public static final float ROLL_COST = 60f;
    public static final int TOGGLE_COOLDOWN_TICKS = 20;
    /** Height of the clown in blocks. A.P.R. starts at 0.5 and grows to 5.4: Crazy Slots is a bit bigger than the A.P.R. you meet first, but small enough to float at your shoulder. */
    public static final float CLOWN_HEIGHT = 0.8f;
    /**
     * Where the clown hovers: beside the user, above their right shoulder. Blocks to the user's right of their body (0 = over the middle),
     * blocks ahead of the shoulder line (negative = behind), and how high its feet float above the shoulder line.
     */
    public static final double CLOWN_SIDE = 0.8;
    public static final double CLOWN_FORWARD = 0.0;
    public static final double CLOWN_RAISE = 0.1;
    /**
     * The clown does not sit still: it wanders slowly around the spot above. How far (blocks) it drifts to the side, forwards/backwards and
     * up/down on top of the small bob. 0 = pinned to the shoulder again. The drift is slow and smooth (a few seconds per loop).
     */
    public static final double CLOWN_DRIFT_SIDE = 0.3;
    public static final double CLOWN_DRIFT_FORWARD = 0.35;
    public static final double CLOWN_DRIFT_UP = 0.15;
    /** After a conjured weapon has been used up or put away, the clown cannot be summoned again for this long (ticks). */
    public static final int AFTER_USE_COOLDOWN_TICKS = 20; // 1 second

    // ---- the roulette (Z) ----
    /** The wheel spins this long (ticks) and then shows the number for {@link #LAND_TICKS} before the clown turns into the weapon. */
    public static final int ROLL_TICKS = 40;
    public static final int LAND_TICKS = 24;
    /**
     * Numbers 1-9 are on the wheel but only the weapons that exist (2 Scythe, 3 Staff, 4 Carbine) are drawn.
     * true = the wheel really stops on any of the 9 numbers, and a number with no weapon yet is a dud (the clown just leaves).
     * Add a weapon for a number in {@link CrazySlots.Weapon} and it is drawn automatically.
     */
    public static final boolean UNASSIGNED_SLOTS_ARE_DUDS = false;

    // ---- 2: Scythe, Silent Waltz (Z with the scythe in hand) ----
    /** The blade grows for this long, then Kite spins once with it for {@link #WALTZ_SPIN_TICKS}; the slash goes off at the end of the spin. */
    public static final int WALTZ_ENLARGE_TICKS = 30;
    public static final int WALTZ_SPIN_TICKS = 6;
    /** The slash is one flat circle at the height of the blade: it reaches this far in every direction (blocks) and cuts creatures AND blocks at that height. */
    public static final double WALTZ_RADIUS = 22.5; // 15 x 1.5
    /**
     * The height of the blade, in blocks above the user's feet: roughly chest (bottom) to shoulder (top). Only creatures that reach into this
     * band are cut, and only the block rows that fill at least half of it are destroyed: nothing below or above is touched.
     */
    public static final double WALTZ_BLADE_BOTTOM = 0.9;
    public static final double WALTZ_BLADE_TOP = 1.7;
    /** Damage to every creature the circle touches (the slash bisects: it ignores armour when {@link #WALTZ_IGNORES_ARMOUR}), plus per Hatsu level. */
    public static final float WALTZ_DAMAGE = 400f;
    public static final float WALTZ_DAMAGE_PER_LEVEL = 4f;
    public static final boolean WALTZ_IGNORES_ARMOUR = true;
    /** Blocks are removed from the centre outwards over this many ticks, at most {@link #WALTZ_BLOCKS_PER_TICK} each tick (keeps the server smooth). */
    public static final int WALTZ_WAVE_TICKS = 12;
    public static final int WALTZ_BLOCKS_PER_TICK = 700;
    /** Chests, furnaces and the like would lose what is inside them. false = the slash leaves them standing. */
    public static final boolean WALTZ_CUTS_BLOCK_ENTITIES = false;
    /** The floor stays, so no fall to soften any more. 0 = none. */
    public static final int WALTZ_SLOW_FALL_TICKS = 0;
    /** Projectiles (arrows, fireballs...) inside the circle are cut down as well. */
    public static final boolean WALTZ_CUTS_PROJECTILES = true;

    /** Attack, Strong attack and Barrage deal this many times the damage while the scythe is in hand (stacks with the Chimera Ant bonus). */
    public static final float SCYTHE_ATTACK_MULT = 1.3f;

    // ---- 3: Staff, sweep (Z with the staff in hand; the staff stays until the user puts it away with H) ----
    /** Ticks from pressing Z to the hit (the sweep comes out fast). */
    public static final int SWEEP_WINDUP_TICKS = 2;
    public static final int SWEEP_COOLDOWN_TICKS = 40; // 2 seconds
    /** How far the sweep reaches (blocks) and how wide the arc in front of the user is (degrees). */
    public static final double SWEEP_RANGE = 3.5;
    public static final double SWEEP_ARC_DEGREES = 140.0;
    /** The basic Attack's base damage (Combat.executeSinglePunch: 3.0, times Spirit), and the sweep's multiple of it (1.5 = 50% more). */
    public static final float SWEEP_ATTACK_BASE_DAMAGE = 3.0f;
    public static final float SWEEP_DAMAGE_MULT = 1.5f;
    public static final double SWEEP_KNOCKBACK = 0.6;

    // ---- 4: Carbine (hold right-click to fire; no burst; stays until the magazine is empty or the user puts it away with H) ----
    /** true = the carbine holds {@link #CARBINE_MAGAZINE} rounds and is gone when they are used up. false = it never runs dry. */
    public static final boolean CARBINE_USES_AMMO = true;
    public static final int CARBINE_MAGAZINE = 80;
    /** Ticks between shots while firing (2 = 10 shots a second). */
    public static final int CARBINE_FIRE_INTERVAL_TICKS = 2;
    public static final float CARBINE_DAMAGE = 2.45f;            // 30% less than 3.5
    public static final float CARBINE_DAMAGE_PER_LEVEL = 0.035f; // 30% less than 0.05
    public static final double CARBINE_RANGE = 64.0;
    /** Random spread of each bullet (a gaussian offset on each axis of the aim, so about 2 degrees at 0.035). */
    public static final double CARBINE_SPREAD = 0.035;
    /** Sustained fire blooms: every shot in a row adds this much spread, up to the maximum extra; it settles again after a short pause. */
    public static final double CARBINE_SPREAD_BLOOM_PER_SHOT = 0.004;
    public static final double CARBINE_SPREAD_BLOOM_MAX = 0.05;
    public static final int CARBINE_BLOOM_RESET_TICKS = 10;
    /** Damage falls off with distance: full damage point blank, down to (1 - this) at {@link #CARBINE_FALLOFF_RANGE} blocks and beyond, in a straight line between. */
    public static final double CARBINE_FALLOFF_MAX = 0.90;
    public static final double CARBINE_FALLOFF_RANGE = 50.0;

    /** Multiplier on a carbine bullet's damage for the distance it travelled: 1.0 at 0 blocks, 0.10 (90% less) at 50 blocks and beyond. */
    public static float carbineFalloff(double distance) {
        double f = Math.max(0.0, Math.min(1.0, distance / CARBINE_FALLOFF_RANGE));
        return (float) (1.0 - CARBINE_FALLOFF_MAX * f);
    }
    /** The carbine is suppressed: shots are only a faint hiss. */
    public static final float CARBINE_SOUND_VOLUME = 0.12f;

    // ---- the staff's curse: being killed by Neferpitou while holding it ----
    /** Entity tags a Chimera Ant player gets (the NPC Neferpitou carries the first one, too). */
    public static final String CHIMERA_TAG = "chimera_ant";
    public static final String CHIMERA_TAG_2 = "neferpitou";
    /** Base maximum health of a Chimera Ant (the Hatsu level bonus is added on top, as for everyone). */
    public static final double CHIMERA_BASE_HEALTH = 40.0;
    /** Attack, Strong attack and Barrage deal this many times the damage, for good. */
    public static final float CHIMERA_ATTACK_MULT = 2.0f;
    /** The rebirth only happens when the one who killed the user is Neferpitou, and she must be at least this many times the user's level (a much stronger target). */
    public static final float CHIMERA_KILLER_MIN_LEVEL_RATIO = 3.0f;

    // ---- Kite (the Kite NPC) fights with Crazy Slots ----
    /** He fights as a Hatsu level this high (set in KiteTuning): carbine damage = CARBINE_DAMAGE + this x CARBINE_DAMAGE_PER_LEVEL. */
    public static final int KITE_HATSU_LEVEL = KiteTuning.HATSU_LEVEL;
    /** Carbine: he opens fire beyond this distance and switches to the scythe once the target is closer than {@link #KITE_SCYTHE_DISTANCE}. */
    public static final double KITE_CARBINE_DISTANCE = 6.5;
    public static final double KITE_SCYTHE_DISTANCE = 4.0;
    /** Rounds in a burst, and the pause between bursts (ticks); the carbine is never short of bullets for him. */
    public static final int KITE_BURST_SHOTS = 12;
    public static final int KITE_BURST_PAUSE_TICKS = 16;
    public static final int KITE_SWITCH_LOCK_TICKS = 20;      // at least this long between changing weapons
    public static final double KITE_REACH = 2.6;               // melee reach (blocks to the edge of the target)
    public static final int KITE_MELEE_GAP_TICKS = 10;
    public static final double KITE_FIRE_RANGE = 48.0;         // he does not shoot at targets further away than this
}
