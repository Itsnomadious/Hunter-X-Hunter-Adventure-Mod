package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import net.hxhadventure.abilities.AbilityRegistry;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketBvAuto;
import net.hxhadventure.addon.network.PacketDisguise;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Shalnark's Black Voice (Hatsu kit 23, Manipulators). Built on the same pattern as Skill Hunter's Black Voice page
 * (an antenna in a creature, tracked by UUID, ticked on the server) but it is a Hatsu of its own with a held phone.
 *
 * <ol>
 *   <li>Shalnark's phone is a crafted item (iron ingot, glass pane, iron ingot in a column). Hold it to use Black Voice; <b>H</b> only reminds you of that.</li>
 *   <li><b>Right-click</b> a creature while holding the phone: an antenna goes into it and it becomes your ally. Allied
 *       mobs follow you and fight your enemies, and nobody hurts anybody in the circle. Sneak + right-click on one of
 *       yours pulls its antenna out.</li>
 *   <li><b>Shift + Z</b> while holding the phone: you swap places with an antenna'd creature (the one you are looking at,
 *       otherwise the nearest). A clone of your own body is left where you stood: it stands still, but it can be hit (the damage
 *       is yours and snaps you back). You appear where the creature was, drawn as the creature (the Convert Hands disguise), and the
 *       real creature turns invisible and intangible and rides along under you until you are back. You move and fight with your own
 *       controls. A plain creature's attack replaces your punch and you have no Nen (Ten, Ren, every Hatsu and every Nen key are shut off).
 *       A Nen NPC (Chrollo, Hisoka, Gon, Neferpitou) gives you its Level, skill levels, Nen type, Hatsu kit, aura pool, max health, knockback resistance and attack damage instead,
 *       and Z, H and your own punches work as theirs.</li>
 *   <li><b>Shift+H</b> while in a body returns you to your own. So does energy running out, the clone being hit, going too far from it,
 *       or the borrowed creature dying.</li>
 *   <li><b>Auto Pilot</b> (second skill, in the Z list): <b>hold Z</b> to put a needle in yourself. For 30 seconds your Ten and Ren
 *       are doubled and you are driven by an NPC brain: no input of yours counts, it walks at the nearest creature and uses Attack on everything around you,
 *       and you stay in Ren the whole time.</li>
 * </ol>
 * While you wear a body your hitbox and eye height become the creature's (so the camera and the way you fit through gaps match what you look like),
 * and if a hit would kill you in it, the creature dies instead and you are back in your own body. A Skill Hunter whose Black Voice page is active uses
 * the very same antennas and body swap (no phone: Z on the page plants an antenna, Shift+Z takes the body).
 * Only mobs can be worn: a player with an antenna is an ally only.
 * Forge hooks live in {@link BlackVoiceEvents}; Auto Pilot's input lock is in {@code client.BlackVoiceClient}.
 */
public final class BlackVoice {
    private BlackVoice() {}

    public static final int KIT = 23;

    // ---------------- state ----------------
    private static final class Antenna {
        long expiry;

        Antenna(long expiry) {
            this.expiry = expiry;
        }
    }

    private static final class State {
        final LinkedHashMap<UUID, Antenna> antennas = new LinkedHashMap<>(); // implant order, oldest first
        int cooldown;
        int lastUse = -100;

        // the body being worn, if any (the clone swap): the creature, and the still clone of your own body left behind
        UUID possessed;
        UUID clone;
        boolean oldNoAi, oldNoGravity, oldInvisible, oldInvulnerable, oldNoPhysics, oldSilent;
        // a body with Nen of its own (Chrollo, Hisoka, Gon, Neferpitou): its Level, Nen type, kit and skills are worn too
        boolean nenBody;
        int savedKit, savedNenType, savedHatsu;
        float savedEnergy, savedHealth;
        int attackCd;
        long startedAt;

        // Auto Pilot: needleStart = player tick when the Z hold began (-1 = no), autoLeft = ticks of control left (0 = off)
        int needleStart = -1;
        int autoLeft;
        int autoCooldown;
        int autoAttackCd;
        UUID autoTarget;
        float autoYaw, autoPitch;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();   // player uuid -> state
    private static final Map<UUID, UUID> OWNER = new HashMap<>();      // antenna'd uuid -> owner uuid
    private static final Map<UUID, UUID> POSSESSED = new HashMap<>();  // body uuid -> the player inside it
    /** Players whose Z key is down right now, as last reported by the client. */
    private static final Set<UUID> Z_DOWN = ConcurrentHashMap.newKeySet();
    /** True only while Auto Pilot runs its own Attack, so interceptUse lets that one through. */
    private static volatile boolean AI_EXEC;

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    /** A Skill Hunter whose Black Voice page is active borrows this Hatsu: the same antennas and body swap, no phone needed. */
    private static boolean hunterBorrow(Player p, Combat c) {
        return c != null && p != null && SkillHunter.blackVoicePageActive(p, c);
    }

    private static boolean usable(Player p, Combat c) {
        return canUse(c) || hunterBorrow(p, c);
    }

    private static State state(ServerPlayer sp) {
        return STATES.computeIfAbsent(sp.getUUID(), k -> new State());
    }

    /** The owner's UUID if this creature carries an antenna, else null. */
    public static UUID controllerOf(UUID entity) {
        return entity == null ? null : OWNER.get(entity);
    }

    /** True for an antenna'd creature (anyone's). */
    public static boolean isAntenna(Entity e) {
        return e != null && OWNER.containsKey(e.getUUID());
    }

    /** True while this player's mind is inside another body (server side). */
    public static boolean isPossessing(Entity e) {
        if (e == null) return false;
        State s = STATES.get(e.getUUID());
        return s != null && s.possessed != null;
    }

    /** True while the player wears a body that has no Nen of its own (a cow, a villager...): no Nen at all. */
    public static boolean isNenlessBody(Entity e) {
        if (e == null) return false;
        State s = STATES.get(e.getUUID());
        return s != null && s.possessed != null && !s.nenBody;
    }

    /** True while the player wears another body or a needle drives them: their own hands cannot use items or blocks (a Nen body leaves the hands free). */
    public static boolean isHandsLocked(Entity e) {
        return isNenlessBody(e) || isAutoPilot(e);
    }

    /** Shift+H (the Hatsu key) inside a borrowed body: back to your own. Returns true when it did. */
    public static boolean returnKey(ServerPlayer sp) {
        State s = STATES.get(sp.getUUID());
        if (s == null || s.possessed == null || !sp.isShiftKeyDown()) return false;
        endPossession(sp, s, "\u00a75Black Voice: you are back in your own body");
        return true;
    }

    /** Owner and antenna'd, or two antenna'd of the same owner: allies. Used by AllianceUtils. */
    public static boolean areAllies(Entity a, Entity b) {
        if (a == null || b == null) return false;
        UUID ua = a.getUUID(), ub = b.getUUID();
        UUID oa = OWNER.get(ua), ob = OWNER.get(ub);
        if (oa != null && oa.equals(ub)) return true;
        if (ob != null && ob.equals(ua)) return true;
        return oa != null && oa.equals(ob);
    }

    private static boolean takenByOther(Entity e) {
        return OWNER.containsKey(e.getUUID()) || IllumiNeedles.isControlled(e) || Puppeteer.isPuppet(e)
            || SkillHunter.controllerOf(e.getUUID()) != null;
    }

    private static void say(ServerPlayer sp, String msg) {
        sp.displayClientMessage(Component.literal(msg), true);
    }

    private static void sound(ServerPlayer sp, SoundEvent ev, float vol, float pitch) {
        sp.level().playSound(null, sp.blockPosition(), ev, SoundSource.PLAYERS, vol, pitch);
    }

    private static Entity find(MinecraftServer server, UUID id) {
        for (ServerLevel lvl : server.getAllLevels()) {
            Entity e = lvl.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    private static boolean gate(ServerPlayer sp, Combat c, int minLevel, String what) {
        if (c == null || !sp.isAlive()) return false;
        if (!usable(sp, c)) {
            say(sp, "§cYour Hatsu is not Black Voice");
            return false;
        }
        if (c.getHatsuLevel() < minLevel) {
            say(sp, "§c" + what + " unlocks at Level " + minLevel);
            return false;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            say(sp, "§5Forced Zetsu: Black Voice cannot be used");
            return false;
        }
        return true;
    }

    // ================= the phone =================
    /** Shalnark's phone is a crafted item (a glass pane and two iron ingots): any phone works for whoever holds it. */
    public static boolean isPhone(ItemStack st) {
        return !st.isEmpty() && BlackVoiceItems.PHONE != null && st.is(BlackVoiceItems.PHONE);
    }

    public static boolean holdingPhone(Player p) {
        return isPhone(p.getMainHandItem()) || isPhone(p.getOffhandItem());
    }

    /** The Hatsu key (H): nothing is conjured any more, it only says how Black Voice is used. */
    public static void togglePhone(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        State s = STATES.get(sp.getUUID());
        if (s != null && s.possessed != null) {
            say(sp, "§cYou are inside another body. Shift+H to come back");
            return;
        }
        if (!gate(sp, c, BlackVoiceTuning.IMPLANT_MIN_LEVEL, "Black Voice")) return;
        if (holdingPhone(sp)) {
            say(sp, "§5Black Voice: §7right-click someone to plant an antenna, Shift+Z to take them over");
        } else {
            say(sp, "§cLacking Phone");
        }
    }

    // ================= the antenna =================
    /** Right-click on an entity (server). Returns true if the click was used and the event should be cancelled. */
    public static boolean handleRightClick(ServerPlayer sp, Entity target) {
        if (target == null || !holdingPhone(sp)) return false;
        State s = STATES.get(sp.getUUID());
        if (s != null && s.possessed != null) return true; // a hand that is not yours cannot reach for a phone
        Combat c = Combat.get(sp);
        if (!canUse(c)) {
            if (target instanceof LivingEntity && sp.tickCount % 10 == 0) say(sp, "\u00a7cYour Hatsu is not Black Voice");
            return false;
        }

        // sneak + right-click on one of yours: pull its antenna out
        if (sp.isShiftKeyDown() && s != null && s.antennas.containsKey(target.getUUID())) {
            removeAntenna(sp.server, target.getUUID());
            sound(sp, SoundEvents.CHAIN_BREAK, 0.7f, 1.4f);
            say(sp, "§7Antenna removed §8(" + s.antennas.size() + " left)");
            return true;
        }
        return tryPlant(sp, c, target, true);
    }

    /** A Skill Hunter's Black Voice page (Z on it): plants an antenna in whatever the hunter is looking at, exactly like the phone does. */
    public static void hunterImplant(ServerPlayer sp, Combat c) {
        if (c == null || !hunterBorrow(sp, c)) return;
        Entity looked = ChainManager.rayEntity(sp, 12.0, e -> e instanceof LivingEntity le && le != sp && le.isAlive());
        if (looked == null) {
            say(sp, "§cBlack Voice needs a creature to plant the antenna in");
            return;
        }
        State s = STATES.get(sp.getUUID());
        if (s != null && s.possessed != null) {
            say(sp, "§cYou are inside another body. Shift+H to come back");
            return;
        }
        if (sp.isShiftKeyDown() && s != null && s.antennas.containsKey(looked.getUUID())) {
            removeAntenna(sp.server, looked.getUUID());
            sound(sp, SoundEvents.CHAIN_BREAK, 0.7f, 1.4f);
            say(sp, "§7Antenna removed §8(" + s.antennas.size() + " left)");
            return;
        }
        tryPlant(sp, c, looked, false);
    }

    private static boolean tryPlant(ServerPlayer sp, Combat c, Entity target, boolean fromPhone) {
        State s = STATES.get(sp.getUUID());
        if (!(target instanceof LivingEntity le) || target instanceof ArmorStand || !le.isAlive() || target == sp) return false;
        if (!gate(sp, c, BlackVoiceTuning.IMPLANT_MIN_LEVEL, "Black Voice")) return true;
        if (takenByOther(target)) {
            say(sp, "§cAlready controlled");
            return true;
        }
        if (target.getType().is(Tags.EntityTypes.BOSSES)) {
            say(sp, "§cA boss's will is too strong for the antenna");
            return true;
        }
        if (target instanceof Player tp && (tp.isCreative() || tp.isSpectator())) {
            say(sp, "§cThe antenna will not take");
            return true;
        }
        s = state(sp);
        if (ChainManager.onCooldown(sp, "Black Voice", s.cooldown)) return true;
        if (BlackVoiceTuning.NEEDLE_REQUIRED && !sp.isCreative() && findNeedle(sp) == null) {
            say(sp, "§cYou need a Black Voice needle (craft one from an iron ingot)");
            return true;
        }
        if (c.getCurrentEnergy() < BlackVoiceTuning.IMPLANT_COST) {
            say(sp, "§cNot enough energy (" + (int) BlackVoiceTuning.IMPLANT_COST + " needed)");
            return true;
        }
        c.consumeEnergy(BlackVoiceTuning.IMPLANT_COST);
        if (resists(c, le)) {
            // a stronger Nen user shrugs it off: the needle is not wasted, the Nen is
            s.cooldown = BlackVoiceTuning.IMPLANT_COOLDOWN_TICKS;
            ChainManager.startCooldown(sp, "Black Voice", BlackVoiceTuning.IMPLANT_COOLDOWN_TICKS);
            sp.swing(InteractionHand.MAIN_HAND, true);
            sound(sp, SoundEvents.CHAIN_BREAK, 0.8f, 1.6f);
            say(sp, "§c" + le.getName().getString() + " resisted the needle §8(wound it first, or be the stronger Nen user)");
            if (le instanceof ServerPlayer tp) tp.sendSystemMessage(Component.literal("§7You shrugged off a needle."));
            return true;
        }
        if (!sp.isCreative()) {
            ItemStack ns = findNeedle(sp);
            if (ns != null) ns.shrink(1);
        }

        int max = Math.min(BlackVoiceTuning.MAX_ANTENNAS, 1 + c.getHatsuLevel() / BlackVoiceTuning.LEVELS_PER_ANTENNA);
        while (s.antennas.size() >= max) {
            UUID oldest = s.antennas.keySet().iterator().next();
            removeAntenna(sp.server, oldest); // the oldest one dissolves to make room
        }
        implant(sp, s, le);
        return true;
    }

    /** The Nen level of a target (its Hatsu level), or -1 if it has no Nen at all. */
    private static int nenLevelOf(LivingEntity t) {
        if (t instanceof Player tp) {
            Combat tc = Combat.get(tp);
            return tc != null && tc.hasNenUnlocked() ? tc.getHatsuLevel() : -1;
        }
        NenBody nb = nenBodyOf(t);
        if (nb != null) return nb.hatsu();
        return -1;
    }

    /**
     * Whether the target fights the needle off. It never does if it has no Nen, if its Nen level is lower than yours,
     * or if it is at or below {@link BlackVoiceTuning#WEAK_HP_FRACTION} of its health.
     */
    private static boolean resists(Combat c, LivingEntity t) {
        if (t.getHealth() <= t.getMaxHealth() * BlackVoiceTuning.WEAK_HP_FRACTION) return false;
        int lvl = nenLevelOf(t);
        if (lvl < 0) return false;
        if (lvl < c.getHatsuLevel()) return false;
        // a stronger or equal Nen user resists only some of the time (it used to be every time, which made Nen NPCs impossible to control):
        // 25% when equal, 2% more per level they are above you, never more than 75%
        double chance = Math.min(0.75, 0.25 + (lvl - c.getHatsuLevel()) * 0.02);
        return java.util.concurrent.ThreadLocalRandom.current().nextDouble() < chance;
    }

    private static ItemStack findNeedle(ServerPlayer sp) {
        for (ItemStack st : sp.getInventory().items) {
            if (!st.isEmpty() && st.getItem() == BlackVoiceItems.NEEDLE) return st;
        }
        ItemStack off = sp.getOffhandItem();
        return !off.isEmpty() && off.getItem() == BlackVoiceItems.NEEDLE ? off : null;
    }

    private static void implant(ServerPlayer sp, State s, LivingEntity target) {
        s.cooldown = BlackVoiceTuning.IMPLANT_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, "Black Voice", BlackVoiceTuning.IMPLANT_COOLDOWN_TICKS);
        long now = sp.level().getGameTime();
        s.antennas.put(target.getUUID(), new Antenna(now + BlackVoiceTuning.ANTENNA_TICKS));
        OWNER.put(target.getUUID(), sp.getUUID());
        AddonNetwork.sendToTrackingAndSelf(new net.hxhadventure.addon.network.PacketNeedleFx(target.getId(), net.hxhadventure.addon.client.NeedleFx.NECK), target); // the needle in the back of the neck
        if (target instanceof Mob m) {
            m.setPersistenceRequired();
            m.setTarget(null);
        }
        sp.swing(InteractionHand.MAIN_HAND, true);
        sound(sp, SoundEvents.BEACON_POWER_SELECT, 1.0f, 1.8f);
        sound(sp, SoundEvents.CHAIN_PLACE, 0.8f, 1.9f);
        if (sp.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + target.getBbHeight() + 0.2, target.getZ(), 15, 0.2, 0.2, 0.2, 0.1);
        }
        if (target instanceof ServerPlayer tp) tp.sendSystemMessage(Component.literal("§5An antenna has been planted in you."));
        say(sp, "§5Black Voice: §f" + target.getName().getString() + " §5is now your ally §8(" + s.antennas.size() + ")");
    }

    /** Takes one antenna out. If you were inside that body, you are thrown back into your own. */
    public static void removeAntenna(MinecraftServer server, UUID id) {
        UUID owner = OWNER.remove(id);
        if (owner == null) return;
        State s = STATES.get(owner);
        if (s == null) return;
        s.antennas.remove(id);
        if (id.equals(s.possessed) && server != null) {
            ServerPlayer sp = server.getPlayerList().getPlayer(owner);
            if (sp != null) endPossession(sp, s, "§7The antenna is gone");
            else s.possessed = null;
        }
        if (server != null) {
            Entity e = find(server, id);
            if (e != null) AddonNetwork.sendToTrackingAndSelf(new net.hxhadventure.addon.network.PacketNeedleFx(e.getId(), 0), e);
            if (e instanceof Mob m) m.setTarget(null);
        }
    }

    // ================= taking a body (Shift+Z): the clone swap =================
    /**
     * Called from AbilityRegistryMixin for every ability the Z key runs. While Auto Pilot drives you nothing you press counts.
     * Inside a body, Z brings you home. With the phone in hand, Shift+Z takes a body. Returns true when it handled the press, so
     * the selected ability does not run. The Z key re-sends every tick for held abilities (barrage, strong attack), so only a
     * press after a gap counts as new.
     */
    public static boolean interceptUse(String id, ServerPlayer sp) {
        if (AI_EXEC) return false; // Auto Pilot's own Attack
        State s = STATES.get(sp.getUUID());
        if (s != null && s.autoLeft > 0) {
            if (sp.tickCount % 20 == 0) say(sp, "§5Auto Pilot: the needle has the controls");
            return true;
        }
        boolean inside = s != null && s.possessed != null;
        boolean toggleKey = "ten_toggle".equals(id) || "ren_toggle".equals(id);
        if (inside) {
            if (s.nenBody) return false; // the body's own Nen and Hatsu: Z runs them like anyone's
            if (sp.tickCount - s.lastUse > 20 && !id.endsWith("_release")) say(sp, "§7You have no Nen in this body. Shift+H to come back");
            s.lastUse = sp.tickCount;
            return true;
        }
        if (toggleKey || id.endsWith("_release")) return false;
        Combat c = Combat.get(sp);
        boolean phoneUse = canUse(c) && holdingPhone(sp);
        boolean hunterUse = SkillHunter.Page.BLACK_VOICE.id.equals(id) && hunterBorrow(sp, c);
        if (!(phoneUse || hunterUse) || !sp.isShiftKeyDown()) return false;
        s = state(sp);
        boolean fresh = sp.tickCount - s.lastUse > 3;
        s.lastUse = sp.tickCount;
        if (fresh) possess(sp, c, s);
        return true;
    }

    private static void possess(ServerPlayer sp, Combat c, State s) {
        if (!gate(sp, c, BlackVoiceTuning.CONTROL_MIN_LEVEL, "Taking over a body")) return;
        if (s.needleStart >= 0) {
            say(sp, "§cYou are busy with the needle");
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        LivingEntity body = pickBody(sp, s);
        if (body == null) return;
        if (c.getCurrentEnergy() < BlackVoiceTuning.POSSESS_COST) {
            say(sp, "§cNot enough energy (" + (int) BlackVoiceTuning.POSSESS_COST + " needed)");
            return;
        }

        // your own body stays behind as a clone: it stands still, but it can be hit
        SmokeCloneEntity clone = new SmokeCloneEntity(HxHEntities.SMOKE_CLONE.get(), level);
        clone.copyLook(sp);
        clone.setup(sp, c.getHatsuLevel());
        clone.makeDecoy(sp);
        clone.moveTo(sp.getX(), sp.getY(), sp.getZ(), sp.getYRot(), 0f);
        clone.setXRot(50f); // head bowed: the body left behind stands still, looking down at the phone in its hand
        clone.xRotO = 50f;
        clone.setYHeadRot(sp.getYHeadRot());
        clone.setYBodyRot(sp.yBodyRot);
        if (!level.addFreshEntity(clone)) {
            say(sp, "§cThere is no room to leave your body here");
            return;
        }
        c.consumeEnergy(BlackVoiceTuning.POSSESS_COST);

        NenBody nb = nenBodyOf(body);
        s.savedHealth = sp.getHealth();
        if (nb == null) {
            // no Nen in this body: everything of yours is shut off
            if (c.isTenActive()) AbilityRegistry.toggleTen(sp, false);
            if (c.isAuraActive()) AbilityRegistry.toggleRen(sp, false);
        } else {
            borrowNen(sp, c, s, nb);
        }
        s.possessed = body.getUUID();
        s.clone = clone.getUUID();
        POSSESSED.put(body.getUUID(), sp.getUUID());
        s.oldNoGravity = body.isNoGravity();
        s.oldInvisible = body.isInvisible();
        s.oldInvulnerable = body.isInvulnerable();
        s.oldNoPhysics = body.noPhysics;
        s.oldSilent = body.isSilent();
        // the real creature is still there but nobody can see it, touch it or hurt it; it follows you around underneath your disguise
        body.setInvisible(true);
        body.setInvulnerable(true);
        body.setSilent(true);
        body.setNoGravity(true);
        body.noPhysics = true;
        if (body instanceof Mob m) {
            s.oldNoAi = m.isNoAi();
            m.setNoAi(true);
            m.setTarget(null);
            m.getNavigation().stop();
        }
        s.attackCd = 0;
        s.startedAt = level.getGameTime();

        // swap places: you take the creature's spot, drawn as the creature (the Convert Hands disguise)
        Vec3 at = body.position();
        sp.teleportTo(level, at.x, at.y, at.z, sp.getYRot(), sp.getXRot());
        sp.fallDistance = 0f;
        syncStats(sp, body, s.nenBody);
        float frac = body.getMaxHealth() > 0 ? body.getHealth() / body.getMaxHealth() : 1f; // the body's own health carries over
        sp.setHealth(Math.max(1f, sp.getMaxHealth() * Math.min(1f, frac)));
        sp.refreshDimensions(); // the creature's hitbox and eye height (see BlackVoiceEvents.onSize)
        AddonNetwork.sendToTrackingAndSelf(new PacketDisguise(sp.getId(), body.getId(), true, true), sp);
        sound(sp, SoundEvents.ENDERMAN_TELEPORT, 0.7f, 1.6f);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, clone.getX(), clone.getY() + 1.0, clone.getZ(), 20, 0.3, 0.4, 0.3, 0.2);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y + body.getBbHeight() * 0.7, at.z, 20, 0.3, 0.4, 0.3, 0.2);
        say(sp, "§5Black Voice: you are §f" + body.getName().getString() + " §5now §7(Shift+H to return to your body)");
    }

    /** The antenna'd body the player is looking at, else the nearest one in range. Tells the player why if there is none. */
    private static LivingEntity pickBody(ServerPlayer sp, State s) {
        if (s.antennas.isEmpty()) {
            say(sp, "§cNo antenna planted. Right-click someone with the phone first");
            return null;
        }
        double range = BlackVoiceTuning.CONTROL_RANGE;
        Entity looked = ChainManager.rayEntity(sp, range, e -> s.antennas.containsKey(e.getUUID()));
        if (looked instanceof Player) {
            say(sp, "§cA person's body cannot be taken over through the antenna");
            return null;
        }
        if (looked instanceof LivingEntity le && le.isAlive() && usableBody(sp, le)) return le;
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (UUID id : s.antennas.keySet()) {
            Entity e = find(sp.server, id);
            if (!(e instanceof LivingEntity le) || !le.isAlive() || !usableBody(sp, le)) continue;
            double d = le.distanceToSqr(sp);
            if (d < bd) {
                bd = d;
                best = le;
            }
        }
        if (best == null) say(sp, "§cNo antenna'd body within " + (int) range + " blocks that can be taken over");
        return best;
    }

    private static boolean usableBody(ServerPlayer sp, LivingEntity le) {
        return !(le instanceof Player) && le.level() == sp.level()
            && le.distanceToSqr(sp) <= BlackVoiceTuning.CONTROL_RANGE * BlackVoiceTuning.CONTROL_RANGE
            && !POSSESSED.containsKey(le.getUUID());
    }

    /** Back into your own body: the clone goes, the creature is visible and solid again, and you stand where the clone stood. */
    private static void endPossession(ServerPlayer sp, State s, String msg) {
        UUID id = s.possessed;
        if (id == null) return;
        UUID cloneId = s.clone;
        boolean nen = s.nenBody;
        s.possessed = null;
        s.clone = null;
        s.nenBody = false;
        POSSESSED.remove(id);
        s.lastUse = sp.tickCount;
        MinecraftServer server = sp.server;
        Entity e = server == null ? null : find(server, id);
        float frac = sp.getMaxHealth() > 0 ? Math.min(1f, sp.getHealth() / sp.getMaxHealth()) : 1f;
        clearStats(sp);
        if (nen) returnNen(sp, s);
        if (sp.isAlive()) sp.setHealth(Math.max(1f, Math.min(s.savedHealth, sp.getMaxHealth())));
        if (e instanceof LivingEntity body) {
            if (body.isAlive()) body.setHealth(Math.max(1f, body.getMaxHealth() * frac)); // what it took in your hands, it keeps
            body.setInvisible(s.oldInvisible);
            body.setInvulnerable(s.oldInvulnerable);
            body.setSilent(s.oldSilent);
            body.setNoGravity(s.oldNoGravity);
            body.noPhysics = s.oldNoPhysics;
            body.setDeltaMovement(Vec3.ZERO);
            if (body instanceof Mob m) {
                m.setNoAi(s.oldNoAi);
                m.setTarget(null);
                m.getNavigation().stop();
            }
        }
        AddonNetwork.sendToTrackingAndSelf(new PacketDisguise(sp.getId(), 0, false), sp);
        sp.refreshDimensions(); // back to your own size
        Entity ce = cloneId == null || server == null ? null : find(server, cloneId);
        if (ce instanceof SmokeCloneEntity clone) {
            if (sp.isAlive() && clone.level() == sp.level() && sp.level() instanceof ServerLevel lv) {
                sp.teleportTo(lv, clone.getX(), clone.getY(), clone.getZ(), sp.getYRot(), sp.getXRot());
                sp.fallDistance = 0f;
            }
            clone.dissolve();
        }
        sound(sp, SoundEvents.ENDERMAN_TELEPORT, 0.7f, 0.9f);
        if (msg != null) say(sp, msg);
    }

    /** Drops the player out of the borrowed body without touching their antennas (a dimension change, say). */
    public static void returnToBody(ServerPlayer sp, String msg) {
        State s = STATES.get(sp.getUUID());
        if (s != null && s.possessed != null) endPossession(sp, s, msg);
    }

    /** True for the creature somebody is wearing right now (invisible and intangible: hostile mobs must not pick it as a target). */
    public static ServerPlayer possessorOf(UUID body) {
        UUID p = body == null ? null : POSSESSED.get(body);
        if (p == null) return null;
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server == null ? null : server.getPlayerList().getPlayer(p);
    }

    /**
     * The clone of your real body was hit. It cannot move, but the damage is yours: it lands on you through your own Ten / armor,
     * and (see {@link BlackVoiceTuning#BODY_HURT_BREAKS_CONTROL}) you snap back into it. Returns whether the hit counted.
     */
    public static boolean onCloneHurt(SmokeCloneEntity clone, DamageSource src, float amount) {
        if (clone.level().isClientSide || !(clone.level() instanceof ServerLevel level)) return false;
        UUID ownerId = clone.ownerId();
        State s = ownerId == null ? null : STATES.get(ownerId);
        ServerPlayer sp = ownerId == null ? null : level.getServer().getPlayerList().getPlayer(ownerId);
        if (s == null || sp == null || !sp.isAlive() || s.possessed == null || !clone.getUUID().equals(s.clone)) return false;
        Entity attacker = src.getEntity();
        if (attacker != null && (attacker == sp || AllianceUtils.isAlly(attacker, sp))) return false;
        level.broadcastEntityEvent(clone, (byte) 2); // the hurt flash
        clone.playSound(SoundEvents.PLAYER_HURT, 1.0f, 1.0f);
        boolean hit = sp.hurt(src, amount);
        if (hit && sp.isAlive() && BlackVoiceTuning.BODY_HURT_BREAKS_CONTROL) {
            endPossession(sp, s, "§cYour body was hit! You are pulled back");
        }
        return hit;
    }

    /**
     * The player (inside a body) attacked something with their own hands: it is swapped for the creature's attack. Returns true when the
     * player is inside a body, so the vanilla punch is cancelled either way.
     */
    public static boolean onPossessedAttack(ServerPlayer sp, Entity target) {
        State s = STATES.get(sp.getUUID());
        if (s == null || s.possessed == null || s.nenBody) return false; // a Nen body punches with your own hands, Ten and Ren included
        if (s.attackCd > 0) return true;
        if (!(target instanceof LivingEntity victim) || !victim.isAlive() || AllianceUtils.isAlly(victim, sp)) return true;
        if (!(find(sp.server, s.possessed) instanceof LivingEntity body)) return true;
        s.attackCd = BlackVoiceTuning.ATTACK_COOLDOWN_TICKS;
        sp.swing(InteractionHand.MAIN_HAND, true);
        if (body instanceof Mob m && m.getAttribute(Attributes.ATTACK_DAMAGE) != null) {
            m.doHurtTarget(victim);
        } else {
            victim.hurt(body.level().damageSources().mobAttack(body), BlackVoiceTuning.FALLBACK_ATTACK_DAMAGE);
        }
        return true;
    }

    // ================= dying inside a body =================
    /** The size the player's body takes while they wear a creature (server side), or null. The client asks DisguiseHandler instead. */
    public static LivingEntity sizeBody(Player p) {
        if (p == null) return null;
        if (p.level().isClientSide) return net.hxhadventure.addon.client.DisguiseHandler.resizeBody(p);
        State s = STATES.get(p.getUUID());
        if (s == null || s.possessed == null || !(p instanceof ServerPlayer sp) || sp.server == null) return null;
        return find(sp.server, s.possessed) instanceof LivingEntity le ? le : null;
    }

    /**
     * The player is about to take damage that would kill them while wearing a body: the creature dies in their place and they are back in
     * their own body (where the clone stood), alive. Returns true when the hit must be cancelled. Kill commands and the void still kill.
     */
    public static boolean onWearerLethal(ServerPlayer sp, DamageSource src, float amount) {
        State s = STATES.get(sp.getUUID());
        if (s == null || s.possessed == null || src == null || src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return false;
        if (amount - sp.getAbsorptionAmount() < sp.getHealth()) return false;
        UUID id = s.possessed;
        Entity e = sp.server == null ? null : find(sp.server, id);
        endPossession(sp, s, "§cThe body you were wearing has been killed! You are back in your own body");
        if (e instanceof LivingEntity body && body.isAlive()) body.hurt(body.damageSources().genericKill(), Float.MAX_VALUE);
        return true;
    }

    // ================= Auto Pilot (the second skill) =================
    public static final String AUTOPILOT_ID = "bv_autopilot";

    /** Adds Auto Pilot to the Z list once the Hatsu level allows it (runs on the client too, so the menu shows it). */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c) || c.getHatsuLevel() < BlackVoiceTuning.AUTOPILOT_MIN_LEVEL) return base;
        String[] out = java.util.Arrays.copyOf(base, base.length + 1);
        out[base.length] = AUTOPILOT_ID;
        return out;
    }

    public static String displayName(String id) {
        return AUTOPILOT_ID.equals(id) ? "§5 Black Voice: Auto Pilot" : null;
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(AUTOPILOT_ID, BlackVoice::autoPilot);
    }

    /** True while a needle drives this player (server side). */
    public static boolean isAutoPilot(Entity e) {
        if (e == null || e.level().isClientSide) return false;
        State s = STATES.get(e.getUUID());
        return s != null && s.autoLeft > 0;
    }

    /** What Ten and Ren are multiplied by right now: 2x while Auto Pilot lasts, else 1. */
    public static float autoPilotMult(Entity e) {
        return isAutoPilot(e) ? BlackVoiceTuning.AUTOPILOT_TEN_REN_MULT : 1f;
    }

    /** The Z key went down or up (PacketZHold): the needle only goes in while Z is held. */
    public static void setZHeld(ServerPlayer sp, boolean held) {
        if (held) Z_DOWN.add(sp.getUUID());
        else Z_DOWN.remove(sp.getUUID());
    }

    /** Z with Auto Pilot selected: starts pushing the needle in. Keep holding Z until it is in. */
    public static void autoPilot(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (!gate(sp, c, BlackVoiceTuning.AUTOPILOT_MIN_LEVEL, "Auto Pilot")) return;
        State s = state(sp);
        if (s.possessed != null) {
            say(sp, "§cCome back to your own body first");
            return;
        }
        if (s.autoLeft > 0 || s.needleStart >= 0) return;
        if (ChainManager.onCooldown(sp, "Auto Pilot", s.autoCooldown)) return;
        if (c.getCurrentEnergy() < BlackVoiceTuning.AUTOPILOT_COST) {
            say(sp, "§cNot enough energy (" + (int) BlackVoiceTuning.AUTOPILOT_COST + " needed)");
            return;
        }
        s.needleStart = sp.tickCount;
        say(sp, "§5Auto Pilot: hold Z to push the needle in...");
        sound(sp, SoundEvents.CHAIN_PLACE, 0.8f, 1.9f);
    }

    private static void tickNeedle(ServerPlayer sp, Combat c, State s) {
        int elapsed = sp.tickCount - s.needleStart;
        // let go of Z (the first few ticks are grace for the key packet to arrive) and the needle is put away
        if (elapsed >= 4 && !Z_DOWN.contains(sp.getUUID())) {
            s.needleStart = -1;
            say(sp, "§7Auto Pilot: needle put away");
            return;
        }
        if (s.possessed != null || ChainManager.isJailed(sp) || HatsuEffects.has(sp)) {
            s.needleStart = -1;
            return;
        }
        if (elapsed < BlackVoiceTuning.AUTOPILOT_NEEDLE_HOLD_TICKS) {
            if (elapsed % 5 == 0) {
                say(sp, String.format(java.util.Locale.ROOT, "§5Auto Pilot: needle going in... %d%% §7(keep holding Z)",
                    elapsed * 100 / BlackVoiceTuning.AUTOPILOT_NEEDLE_HOLD_TICKS));
            }
            return;
        }
        s.needleStart = -1;
        if (c.getCurrentEnergy() < BlackVoiceTuning.AUTOPILOT_COST) {
            say(sp, "§cNot enough energy (" + (int) BlackVoiceTuning.AUTOPILOT_COST + " needed)");
            return;
        }
        c.consumeEnergy(BlackVoiceTuning.AUTOPILOT_COST);
        startAutoPilot(sp, c, s);
    }

    private static void startAutoPilot(ServerPlayer sp, Combat c, State s) {
        NenAddonData d = NenAddonData.get(sp);
        if (d.zetsu) d.setZetsu(sp, false, null);
        if (d.ken) d.toggleKen(sp);
        if (d.ko) d.toggleKo(sp);
        if (!c.isTenActive()) AbilityRegistry.toggleTen(sp, true);
        if (!c.isAuraActive()) AbilityRegistry.toggleRen(sp, true);
        s.autoLeft = BlackVoiceTuning.AUTOPILOT_TICKS;
        s.autoAttackCd = 0;
        s.autoTarget = null;
        s.autoYaw = sp.getYRot();
        s.autoPitch = sp.getXRot();
        sendAuto(sp, true, s.autoYaw, s.autoPitch, 0);
        sound(sp, SoundEvents.BEACON_ACTIVATE, 0.8f, 1.5f);
        sound(sp, SoundEvents.ENDERMAN_STARE, 0.6f, 1.4f);
        if (sp.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getEyeY(), sp.getZ(), 25, 0.3, 0.3, 0.3, 0.2);
        }
        say(sp, "§5Auto Pilot: the needle is in. §7You cannot act for " + (BlackVoiceTuning.AUTOPILOT_TICKS / 20) + "s");
    }

    private static void endAutoPilot(ServerPlayer sp, State s, String msg) {
        if (s.autoLeft <= 0) return;
        s.autoLeft = 0;
        s.autoTarget = null;
        s.autoCooldown = BlackVoiceTuning.AUTOPILOT_COOLDOWN_TICKS;
        ChainManager.startCooldown(sp, "Auto Pilot", BlackVoiceTuning.AUTOPILOT_COOLDOWN_TICKS);
        sendAuto(sp, false, 0f, 0f, 0);
        sound(sp, SoundEvents.CHAIN_BREAK, 0.8f, 1.2f);
        if (msg != null) say(sp, msg);
    }

    private static void sendAuto(ServerPlayer sp, boolean on, float yaw, float pitch, int flags) {
        AddonNetwork.sendToPlayer(new PacketBvAuto(on, yaw, pitch, flags), sp);
    }

    /** Anything the needle will hit: every living thing around you except your allies, your antennas, your own clones and creative / spectator players. */
    private static boolean autoValid(ServerPlayer sp, LivingEntity e) {
        if (e == sp || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, sp)) return false;
        if (OWNER.containsKey(e.getUUID()) || POSSESSED.containsKey(e.getUUID()) || SkillHunter.isFake(e)) return false;
        if (e instanceof SmokeCloneEntity sc && sp.getUUID().equals(sc.ownerId())) return false;
        return !(e instanceof Player p && (p.isCreative() || p.isSpectator()));
    }

    /** The creature the autopilot walks at: the nearest living thing around you (it attacks everything, not just enemies). */
    private static LivingEntity pickAutoTarget(ServerPlayer sp, ServerLevel level) {
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        double r = BlackVoiceTuning.AUTOPILOT_SEARCH_RANGE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(r))) {
            if (!autoValid(sp, e)) continue;
            double d2 = e.distanceToSqr(sp);
            if (d2 < bestD) {
                bestD = d2;
                best = e;
            }
        }
        return best;
    }

    /**
     * The Attack only reaches what is in front of you, but the needle hits everything around you: every valid creature within
     * {@link BlackVoiceTuning#AUTOPILOT_SWEEP_RADIUS} that the Attack's own box did not already catch takes a punch too.
     */
    private static void sweepAround(ServerPlayer sp, ServerLevel level, Combat c) {
        double r = BlackVoiceTuning.AUTOPILOT_SWEEP_RADIUS;
        Vec3 look = sp.getLookAngle();
        Vec3 front = sp.position().add(look.x * 1.5, 1.5, look.z * 1.5);
        AABB frontBox = new AABB(front.x - 1.5, front.y - 1.5, front.z - 1.5, front.x + 1.5, front.y + 1.5, front.z + 1.5);
        float dmg = BlackVoiceTuning.AUTOPILOT_SWEEP_DAMAGE * c.getSpiritBonus();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(r))) {
            if (!autoValid(sp, e) || e.getBoundingBox().intersects(frontBox)) continue;
            if (e.distanceToSqr(sp) > r * r) continue;
            e.hurt(sp.damageSources().mobAttack(sp), dmg);
            e.knockback(0.4, sp.getX() - e.getX(), sp.getZ() - e.getZ());
        }
    }

    /** The needle's brain: walk at the nearest living thing and hit everything around you with Attack. Ren stays on for the whole time. */
    private static void tickAutoPilot(ServerPlayer sp, Combat c, State s, ServerLevel level) {
        if (--s.autoLeft <= 0) {
            endAutoPilot(sp, s, "§7Auto Pilot: the needle dissolves. You have your body back");
            return;
        }
        NenAddonData d = NenAddonData.get(sp);
        if (d.zetsu) d.setZetsu(sp, false, null);
        if (!c.isAuraActive()) AbilityRegistry.toggleRen(sp, true); // permanently in Ren
        if (s.autoLeft % 20 == 0) say(sp, "§5Auto Pilot: §f" + (s.autoLeft / 20) + "s §7left");

        if (s.autoAttackCd > 0) s.autoAttackCd--;
        LivingEntity t = s.autoTarget == null ? null : level.getEntity(s.autoTarget) instanceof LivingEntity le && le.isAlive() ? le : null;
        if (t == null || sp.tickCount % 10 == 0) {
            LivingEntity near = pickAutoTarget(sp, level);
            t = near != null ? near : t;
            s.autoTarget = t == null ? null : t.getUUID();
        }
        int flags = 0;
        if (t != null) {
            double dx = t.getX() - sp.getX(), dz = t.getZ() - sp.getZ();
            double flat = Math.sqrt(dx * dx + dz * dz);
            double dy = t.getY(0.5) - sp.getEyeY();
            s.autoYaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90f;
            s.autoPitch = Mth.clamp((float) -(Mth.atan2(dy, Math.max(flat, 0.001)) * (180.0 / Math.PI)), -80f, 80f);
            double gap = Math.max(0.0, sp.distanceTo(t) - t.getBbWidth() * 0.5);
            if (gap > BlackVoiceTuning.AUTOPILOT_STOP_RANGE) flags |= PacketBvAuto.FORWARD;
            if (gap > 5.0) flags |= PacketBvAuto.SPRINT;
            if ((sp.horizontalCollision && sp.onGround()) || (dy > 0.9 && sp.onGround() && flat < 3.0)) flags |= PacketBvAuto.JUMP;
            float yawErr = Math.abs(Mth.wrapDegrees(s.autoYaw - sp.getYRot()));
            if (gap <= BlackVoiceTuning.AUTOPILOT_ATTACK_RANGE && yawErr < 30f && s.autoAttackCd <= 0) {
                s.autoAttackCd = BlackVoiceTuning.AUTOPILOT_ATTACK_INTERVAL;
                AI_EXEC = true; // the needle uses Attack, the same one Z would
                try {
                    AbilityRegistry.execute("nen_attack", sp);
                } finally {
                    AI_EXEC = false;
                }
                sweepAround(sp, level, c);
            }
        }
        if (sp.tickCount % 2 == 0) sendAuto(sp, true, s.autoYaw, s.autoPitch, flags);
    }

    // ---------------- ending ----------------
    /** Any entity died: if it carried an antenna, the antenna goes (and you are thrown back if you were inside). */
    public static void onDeath(Entity e) {
        if (OWNER.containsKey(e.getUUID())) removeAntenna(e.getServer(), e.getUUID());
    }

    /** The owner died, logged out, lost the Hatsu or changed it: every antenna dissolves and the phone goes. */
    public static void onOwnerGone(ServerPlayer sp) {
        State s = STATES.remove(sp.getUUID());
        Z_DOWN.remove(sp.getUUID());
        if (s == null) return;
        if (s.possessed != null) endPossession(sp, s, null);
        if (s.autoLeft > 0) sendAuto(sp, false, 0f, 0f, 0);
        for (UUID id : new ArrayList<>(s.antennas.keySet())) {
            OWNER.remove(id);
            Entity e = sp.server == null ? null : find(sp.server, id);
            if (e instanceof Mob m) m.setTarget(null);
        }
    }

    public static void clear(Player p) {
        if (p instanceof ServerPlayer sp) onOwnerGone(sp);
    }

    public static void reset() {
        STATES.clear();
        OWNER.clear();
        POSSESSED.clear();
        Z_DOWN.clear();
    }

    // ---------------- per tick ----------------
    public static void serverTick(MinecraftServer server) {
        if (STATES.isEmpty()) return;
        long tick = server.getTickCount();
        for (Map.Entry<UUID, State> en : new ArrayList<>(STATES.entrySet())) {
            State s = en.getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null) { // logged off without the logout hook running (crash handling): let everything go
                for (UUID id : new ArrayList<>(s.antennas.keySet())) OWNER.remove(id);
                if (s.possessed != null) POSSESSED.remove(s.possessed);
                STATES.remove(en.getKey());
                Z_DOWN.remove(en.getKey());
                continue;
            }
            if (!sp.isAlive()) {
                onOwnerGone(sp);
                continue;
            }
            Combat c = Combat.get(sp);
            if (!usable(sp, c) && !(s.possessed != null && s.nenBody)) { // a borrowed kit is not Black Voice, and that is fine
                onOwnerGone(sp);
                continue;
            }
            if (s.cooldown > 0) s.cooldown--;
            if (s.autoCooldown > 0) s.autoCooldown--;
            if (s.possessed != null && (ChainManager.isJailed(sp) || HatsuEffects.has(sp))) {
                endPossession(sp, s, "§5Forced out of the body");
            }

            if (sp.level() instanceof ServerLevel level) {
                tickAntennas(server, sp, s, level, tick);
                if (s.needleStart >= 0) tickNeedle(sp, c, s);
                if (s.autoLeft > 0) tickAutoPilot(sp, c, s, level);
            }
            if (s.possessed != null) tickPossession(server, sp, s, c, tick);
        }
    }

    private static void tickAntennas(MinecraftServer server, ServerPlayer sp, State s, ServerLevel level, long tick) {
        long now = level.getGameTime();
        for (Map.Entry<UUID, Antenna> en : new ArrayList<>(s.antennas.entrySet())) {
            UUID id = en.getKey();
            Entity e = find(server, id);
            if (now >= en.getValue().expiry) {
                removeAntenna(server, id);
                say(sp, "§7An antenna dissolves");
                continue;
            }
            if (e == null) continue; // in an unloaded chunk or another dimension for now
            if (!e.isAlive()) {
                removeAntenna(server, id);
                continue;
            }
            if (tick % 10 == 0 && !id.equals(s.possessed) && e.level() instanceof ServerLevel el) {
                el.sendParticles(ParticleTypes.ELECTRIC_SPARK, e.getX(), e.getY() + e.getBbHeight() + 0.25, e.getZ(), 2, 0.05, 0.1, 0.05, 0.0);
            }
            // when you are not inside it, an allied mob fights for you
            if (tick % 10 == 0 && e instanceof Mob m && !id.equals(s.possessed) && e.level() == sp.level()) steer(sp, level, m);
        }
    }

    /** Allied mobs fight the caster's enemies, otherwise follow the caster. (Same behaviour as Skill Hunter's puppets.) */
    private static void steer(ServerPlayer owner, ServerLevel level, Mob m) {
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, owner.getBoundingBox().inflate(BlackVoiceTuning.ALLY_SCAN_RANGE))) {
            if (e == owner || e == m || !e.isAlive() || AllianceUtils.isAlly(e, owner) || AllianceUtils.isAlly(e, m)) continue;
            if (OWNER.containsKey(e.getUUID()) || SkillHunter.isFake(e)) continue;
            boolean hostile = e instanceof Enemy || (e instanceof Mob em && em.getTarget() == owner)
                || e == owner.getLastHurtByMob() || e == owner.getLastHurtMob();
            if (!hostile) continue;
            double d2 = e.distanceToSqr(m);
            if (d2 < bestD) {
                bestD = d2;
                best = e;
            }
        }
        m.setTarget(best);
        if (best == null && m.distanceToSqr(owner) > BlackVoiceTuning.ALLY_FOLLOW_DIST_SQ) m.getNavigation().moveTo(owner, 1.1);
    }

    /** While you wear a body: the real creature rides along under your disguise, the clone of your body is watched, upkeep is paid. */
    private static void tickPossession(MinecraftServer server, ServerPlayer sp, State s, Combat c, long tick) {
        Entity e = find(server, s.possessed);
        if (!(e instanceof LivingEntity body) || !body.isAlive()) {
            endPossession(sp, s, "§7The body is gone");
            return;
        }
        Entity ce = s.clone == null ? null : find(server, s.clone);
        if (!(ce instanceof SmokeCloneEntity clone) || !clone.isAlive()) {
            endPossession(sp, s, "§cYour own body is gone! You are pulled back");
            return;
        }
        if (body.level() != sp.level() || clone.level() != sp.level()) {
            endPossession(sp, s, "§7Your body is in another world");
            return;
        }
        // no Nen in this body: keep everything off even if something switched it back on
        if (!s.nenBody) {
            if (c.isTenActive()) AbilityRegistry.toggleTen(sp, false);
            if (c.isAuraActive()) AbilityRegistry.toggleRen(sp, false);
        }

        // the real creature stays under you, unseen and untouchable
        body.setPos(sp.getX(), sp.getY(), sp.getZ());
        body.setYRot(sp.getYRot());
        body.setYHeadRot(sp.getYHeadRot());
        body.setYBodyRot(sp.yBodyRot);
        body.setDeltaMovement(Vec3.ZERO);
        body.fallDistance = 0f;
        if (body instanceof Mob m) m.setTarget(null);

        if (s.attackCd > 0) s.attackCd--;
        if (tick % 40 == 0) AddonNetwork.sendToTrackingAndSelf(new PacketDisguise(sp.getId(), body.getId(), true, true), sp); // for whoever just came into view
        if (tick % 20 == 0) {
            syncStats(sp, body, s.nenBody);
            float upkeep = s.nenBody ? BlackVoiceTuning.NEN_BODY_UPKEEP : BlackVoiceTuning.POSSESS_UPKEEP;
            if (upkeep > 0f) {
                if (c.getCurrentEnergy() < upkeep) {
                    endPossession(sp, s, "§cEnergy depleted! You are pulled back");
                    return;
                }
                c.consumeEnergy(upkeep);
            }
        }
        if (sp.distanceToSqr(clone) > BlackVoiceTuning.CONTROL_RANGE * BlackVoiceTuning.CONTROL_RANGE) {
            endPossession(sp, s, "§cToo far from your own body! You are pulled back");
            return;
        }
        if (tick % 10 == 0) say(sp, "§5Black Voice: §f" + body.getName().getString() + " §7(Shift+H to return)");
    }

    // ================= the body's Nen and stats =================
    private record NenBody(int kit, int nenType, int hatsu, int[] levels) {}

    /** The Nen a body carries if it is one of the Nen NPCs (their own Level, skill levels, Nen type and Hatsu kit), else null. */
    private static NenBody nenBodyOf(LivingEntity e) {
        java.util.function.ToIntFunction<NenSkill> f;
        int kit, type, hatsu;
        if (e instanceof ChrolloEntity) {
            f = ChrolloTuning::skillLevel; kit = SkillHunter.KIT; type = ChrolloTuning.NEN_TYPE; hatsu = ChrolloTuning.HATSU_LEVEL;
        } else if (e instanceof HisokaEntity) {
            f = HisokaTuning::skillLevel; kit = BungeeGum.KIT; type = HisokaTuning.NEN_TYPE; hatsu = HisokaTuning.HATSU_LEVEL;
        } else if (e instanceof GonEntity) {
            f = GonTuning::skillLevel; kit = Jajanken.KIT; type = GonTuning.NEN_TYPE; hatsu = GonTuning.HATSU_LEVEL;
        } else if (e instanceof net.hxhadventure.entity.custom.KiteEntity) {
            f = KiteTuning::skillLevel; kit = CrazySlots.KIT; type = KiteTuning.NEN_TYPE; hatsu = KiteTuning.HATSU_LEVEL;
        } else if (e instanceof NeferpitouEntity) {
            f = sk -> sk == NenSkill.TEN ? NeferpitouTuning.TEN_LEVEL : sk == NenSkill.REN ? NeferpitouTuning.REN_LEVEL : 1;
            kit = DoctorBlythe.KIT; type = Combat.NEN_SPECIALIZATION; hatsu = NeferpitouTuning.HATSU_LEVEL;
        } else {
            return null;
        }
        int[] lv = new int[NenSkill.values().length];
        for (NenSkill sk : NenSkill.values()) lv[sk.ordinal()] = Math.max(1, f.applyAsInt(sk));
        return new NenBody(kit, type, hatsu, lv);
    }

    private static final String BACKUP_TAG = "HxHAdventure_BVBackup";

    private static void setKit(ServerPlayer sp, Combat c, int kit) {
        c.syncKit(kit);
        net.hxhadventure.networking.ModMessages.sendToPlayer(new net.hxhadventure.networking.PacketSyncKit(kit), sp);
    }

    private static void setEnergy(Combat c, float to) {
        float diff = Math.min(to, c.getMaxEnergy()) - c.getCurrentEnergy();
        if (diff > 0f) c.restoreEnergy(diff);
        else if (diff < 0f) c.consumeEnergy(-diff);
    }

    /** Wear the body's Nen: its Level, Nen type, kit and skill levels, with a full pool of its size. Yours are kept aside (and in the save, in case of a crash). */
    private static void borrowNen(ServerPlayer sp, Combat c, State s, NenBody nb) {
        net.minecraft.nbt.CompoundTag pd = sp.getPersistentData();
        net.minecraft.nbt.CompoundTag t = new net.minecraft.nbt.CompoundTag();
        s.savedKit = c.getCurrentKit();
        s.savedNenType = c.getNenType();
        s.savedHatsu = c.getHatsuLevel();
        s.savedEnergy = c.getCurrentEnergy();
        t.putInt("kit", s.savedKit);
        t.putInt("type", s.savedNenType);
        t.putInt("hatsu", s.savedHatsu);
        t.putInt("exp", pd.getInt("HatsuExp"));
        t.putFloat("frac", pd.getFloat("HxHCraft_HatsuExpFrac"));
        pd.put(BACKUP_TAG, t);
        s.nenBody = true;
        NenAddonData d = NenAddonData.get(sp);
        d.borrowSkills(nb.levels());
        c.setNenType(nb.nenType());
        c.setHatsuLevel(nb.hatsu());
        setKit(sp, c, nb.kit());
        setEnergy(c, c.getMaxEnergy());
        d.markSync();
    }

    /** Back to your own Level, Nen type, kit, skills and aura. */
    private static void returnNen(ServerPlayer sp, State s) {
        Combat c = Combat.get(sp);
        net.minecraft.nbt.CompoundTag pd = sp.getPersistentData();
        net.minecraft.nbt.CompoundTag t = pd.getCompound(BACKUP_TAG);
        NenAddonData d = NenAddonData.get(sp);
        if (c != null) {
            if (c.isTenActive()) AbilityRegistry.toggleTen(sp, false);
            if (c.isAuraActive()) AbilityRegistry.toggleRen(sp, false);
            c.setNenType(s.savedNenType);
            c.setHatsuLevel(s.savedHatsu);
            if (t.contains("exp")) c.setHatsuExp(t.getInt("exp"));
            pd.putFloat("HxHCraft_HatsuExpFrac", t.getFloat("frac"));
            setKit(sp, c, s.savedKit);
        }
        d.returnSkills();
        pd.remove(BACKUP_TAG);
        if (c != null) setEnergy(c, s.savedEnergy);
        d.markSync();
    }

    /**
     * Runs right after the game has written the player's Nen data to the save (autosave, quit, server stop, crash-safe saves).
     * While you wear a Nen body (Chrollo, Hisoka, Gon, Neferpitou) the live data is the body's Level, Nen type, kit and energy;
     * the file must always get YOUR own, so a save taken mid-possession can never leave you as Skill Hunter (or anyone else) on the next login.
     */
    public static void patchSave(ServerPlayer sp) {
        State s = STATES.get(sp.getUUID());
        if (s == null || !s.nenBody) return;
        net.minecraft.nbt.CompoundTag persisted = sp.getPersistentData().getCompound("PlayerPersisted");
        net.minecraft.nbt.CompoundTag combat = persisted.getCompound("HxHCraftCombat");
        if (combat.isEmpty()) return;
        combat.putInt("CurrentKitId", s.savedKit);
        combat.putInt("HxHCraft_NenType", s.savedNenType);
        combat.putBoolean("HxHCraft_NenUnlocked", s.savedNenType != 0 || s.savedKit >= 1);
        combat.putInt("HatsuLevel", s.savedHatsu);
        combat.putFloat("HxHCraft_CurrentEnergy", s.savedEnergy);
        persisted.putInt("HxHCraft_NenType", s.savedNenType);
        persisted.putBoolean("HxHCraft_NenUnlocked", s.savedNenType != 0 || s.savedKit >= 1);
        sp.getPersistentData().put("PlayerPersisted", persisted);
    }

    /** True if this creature is the body the given player is wearing right now (it is invisible and sits exactly where the player is). */
    public static boolean isWornBy(Entity e, Entity wearer) {
        if (e == null || wearer == null) return false;
        UUID who = POSSESSED.get(e.getUUID());
        return who != null && who.equals(wearer.getUUID());
    }

    /** Login after a crash inside a body: the saved skills are already yours, this puts back Level, Nen type and kit. */
    public static void recoverBackup(ServerPlayer sp) {
        net.minecraft.nbt.CompoundTag pd = sp.getPersistentData();
        if (!pd.contains(BACKUP_TAG) || isPossessing(sp)) return;
        net.minecraft.nbt.CompoundTag t = pd.getCompound(BACKUP_TAG);
        Combat c = Combat.get(sp);
        if (c != null) {
            c.setNenType(t.getInt("type"));
            c.setHatsuLevel(t.getInt("hatsu"));
            c.setHatsuExp(t.getInt("exp"));
            pd.putFloat("HxHCraft_HatsuExpFrac", t.getFloat("frac"));
            setKit(sp, c, t.getInt("kit"));
        }
        pd.remove(BACKUP_TAG);
    }

    private static final UUID STAT_HP = UUID.fromString("c3000000-0000-4000-8000-000000000001");
    private static final UUID STAT_ATK = UUID.fromString("c3000000-0000-4000-8000-000000000002");
    private static final UUID STAT_KB = UUID.fromString("c3000000-0000-4000-8000-000000000003");

    /** Makes the wearer's max health, knockback resistance (and, for a Nen body, attack damage) those of the body. Transient, so never saved. */
    private static void syncStats(ServerPlayer sp, LivingEntity body, boolean withAttack) {
        stat(sp, body, net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, STAT_HP);
        stat(sp, body, net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE, STAT_KB);
        if (withAttack) stat(sp, body, Attributes.ATTACK_DAMAGE, STAT_ATK);
    }

    private static void stat(ServerPlayer sp, LivingEntity body, net.minecraft.world.entity.ai.attributes.Attribute attr, UUID uid) {
        net.minecraft.world.entity.ai.attributes.AttributeInstance a = sp.getAttribute(attr);
        if (a == null || body.getAttribute(attr) == null) return;
        net.minecraft.world.entity.ai.attributes.AttributeModifier old = a.getModifier(uid);
        double oldAmount = old == null ? 0.0 : old.getAmount();
        double amount = body.getAttributeValue(attr) - (a.getValue() - oldAmount);
        if (old != null && Math.abs(amount - oldAmount) < 0.01) return;
        if (old != null) a.removeModifier(uid);
        a.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(uid, "Black Voice body", amount,
            net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION));
    }

    private static void clearStats(ServerPlayer sp) {
        for (var pair : new Object[][] {
            {Attributes.MAX_HEALTH, STAT_HP}, {Attributes.KNOCKBACK_RESISTANCE, STAT_KB}, {Attributes.ATTACK_DAMAGE, STAT_ATK}}) {
            net.minecraft.world.entity.ai.attributes.AttributeInstance a = sp.getAttribute((net.minecraft.world.entity.ai.attributes.Attribute) pair[0]);
            if (a != null) a.removeModifier((UUID) pair[1]);
        }
    }
}
