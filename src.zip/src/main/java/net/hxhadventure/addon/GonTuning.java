package net.hxhadventure.addon;

import net.hxhadventure.abilities.Combat;

/**
 * Every number that defines the Gon NPC, in one place. He is an Enhancer with Jajanken, level 60 in everything (60 is also the level
 * the "I'll use everything." vow unlocks at, see {@link GonVow#MIN_LEVEL}). His combat numbers are HxHAdventure's own player numbers
 * (Combat.java) and his Jajanken numbers are {@link Jajanken}'s, so he hits like a player of those levels would.
 */
public final class GonTuning {
    private GonTuning() {}

    // ---- levels ----
    public static final int LEVEL = 60;
    public static final int HATSU_LEVEL = LEVEL, TEN_LEVEL = LEVEL, REN_LEVEL = LEVEL, KEN_LEVEL = LEVEL;
    public static final int EN_LEVEL = LEVEL, GYO_LEVEL = LEVEL, IN_LEVEL = LEVEL;
    public static final int NEN_TYPE = Combat.NEN_ENHANCEMENT;
    public static final int AURA_COLOR_INDEX = 4;                // 4 = green (the order is gold, light blue, red, dark blue, green, purple, pink, white, black)

    /** The level of a Nen skill for this NPC, for anything that wants to compare it with a player's (En vs In, Gyo, ...). */
    public static int skillLevel(NenSkill s) {
        return switch (s) {
            case TEN -> TEN_LEVEL;
            case REN -> REN_LEVEL;
            case EN -> EN_LEVEL;
            case GYO -> GYO_LEVEL;
            case IN -> IN_LEVEL;
            default -> LEVEL;
        };
    }

    // ---- body ----
    public static final double MAX_HEALTH = 160.0;
    public static final double BASE_SPEED = 0.32;
    public static final double FOLLOW_RANGE = 48.0;
    public static final double KNOCKBACK_RESISTANCE = 0.3;
    public static final float HEAL_PER_SECOND = 1.0f;            // while Ten is up and he has not been hit for 2 s
    public static final int FOE_MEMORY_TICKS = 1200;             // how long a mob that hurt him counts as an enemy

    // ---- who he fights ----
    /** Gon is passive to players. Set true and he fights back (like Hisoka does) against a player who hurts him. */
    public static final boolean RETALIATE_AGAINST_PLAYERS = false;
    public static final double SIGHT_RANGE = 32.0;               // how far he notices hostile mobs
    public static final double PITOU_SIGHT_RANGE = 64.0;         // how far he notices Neferpitou (the vow's trigger)
    public static final int SCAN_INTERVAL_TICKS = 10;

    // ---- aura pool ----
    public static final float AURA_POOL_MULT = 0.25f;
    public static final float EXHAUST_RESUME_FRACTION = 0.10f;
    public static final float EXHAUST_REGEN_PCT = 0.008f;
    public static final float REST_REGEN_PCT = 0.004f;
    public static final int REST_DELAY_TICKS = 100;
    public static final float BASE_REGEN = 0.5f;

    public static float tenRegenPerSecond() {
        float s = (float) Math.sqrt(HATSU_LEVEL);
        float scaled = Math.min(0.5f + HATSU_LEVEL * 0.1f * (1f + s * 0.1f), 2.0f);
        return scaled * 5.5f + Tuning.tenRegen(TEN_LEVEL);
    }

    public static float maxAura() {
        return Tuning.npcMaxNen(HATSU_LEVEL, TEN_LEVEL, REN_LEVEL) * AURA_POOL_MULT;
    }

    // ---- stance behaviour (Ten always, Ken to fight) ----
    public static final int FORM_SWITCH_TICKS = 5;
    public static final int KEN_AFTER_HIT_TICKS = 40;

    // ---- plain attacks (Combat.java's numbers) ----
    public static final double REACH = 2.5;
    public static final int PUNCH_GAP_TICKS = 10;
    public static final float PUNCH_DAMAGE = 5.0f, PUNCH_RANGE = 1.5f;
    public static final float STRONG_DAMAGE = 15.0f, STRONG_RANGE = 2.0f;
    public static final double STRONG_KNOCKBACK = 1.4;
    public static final int STRONG_CHARGE_TICKS = 40;
    public static final int STRONG_MAX_HOLD_TICKS = 55;
    public static final int STRONG_COOLDOWN_TICKS = 100;
    public static final float BARRAGE_DAMAGE = 1.5f;
    public static final int BARRAGE_TICKS = 36;
    public static final int BARRAGE_HIT_GAP = 3;
    public static final int BARRAGE_COOLDOWN_TICKS = 60;
    public static final float ATTACK_SLOW = 0.20f, STRONG_SLOW = 0.50f, BARRAGE_SLOW = 0.40f;
    public static final int PUNCH_ANIM_TICKS = 9;
    public static final float PUNCH_WEIGHT_BARRAGE = 0.18f, PUNCH_WEIGHT_STRONG = 0.14f;

    // ---- Jajanken (the numbers themselves are Jajanken's; these decide when he reaches for each move) ----
    /** Chance, each time he is free and the target is in a move's range, that he starts that Jajanken move instead of a plain punch. */
    public static final float JAJANKEN_CHANCE = 0.55f;
    public static final double ROCK_START_DIST = Jajanken.ROCK_REACH + 1.0;   // Rock is thrown at melee range: he starts the charge this close
    public static final double SCISSORS_MIN_DIST = 3.0, SCISSORS_MAX_DIST = 8.0;
    public static final double PAPER_MIN_DIST = 7.0, PAPER_MAX_DIST = 30.0;
    /** A charge is thrown once it is full; if the target has run out of range by then he throws it anyway after this long. */
    public static final int CHARGE_PATIENCE_TICKS = 30;
    /** He faces the target while charging, and hits foes only (never players, pets, villagers). */
    public static final double CHARGE_AIM_DEG = 40.0;
    /** Chat lines ("First comes rock...", "Gu!") reach players this close. */
    public static final double CHAT_RANGE = 48.0;

    // ---- "I'll use everything." ----
    /**
     * He can only enter the form while Neferpitou is aggravated (she has a target) and he can see her. It runs this long at most,
     * ends {@link #VOW_LINGER_TICKS} after he last saw an aggravated Neferpitou, and ends when she is dead.
     */
    public static final int VOW_MAX_TICKS = 1200;                // 60 s
    public static final int VOW_LINGER_TICKS = 100;
    /** After the form his Nen is spent (he is exhausted until some aura returns) and he cannot take it again for this long. */
    public static final int VOW_COOLDOWN_TICKS = 6000;           // 5 min
    /** Movement speed in the form (a player's is x10, which no pathfinder can steer): this multiplier instead. */
    public static final float VOW_SPEED_MULT = 3.0f;
    /** Rock charges (cycles of the orb) before he lets it go: the first finished cycle is a full charge, each one after is x1.5 on top. */
    public static final int VOW_CYCLES_BEFORE_RELEASE = 2;
    /** Most vow Rocks he throws in one form (each is a level of Nen debt for a player). */
    public static final int VOW_MAX_ROCKS = 3;
    /** The blast reaches this far from where the punch lands, as a multiple of a normal Rock's (GonVow.RADIUS_MULT for a player). */
    public static final float VOW_RADIUS_MULT = GonVow.RADIUS_MULT;
    /** Dig the crater (needs the mobGriefing game rule). Creatures are hit either way. */
    public static final boolean VOW_CRATER = true;
}
