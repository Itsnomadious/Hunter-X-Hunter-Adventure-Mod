package net.hxhadventure.addon;

/** Practice-based skills (Skyrim style): each levels up by being used, independent of level. */
public enum NenSkill {
    TEN("Ten", "Always on after awakening: +20% speed, durability and damage at level 1. Durability and damage reach +300% at level 100; speed grows +1.1% per level. Also gives Jump Boost II. Also regenerates aura."),
    ZETSU("Zetsu", "Better stealth, much faster Nen recovery (always more than Ten), smaller damage penalty."),
    REN("Ren", "Ren doubles your Ten. Higher levels give a bigger aura and lower aura upkeep."),
    EN("En", "Larger En radius. Shows everything in range as glowing, except Nen users whose In is at or above your En level."),
    HATSU("Hatsu", "Abilities cost less aura the more you use them, and Hatsu abilities hit harder: about +29% damage at level 100, then +0.6% for every level above 100."),
    IN("In", "Hides your Nen. En can only sense you if its level beats your In, and Chains / Bungee Gum turn invisible. At Genius you choose whether they show."),
    GYO("Gyo", "Lets you see Nen hidden by In, and read the grade of whoever you look at, up to the grade of your own Gyo."),
    SHU("Shu", "Coats the item in your hand in aura (U): +5% weapon damage at level 1, +50% at level 100 (then +5% per 5 levels). Every 10 levels cuts durability loss by 10%; from level 80 the coating makes the item last far longer, up to 10x a Netherite tool's durability (20310 uses) at level 100. It also speeds up mining: a diamond pickaxe mines at speed 50 at level 100 (vanilla 8), growing further past 100, and it multiplies the pickaxe's Efficiency too. Stacks with Ten and Ren, but you take more damage while it is on: +20% at level 1, +7.5% at level 100.");

    public static final int MAX_LEVEL = 100;
    public final String label;
    public final String description;

    NenSkill(String label, String description) {
        this.label = label;
        this.description = description;
    }

    public static int xpToNext(int level) {
        return 20 + (int) (level * level * 0.12);
    }
}
