package net.hxhadventure.addon;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketLaplaceFx;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Tserriednich Hui Guo Rou's Laplace Devil (Hatsu kit 24, Specialists). There is no ability to press: it opens when the user enters Zetsu
 * and closes when they leave it.
 *
 * <ul>
 *   <li>The Devil appears {@link LaplaceDevilTuning#DEVIL_HEIGHT} (41) blocks above the user and never moves. A dome of
 *       {@link LaplaceDevilTuning#RADIUS} blocks is measured around the user at that moment; everybody inside it is <b>affected</b>, for as
 *       long as the domain lasts. Anyone who walks in later, or was outside, is not.</li>
 *   <li>The affected cannot see the Devil or the real user. They see the user's double instead (same skin, gear and numbers). Mobs that
 *       were hunting the user are handed to the double, and no affected creature can target the real user until the domain closes.</li>
 *   <li>The real user cannot be heard or seen by the affected, cannot hurt any entity, and can still break blocks and use the world.
 *       Everybody the domain does not affect sees the real user and the Devil, and never the double.</li>
 * </ul>
 * Nothing here is drawn on the server: it spawns two entities (the Devil and the double) and tells every client who is affected
 * (PacketLaplaceFx / LaplaceFx), which is what hides things per viewer.
 */
public final class LaplaceDevil {
    private LaplaceDevil() {}

    public static final int KIT = 24;
    public static final String ID = "laplace_devil";
    private static final String NAME = "Laplace Devil";
    /** Set on a player whose silence is ours, so a crash cannot leave them mute for good (cleared on the next login). */
    private static final String SILENCE_TAG = "hxh_laplace_silenced";

    /** One open domain. */
    static final class Session {
        final UUID owner;
        final int ownerId;
        final ResourceKey<Level> dim;
        final Vec3 center;
        UUID devil, dbl;
        int devilId, dblId;
        /** Everybody inside the dome when it opened (not the user, not their allies). Never changes afterwards. */
        final Set<UUID> affected = new HashSet<>();
        /** The mobs that were hunting the user when it opened: they go on to hunt the double. */
        final Set<UUID> hunters = new HashSet<>();
        boolean wasSilent;
        boolean doubleLost;

        Session(ServerPlayer sp) {
            this.owner = sp.getUUID();
            this.ownerId = sp.getId();
            this.dim = sp.level().dimension();
            this.center = sp.position();
        }
    }

    private static final Map<UUID, Session> SESSIONS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> READY = new ConcurrentHashMap<>();

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    /** True while this player's domain is open (they are hidden from, and cannot hurt, anybody). */
    public static boolean isOpen(Entity e) {
        return e != null && SESSIONS.containsKey(e.getUUID());
    }

    /** Is this entity the Devil or the double of that owner's open domain? Used by the entities to remove themselves when it is gone. */
    public static boolean owns(UUID owner, UUID entity) {
        Session s = SESSIONS.get(owner);
        return s != null && (entity.equals(s.devil) || entity.equals(s.dbl));
    }

    /** True when {@code viewer} was inside this user's dome when it opened (so cannot see or target them). */
    public static boolean isBlindedTo(Entity viewer, Entity user) {
        if (viewer == null || user == null) return false;
        Session s = SESSIONS.get(user.getUUID());
        return s != null && s.affected.contains(viewer.getUUID());
    }

    private static Entity find(MinecraftServer server, ResourceKey<Level> dim, UUID id) {
        if (server == null || id == null) return null;
        ServerLevel l = server.getLevel(dim);
        return l == null ? null : l.getEntity(id);
    }

    private static void msg(ServerPlayer sp, String text) {
        sp.displayClientMessage(Component.literal(text), true);
    }

    // ---------------------------------------------------------------- opening

    /** Called from NenAddonData.setZetsu: Zetsu on opens the domain, Zetsu off closes it. */
    public static void onZetsu(ServerPlayer sp, boolean on) {
        if (!on) {
            end(sp, "\u00a77Laplace Devil: the domain closes", true);
            return;
        }
        Combat c = Combat.get(sp);
        if (!canUse(c)) return;
        if (SESSIONS.containsKey(sp.getUUID())) {
            // a stale record (its Devil is gone, e.g. an earlier failed opening) must not block every later Zetsu
            Session old = SESSIONS.get(sp.getUUID());
            Entity oldDev = find(sp.getServer(), old.dim, old.devil);
            if (oldDev != null && oldDev.isAlive()) return;
            end(sp, null, false);
        }
        if (ExtrasHooks.hatsuForced(sp)) return; // Forced Zetsu is not entered, it is imposed
        if (c.getHatsuLevel() < LaplaceDevilTuning.MIN_LEVEL) {
            msg(sp, "\u00a7cLaplace Devil unlocks at Level " + LaplaceDevilTuning.MIN_LEVEL);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        Long ready = READY.get(sp.getUUID());
        if (ready != null && now < ready) {
            ChainManager.onCooldown(sp, NAME, (int) (ready - now));
            return;
        }
        if (c.getCurrentEnergy() < LaplaceDevilTuning.ACTIVATE_COST) {
            msg(sp, "\u00a7cNot enough energy for the Laplace Devil");
            return;
        }
        c.consumeEnergy(LaplaceDevilTuning.ACTIVATE_COST);
        try {
            open(sp, level);
        } catch (Throwable t) { // never leave a half-open domain behind, and say what went wrong in the log
            com.mojang.logging.LogUtils.getLogger().error("[hxh] Laplace Devil could not open", t);
            end(sp, null, false);
            msg(sp, "\u00a7cThe Laplace Devil could not be conjured");
        }
    }

    private static void open(ServerPlayer sp, ServerLevel level) {
        Session s = new Session(sp);

        // who is inside the dome right now
        double r = LaplaceDevilTuning.RADIUS;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(s.center, s.center).inflate(r), x -> x != sp && x.isAlive())) {
            if (!(e instanceof Mob) && !(e instanceof Player)) continue;
            if (e instanceof LaplaceDoubleEntity) continue;
            if (e.distanceToSqr(s.center) > r * r) continue;
            if (!LaplaceDevilTuning.AFFECT_ALLIES && AllianceUtils.isAlly(e, sp)) continue;
            s.affected.add(e.getUUID());
            if (e instanceof Mob m && m.getTarget() == sp) s.hunters.add(m.getUUID());
        }

        // the double, standing where the user stands
        LaplaceDoubleEntity dbl = HxHEntities.LAPLACE_DOUBLE.get().create(level);
        LaplaceDevilEntity dev = HxHEntities.LAPLACE_DEVIL.get().create(level);
        if (dbl == null || dev == null) {
            msg(sp, "\u00a7cThe Laplace Devil could not be conjured");
            return;
        }
        dbl.copyFrom(sp);
        dbl.moveTo(sp.getX(), sp.getY(), sp.getZ(), sp.getYRot(), sp.getXRot());
        dbl.setYHeadRot(sp.getYHeadRot());
        dbl.yBodyRot = sp.yBodyRot;
        dev.setOwner(sp.getUUID());
        dev.moveTo(sp.getX(), sp.getY() + LaplaceDevilTuning.DEVIL_HEIGHT, sp.getZ(), 0f, 0f);
        s.dbl = dbl.getUUID();
        s.devil = dev.getUUID();
        s.dblId = dbl.getId();
        s.devilId = dev.getId();
        SESSIONS.put(sp.getUUID(), s); // before they join the level: the entities remove themselves if their domain is not on record
        level.addFreshEntity(dev);
        level.addFreshEntity(dbl);
        s.dblId = dbl.getId();
        s.devilId = dev.getId();

        // what was hunting the user now hunts the double
        for (UUID id : s.hunters) if (level.getEntity(id) instanceof Mob m) m.setTarget(dbl);

        // no trace: no sound from the user's steps (or anything else) while the domain is open
        s.wasSilent = sp.isSilent();
        if (!s.wasSilent) {
            sp.setSilent(true);
            sp.getPersistentData().putBoolean(SILENCE_TAG, true);
        }

        level.playSound(null, dev.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.35f, 0.5f);
        msg(sp, "\u00a78Laplace Devil");
        broadcast(sp.getServer(), s, true);
    }

    // ---------------------------------------------------------------- closing

    public static void end(ServerPlayer sp, String message, boolean cooldown) {
        Session s = SESSIONS.remove(sp.getUUID());
        if (s == null) return;
        MinecraftServer server = sp.getServer();
        Entity dbl = find(server, s.dim, s.dbl);
        Entity dev = find(server, s.dim, s.devil);
        ServerLevel level = server == null ? null : server.getLevel(s.dim);
        if (level != null) {
            for (UUID id : s.affected) { // nobody keeps fighting a double that is gone
                if (level.getEntity(id) instanceof Mob m && dbl != null && m.getTarget() == dbl) m.setTarget(null);
            }
            if (dbl != null) level.sendParticles(ParticleTypes.POOF, dbl.getX(), dbl.getY() + 0.9, dbl.getZ(), 12, 0.3, 0.5, 0.3, 0.02);
        }
        if (dbl != null) dbl.discard();
        if (dev != null) dev.discard();
        if (!s.wasSilent) sp.setSilent(false);
        sp.getPersistentData().remove(SILENCE_TAG);
        broadcast(server, s, false);
        if (cooldown) {
            long now = sp.level().getGameTime();
            READY.put(sp.getUUID(), now + LaplaceDevilTuning.COOLDOWN_TICKS);
            ChainManager.startCooldown(sp, NAME, LaplaceDevilTuning.COOLDOWN_TICKS);
        }
        if (message != null) msg(sp, message);
    }

    /** Death, losing or changing the Hatsu, logging out: the domain is simply gone, with no cooldown. */
    public static void clear(Entity e) {
        if (e instanceof ServerPlayer sp) end(sp, null, false);
    }

    public static void reset() {
        SESSIONS.clear();
        READY.clear();
    }

    /** Login: if a crash left the user muted by a domain, they can be heard again. */
    public static void repairOnLogin(ServerPlayer sp) {
        if (sp.getPersistentData().getBoolean(SILENCE_TAG)) {
            sp.setSilent(false);
            sp.getPersistentData().remove(SILENCE_TAG);
        }
    }

    // ---------------------------------------------------------------- every tick

    public static void tick(ServerPlayer sp) {
        Session s = SESSIONS.get(sp.getUUID());
        if (s == null) return;
        NenAddonData d = NenAddonData.peek(sp);
        Combat c = Combat.get(sp);
        if (!sp.isAlive() || d == null || !d.zetsu || !sp.level().dimension().equals(s.dim)) {
            end(sp, "\u00a77Laplace Devil: the domain closes", true);
            return;
        }
        if (!canUse(c)) {
            end(sp, null, false);
            return;
        }
        MinecraftServer server = sp.getServer();
        ServerLevel level = server == null ? null : server.getLevel(s.dim);
        if (level == null) return;
        Entity dev = level.getEntity(s.devil);
        if (dev == null || !dev.isAlive()) {
            end(sp, "\u00a77Laplace Devil: the domain collapses", true);
            return;
        }
        Entity dbl = level.getEntity(s.dbl);
        if ((dbl == null || !dbl.isAlive()) && !s.doubleLost) {
            s.doubleLost = true;
            msg(sp, "\u00a78Your double has fallen");
            if (LaplaceDevilTuning.ENDS_WHEN_DOUBLE_DIES) {
                end(sp, "\u00a77Laplace Devil: the domain collapses", true);
                return;
            }
        }

        // upkeep
        if (LaplaceDevilTuning.UPKEEP_PER_SECOND > 0f && sp.tickCount % 20 == 0) {
            c.consumeEnergy(LaplaceDevilTuning.UPKEEP_PER_SECOND);
            if (c.getCurrentEnergy() <= 0f) {
                end(sp, "\u00a7cLaplace Devil: out of energy", true);
                return;
            }
        }

        // the affected cannot hunt the real user
        if (sp.tickCount % 5 == 0) {
            boolean draw = LaplaceDevilTuning.DOUBLE_DRAWS_HOSTILES && sp.tickCount % 20 == 0 && dbl instanceof LivingEntity dl && dl.isAlive();
            double range = LaplaceDevilTuning.DOUBLE_DRAW_RANGE;
            for (UUID id : s.affected) {
                if (!(level.getEntity(id) instanceof Mob m) || !m.isAlive()) continue;
                if (m.getTarget() == sp) m.setTarget(s.hunters.contains(id) && !s.doubleLost ? (LivingEntity) dbl : null);
                if (m.getLastHurtByMob() == sp) m.setLastHurtByMob(null);
                if (draw && m.getTarget() == null && m instanceof Enemy && dbl.distanceToSqr(m) <= range * range && m.hasLineOfSight(dbl)) {
                    m.setTarget((LivingEntity) dbl);
                }
            }
        }
    }

    // ---------------------------------------------------------------- telling clients

    private static void broadcast(MinecraftServer server, Session s, boolean active) {
        if (server == null) return;
        for (ServerPlayer viewer : server.getPlayerList().getPlayers()) {
            if (active && !viewer.level().dimension().equals(s.dim)) continue;
            AddonNetwork.sendToPlayer(new PacketLaplaceFx(s.ownerId, s.dblId, s.devilId, active, s.affected.contains(viewer.getUUID())), viewer);
        }
    }

    /** A player comes into view of the user, the Devil or the double: tell them whether they are inside the dome. */
    public static void sendTo(ServerPlayer viewer, Entity target) {
        UUID owner = null;
        if (target instanceof LaplaceDevilEntity dv) owner = dv.getOwnerId();
        else if (target instanceof LaplaceDoubleEntity db) owner = db.ownerId();
        else if (target instanceof Player p) owner = p.getUUID();
        Session s = owner == null ? null : SESSIONS.get(owner);
        if (s == null) return;
        AddonNetwork.sendToPlayer(new PacketLaplaceFx(s.ownerId, s.dblId, s.devilId, true, s.affected.contains(viewer.getUUID())), viewer);
    }
}
