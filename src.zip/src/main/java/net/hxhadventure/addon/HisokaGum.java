package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.entity.PartEntity;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketCardFx;
import net.hxhadventure.addon.network.PacketGumFx;
import org.joml.Vector3f;
import org.jetbrains.annotations.Nullable;

/**
 * Hisoka's Bungee Gum, run by the NPC. It is the player ability ({@link BungeeGum}, {@link GumCards}) with the same numbers
 * from {@link Tuning} (costs, ranges, damage, cooldowns, the build-up and tether of "Properties of Rubber and Gum"), and it
 * draws with the same client effects (the thread, the tether, the cards), so it looks and behaves like a player's.
 *
 *  - Thread: thrown at his target. Stuck to it from a distance he pulls himself in; close enough he reels it in, swings it
 *    round him and smashes it down in front of him.
 *  - Tether Pull: a target carrying his gum is dragged to him and hit hard.
 *  - Cards: three nen-coated cards from mid range.
 * Each move is paid from his aura and obeys its normal cooldown. Nothing works while he has no aura (or a Forced Zetsu).
 */
final class HisokaGum {
    private enum Phase { FLYING, ATTACHED, REEL, SELF_PULL }

    private enum Reel { PULL, SPIN, LIFT, SLAM }

    private static final class Rope {
        Phase phase = Phase.FLYING;
        Vec3 tip = Vec3.ZERO;
        Vec3 dir = Vec3.ZERO;
        int age;
        UUID entity;
        Reel reel = Reel.PULL;
        int reelTicks;
        int pullTicks;
        double angle;
        Vec3 slamTop = Vec3.ZERO;
        Vec3 slamGround = Vec3.ZERO;
        final Map<Integer, Integer> sweptAt = new HashMap<>();
    }

    private static final class Yank {
        UUID target;
        int ticks;
    }

    private static final class Mark {
        float meter;
        long lastHit;
        int stage = -1;
    }

    private static final class Card {
        int id;
        Vec3 pos = Vec3.ZERO;
        Vec3 vel = Vec3.ZERO;
        int age;
    }

    private static final DustParticleOptions PINK = new DustParticleOptions(new Vector3f(0.92f, 0.42f, 0.84f), 1.1f);
    private static final DustParticleOptions SPARK = new DustParticleOptions(new Vector3f(0.91f, 0.55f, 0.83f), 0.8f);
    private static final int ATTACH_DELAY_TICKS = 4;   // the thread is seen to stick before he does anything with it
    private static final double FAR = 10.0;            // further than this from a stuck target he pulls himself in instead of reeling it
    private static int nextCardId = 1;

    private final HisokaEntity npc;
    private Rope rope;
    private Yank yank;
    private long readyAt, yankReadyAt, cardsReadyAt;
    private boolean cardsSent;
    private final Map<UUID, Mark> marks = new HashMap<>();
    private final Map<UUID, Long> lastMelee = new HashMap<>();
    private final List<Card> cards = new ArrayList<>();
    /** True while this class is itself hurting someone, so the melee hook does not count that hit a second time. */
    boolean selfHurt;

    HisokaGum(HisokaEntity npc) {
        this.npc = npc;
    }

    /** He is busy with the gum (the thread is reeling, dragging him, or a target is being dragged to him): no punching, no walking. */
    boolean busy() {
        return yank != null || (rope != null && (rope.phase == Phase.REEL || rope.phase == Phase.SELF_PULL));
    }

    // =====================================================================================================
    // per tick
    // =====================================================================================================

    void tick(@Nullable LivingEntity target) {
        if (!(npc.level() instanceof ServerLevel level)) return;
        boolean nenOk = npc.isAlive() && npc.canUseNen();
        if (!nenOk) {
            if (rope != null) release();
            if (yank != null) endYank(0);
        } else {
            tickYank(level);
            if (rope != null) {
                switch (rope.phase) {
                    case FLYING -> tickFlying(level);
                    case ATTACHED -> tickAttached(level);
                    case REEL -> tickReel(level);
                    case SELF_PULL -> tickSelfPull(level);
                }
            }
        }
        tickCards(level);
        tickMarks(level);
        if (nenOk && target != null && rope == null && yank == null) think(level, target);
    }

    /** Decides whether to use a gum move this tick (called while he has a target and nothing is out). */
    private void think(ServerLevel level, LivingEntity target) {
        if (npc.isAttacking()) return; // never cut a barrage or a charge short
        long now = level.getGameTime();
        double dist = npc.distanceTo(target);
        boolean los = npc.hasLineOfSight(target);
        var rnd = npc.getRandom();

        Mark m = marks.get(target.getUUID());
        if (m != null && m.stage >= 0 && now >= yankReadyAt && dist > 4.5 && dist <= Tuning.GUM_TETHER_RANGE && rnd.nextInt(8) == 0) {
            if (startYank(level, target)) return;
        }
        if (now >= readyAt && los && dist >= 2.5 && dist <= Tuning.GUM_RANGE - 2.0 && rnd.nextInt(dist < 4.0 ? 40 : 12) == 0) {
            fire(level, target);
            return;
        }
        if (now >= cardsReadyAt && los && dist >= 5.0 && dist <= 24.0 && rnd.nextInt(14) == 0) {
            throwCards(level, target);
        }
    }

    // =====================================================================================================
    // the thread
    // =====================================================================================================

    private void fire(ServerLevel level, LivingEntity target) {
        if (!npc.payAura(Tuning.GUM_THROW_COST)) return;
        Rope r = new Rope();
        Vec3 eye = npc.getEyePosition();
        r.dir = BungeeGum.centerOf(target).subtract(eye).normalize();
        r.tip = eye.add(r.dir.scale(0.6));
        rope = r;
        npc.swing(InteractionHand.MAIN_HAND, true);
        npc.triggerPunchAnim();
        level.playSound(null, npc.blockPosition(), SoundEvents.FISHING_BOBBER_THROW, SoundSource.HOSTILE, 1.2f, 0.7f);
        level.playSound(null, npc.blockPosition(), SoundEvents.SLIME_BLOCK_PLACE, SoundSource.HOSTILE, 1.0f, 1.5f);
        sendThread(-1, r.tip);
    }

    private void tickFlying(ServerLevel level) {
        Rope r = rope;
        r.age++;
        Vec3 from = r.tip;
        Vec3 to = from.add(r.dir.scale(Tuning.GUM_SPEED));
        HitResult wall = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, npc));
        Vec3 end = wall.getType() == HitResult.Type.MISS ? to : wall.getLocation();
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(level, npc, from, end, new AABB(from, end).inflate(0.6), this::grabbable);
        if (eh != null) {
            attach(level, r, eh.getEntity(), eh.getLocation());
            return;
        }
        if (wall instanceof BlockHitResult && wall.getType() == HitResult.Type.BLOCK) { // he does not tear the world up: the thread just peels off the wall
            stickFx(level, wall.getLocation());
            finish(Tuning.GUM_MISS_COOLDOWN_TICKS);
            return;
        }
        r.tip = to;
        if (r.tip.distanceToSqr(npc.getEyePosition()) > Tuning.GUM_RANGE * Tuning.GUM_RANGE) {
            finish(Tuning.GUM_MISS_COOLDOWN_TICKS);
            return;
        }
        sendThread(-1, r.tip);
    }

    private boolean grabbable(Entity e) {
        return npc.isFoe(e) && !(e instanceof PartEntity<?>) && e.isPickable();
    }

    private void attach(ServerLevel level, Rope r, Entity e, Vec3 at) {
        r.phase = Phase.ATTACHED;
        r.entity = e.getUUID();
        r.age = 0;
        sendThread(e.getId(), at);
        stickFx(level, at);
        if (e instanceof LivingEntity le) addBuildup(le, Tuning.GUM_BUILDUP_THREAD);
    }

    private void stickFx(ServerLevel level, Vec3 at) {
        level.sendParticles(PINK, at.x, at.y, at.z, 14, 0.25, 0.25, 0.25, 0.03);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.SLIME_BLOCK_HIT, SoundSource.HOSTILE, 1.2f, 1.1f);
    }

    /** The thread is stuck to something: after a beat he picks what to do with it. */
    private void tickAttached(ServerLevel level) {
        Rope r = rope;
        r.age++;
        Entity obj = r.entity == null ? null : level.getEntity(r.entity);
        if (obj == null || !obj.isAlive() || obj.level() != level) {
            finish(Tuning.GUM_MISS_COOLDOWN_TICKS);
            return;
        }
        Vec3 end = BungeeGum.centerOf(obj);
        if (r.age > Tuning.GUM_HOLD_TICKS || end.distanceToSqr(npc.getEyePosition()) > Tuning.GUM_SNAP_LENGTH * Tuning.GUM_SNAP_LENGTH) {
            finish(Tuning.GUM_MISS_COOLDOWN_TICKS);
            return;
        }
        npc.getNavigation().stop();
        if (r.age < ATTACH_DELAY_TICKS) return;
        double d = npc.distanceTo(obj);
        boolean can = movable(obj);
        if (d > FAR) {
            if (startSelfPull(level, r)) return;
            if (can && startReel(level, r, obj)) return;
        } else {
            if (can && startReel(level, r, obj)) return;
            if (d > 4.0 && startSelfPull(level, r)) return;
        }
        finish(Tuning.GUM_MISS_COOLDOWN_TICKS); // could not afford either
    }

    private static boolean movable(Entity e) {
        return !(e instanceof EnderDragon) && !(e instanceof WitherBoss) && !(e instanceof PartEntity<?>);
    }

    // ---- reel in, spin, slam ----

    private boolean startReel(ServerLevel level, Rope r, Entity obj) {
        if (!npc.payAura(Tuning.GUM_REEL_COST)) return false;
        if (obj.isPassenger()) obj.stopRiding();
        r.phase = Phase.REEL;
        r.reel = Reel.PULL;
        r.reelTicks = 0;
        Vec3 rel = BungeeGum.centerOf(obj).subtract(npc.position());
        r.angle = Math.atan2(rel.z, rel.x); // join the orbit from the side the object is already on
        sendThread(obj.getId(), BungeeGum.centerOf(obj));
        npc.swing(InteractionHand.MAIN_HAND, true);
        level.playSound(null, npc.blockPosition(), SoundEvents.SLIME_BLOCK_STEP, SoundSource.HOSTILE, 1.5f, 0.6f);
        return true;
    }

    private void tickReel(ServerLevel level) {
        Rope r = rope;
        Entity obj = r.entity == null ? null : level.getEntity(r.entity);
        if (obj == null || !obj.isAlive() || obj.level() != level) {
            finish(Tuning.GUM_MISS_COOLDOWN_TICKS);
            return;
        }
        npc.getNavigation().stop();
        npc.getLookControl().setLookAt(obj, 60f, 60f);
        r.reelTicks++;
        Vec3 center = npc.position().add(0, npc.getBbHeight() * 0.5, 0);
        switch (r.reel) {
            case PULL -> {
                Vec3 want = orbit(center, r.angle);
                steer(obj, want, 3.0, 0.35);
                if (BungeeGum.centerOf(obj).distanceToSqr(want) < 4.0 || r.reelTicks > Tuning.GUM_PULL_IN_MAX_TICKS) {
                    r.reel = Reel.SPIN;
                    r.reelTicks = 0;
                    level.playSound(null, npc.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 1.2f, 0.6f);
                }
            }
            case SPIN -> {
                r.angle += Tuning.GUM_SPIN_SPEED;
                steer(obj, orbit(center, r.angle), Tuning.GUM_SPIN_FOLLOW_SPEED, 1.0);
                spinHits(r, obj, level);
                if (r.reelTicks % 8 == 0) {
                    level.playSound(null, npc.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 0.8f, 0.5f);
                }
                if (r.reelTicks >= Tuning.GUM_SPIN_TICKS) {
                    planSlam(r, level);
                    r.reel = Reel.LIFT;
                    r.reelTicks = 0;
                }
            }
            case LIFT -> {
                steer(obj, r.slamTop, 3.2, 0.6);
                if (r.reelTicks >= Tuning.GUM_LIFT_TICKS || BungeeGum.centerOf(obj).distanceToSqr(r.slamTop) < 2.25) {
                    r.reel = Reel.SLAM;
                    r.reelTicks = 0;
                    level.playSound(null, npc.blockPosition(), SoundEvents.SLIME_BLOCK_FALL, SoundSource.HOSTILE, 1.4f, 0.5f);
                }
            }
            case SLAM -> {
                Vec3 down = r.slamGround.add(0, obj.getBbHeight() * 0.5, 0);
                steer(obj, down, Tuning.GUM_SLAM_SPEED, 1.0);
                if (BungeeGum.centerOf(obj).distanceToSqr(down) < 2.25 || r.reelTicks > 25) impact(r, obj, level);
            }
        }
    }

    private static Vec3 orbit(Vec3 center, double angle) {
        return center.add(Math.cos(angle) * Tuning.GUM_ORBIT_RADIUS, 0.3, Math.sin(angle) * Tuning.GUM_ORBIT_RADIUS);
    }

    /** Picks where the object goes up to and where it will land: straight in front of him. */
    private void planSlam(Rope r, ServerLevel level) {
        Vec3 look = npc.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1.0e-4 ? new Vec3(0, 0, 1) : flat.normalize();
        Vec3 base = npc.position().add(flat.scale(Tuning.GUM_SLAM_DISTANCE));
        Vec3 low = new Vec3(base.x, npc.getY() + 0.5, base.z);
        HitResult ceiling = level.clip(new ClipContext(low, low.add(0, Tuning.GUM_SLAM_HEIGHT, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, npc));
        r.slamTop = ceiling.getType() == HitResult.Type.MISS ? low.add(0, Tuning.GUM_SLAM_HEIGHT, 0) : ceiling.getLocation().add(0, -0.8, 0);
        HitResult floor = level.clip(new ClipContext(r.slamTop, r.slamTop.add(0, -(Tuning.GUM_SLAM_HEIGHT + 10), 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, npc));
        r.slamGround = floor.getType() == HitResult.Type.MISS ? new Vec3(base.x, npc.getY(), base.z) : floor.getLocation();
    }

    /** Anything else the spinning object sweeps into takes a hit and is flung outwards. */
    private void spinHits(Rope r, Entity obj, ServerLevel level) {
        double reach = Tuning.GUM_SPIN_HIT_RADIUS + obj.getBbWidth() * 0.5;
        Vec3 oc = BungeeGum.centerOf(obj);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(oc, oc).inflate(reach + 1.5))) {
            if (e == obj || !npc.isFoe(e)) continue;
            double lim = reach + e.getBbWidth() * 0.5;
            if (BungeeGum.centerOf(e).distanceToSqr(oc) > lim * lim) continue;
            Integer last = r.sweptAt.get(e.getId());
            if (last != null && npc.tickCount - last < Tuning.GUM_SPIN_HIT_GAP) continue;
            r.sweptAt.put(e.getId(), npc.tickCount);
            Vec3 out = BungeeGum.centerOf(e).subtract(npc.position().add(0, npc.getBbHeight() * 0.5, 0));
            out = out.lengthSqr() < 1.0e-4 ? new Vec3(0, 0, 1) : out.normalize();
            hurt(e, Tuning.GUM_SPIN_DAMAGE + HisokaTuning.HATSU_LEVEL * Tuning.GUM_DAMAGE_PER_LEVEL, new Vec3(out.x * 0.9, 0.3, out.z * 0.9), Tuning.GUM_BUILDUP_SPIN);
            level.sendParticles(PINK, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 8, 0.3, 0.3, 0.3, 0.02);
            level.playSound(null, e.blockPosition(), SoundEvents.SLIME_BLOCK_HIT, SoundSource.HOSTILE, 1.0f, 0.8f);
        }
    }

    private void impact(Rope r, Entity obj, ServerLevel level) {
        Vec3 at = r.slamGround;
        float base = Tuning.GUM_SLAM_DAMAGE + HisokaTuning.HATSU_LEVEL * Tuning.GUM_DAMAGE_PER_LEVEL;
        double radius = Tuning.GUM_SLAM_RADIUS;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(radius + 2.0))) {
            if (!npc.isFoe(e)) continue;
            double dist = e.position().distanceTo(at);
            if (dist > radius + e.getBbWidth() * 0.5) continue;
            float falloff = (float) (1.0 - 0.5 * Math.min(1.0, dist / radius)); // 100% at the centre, 50% at the edge
            Vec3 out = e.position().subtract(at);
            out = new Vec3(out.x, 0, out.z);
            out = out.lengthSqr() < 1.0e-4 ? Vec3.ZERO : out.normalize();
            double kb = Tuning.GUM_SLAM_KNOCKBACK * falloff;
            hurt(e, base * falloff, new Vec3(out.x * kb, 0.5 + 0.3 * falloff, out.z * kb), Tuning.GUM_BUILDUP_SLAM);
        }
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y + 0.3, at.z, 4, radius * 0.3, 0.2, radius * 0.3, 0);
        level.sendParticles(PINK, at.x, at.y + 0.4, at.z, 70, radius * 0.4, 0.3, radius * 0.4, 0.06);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.3f, 1.5f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 1.0f, 0.6f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.SLIME_BLOCK_BREAK, SoundSource.HOSTILE, 1.5f, 0.7f);
        obj.setDeltaMovement(Vec3.ZERO);
        obj.hurtMarked = true;
        finish(Tuning.GUM_SLAM_COOLDOWN_TICKS);
    }

    // ---- pull himself to what the thread is stuck to ----

    private boolean startSelfPull(ServerLevel level, Rope r) {
        if (!npc.payAura(Tuning.GUM_PULL_COST)) return false;
        r.phase = Phase.SELF_PULL;
        r.pullTicks = 0;
        level.playSound(null, npc.blockPosition(), SoundEvents.SLIME_BLOCK_STEP, SoundSource.HOSTILE, 1.5f, 1.4f);
        return true;
    }

    private void tickSelfPull(ServerLevel level) {
        Rope r = rope;
        Entity stuckTo = r.entity == null ? null : level.getEntity(r.entity);
        if (stuckTo == null || !stuckTo.isAlive() || stuckTo.level() != level) {
            finish(Tuning.GUM_PULL_COOLDOWN_TICKS);
            return;
        }
        r.pullTicks++;
        npc.getNavigation().stop();
        npc.getLookControl().setLookAt(stuckTo, 60f, 60f);
        Vec3 me = npc.position().add(0, npc.getBbHeight() * 0.5, 0);
        Vec3 d = BungeeGum.centerOf(stuckTo).subtract(me);
        double dist = d.length();
        double stop = 1.8 + stuckTo.getBbWidth() * 0.5;
        if (dist <= stop || r.pullTicks > Tuning.GUM_PULL_MAX_TICKS) {
            npc.setDeltaMovement(npc.getDeltaMovement().scale(0.25)); // arrive without flying straight on past it
            npc.fallDistance = 0f;
            npc.hurtMarked = true;
            finish(Tuning.GUM_PULL_COOLDOWN_TICKS);
            return;
        }
        double speed = Math.min(Tuning.GUM_PULL_SPEED, Tuning.GUM_PULL_START_SPEED + r.pullTicks * Tuning.GUM_PULL_RAMP); // snaps tight, then accelerates
        Vec3 v = d.scale(speed / dist);
        npc.setDeltaMovement(v.x, v.y + 0.04, v.z);
        npc.fallDistance = 0f;
        npc.hurtMarked = true;
    }

    // =====================================================================================================
    // Tether Pull
    // =====================================================================================================

    private boolean startYank(ServerLevel level, LivingEntity target) {
        if (!npc.payAura(Tuning.GUM_YANK_COST)) return false;
        Yank y = new Yank();
        y.target = target.getUUID();
        yank = y;
        if (target.isPassenger()) target.stopRiding();
        sendThread(target.getId(), BungeeGum.centerOf(target)); // the tether lights up as a full thread while it drags
        npc.swing(InteractionHand.MAIN_HAND, true);
        npc.triggerPunchAnim();
        level.playSound(null, npc.blockPosition(), SoundEvents.SLIME_BLOCK_STEP, SoundSource.HOSTILE, 1.5f, 0.5f);
        return true;
    }

    private void tickYank(ServerLevel level) {
        if (yank == null) return;
        Entity t = level.getEntity(yank.target);
        if (!(t instanceof LivingEntity victim) || !victim.isAlive() || victim.level() != level) {
            endYank(Tuning.GUM_MISS_COOLDOWN_TICKS);
            return;
        }
        yank.ticks++;
        npc.getNavigation().stop();
        npc.getLookControl().setLookAt(victim, 60f, 60f);
        Vec3 spot = BungeeGum.centerOf(npc).add(npc.getLookAngle().scale(2.0)); // right in front of his face
        steer(victim, spot, 3.4, 0.5);
        if (BungeeGum.centerOf(victim).distanceToSqr(spot) < 2.5 || yank.ticks > Tuning.GUM_YANK_MAX_TICKS) {
            Vec3 dir = victim.position().subtract(npc.position());
            dir = new Vec3(dir.x, 0, dir.z);
            dir = dir.lengthSqr() < 1.0e-4 ? npc.getLookAngle() : dir.normalize();
            float dmg = Tuning.GUM_YANK_DAMAGE + HisokaTuning.HATSU_LEVEL * Tuning.GUM_YANK_PER_LEVEL;
            hurt(victim, dmg, new Vec3(dir.x * Tuning.GUM_YANK_KNOCKBACK, 0.55, dir.z * Tuning.GUM_YANK_KNOCKBACK), Tuning.GUM_BUILDUP_YANK);
            Vec3 at = BungeeGum.centerOf(victim);
            level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 3, 0.3, 0.3, 0.3, 0);
            level.sendParticles(PINK, at.x, at.y, at.z, 40, 0.5, 0.5, 0.5, 0.08);
            level.playSound(null, at.x, at.y, at.z, SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, 1.5f, 0.6f);
            level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.0f, 1.6f);
            endYank(HisokaTuning.YANK_COOLDOWN_TICKS); // players' Tether Pull has no cooldown now; his keeps the old one
        }
    }

    private void endYank(int cooldownTicks) {
        yank = null;
        AddonNetwork.sendToTrackingAndSelf(PacketGumFx.threadOff(npc.getId()), npc);
        if (cooldownTicks > 0) yankReadyAt = npc.level().getGameTime() + HisokaTuning.gumCooldown(cooldownTicks);
    }

    // =====================================================================================================
    // Cards (three straight cards)
    // =====================================================================================================

    private void throwCards(ServerLevel level, LivingEntity target) {
        if (!npc.payAura(Tuning.CARD_COST)) return;
        Vec3 eye = npc.getEyePosition();
        Vec3 look = BungeeGum.centerOf(target).subtract(eye).normalize();
        for (int i = -1; i <= 1; i++) {
            Vec3 d = rotY(look, Math.toRadians(Tuning.CARD_SPREAD_DEG) * i);
            Card k = new Card();
            k.id = nextCardId++;
            k.pos = eye.add(d.scale(0.9)).add(0, -0.25, 0);
            k.vel = d.scale(Tuning.CARD_SPEED);
            cards.add(k);
        }
        npc.swing(InteractionHand.MAIN_HAND, true);
        npc.triggerPunchAnim();
        level.playSound(null, npc.blockPosition(), SoundEvents.ARROW_SHOOT, SoundSource.HOSTILE, 0.8f, 1.9f);
        level.playSound(null, npc.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 0.8f, 1.6f);
        cardsReadyAt = level.getGameTime() + HisokaTuning.gumCooldown(Tuning.CARD_COOLDOWN_TICKS);
    }

    private void tickCards(ServerLevel level) {
        if (cards.isEmpty()) {
            if (cardsSent) {
                cardsSent = false;
                AddonNetwork.sendToTrackingAndSelf(new PacketCardFx(npc.getId(), new int[0], new float[0]), npc);
            }
            return;
        }
        Iterator<Card> it = cards.iterator();
        while (it.hasNext()) {
            Card k = it.next();
            k.age++;
            if (k.age > Tuning.CARD_LIFE) {
                it.remove();
                continue;
            }
            Vec3 from = k.pos;
            Vec3 to = from.add(k.vel);
            HitResult wall = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, npc));
            Vec3 end = wall.getType() == HitResult.Type.MISS ? to : wall.getLocation();
            EntityHitResult eh = ProjectileUtil.getEntityHitResult(level, npc, from, end, new AABB(from, end).inflate(0.5), t -> t instanceof LivingEntity && npc.isFoe(t));
            if (eh != null && eh.getEntity() instanceof LivingEntity victim) {
                hurt(victim, Tuning.CARD_DAMAGE + HisokaTuning.HATSU_LEVEL * Tuning.CARD_DAMAGE_PER_LEVEL, Vec3.ZERO, Tuning.GUM_BUILDUP_CARD);
                sparks(level, eh.getLocation());
                it.remove();
            } else if (wall.getType() == HitResult.Type.BLOCK) {
                sparks(level, wall.getLocation());
                it.remove();
            } else {
                k.pos = to;
            }
        }
        int n = Math.min(cards.size(), 64);
        int[] ids = new int[n];
        float[] d = new float[n * 6];
        for (int i = 0; i < n; i++) {
            Card k = cards.get(i);
            ids[i] = k.id;
            d[i * 6] = (float) k.pos.x;
            d[i * 6 + 1] = (float) k.pos.y;
            d[i * 6 + 2] = (float) k.pos.z;
            d[i * 6 + 3] = (float) k.vel.x;
            d[i * 6 + 4] = (float) k.vel.y;
            d[i * 6 + 5] = (float) k.vel.z;
        }
        cardsSent = true;
        AddonNetwork.sendToTrackingAndSelf(new PacketCardFx(npc.getId(), ids, d), npc);
    }

    private static void sparks(ServerLevel level, Vec3 at) {
        level.sendParticles(SPARK, at.x, at.y, at.z, 4, 0.12, 0.12, 0.12, 0.02);
    }

    private static Vec3 rotY(Vec3 v, double a) {
        double cos = Math.cos(a);
        double sin = Math.sin(a);
        return new Vec3(v.x * cos + v.z * sin, v.y, -v.x * sin + v.z * cos);
    }

    // =====================================================================================================
    // helpers
    // =====================================================================================================

    /** Steers an object towards a point (by its centre) by setting its velocity. */
    private static void steer(Entity e, Vec3 target, double maxSpeed, double gain) {
        if (e instanceof LivingEntity) BungeeGum.markDrawn(e); // being dragged in: cannot attack
        Vec3 d = target.subtract(BungeeGum.centerOf(e));
        double len = d.length();
        Vec3 v = len < 1.0e-4 ? Vec3.ZERO : d.scale(Math.min(maxSpeed, len * gain) / len);
        e.setDeltaMovement(v);
        e.hurtMarked = true;
        e.fallDistance = 0f;
        if (e instanceof ServerPlayer p) p.connection.send(new ClientboundSetEntityMotionPacket(p));
        if (e instanceof Mob m) m.getNavigation().stop();
    }

    /** Damage from his gum, counted towards the debuff by the caller rather than by the melee hook. */
    private void hurt(LivingEntity e, float damage, Vec3 push, float buildup) {
        selfHurt = true;
        try {
            Vows.hatsuHurt(e, npc.damageSources().mobAttack(npc), damage); // a Hatsu hit: Ten / Ren / Ken do not multiply it
        } finally {
            selfHurt = false;
        }
        e.push(push.x, push.y, push.z);
        e.hurtMarked = true;
        addBuildup(e, buildup);
    }

    private void sendThread(int targetEntity, Vec3 point) {
        AddonNetwork.sendToTrackingAndSelf(PacketGumFx.thread(npc.getId(), targetEntity, point), npc);
    }

    /** Ends the thread and sets its cooldown. */
    private void finish(int cooldownTicks) {
        release();
        if (cooldownTicks > 0) readyAt = npc.level().getGameTime() + HisokaTuning.gumCooldown(cooldownTicks);
    }

    /** Drops the thread without a cooldown. */
    void release() {
        if (rope == null) return;
        rope = null;
        AddonNetwork.sendToTrackingAndSelf(PacketGumFx.threadOff(npc.getId()), npc);
    }

    // =====================================================================================================
    // "Properties of Rubber and Gum"
    // =====================================================================================================

    /** Called for every melee hit he lands (by the damage event): his punches stick a little more gum on the victim. */
    void onMeleeHit(LivingEntity victim) {
        if (selfHurt || !npc.canUseNen()) return;
        long now = victim.level().getGameTime();
        Long last = lastMelee.get(victim.getUUID());
        if (last != null && now - last < 10) return; // one count per invulnerability window, so a barrage is not worth ten punches at once
        lastMelee.put(victim.getUUID(), now);
        addBuildup(victim, Tuning.GUM_BUILDUP_MELEE);
    }

    private void addBuildup(LivingEntity victim, float amount) {
        if (victim == npc || !victim.isAlive() || victim instanceof ArmorStand || !npc.isFoe(victim)) return;
        Mark m = marks.computeIfAbsent(victim.getUUID(), k -> new Mark());
        m.meter = Math.min(Tuning.GUM_BUILDUP_MAX, m.meter + amount);
        m.lastHit = victim.level().getGameTime();
    }

    private static int stageOf(float meter) {
        for (int i = Tuning.GUM_STAGES.length - 1; i >= 0; i--) {
            if (meter >= Tuning.GUM_STAGES[i]) return i;
        }
        return -1;
    }

    /** Grows / drains the build-up, applies the debuff, and keeps tethered victims on their leash. */
    private void tickMarks(ServerLevel level) {
        if (marks.isEmpty()) {
            if (!lastMelee.isEmpty() && npc.tickCount % 200 == 0) lastMelee.clear();
            return;
        }
        Iterator<Map.Entry<UUID, Mark>> it = marks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Mark> en = it.next();
            Mark m = en.getValue();
            Entity ve = level.getEntity(en.getKey());
            if (!(ve instanceof LivingEntity victim) || !victim.isAlive() || !npc.isAlive()) {
                if (ve instanceof LivingEntity gone) lift(gone);
                it.remove();
                continue;
            }
            long t = level.getGameTime();
            if (t - m.lastHit > Tuning.GUM_DECAY_DELAY_TICKS && t % 20 == 0) m.meter -= Tuning.GUM_DECAY_PER_SECOND;
            if (m.meter <= 0f) {
                lift(victim);
                it.remove();
                continue;
            }
            int stage = stageOf(m.meter);
            if (stage != m.stage) {
                boolean first = m.stage < 0;
                m.stage = stage;
                if (stage < 0) {
                    lift(victim);
                    continue;
                }
                HatsuEffects.applyGum(victim, 60, stage, true);
                AddonNetwork.sendToTrackingAndSelf(PacketGumFx.tether(victim.getId(), npc.getId(), stage), victim);
                if (first && victim instanceof ServerPlayer vp) {
                    vp.displayClientMessage(Component.literal("\u00a7dSomething sticky is clinging to you..."), true);
                }
            }
            if (stage < 0) continue;
            if (t % 10 == 0) HatsuEffects.applyGum(victim, 60, stage, true);
            if (t % 100 == 0) AddonNetwork.sendToTrackingAndSelf(PacketGumFx.tether(victim.getId(), npc.getId(), stage), victim);
            tether(victim);
        }
    }

    /** The leash: the victim cannot move further from him than the tether range; the gum stretches, then pulls them back. */
    private void tether(LivingEntity victim) {
        Vec3 cv = BungeeGum.centerOf(npc);
        Vec3 out = BungeeGum.centerOf(victim).subtract(cv);
        double dist = out.length();
        double range = Tuning.GUM_TETHER_RANGE;
        if (dist <= range || dist < 1.0e-4) return;
        Vec3 outDir = out.scale(1.0 / dist);
        double over = dist - range;
        if (over > Tuning.GUM_TETHER_SNAP_OVER) { // flung, pearled or teleported far out: snapped straight back to the end of the leash
            Vec3 to = npc.position().add(outDir.x * (range - 1.0), 0, outDir.z * (range - 1.0));
            if (victim instanceof ServerPlayer vp) vp.connection.teleport(to.x, npc.getY(), to.z, vp.getYRot(), vp.getXRot());
            else victim.moveTo(to.x, npc.getY(), to.z, victim.getYRot(), victim.getXRot());
            return;
        }
        Vec3 v = victim.getDeltaMovement();
        double outward = v.dot(outDir);
        if (outward > 0) v = v.subtract(outDir.scale(outward)); // no momentum carries them further out
        v = v.subtract(outDir.scale(Math.min(1.5, 0.12 + over * 0.2))); // the harder they strain, the harder it pulls
        victim.setDeltaMovement(v);
        victim.hurtMarked = true;
        if (victim instanceof ServerPlayer vp) vp.connection.send(new ClientboundSetEntityMotionPacket(vp));
        if (victim instanceof Mob mob) mob.getNavigation().stop();
    }

    private static void lift(LivingEntity victim) {
        HatsuEffects.removeGum(victim);
        AddonNetwork.sendToTrackingAndSelf(PacketGumFx.tetherOff(victim.getId()), victim);
    }

    private static Entity find(MinecraftServer server, UUID id) {
        for (ServerLevel l : server.getAllLevels()) {
            Entity e = l.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    /** Death / removal: the thread, the cards and every victim's debuff from his gum go. */
    void clear() {
        if (rope != null) release();
        if (yank != null) endYank(0);
        if (!cards.isEmpty() || cardsSent) {
            cards.clear();
            cardsSent = false;
            AddonNetwork.sendToTrackingAndSelf(new PacketCardFx(npc.getId(), new int[0], new float[0]), npc);
        }
        MinecraftServer server = npc.getServer();
        for (UUID id : marks.keySet()) {
            if (server != null && find(server, id) instanceof LivingEntity victim) lift(victim);
        }
        marks.clear();
        lastMelee.clear();
    }
}
