package net.hxhadventure.addon;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;

/** Aggro on the nearest other contestant or player (no line of sight needed), once the grace period after spawning is over. */
final class ExamFightGoal extends NearestAttackableTargetGoal<LivingEntity> {
    /** Ticks after spawning in which they do not pick a fight on their own, so the player can read Menchi's start. */
    static final int GRACE_TICKS = 60;

    ExamFightGoal(Mob mob) {
        super(mob, LivingEntity.class, 5, false, false, e -> e instanceof ExamContestant || e instanceof Player);
    }

    @Override
    public boolean canUse() {
        return mob.tickCount >= GRACE_TICKS && super.canUse();
    }
}
