package net.hxhadventure.addon;

import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Forge hooks for {@link GonVow} that are not per player (the per player ones live in {@link JajankenEvents}). Self-registering. */
@Mod.EventBusSubscriber(modid = "hxhadventure", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class GonVowEvents {
    private GonVowEvents() {}

    /** The taller body: hitbox and eye height both grow, on the server and on the client (each side asks GonVow.isActive). */
    // EntityEvent.Size is flagged for removal in newer Forge, but 1.20.1 has no replacement hook for resizing a player's
    // hitbox, so this stays (and has to be reworked, e.g. with the scale attribute, if the mod moves to 1.20.5+/1.21).
    @SuppressWarnings("removal")
    @SubscribeEvent
    public static void onSize(EntityEvent.Size e) {
        if (e.getEntity() instanceof Player p && GonVow.isActive(p)) {
            e.setNewSize(e.getNewSize().scale(GonVow.HEIGHT_MULT), true);
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) GonVow.tickCraters();
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        GonVow.clearCraters();
    }
}
