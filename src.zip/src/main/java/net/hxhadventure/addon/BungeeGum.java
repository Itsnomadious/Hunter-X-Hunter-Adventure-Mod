package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.entity.PartEntity;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketGumFx;
import net.hxhadventure.utils.AllianceUtils;
import org.joml.Vector3f;

/**
 * Hisoka's Bungee Gum (Transmuter Hatsu, kit 13). Z throws a thread of elastic, sticky aura. When it sticks to a block or a
 * creature there are two follow-ups:
 *   - Z again: reel it in. The object is dragged to the user, swung around them, then raised and smashed down in front of
 *     them, damaging everything near the impact. A block is torn out of the world for this and shatters on landing.
 *   - Shift+Z: pull yourself to it.
 * Anything a Bungee Gum user hits slowly builds up "Properties of Rubber and Gum": in stages it slows the victim, shows a faint
 * pink aura on them, and tethers them to the user so they cannot get more than 50 blocks away (the tether is only visible with Gyo).
 * Second skill, Tether Pull: Z drags the tethered target to the user and hits it hard (no cooldown), or, if playing cards thrown in
 * Bungee Gum state are out, calls them back. Then {@link BungeeBarrier} and {@link BungeeBind}. The Playing Card is an item ({@link GumCards}).
 * H toggles Bungee Gum state: 10% less damage taken, and whoever hits the user in melee gets \"Properties of Rubber and Gum\".
 * Anything dragged in by the gum (reeled, slammed or Tether Pulled) cannot attack while it is in the gum's grip.
 */
public final class BungeeGum {
    private BungeeGum() {}

    public static final int KIT = 13;
    public static final String ID = "bungee_gum";
    public static final String PULL_ID = "gum_pull";
    private static final String PULL_NAME = "Tether Pull";
    private static final String NAME = "Bungee Gum";

    private static final DustParticleOptions PINK = new DustParticleOptions(new Vector3f(0.92f, 0.42f, 0.84f), 1.1f);

    private enum Phase { FLYING, ATTACHED, REEL, SELF_PULL }

    private enum Reel { PULL, SPIN, LIFT, SLAM }

    /** One thread per user. */
    private static final class Rope {
        Phase phase = Phase.FLYING;
        Vec3 tip = Vec3.ZERO;
        Vec3 dir = Vec3.ZERO;
        int age;
        UUID entity;               // what the thread is stuck to (after a block is torn loose: the flying block entity)
        BlockPos block;            // the block it first stuck to (null for a creature / object)
        BlockState blockState;
        boolean torn;              // the block has been torn loose and is now a flying block entity
        Vec3 anchor = Vec3.ZERO;   // where the thread ends on a block
        Reel reel = Reel.PULL;
        int reelTicks;
        double angle;
        Vec3 slamTop = Vec3.ZERO;
        Vec3 slamGround = Vec3.ZERO;
        int pullTicks;
        final Map<Integer, Integer> sweptAt = new HashMap<>();   // entity id -> user's tickCount when the spin last hit it
    }

    /** A Tether Pull in progress. */
    private static final class Yank {
        UUID target;
        int ticks;
    }

    /** The debuff's build-up on one victim. */
    private static final class Mark {
        UUID caster;
        float meter;
        long lastHit;
        int stage = -1;
    }

    private static final Map<UUID, Rope> ROPES = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> READY_AT = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> PULL_READY = new ConcurrentHashMap<>();
    private static final Map<UUID, Yank> YANKS = new ConcurrentHashMap<>();   // user -> tethered target currently being dragged in
    private static final Map<UUID, Mark> MARKS = new ConcurrentHashMap<>();   // victim -> build-up

    /** True while this class is itself hurting someone, so the melee hook does not count that hit a second time. */
    private static boolean selfHurt;

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    /** Bungee Gum's three skills join the Z menu as the Hatsu level allows. */
    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c)) return base;
        int lvl = c.getHatsuLevel();
        List<String> out = new ArrayList<>(Arrays.asList(base));
        if (lvl >= Tuning.GUM_MIN_LEVEL) out.add(ID);
        if (lvl >= Tuning.GUM_PULL_MIN_LEVEL) out.add(PULL_ID);
        if (lvl >= Tuning.BARRIER_MIN_LEVEL) out.add(BungeeBarrier.ID);
        if (lvl >= Tuning.BIND_MIN_LEVEL) out.add(BungeeBind.ID);
        return out.toArray(new String[0]);
    }

    // =====================================================================================================
    // Bungee Gum state (H)
    // =====================================================================================================

    /** Users who are in Bungee Gum state. */
    private static final Set<UUID> STATE = ConcurrentHashMap.newKeySet();
    /** Creature -> game time until which it counts as \"being drawn in\" (renewed every tick the gum drags it). */
    private static final Map<UUID, Long> DRAWN = new ConcurrentHashMap<>();

    public static boolean inState(Player p) {
        return p != null && STATE.contains(p.getUUID());
    }

    /** H: Bungee Gum state on / off. */
    public static void toggleState(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Bungee Gum"), true);
            return;
        }
        if (STATE.remove(sp.getUUID())) {
            sp.displayClientMessage(Component.literal("\u00a77Bungee Gum state: Off"), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_STEP, SoundSource.PLAYERS, 0.8f, 0.8f);
            return;
        }
        if (c.getHatsuLevel() < Tuning.GUM_STATE_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cBungee Gum unlocks at Level " + Tuning.GUM_STATE_MIN_LEVEL), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        STATE.add(sp.getUUID());
        sp.displayClientMessage(Component.literal("\u00a7dBungee Gum state: On \u00a77(-10% damage taken; anyone who hits you in melee gets Rubber and Gum)"), true);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_PLACE, SoundSource.PLAYERS, 1.0f, 1.3f);
        if (sp.level() instanceof ServerLevel level) {
            level.sendParticles(PINK, sp.getX(), sp.getY() + 1.0, sp.getZ(), 24, 0.5, 0.8, 0.5, 0.03);
        }
    }

    /** Multiplier on damage the user takes: 10% less while in Bungee Gum state. */
    public static float incomingMult(Player p) {
        return inState(p) ? Tuning.GUM_STATE_DAMAGE_TAKEN : 1f;
    }

    /** Someone hit a user in Bungee Gum state in melee: the gum sticks to them. */
    public static void onMeleeReceived(ServerPlayer user, LivingEntity attacker) {
        if (!STATE.contains(user.getUUID()) || attacker == user || !attacker.isAlive()) return;
        Combat c = Combat.get(user);
        if (!canUse(c) || ExtrasHooks.hatsuForced(user)) return;
        addBuildup(user, attacker, Tuning.GUM_BUILDUP_MELEE);
    }

    /** The gum is dragging this creature right now (reel-in, spin, slam, Tether Pull, Hisoka's too). */
    public static void markDrawn(Entity e) {
        if (e != null) DRAWN.put(e.getUUID(), e.level().getGameTime() + Tuning.GUM_DRAWN_GRACE_TICKS);
    }

    /** True while something is being dragged by the gum: it cannot attack until it is let go. Also true for Bungee Bind's captives. */
    public static boolean cannotAttack(Entity e) {
        if (e == null || e.level().isClientSide) return false;
        Long until = DRAWN.get(e.getUUID());
        if (until != null) {
            if (e.level().getGameTime() <= until) return true;
            DRAWN.remove(e.getUUID());
        }
        return BungeeBind.isBound(e);
    }

    // =====================================================================================================
    // Z / Shift+Z
    // =====================================================================================================

    /** Z pressed on Bungee Gum. Shift+Z is told apart by the user's sneak state. */
    public static void use(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Bungee Gum"), true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.GUM_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cBungee Gum unlocks at Level " + Tuning.GUM_MIN_LEVEL), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        if (YANKS.containsKey(sp.getUUID())) return; // the thread is busy dragging someone in

        Rope r = ROPES.get(sp.getUUID());
        if (r == null) {
            fire(sp, c, level);
            return;
        }
        switch (r.phase) {
            case FLYING -> finish(sp, r, "\u00a77Bungee Gum: thread recalled", Tuning.GUM_MISS_COOLDOWN_TICKS);
            case ATTACHED -> {
                if (sp.isShiftKeyDown()) startSelfPull(sp, c, r, level);
                else startReel(sp, c, r, level);
            }
            case SELF_PULL -> finish(sp, r, "\u00a77Bungee Gum: let go", Tuning.GUM_PULL_COOLDOWN_TICKS);
            case REEL -> { } // once the target is on its way in there is no stopping it
        }
    }

    private static void fire(ServerPlayer sp, Combat c, ServerLevel level) {
        long now = level.getGameTime();
        if (ChainManager.onCooldown(sp, NAME, (int) Math.max(0, READY_AT.getOrDefault(sp.getUUID(), 0L) - now))) return;
        if (c.getCurrentEnergy() < Tuning.GUM_THROW_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.GUM_THROW_COST);
        Rope r = new Rope();
        r.dir = sp.getLookAngle().normalize();
        r.tip = sp.getEyePosition().add(r.dir.scale(0.6));
        ROPES.put(sp.getUUID(), r);
        sp.swing(InteractionHand.MAIN_HAND, true);
        level.playSound(null, sp.blockPosition(), SoundEvents.FISHING_BOBBER_THROW, SoundSource.PLAYERS, 1.2f, 0.7f);
        level.playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_PLACE, SoundSource.PLAYERS, 1.0f, 1.5f);
        sendThread(sp, -1, r.tip);
    }

    // =====================================================================================================
    // per-tick
    // =====================================================================================================

    public static void tick(ServerPlayer sp) {
        if (STATE.contains(sp.getUUID())) {
            Combat sc = Combat.get(sp);
            if (sc == null || !canUse(sc) || !sp.isAlive() || ExtrasHooks.hatsuForced(sp)) {
                STATE.remove(sp.getUUID());
                sp.displayClientMessage(Component.literal("\u00a77Bungee Gum state: Off"), true);
            }
        }
        tickYank(sp);
        Rope r = ROPES.get(sp.getUUID());
        if (r == null) return;
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || !sp.isAlive() || ExtrasHooks.hatsuForced(sp) || !(sp.level() instanceof ServerLevel level)) {
            release(sp, r);
            return;
        }
        switch (r.phase) {
            case FLYING -> tickFlying(sp, r, level);
            case ATTACHED -> tickAttached(sp, r, level);
            case REEL -> tickReel(sp, c, r, level);
            case SELF_PULL -> tickSelfPull(sp, r, level);
        }
    }

    private static void tickFlying(ServerPlayer sp, Rope r, ServerLevel level) {
        r.age++;
        Vec3 from = r.tip;
        Vec3 to = from.add(r.dir.scale(Tuning.GUM_SPEED));
        HitResult wall = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        Vec3 end = wall.getType() == HitResult.Type.MISS ? to : wall.getLocation();
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(level, sp, from, end, new AABB(from, end).inflate(0.6), e -> grabbable(sp, e));
        if (eh != null) {
            attachEntity(sp, r, level, eh.getEntity(), eh.getLocation());
            return;
        }
        if (wall instanceof BlockHitResult bhr && wall.getType() == HitResult.Type.BLOCK) {
            attachBlock(sp, r, level, bhr);
            return;
        }
        r.tip = to;
        if (r.tip.distanceToSqr(sp.getEyePosition()) > Tuning.GUM_RANGE * Tuning.GUM_RANGE) {
            finish(sp, r, "\u00a77Bungee Gum: fell short", Tuning.GUM_MISS_COOLDOWN_TICKS);
            return;
        }
        sendThread(sp, -1, r.tip);
    }

    private static boolean grabbable(ServerPlayer sp, Entity e) {
        return e != sp && e.isAlive() && !e.isSpectator() && !(e instanceof PartEntity<?>)
            && (e.isPickable() || e instanceof ItemEntity);
    }

    private static void attachEntity(ServerPlayer sp, Rope r, ServerLevel level, Entity e, Vec3 at) {
        r.phase = Phase.ATTACHED;
        r.entity = e.getUUID();
        r.age = 0;
        sendThread(sp, e.getId(), at);
        stickFx(level, at);
        if (e instanceof LivingEntity le) addBuildup(sp, le, Tuning.GUM_BUILDUP_THREAD);
        String how = movable(e) ? "Z reel in, Shift+Z pull yourself" : "Shift+Z pull yourself";
        sp.displayClientMessage(Component.literal("\u00a7dBungee Gum: stuck to " + e.getName().getString() + " \u00a77(" + how + ")"), true);
    }

    private static void attachBlock(ServerPlayer sp, Rope r, ServerLevel level, BlockHitResult hit) {
        BlockPos pos = hit.getBlockPos();
        r.phase = Phase.ATTACHED;
        r.block = pos;
        r.blockState = level.getBlockState(pos);
        r.anchor = hit.getLocation();
        r.age = 0;
        sendThread(sp, -1, r.anchor);
        stickFx(level, r.anchor);
        String how = canTear(level, pos, r.blockState) ? "Z reel in, Shift+Z pull yourself" : "Shift+Z pull yourself";
        sp.displayClientMessage(Component.literal("\u00a7dBungee Gum: stuck to " + r.blockState.getBlock().getName().getString() + " \u00a77(" + how + ")"), true);
    }

    private static void stickFx(ServerLevel level, Vec3 at) {
        level.sendParticles(PINK, at.x, at.y, at.z, 14, 0.25, 0.25, 0.25, 0.03);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.SLIME_BLOCK_HIT, SoundSource.PLAYERS, 1.2f, 1.1f);
    }

    private static void tickAttached(ServerPlayer sp, Rope r, ServerLevel level) {
        r.age++;
        Vec3 end = anchorPoint(level, r);
        if (end == null) {
            finish(sp, r, "\u00a77Bungee Gum: the thread went slack", Tuning.GUM_MISS_COOLDOWN_TICKS);
        } else if (r.age > Tuning.GUM_HOLD_TICKS) {
            finish(sp, r, "\u00a77Bungee Gum: the thread let go", Tuning.GUM_MISS_COOLDOWN_TICKS);
        } else if (end.distanceToSqr(sp.getEyePosition()) > Tuning.GUM_SNAP_LENGTH * Tuning.GUM_SNAP_LENGTH) {
            finish(sp, r, "\u00a77Bungee Gum: the thread snapped", Tuning.GUM_MISS_COOLDOWN_TICKS);
        }
    }

    /** Where the thread currently ends, or null if what it was stuck to is gone. */
    private static Vec3 anchorPoint(ServerLevel level, Rope r) {
        if (r.entity != null) {
            Entity e = level.getEntity(r.entity);
            if (e == null || !e.isAlive() || e.level() != level) return null;
            return centerOf(e);
        }
        if (r.block == null || !level.getBlockState(r.block).equals(r.blockState)) return null;
        return r.anchor;
    }

    static Vec3 centerOf(Entity e) {
        return e.position().add(0, e.getBbHeight() * 0.5, 0);
    }

    // =====================================================================================================
    // Z on an attached thread: reel in, spin, slam
    // =====================================================================================================

    private static boolean movable(Entity e) {
        return !(e instanceof EnderDragon) && !(e instanceof WitherBoss) && !(e instanceof PartEntity<?>);
    }

    private static boolean canTear(ServerLevel level, BlockPos pos, BlockState st) {
        return !st.isAir() && st.getDestroySpeed(level, pos) >= 0
            && st.getBlock().getExplosionResistance() <= Tuning.GUM_BLOCK_POWER
            && level.getBlockEntity(pos) == null;
    }

    private static void startReel(ServerPlayer sp, Combat c, Rope r, ServerLevel level) {
        Entity obj = null;
        if (r.entity != null) {
            obj = level.getEntity(r.entity);
            if (obj == null || !obj.isAlive()) {
                finish(sp, r, "\u00a77Bungee Gum: the thread went slack", Tuning.GUM_MISS_COOLDOWN_TICKS);
                return;
            }
            if (!movable(obj)) {
                sp.displayClientMessage(Component.literal("\u00a7cThat is far too big to reel in"), true);
                return;
            }
        } else if (!level.getBlockState(r.block).equals(r.blockState) || !canTear(level, r.block, r.blockState)) {
            sp.displayClientMessage(Component.literal("\u00a7cThis will not come loose"), true);
            return;
        }
        if (c.getCurrentEnergy() < Tuning.GUM_REEL_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.GUM_REEL_COST);

        if (obj == null) { // tear the block out of the world; it becomes a block entity that ignores gravity and collision
            FallingBlockEntity fb = FallingBlockEntity.fall(level, r.block, r.blockState);
            fb.setNoGravity(true);
            fb.noPhysics = true;
            fb.setDeltaMovement(Vec3.ZERO);
            r.entity = fb.getUUID();
            r.torn = true;
            obj = fb;
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, r.blockState), r.anchor.x, r.anchor.y, r.anchor.z, 20, 0.4, 0.4, 0.4, 0.05);
        } else if (obj.isPassenger()) {
            obj.stopRiding();
        }

        r.phase = Phase.REEL;
        r.reel = Reel.PULL;
        r.reelTicks = 0;
        Vec3 rel = centerOf(obj).subtract(sp.position());
        r.angle = Math.atan2(rel.z, rel.x); // join the orbit from the side the object is already on
        sendThread(sp, obj.getId(), centerOf(obj));
        sp.swing(InteractionHand.MAIN_HAND, true);
        level.playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_STEP, SoundSource.PLAYERS, 1.5f, 0.6f);
        sp.displayClientMessage(Component.literal("\u00a7dBungee Gum: reeling in"), true);
    }

    private static void tickReel(ServerPlayer sp, Combat c, Rope r, ServerLevel level) {
        Entity obj = r.entity == null ? null : level.getEntity(r.entity);
        if (obj == null || !obj.isAlive() || obj.level() != level) {
            finish(sp, r, "\u00a77Bungee Gum: lost it", Tuning.GUM_MISS_COOLDOWN_TICKS);
            return;
        }
        r.reelTicks++;
        Vec3 center = sp.position().add(0, sp.getBbHeight() * 0.5, 0);
        switch (r.reel) {
            case PULL -> {
                Vec3 want = orbit(center, r.angle);
                steer(obj, want, 3.0, 0.35);
                if (centerOf(obj).distanceToSqr(want) < 4.0 || r.reelTicks > Tuning.GUM_PULL_IN_MAX_TICKS) {
                    r.reel = Reel.SPIN;
                    r.reelTicks = 0;
                    level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.2f, 0.6f);
                }
            }
            case SPIN -> {
                r.angle += Tuning.GUM_SPIN_SPEED;
                steer(obj, orbit(center, r.angle), Tuning.GUM_SPIN_FOLLOW_SPEED, 1.0);
                spinHits(sp, c, r, obj, level);
                if (r.reelTicks % 8 == 0) {
                    level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.8f, 0.5f);
                }
                if (r.reelTicks >= Tuning.GUM_SPIN_TICKS) {
                    planSlam(sp, r, level);
                    r.reel = Reel.LIFT;
                    r.reelTicks = 0;
                }
            }
            case LIFT -> {
                steer(obj, r.slamTop, 3.2, 0.6);
                if (r.reelTicks >= Tuning.GUM_LIFT_TICKS || centerOf(obj).distanceToSqr(r.slamTop) < 2.25) {
                    r.reel = Reel.SLAM;
                    r.reelTicks = 0;
                    level.playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_FALL, SoundSource.PLAYERS, 1.4f, 0.5f);
                }
            }
            case SLAM -> {
                Vec3 down = r.slamGround.add(0, obj.getBbHeight() * 0.5, 0);
                steer(obj, down, Tuning.GUM_SLAM_SPEED, 1.0);
                if (centerOf(obj).distanceToSqr(down) < 2.25 || r.reelTicks > 25) impact(sp, c, r, obj, level);
            }
        }
    }

    private static Vec3 orbit(Vec3 center, double angle) {
        return center.add(Math.cos(angle) * Tuning.GUM_ORBIT_RADIUS, 0.3, Math.sin(angle) * Tuning.GUM_ORBIT_RADIUS);
    }

    /** Picks where the object goes up to and where it will land: straight in front of the user. */
    private static void planSlam(ServerPlayer sp, Rope r, ServerLevel level) {
        Vec3 look = sp.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1.0e-4 ? new Vec3(0, 0, 1) : flat.normalize();
        Vec3 base = sp.position().add(flat.scale(Tuning.GUM_SLAM_DISTANCE));
        Vec3 low = new Vec3(base.x, sp.getY() + 0.5, base.z);
        HitResult ceiling = level.clip(new ClipContext(low, low.add(0, Tuning.GUM_SLAM_HEIGHT, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        r.slamTop = ceiling.getType() == HitResult.Type.MISS
            ? low.add(0, Tuning.GUM_SLAM_HEIGHT, 0)
            : ceiling.getLocation().add(0, -0.8, 0);
        HitResult floor = level.clip(new ClipContext(r.slamTop, r.slamTop.add(0, -(Tuning.GUM_SLAM_HEIGHT + 10), 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        r.slamGround = floor.getType() == HitResult.Type.MISS ? new Vec3(base.x, sp.getY(), base.z) : floor.getLocation();
    }

    /** Anything the spinning object sweeps into takes a hit and is flung outwards. */
    private static void spinHits(ServerPlayer sp, Combat c, Rope r, Entity obj, ServerLevel level) {
        double reach = Tuning.GUM_SPIN_HIT_RADIUS + obj.getBbWidth() * 0.5;
        Vec3 oc = centerOf(obj);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(oc, oc).inflate(reach + 1.5))) {
            if (e == sp || e == obj || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, sp)) continue;
            double lim = reach + e.getBbWidth() * 0.5;
            if (centerOf(e).distanceToSqr(oc) > lim * lim) continue;
            Integer last = r.sweptAt.get(e.getId());
            if (last != null && sp.tickCount - last < Tuning.GUM_SPIN_HIT_GAP) continue;
            r.sweptAt.put(e.getId(), sp.tickCount);
            Vec3 out = centerOf(e).subtract(sp.position().add(0, sp.getBbHeight() * 0.5, 0));
            out = out.lengthSqr() < 1.0e-4 ? new Vec3(0, 0, 1) : out.normalize();
            hurt(sp, e, Tuning.GUM_SPIN_DAMAGE + c.getHatsuLevel() * Tuning.GUM_DAMAGE_PER_LEVEL,
                new Vec3(out.x * 0.9, 0.3, out.z * 0.9), Tuning.GUM_BUILDUP_SPIN);
            level.sendParticles(PINK, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 8, 0.3, 0.3, 0.3, 0.02);
            level.playSound(null, e.blockPosition(), SoundEvents.SLIME_BLOCK_HIT, SoundSource.PLAYERS, 1.0f, 0.8f);
        }
    }

    private static void impact(ServerPlayer sp, Combat c, Rope r, Entity obj, ServerLevel level) {
        Vec3 at = r.slamGround;
        float base = Tuning.GUM_SLAM_DAMAGE + c.getHatsuLevel() * Tuning.GUM_DAMAGE_PER_LEVEL;
        double radius = Tuning.GUM_SLAM_RADIUS;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(radius + 2.0))) {
            if (e == sp || !e.isAlive() || e instanceof ArmorStand || AllianceUtils.isAlly(e, sp)) continue;
            double dist = e.position().distanceTo(at);
            if (dist > radius + e.getBbWidth() * 0.5) continue;
            float falloff = (float) (1.0 - 0.5 * Math.min(1.0, dist / radius)); // 100% at the centre, 50% at the edge
            Vec3 out = e.position().subtract(at);
            out = new Vec3(out.x, 0, out.z);
            out = out.lengthSqr() < 1.0e-4 ? Vec3.ZERO : out.normalize();
            double kb = Tuning.GUM_SLAM_KNOCKBACK * falloff;
            hurt(sp, e, base * falloff, new Vec3(out.x * kb, 0.5 + 0.3 * falloff, out.z * kb), Tuning.GUM_BUILDUP_SLAM);
        }
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y + 0.3, at.z, 4, radius * 0.3, 0.2, radius * 0.3, 0);
        level.sendParticles(PINK, at.x, at.y + 0.4, at.z, 70, radius * 0.4, 0.3, radius * 0.4, 0.06);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.3f, 1.5f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 1.0f, 0.6f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.SLIME_BLOCK_BREAK, SoundSource.PLAYERS, 1.5f, 0.7f);

        if (r.torn && obj instanceof FallingBlockEntity fb) { // the block shatters where it lands
            BlockState st = fb.getBlockState();
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), at.x, at.y + 0.5, at.z, 40, 0.5, 0.4, 0.5, 0.1);
            if (Tuning.GUM_BLOCK_DROPS) Block.dropResources(st, level, BlockPos.containing(at.x, at.y + 0.5, at.z));
            fb.discard();
            r.torn = false;
        } else {
            obj.setDeltaMovement(Vec3.ZERO);
            obj.hurtMarked = true;
        }
        finish(sp, r, null, Tuning.GUM_SLAM_COOLDOWN_TICKS);
    }

    // =====================================================================================================
    // Shift+Z on an attached thread: pull yourself in
    // =====================================================================================================

    private static void startSelfPull(ServerPlayer sp, Combat c, Rope r, ServerLevel level) {
        if (anchorPoint(level, r) == null) {
            finish(sp, r, "\u00a77Bungee Gum: the thread went slack", Tuning.GUM_MISS_COOLDOWN_TICKS);
            return;
        }
        if (c.getCurrentEnergy() < Tuning.GUM_PULL_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.GUM_PULL_COST);
        r.phase = Phase.SELF_PULL;
        r.pullTicks = 0;
        level.playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_STEP, SoundSource.PLAYERS, 1.5f, 1.4f);
        sp.displayClientMessage(Component.literal("\u00a7dBungee Gum: pulling in"), true);
    }

    private static void tickSelfPull(ServerPlayer sp, Rope r, ServerLevel level) {
        Vec3 end = anchorPoint(level, r);
        if (end == null) {
            finish(sp, r, "\u00a77Bungee Gum: let go", Tuning.GUM_PULL_COOLDOWN_TICKS);
            return;
        }
        r.pullTicks++;
        Vec3 me = sp.position().add(0, sp.getBbHeight() * 0.5, 0);
        Vec3 d = end.subtract(me);
        double dist = d.length();
        double stop = 1.8;
        Entity stuckTo = r.entity == null ? null : level.getEntity(r.entity);
        if (stuckTo != null) stop += stuckTo.getBbWidth() * 0.5;
        if (dist <= stop || r.pullTicks > Tuning.GUM_PULL_MAX_TICKS) {
            sp.setDeltaMovement(sp.getDeltaMovement().scale(0.25)); // arrive without flying straight on past it
            sp.fallDistance = 0f;
            sp.hurtMarked = true;
            sp.connection.send(new ClientboundSetEntityMotionPacket(sp));
            finish(sp, r, null, Tuning.GUM_PULL_COOLDOWN_TICKS);
            return;
        }
        double speed = Math.min(Tuning.GUM_PULL_SPEED, Tuning.GUM_PULL_START_SPEED + r.pullTicks * Tuning.GUM_PULL_RAMP); // snaps tight, then accelerates hard
        Vec3 v = d.scale(speed / dist);
        sp.setDeltaMovement(v.x, v.y + 0.04, v.z);
        sp.fallDistance = 0f;
        sp.hurtMarked = true;
        sp.connection.send(new ClientboundSetEntityMotionPacket(sp));
    }

    // =====================================================================================================
    // helpers
    // =====================================================================================================

    /** Steers an object towards a point (by its centre) by setting its velocity. */
    private static void steer(Entity e, Vec3 target, double maxSpeed, double gain) {
        if (e instanceof LivingEntity) markDrawn(e); // being dragged in: it cannot attack
        Vec3 cur = centerOf(e);
        Vec3 d = target.subtract(cur);
        double len = d.length();
        Vec3 v = len < 1.0e-4 ? Vec3.ZERO : d.scale(Math.min(maxSpeed, len * gain) / len);
        if (e instanceof FallingBlockEntity) {
            e.setDeltaMovement(v); // its own tick moves it by this (no gravity, no collision), so only the velocity is set here
            e.hasImpulse = true;   // makes the server send its position every tick instead of once a second
            return;
        }
        e.setDeltaMovement(v);
        e.hurtMarked = true;
        e.fallDistance = 0f;
        if (e instanceof ServerPlayer p) p.connection.send(new ClientboundSetEntityMotionPacket(p));
        if (e instanceof Mob m) m.getNavigation().stop();
    }

    /** Damage from the user's gum, counted towards the debuff by the caller rather than by the melee hook. */
    static void hurt(ServerPlayer sp, LivingEntity e, float damage, Vec3 push, float buildup) {
        selfHurt = true;
        try {
            Vows.hatsuHurt(e, sp.level().damageSources().playerAttack(sp), damage * Vows.power(sp, ID));
        } finally {
            selfHurt = false;
        }
        e.push(push.x, push.y, push.z);
        e.hurtMarked = true;
        addBuildup(sp, e, buildup);
    }

    /** A card thrown in Bungee Gum state lands: its damage as a normal hit by the thrower, and the gum sticks exactly as from a melee hit
     *  (counted here, once, so it still works through invulnerability frames and is not counted a second time by the melee hook). */
    public static void cardHit(ServerPlayer sp, LivingEntity victim, float damage) {
        selfHurt = true;
        try {
            victim.hurt(sp.level().damageSources().playerAttack(sp), damage);
        } finally {
            selfHurt = false;
        }
        Combat c = Combat.get(sp);
        if (!canUse(c) || c.getHatsuLevel() < Tuning.GUM_MIN_LEVEL || ExtrasHooks.hatsuForced(sp)) return;
        addBuildup(sp, victim, Tuning.GUM_BUILDUP_CARD);
    }

    private static void sendThread(ServerPlayer sp, int targetEntity, Vec3 point) {
        AddonNetwork.sendToTrackingAndSelf(PacketGumFx.thread(sp.getId(), targetEntity, point), sp);
    }

    /** Ends the thread, sets the cooldown and says why. */
    private static void finish(ServerPlayer sp, Rope r, String msg, int cooldownTicks) {
        release(sp, r);
        if (cooldownTicks > 0) {
            READY_AT.put(sp.getUUID(), sp.level().getGameTime() + cooldownTicks);
            ChainManager.startCooldown(sp, NAME, cooldownTicks);
        }
        if (msg != null) sp.displayClientMessage(Component.literal(msg), true);
    }

    /** Drops the thread and whatever it still carries, without a cooldown. */
    private static void release(ServerPlayer sp, Rope r) {
        ROPES.remove(sp.getUUID());
        if (r.torn && r.entity != null && sp.level() instanceof ServerLevel l && l.getEntity(r.entity) instanceof FallingBlockEntity fb) {
            Block.dropResources(fb.getBlockState(), l, fb.blockPosition()); // interrupted mid-reel: the block is not lost
            fb.discard();
        }
        r.torn = false;
        AddonNetwork.sendToTrackingAndSelf(PacketGumFx.threadOff(sp.getId()), sp);
    }

    // =====================================================================================================
    // Tether Pull (second skill): Z drags the tethered target to you and hits it hard
    // =====================================================================================================

    /** Everything currently carrying this user's debuff (any stage), in the user's dimension. */
    static List<LivingEntity> tethered(ServerPlayer sp) {
        List<LivingEntity> out = new ArrayList<>();
        MinecraftServer server = sp.getServer();
        if (server == null) return out;
        for (Map.Entry<UUID, Mark> en : MARKS.entrySet()) {
            Mark m = en.getValue();
            if (m.stage < 0 || !sp.getUUID().equals(m.caster)) continue;
            if (find(server, en.getKey()) instanceof LivingEntity le && le.isAlive() && le.level() == sp.level()) out.add(le);
        }
        // anyone carrying "Properties of Rubber and Gum" is tethered to the user, even if no build-up was recorded for them: they are adopted
        // (unless another user's gum is the one on them), so Tether Pull and the homing cards always find them
        long now = sp.level().getGameTime();
        double r = Tuning.GUM_TETHER_RANGE;
        for (LivingEntity le : sp.level().getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(r),
                e -> e != sp && e.isAlive() && HatsuEffects.hasGum(e) && !(e instanceof ArmorStand))) {
            if (out.contains(le) || AllianceUtils.isAlly(le, sp)) continue;
            Mark m = MARKS.get(le.getUUID());
            if (m != null && m.caster != null && !sp.getUUID().equals(m.caster)) continue; // someone else's gum
            if (m == null) {
                m = new Mark();
                m.caster = sp.getUUID();
                MARKS.put(le.getUUID(), m);
            }
            net.minecraft.world.effect.MobEffectInstance fx = le.getEffect(HatsuEffects.RUBBER_GUM);
            int lvl = fx == null ? 0 : Math.min(fx.getAmplifier(), Tuning.GUM_STAGES.length - 1);
            m.caster = sp.getUUID();
            m.meter = Math.max(m.meter, Tuning.GUM_STAGES[lvl]);
            m.lastHit = now;
            m.stage = -1; // the next tick of the debuff sends the tether to the clients and starts the leash
            out.add(le);
        }
        return out;
    }

    public static void pull(ServerPlayer sp) {
        Combat c = Combat.get(sp);
        if (c == null) return;
        if (!canUse(c)) {
            sp.displayClientMessage(Component.literal("\u00a7cYour Hatsu is not Bungee Gum"), true);
            return;
        }
        if (c.getHatsuLevel() < Tuning.GUM_PULL_MIN_LEVEL) {
            sp.displayClientMessage(Component.literal("\u00a7cTether Pull unlocks at Level " + Tuning.GUM_PULL_MIN_LEVEL), true);
            return;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            sp.displayClientMessage(Component.literal("\u00a75Forced Zetsu: your aura will not answer"), true);
            return;
        }
        if (!(sp.level() instanceof ServerLevel level)) return;
        UUID id = sp.getUUID();
        if (GumCards.recall(sp)) return; // cards thrown in Bungee Gum state are out: Tether Pull brings them back instead
        if (YANKS.containsKey(id) || ROPES.containsKey(id)) {
            sp.displayClientMessage(Component.literal("\u00a77Bungee Gum: your thread is already out"), true);
            return;
        }
        if (ChainManager.onCooldown(sp, PULL_NAME, (int) Math.max(0, PULL_READY.getOrDefault(id, 0L) - level.getGameTime()))) return;
        List<LivingEntity> list = tethered(sp);
        if (list.isEmpty()) {
            sp.displayClientMessage(Component.literal("\u00a7cNo tethered target"), true);
            return;
        }
        // the tethered target you are looking most nearly towards
        Vec3 look = sp.getLookAngle();
        Vec3 eye = sp.getEyePosition();
        LivingEntity best = null;
        double bestDot = -2.0;
        for (LivingEntity e : list) {
            Vec3 to = centerOf(e).subtract(eye);
            double d = to.length();
            if (d < 1.0e-4) continue;
            double dot = to.scale(1.0 / d).dot(look);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        if (best == null) return;
        if (c.getCurrentEnergy() < Tuning.GUM_YANK_COST) {
            sp.displayClientMessage(Component.literal("\u00a7cNot enough energy"), true);
            return;
        }
        c.consumeEnergy(Tuning.GUM_YANK_COST);
        Yank y = new Yank();
        y.target = best.getUUID();
        YANKS.put(id, y);
        if (best.isPassenger()) best.stopRiding();
        sendThread(sp, best.getId(), centerOf(best)); // the tether lights up as a full thread while it drags
        sp.swing(InteractionHand.MAIN_HAND, true);
        level.playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_STEP, SoundSource.PLAYERS, 1.5f, 0.5f);
        sp.displayClientMessage(Component.literal("\u00a7dTether Pull!"), true);
    }

    private static void tickYank(ServerPlayer sp) {
        Yank y = YANKS.get(sp.getUUID());
        if (y == null) return;
        Combat c = Combat.get(sp);
        Entity t = sp.level() instanceof ServerLevel l ? l.getEntity(y.target) : null;
        if (c == null || !canUse(c) || !sp.isAlive() || ExtrasHooks.hatsuForced(sp)
            || !(t instanceof LivingEntity victim) || !victim.isAlive() || victim.level() != sp.level()) {
            endYank(sp, 0); // Tether Pull has no cooldown
            return;
        }
        ServerLevel level = (ServerLevel) sp.level();
        y.ticks++;
        Vec3 spot = centerOf(sp).add(sp.getLookAngle().scale(2.0)); // right in front of the user's face
        steer(victim, spot, 3.4, 0.5);
        if (centerOf(victim).distanceToSqr(spot) < 2.5 || y.ticks > Tuning.GUM_YANK_MAX_TICKS) {
            Vec3 dir = victim.position().subtract(sp.position());
            dir = new Vec3(dir.x, 0, dir.z);
            dir = dir.lengthSqr() < 1.0e-4 ? sp.getLookAngle() : dir.normalize();
            float dmg = Tuning.GUM_YANK_DAMAGE + c.getHatsuLevel() * Tuning.GUM_YANK_PER_LEVEL;
            hurt(sp, victim, dmg, new Vec3(dir.x * Tuning.GUM_YANK_KNOCKBACK, 0.55, dir.z * Tuning.GUM_YANK_KNOCKBACK), Tuning.GUM_BUILDUP_YANK);
            Vec3 at = centerOf(victim);
            level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 3, 0.3, 0.3, 0.3, 0);
            level.sendParticles(PINK, at.x, at.y, at.z, 40, 0.5, 0.5, 0.5, 0.08);
            level.playSound(null, at.x, at.y, at.z, SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.5f, 0.6f);
            level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.0f, 1.6f);
            endYank(sp, Tuning.GUM_YANK_COOLDOWN_TICKS);
        }
    }

    private static void endYank(ServerPlayer sp, int cooldownTicks) {
        YANKS.remove(sp.getUUID());
        AddonNetwork.sendToTrackingAndSelf(PacketGumFx.threadOff(sp.getId()), sp);
        if (cooldownTicks > 0) {
            PULL_READY.put(sp.getUUID(), sp.level().getGameTime() + cooldownTicks);
            ChainManager.startCooldown(sp, PULL_NAME, cooldownTicks);
        }
    }

    // =====================================================================================================
    // "Properties of Rubber and Gum"
    // =====================================================================================================

    /** Called for every melee hit a player lands: a Bungee Gum user's hits stick a little more of the gum onto the victim. */
    public static void onMeleeHit(ServerPlayer attacker, LivingEntity victim) {
        if (selfHurt) return;
        Combat c = Combat.get(attacker);
        if (!canUse(c)) return;
        if (c.getHatsuLevel() < Tuning.GUM_MIN_LEVEL || ExtrasHooks.hatsuForced(attacker)) {
            com.mojang.logging.LogUtils.getLogger().info("[hxh gum] {}'s melee hit on {} left no gum: hatsu level {} (needs {}), forced zetsu/jail: {}",
                attacker.getName().getString(), victim.getName().getString(), c.getHatsuLevel(), Tuning.GUM_MIN_LEVEL, ExtrasHooks.hatsuForced(attacker));
            return;
        }
        addBuildup(attacker, victim, Tuning.GUM_BUILDUP_MELEE);
    }

    static void addBuildup(ServerPlayer caster, LivingEntity victim, float amount) {
        if (victim == caster || !victim.isAlive() || victim instanceof ArmorStand || AllianceUtils.isAlly(victim, caster)) return;
        Mark m = MARKS.computeIfAbsent(victim.getUUID(), k -> new Mark());
        if (!caster.getUUID().equals(m.caster)) { // someone else's gum is on them: the newest user's takes over from scratch
            m.caster = caster.getUUID();
            m.meter = 0f;
            m.stage = -1;
        }
        m.meter = Math.min(Tuning.GUM_BUILDUP_MAX, m.meter + amount);
        m.lastHit = victim.level().getGameTime();
    }

    private static int stageOf(float meter) {
        for (int i = Tuning.GUM_STAGES.length - 1; i >= 0; i--) {
            if (meter >= Tuning.GUM_STAGES[i]) return i;
        }
        return -1;
    }

    /** Every server tick: grows / drains the build-up, applies the debuff, and keeps tethered victims on their leash. */
    public static void tickGlobal(MinecraftServer server) {
        if (MARKS.isEmpty()) return;
        Iterator<Map.Entry<UUID, Mark>> it = MARKS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Mark> en = it.next();
            Mark m = en.getValue();
            Entity ve = find(server, en.getKey());
            ServerPlayer caster = m.caster == null ? null : server.getPlayerList().getPlayer(m.caster);
            if (!(ve instanceof LivingEntity victim) || !victim.isAlive() || caster == null || !caster.isAlive()
                || victim.level() != caster.level()) { // like Hisoka's: the gum holds for as long as it is on them, whatever the caster is doing
                if (ve instanceof LivingEntity gone) lift(gone);
                it.remove();
                continue;
            }
            long t = victim.level().getGameTime();
            if (t - m.lastHit > Tuning.GUM_DECAY_DELAY_TICKS && t % 20 == 0) m.meter -= Tuning.GUM_DECAY_PER_SECOND;
            if (m.meter <= 0f) {
                lift(victim);
                it.remove();
                continue;
            }
            int stage = stageOf(m.meter);
            if (stage != m.stage) {
                boolean first = m.stage < 0;
                m.stage = stage;
                if (stage < 0) {
                    lift(victim);
                    continue;
                }
                HatsuEffects.applyGum(victim, 60, stage, gumIcon(victim, caster)); // takes hold straight away; the refresh below keeps it up
                AddonNetwork.sendToTrackingAndSelf(PacketGumFx.tether(victim.getId(), caster.getId(), stage), victim);
                if (first && victim instanceof ServerPlayer vp) {
                    vp.displayClientMessage(Component.literal("\u00a7dSomething sticky is clinging to you..."), true);
                }
            }
            if (stage < 0) continue;
            if (t % 10 == 0) HatsuEffects.applyGum(victim, 60, stage, gumIcon(victim, caster));
            if (t % 100 == 0) { // for anyone who has only just come into view
                AddonNetwork.sendToTrackingAndSelf(PacketGumFx.tether(victim.getId(), caster.getId(), stage), victim);
            }
            tether(victim, caster);
        }
    }

    /** In hides the gum: the victim gets no effect icon unless they have Gyo on (it is still slowed and tethered). */
    private static boolean gumIcon(LivingEntity victim, ServerPlayer caster) {
        NenAddonData cd = NenAddonData.peek(caster);
        if (cd == null || !cd.hiddenNow()) return true;
        if (victim instanceof ServerPlayer vp) {
            NenAddonData vd = NenAddonData.peek(vp);
            return vd != null && vd.gyo;
        }
        return false;
    }

    /** The leash: the victim cannot move further from the user than the tether range; the gum stretches, then pulls them back. */
    private static void tether(LivingEntity victim, ServerPlayer caster) {
        Vec3 cv = centerOf(caster);
        Vec3 out = centerOf(victim).subtract(cv);
        double dist = out.length();
        double range = Tuning.GUM_TETHER_RANGE;
        if (dist <= range || dist < 1.0e-4) return;
        Vec3 outDir = out.scale(1.0 / dist);
        double over = dist - range;
        if (over > Tuning.GUM_TETHER_SNAP_OVER) { // flung, pearled or teleported far out: snapped straight back to the end of the leash
            Vec3 to = caster.position().add(outDir.x * (range - 1.0), 0, outDir.z * (range - 1.0));
            if (victim instanceof ServerPlayer vp) vp.connection.teleport(to.x, caster.getY(), to.z, vp.getYRot(), vp.getXRot());
            else victim.moveTo(to.x, caster.getY(), to.z, victim.getYRot(), victim.getXRot());
            return;
        }
        Vec3 v = victim.getDeltaMovement();
        double outward = v.dot(outDir);
        if (outward > 0) v = v.subtract(outDir.scale(outward)); // no momentum carries them further out
        v = v.subtract(outDir.scale(Math.min(1.5, 0.12 + over * 0.2))); // the harder they strain, the harder it pulls
        victim.setDeltaMovement(v);
        victim.hurtMarked = true;
        if (victim instanceof ServerPlayer vp) vp.connection.send(new ClientboundSetEntityMotionPacket(vp));
        if (victim instanceof Mob mob) mob.getNavigation().stop();
    }

    private static void lift(LivingEntity victim) {
        HatsuEffects.removeGum(victim);
        AddonNetwork.sendToTrackingAndSelf(PacketGumFx.tetherOff(victim.getId()), victim);
    }

    private static Entity find(MinecraftServer server, UUID id) {
        for (ServerLevel l : server.getAllLevels()) {
            Entity e = l.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    /** Death / logout: the thread goes, and so does every victim's debuff from this user's gum. */
    public static void clear(Player p) {
        UUID id = p.getUUID();
        STATE.remove(id);
        DRAWN.remove(id);
        BungeeBarrier.clear(p);
        BungeeBind.clear(p);
        Rope r = ROPES.get(id);
        if (r != null && p instanceof ServerPlayer sp) release(sp, r);
        ROPES.remove(id);
        READY_AT.remove(id);
        PULL_READY.remove(id);
        if (YANKS.remove(id) != null && p instanceof ServerPlayer ysp) AddonNetwork.sendToTrackingAndSelf(PacketGumFx.threadOff(ysp.getId()), ysp);
        MARKS.remove(id); // as a victim
        MinecraftServer server = p.getServer();
        Iterator<Map.Entry<UUID, Mark>> it = MARKS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Mark> en = it.next();
            if (!id.equals(en.getValue().caster)) continue;
            if (server != null && find(server, en.getKey()) instanceof LivingEntity victim) lift(victim);
            it.remove();
        }
    }
}
