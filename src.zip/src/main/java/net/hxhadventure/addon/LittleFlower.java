package net.hxhadventure.addon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketBombFx;
import net.hxhadventure.addon.network.PacketLfAura;
import net.hxhadventure.addon.network.PacketLfWarn;
import net.hxhadventure.addon.network.PacketLfMode;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;
import net.hxhadventure.utils.AllianceUtils;

/**
 * Genthru's Little Flower and Countdown (Hatsu kit 30, Conjurers).
 * <ul>
 *   <li><b>H: Little Flower.</b> A mode. While it is on, left click puts the left palm on whoever you are facing, right click the right
 *       palm, both together both palms. You are slowed while you hold on; when the contact time is up the palm goes off: the target takes
 *       the blast and so do you ({@link LittleFlowerTuning#SELF_FRACTION} of it, halved in Ken). Using both palms at once makes the whole blast 20%, for the target and for you.</li>
 *   <li><b>Z: Countdown.</b> Touch the target (Z) while saying "Bomber" in chat (either order, within
 *       {@link LittleFlowerTuning#TOUCH_WINDOW_TICKS} ticks), and the target must have had both abilities explained in the right order: Little
 *       Flower first, then Countdown. Seeing Little Flower go off counts as the first explanation. Then a bomb is conjured inside them.
 *       Its timer starts at {@link LittleFlowerTuning#COUNTDOWN_START} and counts heartbeats: 60 a minute at rest, double in a fight, faster when
 *       they run or are badly hurt. At 0 the target explodes from the inside, ten times Little Flower's power.</li>
 *   <li><b>The cure.</b> The victim touches Genthru and says "I caught the Bomber".</li>
 * </ul>
 * Everything is decided here on the server. Forge hooks: {@link LittleFlowerEvents}; the mouse buttons come from the client in {@code PacketLfHands}.
 */
public final class LittleFlower {
    private LittleFlower() {}

    public static final int KIT = 30;
    public static final String COUNTDOWN_ID = "lf_countdown";
    private static final String NAME = "Little Flower";
    private static final String NAME_COUNTDOWN = "Countdown";
    private static final String TAG = "hxh_countdown";

    private static final class State {
        boolean on, left, right;
        UUID touch;
        long touchStart;
        boolean both;
        long readyAt;
        long msgAt;
        long bomberAt = -1000000;
        boolean usedL, usedR, bothWarned;
        int auraFlags = 0;
        long auraStart;
        UUID lastTouched;
        long lastTouchedAt = -1000000;
    }

    /** What one potential victim has been told or shown by one user. -1 = not yet. */
    private static final class Progress {
        long lfAt = -1, cdAt = -1, touchAt = -1;
    }

    private static final class Bomb {
        UUID owner;
        float remaining;
        int sinceSave;
    }

    private record Touch(UUID target, long at) {}

    private static final Map<UUID, State> STATES = new ConcurrentHashMap<>();
    private static final Map<UUID, Map<UUID, Progress>> PROGRESS = new ConcurrentHashMap<>();
    /** victim -> bomb */
    private static final Map<UUID, Bomb> BOMBS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> CURE_SAID = new ConcurrentHashMap<>();
    private static final Map<UUID, Touch> CURE_TOUCH = new ConcurrentHashMap<>();
    /** What a player being held by Little Flower is pressing (their counter): the buttons now and when each was last pressed. */
    private static final class Guard {
        boolean l, r;
        long lAt = -1000000, rAt = -1000000;
    }

    private static final Map<UUID, Guard> GUARDS = new ConcurrentHashMap<>();

    /** player -> game time they last typed "Release" */
    private static final Map<UUID, Long> RELEASE_AT = new ConcurrentHashMap<>();
    /** Set by /hxh setcountdown: where new bombs start (6000 = 100 minutes at rest). */
    private static volatile float countdownStart = LittleFlowerTuning.COUNTDOWN_START;

    // ---------------------------------------------------------------- who and what

    public static boolean canUse(Combat c) {
        return c != null && c.getCurrentKit() == KIT;
    }

    /** Is the Little Flower mode (H) on right now? */
    public static boolean isOn(Player p) {
        State s = p == null ? null : STATES.get(p.getUUID());
        return s != null && s.on;
    }

    public static String[] extend(String[] base, Combat c) {
        if (!canUse(c)) return base;
        List<String> out = new ArrayList<>(Arrays.asList(base));
        if (c.getHatsuLevel() >= LittleFlowerTuning.COUNTDOWN_MIN_LEVEL) out.add(COUNTDOWN_ID);
        return out.toArray(new String[0]);
    }

    public static void registerAll(Map<String, java.util.function.Consumer<ServerPlayer>> m) {
        m.put(COUNTDOWN_ID, LittleFlower::countdown);
    }

    public static String displayName(String id) {
        return COUNTDOWN_ID.equals(id) ? "\u00a7f Countdown" : null;
    }

    private static State state(ServerPlayer sp) {
        return STATES.computeIfAbsent(sp.getUUID(), k -> new State());
    }

    private static void say(ServerPlayer sp, String text) {
        sp.displayClientMessage(Component.literal(text), true);
    }

    private static void anim(ServerPlayer sp, String name) {
        ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(sp.getUUID(), name, false), sp);
    }

    private static Combat gate(ServerPlayer sp, int minLevel, String name) {
        Combat c = Combat.get(sp);
        if (c == null || !sp.isAlive()) return null;
        if (!canUse(c)) {
            say(sp, "\u00a7cYour Hatsu is not Little Flower");
            return null;
        }
        if (c.getHatsuLevel() < minLevel) {
            say(sp, "\u00a7c" + name + " unlocks at Level " + minLevel);
            return null;
        }
        if (ExtrasHooks.hatsuForced(sp)) {
            say(sp, "\u00a75Forced Zetsu: your aura will not answer");
            return null;
        }
        if (HatsuEffects.isStunned(sp)) return null;
        return c;
    }

    private static boolean hostile(ServerPlayer sp, Entity e) {
        if (!(e instanceof LivingEntity le) || le == sp || !le.isAlive() || e instanceof ArmorStand) return false;
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        return !AllianceUtils.isAlly(e, sp);
    }

    /** Whoever the user faces within reach (the one most in front of them). */
    private static LivingEntity findTarget(ServerPlayer sp, double reach) {
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getLookAngle();
        LivingEntity best = null;
        double bestScore = 0.80;
        for (LivingEntity e : sp.level().getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(reach + 1.0), x -> hostile(sp, x))) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist > reach + e.getBbWidth() * 0.5 || dist < 1.0e-3) continue;
            double dot = to.scale(1.0 / dist).dot(look);
            if (dot > bestScore && sp.hasLineOfSight(e)) {
                bestScore = dot;
                best = e;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- H: Little Flower mode

    public static void toggle(ServerPlayer sp) {
        Combat c = gate(sp, LittleFlowerTuning.LITTLE_FLOWER_MIN_LEVEL, NAME);
        if (c == null) return;
        State s = state(sp);
        s.on = !s.on;
        if (!s.on) cancelTouch(sp, s);
        AddonNetwork.sendToPlayer(new PacketLfMode(s.on), sp);
        say(sp, s.on ? "\u00a76Little Flower on \u00a77(left click: left palm, right click: right palm, both: both palms)" : "\u00a77Little Flower off");
        sp.level().playSound(null, sp.blockPosition(), s.on ? SoundEvents.FLINTANDSTEEL_USE : SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.9f, s.on ? 1.5f : 1.2f);
    }

    /** The two mouse buttons as the client sees them (only reported while the mode is on). */
    public static void setHands(ServerPlayer sp, boolean left, boolean right) {
        State s = STATES.get(sp.getUUID());
        if (s == null || !s.on) return;
        s.left = left;
        s.right = right;
    }

    private static void cancelTouch(ServerPlayer sp, State s) {
        if (s.touch != null) {
            anim(sp, "stop_anim");
            warn(sp, s.touch, 0);
        }
        s.touch = null;
        s.both = false;
        s.left = false;
        s.right = false;
    }

    public static void tick(ServerPlayer sp) {
        tickInner(sp);
        State s = STATES.get(sp.getUUID());
        if (s != null) syncAura(sp, s);
    }

    /** Tells everyone who can see the user what their palms look like: bit 0 = mode on, bit 1 = left palm on someone, bit 2 = right palm on someone. */
    private static void syncAura(ServerPlayer sp, State s) {
        int f = 0;
        if (s.on) {
            f |= 1;
            if (s.touch != null) {
                if (s.left) f |= 2;
                if (s.right) f |= 4;
                if ((f & 6) == 0) f |= 6;
            }
        }
        if (f == s.auraFlags) return;
        s.auraFlags = f;
        AddonNetwork.sendToTrackingAndSelf(new PacketLfAura(sp.getId(), f, s.touchStart), sp);
    }

    /** What the one being held must press to brace: 0 nothing, 1 left click, 2 right click, 3 both. Only players can brace. */
    private static int needFor(State s) {
        if (s.both || (s.usedL && s.usedR)) return 3;
        if (s.usedL) return 2;   // left palm on them: they answer with the right button
        if (s.usedR) return 1;
        return 0;
    }

    private static void warn(ServerPlayer user, UUID victim, int need) {
        MinecraftServer server = user.getServer();
        ServerPlayer vp = server == null ? null : server.getPlayerList().getPlayer(victim);
        if (vp == null) return;
        if (need == 0) GUARDS.remove(victim);
        else GUARDS.computeIfAbsent(victim, k -> new Guard());
        AddonNetwork.sendToPlayer(new PacketLfWarn(need), vp);
    }

    /** The client of a player being held reports their mouse buttons (see {@link PacketLfWarn}). */
    public static void setGuard(ServerPlayer sp, boolean l, boolean r) {
        Guard g = GUARDS.get(sp.getUUID());
        if (g == null) return;
        long now = sp.level().getGameTime();
        g.l = l;
        g.r = r;
        if (l) g.lAt = now;
        if (r) g.rAt = now;
    }

    private static boolean braced(LivingEntity target, int need, long since) {
        if (!(target instanceof ServerPlayer tp) || need == 0) return false;
        Guard g = GUARDS.get(tp.getUUID());
        if (g == null) return false;
        long from = since - 4;
        boolean left = g.l || g.lAt >= from, right = g.r || g.rAt >= from;
        return switch (need) { case 1 -> left; case 2 -> right; default -> left && right; };
    }

    private static void tickInner(ServerPlayer sp) {
        State s = STATES.get(sp.getUUID());
        if (s == null || !s.on) return;
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || !sp.isAlive() || ExtrasHooks.hatsuForced(sp) || HatsuEffects.isStunned(sp)) {
            s.on = false;
            cancelTouch(sp, s);
            AddonNetwork.sendToPlayer(new PacketLfMode(false), sp);
            return;
        }
        long now = sp.level().getGameTime();
        boolean pressed = s.left || s.right;
        if (s.touch != null) {
            Entity t = ((ServerLevel) sp.level()).getEntity(s.touch);
            boolean ok = pressed && t instanceof LivingEntity le && le.isAlive() && le.distanceTo(sp) <= LittleFlowerTuning.LF_REACH + 1.5;
            if (!ok) {
                cancelTouch(sp, s);
                return;
            }
            if (!s.both && s.left && s.right) {
                s.both = true;
                anim(sp, "lf_touch_both");
            }
            s.usedL |= s.left;
            s.usedR |= s.right;
            if (s.both && s.touch != null && !s.bothWarned) {
                s.bothWarned = true;
                warn(sp, s.touch, 3);
            }
            // holding on to somebody: much slower
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, LittleFlowerTuning.LF_SLOW_AMPLIFIER, false, false, false));
            if (now - s.touchStart >= LittleFlowerTuning.LF_CONTACT_TICKS) {
                LivingEntity target = (LivingEntity) t;
                boolean both = s.both;
                boolean countered = braced(target, needFor(s), s.touchStart);
                s.touch = null;
                s.both = false;
                s.readyAt = now + LittleFlowerTuning.LF_COOLDOWN_TICKS;
                anim(sp, "stop_anim");
                detonate(sp, c, target, both, countered);
                warn(sp, target.getUUID(), 0);
            }
            return;
        }
        if (!pressed || now < s.readyAt) return;
        LivingEntity target = findTarget(sp, LittleFlowerTuning.LF_REACH);
        if (target == null) {
            if (now - s.msgAt > 20) {
                say(sp, "\u00a77Nobody within reach");
                s.msgAt = now;
            }
            return;
        }
        if (c.getCurrentEnergy() < LittleFlowerTuning.LF_COST) {
            if (now - s.msgAt > 20) {
                say(sp, "\u00a7cNot enough energy");
                s.msgAt = now;
            }
            return;
        }
        s.touch = target.getUUID();
        s.touchStart = now;
        s.both = s.left && s.right;
        s.usedL = s.left;
        s.usedR = s.right;
        s.bothWarned = s.both;
        warn(sp, target.getUUID(), needFor(s));
        anim(sp, s.both ? "lf_touch_both" : s.left ? "lf_touch_left" : "lf_touch_right");
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 0.7f, 1.6f);
        registerTouch(sp, c, s, target); // a hand on someone is also a touch for Countdown
    }

    private static void detonate(ServerPlayer sp, Combat c, LivingEntity target, boolean both, boolean countered) {
        if (c.getCurrentEnergy() < LittleFlowerTuning.LF_COST) return;
        c.consumeEnergy(LittleFlowerTuning.LF_COST);
        ServerLevel level = (ServerLevel) sp.level();
        float dmg = LittleFlowerTuning.LF_DAMAGE * c.getSpiritBonus() * Vows.power(sp, "little_flower") * Vows.hatsuDamageMult(sp);
        if (both) dmg *= LittleFlowerTuning.BOTH_HANDS_DAMAGE_MULT; // two palms at once: everything is 20%, the target's share and yours
        float taken = countered ? dmg * LittleFlowerTuning.BRACE_MULT : dmg; // they pressed the right button: the palm lands at a fifth
        Vows.hatsuHurt(target, level.damageSources().playerAttack(sp), taken);
        if (countered) {
            level.playSound(null, target.blockPosition(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0f, 1.2f);
            say(sp, "\u00a77" + target.getName().getString() + " braced against the palm");
            if (target instanceof ServerPlayer tp) say(tp, "\u00a7aYou braced: the blast lands at " + (int) (LittleFlowerTuning.BRACE_MULT * 100) + "%");
        }
        Vec3 away = target.position().subtract(sp.position()).multiply(1, 0, 1);
        if (away.lengthSqr() > 1.0e-4) {
            away = away.normalize().scale(0.5);
            target.setDeltaMovement(target.getDeltaMovement().add(away.x, 0.2, away.z));
            target.hurtMarked = true;
        }
        blastFx(level, target.getBoundingBox().getCenter(), 0.8f);
        // the user is in the blast too
        float self = dmg * LittleFlowerTuning.SELF_FRACTION;
        if (NenAddonData.get(sp).ken) self *= LittleFlowerTuning.KEN_SELF_MULT;
        sp.hurt(level.damageSources().explosion(sp, sp), self);
        // everyone who saw it now knows what Little Flower is
        long now = level.getGameTime();
        for (LivingEntity w : level.getEntitiesOfClass(LivingEntity.class, target.getBoundingBox().inflate(LittleFlowerTuning.WITNESS_RANGE), e -> e != sp && e.isAlive())) {
            if (w != target && !w.hasLineOfSight(target) && !w.hasLineOfSight(sp)) continue;
            Progress p = progress(sp, w);
            if (p.lfAt < 0 || now - p.lfAt > LittleFlowerTuning.KNOWLEDGE_TICKS) p.lfAt = now;
        }
    }

    private static void blastFx(ServerLevel level, Vec3 at, float volume) {
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 3, 0.2, 0.2, 0.2, 0.0);
        level.sendParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 14, 0.3, 0.3, 0.3, 0.05);
        level.sendParticles(ParticleTypes.SMOKE, at.x, at.y, at.z, 10, 0.3, 0.3, 0.3, 0.03);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, volume, 1.5f);
    }

    // ---------------------------------------------------------------- Countdown

    private static Progress progress(ServerPlayer owner, LivingEntity victim) {
        return PROGRESS.computeIfAbsent(owner.getUUID(), k -> new ConcurrentHashMap<>()).computeIfAbsent(victim.getUUID(), k -> new Progress());
    }

    /** Z: lay a hand on whoever you are facing for Countdown. With nobody there, shows the time left on your bombs. */
    private static void countdown(ServerPlayer sp) {
        Combat c = gate(sp, LittleFlowerTuning.COUNTDOWN_MIN_LEVEL, NAME_COUNTDOWN);
        if (c == null) return;
        LivingEntity target = findTarget(sp, LittleFlowerTuning.LF_REACH + 0.5);
        if (target == null) {
            StringBuilder sb = new StringBuilder();
            ServerLevel level = (ServerLevel) sp.level();
            for (Map.Entry<UUID, Bomb> e : BOMBS.entrySet()) {
                if (!sp.getUUID().equals(e.getValue().owner)) continue;
                Entity v = level.getEntity(e.getKey());
                sb.append(v == null ? "?" : v.getName().getString()).append(" ").append((int) e.getValue().remaining).append("   ");
            }
            say(sp, sb.length() == 0 ? "\u00a77Countdown: touch someone and say \"Bomber\"" : "\u00a74Countdown: \u00a7f" + sb);
            return;
        }
        State s = state(sp);
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        registerTouch(sp, c, s, target);
        Progress p = progress(sp, target);
        if (BOMBS.containsKey(target.getUUID())) return; // already carries one
        if (p.lfAt < 0) say(sp, "\u00a77" + target.getName().getString() + " has not seen or heard of Little Flower yet \u00a78(type it in chat: explain Little Flower's palm, then Countdown's bomb)");
        else if (p.cdAt < 0 || p.cdAt < p.lfAt) say(sp, "\u00a77Now explain Countdown to " + target.getName().getString() + " in chat \u00a78(e.g. \"Countdown puts a bomb in you\"), then type \"Bomber\"");
        else if (p.touchAt < 0) say(sp, "\u00a77You touch " + target.getName().getString() + "... \u00a78(type \"Bomber\" in chat)");
    }

    private static void registerTouch(ServerPlayer sp, Combat c, State s, LivingEntity target) {
        if (c.getHatsuLevel() < LittleFlowerTuning.COUNTDOWN_MIN_LEVEL) return;
        long now = sp.level().getGameTime();
        s.lastTouched = target.getUUID();
        s.lastTouchedAt = now;
        if (now - s.bomberAt <= LittleFlowerTuning.TOUCH_WINDOW_TICKS) {
            progress(sp, target).touchAt = now;
            tryComplete(sp, c, target);
        }
    }

    /** Everything said in chat (the server calls this on its own thread). */
    public static void onChat(ServerPlayer sp, String raw) {
        String text = raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z ]", " ").replaceAll("\\s+", " ").trim();
        checkCureSpeech(sp, text);
        if ((" " + text + " ").contains(" release ")) tryRelease(sp);
        Combat c = Combat.get(sp);
        if (c == null || !canUse(c) || c.getHatsuLevel() < LittleFlowerTuning.COUNTDOWN_MIN_LEVEL || !sp.isAlive()) return;
        State s = state(sp);
        long now = sp.level().getGameTime();
        if ((" " + text + " ").contains(" bomber ")) {
            s.bomberAt = now;
            if (s.lastTouched != null && now - s.lastTouchedAt <= LittleFlowerTuning.TOUCH_WINDOW_TICKS) {
                Entity t = ((ServerLevel) sp.level()).getEntity(s.lastTouched);
                if (t instanceof LivingEntity le && le.isAlive() && le.distanceTo(sp) <= LittleFlowerTuning.LF_REACH + 2.0) {
                    progress(sp, le).touchAt = now;
                    tryComplete(sp, c, le);
                }
            }
        }
        boolean lf = text.contains("little flower") && containsAny(text, "palm", "hand", "explo", "detonat", "touch", "blast");
        boolean cd = text.contains("countdown") && containsAny(text, "bomb", "timer", "pulse", "heart", "explo", "touch", "attach", "say");
        if (!lf && !cd) return;
        for (LivingEntity l : sp.level().getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(LittleFlowerTuning.HEAR_RANGE), e -> e != sp && e.isAlive())) {
            Progress p = progress(sp, l);
            if (lf && (p.lfAt < 0 || now - p.lfAt > LittleFlowerTuning.KNOWLEDGE_TICKS)) p.lfAt = now;
            if (cd) {
                if (p.lfAt >= 0) p.cdAt = now;
                else say(sp, "\u00a77Little Flower has to be explained (or shown) before Countdown");
            }
            tryComplete(sp, c, l);
        }
    }

    private static boolean containsAny(String text, String... words) {
        for (String w : words) if (text.contains(w)) return true;
        return false;
    }

    /** Both conditions met (the touch while saying Bomber, and Little Flower then Countdown explained / shown): the bomb goes in. */
    private static void tryComplete(ServerPlayer sp, Combat c, LivingEntity victim) {
        Progress p = progress(sp, victim);
        long now = sp.level().getGameTime();
        if (p.touchAt < 0 || p.lfAt < 0 || p.cdAt < 0 || p.cdAt < p.lfAt) return;
        if (now - p.touchAt > LittleFlowerTuning.TOUCH_VALID_TICKS || now - p.cdAt > LittleFlowerTuning.KNOWLEDGE_TICKS) return;
        if (BOMBS.containsKey(victim.getUUID())) return;
        long mine = BOMBS.values().stream().filter(b -> sp.getUUID().equals(b.owner)).count();
        if (mine >= LittleFlowerTuning.MAX_BOMBS) {
            say(sp, "\u00a7cYou already have " + LittleFlowerTuning.MAX_BOMBS + " bombs out");
            return;
        }
        if (c.getCurrentEnergy() < LittleFlowerTuning.COUNTDOWN_COST) {
            say(sp, "\u00a7cNot enough energy (" + (int) LittleFlowerTuning.COUNTDOWN_COST + " needed)");
            return;
        }
        c.consumeEnergy(LittleFlowerTuning.COUNTDOWN_COST);
        Bomb b = new Bomb();
        b.owner = sp.getUUID();
        b.remaining = countdownStart;
        BOMBS.put(victim.getUUID(), b);
        save(victim, b);
        syncBomb(victim, true);
        p.touchAt = -1;
        p.cdAt = -1;
        say(sp, "\u00a74Countdown: \u00a7f" + victim.getName().getString() + " \u00a74carries a bomb \u00a77(" + (int) b.remaining + ")");
        if (victim instanceof ServerPlayer vp) vp.displayClientMessage(Component.literal("\u00a74Something is ticking inside you..."), false);
        ((ServerLevel) victim.level()).playSound(null, victim.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 1.0f, 0.6f);
    }

    // ---- the bomb you can see: a small device on the victim's chest (drawn by LittleFlowerClient) ----

    /** Tells everyone who can see the victim (and the victim) that the bomb is on or off. */
    private static void syncBomb(Entity victim, boolean on) {
        if (victim == null || victim.level().isClientSide) return;
        AddonNetwork.sendToTrackingAndSelf(new PacketBombFx(victim.getId(), on), victim);
    }

    /** A player has just started to see this creature: if it carries a bomb they must see it too. */
    public static void onStartTracking(ServerPlayer viewer, Entity target) {
        if (target != null && BOMBS.containsKey(target.getUUID())) AddonNetwork.sendToPlayer(new PacketBombFx(target.getId(), true), viewer);
    }

    /** A victim who logs back in sees their own bomb again (third person). */
    public static void onLogin(ServerPlayer sp) {
        if (BOMBS.containsKey(sp.getUUID())) AddonNetwork.sendToPlayer(new PacketBombFx(sp.getId(), true), sp);
    }

    private static void save(LivingEntity v, Bomb b) {
        v.getPersistentData().putFloat(TAG, b.remaining);
        v.getPersistentData().putUUID(TAG + "_owner", b.owner);
    }

    /** A creature that carried a bomb when the world was saved carries it again. */
    public static void restore(Entity e) {
        if (!(e instanceof LivingEntity v) || v.level().isClientSide) return;
        if (!v.getPersistentData().contains(TAG) || !v.getPersistentData().hasUUID(TAG + "_owner") || BOMBS.containsKey(v.getUUID())) return;
        Bomb b = new Bomb();
        b.remaining = v.getPersistentData().getFloat(TAG);
        b.owner = v.getPersistentData().getUUID(TAG + "_owner");
        BOMBS.put(v.getUUID(), b);
        if (!(v instanceof ServerPlayer)) syncBomb(v, true); // a player gets it from onLogin once their connection is ready
    }

    private static void drop(UUID victim, Entity entity) {
        BOMBS.remove(victim);
        syncBomb(entity, false);
        if (entity != null) {
            entity.getPersistentData().remove(TAG);
            entity.getPersistentData().remove(TAG + "_owner");
        }
    }

    /** The heart rate of a victim, in beats a minute. */
    public static float heartRate(LivingEntity v) {
        float bpm = LittleFlowerTuning.BASE_BPM;
        if (v.isSprinting()) bpm += LittleFlowerTuning.SPRINT_BPM_BONUS;
        if (v.getHealth() < v.getMaxHealth() * 0.4f) bpm += LittleFlowerTuning.LOW_HEALTH_BPM_BONUS;
        boolean aggro = (v.getLastHurtByMob() != null && v.tickCount - v.getLastHurtByMobTimestamp() < 200)
            || (v.getLastHurtMob() != null && v.tickCount - v.getLastHurtMobTimestamp() < 200)
            || (v instanceof Mob m && m.getTarget() != null);
        if (aggro) bpm *= LittleFlowerTuning.AGGRO_BPM_MULT;
        return Math.min(bpm, LittleFlowerTuning.MAX_BPM);
    }

    public static void serverTick(MinecraftServer server) {
        if (server == null || BOMBS.isEmpty()) return;
        for (Map.Entry<UUID, Bomb> en : new HashMap<>(BOMBS).entrySet()) {
            Entity found = null;
            for (ServerLevel l : server.getAllLevels()) {
                found = l.getEntity(en.getKey());
                if (found != null) break;
            }
            if (found == null) continue; // not loaded: the bomb waits
            if (!(found instanceof LivingEntity v) || !v.isAlive()) {
                drop(en.getKey(), found);
                continue;
            }
            Bomb b = en.getValue();
            // the timer follows the pulse: beats a minute / 60 / 20 ticks = beats a tick
            b.remaining -= heartRate(v) / 1200f * LittleFlowerTuning.TIME_SCALE;
            if (++b.sinceSave >= 100) {
                b.sinceSave = 0;
                save(v, b);
            }
            if (b.remaining <= 60f && b.remaining > 0f && v instanceof ServerPlayer vp && vp.tickCount % 20 == 0) {
                vp.displayClientMessage(Component.literal("\u00a74" + (int) b.remaining), true);
            }
            if (b.remaining <= 0f) explode(server, v, b);
        }
    }

    private static void explode(MinecraftServer server, LivingEntity v, Bomb b) {
        drop(v.getUUID(), v);
        ServerLevel level = (ServerLevel) v.level();
        ServerPlayer owner = server.getPlayerList().getPlayer(b.owner);
        float dmg = LittleFlowerTuning.LF_DAMAGE * LittleFlowerTuning.BLAST_MULT;
        net.minecraft.world.damagesource.DamageSource src = level.damageSources().magic();
        if (owner != null) {
            Combat oc = Combat.get(owner);
            if (oc != null) dmg *= oc.getSpiritBonus() * Vows.hatsuDamageMult(owner);
            src = level.damageSources().indirectMagic(owner, owner); // from the inside: armour does not help
        }
        blastFx(level, v.getBoundingBox().getCenter(), 3.0f);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, v.getX(), v.getY() + v.getBbHeight() * 0.5, v.getZ(), 1, 0, 0, 0, 0);
        Vows.hatsuHurt(v, src, dmg);
        breakBlocks(level, v.getBoundingBox().getCenter());
    }

    /** The blast tears a ball of blocks out of the world (unbreakable ones stay). */
    private static void breakBlocks(ServerLevel level, Vec3 at) {
        int r = LittleFlowerTuning.BLAST_BLOCK_RADIUS;
        if (r <= 0) return;
        BlockPos centre = BlockPos.containing(at);
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        java.util.List<BlockPos> doomed = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dy * dy + dz * dz > r * r) continue;
                    p.set(centre.getX() + dx, centre.getY() + dy, centre.getZ() + dz);
                    if (!level.isInWorldBounds(p) || !level.hasChunkAt(p)) continue;
                    BlockState st = level.getBlockState(p);
                    if (st.isAir() || st.getDestroySpeed(level, p) < 0f) continue;
                    doomed.add(p.immutable());
                }
            }
        }
        for (BlockPos bp : doomed) level.removeBlock(bp, false);
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 12, r * 0.4, r * 0.4, r * 0.4, 0.0);
    }

    // ---------------------------------------------------------------- Release

    /**
     * Genthru, Sub and Bara touch thumbs together and all say "Release". Three players within {@link LittleFlowerTuning#RELEASE_RANGE} of
     * each other who have each typed "Release" lately set off the bombs of ONE of them (whoever of the three typed first and has bombs out).
     * The word is spent for all three, so for somebody else's bombs they have to do it again.
     */
    private static void tryRelease(ServerPlayer sp) {
        long now = sp.level().getGameTime();
        RELEASE_AT.put(sp.getUUID(), now);
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        java.util.List<ServerPlayer> near = new ArrayList<>();
        for (ServerPlayer o : server.getPlayerList().getPlayers()) {
            Long at = RELEASE_AT.get(o.getUUID());
            if (at == null || now - at > LittleFlowerTuning.RELEASE_WINDOW_TICKS || !o.isAlive()) continue;
            if (o != sp && (o.level() != sp.level() || o.distanceTo(sp) > LittleFlowerTuning.RELEASE_RANGE)) continue;
            near.add(o);
        }
        if (near.size() < 3) {
            say(sp, "\u00a77Release: " + near.size() + "/3 (three of you, within " + (int) LittleFlowerTuning.RELEASE_RANGE + " blocks, all saying \"Release\")");
            return;
        }
        near.sort(java.util.Comparator.comparingLong(o -> RELEASE_AT.get(o.getUUID())));
        // a triple that includes the speaker where every pair is close enough
        java.util.List<ServerPlayer> group = null;
        outer:
        for (int i = 0; i < near.size(); i++) {
            for (int j = i + 1; j < near.size(); j++) {
                for (int k = j + 1; k < near.size(); k++) {
                    ServerPlayer a = near.get(i), b = near.get(j), c = near.get(k);
                    if (a != sp && b != sp && c != sp) continue;
                    if (a.distanceTo(b) <= LittleFlowerTuning.RELEASE_RANGE && a.distanceTo(c) <= LittleFlowerTuning.RELEASE_RANGE && b.distanceTo(c) <= LittleFlowerTuning.RELEASE_RANGE) {
                        group = java.util.List.of(a, b, c);
                        break outer;
                    }
                }
            }
        }
        if (group == null) {
            say(sp, "\u00a77Release: all three of you have to be within " + (int) LittleFlowerTuning.RELEASE_RANGE + " blocks of each other");
            return;
        }
        ServerPlayer owner = null;
        for (ServerPlayer g : group) { // earliest "Release" first
            boolean has = false;
            for (Bomb b : BOMBS.values()) if (g.getUUID().equals(b.owner)) { has = true; break; }
            if (has) { owner = g; break; }
        }
        if (owner == null) {
            say(sp, "\u00a77Release: none of you has a bomb out");
            return;
        }
        for (ServerPlayer g : group) RELEASE_AT.remove(g.getUUID()); // spent: the others must say it again for their own bombs
        int n = 0;
        for (Map.Entry<UUID, Bomb> en : new HashMap<>(BOMBS).entrySet()) {
            if (!owner.getUUID().equals(en.getValue().owner)) continue;
            Entity v = null;
            for (ServerLevel l : server.getAllLevels()) { v = l.getEntity(en.getKey()); if (v != null) break; }
            if (v instanceof LivingEntity le && le.isAlive()) {
                explode(server, le, en.getValue());
                n++;
            } else if (v != null) {
                drop(en.getKey(), v); // dead: the bomb is gone with it (an unloaded creature's bomb just waits)
            }
        }
        for (ServerPlayer g : group) say(g, "\u00a74Release: \u00a7f" + owner.getName().getString() + "'s " + n + " bomb" + (n == 1 ? "" : "s") + " detonated");
    }

    public static com.mojang.brigadier.builder.LiteralArgumentBuilder<net.minecraft.commands.CommandSourceStack> commandNode() {
        return net.minecraft.commands.Commands.literal("setcountdown")
            .requires(src -> src.hasPermission(2))
            .then(net.minecraft.commands.Commands.argument("seconds", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 360000))
                .executes(ctx -> {
                    int secs = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "seconds");
                    countdownStart = secs;
                    ctx.getSource().sendSuccess(() -> Component.literal("Countdown bombs planted from now on start at " + secs
                        + " (about " + secs + " seconds at rest; a fight halves it, running and low health shorten it more). 6000 is the default."), true);
                    return 1;
                }));
    }

    // ---------------------------------------------------------------- the cure

    public static void onTouch(Player p, Entity target) {
        if (!(p instanceof ServerPlayer sp) || !BOMBS.containsKey(sp.getUUID())) return;
        CURE_TOUCH.put(sp.getUUID(), new Touch(target.getUUID(), sp.level().getGameTime()));
        checkCure(sp);
    }

    private static void checkCureSpeech(ServerPlayer sp, String text) {
        if (!BOMBS.containsKey(sp.getUUID()) || !text.contains("i caught the bomber")) return;
        CURE_SAID.put(sp.getUUID(), sp.level().getGameTime());
        checkCure(sp);
    }

    private static void checkCure(ServerPlayer victim) {
        Bomb b = BOMBS.get(victim.getUUID());
        Long said = CURE_SAID.get(victim.getUUID());
        Touch t = CURE_TOUCH.get(victim.getUUID());
        if (b == null || said == null || t == null || !t.target().equals(b.owner)) return;
        long now = victim.level().getGameTime();
        if (now - said > LittleFlowerTuning.TOUCH_WINDOW_TICKS || now - t.at() > LittleFlowerTuning.TOUCH_WINDOW_TICKS) return;
        Entity owner = ((ServerLevel) victim.level()).getEntity(b.owner);
        if (owner == null || owner.distanceTo(victim) > LittleFlowerTuning.LF_REACH + 2.0) return;
        drop(victim.getUUID(), victim);
        CURE_SAID.remove(victim.getUUID());
        CURE_TOUCH.remove(victim.getUUID());
        victim.displayClientMessage(Component.literal("\u00a7aThe ticking stops."), true);
        if (owner instanceof ServerPlayer op) op.displayClientMessage(Component.literal("\u00a7c" + victim.getName().getString() + " caught the Bomber: your bomb is gone"), true);
        ((ServerLevel) victim.level()).sendParticles(ParticleTypes.HAPPY_VILLAGER, victim.getX(), victim.getY() + 1.0, victim.getZ(), 12, 0.4, 0.5, 0.4, 0.0);
    }

    // ---------------------------------------------------------------- clean-up

    /** Death, logout: the mode and any touch end; bombs already planted stay. */
    public static void clear(ServerPlayer sp) {
        RELEASE_AT.remove(sp.getUUID());
        GUARDS.remove(sp.getUUID());
        State s = STATES.remove(sp.getUUID());
        if (s != null && s.touch != null) {
            anim(sp, "stop_anim");
            warn(sp, s.touch, 0);
        }
        AddonNetwork.sendToTrackingAndSelf(new PacketLfAura(sp.getId(), 0, 0), sp);
        AddonNetwork.sendToPlayer(new PacketLfMode(false), sp);
    }

    /** Losing the Nen or changing the Hatsu: every bomb you planted goes with it. */
    public static void release(ServerPlayer sp) {
        clear(sp);
        PROGRESS.remove(sp.getUUID());
        MinecraftServer server = sp.getServer();
        for (Map.Entry<UUID, Bomb> en : new HashMap<>(BOMBS).entrySet()) {
            if (!sp.getUUID().equals(en.getValue().owner)) continue;
            Entity e = null;
            if (server != null) for (ServerLevel l : server.getAllLevels()) { e = l.getEntity(en.getKey()); if (e != null) break; }
            drop(en.getKey(), e);
        }
    }
}
