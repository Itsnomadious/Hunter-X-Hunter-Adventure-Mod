package net.hxhadventure.abilities;

import java.util.HashMap;
import java.util.Random;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.hxhadventure.entity.ModEntities;
import net.hxhadventure.entity.custom.AuraEntity;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;
import net.hxhadventure.networking.PacketSyncAuraColor;
import net.hxhadventure.networking.PacketSyncNenStatus;

public class AbilityRegistry {
   private static final HashMap<String, Consumer<ServerPlayer>> ABILITIES = new HashMap<>();
   private static final HashMap<UUID, AuraEntity> ACTIVE_AURAS = new HashMap<>();
   private static final UUID TEN_ARMOR_UUID = UUID.fromString("11111111-2222-3333-4444-555555555555");
   private static final UUID TEN_TOUGHNESS_UUID = UUID.fromString("22222222-3333-4444-5555-666666666666");
   public static final UUID REN_SPEED_UUID = UUID.fromString("33333333-4444-5555-6666-777777777777");

   public AbilityRegistry() {
   }

   public static void execute(String id, ServerPlayer player) {
      if (ABILITIES.containsKey(id)) {
         ABILITIES.get(id).accept(player);
      } else {
         System.out.println("LOG ERROR: Ability " + id + " not found!");
      }
   }

   public static void toggleTen(Player player, boolean active) {
      applyTen(player, active, false);
   }

   /**
    * Ten on or off. {@code quiet} is used by the automatic Ten (it switches itself back on the moment Zetsu, Ko or a chain lets go):
    * no message, sound, flash or raise-aura animation, so it never spams the player.
    * Ten no longer gives armor or toughness: its speed, durability and damage come from the addon (NenAddonData).
    */
   public static void applyTen(Player player, boolean active, boolean quiet) {
      Level level = player.level();
      Combat stats = CombatManager.get(player);
      if (stats.isTenActive() != active) {
         stats.setTenActive(active);
         if (active) {
            if (!level.isClientSide) {
               if (!quiet) {
                  player.displayClientMessage(Component.literal("\u00a7aTen: On"), true);
                  ((ServerLevel)level).sendParticles(ParticleTypes.FLASH, player.getX(), player.getY() + 1.0, player.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
                  ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(player.getUUID(), "aura_up", false), player);
               }

               int hatsuLvl = stats.getHatsuLevel();
               int regenAmplifier = Math.min(1, hatsuLvl / 20);
               player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 400, regenAmplifier, false, false, true));
               if (player instanceof ServerPlayer serverPlayer) {
                  ModMessages.sendToPlayer(
                     new PacketSyncNenStatus(stats.hasNenUnlocked(), stats.getNenType(), stats.isTenActive(), stats.isAuraActive()), serverPlayer
                  );
               }
            }
         } else if (!level.isClientSide) {
            if (!quiet) {
               player.displayClientMessage(Component.literal("\u00a7cTen: Off"), true);
            }

            AttributeInstance armorAttrx = player.getAttribute(Attributes.ARMOR);
            if (armorAttrx != null) {
               armorAttrx.removeModifier(TEN_ARMOR_UUID);
            }

            AttributeInstance toughnessAttrx = player.getAttribute(Attributes.ARMOR_TOUGHNESS);
            if (toughnessAttrx != null) {
               toughnessAttrx.removeModifier(TEN_TOUGHNESS_UUID);
            }

            player.removeEffect(MobEffects.REGENERATION);
            if (player instanceof ServerPlayer serverPlayer) {
               ModMessages.sendToPlayer(
                  new PacketSyncNenStatus(stats.hasNenUnlocked(), stats.getNenType(), stats.isTenActive(), stats.isAuraActive()), serverPlayer
               );
            }
         }
      }
   }

   /** Resize the Ren aura a player already has out (the Mastery screen's size slider). */
   public static void setActiveAuraScale(Player player, float scale) {
      AuraEntity aura = ACTIVE_AURAS.get(player.getUUID());
      if (aura != null) {
         aura.setAuraScale(scale);
      }
   }

   public static void toggleRen(Player player, boolean active) {
      Level level = player.level();
      UUID uuid = player.getUUID();
      Combat stats = CombatManager.get(player);
      if (stats.isAuraActive() != active) {
         if (!active) {
            if (ACTIVE_AURAS.containsKey(uuid)) {
               AuraEntity aura = ACTIVE_AURAS.get(uuid);
               if (aura != null) {
                  aura.discard();
               }

               ACTIVE_AURAS.remove(uuid);
            }

            stats.setAuraActive(false);
            if (!level.isClientSide) {
               player.displayClientMessage(Component.literal("\u00a7cRen: Off"), true);
               AttributeInstance speedAttr = player.getAttribute(Attributes.MOVEMENT_SPEED);
               if (speedAttr != null) {
                  speedAttr.removeModifier(REN_SPEED_UUID);
               }

               player.removeEffect(MobEffects.JUMP);
               if (player instanceof ServerPlayer serverPlayer) {
                  ModMessages.sendToPlayer(
                     new PacketSyncNenStatus(stats.hasNenUnlocked(), stats.getNenType(), stats.isTenActive(), stats.isAuraActive()), serverPlayer
                  );
               }
            }
         } else {
            if (stats.getCurrentEnergy() < 5.0F) {
               if (!level.isClientSide) {
                  player.displayClientMessage(Component.literal("\u00a7cNot enough energy to activate Ren!"), true);
               }

               return;
            }

            if (!level.isClientSide) {
               if (ACTIVE_AURAS.containsKey(uuid)) {
                  AuraEntity oldAura = ACTIVE_AURAS.remove(uuid);
                  if (oldAura != null) {
                     oldAura.discard();
                  }
               }

               AuraEntity aura = new AuraEntity((EntityType<?>)ModEntities.AURA_ENTITY.get(), level);
               aura.setPos(player.getX(), player.getY(), player.getZ());
               aura.setOwner(player);
               int currentColor = getOrCreatePlayerAuraColor(player);
               aura.setAuraColorIndex(currentColor - 1);
               aura.setAuraType(0);
               aura.setAuraScale(net.hxhadventure.addon.NenAddonData.get(player).renScale());
               aura.setIntroScale(net.hxhadventure.addon.NenAddonData.get(player).renIntroScale());
               level.addFreshEntity(aura);
               ACTIVE_AURAS.put(uuid, aura);
               stats.setAuraActive(true);
               int hatsuLvl = stats.getHatsuLevel();
               // Ren no longer has a speed bonus of its own: Ren doubles Ten, and the addon applies that (NenAddonData.refreshModifiers)
               AttributeInstance speedAttrx = player.getAttribute(Attributes.MOVEMENT_SPEED);
               if (speedAttrx != null) {
                  speedAttrx.removeModifier(REN_SPEED_UUID);
               }

               int jumpAmplifier = hatsuLvl / 15;
               player.addEffect(new MobEffectInstance(MobEffects.JUMP, 999999, jumpAmplifier, false, false, true));
               ((ServerLevel)level).sendParticles(ParticleTypes.FLASH, player.getX(), player.getY() + 1.0, player.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
               boolean bigRen = net.hxhadventure.addon.NenAddonData.get(player).renScale() >= net.hxhadventure.addon.Tuning.REN_BIG_SOUND_SIZE;
               level.playSound(null, player.blockPosition(), (bigRen ? net.hxhadventure.addon.HxHSounds.REN_BIG : net.hxhadventure.addon.HxHSounds.REN).get(), SoundSource.PLAYERS, 1.0F, 1.0F);
               player.displayClientMessage(Component.literal("\u00a7bRen: On"), true);
               ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(player.getUUID(), "aura_up", false), player);
               if (player instanceof ServerPlayer serverPlayer) {
                  ModMessages.sendToPlayer(
                     new PacketSyncNenStatus(stats.hasNenUnlocked(), stats.getNenType(), stats.isTenActive(), stats.isAuraActive()), serverPlayer
                  );
               }
            }
         }
      }
   }

   public static int getOrCreatePlayerAuraColor(Player player) {
      int color = player.getPersistentData().getInt("HxHCraft_PermanentAuraColor");
      if (color == 0) {
         // Fallback only (colour is normally rolled when Nen awakens, see NenProfile.rollAwakening). Same rules: nothing else affects it.
         boolean rare = player.level().getServer() != null
            && player.level().getServer().getGameRules().getBoolean(net.hxhadventure.addon.NenGameRules.RARE_COLOURS);
         color = net.hxhadventure.addon.NenRarity.rollColour(new Random(), rare);
         player.getPersistentData().putInt("HxHCraft_PermanentAuraColor", color);
      }

      return color;
   }

   public static void syncAuraColor(ServerPlayer player) {
      int color = player.getPersistentData().getInt("HxHCraft_PermanentAuraColor");
      ModMessages.sendToPlayer(new PacketSyncAuraColor(color), player);
   }

   public static void updateActiveAuraColor(Player player) {
      UUID uuid = player.getUUID();
      if (ACTIVE_AURAS.containsKey(uuid)) {
         AuraEntity aura = ACTIVE_AURAS.get(uuid);
         if (aura != null && aura.isAlive()) {
            int newColor = getOrCreatePlayerAuraColor(player) - 1;
            aura.setAuraColorIndex(newColor);
         }
      }
   }

   public static boolean isRenActive(Player player) {
      Combat combat = Combat.get(player);
      return combat != null ? combat.isAuraActive() : false;
   }

   static {
      ABILITIES.put("nen_attack", player -> CombatManager.get(player).performAttack());
      ABILITIES.put("nen_strong", player -> CombatManager.get(player).chargeStrongAttack());
      ABILITIES.put("nen_strong_release", player -> CombatManager.get(player).releaseStrongAttack());
      ABILITIES.put("nen_barrage", player -> CombatManager.get(player).handleBarrage());
      ABILITIES.put("ten_toggle", player -> {
         Combat stats = CombatManager.get(player);
         toggleTen(player, !stats.isTenActive());
      });
      ABILITIES.put("ren_toggle", player -> {
         Combat stats = CombatManager.get(player);
         toggleRen(player, !stats.isAuraActive());
      });
   }
}
