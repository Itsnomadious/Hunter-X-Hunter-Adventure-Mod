package net.hxhadventure.abilities;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

public class CombatManager {
   private static final Map<Player, Combat> COMBAT_DATA = new WeakHashMap<>();

   public CombatManager() {
   }

   public static Combat get(Player player) {
      if (player == null) {
         return null;
      } else {
         Combat data = COMBAT_DATA.computeIfAbsent(player, p -> new Combat(p));
         if (data.getPlayer() != player) {
            data.setPlayer(player);
         }

         return data;
      }
   }

   public static void refreshPlayer(Player newPlayer) {
      Combat data = get(newPlayer);
      data.setPlayer(newPlayer);
   }

   public static void savePlayerPersistentData(Player player, CompoundTag persistentData) {
      Combat data = COMBAT_DATA.get(player);
      if (data != null) {
         CompoundTag hxhData = new CompoundTag();
         data.saveNBTData(hxhData);
         persistentData.put("HxHCraftCombat", hxhData);
      }
   }

   public static void loadPlayerPersistentData(Player player, CompoundTag persistentData) {
      if (persistentData.contains("HxHCraftCombat")) {
         CompoundTag hxhData = persistentData.getCompound("HxHCraftCombat");
         Combat data = get(player);
         data.loadNBTData(hxhData);
      }
   }

   public static void playerTick(Player player) {
      Combat combatData = get(player);
      if (combatData != null) {
         combatData.tick();
      }
   }
}
