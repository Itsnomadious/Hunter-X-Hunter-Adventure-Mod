package net.hxhadventure.abilities;

import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;
import dev.kosmx.playerAnim.api.layered.modifier.AbstractFadeModifier;
import dev.kosmx.playerAnim.api.layered.modifier.SpeedModifier;
import dev.kosmx.playerAnim.core.util.Ease;
import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess.PlayerAssociatedAnimationData;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.hxhadventure.addon.client.anim.PoseDriver;

public class AnimationHandler {
   public AnimationHandler() {
   }

   /** True when this player's animation layer exists, so a clip can be played on it right now. */
   public static boolean canPlay(Player player) {
      if (!(player instanceof AbstractClientPlayer clientPlayer)) return false;
      PlayerAssociatedAnimationData data = PlayerAnimationAccess.getPlayerAssociatedData(clientPlayer);
      return data != null && data.get(ResourceLocation.fromNamespaceAndPath("hxhadventure", "animation_factory")) instanceof ModifierLayer<?>;
   }

   public static void playAnimation(Player player, String animationName, boolean isBarrage) {
      if (player instanceof AbstractClientPlayer) {
         net.hxhadventure.addon.client.StanceWatchdog.note(player, animationName);
         // a clip that has been reworked as a pose animation (pose_animations/<name>.json) has its own wrist/roll: no katana table on top
         if (!PoseDriver.has(animationName)) net.hxhadventure.addon.client.KatanaWrist.note(player, animationName);
         // a disguised player is drawn as a stand-in model: it has to move the same way
         for (AbstractClientPlayer stand : net.hxhadventure.addon.client.DisguiseStands.standInsFor(player.getId())) {
            playAnimation(stand, animationName, isBarrage);
         }
      }
      if (player instanceof AbstractClientPlayer clientPlayer) {
         // Pose framework: a pose animation with this name (assets/hxhadventure/pose_animations/<name>.json) replaces the
         // player-animator clip of the same name. Delete the json and the old clip plays again.
         if (animationName.equals("stop_anim")) {
            PoseDriver.stop(clientPlayer.getId());   // then fall through: the player-animator layer is eased out as before
         } else if (PoseDriver.play(clientPlayer.getId(), animationName)) {
            PlayerAssociatedAnimationData old = PlayerAnimationAccess.getPlayerAssociatedData(clientPlayer);
            if (old != null && old.get(ResourceLocation.fromNamespaceAndPath("hxhadventure", "animation_factory")) instanceof ModifierLayer<?> oldLayer) {
               ((ModifierLayer<IAnimation>) oldLayer).setAnimation(null);   // the previous clip must not keep posing under ours
            }
            return;
         }
         PlayerAssociatedAnimationData animationData = PlayerAnimationAccess.getPlayerAssociatedData(clientPlayer);
         if (animationData != null && animationData.get(ResourceLocation.fromNamespaceAndPath("hxhadventure", "animation_factory")) instanceof ModifierLayer<?> modLayer) {
            if (animationName.equals("stop_anim")) {
               // Cancelled charge: ease out of the stance back to normal movement.
               ((ModifierLayer<IAnimation>)modLayer).replaceAnimationWithFade(AbstractFadeModifier.standardFadeIn(4, Ease.INOUTSINE), null);
               return;
            }

            KeyframeAnimation anim = PlayerAnimationRegistry.getAnimation(ResourceLocation.fromNamespaceAndPath("hxhadventure", animationName));
            if (anim != null) {
               KeyframeAnimationPlayer animationPlayer = new KeyframeAnimationPlayer(anim);
               ModifierLayer<IAnimation> castedLayer = (ModifierLayer<IAnimation>)modLayer;

               // Drop leftover speed/fade modifiers from the previous move so they can't stack up.
               for (int i = 0; i < 8; i++) {
                  try {
                     castedLayer.removeModifier(0);
                  } catch (Exception var11) {
                     break;
                  }
               }

               float speed = getSpeed(animationName);
               if (speed != 1.0F) {
                  castedLayer.addModifier(new SpeedModifier(speed), 0);
               }

               if (isBarrage || !castedLayer.isActive()) {
                  // Jujutsu Craft style: hard-set the clip. Every barrage hit starts in the previous hit's end pose,
                  // so there is nothing to blend and any fade would only soften the strike.
                  castedLayer.setAnimation(animationPlayer);
               } else {
                  // Single moves blend in very briefly (1 tick punches / 2 ticks kicks) so the strike still lands on the hit.
                  int fadeTicks = animationName.startsWith("kick") ? 2 : (animationName.equals("charge_stance") || animationName.equals("katana_charge") || animationName.equals("iaido_charge")) ? 5 : animationName.startsWith("katana_attack") ? 3 : animationName.equals("iaido_cut") ? 2 : 1;
                  castedLayer.replaceAnimationWithFade(AbstractFadeModifier.standardFadeIn(fadeTicks, Ease.INOUTSINE), animationPlayer);
               }
            }
         }
      }
   }

   /** Timing is now authored in the JSON itself, so only the kicks get a (small) speed-up. */
   private static float getSpeed(String animationName) {
      if (animationName.equals("evoke")) return 2.0F; // Crazy Slots' summon pose: HxH Craft plays it at double speed
      if (animationName.startsWith("katana_barrage")) return net.hxhadventure.addon.KatanaSwingTuning.animSpeed(animationName);
      return animationName.startsWith("kick") ? 1.3F : 1.0F;
   }
}
