package net.hxhadventure.abilities;

import java.util.Random;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.hxhadventure.entity.custom.KiteEntity;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncAnimation;
import net.hxhadventure.networking.PacketSyncEnergy;
import net.hxhadventure.networking.PacketSyncHatsuExp;
import net.hxhadventure.networking.PacketSyncHatsuLevel;
import net.hxhadventure.networking.PacketSyncKit;
import net.hxhadventure.networking.PacketSyncNenStatus;

public class Combat {
   private Player player;
   private final float spirit = 5.0F;
   private boolean isAuraActive = false;
   private float currentEnergy = 1200.0F;
   private int currentKit = 0;
   public static final int NEN_NONE = 0;
   public static final int NEN_ENHANCEMENT = 1;
   public static final int NEN_TRANSMUTATION = 2;
   public static final int NEN_EMISSION = 3;
   public static final int NEN_CONJURATION = 4;
   public static final int NEN_MANIPULATION = 5;
   public static final int NEN_SPECIALIZATION = 6;
   private int nenType = 0;
   private boolean isNenUnlocked = false;
   private int hatsuLevel = 1;
   private int hatsuExp = 0;
   public boolean isBarrageActive = false;
   private int barrageTicks = 0;
   private int barragePunchCooldown = 0;
   private long lastBarrageUpdate = 0L;
   private long lastSinglePunchTime = 0L;
   private boolean isPunch1 = true;
   // Single "Attack" is a combo chain (like Jujutsu Craft's combo1/2/3): R punch -> L punch -> R kick, then L punch -> R punch -> L kick.
   private static final String[] ATTACK_COMBO = {"punch1", "punch2", "kick1", "punch2", "punch1", "kick2"};
   private static final long COMBO_RESET_MS = 1200L;
   private int comboStep = 0;
   private long lastComboTime = 0L;
   // Barrage strictly alternates hands so every hit starts in the pose the previous hit ended in.
   private boolean barrageRightNext = true;
   // Strong Attack: hold to charge for STRONG_CHARGE_TICKS, release to throw the punch.
   public static final int STRONG_CHARGE_TICKS = 40; // 2 seconds
   private static final float STRONG_DAMAGE = 15.0F; // normal attack deals 5.0
   private static final float STRONG_RANGE = 2.0F;
   private static final double STRONG_KNOCKBACK = 1.4;
   private boolean isChargingStrong = false;
   private int strongChargeStartTick = 0;
   private int strongLastKeepAliveTick = 0;
   // Movement slow while attacking: Attack 20%, Strong attack 50%, Barrage 40%.
   // Every slow ends with its move: Attack/Strong last as long as the punch/kick animation, Strong also while charging, Barrage only while it is actually running.
   private static final UUID ATTACK_SLOW_UUID = UUID.fromString("33333333-4444-5555-6666-888888888801");
   /** Attack and Strong attack share this 1 second cooldown; Barrage has its own 1 second cooldown after it ends. */
   private static final long ATTACK_COOLDOWN_MS = 1000L;
   private static final int BARRAGE_COOLDOWN_TICKS = 20;
   private static final float ATTACK_SLOW = 0.20F;
   private static final float STRONG_SLOW = 0.50F;
   private static final float BARRAGE_SLOW = 0.40F;
   private static final int PUNCH_ANIM_TICKS = 9;  // punch1 / punch2 are 0.45s
   private static final int KICK_ANIM_TICKS = 11;  // kick1 / kick2 are 0.55s
   private static final int BARRAGE_KEEPALIVE_TICKS = 2; // client resends Barrage every tick while held
   private float tailSlow = 0.0F;
   private int tailSlowUntilTick = 0;

   /** Next move in the combo chain; the chain restarts if the player pauses for a bit. */
   private String pickAttackAnim() {
      long now = System.currentTimeMillis();
      if (now - this.lastComboTime > COMBO_RESET_MS) {
         this.comboStep = 0;
      }
      String pick = ATTACK_COMBO[this.comboStep];
      this.comboStep = (this.comboStep + 1) % ATTACK_COMBO.length;
      this.lastComboTime = now;
      return pick;
   }

   /** Barrage hits alternate right / left punches only (no kicks) so the flurry stays fluid. */
   private String nextBarrageAnim() {
      Style st = this.style();
      boolean right = this.barrageRightNext;
      this.barrageRightNext = !this.barrageRightNext;
      return switch (st) {
         case SCYTHE -> right ? "scythe_barrage_right" : "scythe_barrage_left";
         case STAFF -> right ? "staff_barrage_right" : "staff_barrage_left";
         case PIPE -> "pipe_barrage" + this.pipeArmSuffix(); // one arm, the same hook over and over
         case KATANA -> this.katanaBarrageAnim();            // random diagonal / horizontal, never the vertical
         default -> right ? "barrage_right" : "barrage_left";
      };
   }
   // Armed attacks: holding the Crazy Slots scythe / staff or Morel's pipe swaps the punches and kicks for that weapon's own swings,
   // and the hit (and its sound) lands when the weapon does. Only the scythe also hits harder.
   private enum Style { NONE, SCYTHE, STAFF, PIPE, KATANA }
   private boolean armedAltNext = true;
   private Runnable pendingHit = null;
   private int pendingHitTick = 0;
   private static final int ARMED_ATTACK_HIT_DELAY = 4;   // weapon connects ~0.2s into the *_attack / *_swing clips
   private static final int ARMED_STRONG_HIT_DELAY = 6;   // ... and 0.3s into the *_strong clips

   /** Which weapon the player is swinging right now. */
   private Style style() {
      if (this.player == null) return Style.NONE;
      net.hxhadventure.addon.CrazySlots.Weapon w = net.hxhadventure.addon.CrazySlots.heldWeapon(this.player);
      if (w == net.hxhadventure.addon.CrazySlots.Weapon.SCYTHE) return Style.SCYTHE;
      if (w == net.hxhadventure.addon.CrazySlots.Weapon.STAFF) return Style.STAFF;
      if (net.hxhadventure.addon.SmokePipeItem.heldIn(this.player) != null) return Style.PIPE;
      if (net.hxhadventure.addon.KatanaSwingTuning.holdingDrawn(this.player)) return Style.KATANA;
      return Style.NONE;
   }

   /** Damage multiplier of Attack, Strong attack and Barrage: the scythe hits harder, the others hit like fists. */
   private float weaponDamageMult(Style st) {
      return st == Style.SCYTHE ? net.hxhadventure.addon.CrazySlotsTuning.SCYTHE_ATTACK_MULT : 1.0F;
   }

   /** "_l" or "_r": which arm holds Morel's pipe (the pipe clips are one-handed, so they have to use that arm). */
   private String pipeArmSuffix() {
      net.minecraft.world.InteractionHand hand = net.hxhadventure.addon.SmokePipeItem.heldIn(this.player);
      net.minecraft.world.entity.HumanoidArm arm = hand == net.minecraft.world.InteractionHand.OFF_HAND ? this.player.getMainArm().getOpposite() : this.player.getMainArm();
      return arm == net.minecraft.world.entity.HumanoidArm.LEFT ? "_l" : "_r";
   }

   /** Next Attack swing: scythe and staff alternate right / left, the pipe alternates forehand / backhand. */
   private String nextArmedSwing(Style st) {
      boolean first = this.armedAltNext;
      this.armedAltNext = !this.armedAltNext;
      return switch (st) {
         case SCYTHE -> first ? "scythe_swing_right" : "scythe_swing_left";
         case STAFF -> first ? "staff_attack_right" : "staff_attack_left";
         case KATANA -> this.katanaAttackAnim();             // random diagonal / horizontal, never the vertical
         default -> (first ? "pipe_attack1" : "pipe_attack2") + this.pipeArmSuffix();
      };
   }

   private String armedStrongAnim(Style st) {
      return switch (st) {
         case SCYTHE -> "scythe_strong";
         case STAFF -> "staff_strong";
         case KATANA -> this.katanaStrongAnim();             // mostly the vertical and the right-to-left diagonal
         default -> "pipe_strong" + this.pipeArmSuffix();
      };
   }

   /** Ticks the slow lasts after a swing: the length of its clip. */
   private static int armedAttackTicks(Style st) {
      return st == Style.SCYTHE || st == Style.KATANA ? 10 : 9;       // scythe_swing 0.5s, staff_attack / pipe_attack 0.45s
   }

   private static int armedStrongTicks(Style st) {
      return st == Style.SCYTHE || st == Style.KATANA ? 15 : 14;      // scythe_strong 0.75s, staff_strong / pipe_strong 0.7s
   }

   // ---- Katana (drawn): two-handed slashes. Clips: assets/hxhadventure/player_animation/katana_*.json, numbers: KatanaSwingTuning ----
   private static final String[] KATANA_ATTACK = {"katana_attack_diag", "katana_attack_lr", "katana_attack_rl"};
   private static final String[] KATANA_BARRAGE = {"katana_barrage_diag", "katana_barrage_lr", "katana_barrage_rl"};
   private final Random katanaRng = new Random();
   private int katanaLastAttack = -1;
   private int katanaLastBarrage = -1;
   /** Game tick at which the held guard pose is eased out (the katana clips hold their last frame, the stop ends them). 0 = none pending. */
   private int katanaStopTick = 0;

   /** A random index that is not the one used last time (so the same slash never plays twice in a row); -1 = no previous. */
   private int katanaPickDifferent(int count, int last) {
      if (last < 0) return this.katanaRng.nextInt(count);
      int n = this.katanaRng.nextInt(count - 1);
      return n >= last ? n + 1 : n;
   }

   private void katanaScheduleStop(int ticks) {
      this.katanaStopTick = this.player.tickCount + ticks;
   }

   /** Attack: the diagonal (top right to bottom left) or one of the two horizontals, at random. Never the vertical. */
   private String katanaAttackAnim() {
      this.katanaLastAttack = this.katanaPickDifferent(KATANA_ATTACK.length, this.katanaLastAttack);
      this.katanaScheduleStop(11);   // the clip is 0.5 s
      return KATANA_ATTACK[this.katanaLastAttack];
   }

   /** Barrage: the same pool as Attack (no vertical), a new one every hit. Each clip starts and ends in the guard so the hits join up. */
   private String katanaBarrageAnim() {
      this.katanaLastBarrage = this.katanaPickDifferent(KATANA_BARRAGE.length, this.katanaLastBarrage);
      this.katanaScheduleStop(net.hxhadventure.addon.KatanaSwingTuning.BARRAGE_INTERVAL_TICKS + 3);    // renewed by every slash, so the guard is only released after the last one
      return KATANA_BARRAGE[this.katanaLastBarrage];
   }

   /** Strong attack: weighted, mostly the vertical down the middle and the diagonal from the right to the left (KatanaSwingTuning). */
   private String katanaStrongAnim() {
      int total = net.hxhadventure.addon.KatanaSwingTuning.STRONG_WEIGHT_VERTICAL + net.hxhadventure.addon.KatanaSwingTuning.STRONG_WEIGHT_DIAGONAL
            + 2 * net.hxhadventure.addon.KatanaSwingTuning.STRONG_WEIGHT_HORIZONTAL;
      int r = this.katanaRng.nextInt(total);
      String pick;
      if (r < net.hxhadventure.addon.KatanaSwingTuning.STRONG_WEIGHT_VERTICAL) {
         pick = "katana_strong_vert";
      } else if ((r -= net.hxhadventure.addon.KatanaSwingTuning.STRONG_WEIGHT_VERTICAL) < net.hxhadventure.addon.KatanaSwingTuning.STRONG_WEIGHT_DIAGONAL) {
         pick = "katana_strong_diag";
      } else if ((r -= net.hxhadventure.addon.KatanaSwingTuning.STRONG_WEIGHT_DIAGONAL) < net.hxhadventure.addon.KatanaSwingTuning.STRONG_WEIGHT_HORIZONTAL) {
         pick = "katana_strong_lr";
      } else {
         pick = "katana_strong_rl";
      }
      this.katanaScheduleStop(16);   // the clip is 0.75 s
      return pick;
   }

   /** Runs the hit when the weapon reaches the target on the client's animation (immediately for a zero delay). */
   private void scheduleHit(int delayTicks, Runnable hit) {
      if (delayTicks <= 0) {
         hit.run();
         return;
      }
      if (this.pendingHit != null) { // never drop an earlier swing's hit
         Runnable old = this.pendingHit;
         this.pendingHit = null;
         old.run();
      }
      this.pendingHit = hit;
      this.pendingHitTick = this.player.tickCount + delayTicks;
   }

   private int globalBarrageCooldown = 0;
   private boolean isReadyAfterLogin = false;
   private String animName;
   private boolean isTenActive = false;
   private String auraPrefix = "";

   public long getLastSinglePunchTime() {
      return this.lastSinglePunchTime;
   }

   public void setClientEnergy(float energy) {
      this.currentEnergy = energy;
   }

   private void syncEnergyToClient() {
      if (this.player instanceof ServerPlayer serverPlayer && !this.player.level().isClientSide) {
         ModMessages.sendToPlayer(new PacketSyncEnergy(this.currentEnergy), serverPlayer);
      }
   }

   /** Energy paid as Ren upkeep since the addon last looked, so it is not mistaken for an ability cost. */
   private float upkeepSpent = 0.0F;

   public float takeUpkeepSpent() {
      float v = this.upkeepSpent;
      this.upkeepSpent = 0.0F;
      return v;
   }

   public float getMaxEnergy() {
      int ten;
      int ren;
      if (this.player.level().isClientSide) {
         ten = net.hxhadventure.addon.Vows.effLevel(this.player, net.hxhadventure.addon.NenSkill.TEN, net.hxhadventure.addon.ClientAddonState.level[net.hxhadventure.addon.NenSkill.TEN.ordinal()]);
         ren = net.hxhadventure.addon.Vows.effLevel(this.player, net.hxhadventure.addon.NenSkill.REN, net.hxhadventure.addon.ClientAddonState.level[net.hxhadventure.addon.NenSkill.REN.ordinal()]);
      } else {
         net.hxhadventure.addon.NenAddonData d = net.hxhadventure.addon.NenAddonData.get(this.player);
         ten = d == null ? 1 : d.effLevel(net.hxhadventure.addon.NenSkill.TEN);
         ren = d == null ? 1 : d.effLevel(net.hxhadventure.addon.NenSkill.REN);
      }

      return net.hxhadventure.addon.Tuning.maxNen(this.hatsuLevel, ten, ren) * net.hxhadventure.addon.GonVow.energyMult(this.player) * net.hxhadventure.addon.MagicalEsthetician.maxAuraMult(this.player) * net.hxhadventure.addon.Vows.maxAuraMult(this.player);
   }

   public float getCurrentEnergy() {
      return this.currentEnergy;
   }

   public void consumeEnergy(float amount) {
      this.currentEnergy = Math.max(0.0F, this.currentEnergy - amount);
      this.syncEnergyToClient();
   }

   public void restoreEnergy(float amount) {
      this.currentEnergy = Math.min(this.getMaxEnergy(), this.currentEnergy + amount);
      this.syncEnergyToClient();
   }

   public int rollWaterDivinationNenType() {
      if (this.nenType != 0) {
         return this.nenType;
      } else {
         Random random = new Random();
         int rolledType = random.nextInt(5) + 1;
         this.setNenType(rolledType);
         return rolledType;
      }
   }

   public int getHatsuLevel() {
      return this.hatsuLevel;
   }

   /** Mastery level cap: levels from kills, commands and everything else stop here. */
   public static final int MAX_LEVEL = 100;

   public void setHatsuLevel(int newLevel) {
      this.hatsuLevel = Math.min(MAX_LEVEL, newLevel);
      this.player.getPersistentData().putInt("HatsuLevel", this.hatsuLevel);
      this.updatePlayerMaxHealth(); // a level change re-checks the set max health at once, not only on damage or login
      if (this.hatsuLevel <= 1) {
         this.player.getPersistentData().remove("HxHCraft_LastRespinLevel");
      }

      if (this.player instanceof ServerPlayer serverPlayer) {
         ModMessages.sendToPlayer(new PacketSyncHatsuLevel(this.hatsuLevel), serverPlayer);
      }
   }

   public void addHatsuLevel(int amount) {
      this.setHatsuLevel(this.hatsuLevel + amount);
   }

   public int getHatsuExp() {
      return this.hatsuExp;
   }

   public void setHatsuExp(int exp) {
      this.hatsuExp = Math.max(0, exp);
   }

   public int getMaxExpForLevel() {
      return 100 + this.hatsuLevel * 20;
   }

   public void addHatsuExp(int amount) {
      if (!this.hasNenUnlocked()) {
         if (!this.player.level().isClientSide) {
            this.player.displayClientMessage(Component.literal("\u00a7cYou must unlock your Nen to gain experience!"), true);
         }
      } else if (this.hatsuLevel >= MAX_LEVEL) {
         // Maxed: no more level XP.
         this.hatsuExp = 0;
         this.player.getPersistentData().putInt("HatsuExp", 0);
      } else {
         // Every grade reached halves XP gain. Fractions are carried over so nothing is lost to rounding.
         float talentMult = this.player instanceof ServerPlayer ? net.hxhadventure.addon.NenProfile.talent(this.player).xpMult : 1.0F; // talent: more XP
         float scaled = (float)amount * net.hxhadventure.addon.Tuning.levelExpMult(this.hatsuLevel) * talentMult
            + this.player.getPersistentData().getFloat("HxHCraft_HatsuExpFrac");
         int whole = (int)scaled;
         this.player.getPersistentData().putFloat("HxHCraft_HatsuExpFrac", scaled - (float)whole);
         this.hatsuExp += whole;
         if (this.hatsuExp >= this.getMaxExpForLevel()) {
            this.hatsuExp = 0;
            this.player.getPersistentData().putInt("HatsuExp", this.hatsuExp);
            this.addHatsuLevel(1);
            if (!this.player.level().isClientSide) {
               String grade = hatsuGrade(this.hatsuLevel);
               if (grade != null) {
                  this.player.displayClientMessage(Component.literal("\u00a76\u00a7lGrade: " + grade), true);
               }
               if (this.player instanceof ServerPlayer sp) {
                  this.slSoundLevelUp(sp);
               }
            }
         } else {
            this.player.getPersistentData().putInt("HatsuExp", this.hatsuExp);
         }

         if (this.player instanceof ServerPlayer serverPlayer) {
            ModMessages.sendToPlayer(new PacketSyncHatsuExp(this.hatsuExp), serverPlayer);
         }
      }
   }

   /** Grade reached exactly at this level, or null when the level is not a grade milestone. */
   public static String hatsuGrade(int level) {
      return switch (level) {
         case 100 -> "Ultimate";
         case 60 -> "Genius";
         case 40 -> "Excellent";
         case 20 -> "Great";
         default -> null;
      };
   }

   /** The grade a player currently holds: the highest milestone at or below this level ("Novice" before Great). */
   public static String masteryGrade(int level) {
      if (level >= 100) return "Ultimate";
      if (level >= 60) return "Genius";
      if (level >= 40) return "Excellent";
      if (level >= 20) return "Great";
      return "Novice";
   }

   private void slSoundLevelUp(ServerPlayer sp) {
      sp.level().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
   }

   public static void handleMobKill(Player player, LivingEntity target) {
      if (player != null && target != null) {
         Combat combat = get(player);
         if (combat != null && combat.hasNenUnlocked()) {
            int rewardExp = 20;
            String entityName = target.getType().getDescriptionId();
            if (entityName.contains("skeleton") || entityName.contains("spider") || entityName.contains("witch")) {
               rewardExp = 30;
            } else if (entityName.contains("enderman") || entityName.contains("zombie") || entityName.contains("blaze") || entityName.contains("nether_boss")) {
               rewardExp = 50;
            } else if (target instanceof EnderDragon || target instanceof WitherBoss) {
               rewardExp = 250;
            } else if (target instanceof KiteEntity) {
               rewardExp = 500;
            } else if (target instanceof Player p) {
               Combat targetCombat = get(p);
               rewardExp = 10 + targetCombat.hatsuLevel * 10;
            }

            combat.addHatsuExp(rewardExp);
         }
      }
   }

   public boolean canRespinNow() {
      CompoundTag data = this.player.getPersistentData();
      if (!data.contains("HxHCraft_LastRespinLevel")) {
         return true;
      } else {
         int lastRespinLevel = data.getInt("HxHCraft_LastRespinLevel");
         return lastRespinLevel == 1 ? this.hatsuLevel >= 5 : this.hatsuLevel >= lastRespinLevel + 5;
      }
   }

   public void recordRespinLevel() {
      this.player.getPersistentData().putInt("HxHCraft_LastRespinLevel", this.hatsuLevel);
   }

   /** The extra max health a level grants: +0.41 per level, capped at +40 (60 in total at Level 100), in the steps of 4 that Health Boost gives. */
   public static double bonusHealthForLevel(int level) {
      return Math.floor(Math.min(40.0, (double)(level - 1) * 0.41) / 4.0) * 4.0;
   }

   /** The max health a level grants: 20 plus {@link #bonusHealthForLevel}. */
   public static double maxHealthForLevel(int level) {
      return 20.0 + bonusHealthForLevel(level);
   }

   /**
    * Gives the player a permanent, hidden-particle Health Boost worth {@code bonus} extra health (a multiple of 4), or clears ours when it is 0.
    * Current health is kept: removing the old boost first would otherwise cut it down to the plain maximum.
    */
   public static void applyHealthBoost(Player p, double bonus) {
      int amp = (int)Math.round(bonus / 4.0) - 1;
      net.minecraft.world.effect.MobEffectInstance cur = p.getEffect(MobEffects.HEALTH_BOOST);
      if (amp < 0) {
         if (cur != null && cur.getDuration() == -1) p.removeEffect(MobEffects.HEALTH_BOOST);
         return;
      }
      if (cur != null && cur.getAmplifier() == amp && cur.getDuration() == -1) return;      // already right
      if (cur != null && cur.getDuration() != -1 && cur.getAmplifier() >= amp) return;     // a stronger boost from somewhere else: leave it
      float hp = p.getHealth();
      if (cur != null) p.removeEffect(MobEffects.HEALTH_BOOST);
      p.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.HEALTH_BOOST, -1, amp, false, false, true));
      if (p.isAlive() && hp > 0f) p.setHealth(Math.min(hp, p.getMaxHealth()));
   }

   /**
    * Applies the set max health for the current level to the BASE value of the attribute. The "Lifespan lost" penalty is a separate
    * multiplier modifier on top (NenAddonData.applyLifespanHealth), so the two never overwrite each other: this sets the base, lifespan
    * scales it. Called whenever the level changes, on login and on respawn.
    */
   public void updatePlayerMaxHealth() {
      if (this.player != null && !this.player.level().isClientSide) {
         AttributeInstance healthAttribute = this.player.getAttribute(Attributes.MAX_HEALTH);
         if (healthAttribute != null && healthAttribute.getBaseValue() != 20.0) {
            healthAttribute.setBaseValue(20.0);          // the level's bonus is a Health Boost effect now, not the base value (this also fixes saves that kept the old base of up to 60)
            if (this.player.getHealth() > this.player.getMaxHealth()) this.player.setHealth(this.player.getMaxHealth());
         }
         applyHealthBoost(this.player, bonusHealthForLevel(this.hatsuLevel));
      }
   }

   public int getNenType() {
      return this.nenType;
   }

   public void setNenType(int type) {
      this.nenType = type;
      this.player.getPersistentData().putInt("HxHCraft_NenType", type);
      if (type != 0) {
         this.isNenUnlocked = true;
         this.player.getPersistentData().putBoolean("HxHCraft_NenUnlocked", true);
      } else if (type == 0) {
         this.isNenUnlocked = false;
         this.player.getPersistentData().putBoolean("HxHCraft_NenUnlocked", false);
      }

      if (this.player instanceof ServerPlayer sp && !this.player.level().isClientSide) {
         ModMessages.sendToPlayer(new PacketSyncNenStatus(this.isNenUnlocked, this.nenType, this.isTenActive, this.isAuraActive), sp);
      }
   }

   public float getScaledRegeneration() {
      float baseRegen = 0.5F;
      if (this.isTenActive) {
         float maxRegen = 2.0F;
         float calculatedRegen = baseRegen + (float)this.hatsuLevel * 0.1F * this.getSpiritBonus();
         return Math.min(calculatedRegen, maxRegen);
      } else {
         return baseRegen;
      }
   }

   public boolean hasNenUnlocked() {
      return this.currentKit >= 1;
   }

   public Combat(Player player) {
      this.player = player;
   }

   public Player getPlayer() {
      return this.player;
   }

   public static Combat get(Player player) {
      return CombatManager.get(player);
   }

   private void sendAnimationPacket(String animName, boolean play) {
      if (this.player != null && !this.player.level().isClientSide) {
         ModMessages.sendToPlayersTrackingEntityAndSelf(new PacketSyncAnimation(this.player.getUUID(), animName, play), this.player);
      }
   }

   public boolean setKit(int kitId) {
      if (kitId < 0 || kitId >= 3 && kitId <= 7) {
         return false;
      }

      this.currentKit = kitId;
      this.reset();
      this.setAuraActive(false);
      this.resetAura();
      if (this.player instanceof ServerPlayer sp && !this.player.level().isClientSide) {
         ModMessages.sendToPlayer(new PacketSyncKit(kitId), sp);
      }

      return true;
   }

   public String getAuraPrefix(Player player) {
      int colorIndex = player.getPersistentData().getInt("HxHCraft_PermanentAuraColor");
      String[] prefissi = new String[]{"gold_orange", "light_blue", "red", "dark_blue", "green", "purple", "pink", "white", "black", "yellow", "silver", "lime", "cyan", "coral", "teal", "grey", "forest", "maroon", "indigo", "midnight"};
      int index = colorIndex > 0 ? Math.min(colorIndex - 1, prefissi.length - 1) : 0;
      return prefissi[index];
   }

   public void syncKit(int kitId) {
      this.currentKit = kitId;
      this.reset();
   }

   public int getCurrentKit() {
      return this.currentKit;
   }

   public boolean hasNen() {
      return true;
   }

   public void setPlayer(Player newPlayer) {
      this.player = newPlayer;
   }

   public void updatePlayerReference(Player p) {
      this.player = p;
      this.reset();
   }

   public void reset() {
      if (this.isChargingStrong) {
         this.sendAnimationPacket("stop_anim", false); // otherwise the held charge stance stays on the client and locks the body
      }
      if (this.katanaStopTick > 0) { // a katana guard pose is still being held: let it go
         this.katanaStopTick = 0;
         this.sendAnimationPacket("stop_anim", false);
      }
      this.isChargingStrong = false;
      this.isBarrageActive = false;
      this.barrageTicks = 0;
      this.globalBarrageCooldown = 0;
      this.tailSlowUntilTick = 0;
      this.pendingHit = null;
      if (this.player != null && !this.player.level().isClientSide) {
         this.applySlow(0.0F);
      }
   }

   public void setAuraActive(boolean active) {
      this.isAuraActive = active;
   }

   public void resetAura() {
      this.isAuraActive = false;
   }

   public boolean isAuraActive() {
      return this.isAuraActive;
   }

   public float getSpiritBonus() {
      float sqrtLevel = (float)Math.sqrt((double)this.hatsuLevel);
      // Ren's damage no longer lives here: Ren doubles Ten, and Ten's damage bonus is applied by the addon (AddonServerEvents.onHurt).
      return 1.0F + sqrtLevel * 0.1F;
   }

   /** An enlightened 100-Type Guanyin user has no cooldown on Attack, Strong attack or Barrage. */
   private boolean noAttackCooldowns() {
      return this.player instanceof net.minecraft.server.level.ServerPlayer sp && net.hxhadventure.addon.Guanyin.enlightened(sp);
   }

   private long attackCooldownMs() {
      return this.noAttackCooldowns() ? 0L : ATTACK_COOLDOWN_MS;
   }

   public void performAttack() {
      if (!this.isBarrageActive) {
         long currentTime = System.currentTimeMillis();
         if (currentTime - this.lastSinglePunchTime >= this.attackCooldownMs()) {
            this.executeSinglePunch();
            this.lastSinglePunchTime = currentTime;
         }
      }
   }

   /** Called every tick by the client while the key is held on "Strong attack". Starts / keeps the charge alive. */
   public void chargeStrongAttack() {
      if (this.isBarrageActive || this.player.level().isClientSide) {
         return;
      }

      this.strongLastKeepAliveTick = this.player.tickCount;
      if (!this.isChargingStrong) {
         if (System.currentTimeMillis() - this.lastSinglePunchTime < this.attackCooldownMs()) {
            return;
         }

         this.isChargingStrong = true;
         this.strongChargeStartTick = this.player.tickCount;
         this.katanaStopTick = 0;
         this.sendAnimationPacket(this.style() == Style.KATANA ? "katana_charge" : "charge_stance", false);
      }
   }

   /** Key released at any point: throws the punch, scaled by how long it was charged (full damage only at the full 2 seconds). */
   public void releaseStrongAttack() {
      if (!this.isChargingStrong) {
         return;
      }

      float progress = Math.min(1.0F, (float)(this.player.tickCount - this.strongChargeStartTick) / (float)STRONG_CHARGE_TICKS);
      this.isChargingStrong = false;
      this.executeStrongPunch(progress);
      this.lastSinglePunchTime = System.currentTimeMillis();
   }

   public boolean isChargingStrongAttack() {
      return this.isChargingStrong;
   }

   /** Small build-up effect around the fist while charging; gets denser as the charge fills. */
   private void tickStrongCharge() {
      // Key-up packet lost (disconnect, screen opened...): drop the charge instead of leaving it stuck.
      if (this.player.tickCount - this.strongLastKeepAliveTick > (this.style() == Style.KATANA ? 20 : 5) || this.isBarrageActive) {
         this.isChargingStrong = false;
         this.sendAnimationPacket("stop_anim", false);
         return;
      }

      if (!(this.player.level() instanceof ServerLevel sl)) {
         return;
      }

      int charged = Math.min(this.player.tickCount - this.strongChargeStartTick, STRONG_CHARGE_TICKS);
      float progress = (float)charged / (float)STRONG_CHARGE_TICKS;
      Vec3 look = this.player.getLookAngle();
      // Fist sits roughly at chest height, slightly in front of the player.
      double fx = this.player.getX() + look.x * 0.7;
      double fy = this.player.getY() + 1.2;
      double fz = this.player.getZ() + look.z * 0.7;

      // Same small spark effect for the whole charge; nothing extra when it fills up.
      if (this.player.tickCount % 3 == 0) {
         int count = 1 + (int)(progress * 3.0F);
         sl.sendParticles(ParticleTypes.CRIT, fx, fy, fz, count, 0.15, 0.15, 0.15, 0.02);
      }
   }

   /** Slows the player for as long as the punch / kick animation plays, then lets go. */
   private void startSlowTail(float amount, int ticks) {
      int until = this.player.tickCount + ticks;
      // Don't let a light Attack shorten the heavier slow from a Strong attack that is still winding down.
      if (this.player.tickCount < this.tailSlowUntilTick && amount < this.tailSlow && until <= this.tailSlowUntilTick) {
         return;
      }

      this.tailSlow = amount;
      this.tailSlowUntilTick = until;
   }

   /** Picks the strongest slow that applies right now (charging, barraging, or a punch's follow-through) and applies it. */
   private void updateAttackSlow() {
      if (this.player.level().isClientSide) {
         return;
      }

      float slow = 0.0F;
      if (this.isChargingStrong) {
         slow = STRONG_SLOW;
      }
      // Barrage slows only while the key is still being held (it stops the moment you let go, not 5 ticks later).
      if (this.isBarrageActive && (long)this.player.tickCount - this.lastBarrageUpdate <= (long)BARRAGE_KEEPALIVE_TICKS) {
         slow = Math.max(slow, BARRAGE_SLOW);
      }
      if (this.player.tickCount < this.tailSlowUntilTick) {
         slow = Math.max(slow, this.tailSlow);
      }

      this.applySlow(slow);
   }

   /** Always compares against the real attribute, so a stale modifier can never be left behind. */
   private void applySlow(float slow) {
      AttributeInstance speed = this.player.getAttribute(Attributes.MOVEMENT_SPEED);
      if (speed == null) {
         return;
      }

      AttributeModifier current = speed.getModifier(ATTACK_SLOW_UUID);
      if (slow <= 0.0F) {
         if (current != null) {
            speed.removeModifier(ATTACK_SLOW_UUID);
         }

         return;
      }

      if (current != null && Math.abs(current.getAmount() + (double)slow) < 1.0E-4) {
         return;
      }

      if (current != null) {
         speed.removeModifier(ATTACK_SLOW_UUID);
      }

      speed.addTransientModifier(new AttributeModifier(ATTACK_SLOW_UUID, "Attack slow", (double)(-slow), AttributeModifier.Operation.MULTIPLY_TOTAL));
   }

   /** Ticks between barrage hits: 3 for fists and other weapons, slower for the drawn Katana (one full slash at a time). */
   private int barrageGap() {
      return this.style() == Style.KATANA ? net.hxhadventure.addon.KatanaSwingTuning.BARRAGE_INTERVAL_TICKS : 3;
   }

   public void handleBarrage() {
      if (this.globalBarrageCooldown <= 0) {
         if (!this.isBarrageActive) {
            if (this.isChargingStrong) {
               this.sendAnimationPacket("stop_anim", false);
            }
            this.isChargingStrong = false;
            this.isBarrageActive = true;
            this.barrageTicks = 0;
            this.barragePunchCooldown = 0;
            this.barrageRightNext = true;
            this.executeBarragePunch();
            if (this.style() == Style.KATANA) this.barragePunchCooldown = this.barrageGap() - 1;   // the first slash must not be followed at once by a second
         }

         this.lastBarrageUpdate = (long)this.player.tickCount;
      }
   }

   public void tick() {
      if (!this.isReadyAfterLogin && this.player.tickCount > 60) {
         this.isReadyAfterLogin = true;
         this.updatePlayerMaxHealth();
      }

      if (this.globalBarrageCooldown > 0) {
         this.globalBarrageCooldown--;
      }

      if (this.isChargingStrong) {
         this.tickStrongCharge();
      }

      this.updateAttackSlow();

      if (this.pendingHit != null && this.player.tickCount >= this.pendingHitTick) {
         Runnable hit = this.pendingHit;
         this.pendingHit = null;
         if (!this.player.level().isClientSide && this.player.isAlive()) {
            hit.run();
         }
      }

      if (this.katanaStopTick > 0 && this.player.tickCount >= this.katanaStopTick) {
         this.katanaStopTick = 0;
         if (!this.player.level().isClientSide && !this.isChargingStrong && !this.isBarrageActive) {
            this.sendAnimationPacket("stop_anim", false); // eases out of the katana guard pose
         }
      }

      if (this.isBarrageActive) {
         if ((long)this.player.tickCount - this.lastBarrageUpdate <= 5L && this.barrageTicks <= 60) {
            this.barrageTicks++;
            if (this.barragePunchCooldown <= 0) {
               this.executeBarragePunch();
               this.barragePunchCooldown = this.barrageGap() - 1;
            } else {
               this.barragePunchCooldown--;
            }
         } else {
            this.isBarrageActive = false;
            this.barrageTicks = 0;
            this.globalBarrageCooldown = this.noAttackCooldowns() ? 0 : BARRAGE_COOLDOWN_TICKS;
         }
      }

      if (!this.player.level().isClientSide && this.player.tickCount % 20 == 0) {
         this.updatePlayerMaxHealth(); // milk, a totem or a command can clear the Health Boost: put it back within a second
         if (this.isTenActive) {
            float tenBonusRegen = this.getScaledRegeneration() * 5.5F;
            this.restoreEnergy(tenBonusRegen * net.hxhadventure.addon.MagicalEsthetician.regenMult(this.player)); // Piano Massage
         } else {
            this.restoreEnergy(this.getScaledRegeneration() * net.hxhadventure.addon.MagicalEsthetician.regenMult(this.player));
         }

         if (AbilityRegistry.isRenActive(this.player)) {
            float renConsumption = net.hxhadventure.addon.Tuning.renUpkeep(this.getMaxEnergy());
            this.consumeEnergy(renConsumption);
            this.upkeepSpent += renConsumption;
            if (this.currentEnergy <= 0.0F) {
               AbilityRegistry.toggleRen(this.player, false);
               this.setAuraActive(false);
               this.player.removeEffect(MobEffects.JUMP);
               AttributeInstance speedAttr = this.player.getAttribute(Attributes.MOVEMENT_SPEED);
               if (speedAttr != null) {
                  speedAttr.removeModifier(AbilityRegistry.REN_SPEED_UUID);
               }

               this.player.displayClientMessage(Component.literal("\u00a7cEnergy depleted! Ren deactivated."), true);
            }
         }
      }
   }

   private void executeSinglePunch() {
      Style st = this.style();
      if (st != Style.NONE) {
         final float mult = this.weaponDamageMult(st);
         this.animName = this.nextArmedSwing(st);
         this.startSlowTail(ATTACK_SLOW, armedAttackTicks(st));
         this.sendAnimationPacket(this.animName, false);
         this.swingArm();
         this.scheduleHit(ARMED_ATTACK_HIT_DELAY, () -> {
            this.applyAreaDamage(1.5F, 3.0F, 0.5, mult);
            this.spawnAttackEffects(1.2, false, false);
         });
         return;
      }
      this.animName = this.pickAttackAnim();
      this.startSlowTail(ATTACK_SLOW, this.animName.startsWith("kick") ? KICK_ANIM_TICKS : PUNCH_ANIM_TICKS);
      this.applyAreaDamage(1.5F, 3.0F); // Attack base damage (was 5)
      this.spawnAttackEffects(1.2, false, false);
      this.sendAnimationPacket(this.animName, false);
      this.swingArm();
   }

   /** Every attacking skill plays Minecraft's default punch (the arm swing), which is also what shows in first person. */
   private void swingArm() {
      if (this.player != null && !this.player.level().isClientSide) {
         net.hxhadventure.addon.SwingUtil.forceSwing(this.player, net.minecraft.world.InteractionHand.MAIN_HAND);
      }
   }

   /** @param progress 0..1 charge. 0 hits like a normal Attack (5 dmg); 1 is the full Strong attack. */
   private void executeStrongPunch(float progress) {
      boolean full = progress >= 1.0F;
      float damage = 5.0F + (STRONG_DAMAGE - 5.0F) * progress;
      float range = 1.5F + (STRONG_RANGE - 1.5F) * progress;
      double knockback = 0.5 + (STRONG_KNOCKBACK - 0.5) * progress;
      Style st = this.style();
      if (st != Style.NONE) {
         final float mult = this.weaponDamageMult(st);
         this.startSlowTail(STRONG_SLOW, armedStrongTicks(st));
         this.sendAnimationPacket(this.armedStrongAnim(st), false);
         this.swingArm();
         this.scheduleHit(ARMED_STRONG_HIT_DELAY, () -> {
            this.applyAreaDamage(range, damage, knockback, mult);
            this.spawnAttackEffects(1.4, full, full);
         });
         return;
      }
      this.startSlowTail(STRONG_SLOW, PUNCH_ANIM_TICKS);
      this.applyAreaDamage(range, damage, knockback);
      // The sonic boom is reserved for a fully charged punch.
      this.spawnAttackEffects(1.4, full, full);
      this.sendAnimationPacket("strong_punch", false);
      this.swingArm();
   }

   private void executeBarragePunch() {
      if (this.player != null && !this.player.level().isClientSide) {
         if (this.player.level() instanceof ServerLevel) {
            if (this.style() == Style.KATANA) {
               // the hit lands when the blade does, on the slowed clip
               final float mult = net.hxhadventure.addon.KatanaSwingTuning.BARRAGE_DAMAGE_MULT;
               this.sendAnimationPacket(this.nextBarrageAnim(), true);
               this.swingArm();
               this.scheduleHit(net.hxhadventure.addon.KatanaSwingTuning.BARRAGE_HIT_DELAY_TICKS, () -> {
                  this.applyAreaDamage(1.5F, 1.5F, 0.5, this.weaponDamageMult(Style.KATANA) * mult);
                  this.spawnAttackEffects(1.2, true, false);
               });
               return;
            }
            this.applyAreaDamage(1.5F, 1.5F, 0.5, this.weaponDamageMult(this.style()));
            this.spawnAttackEffects(1.2, true, false);
            this.sendAnimationPacket(this.nextBarrageAnim(), true);
            this.swingArm();
         }
      }
   }

   private void applyAreaDamage(float range, float damage) {
      this.applyAreaDamage(range, damage, 0.5);
   }

   private void applyAreaDamage(float range, float damage, double knockback) {
      this.applyAreaDamage(range, damage, knockback, 1.0F);
   }

   private void applyAreaDamage(float range, float damage, double knockback, float weaponMult) {
      float totalDamage = damage * this.getSpiritBonus() * weaponMult;
      Vec3 look = this.player.getLookAngle();
      Vec3 hitPos = this.player.position().add(look.x * (double)range, 1.5, look.z * (double)range);
      AABB hitArea = new AABB(
         hitPos.x - (double)range,
         hitPos.y - (double)range,
         hitPos.z - (double)range,
         hitPos.x + (double)range,
         hitPos.y + (double)range,
         hitPos.z + (double)range
      );
      this.player
         .level()
         .getEntities(
            this.player,
            hitArea,
            e -> e instanceof LivingEntity && e != this.player && !e.getUUID().equals(this.player.getUUID())
         )
         .forEach(target -> {
            target.hurt(this.player.damageSources().mobAttack(this.player), totalDamage);
            double dx = target.getX() - this.player.getX();
            double dz = target.getZ() - this.player.getZ();
            ((LivingEntity)target).knockback(knockback, -dx, -dz);
         });
   }

   public void loadNBTData(CompoundTag nbt) {
      if (nbt.contains("CurrentKitId")) {
         this.currentKit = nbt.getInt("CurrentKitId");
         this.auraPrefix = nbt.getString("AuraPrefix");
      }

      if (nbt.contains("IsTenActive")) {
         this.isTenActive = nbt.getBoolean("IsTenActive");
      }

      if (nbt.contains("HxHCraft_LastRespinLevel")) {
         int lastRespin = nbt.getInt("HxHCraft_LastRespinLevel");
         if (this.player != null) {
            this.player.getPersistentData().putInt("HxHCraft_LastRespinLevel", lastRespin);
         }
      }

      if (this.currentKit >= 1) {
         this.isNenUnlocked = true;
         if (this.player != null) {
            this.player.getPersistentData().putBoolean("HxHCraft_NenUnlocked", true);
         }
      }

      if (nbt.contains("HxHCraft_NenType")) {
         this.nenType = nbt.getInt("HxHCraft_NenType");
         this.isNenUnlocked = nbt.getBoolean("HxHCraft_NenUnlocked");
         if (this.player != null) {
            this.player.getPersistentData().putInt("HxHCraft_NenType", this.nenType);
            this.player.getPersistentData().putBoolean("HxHCraft_NenUnlocked", this.isNenUnlocked);
         }
      }

      this.hatsuLevel = nbt.getInt("HatsuLevel");
      if (this.hatsuLevel == 0) {
         this.hatsuLevel = 1;
      }
      if (this.hatsuLevel > MAX_LEVEL) {
         this.hatsuLevel = MAX_LEVEL; // saves from before the cap
      }

      if (nbt.contains("HatsuExp")) {
         this.hatsuExp = nbt.getInt("HatsuExp");
      }

      if (nbt.contains("HxHCraft_CurrentEnergy")) {
         this.currentEnergy = nbt.getFloat("HxHCraft_CurrentEnergy");
      } else {
         this.currentEnergy = this.getMaxEnergy();
      }

      this.updatePlayerMaxHealth();
   }

   public void saveNBTData(CompoundTag nbt) {
      nbt.putInt("CurrentKitId", this.currentKit);
      nbt.putString("AuraPrefix", this.auraPrefix);
      nbt.putBoolean("IsTenActive", this.isTenActive);
      nbt.putInt("HxHCraft_NenType", this.nenType);
      nbt.putBoolean("HxHCraft_NenUnlocked", this.isNenUnlocked);
      nbt.putInt("HatsuLevel", this.hatsuLevel);
      nbt.putInt("HatsuExp", this.hatsuExp);
      nbt.putFloat("HxHCraft_CurrentEnergy", this.currentEnergy);
      if (this.player != null && this.player.getPersistentData().contains("HxHCraft_LastRespinLevel")) {
         nbt.putInt("HxHCraft_LastRespinLevel", this.player.getPersistentData().getInt("HxHCraft_LastRespinLevel"));
      }
   }

   /**
    * @param particles false for the plain Attack (sound only)
    * @param strong    true for the charged Strong attack (sonic boom + heavier hit sound)
    */
   private void spawnAttackEffects(double range, boolean particles, boolean strong) {
      if (!this.player.level().isClientSide) {
         if (this.player.level() instanceof ServerLevel sl) {
            Vec3 look = this.player.getLookAngle();
            double x = this.player.getX() + look.x * range;
            double z = this.player.getZ() + look.z * range;
            sl.playSound(null, this.player.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.0F, strong ? 0.7F : 1.0F);
            if (strong) {
               sl.playSound(null, this.player.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.4F, 1.5F);
               sl.sendParticles(ParticleTypes.SONIC_BOOM, x, this.player.getY() + 1.2, z, 1, 0.0, 0.0, 0.0, 0.0);
            } else if (particles) {
               sl.sendParticles(ParticleTypes.BUBBLE_POP, x, this.player.getY() + 1.2, z, 1, 0.0, 0.0, 0.0, 0.0);
            }
         }
      }
   }

   public void setReadyAfterLogin(boolean ready) {
      this.isReadyAfterLogin = ready;
   }

   public boolean isTenActive() {
      return this.isTenActive;
   }

   public void setTenActive(boolean active) {
      this.isTenActive = active;
   }
}
