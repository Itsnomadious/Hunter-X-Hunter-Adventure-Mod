package net.hxhadventure.entity.client.gui;

import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;

/**
 * The Water Divination reaction: a glass of water with a leaf on it, and what the water does when the player's aura reaches it.
 * One animation per Nen type (Hunter x Hunter's water divination):
 * <ul>
 *   <li>Enhancer: the volume of the water increases until it overflows the glass.</li>
 *   <li>Transmuter: the taste of the water changes (sweet, sour, bitter).</li>
 *   <li>Conjurer: impurities and particles appear in the water.</li>
 *   <li>Emitter: the colour of the water changes.</li>
 *   <li>Manipulator: the leaf moves on its own.</li>
 *   <li>Specialist: something else entirely: the leaf burns away, the water freezes, or it fills with bubbles (one, picked per player).</li>
 * </ul>
 * Everything is drawn from rectangles (like the rest of the screens), in the glass's own local pixels and scaled up. Time is in ticks.
 */
public final class DivinationAnimation {
    private DivinationAnimation() {}

    /** Ticks the whole reaction lasts. */
    public static final int DURATION = 150;
    /** The aura thread reaches the water at this tick; the reaction starts. */
    private static final float START = 24f;

    // glass, in local pixels
    private static final int W = 48, H = 64, WATER_TOP = 16;
    private static final int WATER = 0xC03C7FB0, SURFACE = 0xFF7FC0E8, FRAME = 0xFFB8D8E8;
    private static final int LEAF = 0xFF3F9A4A, LEAF_DARK = 0xFF2E7A38;

    /** Height of the aura thread above the glass (local pixels): the scale needs room for it. */
    public static final int THREAD_H = 18;
    /** Total local height of everything drawn, used by the screen to pick a scale. */
    public static final int TOTAL_H = THREAD_H + H + 6;
    /** How far the reaction reaches out sideways past the glass (overflow streams, puddle, glow, droplets), in local pixels. */
    public static final int SIDE_PAD = 24;
    /** Total local width of everything drawn, used by the screen to pick a scale. */
    public static final int TOTAL_W = W + SIDE_PAD * 2;

    // ================================================================================================
    // entry points
    // ================================================================================================

    /** Draws the glass with its reaction. (gx, gy) is the glass's top-left corner on screen; scale is pixels per local pixel. */
    public static void render(GuiGraphics g, int type, long seed, float t, int gx, int gy, float scale) {
        g.pose().pushPose();
        g.pose().translate(gx, gy, 0);
        g.pose().scale(scale, scale, 1f);
        switch (type) {
            case 1 -> enhancer(g, t);
            case 2 -> transmuter(g, seed, t);
            case 3 -> emitter(g, seed, t);
            case 4 -> conjurer(g, seed, t);
            case 5 -> manipulator(g, t);
            case 6 -> specialist(g, seed, t);
            default -> plain(g, t);
        }
        g.pose().popPose();
    }

    /** The quiet glass before anything happens (or while the request is on its way). */
    public static void renderIdle(GuiGraphics g, float t, int gx, int gy, float scale) {
        g.pose().pushPose();
        g.pose().translate(gx, gy, 0);
        g.pose().scale(scale, scale, 1f);
        float bob = Mth.sin(t * 0.08f) * 0.6f;
        water(g, WATER_TOP, WATER, 1f);
        leaf(g, W / 2f, WATER_TOP + 1 + bob, 0f, LEAF, 1f, 1f);
        glassFrame(g);
        g.pose().popPose();
    }

    /** The line of text that goes with the reaction at this moment ("" while nothing has happened yet). */
    public static String caption(int type, long seed, float t) {
        if (t < START) return "Your aura slips into the water...";
        float u = t - START;
        switch (type) {
            case 1:
                return u < 40 ? "The water begins to rise..." : "The water swells and overflows the glass.";
            case 2: {
                if (u < 8) return "You lift the glass to your lips...";
                int k = tasteIndex(seed, t);
                return "It tastes " + TASTE_NAMES[k] + (u >= tasteEnd() ? "." : "...");
            }
            case 3: // Emitter
                return u < 40 ? "The water begins to change..." : "The colour of the water has changed.";
            case 4: // Conjurer
                return u < 30 ? "Something stirs in the water..." : "Impurities cloud the water.";
            case 5:
                return u < 40 ? "The leaf trembles..." : "The leaf moves by itself.";
            case 6:
                switch (specialistKind(seed)) {
                    case 0: return u < 30 ? "The leaf darkens..." : "The leaf burns to ash.";
                    case 1: return u < 30 ? "A chill creeps into the glass..." : "The water has frozen solid.";
                    default: return u < 30 ? "The water begins to fizz..." : "Bubbles pour out of the water.";
                }
            default:
                return "";
        }
    }

    /** One-off sound cues, called once per client tick with the tick that has just been reached. */
    public static void sounds(int type, long seed, int tick) {
        if (tick == 2) ui(SoundEvents.AMETHYST_BLOCK_CHIME, 1.2f);
        if (tick == (int) START) ui(SoundEvents.BEACON_POWER_SELECT, 1.6f);
        switch (type) {
            case 1 -> { // rising, then spilling
                if (tick == 40) ui(SoundEvents.BUCKET_EMPTY, 0.8f);
                if (tick == 80) ui(SoundEvents.WATER_AMBIENT, 1.0f);
            }
            case 2 -> { // a sip per taste
                float s = START + 8;
                for (int i = 0; i < 3; i++) if (tick == (int) (s + i * TASTE_TICKS)) ui(SoundEvents.GENERIC_DRINK, 0.9f + 0.2f * i);
            }
            case 3 -> { // Emitter
                if (tick == 40) ui(SoundEvents.BEACON_AMBIENT, 1.4f);
                if (tick == 90) ui(SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0f);
            }
            case 4 -> { // Conjurer
                if (tick == 40) ui(SoundEvents.BREWING_STAND_BREW, 0.8f);
                if (tick == 90) ui(SoundEvents.GRAVEL_PLACE, 0.8f);
            }
            case 5 -> {
                if (tick == 40) ui(SoundEvents.CHORUS_FLOWER_GROW, 0.7f);
                if (tick == 80) ui(SoundEvents.ENDER_EYE_DEATH, 1.2f);
            }
            case 6 -> {
                switch (specialistKind(seed)) {
                    case 0 -> { if (tick == 36) ui(SoundEvents.FIRECHARGE_USE, 1.0f); if (tick == 80) ui(SoundEvents.FIRE_EXTINGUISH, 1.0f); }
                    case 1 -> { if (tick == 36) ui(SoundEvents.POWDER_SNOW_PLACE, 0.8f); if (tick == 70) ui(SoundEvents.GLASS_PLACE, 1.4f); }
                    default -> { for (int i = 0; i < 6; i++) if (tick == 40 + i * 14) ui(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 0.8f + 0.1f * i); }
                }
            }
            default -> { }
        }
        if (tick == DURATION - 30) ui(SoundEvents.AMETHYST_BLOCK_CHIME, 0.8f);
    }

    private static void ui(SoundEvent ev, float pitch) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ev, pitch, 0.7f));
    }

    // ================================================================================================
    // Enhancer: the water rises and overflows
    // ================================================================================================
    private static void enhancer(GuiGraphics g, float t) {
        float rise = smooth(clamp01((t - START) / 36f));
        float over = clamp01((t - START - 36f) / 50f);
        int top = Math.round(Mth.lerp(rise, WATER_TOP, -3));
        // the water, bulging above the rim once it passes it
        water(g, Math.max(top, 0), WATER, 1f);
        if (top < 0) {
            int bulge = -top;
            g.fill(-1, -bulge, W + 1, 0, WATER);
            g.fill(2, -bulge - 1, W - 2, -bulge, SURFACE);
        }
        aura(g, t);
        leaf(g, W / 2f, top + 1 + Mth.sin(t * 0.2f) * 0.7f, Mth.sin(t * 0.1f) * 0.1f, LEAF, 1f, 1f);
        glassFrame(g);
        if (over > 0f) {
            // streams run down both outsides of the glass; the puddle widens at its foot
            int len = Math.round(over * (H + 4));
            for (int side = 0; side < 2; side++) {
                int x0 = side == 0 ? -3 : W;
                g.fill(x0, 0, x0 + 3, len, WATER);
                for (int y = 0; y < len; y += 6) { // the running highlight
                    int yy = (int) ((y + t * 2.5f) % Math.max(1, len));
                    g.fill(x0 + 1, yy, x0 + 2, Math.min(len, yy + 3), SURFACE);
                }
            }
            int spread = Math.round(over * 16f);
            g.fill(-6 - spread, H, W + 6 + spread, H + 3, WATER);
            g.fill(-6 - spread, H, W + 6 + spread, H + 1, SURFACE);
            for (int i = 0; i < 8; i++) { // droplets thrown off the rim
                float u = (t * 0.07f + i * 0.31f) % 1f;
                int x = Math.round(i % 2 == 0 ? -2 - u * 8f * (0.6f + rnd(5, i, 1)) : W + 2 + u * 8f * (0.6f + rnd(5, i, 1)));
                int y = Math.round(-4f + 18f * u * u - 9f * u);
                g.fill(x, y, x + 2, y + 2, SURFACE);
            }
        }
    }

    // ================================================================================================
    // Transmuter: the taste of the water changes (sweet, sour, bitter)
    // ================================================================================================
    private static final String[] TASTE_NAMES = {"sweet", "sour", "bitter"};
    private static final int[] TASTE_TINT = {0xFFF29AC8, 0xFFD6E84A, 0xFF5E3F26};
    private static final float TASTE_TICKS = 38f;

    private static float tasteEnd() { return 8f + TASTE_TICKS * 3f; }

    /** Which taste is showing at tick t: each of the three in a per-player order. */
    private static int tasteIndex(long seed, float t) {
        float u = Math.max(0f, t - START - 8f);
        int slot = Math.min(2, (int) (u / TASTE_TICKS));
        return tasteOrder(seed)[slot];
    }

    private static int[] tasteOrder(long seed) {
        int[][] orders = {{0, 1, 2}, {1, 2, 0}, {2, 0, 1}, {0, 2, 1}, {1, 0, 2}, {2, 1, 0}};
        return orders[(int) ((seed & 0x7fffffffL) % orders.length)];
    }

    private static void transmuter(GuiGraphics g, long seed, float t) {
        float u = Math.max(0f, t - START - 8f);
        int slot = Math.min(2, (int) (u / TASTE_TICKS));
        float within = Math.min(1f, (u - slot * TASTE_TICKS) / TASTE_TICKS);
        int[] order = tasteOrder(seed);
        int cur = TASTE_TINT[order[slot]];
        int prev = slot == 0 ? 0xFF3C7FB0 : TASTE_TINT[order[slot - 1]];
        float fade = smooth(clamp01(within * 3f));
        int tint = t < START + 8f ? 0xFF3C7FB0 : lerpColor(prev, cur, fade);
        int water = lerpColor(0xFF3C7FB0, tint, t < START + 8f ? 0f : 0.55f);
        water = (water & 0x00FFFFFF) | 0xC0000000;
        water(g, WATER_TOP, water, 1f);
        aura(g, t);
        if (t >= START + 8f) {
            int taste = order[slot];
            for (int i = 0; i < 14; i++) {
                float life = (u * 0.03f + i * 0.137f) % 1f;
                float px = 5 + rnd(seed, i + slot * 20, 3) * (W - 12);
                switch (taste) {
                    case 0 -> { // sweet: white sugar crystals twinkling and sinking, with pink glints
                        float a = Mth.sin(life * Mth.PI);
                        int y = Math.round(WATER_TOP + 2 + life * 38);
                        int col = withAlpha(i % 3 == 0 ? 0xFFFFC8E4 : 0xFFFFFFFF, a);
                        g.fill(Math.round(px), y, Math.round(px) + 2, y + 2, col);
                        if (i % 4 == 0) { g.fill(Math.round(px) - 1, y + 1, Math.round(px) + 3, y + 2, col); g.fill(Math.round(px) + 1, y - 1, Math.round(px) + 2, y + 3, col); }
                    }
                    case 1 -> { // sour: yellow-green droplets jump out of the water and puckering ripples
                        float a = 1f - life;
                        int y = Math.round(WATER_TOP - 1 - Mth.sin(life * Mth.PI) * 11);
                        g.fill(Math.round(px), y, Math.round(px) + 2, y + 3, withAlpha(0xFFE6F25A, a));
                        int ring = Math.round(life * 9);
                        g.fill(Math.round(W / 2f) - ring, WATER_TOP + 1, Math.round(W / 2f) + ring, WATER_TOP + 2, withAlpha(0xFFF4FF9A, 1f - life));
                    }
                    default -> { // bitter: dark murky swirls rising from the bottom
                        float a = Mth.sin(life * Mth.PI) * 0.8f;
                        int y = Math.round(H - 3 - life * 42);
                        int x = Math.round(px + Mth.sin(life * 9f + i) * 4);
                        g.fill(x, y, x + 4, y + 3, withAlpha(0xFF2B1A10, a));
                        g.fill(x + 1, y - 1, x + 3, y, withAlpha(0xFF4A3220, a));
                    }
                }
            }
        }
        float curl = t >= START + 8f ? Mth.sin(u * 0.2f) * 0.12f : 0f;
        leaf(g, W / 2f, WATER_TOP + 1 + Mth.sin(t * 0.15f) * 0.6f, curl, tinted(LEAF, tint, t >= START + 8f ? 0.25f : 0f), 1f, 1f);
        glassFrame(g);
    }

    // ================================================================================================
    // Emitter: the colour of the water changes
    // ================================================================================================
    private static void emitter(GuiGraphics g, long seed, float t) {
        float p = smooth(clamp01((t - START) / 70f));
        float baseHue = 0.565f; // the water's blue
        float[] targets = {0.0f, 0.33f, 0.12f, 0.78f, 0.9f}; // red, green, orange, violet, pink
        float target = targets[(int) ((seed >>> 3 & 0x7fffffffL) % targets.length)];
        float hueDelta = target - baseHue;
        if (hueDelta > 0.5f) hueDelta -= 1f;
        if (hueDelta < -0.5f) hueDelta += 1f;
        float hue = baseHue + hueDelta * p;
        int rgb = Mth.hsvToRgb(((hue % 1f) + 1f) % 1f, 0.65f, 0.78f);
        int col = 0xC0000000 | rgb;
        if (p > 0f) { // a soft glow around the glass in the new colour
            int glow = withAlpha(0xFF000000 | rgb, 0.22f * p);
            g.fill(-6, -4, W + 6, H + 4, glow);
            g.fill(-3, -2, W + 3, H + 2, glow);
        }
        water(g, WATER_TOP, p > 0f ? col : WATER, 1f);
        aura(g, t);
        if (p > 0f && p < 1f) { // a band of the new colour sweeping down through the water
            int y = WATER_TOP + Math.round(p * (H - WATER_TOP));
            g.fill(1, Math.max(WATER_TOP, y - 3), W - 1, Math.min(H - 1, y), withAlpha(0xFFFFFFFF, 0.25f));
        }
        for (int i = 0; i < 5; i++) { // ripples at the surface
            float life = ((t - START) * 0.025f + i * 0.2f) % 1f;
            if (t < START) break;
            int r = Math.round(2 + life * 18);
            g.fill(W / 2 - r, WATER_TOP + 1, W / 2 + r, WATER_TOP + 2, withAlpha(0xFFFFFFFF, (1f - life) * 0.5f));
        }
        leaf(g, W / 2f, WATER_TOP + 1 + Mth.sin(t * 0.15f) * 0.6f, 0f, LEAF, 1f, 1f);
        glassFrame(g);
    }

    // ================================================================================================
    // Conjurer: impurities appear in the water
    // ================================================================================================
    private static void conjurer(GuiGraphics g, long seed, float t) {
        float p = clamp01((t - START) / 80f);
        int cloudy = lerpColor(0xFF3C7FB0, 0xFF6F8A86, p * 0.7f);
        water(g, WATER_TOP, (cloudy & 0x00FFFFFF) | 0xC0000000, 1f);
        aura(g, t);
        int n = Math.round(Mth.clamp((t - START) * 0.9f, 0f, 70f));
        int[] cols = {0xFFE8E4D0, 0xFF8A8F90, 0xFF5E4A36, 0xFFB7A98A, 0xFF2E2E30, 0xFFD9D2B0};
        for (int i = 0; i < n; i++) {
            float born = START + i * 1.1f;
            float age = t - born;
            if (age < 0) continue;
            float px0 = 4 + rnd(seed, i, 1) * (W - 9);
            float speed = 0.12f + rnd(seed, i, 2) * 0.28f;
            float y = WATER_TOP + 2 + Math.min(age * speed, (H - 5) - (WATER_TOP + 2) - rnd(seed, i, 4) * 6f);
            float x = px0 + Mth.sin(age * 0.12f + i) * 2.5f * Math.max(0f, 1f - age * 0.012f);
            int size = rnd(seed, i, 5) > 0.7f ? 3 : rnd(seed, i, 5) > 0.35f ? 2 : 1;
            int xi = Math.round(Mth.clamp(x, 2, W - 2 - size)), yi = Math.round(y);
            g.fill(xi, yi, xi + size, yi + size, cols[(int) (rnd(seed, i, 6) * cols.length) % cols.length]);
        }
        leaf(g, W / 2f, WATER_TOP + 1 + Mth.sin(t * 0.15f) * 0.5f, Mth.sin(t * 0.07f) * 0.06f, tinted(LEAF, 0xFF6F5A3A, p * 0.3f), 1f, 1f);
        glassFrame(g);
    }

    // ================================================================================================
    // Manipulator: the leaf moves
    // ================================================================================================
    private static void manipulator(GuiGraphics g, float t) {
        water(g, WATER_TOP, WATER, 1f);
        aura(g, t);
        float u = Math.max(0f, t - START);
        float ramp = smooth(clamp01(u / 20f));
        float x, rot;
        if (u < 70f) { // it wakes and wanders in a slow figure of eight
            x = W / 2f + Mth.sin(u * 0.13f) * 15f * ramp;
            rot = Mth.sin(u * 0.13f) * 0.9f * ramp + u * 0.02f * ramp;
        } else { // then drifts to one side and turns to point at the player
            float k = smooth(clamp01((u - 70f) / 30f));
            float x0 = W / 2f + Mth.sin(70f * 0.13f) * 15f;
            x = Mth.lerp(k, x0, W / 2f - 14f);
            rot = Mth.lerp(k, Mth.sin(70f * 0.13f) * 0.9f + 70f * 0.02f, -0.35f) + Mth.sin(u * 0.4f) * 0.04f * k;
        }
        float y = WATER_TOP + 1 + Mth.sin(u * 0.26f) * 0.9f * ramp + Mth.cos(u * 0.13f) * 1.2f * ramp;
        for (int i = 0; i < 4 && u > 0; i++) { // ripples spreading from the leaf
            float life = (u * 0.03f + i * 0.25f) % 1f;
            int r = Math.round(3 + life * 10);
            g.fill(Math.round(x) - r, WATER_TOP + 1, Math.round(x) + r, WATER_TOP + 2, withAlpha(0xFFFFFFFF, (1f - life) * 0.45f));
        }
        leaf(g, x, y, rot, LEAF, 1f, 1f);
        glassFrame(g);
    }

    // ================================================================================================
    // Specialist: anything else (the leaf burns, the water freezes, or bubbles pour out of it)
    // ================================================================================================
    /** 0 = the leaf burns, 1 = the water freezes, 2 = bubbles. Fixed for a player. */
    private static int specialistKind(long seed) {
        return (int) ((seed >>> 5 & 0x7fffffffL) % 3);
    }

    private static void specialist(GuiGraphics g, long seed, float t) {
        switch (specialistKind(seed)) {
            case 0 -> burn(g, seed, t);
            case 1 -> freeze(g, seed, t);
            default -> bubbles(g, seed, t);
        }
    }

    private static void burn(GuiGraphics g, long seed, float t) {
        float u = Math.max(0f, t - START);
        water(g, WATER_TOP, WATER, 1f);
        aura(g, t);
        float char_ = clamp01(u / 40f);
        float crumble = clamp01((u - 40f) / 30f);
        if (crumble < 1f) {
            int col = char_ < 0.5f ? lerpColor(LEAF, 0xFF6B4A1E, char_ * 2f) : lerpColor(0xFF6B4A1E, 0xFF1B1410, (char_ - 0.5f) * 2f);
            if (crumble <= 0f) {
                leaf(g, W / 2f, WATER_TOP + 1, 0f, col, 1f, 1f);
                // the glowing edge, then flames licking up from it
                if (u > 4f) {
                    int fl = Math.round(1 + char_ * 7);
                    for (int i = 0; i < 6; i++) {
                        int fx = Math.round(W / 2f - 10 + i * 4);
                        float fh = fl * (0.6f + 0.4f * Mth.sin(t * 0.7f + i * 1.9f));
                        g.fill(fx, WATER_TOP - Math.round(fh), fx + 3, WATER_TOP, withAlpha(0xFFFF8A1E, 0.9f));
                        g.fill(fx + 1, WATER_TOP - Math.round(fh * 0.6f), fx + 2, WATER_TOP, 0xFFFFE08A);
                    }
                }
            } else { // it comes apart into pieces that fall away and glow out
                for (int i = 0; i < 8; i++) {
                    float dx = (rnd(seed, i, 1) - 0.5f) * 26f * crumble;
                    float dy = crumble * crumble * (6 + rnd(seed, i, 2) * 14f);
                    float a = 1f - crumble;
                    g.pose().pushPose();
                    g.pose().translate(W / 2f - 8 + i * 2.3f + dx, WATER_TOP + 1 + dy, 0);
                    g.pose().mulPose(Axis.ZP.rotation(crumble * (rnd(seed, i, 3) - 0.5f) * 8f));
                    g.fill(-2, -2, 3, 2, withAlpha(0xFF1B1410, a));
                    g.fill(-2, -2, 0, 0, withAlpha(0xFFFF7A1A, a * 0.8f));
                    g.pose().popPose();
                }
            }
        }
        if (u > 6f) { // embers and smoke
            for (int i = 0; i < 12; i++) {
                float life = (u * 0.025f + i * 0.083f) % 1f;
                if (u > 100f && i % 2 == 0) continue;
                float x = W / 2f - 12 + rnd(seed, i, 4) * 24f + Mth.sin(life * 6f + i) * 3f;
                float y = WATER_TOP - 2 - life * 22f;
                if (i % 3 == 0) g.fill(Math.round(x), Math.round(y), Math.round(x) + 3, Math.round(y) + 3, withAlpha(0xFF6E6A66, (1f - life) * 0.55f));
                else g.fill(Math.round(x), Math.round(y), Math.round(x) + 1, Math.round(y) + 1, withAlpha(0xFFFFA030, 1f - life));
            }
        }
        glassFrame(g);
    }

    private static void freeze(GuiGraphics g, long seed, float t) {
        float p = smooth(clamp01((t - START) / 55f));
        water(g, WATER_TOP, WATER, 1f);
        int front = WATER_TOP + Math.round(p * (H - 1 - WATER_TOP)); // the freezing front moves down
        if (p > 0f) {
            g.fill(1, WATER_TOP, W - 1, front, 0xE0C8EAF8);
            g.fill(1, WATER_TOP, W - 1, WATER_TOP + 2, 0xFFF4FCFF);
            for (int i = 0; i < 9; i++) { // cracks and ice crystals
                float cx = 4 + rnd(seed, i, 1) * (W - 8);
                float cy = WATER_TOP + 3 + rnd(seed, i, 2) * (H - WATER_TOP - 8);
                if (cy > front) continue;
                int len = 4 + (int) (rnd(seed, i, 3) * 9);
                g.fill(Math.round(cx), Math.round(cy), Math.round(cx) + len, Math.round(cy) + 1, 0xFFFFFFFF);
                g.fill(Math.round(cx) + len / 2, Math.round(cy) - len / 3, Math.round(cx) + len / 2 + 1, Math.round(cy) + len / 3, 0xFFE6F7FF);
            }
            if (front < H - 1) g.fill(1, front, W - 1, front + 1, 0xFFFFFFFF);
        }
        aura(g, t);
        leaf(g, W / 2f, WATER_TOP + 1, 0f, tinted(LEAF, 0xFFE8F6FF, p * 0.8f), 1f, 1f);
        glassFrame(g);
        if (p > 0.3f) { // frost creeping over the glass
            float f = clamp01((p - 0.3f) / 0.7f);
            int frost = withAlpha(0xFFFFFFFF, 0.55f * f);
            g.fill(-1, 0, 2, Math.round(H * f), frost);
            g.fill(W - 2, 0, W + 1, Math.round(H * f), frost);
            g.fill(-1, H - 3, W + 1, H, withAlpha(0xFFFFFFFF, 0.6f * f));
            for (int i = 0; i < 10; i++) {
                float life = ((t * 0.03f) + i * 0.1f) % 1f;
                int x = Math.round(rnd(seed, i, 7) * W);
                g.fill(x, Math.round(-2 - life * 12f), x + 1, Math.round(-2 - life * 12f) + 1, withAlpha(0xFFFFFFFF, (1f - life) * f));
            }
        }
    }

    private static void bubbles(GuiGraphics g, long seed, float t) {
        float u = Math.max(0f, t - START);
        float p = clamp01(u / 30f);
        int fizz = lerpColor(0xFF3C7FB0, 0xFF6FB6D8, p * 0.5f);
        water(g, WATER_TOP, (fizz & 0x00FFFFFF) | 0xC0000000, 1f);
        aura(g, t);
        int n = Math.round(Mth.clamp(u * 0.5f, 0f, 46f));
        for (int i = 0; i < n; i++) {
            float speed = 0.5f + rnd(seed, i, 2) * 0.7f;
            float period = (H - WATER_TOP) / speed;
            float age = ((u - i * 1.7f) % period + period) % period;
            float x = 4 + rnd(seed, i, 1) * (W - 11) + Mth.sin(age * 0.2f + i) * 1.8f;
            float y = H - 4 - age * speed;
            if (y < WATER_TOP + 1) continue;
            int size = rnd(seed, i, 5) > 0.6f ? 5 : rnd(seed, i, 5) > 0.3f ? 4 : 3;
            int xi = Math.round(x), yi = Math.round(y);
            g.fill(xi, yi, xi + size, yi + 1, 0xCCFFFFFF);
            g.fill(xi, yi + size - 1, xi + size, yi + size, 0x99FFFFFF);
            g.fill(xi, yi, xi + 1, yi + size, 0xCCFFFFFF);
            g.fill(xi + size - 1, yi, xi + size, yi + size, 0x99FFFFFF);
            g.fill(xi + 1, yi + 1, xi + 2, yi + 2, 0xFFFFFFFF);
        }
        for (int i = 0; i < 10 && u > 6f; i++) { // foam and popping droplets at the surface
            float life = (u * 0.06f + i * 0.1f) % 1f;
            float x = 5 + rnd(seed, i, 9) * (W - 10);
            g.fill(Math.round(x) - 2, WATER_TOP - 1, Math.round(x) + 3, WATER_TOP + 1, withAlpha(0xFFFFFFFF, 0.8f));
            if (life < 0.5f) g.fill(Math.round(x), Math.round(WATER_TOP - 2 - Mth.sin(life * 2f * Mth.PI) * 5f), Math.round(x) + 1, Math.round(WATER_TOP - 2 - Mth.sin(life * 2f * Mth.PI) * 5f) + 1, 0xFFCFEFFF);
        }
        leaf(g, W / 2f + Mth.sin(u * 0.5f) * 1.2f * p, WATER_TOP + 1 + Mth.sin(u * 0.7f) * 1.1f * p, Mth.sin(u * 0.45f) * 0.12f * p, LEAF, 1f, 1f);
        glassFrame(g);
    }

    private static void plain(GuiGraphics g, float t) {
        water(g, WATER_TOP, WATER, 1f);
        aura(g, t);
        leaf(g, W / 2f, WATER_TOP + 1, 0f, LEAF, 1f, 1f);
        glassFrame(g);
    }

    // ================================================================================================
    // shared pieces
    // ================================================================================================

    /** The water body, from {@code top} down to the bottom of the glass, with a bright line at the surface. */
    private static void water(GuiGraphics g, int top, int color, float alpha) {
        g.fill(1, top, W - 1, H - 1, color);
        g.fill(1, top, W - 1, top + 2, SURFACE);
    }

    private static void glassFrame(GuiGraphics g) {
        g.fill(0, 0, W, 1, FRAME);
        g.fill(0, H - 1, W, H, FRAME);
        g.fill(0, 0, 1, H, FRAME);
        g.fill(W - 1, 0, W, H, FRAME);
        g.fill(8, H, W - 8, H + 3, FRAME); // the foot
    }

    /** The thin thread of aura reaching down from above into the water, pulsing, until the reaction takes over. */
    private static void aura(GuiGraphics g, float t) {
        if (t >= START + 14f) return;
        float fade = t < START ? 1f : 1f - (t - START) / 14f;
        float pulse = 0.6f + 0.4f * Mth.sin(t * 0.6f);
        int len = Math.round(Math.min(1f, t / (START * 0.8f)) * (THREAD_H + WATER_TOP));
        int x = W / 2;
        g.fill(x - 1, -THREAD_H, x + 1, -THREAD_H + len, withAlpha(0xFFFFD27F, 0.85f * fade * pulse));
        g.fill(x - 3, -THREAD_H, x + 3, -THREAD_H + len, withAlpha(0xFFFFB347, 0.18f * fade * pulse));
        if (len >= THREAD_H + WATER_TOP - 1) {
            int r = Math.round(3 + (t % 8) * 1.5f);
            g.fill(x - r, WATER_TOP + 1, x + r, WATER_TOP + 2, withAlpha(0xFFFFE9B0, 0.5f * fade));
        }
    }

    /** A leaf on the water: a body, a stem and a vein, drawn about its centre and turned by {@code rot} radians. */
    private static void leaf(GuiGraphics g, float cx, float cy, float rot, int color, float alpha, float size) {
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().mulPose(Axis.ZP.rotation(rot));
        g.pose().scale(size, size, 1f);
        g.fill(-11, -3, 12, 1, color);
        g.fill(-8, -4, 8, -3, color);
        g.fill(-8, 1, 8, 2, darker(color));
        g.fill(-13, -2, -11, -1, darker(color)); // stem
        g.fill(-9, -1, 10, 0, darker(color));    // the central vein
        g.pose().popPose();
    }

    private static int darker(int c) {
        int a = c >>> 24, r = (c >> 16 & 255) * 3 / 4, gg = (c >> 8 & 255) * 3 / 4, b = (c & 255) * 3 / 4;
        return a << 24 | r << 16 | gg << 8 | b;
    }

    private static int tinted(int base, int tint, float amount) {
        return lerpColor(base, tint, amount) | 0xFF000000;
    }

    private static int lerpColor(int a, int b, float t) {
        t = clamp01(t);
        int r = Math.round(Mth.lerp(t, a >> 16 & 255, b >> 16 & 255));
        int gg = Math.round(Mth.lerp(t, a >> 8 & 255, b >> 8 & 255));
        int bl = Math.round(Mth.lerp(t, a & 255, b & 255));
        int al = Math.round(Mth.lerp(t, a >>> 24, b >>> 24));
        return al << 24 | r << 16 | gg << 8 | bl;
    }

    /** The colour with its alpha multiplied by {@code a} (0..1). */
    private static int withAlpha(int c, float a) {
        int al = Math.round((c >>> 24) * clamp01(a));
        return al << 24 | (c & 0x00FFFFFF);
    }

    private static float clamp01(float v) { return v < 0f ? 0f : Math.min(v, 1f); }

    private static float smooth(float v) { return v * v * (3f - 2f * v); }

    /** A stable pseudo-random number in [0, 1) from a seed, an index and a salt. */
    private static float rnd(long seed, int i, int salt) {
        long h = seed * 0x9E3779B97F4A7C15L + i * 0xBF58476D1CE4E5B9L + salt * 0x94D049BB133111EBL;
        h ^= h >>> 30;
        h *= 0xBF58476D1CE4E5B9L;
        h ^= h >>> 27;
        h *= 0x94D049BB133111EBL;
        h ^= h >>> 31;
        return (h >>> 40) / (float) (1 << 24);
    }
}
