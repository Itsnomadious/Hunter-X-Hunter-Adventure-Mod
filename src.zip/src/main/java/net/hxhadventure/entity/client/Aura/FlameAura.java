package net.hxhadventure.entity.client.Aura;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;

/**
 * Procedural flame used for the Ren and Ken auras.
 *
 * The flame is built from three translucent shells of the same size (pale edge, aura-colour body, deeper core) that
 * move out of step with each other, like the layers of a candle flame. Every shell is a surface of revolution: a rounded, near-spherical belly around the player that
 * narrows into a plume. The mesh is rebuilt every frame so it can wave, sway and ebb.
 *
 * Coordinates are in blocks with the feet at the origin and +Y up, so callers only need to position and scale it.
 *
 * Draw with FlameRenderType.flame() (position + colour, normal alpha blending like Ten, no depth write) so the overlapping shells all show.
 */
public final class FlameAura {
    private FlameAura() {}

    public enum Style {
        /** One big smooth flame: a near-sphere around the player that plumes upward. Slow, gentle waving. */
        REN(1.05f, 1.05f, 2.35f, 24, 7, 14, 0.04f, 0.17f, 0f, 0.38f, 1.8f, 1f, 40),
        /** Little Flower's palm aura: the same flame, but a small ball wrapped round the hand with only a short plume. Draw it scaled to about the size of a hand. */
        HAND(1.0f, 1.0f, 0.75f, 16, 6, 8, 0.05f, 0.20f, 0f, 0.22f, 1.5f, 1.4f, 14);

        final float radius, belly, plume;
        final int segments, bellyRings, plumeRings, wisps;
        final float wobbleBase, wobbleTop, jag, sway, tipSharpness, speed;
        /** How many jagged tongues around the flame (Ken only). */
        final float lobes = 7f;

        Style(float radius, float belly, float plume, int segments, int bellyRings, int plumeRings,
              float wobbleBase, float wobbleTop, float jag, float sway, float tipSharpness, float speed, int wisps) {
            this.radius = radius;
            this.belly = belly;
            this.plume = plume;
            this.segments = segments;
            this.bellyRings = bellyRings;
            this.plumeRings = plumeRings;
            this.wobbleBase = wobbleBase;
            this.wobbleTop = wobbleTop;
            this.jag = jag;
            this.sway = sway;
            this.tipSharpness = tipSharpness;
            this.speed = speed;
            this.wisps = wisps;
        }

        float height() { return belly + plume; }
    }

    /** Aura colour index (0-8: gold, light blue, red, dark blue, green, purple, pink, white, black; 9-20: yellow, silver, lime, cyan, coral, teal, grey, forest, maroon, indigo, midnight) to base RGB. */
    private static final int[][] BASE = {
        {255, 191, 0}, {0, 175, 255}, {196, 12, 0}, {90, 70, 235}, {40, 230, 70},
        {160, 60, 255}, {255, 90, 190}, {245, 245, 255}, {12, 12, 16},
        {255, 236, 70}, {200, 205, 215}, {170, 255, 60}, {0, 230, 230}, {255, 112, 80}, {0, 150, 136}, {100, 100, 110}, {0, 96, 44}, {140, 0, 34}, {62, 32, 150}, {26, 14, 66}
    };

    // Shell definitions, inner to outer: alpha per layer (they stack, so each is low).
    // All three shells are the same size; they only differ in colour and in when they move (phase offset per shell).
    private static final float[] SHELL_A = {0.17f, 0.15f, 0.14f, 0.13f, 0.11f, 0.10f};
    /** Per-layer opacity variation: each layer is up to 30% more or less opaque than its base alpha (averages out to about 1). */
    private static final float[] SHELL_VARY = {1.30f, 0.72f, 1.18f, 0.80f, 1.25f, 0.78f};
    /** Per-layer movement speed, deliberately not in order, so neighbouring layers keep drifting apart. */
    private static final float[] SHELL_SPEED = {0.70f, 1.20f, 0.90f, 1.45f, 0.60f, 1.05f};
    /** Each layer swells and shrinks on its own by up to this fraction (0.10 = 10% larger and smaller), and its opacity likewise. */
    private static final float SIZE_AMP = 0.10f, OPACITY_AMP = 0.10f;
    /** Radians per second of each layer's size and opacity cycle: all different, so the layers drift in and out of step. */
    private static final float[] SIZE_FREQ = {1.30f, 1.90f, 1.10f, 2.20f, 1.60f, 1.45f};
    private static final float[] OPACITY_FREQ = {1.70f, 1.20f, 2.10f, 1.50f, 1.00f, 1.90f};
    // How many wisps (small pieces of aura that break off, drift away and dissipate) are out at once is per Style (Style.wisps).
    /** The flame starts this far below the feet, so its flat base sits just under the player. */
    /** Ren's default size: every Ren flame is drawn this much bigger than the size shown on the slider (1.0x on the slider = 1.2 here). */
    public static final float REN_BASE_SCALE = 1.2f;
    /** Ren is this much taller than it is wide. */
    public static final float REN_HEIGHT_STRETCH = 1.1f;
    /** Opacity multiplier for the player's own flame in first person, so it is visible but never blocks the view. */
    public static final float FIRST_PERSON_OPACITY = 0.3f;
    /** The whole flame, wisps included, is drawn this much as opaque as before (0.7 = 30% more transparent). */
    private static final float OVERALL_OPACITY = 0.7f;
    private static final float DROP = 0.25f;
    /** Below 1 flattens the base of the belly (radius = cos(phi)^this): 1 would be a round sphere bottom. */
    private static final float FLAT_BASE = 0.3f;

    /**
     * @param time    seconds, can be fractional (ageInTicks / 20)
     * @param seed    per-entity phase offset so two flames never move in sync
     * @param opacity overall opacity multiplier (1 = normal)
     * @param shade   colour multiplier (1 = normal, below 1 = darker)
     */
    public static void draw(PoseStack ps, VertexConsumer vc, Style style, int colour, float time, float seed,
                            float opacity, float shade) {
        draw(ps, vc, style, colour, time, seed, opacity, shade, 0f);
    }

    /** Where the middle of the belly sits in the style's own units (the flame is drawn {@link #DROP} lower than its raw shape), so a caller can put that point on whatever it wraps. */
    public static float bellyCentreY(Style style) {
        return style.belly - DROP;
    }

    /**
     * @param bright 0..1: how far the colour is pushed towards white (a hotter, brighter flame); 0 = the plain aura colour
     */
    public static void draw(PoseStack ps, VertexConsumer vc, Style style, int colour, float time, float seed,
                            float opacity, float shade, float bright) {
        opacity *= OVERALL_OPACITY;
        bright = Math.max(0f, Math.min(1f, bright));
        int[] base = BASE[Math.max(0, Math.min(BASE.length - 1, colour))];
        Matrix4f m = ps.last().pose();
        float t = time * style.speed;

        for (int layer = 0; layer < SHELL_A.length; layer++) {
            // every layer is exactly the Ten colour; the layers differ only in how they move
            float[] c = lift(base, shade, bright);
            // every layer has its own size and opacity cycle: up to 10% bigger / smaller and 10% more / less opaque
            float sizeF = 1f + SIZE_AMP * (float) Math.sin(time * SIZE_FREQ[layer] + seed * 1.3f + layer * 2.3f);
            float opF = 1f + OPACITY_AMP * (float) Math.sin(time * OPACITY_FREQ[layer] + seed * 0.7f + layer * 1.1f + 1.3f);
            shell(m, vc, style, layer, t * SHELL_SPEED[layer], seed + layer * 1.9f, c, SHELL_A[layer] * SHELL_VARY[layer] * opacity * opF, sizeF);
        }
        wisps(m, vc, style, lift(base, shade, bright), time, (int) (seed * 1000f), opacity);
    }

    /** The aura colour, darkened by shade, then pushed towards white by bright. */
    private static float[] lift(int[] base, float shade, float bright) {
        float[] c = new float[3];
        for (int i = 0; i < 3; i++) {
            float v = base[i] * shade;
            c[i] = Math.min(255f, v + (255f - v) * bright);
        }
        return c;
    }

    private static void shell(Matrix4f m, VertexConsumer vc, Style s, int layer, float t, float phase, float[] col, float alpha, float sizeF) {
        int segs = s.segments;
        int rings = s.bellyRings + s.plumeRings + 1;
        float total = s.height();

        float[][][] pos = new float[rings][segs + 1][3];
        float[] a = new float[rings];

        // the whole flame breathes: slow ebb in width and height
        float breathW = 1f + 0.035f * (float) Math.sin(t * 2.0f + phase);
        float breathH = 1f + 0.05f * (float) Math.sin(t * 1.6f + phase + 1.0f);

        for (int i = 0; i < rings; i++) {
            float y, r, up;
            if (i <= s.bellyRings) {
                // rounded belly: lower half of an ellipsoid, pole at the feet, widest at the belly line
                float phi = -(float) Math.PI / 2f + (float) Math.PI / 2f * i / s.bellyRings;
                y = s.belly + s.belly * (float) Math.sin(phi);
                r = s.radius * (float) Math.pow(Math.cos(phi), FLAT_BASE);
                up = 0f;
            } else {
                // plume: narrows smoothly to a point, with no kink where it leaves the belly
                float u = (float) (i - s.bellyRings) / s.plumeRings;
                y = s.belly + u * s.plume;
                r = s.radius * (float) Math.pow(Math.cos(u * Math.PI / 2.0), s.tipSharpness);
                up = u;
            }

            float hNorm = y / total;
            // fade out towards the tip and soften the very bottom so it never shows a hard edge
            float fade = 1f - 0.8f * smooth(0.45f, 1.0f, hNorm);
            float bottom = smooth(0.0f, 0.10f, hNorm);
            a[i] = alpha * fade * (0.8f + 0.2f * bottom);

            float amp = s.wobbleBase + s.wobbleTop * up;
            float swayAmp = s.sway * up * up;
            float swayX = swayAmp * ((float) Math.sin(t * 1.4f + phase) + 0.5f * (float) Math.sin(t * 2.3f + phase * 1.3f + 1.3f));
            float swayZ = swayAmp * ((float) Math.cos(t * 1.1f + phase * 1.7f) + 0.4f * (float) Math.sin(t * 2.7f + phase));
            // the very tip flickers a little faster
            float tipFlicker = 1f + 0.08f * up * (float) Math.sin(t * 5.0f + phase * 2f);

            for (int j = 0; j <= segs; j++) {
                float th = (float) (2.0 * Math.PI * (j % segs) / segs);
                float wob = amp * (0.6f * (float) Math.sin(3f * th + t * 2.3f + y * 2.2f + phase)
                    + 0.4f * (float) Math.sin(2f * th - t * 3.1f + y * 3.0f + phase * 0.7f));

                float jagR = 0f, lift = 0f;
                if (s.jag > 0f) {
                    // triangle wave around the flame gives sharp tongues; they travel and fade in with height
                    float tri = tri(s.lobes * th / (2f * (float) Math.PI) + t * 0.9f - y * 0.8f + phase);
                    jagR = s.jag * (0.15f + up) * (tri - 0.5f) * 2f;
                    lift = s.jag * 0.45f * up * (tri - 0.5f);
                }

                float rr = Math.max(0f, r * (1f + wob + jagR)) * breathW * sizeF;
                float yy = (y * breathH * tipFlicker + lift) * sizeF;

                float x = swayX + rr * (float) Math.cos(th);
                float z = swayZ + rr * (float) Math.sin(th);

                pos[i][j][0] = x;
                pos[i][j][1] = yy - DROP;
                pos[i][j][2] = z;
            }
        }

        for (int i = 0; i < rings - 1; i++) {
            for (int j = 0; j < segs; j++) {
                put(m, vc, pos[i][j], col, a[i]);
                put(m, vc, pos[i + 1][j], col, a[i + 1]);
                put(m, vc, pos[i + 1][j + 1], col, a[i + 1]);
                put(m, vc, pos[i][j + 1], col, a[i]);
            }
        }
    }

    // =================================================================================================
    // Wisps: smaller pieces of the aura that break off the surface, drift outward and upward, and dissipate.
    // Every wisp lives in cycles; each cycle picks a fresh place, size, shape and drift from a hash, so nothing is stored.
    // Shapes: curling teardrops (flame licks), round embers and sharp shards, in a spread of sizes.
    // =================================================================================================

    private static float hash(int a, int b, int c) {
        int h = a * 0x27d4eb2d + b * 0x165667b1 + c * 0x9e3779b1;
        h ^= h >>> 15;
        h *= 0x85ebca6b;
        h ^= h >>> 13;
        h *= 0xc2b2ae35;
        h ^= h >>> 16;
        return (h >>> 8) / 16777216f;
    }

    /** The flame's radius at this height (the same profile the shells use, without the wobble). */
    private static float profileRadius(Style s, float y) {
        if (y <= s.belly) {
            float phi = (float) Math.asin(Math.max(-1f, Math.min(1f, (y - s.belly) / s.belly)));
            return s.radius * (float) Math.pow(Math.max(0.0, Math.cos(phi)), FLAT_BASE);
        }
        float u = Math.min(1f, (y - s.belly) / s.plume);
        return s.radius * (float) Math.pow(Math.max(0.0, Math.cos(u * Math.PI / 2.0)), s.tipSharpness);
    }

    private static void wisps(Matrix4f m, VertexConsumer vc, Style s, float[] col, float time, int seedI, float opacity) {
        float total = s.height();
        for (int k = 0; k < s.wisps; k++) {
            float life = 1.5f + 1.7f * hash(seedI, k, 11);
            float x = time / life + hash(seedI, k, 12);
            int cyc = (int) Math.floor(x);
            float f = x - cyc;
            int rs = seedI * 31 + k; // this wisp's randoms for this cycle: hash(rs, cyc, n)
            float th = (float) (2.0 * Math.PI) * hash(rs, cyc, 1);
            float y0 = (0.08f + 0.62f * hash(rs, cyc, 2)) * total;
            float r0 = profileRadius(s, y0) * 0.92f;
            float out = 0.25f + 0.55f * hash(rs, cyc, 3);
            float up = 0.45f + 0.85f * hash(rs, cyc, 4);
            float swirl = (hash(rs, cyc, 5) - 0.5f) * 0.9f;
            int type = Math.min(2, (int) (hash(rs, cyc, 6) * 3f));
            float big = hash(rs, cyc, 7);
            float bend = (hash(rs, cyc, 8) - 0.5f) * 0.9f;
            float spin = (float) (2.0 * Math.PI) * hash(rs, cyc, 9);

            float cx = (float) Math.cos(th), sz = (float) Math.sin(th);
            float a = f * life; // seconds since it broke off
            float wob = 0.05f * (float) Math.sin(a * 4f + hash(rs, cyc, 10) * 6f);
            float px = cx * (r0 + out * a + wob) - sz * swirl * a;
            float py = y0 - DROP + up * a;
            float pz = sz * (r0 + out * a + wob) + cx * swirl * a;

            // it points the way it is travelling
            float vx = cx * out - sz * swirl, vy = up, vz = sz * out + cx * swirl;
            float vl = (float) Math.sqrt(vx * vx + vy * vy + vz * vz);
            vx /= vl;
            vy /= vl;
            vz /= vl;

            float length, radius;
            int sides, rings;
            if (type == 1) { // ember
                length = 0.14f + 0.30f * big * big;
                radius = length * 0.5f;
                sides = 7;
                rings = 5;
            } else if (type == 2) { // shard
                length = 0.30f + 0.85f * big * big;
                radius = length * 0.11f;
                sides = 4;
                rings = 4;
            } else { // curling flame lick
                length = 0.22f + 0.75f * big * big;
                radius = length * 0.26f;
                sides = 6;
                rings = 6;
            }
            float shrink = 0.35f + 0.65f * (float) Math.sin(Math.PI * f);
            float env = smooth(0f, 0.15f, f) * (1f - smooth(0.35f, 1f, f));
            float alpha = 0.30f * opacity * env;
            if (alpha <= 0.002f) continue;
            lathe(m, vc, col, px, py, pz, vx, vy, vz, length * shrink, radius * shrink, type, type == 0 ? bend : 0f, spin + a * 1.6f, alpha, sides, rings);
        }
    }

    private static float profile(int type, float u) {
        return switch (type) {
            case 1 -> (float) Math.sin(Math.PI * u);                       // round ember
            case 2 -> 1f - Math.abs(2f * u - 1f);                          // double cone: a shard
            default -> (float) Math.sin(Math.PI * Math.pow(u, 0.6));       // teardrop: fat behind, sharp ahead
        };
    }

    /** A small solid of revolution about the axis (ax, ay, az), centred on (cx, cy, cz); both faces of every quad are drawn so it shows from any side. */
    private static void lathe(Matrix4f m, VertexConsumer vc, float[] col, float cx, float cy, float cz, float ax, float ay, float az,
                              float length, float radius, int type, float bend, float spin, float alpha, int sides, int rings) {
        // two directions across the axis
        float rx = Math.abs(ay) > 0.9f ? 1f : 0f, ry = Math.abs(ay) > 0.9f ? 0f : 1f;
        float e1x = ay * 0f - az * ry, e1y = az * rx - ax * 0f, e1z = ax * ry - ay * rx;
        float l1 = (float) Math.sqrt(e1x * e1x + e1y * e1y + e1z * e1z);
        e1x /= l1;
        e1y /= l1;
        e1z /= l1;
        float e2x = ay * e1z - az * e1y, e2y = az * e1x - ax * e1z, e2z = ax * e1y - ay * e1x;

        float[][][] pos = new float[rings + 1][sides + 1][3];
        float[] al = new float[rings + 1];
        for (int i = 0; i <= rings; i++) {
            float u = (float) i / rings;
            float along = (u - 0.5f) * length;
            float lateral = bend * length * (float) Math.sin(Math.PI * u);
            float r = radius * profile(type, u);
            float bx = cx + ax * along + e1x * lateral, by = cy + ay * along + e1y * lateral, bz = cz + az * along + e1z * lateral;
            al[i] = alpha * (0.45f + 0.55f * (float) Math.sin(Math.PI * u));
            for (int j = 0; j <= sides; j++) {
                float ang = (float) (2.0 * Math.PI * (j % sides) / sides) + spin;
                float c = (float) Math.cos(ang) * r, sn = (float) Math.sin(ang) * r;
                pos[i][j][0] = bx + e1x * c + e2x * sn;
                pos[i][j][1] = by + e1y * c + e2y * sn;
                pos[i][j][2] = bz + e1z * c + e2z * sn;
            }
        }
        for (int i = 0; i < rings; i++) {
            for (int j = 0; j < sides; j++) {
                put(m, vc, pos[i][j], col, al[i]);
                put(m, vc, pos[i + 1][j], col, al[i + 1]);
                put(m, vc, pos[i + 1][j + 1], col, al[i + 1]);
                put(m, vc, pos[i][j + 1], col, al[i]);
                put(m, vc, pos[i][j + 1], col, al[i]); // and the same quad the other way round
                put(m, vc, pos[i + 1][j + 1], col, al[i + 1]);
                put(m, vc, pos[i + 1][j], col, al[i + 1]);
                put(m, vc, pos[i][j], col, al[i]);
            }
        }
    }

    private static void put(Matrix4f m, VertexConsumer vc, float[] p, float[] col, float alpha) {
        int al = Math.max(0, Math.min(255, (int) (alpha * 255f)));
        vc.vertex(m, p[0], p[1], p[2]).color((int) col[0], (int) col[1], (int) col[2], al).endVertex();
    }

    private static float smooth(float e0, float e1, float x) {
        float k = Math.max(0f, Math.min(1f, (x - e0) / (e1 - e0)));
        return k * k * (3f - 2f * k);
    }

    /** Triangle wave, 0..1, period 1. */
    private static float tri(float x) {
        return Math.abs(2f * (x - (float) Math.floor(x)) - 1f);
    }
}
