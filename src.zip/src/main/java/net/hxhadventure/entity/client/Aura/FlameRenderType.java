package net.hxhadventure.entity.client.Aura;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.RenderType;

/**
 * Position + colour with normal alpha blending (like the Ten texture, so colours match exactly, black included), and no depth
 * write. The flame shells are the same size and overlap everywhere, so with depth writes the first one drawn would hide the others.
 */
public final class FlameRenderType extends RenderType {
    private FlameRenderType() {
        super("hxh_flame", DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 256, false, true, () -> {}, () -> {});
        throw new IllegalStateException("not instantiable");
    }

    private static final RenderType FLAME = RenderType.create(
        "hxh_flame",
        DefaultVertexFormat.POSITION_COLOR,
        VertexFormat.Mode.QUADS,
        1536,
        false,
        true,
        RenderType.CompositeState.builder()
            .setShaderState(RENDERTYPE_LIGHTNING_SHADER)
            .setWriteMaskState(COLOR_WRITE)
            .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
            .createCompositeState(false));

    /** Same, but both faces are drawn, so the flame can be seen from inside it (first person). */
    private static final RenderType FLAME_INSIDE = RenderType.create(
        "hxh_flame_inside",
        DefaultVertexFormat.POSITION_COLOR,
        VertexFormat.Mode.QUADS,
        1536,
        false,
        true,
        RenderType.CompositeState.builder()
            .setShaderState(RENDERTYPE_LIGHTNING_SHADER)
            .setWriteMaskState(COLOR_WRITE)
            .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
            .setCullState(NO_CULL)
            .createCompositeState(false));

    public static RenderType flame() {
        return FLAME;
    }

    public static RenderType flameInside() {
        return FLAME_INSIDE;
    }
}
