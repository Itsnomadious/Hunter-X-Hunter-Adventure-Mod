package net.hxhadventure.entity.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.Talent;
import net.hxhadventure.addon.client.ClientProfile;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketKiteAction;

/**
 * Talking to Kite. He comments on your talent; if your aura nodes are still shut he offers to force them open, and once they
 * are open he can teach you about Nen (NenTutorialScreen).
 */
public class KiteScreen extends Screen {
   private final int kiteId;
   private boolean confirming;
   private int px, py, pw, ph;

   public KiteScreen() {
      this(-1);
   }

   public KiteScreen(int kiteId) {
      super(Component.literal("Kite"));
      this.kiteId = kiteId;
   }

   private static boolean awakened() {
      Minecraft mc = Minecraft.getInstance();
      Combat c = mc.player == null ? null : Combat.get(mc.player);
      return c != null && c.hasNenUnlocked();
   }

   protected void init() {
      super.init();
      pw = Math.min(380, this.width - 20);
      ph = Math.min(240, this.height - 20);
      px = (this.width - pw) / 2;
      py = (this.height - ph) / 2;
      int bx = px + 24;
      int bw = pw - 48;
      int half = (bw - 8) / 2;
      int by = py + ph - 44;
      if (!awakened()) {
         if (!confirming) {
            this.addRenderableWidget(HxhUi.button(bx, by, half, 22, "Open my aura nodes", b -> {
               confirming = true;
               this.rebuildWidgets();
            }, true));
            this.addRenderableWidget(HxhUi.button(bx + half + 8, by, half, 22, "Not yet", b -> this.onClose(), false));
         } else {
            this.addRenderableWidget(HxhUi.button(bx, by, half, 22, "I am ready", b -> {
               AddonNetwork.sendToServer(new PacketKiteAction(kiteId));
               this.onClose();
            }, true));
            this.addRenderableWidget(HxhUi.button(bx + half + 8, by, half, 22, "Wait", b -> {
               confirming = false;
               this.rebuildWidgets();
            }, false));
         }
      } else {
         this.addRenderableWidget(HxhUi.button(bx, by, half, 22, "Teach me about Nen", b -> Minecraft.getInstance().setScreen(new NenTutorialScreen(this)), true));
         this.addRenderableWidget(HxhUi.button(bx + half + 8, by, half, 22, "Goodbye", b -> this.onClose(), false));
      }
   }

   public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
      HxhUi.backdrop(g, this.width, this.height);
      HxhUi.panel(g, px, py, pw, ph);
      int cx = px + pw / 2;
      HxhUi.title(g, this.font, "KITE", cx, py + 14);
      HxhUi.subtitle(g, this.font, "Nen Teacher", cx, py + 28);

      int ix = px + 16;
      int iy = py + 44;
      int iw = pw - 32;
      int ih = ph - 44 - 56;
      HxhUi.inset(g, ix, iy, iw, ih);
      int tx = ix + 10;
      int tw = iw - 20;
      int y = iy + 10;

      Talent talent = ClientProfile.talent();
      boolean awake = awakened();

      if (!confirming) {
         y = HxhUi.wrap(g, this.font, awake
            ? "Kite looks at you for a moment, and nods."
            : "Kite studies you in silence. You feel like he can see straight through you.", tx, y, tw, HxhUi.TEXT_DIM);
         y += 6;
         if (awake) { // talent is only rolled when the nodes open, so before that Kite has nothing to say about it
            y = HxhUi.wrap(g, this.font, "\"" + talent.kiteLine + "\"", tx, y, tw, talent.color);
            y += 14; // just Kite's line: the actual talent tier is never shown
         } else {
            y += 8;
         }
         HxhUi.rule(g, tx, y - 6, tw);
         if (awake) {
            y = HxhUi.wrap(g, this.font, "Your nodes are open. Craft a Water Divination glass, place it down, fill it from a water bucket and float a leaf on it, and it will show you what kind of Nen you have.", tx, y, tw, HxhUi.TEXT);
            y += 4;
            HxhUi.wrap(g, this.font, "If you want to understand what you are doing with it, ask. I will teach you everything I can.", tx, y, tw, HxhUi.TEXT);
         } else {
            y = HxhUi.wrap(g, this.font, "Your aura is sealed. It would open on its own in time, but I can force the nodes open now.", tx, y, tw, HxhUi.TEXT);
            y += 4;
            HxhUi.wrap(g, this.font, "It is not gentle, and you will not be able to move while it happens. Once they are open they stay open. Shall I?", tx, y, tw, HxhUi.TEXT);
         }
      } else {
         y = HxhUi.wrap(g, this.font, "\"Stand still, and face away from me. Do not fight it. When my hand is on your back, your aura will surge out of you.\"", tx, y, tw, HxhUi.TEXT);
         y += 8;
         HxhUi.wrap(g, this.font, "You will be held in place for about five seconds, and you cannot be hurt while it lasts.", tx, y, tw, HxhUi.GOLD);
      }
      super.render(g, mouseX, mouseY, partialTick);
   }

   public boolean isPauseScreen() {
      return false;
   }
}
