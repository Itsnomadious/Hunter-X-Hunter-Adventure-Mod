package net.hxhadventure.entity.client.Aura;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.AuraForm;
import net.hxhadventure.addon.GonVow;
import net.hxhadventure.addon.client.AuraForms;
import net.hxhadventure.abilities.CombatManager;

public class AuraLayerRenderer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
   public AuraLayerRenderer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> renderer) {
      super(renderer);
   }

   public void render(
      PoseStack poseStack,
      MultiBufferSource bufferSource,
      int packedLight,
      AbstractClientPlayer player,
      float limbSwing,
      float limbSwingAmount,
      float partialTicks,
      float ageInTicks,
      float netHeadYaw,
      float headPitch
   ) {
      LocalPlayer clientPlayer = Minecraft.getInstance().player;
      if (clientPlayer != null) {
         boolean hasNen = clientPlayer.getPersistentData().getBoolean("HxHCraft_NenUnlocked");
         if (!hasNen) {
            return;
         }
         // Right after spawning, the aura colour has not reached the client yet and would default to gold_orange, tinting the
         // whole body for a moment. Hold the aura back until the colour has synced (with a cap, so it can never stay hidden).
         if (player == clientPlayer && player.tickCount < 100 && !clientPlayer.getPersistentData().contains("HxHCraft_PermanentAuraColor")) {
            return;
         }
      }

      Combat stats = CombatManager.get(player);
      if (stats != null) {
         boolean renAttivo = stats.isAuraActive();
         boolean tenAttivo = stats.isTenActive();
         AuraForm form = renAttivo ? AuraForm.NONE : AuraForms.get(player.getId());
         boolean formAttiva = form != AuraForm.NONE;
         boolean vow = GonVow.clientHas(player.getId()); // Gon's adult form: darker, much more opaque colour
         float shade = vow ? 0.4F : 1.0F;
         // A form (Ken / Ko) is drawn with the Ten aura, sized and filled per zone, instead of the plain Ten glow.
         boolean deveRenderizzareTen = tenAttivo && !renAttivo && !formAttiva;
         if (renAttivo || deveRenderizzareTen || formAttiva) {
            String prefix = stats.getAuraPrefix(player);
            if (formAttiva) {
               // Forms use the Ten aura: same texture and glow, sized and filled per zone (see AuraForm).
               ResourceLocation formTexture = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/" + prefix + "aura_ten.png");
               VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucentEmissive(formTexture));
               PlayerModel<AbstractClientPlayer> model = this.getParentModel();
               zone(poseStack, consumer, vow, form.rightArm, false, model.rightArm, model.rightSleeve);
               zone(poseStack, consumer, vow, form.leftArm, false, model.leftArm, model.leftSleeve);
               zone(poseStack, consumer, vow, form.torso, false, model.body, model.jacket, model.head, model.hat);
               zone(poseStack, consumer, vow, form.legs, true, model.rightLeg, model.rightPants, model.leftLeg, model.leftPants);
            }
            if (deveRenderizzareTen) {
               ResourceLocation tenTexture = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/" + prefix + "aura_ten.png");
               VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucentEmissive(tenTexture));
               poseStack.pushPose();
               poseStack.scale(1.1F, 1.0F, 1.2F);
               ((PlayerModel)this.getParentModel()).renderToBuffer(poseStack, consumer, 15728880, OverlayTexture.NO_OVERLAY, shade, shade, shade, vow ? 0.9F : 0.6F);
               poseStack.popPose();
            }

            // Ren has no body overlay: the flame (AuraEntityRenderer / FlameAura) is the whole aura.
         }
      }
   }

   /** Ten's own scale (see the Ten branch above); a zone's size is a multiple of it, so size 1.0 looks exactly like Ten. */
   private static final float TEN_X = 1.1F, TEN_Z = 1.2F;
   /** Ten's opacity; a zone's power raises it towards fully opaque. */
   private static final float TEN_ALPHA = 0.6F;
   /** Ren body glow: 0.6 before, 30% more transparent now. */
   private static final float REN_ALPHA = 0.6F * 0.7F;
   /** Ken / Ko aura density: 0.7 = 30% less opaque than before (applies to the finished, stacked result, not just one layer). */
   private static final float FORM_OPACITY = 0.7F;

   /**
    * Draws one zone (some body parts) with the Ten aura. size: 1.0 = Ten's size, never more than AuraForm.MAX_SIZE.
    * power: 0 = Ten's faintness, 1 = deepest colour (a stronger first pass plus up to 3 more layers on top).
    * Parts are scaled about their own joint; legs keep their height so the aura never sinks into the floor.
    */
   private static void zone(PoseStack poseStack, VertexConsumer consumer, boolean vow, AuraForm.Zone z, boolean keepHeight, ModelPart... parts) {
      if (z.size() <= 0.0F) {
         return;
      }

      float size = Math.min(z.size(), AuraForm.MAX_SIZE);
      float power = Math.max(0.0F, Math.min(1.0F, z.power()));
      float sx = TEN_X * size;
      float sz = TEN_Z * size;
      float sy = keepHeight ? 1.0F : 1.0F + (size - 1.0F) * 0.5F;
      float firstAlpha = TEN_ALPHA + (1.0F - TEN_ALPHA) * power;
      // Extra fully-opaque layers stacked on the first: 0 for a faint zone, 3 for a fully targeted one (colour gets much deeper).
      int extraLayers = Math.max(0, (int)Math.floor(power * 4.0F - 0.5F));
      // Stacked layers saturate to fully opaque, so scaling each layer's alpha by 0.7 would barely change a deep zone.
      // Instead take the opacity the stack used to reach (opaque once any extra layer exists), cut it by 30%, and spread
      // that over the same number of layers so the layered look is kept but the whole zone is 30% less dense.
      float oldCombined = extraLayers > 0 ? 1.0F : firstAlpha;
      float newCombined = vow ? 0.95F : oldCombined * FORM_OPACITY; // the vow keeps the layers dense instead of thinning them
      float shade = vow ? 0.4F : 1.0F;
      int layers = extraLayers + 1;
      float layerAlpha = 1.0F - (float)Math.pow(1.0F - newCombined, 1.0 / layers);
      for (ModelPart part : parts) {
         if (!part.visible) {
            continue;
         }

         poseStack.pushPose();
         float px = part.x / 16.0F;
         float py = part.y / 16.0F;
         float pz = part.z / 16.0F;
         poseStack.translate(px, py, pz);
         poseStack.scale(sx, sy, sz);
         poseStack.translate(-px, -py, -pz);
         for (int i = 0; i < layers; i++) {
            part.render(poseStack, consumer, 15728880, OverlayTexture.NO_OVERLAY, shade, shade, shade, layerAlpha);
         }
         poseStack.popPose();
      }
   }
}
