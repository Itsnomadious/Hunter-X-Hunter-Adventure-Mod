package net.hxhadventure.entity.client.Aura;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.hxhadventure.addon.GonVow;
import net.hxhadventure.entity.custom.AuraEntity;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class AuraEntityRenderer extends GeoEntityRenderer<AuraEntity> {
   public AuraEntityRenderer(Context renderManager) {
      super(renderManager, new AuraModel());
   }

   public RenderType getRenderType(AuraEntity animatable, ResourceLocation texture, @Nullable MultiBufferSource bufferSource, float partialTick) {
      return RenderType.beaconBeam(texture, true);
   }

   public void preRender(
      PoseStack poseStack,
      AuraEntity animatable,
      BakedGeoModel model,
      MultiBufferSource bufferSource,
      VertexConsumer buffer,
      boolean isRebind,
      float partialTick,
      int packedLight,
      int packedOverlay,
      float red,
      float green,
      float blue,
      float alpha
   ) {
      float dynamicScale = animatable.getAuraScale();
      float finalScale = 9.0F * dynamicScale;
      poseStack.scale(finalScale, finalScale, finalScale);
      float customAlpha = animatable.getAuraType() == 1 ? 0.35F : 0.96F;
      super.preRender(poseStack, animatable, model, bufferSource, buffer, isRebind, partialTick, packedLight, packedOverlay, red, green, blue, customAlpha);
   }

   protected void applyRotations(AuraEntity animatable, PoseStack poseStack, float ageInTicks, float rotationYaw, float partialTick) {
   }

   private boolean isRebind() {
      return false;
   }

   public void render(AuraEntity entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
      LivingEntity owner = entity.getOwner();
      if (owner instanceof net.hxhadventure.addon.LaplaceDoubleEntity && !net.hxhadventure.addon.client.LaplaceFx.showDouble(owner.getId())) return;
      // Ren is drawn as one procedural flame (see FlameAura): a near-sphere around the player that plumes upwards,
      // waving and ebbing. The old Geckolib aura model is no longer used for rendering.
      // Gon's adult form: the natural Nen colour is darker and much more opaque.
      boolean vow = owner != null && GonVow.clientHas(owner.getId());
      float shade = vow ? 0.4F : 1.0F;
      float opacity = vow ? 2.2F : 1.0F;
      // Your own flame in first person: you are inside it, so draw both faces but much fainter so it never hinders the view.
      Minecraft mcNow = Minecraft.getInstance();
      boolean firstPerson = owner != null && mcNow.player == owner && mcNow.options.getCameraType().isFirstPerson();
      if (firstPerson) opacity *= FlameAura.FIRST_PERSON_OPACITY;
      float time = (entity.tickCount + partialTick) / 20.0F;
      float seed = entity.getId() * 0.37F;
      poseStack.pushPose();
      poseStack.translate(0.0F, -0.1F, 0.0F); // the aura entity sits 0.1 above the feet
      float size = entity.getAuraScale(partialTick) * FlameAura.REN_BASE_SCALE;
      poseStack.scale(size, size * FlameAura.REN_HEIGHT_STRETCH * entity.getBarrierStretch(), size);
      VertexConsumer buffer = bufferSource.getBuffer(firstPerson ? FlameRenderType.flameInside() : FlameRenderType.flame());
      FlameAura.draw(poseStack, buffer, FlameAura.Style.REN, entity.getAuraColor(), time, seed, opacity, shade);
      poseStack.popPose();
   }

   public boolean shouldRender(AuraEntity animatable, Frustum camera, double camX, double camY, double camZ) {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && mc.player != null) {
         LocalPlayer clientPlayer = mc.player;
         boolean hasNen = clientPlayer.getPersistentData().getBoolean("HxHCraft_NenUnlocked");
         if (!hasNen) {
            return false;
         }
         // Any owned Ren flame (yours, other players', NPCs') skips frustum culling: the flame is far bigger than this
         // entity's tiny hitbox, so culling on the hitbox would make it pop out whenever the feet are off screen.
         if (animatable.getOwner() != null) {
            return animatable.shouldRender(camX, camY, camZ);
         }
      }
      return super.shouldRender(animatable, camera, camX, camY, camZ);
   }

   public ResourceLocation getTextureLocation(AuraEntity animatable) {
      String[] prefissi = new String[]{"gold_orange", "light_blue", "red", "dark_blue", "green", "purple", "pink", "white", "black", "yellow", "silver", "lime", "cyan", "coral", "teal", "grey", "forest", "maroon", "indigo", "midnight"};
      int index = animatable.getAuraColor();
      if (index < 0 || index >= prefissi.length) {
         index = 0;
      }

      String prefix = prefissi[index];
      String suffix = animatable.getAuraType() == 1 ? "aura_ten" : "aura";
      return ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/" + prefix + suffix + ".png");
   }
}
