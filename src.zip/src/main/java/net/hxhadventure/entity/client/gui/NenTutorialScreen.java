package net.hxhadventure.entity.client.gui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.hxhadventure.addon.Affinity;
import net.hxhadventure.addon.HatsuCatalog;
import net.hxhadventure.addon.Tuning;
import net.hxhadventure.abilities.Combat;

/**
 * Kite's lessons. One topic per page, picked from the list on the left; the text scrolls. In the text, a line starting with "# "
 * is a sub-heading, "- " is a bullet, anything else is a paragraph. Numbers are read from Tuning so the lessons stay true.
 */
public class NenTutorialScreen extends Screen {
   private record Section(String title, List<String> lines) {}

   private final Screen parent;
   private final List<Section> sections = buildSections();
   private int selected;
   private int scroll;
   private int contentHeight;
   private int px, py, pw, ph, listW, textX, textY, textW, textH;

   public NenTutorialScreen(Screen parent) {
      super(Component.literal("Nen Lessons"));
      this.parent = parent;
   }

   protected void init() {
      super.init();
      // a big panel: nearly the whole window, so the topic list, the Back button and the lesson text never crowd each other
      pw = Math.min(600, this.width - 16);
      ph = Math.min(380, this.height - 16);
      px = (this.width - pw) / 2;
      py = (this.height - ph) / 2;
      listW = Math.max(100, Math.min(140, pw / 4));
      int n = sections.size();
      int gap = 3;
      int backH = 20;
      int listTop = py + 42;
      int listBottom = py + ph - 14 - backH - 8; // leaves a clear strip above the Back button
      int bh = Math.max(12, Math.min(20, (listBottom - listTop - gap * (n - 1)) / n));
      for (int i = 0; i < n; i++) {
         final int idx = i;
         this.addRenderableWidget(HxhUi.button(px + 14, listTop + i * (bh + gap), listW, bh, sections.get(i).title(), b -> {
            selected = idx;
            scroll = 0;
            this.rebuildWidgets();
         }, i == selected));
      }
      this.addRenderableWidget(HxhUi.button(px + 14, py + ph - 14 - backH, listW, backH, "Back", b -> Minecraft.getInstance().setScreen(parent), false));
      textX = px + 14 + listW + 18;
      textY = py + 46;
      textW = pw - (textX - px) - 26;
      textH = ph - 46 - 20;
   }

   public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
      HxhUi.backdrop(g, this.width, this.height);
      HxhUi.panel(g, px, py, pw, ph);
      HxhUi.title(g, this.font, "KITE'S LESSONS", px + pw / 2, py + 14);
      HxhUi.subtitle(g, this.font, "Everything about Nen, one topic at a time", px + pw / 2, py + 27);
      HxhUi.inset(g, textX - 6, textY - 4, textW + 12, textH + 8);

      Section s = sections.get(selected);
      // measure first, so the scroll can be clamped and the bar sized
      int h = 16 + 8;
      for (String line : s.lines()) h += lineHeight(line);
      contentHeight = h;
      scroll = Math.max(0, Math.min(scroll, Math.max(0, contentHeight - textH)));

      g.enableScissor(textX - 4, textY - 2, textX + textW + 4, textY + textH + 2);
      int y = textY - scroll;
      g.drawString(this.font, s.title(), textX, y, HxhUi.GOLD, false);
      HxhUi.rule(g, textX, y + 11, textW);
      y += 20;
      for (String line : s.lines()) y = drawLine(g, line, y);
      g.disableScissor();

      if (contentHeight > textH) { // scroll bar
         int trackX = textX + textW + 2;
         int barH = Math.max(14, textH * textH / contentHeight);
         int barY = textY + (int) ((textH - barH) * (scroll / (float) (contentHeight - textH)));
         g.fill(trackX, textY, trackX + 2, textY + textH, HxhUi.INSET_LINE);
         g.fill(trackX, barY, trackX + 2, barY + barH, HxhUi.GOLD);
      }
      super.render(g, mouseX, mouseY, partialTick);
   }

   private int lineHeight(String line) {
      if (line.startsWith("# ")) return 8 + HxhUi.LINE_H + 2;
      if (line.startsWith("- ")) return HxhUi.wrapHeight(this.font, line.substring(2), textW - 10) + 2;
      return HxhUi.wrapHeight(this.font, line, textW) + 4;
   }

   private int drawLine(GuiGraphics g, String line, int y) {
      if (line.startsWith("# ")) {
         g.drawString(this.font, line.substring(2), textX, y + 8, HxhUi.GREEN, false);
         return y + 8 + HxhUi.LINE_H + 2;
      }
      if (line.startsWith("- ")) {
         g.fill(textX + 2, y + 4, textX + 5, y + 7, HxhUi.GOLD);
         return HxhUi.wrap(g, this.font, line.substring(2), textX + 10, y, textW - 10, HxhUi.TEXT) + 2;
      }
      return HxhUi.wrap(g, this.font, line, textX, y, textW, HxhUi.TEXT) + 4;
   }

   public boolean mouseScrolled(double mx, double my, double delta) {
      scroll -= (int) (delta * 14);
      scroll = Math.max(0, Math.min(scroll, Math.max(0, contentHeight - textH)));
      return true;
   }

   public void onClose() {
      Minecraft.getInstance().setScreen(parent);
   }

   public boolean isPauseScreen() {
      return false;
   }

   // =====================================================================================================
   // the lessons
   // =====================================================================================================

   private static String pct1(float f) {
      return String.format(java.util.Locale.ROOT, "%.1f%%", f * 100f);
   }

   private static String pct(float f) {
      return Math.round(f * 100f) + "%";
   }

   private static List<Section> buildSections() {
      List<Section> out = new ArrayList<>();

      out.add(new Section("The Basics", List.of(
         "Nen is the power of your own life energy, called aura. Everyone has it. Most people leak it away without ever noticing. Once your aura nodes are open you can shape it and use it.",
         "# Your level",
         "Nen has a level from 1 to " + Combat.MAX_LEVEL + ". You gain experience by defeating creatures. The higher your level, the stronger your hits, the larger your aura, and the more techniques you unlock.",
         "- Novice: from level 1.",
         "- Great: from level 20.",
         "- Excellent: from level 40.",
         "- Genius: from level 60.",
         "- Ultimate: level 100.",
         "Each step up in grade makes new experience come in more slowly, so the last levels are the hardest.",
         "# Talent",
         "Everyone is born with a different amount of natural talent. The more rare your talent, the faster all of your Nen experience comes in, both for your level and for each of your skills.",
         "# Your aura",
         "Your aura is a pool. You start with about " + (int) Tuning.maxNen(1, 1, 1) + ". Max aura grows with your level and with your Ten and Ren skills, and it grows faster the stronger you get: about " + (int) Tuning.maxNen(60, 60, 60) + " at level 60 with Ten and Ren at 60, and about " + (int) Tuning.maxNen(100, 100, 100) + " at level 100 with both at 100.",
         "Most techniques cost aura. Some cost it every second you keep them going. When it runs out, Ren and every aura form shut off, and techniques stop working until it comes back.",
         "# Keys",
         "Every Nen key can be found and changed in the Controls menu, under HxHAdventure."
      )));

      out.add(new Section("Ten", List.of(
         "Ten is the first and most important technique. You wrap your aura around your body so it stops leaking away.",
         "# What it does",
         "- Raises your damage and your durability by " + pct(Tuning.tenBonus(1)) + " at Ten 1, growing to " + pct(Tuning.tenBonus(100)) + " at Ten 100.",
         "- Makes you faster: +" + pct(Tuning.tenSpeedBonus(1)) + " at Ten 1, about +" + pct(Tuning.tenSpeedBonus(100)) + " at Ten 100, and gives you Jump Boost.",
         "- Refills your aura, far faster than with Ten off. Your Ten skill makes it faster still.",
         "- Hides nothing. Anyone who can sense Nen can sense you.",
         "# Cost",
         "Ten costs no aura to hold. You should have it on whenever you are not doing something else with your aura.",
         "Turning Ten on breaks Zetsu."
      )));

      out.add(new Section("Zetsu", List.of(
         "Zetsu is the opposite of Ten. You shut your aura nodes completely and your presence vanishes.",
         "# What it does",
         "- Creatures that have not noticed you will not notice you until you are within a few blocks. At level 1 that is " + (int) Tuning.zetsuStealthRange(1) + " blocks, shrinking as your Zetsu skill grows.",
         "- Refills your aura far faster than Ten does, including " + String.format("%.1f", Tuning.ZETSU_REGEN_PCT * 100f) + "% of your maximum every second.",
         "- Hides you from En, except at close range.",
         "# The price",
         "- You take extra damage while in Zetsu: " + pct(Tuning.zetsuDamagePenalty(1)) + " more at Zetsu 1, less as the skill grows.",
         "- You cannot use techniques. Turning Ten or Ren on breaks Zetsu at once.",
         "Zetsu is for hiding, resting and recovering. It is not for fighting."
      )));

      out.add(new Section("Ren", List.of(
         "Ren pours out as much aura as you can. It is loud, it is bright, and it makes you far more dangerous.",
         "# What it does",
         "- Doubles everything Ten gives you: damage, durability and speed.",
         "- Shows your aura around you, in your aura colour. Only people with Nen of their own can see it.",
         "- Can be made bigger or smaller with the Ren size slider on the Mastery screen. How big it can get depends on your Ren skill: it grows a little every 20 levels up to 3 times normal size at level 100, and past level 100 it keeps growing, by 1 times normal size every 10 levels.",
         "# Cost",
         "Ren drains " + pct1(Tuning.REN_UPKEEP_PCT) + " of your max aura every second. Your Ren skill gives some of that back as it grows. When your aura hits zero, Ren shuts off.",
         "Ren unlocks at level " + Tuning.REN_MIN_HATSU_LEVEL + "."
      )));

      out.add(new Section("Ken and Ko", List.of(
         "These are the two aura forms. Each one moves your aura somewhere specific instead of spreading it evenly. Only one form can be active at a time, and a form replaces Ren. Ken and Ko unlock at level " + Tuning.FORM_MIN_HATSU_LEVEL + ". Switching between Ren, Ken and Ko takes half a second, and gets shorter as your total Nen mastery (the average level of all your Nen skills) grows, until it is instant when every skill is at level 100.",
         "# Ken",
         "You wrap a thick layer of aura around your whole body. It is a defensive stance.",
         "- Cuts the damage you take. At level 1 it blocks " + pct(Tuning.kenDefence(1)) + ", and it blocks more as your skill grows.",
         "- Your own attacks do a little less damage while it is up.",
         "- Costs " + pct1(Tuning.KEN_UPKEEP_PCT) + " of your max aura per second.",
         "# Ko",
         "You gather nearly all of your aura into one limb, for one devastating hit.",
         "- Your hits do far more damage.",
         "- Everything else is left bare: you take " + pct(Tuning.KO_INCOMING_MULT - 1f) + " extra damage.",
         "- Costs " + pct1(Tuning.KO_UPKEEP_PCT) + " of your max aura per second.",
         "Ken and Ko take their strength from your Ten skill."
      )));

      out.add(new Section("En", List.of(
         "En stretches your aura out around you like a net, so you can feel everything that moves inside it.",
         "# What it does",
         "- Lets you sense creatures and people inside your radius, even through walls.",
         "- The radius starts at " + (int) Tuning.EN_BASE_RADIUS + " blocks and grows with your En skill: " + (int) Tuning.EN_FREE_RADIUS + " blocks at En " + Tuning.EN_FREE_LEVEL + ", then up to a maximum of " + (int) Tuning.EN_MAX_RADIUS + " blocks at En 100.",
         "- You can choose a smaller radius with the En slider on the Mastery screen.",
         "# Cost",
         "Keeping En up to " + (int) Tuning.EN_FREE_RADIUS + " blocks costs " + (int) Tuning.enUpkeep(Tuning.EN_FREE_RADIUS, 1) + " aura per second. Beyond that the cost climbs quickly, to " + (int) Tuning.enUpkeep(100f, 1) + " per second at 100 blocks and about " + (int) Tuning.enUpkeep(200f, 1) + " per second at 200.",
         "# Who it cannot see",
         "- People in Zetsu, beyond a few blocks.",
         "- People using In, if their In level is high enough compared to your En level.",
         "En unlocks at level " + Tuning.EN_MIN_HATSU_LEVEL + "."
      )));

      out.add(new Section("In and Gyo", List.of(
         "In and Gyo are two halves of the same idea: hiding Nen, and seeing hidden Nen. Both unlock at level " + Tuning.IN_MIN_HATSU_LEVEL + ".",
         "# In",
         "You hide your aura and your techniques so they cannot be seen.",
         "- Makes you invisible to En, if your In level is high enough compared to the user's En level.",
         "- Hides your Hatsu while it is out, such as chains or gum threads.",
         "- Costs " + (int) Tuning.IN_UPKEEP + " aura per second.",
         "At In level " + Tuning.IN_VISIBILITY_LEVEL + " you can choose to show your Nen again while In is up.",
         "# Gyo",
         "You gather aura into your eyes. You can then see Nen that is hidden by In, and read how skilled someone is.",
         "- Shows hidden techniques.",
         "- Lets you read the grade of someone you look at, up to the grade of your own Gyo, within " + (int) Tuning.GYO_RANGE + " blocks.",
         "- Costs " + (int) Tuning.GYO_UPKEEP + " aura per second."
      )));

      List<String> types = new ArrayList<>();
      types.add("Every person has one of six Nen types. Your type decides what you are naturally good at, and which Hatsu you can learn. It stays with you. Only losing your Nen completely, or having your nodes closed, lets Kite open them again and roll a new one.");
      for (int t = 1; t <= 6; t++) {
         types.add("# " + Affinity.name(t));
         types.add(Affinity.describe(t) + ".");
      }
      types.add("# Which type is yours?");
      types.add("You are given one when your aura nodes open, but nobody tells you which. You find out with Water Divination.");
      out.add(new Section("Nen Types", types));

      out.add(new Section("Water Divination", List.of(
         "Water Divination is the ritual that shows you what Nen type you have. You can only do it once your aura nodes are open.",
         "# What you need",
         "- A Water Divination glass. Craft it from five glass blocks in a U shape (glass in the left and right of the top two rows, and the whole bottom row).",
         "- A water bucket.",
         "- A leaf block (any kind).",
         "# How to do it",
         "- Place the glass down. It starts empty.",
         "- Right-click it with the water bucket to fill it.",
         "- Right-click it with a leaf block. A leaf floats onto the water.",
         "- Right-click it again to use it.",
         "- Send your aura into the water. The glass shows you your Nen type.",
         "# After you know",
         "Your type is now known. The same glass is where you choose your Hatsu."
      )));

      out.add(new Section("Hatsu", List.of(
         "Hatsu is your own personal technique: the thing that makes you different from every other Nen user. It is the core of how you fight.",
         "# Choosing one",
         "- First, learn your Nen type with Water Divination.",
         "- You need to be level " + HatsuCatalog.MIN_LEVEL + " or higher.",
         "- The menu on the glass shows only the Hatsu that belong to your type. You cannot see the others.",
         "- Pick one. Your Hatsu is then set.",
         "# Changing it",
         "You can change your Hatsu later, but only once your level has risen by " + HatsuCatalog.CHANGE_EVERY_LEVELS + " since you last chose. Whatever you had out is dismissed when you change.",
         "# Using it",
         "Your ability key (Z by default) uses your Hatsu. Some Hatsu have several abilities, and some need the key held down to charge. Each technique has a level it unlocks at and costs aura to use."
      )));

      out.add(new Section("Fighting", List.of(
         "You always have three basic attacks, with or without Nen.",
         "# Attack",
         "A quick punch. Damage 3 before bonuses. 1 second cooldown.",
         "# Strong attack",
         "Hold to charge, release to hit. A full charge does 15 damage, reaches further and knocks the target back hard. You move slowly while you charge. 1 second cooldown.",
         "# Barrage",
         "A rapid flurry of punches, each doing 1.5 damage before bonuses. Good for keeping pressure on, but each punch is weak on its own. 1 second cooldown.",
         "# Bonuses",
         "All of these are multiplied by a bonus that grows with your level, and by more again while Ren is up. Aura forms change it too: Ken lowers your damage, Ko raises it a lot.",
         "Your Nen type adds to it as well. For example Enhancers do 15% more damage."
      )));

      out.add(new Section("Mastery", List.of(
         "Besides your level, each part of Nen has its own skill, which grows as you use it.",
         "# Skills",
         "- Ten, Zetsu, Ren, En, Hatsu, In and Gyo each have their own level from 1 to " + 100 + ".",
         "- A skill grows as you use it.",
         "- A higher skill makes that technique stronger, cheaper or both.",
         "- Hatsu skill also makes every Hatsu ability hit harder: about +" + Math.round(Tuning.hatsuDamageBonus(100) * 100f) + "% damage at level 100.",
         "# The Mastery screen",
         "Open it from its key to see every skill, how close it is to the next level, your Nen type and your grade. It also holds the En and Ren size sliders.",
         "# Advice",
         "Do not rush. Train Ten first, then Ren and Zetsu. A Nen user who has mastered the basics will beat one with a flashy Hatsu and nothing underneath it."
      )));

      return out;
   }
}
