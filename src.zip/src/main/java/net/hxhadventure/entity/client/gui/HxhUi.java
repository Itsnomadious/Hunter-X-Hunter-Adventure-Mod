package net.hxhadventure.entity.client.gui;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

/**
 * The look shared by every HxHAdventure menu: a dark panel with gold trim, gold titles, quiet body text and square buttons that
 * light up gold. Screens call these helpers instead of drawing their own widgets, so they all match.
 */
public final class HxhUi {
    private HxhUi() {}

    public static final int DIM = 0xB0050608;
    public static final int PANEL = 0xF0101418;
    public static final int INSET = 0xFF161B21;
    public static final int INSET_LINE = 0xFF2A323B;
    public static final int GOLD = 0xFFD4AF37;
    public static final int GOLD_DIM = 0xFF7A6628;
    public static final int TEXT = 0xFFE8E4D8;
    public static final int TEXT_DIM = 0xFF9A968A;
    public static final int GREEN = 0xFF4FBF7A;
    public static final int RED = 0xFFD2524C;
    public static final int LINE_H = 10;

    public static void backdrop(GuiGraphics g, int w, int h) {
        g.fill(0, 0, w, h, DIM);
    }

    /** The main panel: gold border, a thin inner rule, and a small gold stud in each corner. */
    public static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, GOLD_DIM);
        g.fill(x, y, x + w, y + h, PANEL);
        frame(g, x + 4, y + 4, w - 8, h - 8, GOLD_DIM);
        for (int cx : new int[] {x + 2, x + w - 5}) {
            for (int cy : new int[] {y + 2, y + h - 5}) g.fill(cx, cy, cx + 3, cy + 3, GOLD);
        }
    }

    /** A recessed box for content. */
    public static void inset(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, INSET_LINE);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, INSET);
    }

    public static void frame(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    /** A centred gold title with a rule on each side. */
    public static void title(GuiGraphics g, Font font, String text, int cx, int y) {
        int tw = font.width(text);
        g.drawString(font, text, cx - tw / 2, y, GOLD, false);
        g.fill(cx - tw / 2 - 46, y + 4, cx - tw / 2 - 8, y + 5, GOLD_DIM);
        g.fill(cx + tw / 2 + 8, y + 4, cx + tw / 2 + 46, y + 5, GOLD_DIM);
    }

    public static void subtitle(GuiGraphics g, Font font, String text, int cx, int y) {
        g.drawCenteredString(font, text, cx, y, TEXT_DIM);
    }

    /** A thin gold rule. */
    public static void rule(GuiGraphics g, int x, int y, int w) {
        g.fill(x, y, x + w, y + 1, GOLD_DIM);
    }

    /** Draws wrapped text; returns the y below the last line. */
    public static int wrap(GuiGraphics g, Font font, String text, int x, int y, int width, int color) {
        List<FormattedCharSequence> lines = font.split(Component.literal(text), width);
        for (FormattedCharSequence line : lines) {
            g.drawString(font, line, x, y, color, false);
            y += LINE_H;
        }
        return y;
    }

    public static int wrapHeight(Font font, String text, int width) {
        return font.split(Component.literal(text), width).size() * LINE_H;
    }

    /** The one button style. {@code accent} draws it gold (the main choice). */
    public static class HxhButton extends Button {
        private final boolean accent;

        public HxhButton(int x, int y, int w, int h, Component msg, Button.OnPress press, boolean accent) {
            super(x, y, w, h, msg, press, DEFAULT_NARRATION);
            this.accent = accent;
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            boolean hover = this.active && this.isHoveredOrFocused();
            int bg = !this.active ? 0xFF14181C : hover ? 0xFF2B3440 : 0xFF1B2128;
            int border = !this.active ? 0xFF3A3A3A : (hover || accent) ? GOLD : GOLD_DIM;
            int text = !this.active ? 0xFF6A6A6A : hover ? 0xFFFFE9A8 : accent ? GOLD : TEXT;
            g.fill(getX(), getY(), getX() + width, getY() + height, border);
            g.fill(getX() + 1, getY() + 1, getX() + width - 1, getY() + height - 1, bg);
            Font font = Minecraft.getInstance().font;
            net.hxhadventure.addon.client.UiText.drawFit(g, font, getMessage().getString(), getX() + 3, getY() + (height - 8) / 2, width - 6, text, true);
        }
    }

    public static HxhButton button(int x, int y, int w, int h, String label, Button.OnPress press, boolean accent) {
        return new HxhButton(x, y, w, h, Component.literal(label), press, accent);
    }
}
