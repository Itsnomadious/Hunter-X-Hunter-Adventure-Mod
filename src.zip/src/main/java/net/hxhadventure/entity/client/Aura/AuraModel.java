package net.hxhadventure.entity.client.Aura;

import net.minecraft.resources.ResourceLocation;
import net.hxhadventure.entity.custom.AuraEntity;
import software.bernie.geckolib.model.GeoModel;

public class AuraModel extends GeoModel<AuraEntity> {
   private static final ResourceLocation TEXTURE_DEFAULT = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/light_blueaura.png");
   private static final ResourceLocation TEXTURE_JAJANKEN = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/gold_orangeaura.png");
   private static final ResourceLocation TEXTURE_RED = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/redaura.png");
   private static final ResourceLocation TEXTURE_BLUE = ResourceLocation.fromNamespaceAndPath("hxhadventure", "textures/entity/dark_blueaura.png");

   public AuraModel() {
   }

   public ResourceLocation getModelResource(AuraEntity animatable) {
      return ResourceLocation.fromNamespaceAndPath("hxhadventure", "geo/aura.geo.json");
   }

   public ResourceLocation getTextureResource(AuraEntity animatable) {
      ResourceLocation color = null;
      switch (animatable.getAuraType()) {
         case 1:
            color = TEXTURE_JAJANKEN;
            break;
         case 2:
            color = TEXTURE_DEFAULT;
            break;
         case 3:
            color = TEXTURE_RED;
            break;
         case 4:
            color = TEXTURE_BLUE;
      }

      return color;
   }

   public ResourceLocation getAnimationResource(AuraEntity animatable) {
      return ResourceLocation.fromNamespaceAndPath("hxhadventure", "animations/aura.animation.json");
   }
}
