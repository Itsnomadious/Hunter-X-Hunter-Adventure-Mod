package net.hxhadventure.entity.client.gui;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.Affinity;
import net.hxhadventure.addon.HatsuCatalog;
import net.hxhadventure.addon.client.ClientProfile;
import net.hxhadventure.addon.network.AddonNetwork;
import net.hxhadventure.addon.network.PacketSelectHatsu;
import net.hxhadventure.addon.network.PacketSelectNenType;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketRequestNenRoll;

/**
 * The Nen water glass. First use: send your aura into the water and it shows your Nen type (once, for good; it cannot be
 * rerolled). After that it lists the Hatsu of your type only, and you choose one.
 */
public class WaterDivinationScreen extends Screen {
   private int px, py, pw, ph;
   private boolean seenRevealed;
   private boolean seenSelect;
   private int seenKit = -1;
   private int seenLevel = -1;
   /** The type had not been revealed when this screen opened, so the reveal gets its animation (per Nen type). */
   private final boolean playReveal;
   private boolean requested;
   private boolean animating;
   private boolean animationDone;
   private int animTick;
   private int idleTick;
   private final long seed;

   public WaterDivinationScreen() {
      super(Component.literal("Water Divination"));
      this.playReveal = !ClientProfile.revealed;
      Minecraft mc = Minecraft.getInstance();
      this.seed = mc.player == null ? 0L : mc.player.getUUID().getLeastSignificantBits() ^ mc.player.getUUID().getMostSignificantBits();
   }

   /** The result (type and Hatsu list) is shown once the type is revealed and its animation has played. */
   private boolean showResult() {
      return ClientProfile.revealed && !animating && !(playReveal && !animationDone);
   }

   private Combat combat() {
      Minecraft mc = Minecraft.getInstance();
      return mc.player == null ? null : Combat.get(mc.player);
   }

   protected void init() {
      super.init();
      pw = Math.min(600, this.width - 20);
      ph = Math.min(460, this.height - 20);
      if (showResult()) {
         Combat rc = combat();
         if (rc != null) {
            int need = optionsTopFor(rc.getNenType()) + 56 + 8;
            for (HatsuCatalog.Option o : HatsuCatalog.forType(rc.getNenType())) need += cardH(o) + 6;
            ph = Math.min(this.height - 20, Math.max(ph, need));
         }
      }
      px = (this.width - pw) / 2;
      py = (this.height - ph) / 2;
      Combat c = combat();
      seenRevealed = ClientProfile.revealed;
      seenSelect = ClientProfile.canSelectType;
      seenKit = c != null ? c.getCurrentKit() : -1;
      seenLevel = c != null ? c.getHatsuLevel() : -1;

      int bx = px + 16;
      int bw = pw - 32;
      int closeY = py + ph - 32;
      if (animating) {
         this.addRenderableWidget(HxhUi.button(bx, closeY - 28, bw, 22, "Skip", b -> finishAnimation(), false));
      } else if (!ClientProfile.revealed && ClientProfile.canSelectType) {
         if (!requested) {
            // game rule hxhnentypeselect: pick the type instead of sending aura into the water (3 x 2 grid)
            int gap = 6;
            int cw = (bw - gap * 2) / 3;
            int top = closeY - 28 - 2 * 22 - gap;
            for (int i = 0; i < 6; i++) {
               final int type = i + 1;
               int bxi = bx + (i % 3) * (cw + gap);
               int byi = top + (i / 3) * (22 + gap);
               this.addRenderableWidget(HxhUi.button(bxi, byi, cw, 22, Affinity.name(type), b -> {
                  requested = true;
                  AddonNetwork.sendToServer(new PacketSelectNenType(type));
                  this.rebuildWidgets();
               }, true));
            }
         }
      } else if (!ClientProfile.revealed) {
         if (!requested) {
            this.addRenderableWidget(HxhUi.button(bx, closeY - 28, bw, 22, "Send my aura into the water", b -> {
               requested = true;
               ModMessages.sendToServer(new PacketRequestNenRoll());
               this.rebuildWidgets();
            }, true));
         }
      } else if (c != null) {
         List<HatsuCatalog.Option> options = HatsuCatalog.forType(c.getNenType());
         int y = optionsTop();
         for (HatsuCatalog.Option o : options) {
            boolean current = c.getCurrentKit() == o.kit();
            boolean levelOk = c.getHatsuLevel() >= HatsuCatalog.MIN_LEVEL;
            String label = current ? "Chosen" : "Choose";
            var btn = HxhUi.button(px + pw - 16 - BUTTON_W - 8, y + (cardH(o) - 20) / 2, BUTTON_W, 20, label, b -> AddonNetwork.sendToServer(new PacketSelectHatsu(o.kit())), !current && levelOk);
            btn.active = levelOk && !current;
            this.addRenderableWidget(btn);
            y += cardH(o) + 6;
         }
      }
      this.addRenderableWidget(HxhUi.button(bx, closeY, bw, 20, "Close", b -> this.onClose(), false));
   }

   private static final int CARD_MIN_H = 46;
   private static final int BUTTON_W = 70;

   /** Height of the header box that shows the type name and its description (wrapped, so nothing overlaps). */
   private int headerH() {
      Combat c = combat();
      int type = c != null ? c.getNenType() : 0;
      return 8 + HxhUi.LINE_H + 4 + HxhUi.wrapHeight(this.font, Affinity.describe(type), pw - 52) + 8;
   }

   private int optionsTop() {
      return py + 40 + headerH() + 8;
   }

   private int optionsTopFor(int type) {
      return 40 + 8 + HxhUi.LINE_H + 4 + HxhUi.wrapHeight(this.font, Affinity.describe(type), pw - 52) + 8 + 8;
   }

   /** A card grows with its text, so a long blurb never runs into the next card or the button. */
   private int cardH(HatsuCatalog.Option o) {
      int textW = pw - 32 - 10 - BUTTON_W - 24;
      return Math.max(CARD_MIN_H, 31 + HxhUi.wrapHeight(this.font, o.blurb(), textW) + 8);
   }

   private void finishAnimation() {
      boolean wasReveal = playReveal && !animationDone;
      animating = false;
      animationDone = true;
      Combat c = combat();
      if (wasReveal && c != null && c.getNenType() >= 1) {
         popupType = c.getNenType();
         popupTick = 0;
      }
      this.rebuildWidgets();
   }

   /** The pop-up that names the Nen type once the water has finished reacting. */
   private int popupType;
   private int popupTick = -1;
   private static final int POPUP_TICKS = 120;

   private boolean popupActive() {
      return popupTick >= 0 && popupTick < POPUP_TICKS;
   }

   public boolean mouseClicked(double mx, double my, int button) {
      if (popupActive()) {
         popupTick = POPUP_TICKS; // a click dismisses it
         return true;
      }
      return super.mouseClicked(mx, my, button);
   }

   private void renderPopup(GuiGraphics g, float partialTick) {
      float t = popupTick + partialTick;
      float in = Math.min(1f, t / 8f);
      float out = Math.min(1f, (POPUP_TICKS - t) / 14f);
      float a = Math.max(0f, Math.min(in, out));
      int alpha = (int) (255 * a);
      if (alpha < 4) return;
      int color = typeColor(popupType);
      String label = "Your Nen type";
      String name = Affinity.name(popupType);
      float scale = 2.6f;
      int boxW = Math.max(this.font.width(label), Math.round(this.font.width(name) * scale)) + 60;
      int boxH = 24 + Math.round(8 * scale) + 22;
      int bx = (this.width - boxW) / 2;
      int by = (this.height - boxH) / 2;
      int bg = (Math.min(alpha, 0xE8) << 24) | 0x0A0D12;
      g.pose().pushPose();
      g.pose().translate(0, 0, 400);
      g.fill(bx - 1, by - 1, bx + boxW + 1, by + boxH + 1, (alpha << 24) | (HxhUi.GOLD & 0xFFFFFF));
      g.fill(bx, by, bx + boxW, by + boxH, bg);
      g.drawCenteredString(this.font, label, this.width / 2, by + 10, (alpha << 24) | 0xC8C4B8);
      g.pose().pushPose();
      g.pose().translate(this.width / 2f, by + 24, 0);
      g.pose().scale(scale, scale, 1f);
      g.drawCenteredString(this.font, name, 0, 0, (alpha << 24) | (color & 0xFFFFFF));
      g.pose().popPose();
      g.pose().popPose();
   }

   public void tick() {
      super.tick();
      idleTick++;
      if (popupTick >= 0 && popupTick < POPUP_TICKS) popupTick++;
      Combat c = combat();
      // the type has just been revealed by the server: play the reaction of the water before showing it
      if (playReveal && ClientProfile.revealed && !animating && !animationDone) {
         if (c != null && c.getNenType() >= 1) animating = true;
         else animationDone = true; // no type to show a reaction for: straight to the result
         animTick = 0;
         this.rebuildWidgets();
      }
      if (animating) {
         animTick++;
         DivinationAnimation.sounds(c != null ? c.getNenType() : 0, seed, animTick);
         if (animTick >= DivinationAnimation.DURATION) finishAnimation();
         return;
      }
      int kit = c != null ? c.getCurrentKit() : -1;
      int level = c != null ? c.getHatsuLevel() : -1;
      if (ClientProfile.revealed != seenRevealed || ClientProfile.canSelectType != seenSelect || kit != seenKit || level != seenLevel) this.rebuildWidgets();
   }

   public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
      HxhUi.backdrop(g, this.width, this.height);
      HxhUi.panel(g, px, py, pw, ph);
      int cx = px + pw / 2;
      HxhUi.title(g, this.font, "WATER DIVINATION", cx, py + 14);
      Combat c = combat();

      if (!showResult()) {
         HxhUi.subtitle(g, this.font, "A glass of water, and a leaf", cx, py + 28);
         int insetY = py + 44, insetH = ph - 44 - 74;
         HxhUi.inset(g, px + 16, insetY, pw - 32, insetH);
         // the glass is drawn big, with room above it for the thread of aura
         // the reaction spills out past the glass (streams, puddle, glow): leave room for it, and keep the text clear of it
         float byHeight = (insetH - 12) / (float) DivinationAnimation.TOTAL_H;
         float byWidth = (pw - 32) * 0.46f / DivinationAnimation.TOTAL_W;
         float scale = Math.max(0.8f, Math.min(3.2f, Math.min(byHeight, byWidth)));
         int gx = px + 16 + Math.round(DivinationAnimation.SIDE_PAD * scale) + 10;
         int gy = insetY + 6 + Math.round(DivinationAnimation.THREAD_H * scale);
         int tx = gx + Math.round((48 + DivinationAnimation.SIDE_PAD) * scale) + 18;
         int tw = px + pw - 28 - tx;
         int y = insetY + 14;
         if (animating) {
            int type = c != null ? c.getNenType() : 0;
            float t = animTick + partialTick;
            DivinationAnimation.render(g, type, seed, t, gx, gy, scale);
            String line = DivinationAnimation.caption(type, seed, t);
            HxhUi.wrap(g, this.font, line, tx, y, tw, typeColor(type));
         } else {
            DivinationAnimation.renderIdle(g, idleTick + partialTick, gx, gy, scale);
            if (requested) {
               HxhUi.wrap(g, this.font, "Your aura reaches for the water...", tx, y, tw, HxhUi.TEXT_DIM);
            } else if (ClientProfile.canSelectType) {
               y = HxhUi.wrap(g, this.font, "Hold the glass and send a thin thread of aura into the water. This time the leaf will answer to your will: choose the kind of Nen you want.", tx, y, tw, HxhUi.TEXT);
               y += 6;
               HxhUi.wrap(g, this.font, "You can only choose once. What you pick is permanent.", tx, y, tw, HxhUi.GOLD);
            } else {
               y = HxhUi.wrap(g, this.font, "Hold the glass and send a thin thread of aura into the water. The leaf will answer, and show you what kind of Nen you were born with.", tx, y, tw, HxhUi.TEXT);
               y += 6;
               HxhUi.wrap(g, this.font, "This can only be done once. What it shows you is permanent.", tx, y, tw, HxhUi.GOLD);
            }
         }
      } else if (c != null) {
         int type = c.getNenType();
         int color = typeColor(type);
         HxhUi.subtitle(g, this.font, "Your Nen type is shown", cx, py + 28);
         int headH = headerH();
         HxhUi.inset(g, px + 16, py + 40, pw - 32, headH);
         g.drawString(this.font, Affinity.name(type), px + 26, py + 40 + 8, color, false);
         HxhUi.wrap(g, this.font, Affinity.describe(type), px + 26, py + 40 + 8 + HxhUi.LINE_H + 4, pw - 52, HxhUi.TEXT_DIM);

         List<HatsuCatalog.Option> options = HatsuCatalog.forType(type);
         int y = optionsTop();
         for (HatsuCatalog.Option o : options) {
            boolean current = c.getCurrentKit() == o.kit();
            int ch = cardH(o);
            HxhUi.inset(g, px + 16, y, pw - 32, ch);
            if (current) HxhUi.frame(g, px + 16, y, pw - 32, ch, HxhUi.GOLD);
            g.drawString(this.font, o.name(), px + 26, y + 6, HxhUi.GOLD, false);
            g.drawString(this.font, "by " + o.owner(), px + 26, y + 18, HxhUi.TEXT_DIM, false);
            HxhUi.wrap(g, this.font, o.blurb(), px + 26, y + 31, pw - 32 - 10 - BUTTON_W - 24, HxhUi.TEXT);
            y += ch + 6;
         }
         String note;
         int noteColor;
         if (c.getHatsuLevel() < HatsuCatalog.MIN_LEVEL) {
            note = "You can choose your Hatsu at level " + HatsuCatalog.MIN_LEVEL + ". You are level " + c.getHatsuLevel() + ".";
            noteColor = HxhUi.RED;
         } else if (c.getCurrentKit() > 1 && c.getHatsuLevel() >= HatsuCatalog.FREE_CHANGE_LEVEL) {
            note = "From level " + HatsuCatalog.FREE_CHANGE_LEVEL + " you can change your Hatsu whenever you like.";
            noteColor = HxhUi.GREEN;
         } else if (c.getCurrentKit() > 1) {
            note = "You can change your Hatsu again once your level has risen by " + HatsuCatalog.CHANGE_EVERY_LEVELS + " since you last chose.";
            noteColor = HxhUi.TEXT_DIM;
         } else {
            note = "Choose your Hatsu. Only the ones that belong to your type are shown.";
            noteColor = HxhUi.GREEN;
         }
         HxhUi.wrap(g, this.font, note, px + 20, py + ph - 32 - 24, pw - 40, noteColor);
      }
      super.render(g, mouseX, mouseY, partialTick);
      if (popupActive()) renderPopup(g, partialTick);
   }

   /** A small glass of water with a leaf on it, drawn from rectangles. */
   private void glass(GuiGraphics g, int x, int y) {
      int w = 48;
      int h = 64;
      HxhUi.frame(g, x, y, w, h, 0xFFB8D8E8);
      g.fill(x + 1, y + 16, x + w - 1, y + h - 1, 0xC03C7FB0);
      g.fill(x + 1, y + 16, x + w - 1, y + 18, 0xFF7FC0E8);
      g.fill(x + 12, y + 12, x + 34, y + 20, 0xFF3F9A4A); // the leaf
      g.fill(x + 14, y + 10, x + 30, y + 12, 0xFF3F9A4A);
      g.fill(x + 10, y + 15, x + 36, y + 16, 0xFF2E7A38);
      g.fill(x + 8, y + h, x + w - 8, y + h + 3, 0xFFB8D8E8);
   }

   private static int typeColor(int type) {
      return switch (type) {
         case 1 -> 0xFF55FF55;
         case 2 -> 0xFFFFD700;
         case 3 -> 0xFF55FFFF;
         case 4 -> 0xFFA020F0;
         case 5 -> 0xFFFF8C00;
         case 6 -> 0xFFFF4444;
         default -> 0xFFFFFFFF;
      };
   }

   public boolean isPauseScreen() {
      return false;
   }
}
