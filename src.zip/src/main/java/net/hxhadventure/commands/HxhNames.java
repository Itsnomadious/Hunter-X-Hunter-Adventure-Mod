package net.hxhadventure.commands;

import com.mojang.brigadier.suggestion.SuggestionProvider;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;

/** Name lookups so the /hxh commands take words instead of ID numbers. */
public final class HxhNames {
    private HxhNames() {}

    /** Primary names (shown as tab-complete suggestions) -> kit id. */
    public static final Map<String, Integer> KITS = new LinkedHashMap<>();
    /** Extra spellings that are accepted but not suggested. */
    private static final Map<String, Integer> KIT_ALIASES = new LinkedHashMap<>();

    public static final Map<String, Integer> NEN_TYPES = new LinkedHashMap<>();
    public static final Map<String, Integer> AURA_COLOURS = new LinkedHashMap<>();
    private static final Map<String, Integer> AURA_ALIASES = new LinkedHashMap<>();

    /** Display names for nen types, indexed by id. */
    public static final String[] NEN_TYPE_LABELS = {"None", "Enhancement", "Transmutation", "Emission", "Conjuration", "Manipulation", "Specialization"};

    static {
        KITS.put("none", 0);
        KITS.put("kit1", 1);
        KITS.put("kit2", 2);
        KITS.put("chains", 8);
        KITS.put("skillhunter", 9);
        KITS.put("nerferpitou", 10);   // Doctor Blythe
        KITS.put("explosiveorbs", 11);
        KITS.put("dragonhead", 12);  // Zeno's Dragon's Head (formerly shown as Aura Blast)
        KITS.put("bungeegum", 13);   // Hisoka's Bungee Gum, transmuters only
        KITS.put("jajanken", 14);    // Gon's Jajanken, enhancers only
        KITS.put("needles", 15);     // Illumi's Needles, manipulators only
        KITS.put("lightningaura", 16); // Killua's Lightning Aura, transmuters only
        KITS.put("guanyin", 17);       // Netero's 100-Type Guanyin Bodhisattva, enhancers only
        KITS.put("paper", 18);         // Kalluto's Paper Manipulation, manipulators only
        KITS.put("hakoware", 19);      // Knuckle's Hakoware, conjurers only
        KITS.put("hideandseek", 20);   // Knov's Hide and Seek, emitters only
        KITS.put("painpacker", 21);    // Feitan's Pain Packer and Rising Sun, transmuters only
        KITS.put("rippercyclotron", 22); // Phinks's Ripper Cyclotron, enhancers only
        KITS.put("blackvoice", 23);    // Shalnark's Black Voice, manipulators only
        KITS.put("laplacedevil", 24);   // Tserriednich's Laplace Devil, specialists only
        KITS.put("nenstitches", 25);    // Machi's Nen Stitches, transmuters only
        KITS.put("blinky", 26);         // Shizuku's Blinky, conjurers only
        KITS.put("esthetician", 27);    // Biscuit Krueger's Magical Esthetician, transmuters only
        KITS.put("smoke", 28);          // Morel's Smoke Manipulation, manipulators only
        KITS.put("crazyslots", 29);     // Kite's Crazy Slots, conjurers only
        KITS.put("littleflower", 30);   // Genthru's Little Flower and Countdown, conjurers only
        KITS.put("bigbangimpact", 31);  // Uvogin's Big Bang Impact, enhancers only
        KIT_ALIASES.put("uvogin", 31);
        KIT_ALIASES.put("bigbang", 31);
        KIT_ALIASES.put("big_bang_impact", 31);
        KIT_ALIASES.put("genthru", 30);
        KIT_ALIASES.put("little_flower", 30);
        KIT_ALIASES.put("countdown", 30);
        KIT_ALIASES.put("bomber", 30);
        KIT_ALIASES.put("kite", 29);
        KIT_ALIASES.put("slots", 29);
        KIT_ALIASES.put("clown", 29);
        KIT_ALIASES.put("crazy_slots", 29);
        KIT_ALIASES.put("laplace", 24);
        KIT_ALIASES.put("tserriednich", 24);
        KIT_ALIASES.put("stitches", 25);
        KIT_ALIASES.put("machi", 25);
        KIT_ALIASES.put("nenthread", 25);
        KIT_ALIASES.put("shizuku", 26);
        KIT_ALIASES.put("biscuit", 27);
        KIT_ALIASES.put("morel", 28);
        KIT_ALIASES.put("deeppurple", 28);
        KIT_ALIASES.put("smokejail", 28);
        KIT_ALIASES.put("smokemanipulation", 28);
        KIT_ALIASES.put("magicalesthetician", 27);

        KIT_ALIASES.put("judgmentchain", 8); // old name
        KIT_ALIASES.put("neferpitou", 10);
        KIT_ALIASES.put("doctorblythe", 10);
        KIT_ALIASES.put("blythe", 10);
        KIT_ALIASES.put("orbs", 11);
        KIT_ALIASES.put("bungee", 13);
        KIT_ALIASES.put("gum", 13);
        KIT_ALIASES.put("hisoka", 13);
        KIT_ALIASES.put("gon", 14);
        KIT_ALIASES.put("rock", 14);
        KIT_ALIASES.put("zeno", 12);
        KIT_ALIASES.put("aurablast", 12);
        KIT_ALIASES.put("lightning", 16);
        KIT_ALIASES.put("killua", 16);
        KIT_ALIASES.put("illumi", 15);
        KIT_ALIASES.put("needle", 15);
        KIT_ALIASES.put("kalluto", 18);
        KIT_ALIASES.put("netero", 17);
        KIT_ALIASES.put("bodhisattva", 17);
        KIT_ALIASES.put("guanyinbodhisattva", 17);
        KIT_ALIASES.put("knuckle", 19);
        KIT_ALIASES.put("knuckleboom", 19);
        KIT_ALIASES.put("apr", 19);
        KIT_ALIASES.put("knov", 20);
        KIT_ALIASES.put("hideseek", 20);
        KIT_ALIASES.put("hide_and_seek", 20);
        KIT_ALIASES.put("feitan", 21);
        KIT_ALIASES.put("pain", 21);
        KIT_ALIASES.put("risingsun", 21);
        KIT_ALIASES.put("rising_sun", 21);
        KIT_ALIASES.put("pain_packer", 21);
        KIT_ALIASES.put("riper", 22);
        KIT_ALIASES.put("ripper", 22);
        KIT_ALIASES.put("rippercyclotron", 22);
        KIT_ALIASES.put("ripercyclotron", 22);
        KIT_ALIASES.put("cyclotron", 22);
        KIT_ALIASES.put("phinks", 22);
        KIT_ALIASES.put("shalnark", 23);
        KIT_ALIASES.put("black_voice", 23);
        KIT_ALIASES.put("phone", 23);
        KIT_ALIASES.put("chrollo", 9);
        KIT_ALIASES.put("kurapika", 8);
        KIT_ALIASES.put("papermanipulation", 18);

        NEN_TYPES.put("none", 0);
        NEN_TYPES.put("enhancer", 1);
        NEN_TYPES.put("transmuter", 2);
        NEN_TYPES.put("emitter", 3);
        NEN_TYPES.put("conjurer", 4);
        NEN_TYPES.put("manipulator", 5);
        NEN_TYPES.put("specialist", 6);

        AURA_COLOURS.put("gold", 1);
        AURA_COLOURS.put("lightblue", 2);
        AURA_COLOURS.put("red", 3);
        AURA_COLOURS.put("darkblue", 4);
        AURA_COLOURS.put("green", 5);
        AURA_COLOURS.put("purple", 6);
        AURA_COLOURS.put("pink", 7);
        AURA_COLOURS.put("white", 8);
        AURA_COLOURS.put("black", 9);
        AURA_COLOURS.put("yellow", 10);
        AURA_COLOURS.put("silver", 11);
        AURA_COLOURS.put("lime", 12);
        AURA_COLOURS.put("cyan", 13);
        AURA_COLOURS.put("coral", 14);
        AURA_COLOURS.put("teal", 15);
        AURA_COLOURS.put("grey", 16);
        AURA_COLOURS.put("forest", 17);
        AURA_COLOURS.put("maroon", 18);
        AURA_COLOURS.put("indigo", 19);
        AURA_COLOURS.put("midnight", 20);
        AURA_ALIASES.put("gray", 16);
        AURA_ALIASES.put("crimson", 18);
        AURA_ALIASES.put("aqua", 13);
        AURA_ALIASES.put("dark_green", 17);
        AURA_ALIASES.put("darkgreen", 17);
        AURA_ALIASES.put("gold_orange", 1);
        AURA_ALIASES.put("orange", 1);
        AURA_ALIASES.put("light_blue", 2);
        AURA_ALIASES.put("dark_blue", 4);
    }

    /** Name, alias, or the raw kit id number (only ids that belong to a listed kit are accepted). */
    public static Integer kit(String name) {
        String k = name.toLowerCase(Locale.ROOT);
        Integer id = KITS.get(k);
        if (id == null) id = KIT_ALIASES.get(k);
        if (id == null) {
            try {
                int n = Integer.parseInt(k);
                if (KITS.containsValue(n)) id = n;
            } catch (NumberFormatException ignored) { }
        }
        return id;
    }

    /** The primary name of a kit id, for messages. */
    public static String kitName(int id) {
        for (Map.Entry<String, Integer> e : KITS.entrySet()) if (e.getValue() == id) return e.getKey();
        return String.valueOf(id);
    }

    public static Integer nenType(String name) {
        return NEN_TYPES.get(name.toLowerCase(Locale.ROOT));
    }

    public static Integer auraColour(String name) {
        String k = name.toLowerCase(Locale.ROOT);
        Integer id = AURA_COLOURS.get(k);
        return id != null ? id : AURA_ALIASES.get(k);
    }

    public static SuggestionProvider<CommandSourceStack> suggest(Map<String, Integer> names) {
        List<String> list = List.copyOf(names.keySet());
        return (ctx, builder) -> SharedSuggestionProvider.suggest(list, builder);
    }
}
