package net.hxhadventure.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Collection;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.hxhadventure.addon.NenProfile;
import net.hxhadventure.addon.Talent;

/**
 * /hxh set talent &lt;common|oneinthousand|oneintenthousand|oneinhundredthousand|oneinmillion|oneintenmillion|oneinbillion|oneofakind&gt; [targets]
 * /hxh talent get [targets]
 */
public final class TalentCommand {
   private TalentCommand() {
   }

   public static LiteralArgumentBuilder<CommandSourceStack> node() {
      List<String> names = java.util.Arrays.stream(Talent.values()).map(t -> t.id).toList();
      return Commands.literal("talent")
         .requires(source -> source.hasPermission(2))
         .then(Commands.argument("tier", StringArgumentType.word())
            .suggests((ctx, b) -> SharedSuggestionProvider.suggest(names, b))
            .executes(ctx -> set(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException()), StringArgumentType.getString(ctx, "tier")))
            .then(Commands.argument("targets", EntityArgument.players())
               .executes(ctx -> set(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"), StringArgumentType.getString(ctx, "tier")))));
   }

   /** /hxh talent get [targets] */
   public static LiteralArgumentBuilder<CommandSourceStack> getNode() {
      return Commands.literal("talent")
         .requires(source -> source.hasPermission(2))
         .then(Commands.literal("get")
            .executes(ctx -> get(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException())))
            .then(Commands.argument("targets", EntityArgument.players())
               .executes(ctx -> get(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))));
   }

   private static int set(CommandSourceStack source, Collection<ServerPlayer> targets, String tierName) {
      Talent t = Talent.byId(tierName.toLowerCase());
      if (t == null) {
         source.sendFailure(Component.literal("Unknown talent '" + tierName + "'. Try: " + String.join(", ", java.util.Arrays.stream(Talent.values()).map(x -> x.id).toList())));
         return 0;
      }
      for (ServerPlayer p : targets) {
         NenProfile.setTalent(p, t);
         NenProfile.sync(p);
         source.sendSuccess(() -> Component.literal("Talent of " + p.getName().getString() + " set to " + t.label), true);
      }
      return targets.size();
   }

   private static int get(CommandSourceStack source, Collection<ServerPlayer> targets) {
      for (ServerPlayer p : targets) {
         Talent t = NenProfile.peekTalent(p);
         source.sendSuccess(() -> Component.literal(p.getName().getString() + ": " + (t != null ? t.label : "not rolled yet (rolls when their Nen awakens)")), false);
      }
      return targets.size();
   }
}
