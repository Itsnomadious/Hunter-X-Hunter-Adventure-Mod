package net.hxhadventure.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Collection;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.abilities.CombatManager;

/**
 * /hxh set nentype &lt;none|enhancer|transmuter|emitter|conjurer|manipulator|specialist&gt; [targets]
 * 
 */
public class SetNenTypeCommand {
   private SetNenTypeCommand() {
   }

   public static LiteralArgumentBuilder<CommandSourceStack> node() {
      return Commands.literal("nentype")
         .requires(source -> source.hasPermission(2))
         .then(
            Commands.argument("type", StringArgumentType.word())
               .suggests(HxhNames.suggest(HxhNames.NEN_TYPES))
               .executes(ctx -> run(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException()), StringArgumentType.getString(ctx, "type")))
               .then(
                  Commands.argument("targets", EntityArgument.players())
                     .executes(ctx -> run(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"), StringArgumentType.getString(ctx, "type")))
               )
         );
   }

   private static int run(CommandSourceStack source, Collection<ServerPlayer> targets, String typeName) {
      Integer type = HxhNames.nenType(typeName);
      if (type == null) {
         source.sendFailure(Component.literal("Unknown nen type '" + typeName + "'. Try: " + String.join(", ", HxhNames.NEN_TYPES.keySet())));
         return 0;
      }

      String label = HxhNames.NEN_TYPE_LABELS[type];
      for (ServerPlayer target : targets) {
         if (type == 0) {
            net.hxhadventure.addon.NenLoss.resetCharacter(target);
            source.sendSuccess(() -> Component.literal("Reset " + target.getName().getString() + " completely (restrictions, gratitude, levels, colour, talent, Nen type). They must awaken at Kite again."), true);
            continue;
         }
         Combat combat = CombatManager.get(target);
         combat.setNenType(type);
         target.sendSystemMessage(Component.literal("\u00a7bYour Nen-Type has been set to: \u00a76" + label));
         source.sendSuccess(() -> Component.literal("Nen-Type set to " + label + " for " + target.getName().getString()), true);
      }

      return targets.size();
   }
}
