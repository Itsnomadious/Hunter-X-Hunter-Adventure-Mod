package net.hxhadventure.commands;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.hxhadventure.addon.LittleFlower;
import net.hxhadventure.addon.NenSkillCommand;
import net.hxhadventure.addon.SkillHunter;

/**
 * The single root command. Everything lives under /hxh:
 * <pre>
 *   /hxh set skill &lt;kit&gt; [targets]
 *   /hxh set nentype &lt;type&gt; [targets]
 *   /hxh set auracolour &lt;colour&gt; [targets]
 *   /hxh set nenlevel &lt;level|ten|zetsu|ren|en|hatsu|all&gt; &lt;level&gt; [targets]
 *   /hxh set lifespan &lt;years&gt; [targets]      /hxh lifespan add &lt;years&gt; [targets]
 *   /hxh set gratitude &lt;count&gt; [targets]
 *   /hxh skillhunter answer &lt;uuid&gt;
 *   /hxh setcountdown &lt;seconds&gt;   (Countdown bombs planted from now on start at this many seconds at rest; 6000 = default)
 *   /hxh forceawaken [targets]
 *   /hxh remove restrictions [targets]   (removes every Condition, Limitation and Vow)
 *   /hxh exam stage &lt;0-3&gt; [targets]   (Hunter Exam progress, 3 = completed)
 *   /hxh set talent &lt;tier&gt; [targets]   (and /hxh talent get [targets])
 * </pre>
 */
public final class HxhCommand {
   private HxhCommand() {
   }

   public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
      dispatcher.register(
         Commands.literal("hxh")
            .then(Commands.literal("set")
               .requires(source -> source.hasPermission(2))
               .then(KitCommand.node("skill"))
               .then(SetNenTypeCommand.node())
               .then(SetAuraCommand.node())
               .then(NenSkillCommand.levelNode())
               .then(NenSkillCommand.setLifespanNode())
               .then(NenSkillCommand.gratitudeNode())
               .then(TalentCommand.node()))
            .then(NenSkillCommand.addLifespanNode())
            .then(TalentCommand.getNode())
            .then(SkillHunter.commandNode())
            .then(LittleFlower.commandNode())
            .then(ForceAwakenCommand.node())
            .then(DebugCommand.node())
            .then(RemoveRestrictionsCommand.node())
            .then(ExamCommand.node())
      );
   }
}
