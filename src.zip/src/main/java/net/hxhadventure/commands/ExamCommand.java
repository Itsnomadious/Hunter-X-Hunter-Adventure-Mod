package net.hxhadventure.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Collection;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.hxhadventure.addon.HunterExam;

/**
 * /hxh exam stage &lt;0-3&gt; [targets]: sets how far someone is in the Hunter Exam. 0 = not started, 1 = first test passed,
 * 2 = in between, 3 = completed (Hunter card; the O menu becomes the Hunter License). Without targets it is you.
 */
public final class ExamCommand {
   private ExamCommand() {
   }

   public static LiteralArgumentBuilder<CommandSourceStack> node() {
      return Commands.literal("exam")
         .requires(source -> source.hasPermission(2))
         .then(Commands.literal("stage")
            .then(Commands.argument("stage", IntegerArgumentType.integer(0, HunterExam.STAGE_DONE))
               .executes(ctx -> run(ctx.getSource(), java.util.List.of(ctx.getSource().getPlayerOrException()), IntegerArgumentType.getInteger(ctx, "stage")))
               .then(Commands.argument("targets", EntityArgument.players())
                  .executes(ctx -> run(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"), IntegerArgumentType.getInteger(ctx, "stage"))))));
   }

   private static int run(CommandSourceStack src, Collection<ServerPlayer> targets, int stage) {
      for (ServerPlayer p : targets) HunterExam.setStage(p, stage);
      src.sendSuccess(() -> Component.literal("Hunter Exam stage set to " + stage + " for " + targets.size() + " player(s)."), true);
      return targets.size();
   }
}
