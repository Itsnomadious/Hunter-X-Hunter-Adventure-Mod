package net.hxhadventure.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.hxhadventure.addon.NenAddonData;

/** /hxh debug: prints the state of your Nen (is the per-tick code running, what holds Ten down, skill levels and XP). Needs op. */
public final class DebugCommand {
   private DebugCommand() {
   }

   public static LiteralArgumentBuilder<CommandSourceStack> node() {
      return Commands.literal("debug").requires(src -> src.hasPermission(2)).executes(ctx -> {
         ServerPlayer sp = ctx.getSource().getPlayerOrException();
         for (String line : NenAddonData.get(sp).debugReport(sp)) {
            sp.sendSystemMessage(Component.literal("\u00a77[hxh debug] \u00a7f" + line));
         }
         return 1;
      });
   }
}
