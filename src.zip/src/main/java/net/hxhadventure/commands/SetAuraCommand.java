package net.hxhadventure.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Collection;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.hxhadventure.abilities.AbilityRegistry;

/** /hxh set auracolour &lt;colour&gt; [targets]: any name in HxhNames.AURA_COLOURS (21 colours) */
public class SetAuraCommand {
   private SetAuraCommand() {
   }

   public static LiteralArgumentBuilder<CommandSourceStack> node() {
      return Commands.literal("auracolour")
         .requires(source -> source.hasPermission(2))
         .then(
            Commands.argument("colour", StringArgumentType.word())
               .suggests(HxhNames.suggest(HxhNames.AURA_COLOURS))
               .executes(ctx -> run(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException()), StringArgumentType.getString(ctx, "colour")))
               .then(
                  Commands.argument("targets", EntityArgument.players())
                     .executes(ctx -> run(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"), StringArgumentType.getString(ctx, "colour")))
               )
         );
   }

   private static int run(CommandSourceStack source, Collection<ServerPlayer> targets, String colourName) {
      Integer colourId = HxhNames.auraColour(colourName);
      if (colourId == null) {
         source.sendFailure(Component.literal("Unknown aura colour '" + colourName + "'. Try: " + String.join(", ", HxhNames.AURA_COLOURS.keySet())));
         return 0;
      }

      for (ServerPlayer target : targets) {
         target.getPersistentData().putInt("HxHCraft_PermanentAuraColor", colourId);
         AbilityRegistry.updateActiveAuraColor(target);
         AbilityRegistry.syncAuraColor(target);
         source.sendSuccess(() -> Component.literal("Aura colour set to " + colourName.toLowerCase() + " for " + target.getName().getString()), true);
      }
      return targets.size();
   }
}
