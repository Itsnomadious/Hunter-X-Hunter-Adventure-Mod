package net.hxhadventure.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Collection;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.hxhadventure.addon.Vows;

/**
 * /hxh remove restrictions [targets]: removes every Nen Condition, Limitation and Vow the player has sworn (and their prayers),
 * completely. Needs permission level 2. Hina does the same thing through {@link Vows#removeAllRestrictions} (no op needed).
 */
public final class RemoveRestrictionsCommand {
   private RemoveRestrictionsCommand() {
   }

   public static LiteralArgumentBuilder<CommandSourceStack> node() {
      return Commands.literal("remove")
         .requires(source -> source.hasPermission(2))
         .then(Commands.literal("restrictions")
            .executes(ctx -> run(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException())))
            .then(Commands.argument("targets", EntityArgument.players())
               .executes(ctx -> run(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))));
   }

   private static int run(CommandSourceStack source, Collection<ServerPlayer> targets) {
      int done = 0;
      for (ServerPlayer p : targets) {
         int n = Vows.removeAllRestrictions(p);
         if (n > 0) {
            done++;
            p.sendSystemMessage(Component.literal("\u00a7dAll your Nen restrictions have been removed."));
            source.sendSuccess(() -> Component.literal("Removed " + n + " restriction(s) from " + p.getName().getString()), true);
         } else {
            source.sendFailure(Component.literal(p.getName().getString() + " has no Nen restrictions"));
         }
      }
      return done;
   }
}
