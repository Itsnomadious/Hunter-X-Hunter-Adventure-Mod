package net.hxhadventure.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Collection;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.hxhadventure.addon.NenAwakening;

/** /hxh forceawaken [targets]: awakens Nen straight away, without Kite's ritual. */
public final class ForceAwakenCommand {
   private ForceAwakenCommand() {
   }

   public static LiteralArgumentBuilder<CommandSourceStack> node() {
      return Commands.literal("forceawaken")
         .requires(source -> source.hasPermission(2))
         .executes(ctx -> run(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException())))
         .then(Commands.argument("targets", EntityArgument.players())
            .executes(ctx -> run(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"))));
   }

   private static int run(CommandSourceStack source, Collection<ServerPlayer> targets) {
      int done = 0;
      for (ServerPlayer p : targets) {
         if (NenAwakening.forceAwaken(p)) {
            done++;
            p.sendSystemMessage(Component.literal("\u00a76Your Nen has been awakened."));
            source.sendSuccess(() -> Component.literal("Awakened Nen for " + p.getName().getString()), true);
         } else {
            source.sendFailure(Component.literal(p.getName().getString() + " has already awakened Nen"));
         }
      }
      return done;
   }
}
