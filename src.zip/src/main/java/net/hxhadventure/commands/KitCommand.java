package net.hxhadventure.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Collection;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.hxhadventure.abilities.Combat;
import net.hxhadventure.addon.HatsuCatalog;
import net.hxhadventure.networking.ModMessages;
import net.hxhadventure.networking.PacketSyncKit;

/**
 * /hxh set skill &lt;kit&gt; [targets].
 * Every Hatsu has a name here (and the raw kit id works too), see {@link HxhNames}:
 * <pre>
 *   8 chains        9 skillhunter    10 nerferpitou (Doctor Blythe)   11 explosiveorbs   12 dragonhead
 *  13 bungeegum    14 jajanken       15 needles                       16 lightningaura   17 guanyin
 *  18 paper        19 hakoware       20 hideandseek                   21 painpacker (Pain Packer + Rising Sun)
 * </pre>
 * Plus none, kit1 and kit2. The Nen type still has to fit the Hatsu (the same check the Water Divination menu has).
 */
public class KitCommand {
   private KitCommand() {
   }

   public static LiteralArgumentBuilder<CommandSourceStack> node(String literal) {
      return Commands.literal(literal)
         .requires(source -> source.hasPermission(2))
         .then(
            Commands.argument("kit", StringArgumentType.word())
               .suggests(HxhNames.suggest(HxhNames.KITS))
               .executes(ctx -> run(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException()), StringArgumentType.getString(ctx, "kit")))
               .then(
                  Commands.argument("targets", EntityArgument.players())
                     .executes(ctx -> run(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"), StringArgumentType.getString(ctx, "kit")))
               )
         );
   }

   private static int run(CommandSourceStack source, Collection<ServerPlayer> targets, String kitName) {
      Integer id = HxhNames.kit(kitName);
      if (id == null) {
         source.sendFailure(Component.literal("Unknown kit '" + kitName + "'. Try: " + String.join(", ", HxhNames.KITS.keySet())));
         return 0;
      }

      int successCount = 0;
      for (ServerPlayer targetPlayer : targets) {
         Combat combat = Combat.get(targetPlayer);
         if (combat == null) {
            continue;
         }
         int type = combat.getNenType();
         if (id > 2 && HatsuCatalog.find(type, id) == null) {
            String label = type >= 0 && type < HxhNames.NEN_TYPE_LABELS.length ? HxhNames.NEN_TYPE_LABELS[type] : "unknown";
            source.sendFailure(Component.literal("Can't give " + HxhNames.kitName(id) + " to " + targetPlayer.getName().getString()
               + ": it does not fit their Nen type (" + label + "). Change it first with /hxh set nentype <type>."));
            continue;
         }
         // what the old Hatsu had out in the world goes
         if (combat.getCurrentKit() != id) HatsuCatalog.clearAll(targetPlayer, combat);
         if (combat.setKit(id)) {
            // the licence screen shows the Hatsu by its text, so keep that in step with the kit
            String text = HatsuCatalog.textFor(id);
            if (text != null) targetPlayer.getPersistentData().putString("HxHCraft_HatsuAbility", text);
            else if (id <= 2) targetPlayer.getPersistentData().remove("HxHCraft_HatsuAbility");
            ModMessages.sendToPlayer(new PacketSyncKit(id), targetPlayer);
            successCount++;
         } else {
            source.sendFailure(Component.literal("Can't set the kit for " + targetPlayer.getName().getString() + " (Nen type isn't compatible)."));
         }
      }

      if (successCount > 0) {
         int n = successCount;
         source.sendSuccess(() -> Component.literal("Kit set to " + kitName.toLowerCase() + " for " + n + " player(s)"), true);
      }
      return successCount;
   }
}
